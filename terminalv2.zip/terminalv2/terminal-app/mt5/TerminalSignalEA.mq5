//+------------------------------------------------------------------+
//|                                            TerminalSignalEA.mq5  |
//|  Eksekusi otomatis sinyal menu SIGNAL website Terminal           |
//|  (10 METODE & STRATEGI ONE). Tanpa API pihak ketiga/berbayar:    |
//|  EA hanya membaca website Anda sendiri.                          |
//|                                                                  |
//|  Cara kerja                                                      |
//|  - Tiap beberapa detik EA membaca  <URL>/api/ea/feed  (header    |
//|    X-Access-Key = kunci USER). Banyak EA boleh membaca sekaligus: |
//|    feed dibangun sekali untuk semua & dijawab 304 bila tetap.     |
//|  - Sinyal baru (PENDING) dipasang sebagai limit order. SL dan TP  |
//|    akhir langsung di broker; lot dihitung dari risiko per sinyal  |
//|    yang Anda atur di EA ini.                                      |
//|  - Ambil untung bertahap (TP1/TP2), breakeven, hapus E2 sesudah   |
//|    TP1 (ONE), dan batas waktu posisi (10 METODE) dikelola EA      |
//|    memakai harga broker Anda, sesuai aturan tiap sinyal.          |
//|  - Limit yang dibatalkan/kedaluwarsa dihapus otomatis.            |
//|  - Satu EA di SATU chart (pair apa saja) menangani semua pair.    |
//|  - Website/PC server mati: posisi tetap aman (SL/TP di broker) &  |
//|    tetap dikelola EA; hanya sinyal BARU yang tertunda.            |
//|                                                                  |
//|  Wajib sekali: Tools > Options > Expert Advisors > centang       |
//|  "Allow WebRequest for listed URL", lalu tambahkan URL website.  |
//|  Strategy Tester tidak bisa memakai WebRequest (EA ini live).    |
//+------------------------------------------------------------------+
#property copyright   "Terminal"
#property version     "1.00"
#property description "Auto-trade sinyal menu SIGNAL website Terminal (10 METODE & STRATEGI ONE)."
#property description "Risiko per sinyal & breakeven diatur di EA; sinyal diambil dari website Anda (tanpa API berbayar)."

#include <Trade\Trade.mqh>

#define TS_VER         "1.00"
#define TS_MIN_FIELDS  25          // kolom minimum format v1 (kolom baru hanya ditambah di belakang)

//--- pilihan
enum ENUM_TS_RISK
  {
   TS_RISK_PCT_BALANCE = 0,   // % saldo (balance)
   TS_RISK_PCT_EQUITY  = 1,   // % ekuitas (equity)
   TS_RISK_MONEY       = 2,   // uang tetap (mata uang akun)
   TS_RISK_FIXED_LOT   = 3    // lot tetap
  };
enum ENUM_TS_STRAT
  {
   TS_STRAT_ALL   = 0,        // semua strategi
   TS_STRAT_MULTI = 1,        // hanya 10 METODE
   TS_STRAT_ONE   = 2         // hanya STRATEGI ONE
  };
enum ENUM_TS_BE
  {
   TS_BE_ALWAYS = 0,          // aktif untuk 10 METODE & STRATEGI ONE
   TS_BE_SIGNAL = 1,          // ikuti pengaturan sinyal di website
   TS_BE_OFF    = 2           // mati
  };

//--- input
input group "=== Koneksi website ==="
input string InpServerURL       = "";                          // URL website terminal, mis. https://xxxx.trycloudflare.com
input string InpBackupURL       = "";                          // URL cadangan (opsional)
input string InpAccessKey       = "";                          // Kunci akses USER dari admin
input int    InpPollSec         = 10;                          // Ambil sinyal tiap N detik (min 5)

input group "=== Risiko per sinyal ==="
input ENUM_TS_RISK InpRiskMode  = TS_RISK_PCT_BALANCE;         // Cara menghitung lot
input double InpRiskPercent     = 0.5;                         // Risiko per sinyal (%) - mode % saldo/ekuitas
input double InpRiskMoney       = 50.0;                        // Risiko per sinyal (uang) - mode uang tetap
input double InpFixedLot        = 0.01;                        // Lot total per sinyal - mode lot tetap
input double InpMaxLot          = 5.0;                         // Batas lot total per sinyal
input bool   InpAllowMinLot     = false;                       // Lot terhitung < minimum: tetap pakai lot minimum
input double InpMinLotRiskMult  = 2.0;                         // ...hanya bila risikonya <= N x target

input group "=== Breakeven ==="
input ENUM_TS_BE InpBEMode      = TS_BE_ALWAYS;                // Breakeven (SL ke rata-rata harga entry)
input double InpBETriggerR      = 0.0;                         // Pindah ke BE saat untung >= N x R (0 = saat TP1 tercapai)
input int    InpBEOffsetPoints  = 0;                           // Tambahan offset BE (point) searah posisi, mis. tutup komisi

input group "=== Filter ==="
input ENUM_TS_STRAT InpStrategy = TS_STRAT_ALL;                // Strategi yang diikuti
input string InpOnlySymbols     = "";                          // Hanya pair ini (nama di website, pisah koma; kosong = semua)
input int    InpMaxSignalAgeMin = 60;                          // Abaikan sinyal yang terbit lebih dari N menit lalu
input int    InpMaxOpenSignals  = 5;                           // Maks. sinyal berjalan bersamaan
input double InpMaxDailyLossPct = 3.0;                         // Stop entry baru bila rugi hari ini >= % saldo awal hari (0 = mati)
input int    InpMaxSpreadPoints = 0;                           // Maks. spread (point) saat memasang order (0 = mati)

input group "=== Simbol broker ==="
input string InpSymbolPrefix    = "";                          // Awalan simbol broker (jarang dipakai)
input string InpSymbolSuffix    = "";                          // Akhiran simbol broker, mis. .m  m  .pro  -ECN
input string InpSymbolMap       = "";                          // Peta manual, mis. Gold=XAUUSD,US100=NAS100
input bool   InpAdjustToBroker  = true;                        // Geser level mengikuti selisih harga broker vs website
input double InpMaxPriceDiffPct = 1.5;                         // Lewati sinyal bila selisih harga > % (simbol salah?)

input group "=== Eksekusi & pengelolaan ==="
input long   InpMagic           = 26112601;                    // Magic number
input int    InpSlippagePoints  = 30;                          // Slippage maks. (point) order market
input bool   InpMarketIfPassed  = true;                        // Harga sudah melewati entry (lebih baik): masuk market
input bool   InpManageTP        = true;                        // Kelola TP bertahap & batas waktu sesuai sinyal
input bool   InpSyncCancel      = true;                        // Hapus limit bila sinyal batal/selesai di website
input bool   InpSyncClose       = false;                       // Tutup posisi bila website menyatakan sinyal selesai

//--- satu sinyal dari feed
struct TSSignal
  {
   string            uid;
   string            strat;
   string            sym;
   string            side;
   string            status;
   long              created;
   long              expiry;
   double            e[2];
   double            f[2];
   double            sl;
   double            tp[3];
   double            cf[3];
   int               be;
   double            beoff;
   int               cut2;
   double            ref;
   long              refts;
   double            r;
   long              hold;
  };

//--- keadaan global (direset di OnInit: MT5 tidak mereset global saat input diubah)
CTrade    g_trade;
TSSignal  g_sig[];
int       g_nsig      = 0;
string    g_primary   = "";
string    g_backup    = "";
string    g_key       = "";
string    g_url       = "";
string    g_etag      = "";
long      g_srvOffset = 0;            // waktu website - TimeGMT() komputer ini
datetime  g_lastPoll  = 0;
datetime  g_lastOk    = 0;
int       g_jitter    = 0;
string    g_lastErr   = "";
string    g_mapFrom[];
string    g_mapTo[];
string    g_warned[];
bool      g_hedging   = true;
double    g_todayPL   = 0.0;
datetime  g_plAt      = 0;

//+------------------------------------------------------------------+
//| teks                                                              |
//+------------------------------------------------------------------+
string Trim(string s)
  {
   StringReplace(s,"\r","");
   StringTrimLeft(s);
   StringTrimRight(s);
   return s;
  }

bool SameText(const string a,const string b)
  {
   return StringCompare(Trim(a),Trim(b),false)==0;
  }

void WarnOnce(const string key,const string msg)
  {
   for(int i=0;i<ArraySize(g_warned);i++)
      if(g_warned[i]==key)
         return;
   int n=ArraySize(g_warned);
   ArrayResize(g_warned,n+1);
   g_warned[n]=key;
   Print(msg);
  }

string HeaderValue(const string headers,const string name)
  {
   string lines[];
   int n=StringSplit(headers,'\n',lines);
   string want=name+":";
   StringToLower(want);
   for(int i=0;i<n;i++)
     {
      string l=Trim(lines[i]);
      string low=l;
      StringToLower(low);
      if(StringFind(low,want)==0)
         return Trim(StringSubstr(l,StringLen(want)));
     }
   return "";
  }

// "https://host/apa/saja?x" -> "https://host"
string BaseUrl(const string raw)
  {
   string u=Trim(raw);
   int p=StringFind(u,"://");
   if(p<0)
      return "";
   int slash=StringFind(u,"/",p+3);
   if(slash>0)
      u=StringSubstr(u,0,slash);
   return u;
  }

long NowSrv()
  {
   return (long)TimeGMT()+g_srvOffset;
  }

string Px(const string sym,const double p)
  {
   return DoubleToString(p,(int)SymbolInfoInteger(sym,SYMBOL_DIGITS));
  }

//+------------------------------------------------------------------+
//| GlobalVariables: catatan per sinyal (bertahan saat MT5 restart)  |
//+------------------------------------------------------------------+
string GVPrefix()
  {
   return "TS."+IntegerToString(InpMagic)+".";
  }
string GV(const string uid,const string k)
  {
   return GVPrefix()+uid+"."+k;
  }
double GVGet(const string uid,const string k,const double def=0.0)
  {
   string n=GV(uid,k);
   if(!GlobalVariableCheck(n))
      return def;
   return GlobalVariableGet(n);
  }
void GVSet(const string uid,const string k,const double v)
  {
   GlobalVariableSet(GV(uid,k),v);
  }
bool Processed(const string uid)
  {
   return GlobalVariableCheck(GV(uid,"done"));
  }
void MarkDone(const string uid)
  {
   GVSet(uid,"done",(double)TimeLocal());
  }
void GVDeleteSignal(const string uid)
  {
   string ks[]={"o1","o2","at","st","sh","exp","side","t1","t2","t3","c1","c2","c3","be","bo","cut","sl","avg","beok","e0","hold","try","fill"};
   for(int i=0;i<ArraySize(ks);i++)
      GlobalVariableDel(GV(uid,ks[i]));
  }

//+------------------------------------------------------------------+
//| simbol: nama website -> simbol broker                             |
//+------------------------------------------------------------------+
void Aliases(const string name,string &out[])
  {
   string u=name;
   StringToUpper(u);
   string list="";
   if(u=="GOLD")                    list="XAUUSD,GOLD";
   else if(u=="SILVER")             list="XAGUSD,SILVER";
   else if(u=="PLATINUM")           list="XPTUSD,PLATINUM";
   else if(u=="PALLADIUM")          list="XPDUSD,PALLADIUM";
   else if(u=="COPPER")             list="XCUUSD,COPPER";
   else if(u=="CRUDE OIL WTI")      list="USOIL,XTIUSD,WTI,USOUSD,OILCASH";
   else if(u=="BRENT OIL")          list="UKOIL,XBRUSD,BRENT,UKOUSD,BRENTCASH";
   else if(u=="NATURAL GAS")        list="XNGUSD,NATGAS,NGAS,NGCASH";
   else if(u=="BITCOIN")            list="BTCUSD,BITCOIN,BTCUSDT";
   else if(u=="ETHEREUM")           list="ETHUSD,ETHEREUM,ETHUSDT";
   else if(u=="US500")              list="US500,SPX500,SP500,US500CASH,USA500,SPX";
   else if(u=="US100")              list="US100,USTEC,NAS100,NDX100,US100CASH,USATEC,NASDAQ";
   else if(u=="US30")               list="US30,DJ30,WS30,DJI30,US30CASH,USA30";
   else if(u=="US2000")             list="US2000,RUSSELL2000,US2000CASH";
   else if(u=="DAX30" || u=="DAX40" || u=="GER40") list="GER40,DE40,GER30,DE30,DAX40,DAX30,GER40CASH";
   else if(u=="FTSE100")            list="UK100,FTSE100,UK100CASH";
   else if(u=="CAC40")              list="FRA40,F40,CAC40,FRA40CASH";
   else if(u=="EU50")               list="EU50,STOXX50,EUSTX50,EU50CASH";
   else if(u=="CH20")               list="SWI20,CH20,SMI20,SWI20CASH";
   else if(u=="IBEX35")             list="ESP35,SPA35,IBEX35,ESP35CASH";
   else if(u=="NIKKEI225")          list="JP225,JPN225,NIKKEI225,JP225CASH";
   else if(u=="HK50")               list="HK50,HSI,HK50CASH";
   else if(u=="ASX200")             list="AUS200,ASX200,AUS200CASH";
   else if(u=="USD INDEX")          list="DXY,USDX,USDINDEX";
   else
     {
      StringReplace(u," ","");
      list=u;
     }
   StringSplit(list,',',out);
  }

string MapManual(const string name)
  {
   if(InpSymbolMap=="")
      return "";
   string pairs[];
   int n=StringSplit(InpSymbolMap,',',pairs);
   for(int i=0;i<n;i++)
     {
      string kv[];
      if(StringSplit(pairs[i],'=',kv)==2 && SameText(kv[0],name))
         return Trim(kv[1]);
     }
   return "";
  }

bool TrySymbol(const string s)
  {
   if(s=="")
      return false;
   if(!SymbolSelect(s,true))
      return false;
   return SymbolInfoInteger(s,SYMBOL_TRADE_MODE)!=SYMBOL_TRADE_MODE_DISABLED;
  }

string BrokerSymbol(const string name)
  {
   for(int i=0;i<ArraySize(g_mapFrom);i++)
      if(g_mapFrom[i]==name)
         return g_mapTo[i];
   string found="";
   string manual=MapManual(name);
   if(manual!="")
     {
      if(TrySymbol(manual))
         found=manual;
      else if(TrySymbol(InpSymbolPrefix+manual+InpSymbolSuffix))
         found=InpSymbolPrefix+manual+InpSymbolSuffix;
     }
   if(found=="")
     {
      string al[];
      Aliases(name,al);
      for(int i=0;i<ArraySize(al) && found=="";i++)
        {
         string c=Trim(al[i]);
         if(c=="")
            continue;
         if(TrySymbol(InpSymbolPrefix+c+InpSymbolSuffix))
            found=InpSymbolPrefix+c+InpSymbolSuffix;
         else if(TrySymbol(c))
            found=c;
        }
     }
   int k=ArraySize(g_mapFrom);
   ArrayResize(g_mapFrom,k+1);
   ArrayResize(g_mapTo,k+1);
   g_mapFrom[k]=name;
   g_mapTo[k]=found;
   if(found=="")
      WarnOnce("nosym:"+name,"[TS] Simbol '"+name+"' tidak ditemukan di broker. Isi InpSymbolMap, mis. "+name+"=NAMA_DI_BROKER");
   else
      Print("[TS] Simbol website '",name,"' -> broker '",found,"'");
   return found;
  }

bool SymbolAllowed(const string name)
  {
   if(InpOnlySymbols=="")
      return true;
   string list[];
   int n=StringSplit(InpOnlySymbols,',',list);
   for(int i=0;i<n;i++)
      if(SameText(list[i],name))
         return true;
   return false;
  }

//+------------------------------------------------------------------+
//| feed: ambil & urai                                                |
//+------------------------------------------------------------------+
bool ParseFeed(const string text)
  {
   string lines[];
   int n=StringSplit(text,'\n',lines);
   if(n<1)
      return false;
   string head[];
   if(StringSplit(Trim(lines[0]),'|',head)<4 || head[0]!="TSIG")
     {
      g_lastErr="jawaban website bukan feed sinyal (URL benar?)";
      return false;
     }
   if(head[1]!="1")
      WarnOnce("ver"+head[1],"[TS] Feed versi "+head[1]+" lebih baru dari EA ini (v1). Minta EA terbaru ke admin.");
   long srv=StringToInteger(head[2]);
   if(srv>0)
      g_srvOffset=srv-(long)TimeGMT();
   ArrayResize(g_sig,0,64);
   g_nsig=0;
   for(int i=1;i<n;i++)
     {
      string l=Trim(lines[i]);
      if(StringLen(l)<3 || StringSubstr(l,0,2)!="S|")
         continue;
      string f[];
      int nf=StringSplit(l,'|',f);
      if(nf<TS_MIN_FIELDS)
         continue;
      TSSignal s;
      s.uid=f[1];
      s.strat=f[2];
      s.sym=f[3];
      s.side=f[4];
      s.status=f[5];
      s.created=StringToInteger(f[6]);
      s.expiry=StringToInteger(f[7]);
      s.e[0]=StringToDouble(f[8]);
      s.f[0]=StringToDouble(f[9]);
      s.e[1]=StringToDouble(f[10]);
      s.f[1]=StringToDouble(f[11]);
      s.sl=StringToDouble(f[12]);
      s.tp[0]=StringToDouble(f[13]);
      s.tp[1]=StringToDouble(f[14]);
      s.tp[2]=StringToDouble(f[15]);
      s.cf[0]=StringToDouble(f[16]);
      s.cf[1]=StringToDouble(f[17]);
      s.cf[2]=StringToDouble(f[18]);
      s.be=(int)StringToInteger(f[19]);
      s.beoff=StringToDouble(f[20]);
      s.cut2=(int)StringToInteger(f[21]);
      s.ref=StringToDouble(f[22]);
      s.refts=StringToInteger(f[23]);
      s.r=StringToDouble(f[24]);
      s.hold=(nf>25) ? StringToInteger(f[25]) : 0;
      ArrayResize(g_sig,g_nsig+1,64);
      g_sig[g_nsig]=s;
      g_nsig++;
     }
   return true;
  }

bool FetchFrom(const string baseUrl)
  {
   if(baseUrl=="")
      return false;
   string url=baseUrl+"/api/ea/feed";
   string headers="X-Access-Key: "+g_key+"\r\nUser-Agent: TerminalSignalEA/"+TS_VER+"\r\nAccept: text/plain\r\n";
   if(g_etag!="" && g_url==baseUrl)
      headers+="If-None-Match: "+g_etag+"\r\n";
   char post[];
   char res[];
   string rh;
   ResetLastError();
   int code=WebRequest("GET",url,headers,5000,post,res,rh);
   if(code==-1)
     {
      int err=GetLastError();
      if(err==4014)
         g_lastErr="WebRequest belum diizinkan: Tools > Options > Expert Advisors > Allow WebRequest, tambahkan "+baseUrl;
      else
         g_lastErr="tidak bisa menghubungi "+baseUrl+" (error "+IntegerToString(err)+"; URL benar & website menyala?)";
      WarnOnce("wr"+IntegerToString(err)+baseUrl,"[TS] "+g_lastErr);
      return false;
     }
   if(code==304)
     {
      g_url=baseUrl;
      return true;
     }
   if(code==401 || code==403)
     {
      g_lastErr="kunci akses ditolak (HTTP "+IntegerToString(code)+") - periksa InpAccessKey";
      WarnOnce("auth"+baseUrl,"[TS] "+g_lastErr);
      return false;
     }
   if(code!=200)
     {
      g_lastErr="website menjawab HTTP "+IntegerToString(code)+" (URL lama / website mati?)";
      return false;
     }
   if(!ParseFeed(CharArrayToString(res,0,WHOLE_ARRAY,CP_UTF8)))
      return false;
   g_etag=HeaderValue(rh,"ETag");
   if(g_url!=baseUrl)
      Print("[TS] Terhubung ke ",baseUrl," (",g_nsig," sinyal di feed)");
   g_url=baseUrl;
   return true;
  }

void Poll()
  {
   string first=(g_url=="") ? g_primary : g_url;
   bool ok=FetchFrom(first);
   if(!ok && g_backup!="")
     {
      string other=(first==g_backup) ? g_primary : g_backup;
      g_etag="";
      ok=FetchFrom(other);
     }
   if(ok)
     {
      g_lastOk=TimeLocal();
      g_lastErr="";
     }
  }

//+------------------------------------------------------------------+
//| volume, harga, risiko                                             |
//+------------------------------------------------------------------+
double NormVolume(const string sym,double v)
  {
   double step=SymbolInfoDouble(sym,SYMBOL_VOLUME_STEP);
   double vmin=SymbolInfoDouble(sym,SYMBOL_VOLUME_MIN);
   double vmax=SymbolInfoDouble(sym,SYMBOL_VOLUME_MAX);
   if(step<=0)
      step=0.01;
   v=MathFloor(v/step+1e-9)*step;
   if(vmax>0 && v>vmax)
      v=vmax;
   if(v<vmin-1e-12)
      return 0.0;
   int dg=(int)MathMax(0.0,MathCeil(-MathLog10(step)-1e-9));
   return NormalizeDouble(v,dg);
  }

double NormPrice(const string sym,double p)
  {
   double ts=SymbolInfoDouble(sym,SYMBOL_TRADE_TICK_SIZE);
   if(ts>0)
      p=MathRound(p/ts)*ts;
   return NormalizeDouble(p,(int)SymbolInfoInteger(sym,SYMBOL_DIGITS));
  }

// rugi (uang akun, positif) bila 1 lot bergerak dari 'from' ke 'sl'
double LossPerLot(const string sym,const bool buy,const double from,const double sl)
  {
   double profit=0.0;
   if(OrderCalcProfit(buy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,sym,1.0,from,sl,profit) && profit<0)
      return -profit;
   double tv=SymbolInfoDouble(sym,SYMBOL_TRADE_TICK_VALUE_LOSS);
   double ts=SymbolInfoDouble(sym,SYMBOL_TRADE_TICK_SIZE);
   if(tv<=0)
      tv=SymbolInfoDouble(sym,SYMBOL_TRADE_TICK_VALUE);
   if(ts<=0 || tv<=0)
      return 0.0;
   return MathAbs(from-sl)/ts*tv;
  }

double RiskMoney()
  {
   if(InpRiskMode==TS_RISK_PCT_BALANCE)
      return AccountInfoDouble(ACCOUNT_BALANCE)*InpRiskPercent/100.0;
   if(InpRiskMode==TS_RISK_PCT_EQUITY)
      return AccountInfoDouble(ACCOUNT_EQUITY)*InpRiskPercent/100.0;
   if(InpRiskMode==TS_RISK_MONEY)
      return InpRiskMoney;
   return 0.0;
  }

//+------------------------------------------------------------------+
//| batas harian                                                      |
//+------------------------------------------------------------------+
datetime DayStart()
  {
   MqlDateTime t;
   TimeToStruct(TimeTradeServer(),t);
   t.hour=0;
   t.min=0;
   t.sec=0;
   return StructToTime(t);
  }

void DayRoll()
  {
   string kd=GVPrefix()+"day";
   double d0=(double)DayStart();
   if(!GlobalVariableCheck(kd) || GlobalVariableGet(kd)!=d0)
     {
      GlobalVariableSet(kd,d0);
      GlobalVariableSet(GVPrefix()+"day.bal",AccountInfoDouble(ACCOUNT_BALANCE));
     }
  }

double TodayPL()
  {
   double pl=0.0;
   if(HistorySelect(DayStart(),TimeTradeServer()+60))
     {
      int n=HistoryDealsTotal();
      for(int i=0;i<n;i++)
        {
         ulong t=HistoryDealGetTicket(i);
         if(t==0 || HistoryDealGetInteger(t,DEAL_MAGIC)!=InpMagic)
            continue;
         pl+=HistoryDealGetDouble(t,DEAL_COMMISSION);
         long en=HistoryDealGetInteger(t,DEAL_ENTRY);
         if(en==DEAL_ENTRY_OUT || en==DEAL_ENTRY_INOUT || en==DEAL_ENTRY_OUT_BY)
            pl+=HistoryDealGetDouble(t,DEAL_PROFIT)+HistoryDealGetDouble(t,DEAL_SWAP);
        }
     }
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong pt=PositionGetTicket(i);
      if(pt==0 || PositionGetInteger(POSITION_MAGIC)!=InpMagic)
         continue;
      pl+=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
     }
   g_todayPL=pl;
   g_plAt=TimeLocal();
   return pl;
  }

bool DailyLossHit()
  {
   if(InpMaxDailyLossPct<=0)
      return false;
   DayRoll();
   double bal0=GlobalVariableGet(GVPrefix()+"day.bal");
   return bal0>0 && TodayPL()<=-bal0*InpMaxDailyLossPct/100.0;
  }

//+------------------------------------------------------------------+
//| pelacakan order & posisi milik sinyal                             |
//+------------------------------------------------------------------+
int TrackedUids(string &uids[])
  {
   ArrayResize(uids,0);
   string pre=GVPrefix();
   int total=GlobalVariablesTotal();
   for(int i=0;i<total;i++)
     {
      string n=GlobalVariableName(i);
      if(StringFind(n,pre)!=0)
         continue;
      int L=StringLen(n);
      if(L<4 || StringSubstr(n,L-3)!=".o1")
         continue;
      int k=ArraySize(uids);
      ArrayResize(uids,k+1);
      uids[k]=StringSubstr(n,StringLen(pre),L-StringLen(pre)-3);
     }
   return ArraySize(uids);
  }

bool IsMyLeg(const string uid,const ulong id)
  {
   if(id==0)
      return false;
   return id==(ulong)GVGet(uid,"o1") || id==(ulong)GVGet(uid,"o2");
  }

bool SelectMyPosition(const int i,const string uid)
  {
   ulong pt=PositionGetTicket(i);
   return pt!=0 && PositionGetInteger(POSITION_MAGIC)==InpMagic && IsMyLeg(uid,(ulong)PositionGetInteger(POSITION_IDENTIFIER));
  }

bool SelectMyOrder(const int i,const string uid)
  {
   ulong t=OrderGetTicket(i);
   return t!=0 && OrderGetInteger(ORDER_MAGIC)==InpMagic && IsMyLeg(uid,t);
  }

void CountLive(const string uid,int &npend,int &npos)
  {
   npend=0;
   npos=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
      if(SelectMyOrder(i,uid))
         npend++;
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(SelectMyPosition(i,uid))
         npos++;
  }

int OpenSignalCount()
  {
   string uids[];
   int n=TrackedUids(uids);
   int live=0;
   for(int i=0;i<n;i++)
     {
      int a=0,b=0;
      CountLive(uids[i],a,b);
      if(a+b>0)
         live++;
     }
   return live;
  }

bool SymbolBusy(const string sym)
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(PositionGetTicket(i)!=0 && PositionGetString(POSITION_SYMBOL)==sym)
         return true;
   for(int i=OrdersTotal()-1;i>=0;i--)
      if(OrderGetTicket(i)!=0 && OrderGetString(ORDER_SYMBOL)==sym && OrderGetInteger(ORDER_MAGIC)==InpMagic)
         return true;
   return false;
  }

//+------------------------------------------------------------------+
//| entry sinyal baru                                                 |
//+------------------------------------------------------------------+
bool TradingAllowed()
  {
   return TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) && MQLInfoInteger(MQL_TRADE_ALLOWED) && AccountInfoInteger(ACCOUNT_TRADE_ALLOWED);
  }

// 1 = limit, 2 = market, 0 = lewati kaki ini, -1 = tunggu (harga terlalu dekat), -2 = harga sudah di/lewat SL (sinyal gugur)
int LegAction(const string sym,const bool buy,const double e,const double sl,const MqlTick &tk)
  {
   double pt=SymbolInfoDouble(sym,SYMBOL_POINT);
   double stops=(double)SymbolInfoInteger(sym,SYMBOL_TRADE_STOPS_LEVEL)*pt;
   if(buy)
     {
      if(tk.bid<=sl)
         return -2;
      if(e<=tk.ask-stops-pt)
         return 1;
      if(tk.ask<=e)
         return (InpMarketIfPassed && tk.bid>sl+stops) ? 2 : -1;
      return -1;
     }
   if(tk.ask>=sl)
      return -2;
   if(e>=tk.bid+stops+pt)
      return 1;
   if(tk.bid>=e)
      return (InpMarketIfPassed && tk.ask<sl-stops) ? 2 : -1;
   return -1;
  }

bool Transient(const uint rc)
  {
   return rc==TRADE_RETCODE_MARKET_CLOSED || rc==TRADE_RETCODE_REQUOTE || rc==TRADE_RETCODE_PRICE_CHANGED ||
          rc==TRADE_RETCODE_PRICE_OFF || rc==TRADE_RETCODE_TOO_MANY_REQUESTS || rc==TRADE_RETCODE_CONNECTION ||
          rc==TRADE_RETCODE_TIMEOUT || rc==TRADE_RETCODE_SERVER_DISABLES_AT || rc==TRADE_RETCODE_CLIENT_DISABLES_AT;
  }

bool Placed()
  {
   uint rc=g_trade.ResultRetcode();
   return rc==TRADE_RETCODE_DONE || rc==TRADE_RETCODE_PLACED || rc==TRADE_RETCODE_DONE_PARTIAL;
  }

// pasang satu kaki; limit memakai kedaluwarsa di broker bila didukung (aman walau MT5 mati)
ulong PlaceLeg(const string sym,const bool buy,const int act,const double lot,const double e,const double sl,const double tp,
               const long expiry_web,const string cmt,uint &rc)
  {
   bool ok=false;
   if(act==2)
      ok=buy ? g_trade.Buy(lot,sym,0.0,sl,tp,cmt) : g_trade.Sell(lot,sym,0.0,sl,tp,cmt);
   else
     {
      ENUM_ORDER_TYPE_TIME ttype=ORDER_TIME_GTC;
      datetime texp=0;
      long em=SymbolInfoInteger(sym,SYMBOL_EXPIRATION_MODE);
      if(expiry_web>0 && (em & SYMBOL_EXPIRATION_SPECIFIED)!=0)
        {
         long brokerShift=(long)TimeTradeServer()-(long)TimeGMT();
         long t=expiry_web-g_srvOffset+brokerShift;
         if(t>(long)TimeTradeServer()+120)
           {
            ttype=ORDER_TIME_SPECIFIED;
            texp=(datetime)t;
           }
        }
      ok=buy ? g_trade.BuyLimit(lot,e,sym,sl,tp,ttype,texp,cmt) : g_trade.SellLimit(lot,e,sym,sl,tp,ttype,texp,cmt);
      if(!Placed() && ttype==ORDER_TIME_SPECIFIED && g_trade.ResultRetcode()==TRADE_RETCODE_INVALID_EXPIRATION)
         ok=buy ? g_trade.BuyLimit(lot,e,sym,sl,tp,ORDER_TIME_GTC,0,cmt) : g_trade.SellLimit(lot,e,sym,sl,tp,ORDER_TIME_GTC,0,cmt);
     }
   rc=g_trade.ResultRetcode();
   if(ok && Placed())
      return g_trade.ResultOrder();
   return 0;
  }

void Enter(const TSSignal &s)
  {
   if(InpStrategy==TS_STRAT_MULTI && s.strat!="MULTI")
      return;
   if(InpStrategy==TS_STRAT_ONE && s.strat!="ONE")
      return;
   if(!SymbolAllowed(s.sym))
      return;
   long now=NowSrv();
   if(now-s.created>(long)InpMaxSignalAgeMin*60 || (s.expiry>0 && now>=s.expiry))
      return;                                                     // sinyal lama / kedaluwarsa: tidak dikejar
   if(!TradingAllowed())
     {
      WarnOnce("algo","[TS] Trading otomatis belum diizinkan (tombol Algo Trading / centang Allow Algo Trading di EA).");
      return;
     }
   if(OpenSignalCount()>=InpMaxOpenSignals)
      return;
   if(DailyLossHit())
     {
      WarnOnce("dd"+IntegerToString((long)DayStart()),"[TS] Batas rugi harian tercapai: tidak ada entry baru sampai besok.");
      return;
     }
   string sym=BrokerSymbol(s.sym);
   if(sym=="")
      return;
   if(SymbolInfoInteger(sym,SYMBOL_TRADE_MODE)!=SYMBOL_TRADE_MODE_FULL)
     {
      WarnOnce("tm"+sym,"[TS] "+sym+": simbol tidak bisa diperdagangkan dua arah (cek izin akun).");
      return;
     }
   if(!g_hedging && SymbolBusy(sym))
      return;                                                     // akun netting: satu sinyal per simbol
   MqlTick tk;
   if(!SymbolInfoTick(sym,tk) || tk.bid<=0 || tk.ask<=0)
      return;
   if(InpMaxSpreadPoints>0 && SymbolInfoInteger(sym,SYMBOL_SPREAD)>InpMaxSpreadPoints)
      return;
   bool buy=(s.side=="BUY");
   double mid=(tk.bid+tk.ask)/2.0;
   //--- selisih harga broker vs sumber data website (simbol salah -> lewati)
   double shift=0.0;
   double refPx=(s.ref>0) ? s.ref : s.e[0];
   double tol=(s.ref>0) ? InpMaxPriceDiffPct : InpMaxPriceDiffPct*2.0;
   double diffPct=(refPx>0) ? MathAbs(mid-refPx)/refPx*100.0 : 100.0;
   if(diffPct>tol)
     {
      WarnOnce("diff"+s.uid,StringFormat("[TS] %s %s dilewati: harga broker %s beda %.2f%% dari website %s (simbol salah? cek InpSymbolMap)",
               s.uid,s.sym,Px(sym,mid),diffPct,DoubleToString(refPx,8)));
      return;
     }
   if(s.ref>0 && InpAdjustToBroker && now-s.refts<=900)
      shift=mid-s.ref;
   double e1=NormPrice(sym,s.e[0]+shift);
   double e2=(s.f[1]>0 && s.e[1]>0) ? NormPrice(sym,s.e[1]+shift) : 0.0;
   double sl=NormPrice(sym,s.sl+shift);
   double tpFinal=0.0;
   for(int k=2;k>=0;k--)
      if(s.tp[k]>0)
        {
         tpFinal=NormPrice(sym,s.tp[k]+shift);
         break;
        }
   bool geo=buy ? (sl<e1 && (tpFinal==0 || tpFinal>e1)) : (sl>e1 && (tpFinal==0 || tpFinal<e1));
   if(!geo)
     {
      WarnOnce("geo"+s.uid,"[TS] "+s.uid+": level sinyal tidak valid, dilewati.");
      MarkDone(s.uid);
      return;
     }
   //--- lot (porsi kaki f1/f2 sesuai sinyal)
   double f1=s.f[0];
   double f2=(e2>0) ? s.f[1] : 0.0;
   if(f1+f2<=0)
      f1=1.0;
   double lot1=0.0,lot2=0.0;
   double risk=RiskMoney();
   if(InpRiskMode==TS_RISK_FIXED_LOT)
     {
      double tot=MathMin(InpFixedLot,InpMaxLot);
      lot1=NormVolume(sym,tot*f1/(f1+f2));
      lot2=(f2>0) ? NormVolume(sym,tot*f2/(f1+f2)) : 0.0;
     }
   else
     {
      double eavg=(f2>0) ? (f1*e1+f2*e2)/(f1+f2) : e1;
      double lpl=LossPerLot(sym,buy,eavg,sl);
      if(risk<=0 || lpl<=0)
        {
         WarnOnce("lpl"+s.uid,"[TS] "+s.uid+": nilai risiko per lot "+sym+" tidak bisa dihitung, dilewati.");
         return;
        }
      double tot=MathMin(risk/lpl,InpMaxLot);
      lot1=NormVolume(sym,tot*f1/(f1+f2));
      lot2=(f2>0) ? NormVolume(sym,tot*f2/(f1+f2)) : 0.0;
      if(f2>0 && lot2<=0)
        {
         // kaki 2 di bawah lot minimum: hanya E1, risiko penuh pada jarak E1-SL (aturan sinyal ONE)
         double l1=LossPerLot(sym,buy,e1,sl);
         lot1=(l1>0) ? NormVolume(sym,MathMin(risk/l1,InpMaxLot)) : 0.0;
         e2=0.0;
        }
     }
   if(lot1<=0)
     {
      double vmin=SymbolInfoDouble(sym,SYMBOL_VOLUME_MIN);
      double rmin=LossPerLot(sym,buy,e1,sl)*vmin;
      if(InpAllowMinLot && (InpRiskMode==TS_RISK_FIXED_LOT || rmin<=risk*InpMinLotRiskMult))
        {
         lot1=NormVolume(sym,vmin);
         e2=0.0;
        }
      else
        {
         WarnOnce("lot"+s.uid,StringFormat("[TS] %s %s dilewati: lot terhitung di bawah minimum %.2f (risiko lot minimum %.2f > target %.2f %s).",
                  s.uid,sym,vmin,rmin,risk,AccountInfoString(ACCOUNT_CURRENCY)));
         MarkDone(s.uid);
         return;
        }
     }
   double entries[2];
   double lots[2];
   int act[2];
   entries[0]=e1;
   entries[1]=e2;
   lots[0]=lot1;
   lots[1]=(e2>0) ? lot2 : 0.0;
   for(int leg=0;leg<2;leg++)
     {
      act[leg]=(lots[leg]>0 && entries[leg]>0) ? LegAction(sym,buy,entries[leg],sl,tk) : 0;
      if(act[leg]==-2)
        {
         Print("[TS] ",s.uid," ",sym,": harga sudah menyentuh SL sinyal sebelum entry, dilewati.");
         MarkDone(s.uid);
         return;
        }
      if(act[leg]==-1)
         return;                                                  // terlalu dekat harga: coba lagi putaran berikutnya
     }
   //--- pasang
   g_trade.SetExpertMagicNumber((ulong)InpMagic);
   g_trade.SetDeviationInPoints((ulong)InpSlippagePoints);
   g_trade.SetTypeFillingBySymbol(sym);
   ulong tickets[2]={0,0};
   int placed=0;
   bool transient=false;
   for(int leg=0;leg<2;leg++)
     {
      if(act[leg]<=0)
         continue;
      uint rc=0;
      tickets[leg]=PlaceLeg(sym,buy,act[leg],lots[leg],entries[leg],sl,tpFinal,s.expiry,"TS|"+s.uid+"|"+IntegerToString(leg+1),rc);
      if(tickets[leg]>0)
         placed++;
      else
        {
         transient=transient || Transient(rc);
         Print("[TS] ",s.uid," kaki ",leg+1," gagal: ",rc," ",g_trade.ResultRetcodeDescription());
        }
     }
   if(placed==0)
     {
      if(!transient)
        {
         double tries=GVGet(s.uid,"try",0)+1;
         GVSet(s.uid,"try",tries);
         if(tries>=3)
           {
            Print("[TS] ",s.uid,": 3x gagal dipasang, sinyal dilewati.");
            MarkDone(s.uid);
           }
        }
      return;
     }
   //--- catat (bertahan saat restart) - dipakai pengelolaan walau website tidak terjangkau
   MarkDone(s.uid);
   GVSet(s.uid,"o1",(double)tickets[0]);
   GVSet(s.uid,"o2",(double)tickets[1]);
   GVSet(s.uid,"at",(double)TimeLocal());
   GVSet(s.uid,"st",0);
   GVSet(s.uid,"sh",shift);
   GVSet(s.uid,"exp",(double)s.expiry);
   GVSet(s.uid,"side",buy ? 1 : -1);
   GVSet(s.uid,"t1",s.tp[0]>0 ? NormPrice(sym,s.tp[0]+shift) : 0);
   GVSet(s.uid,"t2",s.tp[1]>0 ? NormPrice(sym,s.tp[1]+shift) : 0);
   GVSet(s.uid,"t3",s.tp[2]>0 ? NormPrice(sym,s.tp[2]+shift) : 0);
   GVSet(s.uid,"c1",s.cf[0]);
   GVSet(s.uid,"c2",s.cf[1]);
   GVSet(s.uid,"c3",s.cf[2]);
   GVSet(s.uid,"be",s.be);
   GVSet(s.uid,"bo",s.beoff);
   GVSet(s.uid,"cut",s.cut2);
   GVSet(s.uid,"sl",sl);
   GVSet(s.uid,"hold",(double)s.hold);
   string how1=(act[0]==2) ? "market" : "limit";
   string leg2=(tickets[1]>0) ? StringFormat(" | kaki 2 %.2f lot %s @ %s",lots[1],(act[1]==2) ? "market" : "limit",Px(sym,e2)) : "";
   Print("[TS] ",s.uid," ",s.strat," ",s.side," ",sym,": kaki 1 ",DoubleToString(lots[0],2)," lot ",how1," @ ",Px(sym,e1),leg2,
         " | SL ",Px(sym,sl)," | TP ",Px(sym,tpFinal)," | geser ",DoubleToString(shift,(int)SymbolInfoInteger(sym,SYMBOL_DIGITS)));
  }

//+------------------------------------------------------------------+
//| pengelolaan: hapus limit, TP bertahap, breakeven, batas waktu    |
//+------------------------------------------------------------------+
void DeletePendings(const string uid,const string why)
  {
   for(int i=OrdersTotal()-1;i>=0;i--)
      if(SelectMyOrder(i,uid))
        {
         ulong t=(ulong)OrderGetInteger(ORDER_TICKET);
         if(g_trade.OrderDelete(t))
            Print("[TS] ",uid,": limit #",t," dihapus (",why,")");
        }
  }

void ClosePositions(const string uid,const string why)
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(SelectMyPosition(i,uid))
        {
         ulong pt=(ulong)PositionGetInteger(POSITION_TICKET);
         if(g_trade.PositionClose(pt,(ulong)InpSlippagePoints))
            Print("[TS] ",uid,": posisi #",pt," ditutup (",why,")");
        }
  }

double AvgOpen(const string uid)
  {
   double vol=0.0,wsum=0.0;
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(SelectMyPosition(i,uid))
        {
         double v=PositionGetDouble(POSITION_VOLUME);
         vol+=v;
         wsum+=v*PositionGetDouble(POSITION_PRICE_OPEN);
        }
   return (vol>0) ? wsum/vol : 0.0;
  }

datetime FirstOpenTime(const string uid)
  {
   datetime t0=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(SelectMyPosition(i,uid))
        {
         datetime t=(datetime)PositionGetInteger(POSITION_TIME);
         if(t0==0 || t<t0)
            t0=t;
        }
   return t0;
  }

// tutup 'frac' dari volume TERBUKA sinyal (1 = semua)
void CloseFraction(const string uid,const string sym,const double frac,const string why)
  {
   if(frac>=0.999)
     {
      ClosePositions(uid,why);
      return;
     }
   ulong tks[];
   double vols[];
   double open=0.0;
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(SelectMyPosition(i,uid))
        {
         int k=ArraySize(tks);
         ArrayResize(tks,k+1);
         ArrayResize(vols,k+1);
         tks[k]=(ulong)PositionGetInteger(POSITION_TICKET);
         vols[k]=PositionGetDouble(POSITION_VOLUME);
         open+=vols[k];
        }
   double want=NormVolume(sym,open*frac);
   if(want<=0)
     {
      Print("[TS] ",uid,": porsi ",why," di bawah lot minimum, posisi dibiarkan ke TP berikutnya.");
      return;
     }
   double vmin=SymbolInfoDouble(sym,SYMBOL_VOLUME_MIN);
   for(int k=ArraySize(tks)-1;k>=0 && want>1e-12;k--)
     {
      double v=MathMin(want,vols[k]);
      if(vols[k]-v<vmin-1e-12)
         v=vols[k];                                               // sisa terlalu kecil: tutup posisi itu penuh
      bool ok=false;
      if(v>=vols[k]-1e-12)
         ok=g_trade.PositionClose(tks[k],(ulong)InpSlippagePoints);
      else if(g_hedging)
         ok=g_trade.PositionClosePartial(tks[k],v,(ulong)InpSlippagePoints);
      else if(PositionSelectByTicket(tks[k]))
        {
         bool isBuy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
         ok=isBuy ? g_trade.Sell(v,sym,0.0,0.0,0.0,"TS|"+uid+"|x") : g_trade.Buy(v,sym,0.0,0.0,0.0,"TS|"+uid+"|x");
        }
      if(ok)
        {
         want-=v;
         Print("[TS] ",uid,": ",why," - tutup ",DoubleToString(v,2)," lot");
        }
     }
  }

// breakeven aktif untuk sinyal ini?  (pengaturan EA; mode "ikuti sinyal" memakai bendera dari website)
bool BEEnabled(const string uid)
  {
   if(InpBEMode==TS_BE_OFF)
      return false;
   if(InpBEMode==TS_BE_ALWAYS)
      return true;
   return GVGet(uid,"be",0)>0;
  }

// SL semua posisi sinyal -> rata-rata harga entry (+offset sinyal + offset EA, searah posisi).
// Limit kaki yang belum terisi dihapus (posisinya di balik SL baru).
void MoveToBreakeven(const string uid,const string sym,const bool buy,const string why)
  {
   double avg=GVGet(uid,"avg",0);
   if(avg<=0)
      avg=AvgOpen(uid);
   if(avg<=0)
      return;
   double pt=SymbolInfoDouble(sym,SYMBOL_POINT);
   double off=GVGet(uid,"bo",0)+InpBEOffsetPoints*pt;
   double be=NormPrice(sym,buy ? avg+off : avg-off);
   MqlTick tk;
   if(!SymbolInfoTick(sym,tk))
      return;
   DeletePendings(uid,"breakeven aktif");
   //--- harga sudah balik melewati breakeven sebelum SL sempat dipindah: tutup sisa (sama dengan aturan sinyal)
   if(buy ? (tk.bid<=be) : (tk.ask>=be))
     {
      CloseFraction(uid,sym,1.0,"kembali ke breakeven ("+why+")");
      GVSet(uid,"beok",1);
      return;
     }
   double gap=(double)MathMax(SymbolInfoInteger(sym,SYMBOL_TRADE_STOPS_LEVEL),SymbolInfoInteger(sym,SYMBOL_TRADE_FREEZE_LEVEL))*pt;
   if(buy ? (be>tk.bid-gap) : (be<tk.ask+gap))
      return;                                                     // terlalu dekat harga: coba lagi nanti
   bool allok=true;
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(SelectMyPosition(i,uid))
        {
         ulong ticket=(ulong)PositionGetInteger(POSITION_TICKET);
         double cur=PositionGetDouble(POSITION_SL);
         double tp=PositionGetDouble(POSITION_TP);
         if(buy ? (cur>=be-pt*0.5) : (cur>0 && cur<=be+pt*0.5))
            continue;                                             // SL sudah sama/lebih baik
         if(g_trade.PositionModify(ticket,be,tp))
            Print("[TS] ",uid,": SL #",ticket," -> breakeven ",Px(sym,be)," (",why,")");
         else
            allok=false;
        }
   if(allok)
      GVSet(uid,"beok",1);
  }

string SymbolOfUid(const string uid)
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(SelectMyPosition(i,uid))
         return PositionGetString(POSITION_SYMBOL);
   for(int i=OrdersTotal()-1;i>=0;i--)
      if(SelectMyOrder(i,uid))
         return OrderGetString(ORDER_SYMBOL);
   return "";
  }

int FindSignal(const string uid)
  {
   for(int i=0;i<g_nsig;i++)
      if(g_sig[i].uid==uid)
         return i;
   return -1;
  }

bool IsFinal(const string st)
  {
   return st!="PENDING" && st!="OPEN";
  }

void ManageUid(const string uid)
  {
   int npend=0,npos=0;
   CountLive(uid,npend,npos);
   if(npend+npos==0)
     {
      // selesai di broker (SL/TP/dihapus). Tunggu sebentar: limit yang baru terisi bisa sesaat tidak terlihat.
      if((double)TimeLocal()-GVGet(uid,"at")<60)
         return;
      double e0=GVGet(uid,"e0",0);
      if(e0<=0)
         GVSet(uid,"e0",(double)TimeLocal());
      else if((double)TimeLocal()-e0>=20)
         GVDeleteSignal(uid);                                     // 'done' tetap ada -> sinyal tidak dimasuki ulang
      return;
     }
   if(GVGet(uid,"e0",0)>0)
      GVSet(uid,"e0",0);
   if(npos>0 && GVGet(uid,"fill",0)<=0)
      GVSet(uid,"fill",1);
   int si=FindSignal(uid);
   bool ended=(si>=0 && IsFinal(g_sig[si].status));
   //--- limit yang belum terisi
   if(npend>0)
     {
      double exp=GVGet(uid,"exp",0);
      if(npos==0 && GVGet(uid,"fill",0)>0 && (double)TimeLocal()-GVGet(uid,"at")>=60)
         DeletePendings(uid,"posisi sinyal sudah selesai");       // jangan buka lagi sesudah posisi ditutup
      else if(exp>0 && NowSrv()>=(long)exp)
         DeletePendings(uid,"kedaluwarsa");
      else if(ended && InpSyncCancel)
         DeletePendings(uid,"sinyal "+g_sig[si].status+" di website");
     }
   if(npos==0)
      return;
   if(ended && InpSyncClose)
     {
      ClosePositions(uid,"sinyal "+g_sig[si].status+" di website");
      DeletePendings(uid,"sinyal selesai");
      return;
     }
   string sym=SymbolOfUid(uid);
   if(sym=="")
      return;
   datetime t0=FirstOpenTime(uid);
   //--- batas waktu tahan (10 METODE: max_hold bar)
   double hold=GVGet(uid,"hold",0);
   if(InpManageTP && hold>0 && t0>0 && (double)(TimeTradeServer()-t0)>=hold)
     {
      ClosePositions(uid,"batas waktu tahan sinyal");
      DeletePendings(uid,"batas waktu tahan sinyal");
      return;
     }
   MqlTick tk;
   if(!SymbolInfoTick(sym,tk))
      return;
   bool buy=(GVGet(uid,"side",1)>0);
   double px=buy ? tk.bid : tk.ask;
   //--- lonjakan di antara dua pemeriksaan: pakai high/low bar M1 berjalan (hanya bila posisi dibuka sebelum bar itu)
   datetime b0=iTime(sym,PERIOD_M1,0);
   if(b0>0 && t0>0 && t0<b0)
     {
      if(buy)
        {
         double h=iHigh(sym,PERIOD_M1,0);
         if(h>px)
            px=h;
        }
      else
        {
         double l=iLow(sym,PERIOD_M1,0);
         if(l>0 && l+(tk.ask-tk.bid)<px)
            px=l+(tk.ask-tk.bid);
        }
     }
   int st=(int)GVGet(uid,"st",0);
   if(InpManageTP)
     {
      string tn[3]={"t1","t2","t3"};
      string cn[3]={"c1","c2","c3"};
      while(st<3)
        {
         double lv=GVGet(uid,tn[st],0);
         if(lv<=0)
            break;
         if(buy ? (px<lv) : (px>lv))
            break;
         if(st==0 && GVGet(uid,"avg",0)<=0)
            GVSet(uid,"avg",AvgOpen(uid));                        // rata-rata entry SEBELUM tutup sebagian (acuan breakeven)
         CloseFraction(uid,sym,GVGet(uid,cn[st],1),"TP"+IntegerToString(st+1));
         st++;
         GVSet(uid,"st",st);
         if(st==1 && GVGet(uid,"cut",0)>0)
            DeletePendings(uid,"TP1 tercapai");
        }
     }
   //--- breakeven: sesudah TP1, atau lebih awal saat untung >= InpBETriggerR x R
   if(!BEEnabled(uid) || GVGet(uid,"beok",0)>0)
      return;
   string why="";
   if(st>=1)
      why="TP1 tercapai";
   else if(InpBETriggerR>0)
     {
      double avg=AvgOpen(uid);
      double dist=MathAbs(avg-GVGet(uid,"sl",0));
      double move=buy ? (px-avg) : (avg-px);
      if(avg>0 && dist>0 && move>=InpBETriggerR*dist)
        {
         why="untung "+DoubleToString(move/dist,2)+"R";
         GVSet(uid,"avg",avg);
        }
     }
   if(why=="")
      return;
   int a=0,b=0;
   CountLive(uid,a,b);
   if(b>0)
      MoveToBreakeven(uid,sym,buy,why);
  }

void ManageAll()
  {
   string uids[];
   int n=TrackedUids(uids);
   for(int i=0;i<n;i++)
      ManageUid(uids[i]);
  }

void ProcessFeed()
  {
   for(int i=0;i<g_nsig;i++)
     {
      if(g_sig[i].status!="PENDING" || Processed(g_sig[i].uid))
         continue;
      Enter(g_sig[i]);
     }
  }

//+------------------------------------------------------------------+
//| panel status di chart                                             |
//+------------------------------------------------------------------+
void ShowStatus()
  {
   int pend=0,act=0;
   for(int i=0;i<g_nsig;i++)
     {
      if(g_sig[i].status=="PENDING")
         pend++;
      else if(g_sig[i].status=="OPEN")
         act++;
     }
   if(TimeLocal()-g_plAt>=5)
      TodayPL();
   string cur=AccountInfoString(ACCOUNT_CURRENCY);
   string risk=DoubleToString(InpRiskPercent,2)+"%";
   if(InpRiskMode==TS_RISK_FIXED_LOT)
      risk=DoubleToString(InpFixedLot,2)+" lot";
   else if(InpRiskMode==TS_RISK_MONEY)
      risk=DoubleToString(InpRiskMoney,2)+" "+cur;
   string be="ikuti sinyal";
   if(InpBEMode==TS_BE_OFF)
      be="mati";
   else if(InpBEMode==TS_BE_ALWAYS)
      be="semua strategi";
   be+=(InpBETriggerR>0) ? " (TP1 / "+DoubleToString(InpBETriggerR,2)+"R)" : " (sesudah TP1)";
   string s="TerminalSignalEA "+TS_VER+"   ["+(g_hedging ? "hedging" : "netting")+"]\n";
   s+="Website : "+((g_url=="") ? g_primary : g_url)+"\n";
   s+="Feed    : "+((g_lastOk>0) ? "OK "+TimeToString(g_lastOk,TIME_SECONDS) : "belum terhubung")+
      "   (website: menunggu entry "+IntegerToString(pend)+", berjalan "+IntegerToString(act)+")\n";
   s+="Risiko  : "+risk+" per sinyal   |   sinyal EA aktif "+IntegerToString(OpenSignalCount())+"/"+IntegerToString(InpMaxOpenSignals)+"\n";
   s+="BE      : "+be+"\n";
   s+="Hari ini: "+DoubleToString(g_todayPL,2)+" "+cur+"\n";
   if(g_lastErr!="")
      s+="Masalah : "+g_lastErr+"\n";
   Comment(s);
  }

//+------------------------------------------------------------------+
//| event                                                             |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(MQLInfoInteger(MQL_TESTER))
     {
      Print("[TS] Strategy Tester tidak bisa memakai WebRequest: EA ini mengeksekusi sinyal LIVE dari website.");
      return INIT_FAILED;
     }
   //--- reset (MT5 mempertahankan variabel global saat input/chart diubah)
   g_primary=BaseUrl(InpServerURL);
   g_backup=BaseUrl(InpBackupURL);
   g_key=Trim(InpAccessKey);
   g_url="";
   g_etag="";
   g_nsig=0;
   ArrayResize(g_sig,0);
   ArrayResize(g_mapFrom,0);
   ArrayResize(g_mapTo,0);
   ArrayResize(g_warned,0);
   g_lastPoll=0;
   g_lastOk=0;
   g_lastErr="";
   g_plAt=0;
   if(g_primary=="")
     {
      Alert("TerminalSignalEA: isi InpServerURL dengan alamat website, mis. https://xxxx.trycloudflare.com");
      return INIT_PARAMETERS_INCORRECT;
     }
   if(g_key=="")
     {
      Alert("TerminalSignalEA: isi InpAccessKey dengan kunci USER dari admin website");
      return INIT_PARAMETERS_INCORRECT;
     }
   if((InpRiskMode==TS_RISK_PCT_BALANCE || InpRiskMode==TS_RISK_PCT_EQUITY) && InpRiskPercent<=0)
      return INIT_PARAMETERS_INCORRECT;
   if(InpRiskMode==TS_RISK_MONEY && InpRiskMoney<=0)
      return INIT_PARAMETERS_INCORRECT;
   if(InpRiskMode==TS_RISK_FIXED_LOT && InpFixedLot<=0)
      return INIT_PARAMETERS_INCORRECT;
   if(InpBETriggerR<0 || InpBEOffsetPoints<0)
      return INIT_PARAMETERS_INCORRECT;
   //--- satu EA per akun+magic (dua chart = order ganda)
   string kc=GVPrefix()+"chart";
   string kh=GVPrefix()+"hb";
   if(GlobalVariableCheck(kc) && GlobalVariableGet(kc)!=(double)ChartID() && GlobalVariableCheck(kh) &&
      (double)TimeLocal()-GlobalVariableGet(kh)<15)
     {
      Alert("TerminalSignalEA sudah berjalan di chart lain (magic sama). Cukup SATU chart untuk semua pair.");
      return INIT_FAILED;
     }
   GlobalVariableSet(kc,(double)ChartID());
   GlobalVariableSet(kh,(double)TimeLocal());
   g_hedging=(AccountInfoInteger(ACCOUNT_MARGIN_MODE)==ACCOUNT_MARGIN_MODE_RETAIL_HEDGING);
   g_trade.SetExpertMagicNumber((ulong)InpMagic);
   g_trade.SetDeviationInPoints((ulong)InpSlippagePoints);
   g_trade.SetAsyncMode(false);
   MathSrand((uint)GetTickCount()^(uint)AccountInfoInteger(ACCOUNT_LOGIN));
   g_jitter=MathRand()%4;                                         // sebar waktu baca ratusan EA
   DayRoll();
   EventSetTimer(1);
   Print("[TS] TerminalSignalEA ",TS_VER," mulai | website ",g_primary,(g_backup!="" ? " (cadangan "+g_backup+")" : ""),
         " | akun ",(g_hedging ? "hedging" : "netting"));
   ShowStatus();
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   if(reason!=REASON_PARAMETERS && reason!=REASON_CHARTCHANGE && reason!=REASON_RECOMPILE)
      GlobalVariableDel(GVPrefix()+"hb");
   Comment("");
  }

void OnTimer()
  {
   GlobalVariableSet(GVPrefix()+"chart",(double)ChartID());
   GlobalVariableSet(GVPrefix()+"hb",(double)TimeLocal());
   DayRoll();
   ManageAll();
   int every=(int)MathMax(5,InpPollSec)+g_jitter;
   if(g_lastPoll==0 || TimeLocal()-g_lastPoll>=every)
     {
      g_lastPoll=TimeLocal();
      Poll();
      ProcessFeed();
     }
   ShowStatus();
  }

void OnTick()
  {
   // pengelolaan utama di OnTimer (semua pair); tick chart ini hanya mempercepat reaksi
   static uint last=0;
   uint t=GetTickCount();
   if(t-last<250)
      return;
   last=t;
   ManageAll();
  }
//+------------------------------------------------------------------+
