"""Pencatat kesehatan sumber data.

Setiap pemanggilan jaringan dan setiap fungsi ber-cache melapor ke sini, sehingga
"kenapa data kosong?" bisa dijawab dari /api/health, /status di bot, atau selfcheck.

Agar lencana "N sumber bermasalah" bermakna, kegagalan dibedakan menjadi:
  - bad       : sumber utama gagal dan tidak ada cadangan yang menutupinya  -> dihitung di lencana
  - covered   : gagal, tetapi data yang sama berhasil didapat dari sumber cadangan -> tidak dihitung
  - optional  : sumber redundan (mis. salah satu dari puluhan feed berita)           -> tidak dihitung
  - disabled  : URL mati permanen (404/410/403 berulang) dinonaktifkan sementara      -> tidak dihitung
"""
import time

_hosts = {}
_funcs = {}
_optional = set()
_disabled = {}  # url_key -> dict(until, reason)


def _short(exc):
    return f"{type(exc).__name__}: {str(exc)[:160]}"


def _h(host):
    return _hosts.setdefault(host, dict(ok=0, fail=0, last_ok=0, last_fail=0, error=None, last_url=None, covered_by=None, via=None))


def mark_optional(host):
    _optional.add(host)


def host_ok(host, via=None):
    s = _h(host)
    s["ok"] += 1
    s["last_ok"] = time.time()
    s["error"] = None
    s["covered_by"] = None
    if via:
        s["via"] = via


def host_fail(host, exc, url=None):
    s = _h(host)
    s["fail"] += 1
    s["last_fail"] = time.time()
    s["error"] = _short(exc)
    s["last_url"] = (url or "")[:200] or s["last_url"]
    s["covered_by"] = None


def cover(host, by):
    """Tandai bahwa kegagalan `host` sudah ditutup oleh sumber cadangan `by` (data tetap tersedia)."""
    s = _hosts.get(host)
    if s and s["error"]:
        s["covered_by"] = by


def disable(url_key, reason, seconds):
    _disabled[url_key] = dict(until=time.time() + seconds, reason=reason)


def is_disabled(url_key):
    d = _disabled.get(url_key)
    if not d:
        return False
    if d["until"] < time.time():
        _disabled.pop(url_key, None)
        return False
    return True


def func_ok(name):
    s = _funcs.setdefault(name, dict(ok=0, fail=0, last_ok=0, last_fail=0, error=None))
    s["ok"] += 1
    s["last_ok"] = time.time()
    s["error"] = None


def func_fail(name, exc):
    s = _funcs.setdefault(name, dict(ok=0, fail=0, last_ok=0, last_fail=0, error=None))
    s["fail"] += 1
    s["last_fail"] = time.time()
    s["error"] = _short(exc)


def _level(host, v):
    if not v["error"]:
        return "ok"
    if host in _optional:
        return "optional"
    if v["covered_by"]:
        return "covered"
    return "bad"


def snapshot():
    hosts = []
    for h, v in _hosts.items():
        hosts.append(dict(host=h, level=_level(h, v), optional=h in _optional, **v))
    order = {"bad": 0, "covered": 1, "optional": 2, "ok": 3}
    hosts.sort(key=lambda x: (order[x["level"]], x["host"]))
    funcs = [dict(name=n, **v) for n, v in _funcs.items()]
    funcs.sort(key=lambda x: (x["error"] is None, x["name"]))
    bad_hosts = [h for h in hosts if h["level"] == "bad"]
    disabled = [dict(url=k, reason=v["reason"], until=v["until"]) for k, v in _disabled.items() if v["until"] > time.time()]
    return dict(
        hosts=hosts, funcs=funcs, bad=len(bad_hosts),
        covered=sum(1 for h in hosts if h["level"] == "covered"),
        optional_bad=sum(1 for h in hosts if h["level"] == "optional"),
        disabled=disabled,
        bad_hosts=[f"{h['host']} ({h['error']})" for h in bad_hosts][:12],
    )


def reset():
    _hosts.clear()
    _funcs.clear()
    _disabled.clear()
