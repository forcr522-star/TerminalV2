"""Saringan informasi diagnostik untuk peran USER (pengunjung biasa).

Admin melihat semuanya. User TIDAK boleh melihat informasi internal server:
  - teks error / jenis exception / URL sumber yang gagal,
  - daftar endpoint/menu yang gagal diperbarui (popup DATA TERSIMPAN DI SERVER),
  - status per sumber data (sumber mana yang hidup / mati, channel/akun feed yang dipakai),
  - lokasi database dan konfigurasi feed.
Data pasar, hasil analisa, berita, dan log bot tetap tampil apa adanya.

Penyaringan dilakukan di server (bukan hanya disembunyikan di tampilan) agar tidak bisa dibaca lewat /api langsung.
Respons yang tersimpan (snapshot) dipakai bersama semua pengunjung -> hasil saringan di-cache per isi snapshot,
jadi tiap versi data hanya diurai sekali.
"""
import collections
import json
import re

from . import snapshots as S

GENERIC = "Data sementara tidak tersedia. Server mencoba ulang otomatis."
SHORT = "tidak tersedia"
# kunci yang dibuang seluruhnya untuk user
DROP = frozenset({"errors", "last_url", "via", "db", "accounts_cfg", "rss", "llm_status", "public_url", "local_url", "health",
                  "watchdog", "failed_hosts", "disabled"})
# pola byte yang menandakan respons mungkin berisi info diagnostik (cek cepat sebelum mengurai JSON)
_TRIGGERS = (b'"error', b'_error"', b'"errors"', b'"last_url"', b'"via"', b'"db"', b'"accounts_cfg"', b'"sources":{', b'"health"', b'"public_url"')
_BIG = 256 * 1024
_cache = collections.OrderedDict()          # (path, query) -> (body asli, body tersaring)
_CACHE_MAX = 192


def _is_err_key(k):
    return k == "error" or k.endswith("_error")


# Pesan teknis = bocoran internal (nama exception, URL/host sumber, kode HTTP, timeout, path berkas). Pesan penjelasan biasa
# untuk pengguna (mis. "pair ini tidak dipantau") tetap ditampilkan.
_TECH = re.compile(r"\b[A-Z][A-Za-z]*(?:Error|Exception|Timeout|Exit)\b|https?://|\bHTTP\s?\d{3}\b|\b\d{3} (?:Client|Server) Error|"
                   r"\b[a-z][\w-]*\.[a-z][\w.-]*\b|time ?out|traceback|errno|[A-Za-z]:\\|\.py\b|\.db\b|\bsqlite", re.I)


_EXC_PREFIX = re.compile(r"^\s*[A-Za-z_.]*(?:Error|Exception|Warning)\s*:\s*")


def technical(msg):
    return isinstance(msg, str) and bool(_TECH.search(msg))


def clean(msg, fallback):
    """Pesan error untuk user: awalan nama exception dibuang; bila isinya teknis -> teks umum."""
    if not isinstance(msg, str):
        return msg
    m = _EXC_PREFIX.sub("", msg).strip()
    return fallback if not m or technical(m) else m


def scrub(o):
    """Salinan objek tanpa info diagnostik. Kunci error* bernilai -> diganti teks umum; status per sumber (dict) dibuang."""
    if isinstance(o, dict):
        out = {}
        for k, v in o.items():
            if k in DROP:
                continue
            if _is_err_key(k):
                out[k] = (clean(v, SHORT) if v else v) if not isinstance(v, (dict, list)) else None
                continue
            if k == "sources" and isinstance(v, dict):          # peta status per sumber -> rahasia admin
                continue
            out[k] = scrub(v)
        return out
    if isinstance(o, list):
        return [scrub(v) for v in o]
    return o


def _snapshots_view(d):
    """Popup DATA TERSIMPAN: user hanya melihat ringkasan per menu, tanpa daftar endpoint gagal & pesan error."""
    keep = ("stored", "planned", "ready", "bytes", "updated", "oldest", "groups", "failing", "inflight")
    out = {k: d.get(k) for k in keep if k in d}
    pl = d.get("preload") or {}
    out["preload"] = {k: pl.get(k) for k in ("phase", "done", "total", "started", "finished")}
    return out


def _view(path, body):
    try:
        d = json.loads(body)
    except Exception:
        return body
    if isinstance(d, dict) and d.get("error") and isinstance(d["error"], str):
        msg = clean(d["error"], GENERIC)
        if msg == GENERIC:
            return S.encode({"error": GENERIC})
        d["error"] = msg
    if path == "snapshots" and isinstance(d, dict):
        d = _snapshots_view(d)
    elif path == "squawk" and isinstance(d, dict):                 # status feed (akun/channel/sumber) = info admin
        d = {k: v for k, v in d.items() if k not in ("x", "social", "sources")}
    return S.encode(scrub(d))


def needs(path, body):
    return path in ("snapshots", "squawk") or any(t in body for t in _TRIGGERS)


async def for_user(path, query, body):
    """Body JSON versi user. Cepat bila tidak ada pola diagnostik; snapshot besar diurai di thread parse."""
    if not needs(path, body):
        return body
    key = (path, query)
    hit = _cache.get(key)
    if hit is not None and hit[0] is body:
        _cache.move_to_end(key)
        return hit[1]
    if len(body) > _BIG:
        from . import cpu
        out = await cpu.parse(_view, path, body)
    else:
        out = _view(path, body)
    _cache[key] = (body, out)
    _cache.move_to_end(key)
    while len(_cache) > _CACHE_MAX:
        _cache.popitem(last=False)
    return out
