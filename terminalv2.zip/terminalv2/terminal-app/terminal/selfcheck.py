"""Cek semua sumber data dari komputer ini:   python -m terminal.selfcheck

Mencetak [OK] / [GAGAL] per sumber (dan per adapter yield), lengkap dengan contoh nilai atau pesan error.
Hasilnya menunjukkan sumber mana yang diblokir/berubah format di jaringan Anda, tanpa perlu membuka bot.
"""
import asyncio
import os
import sys
import tempfile
import time


def _prep():
    # DB sementara agar cache permanen tidak menutupi kegagalan sumber.
    os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "selfcheck.db")


async def _run(name, coro, fmt):
    t = time.time()
    try:
        res = await asyncio.wait_for(coro, 40)
        return True, name, f"{fmt(res)}  ({time.time() - t:.1f}s)"
    except Exception as exc:
        return False, name, f"{type(exc).__name__}: {str(exc)[:140]}  ({time.time() - t:.1f}s)"


async def main():
    from terminal import http as H, llm, config
    from terminal.providers import fred, annual, worldbank, yields, rates, cftc, calendar, gpr, geo, portwatch, news, yahoo, auctions
    import datetime as dt

    def last(rows):
        return f"{len(rows)} titik, terakhir {rows[-1][0]} = {rows[-1][1]}"

    def tenors(d):
        return ", ".join(f"{t}:{rows[-1][1]}" for t, rows in sorted(d.items(), key=lambda x: yields.TENORS.index(x[0]))[:8])

    checks = [
        ("FRED  (DGS10)", fred.series("DGS10", start=str(dt.date.today().year - 1) + "-01-01"), last),
        ("BIS   (suku bunga kebijakan)", rates.policy_all(), lambda d: f"{len(d)} negara: " + ", ".join(f"{k}={v[-1][1]}" for k, v in list(d.items())[:5])),
        ("IMF DataMapper (NGDP_RPCH)", annual._imf_fetch("NGDP_RPCH", ("USA", "IDN", "EURO")), lambda d: ", ".join(f"{k}:{v[-1]}" for k, v in d.items())),
        ("World Bank (GDP growth)", worldbank.indicator("NY.GDP.MKTP.KD.ZG", ("USA", "IDN", "EMU")), lambda d: ", ".join(f"{k}:{v[-1]}" for k, v in d.items())),
        ("CFTC  (COT Euro FX)", cftc.instrument("tff", "Euro FX", 4), lambda d: f"{len(d['rows'])} baris, {d['rows'][0]['date']}"),
        ("TradingView calendar", calendar.tv_calendar(), lambda d: f"{len(d)} event"),
        ("Forex Factory calendar", calendar.ff_calendar(), lambda d: f"{len(d)} event"),
        ("AI-GPR (Iacoviello)", gpr.daily(), lambda d: f"GPR {d['latest']:.0f} ({d['asof']})"),
        ("GDELT GEO", geo.gdelt_hotspots(), lambda d: f"{len(d)} titik panas"),
        ("IMF PortWatch", portwatch.summary(), lambda d: f"{len(d)} choke point/pelabuhan"),
        ("Yahoo Finance (^GSPC, EURUSD=X)", yahoo.quotes(("^GSPC", "EURUSD=X")), lambda d: ", ".join(f"{k}={v['price']}" for k, v in d.items())),
        ("Google News RSS", news.fetch_feed_url(news.gn("Federal Reserve"), "Google", [], 3), lambda d: f"{len(d)} headline"),
        ("Bank of England IADB (gilt 5/10/20Y)", yields.ad_boe_gb("GB"), tenors),
        ("MOF Jepang (JGB, URL kandidat)", yields.ad_mof_jp("JP"), tenors),
        ("ECB Data Portal (neraca Eurosystem)", rates._bs_ecb(), lambda r: f"{len(r[0])} titik, terakhir {r[0][-1][0]} = {r[0][-1][1] / 1e12:.2f} T {r[1]}"),
        ("BIS WS_TC (utang pemerintah % PDB, cadangan IMF)", annual._bis_debt(("CHN", "IDN")), lambda d: ", ".join(f"{k}:{v[-1]}" for k, v in d.items())),
        ("Lelang AS (FiscalData -> TreasuryDirect)", auctions._us(), lambda r: f"{len([x for x in r[0] if x['status'] == 'upcoming'])} mendatang, {len([x for x in r[0] if x['status'] == 'done'])} riwayat, sumber {r[1]}"),
        ("Lelang negara lain (TradingView)", auctions._tv_all(), lambda d: ", ".join(f"{k}:{len(v)}" for k, v in sorted(d.items())) or "tidak ada lelang di kalender"),
    ]
    results = []
    res = await asyncio.gather(*[_run(n, c, f) for n, c, f in checks])
    results += res
    print("\n== Sumber umum ==")
    for ok, n, m in results:
        print(f"[{'OK' if ok else 'GAGAL':5}] {n:34} {m}")

    print("\n== Yield obligasi: tiap adapter per negara (urutan prioritas) ==")
    for cc, chain in yields.CHAIN.items():
        for name, fn in chain:
            ok, n, m = await _run(f"{cc} / {name}", fn(cc), tenors)
            print(f"[{'OK' if ok else 'GAGAL':5}] {n:44} {m}")
        got = await yields.collect(cc)
        print(f"        => {cc}: tenor tersedia {[c['tenor'] for c in got['curve']]}  (sumber: {got['src']})")

    print("\n== AI lokal (Ollama) ==")
    await llm.probe(force=True)
    st = llm.status()
    print(f"[{'OK' if st['available'] else 'GAGAL':5}] Ollama {config.OLLAMA_HOST}  model={st['model']}  terpasang={st['installed']}  {st['error'] or ''}")

    from terminal import health
    try:
        import curl_cffi  # noqa: F401
        tls = "terpasang (cadangan TLS-Chrome aktif untuk situs yang menolak klien biasa: IMF, RBA, FRED, dll.)"
    except Exception:
        tls = "TIDAK terpasang -> `pip install curl_cffi` agar IMF/RBA/FRED yang memblokir sidik jari TLS bisa dijangkau"
    print(f"\ncurl_cffi: {tls}")
    snap = health.snapshot()
    for h in snap["hosts"]:
        if h["level"] in ("ok", "covered") and h.get("via"):
            print(f"        host {h['host']} lolos via {h['via']}")

    bad = [r for r in results if not r[0]]
    print(f"\nRingkasan sumber umum: {len(results) - len(bad)} OK, {len(bad)} gagal. Kirim keluaran ini bila ada yang gagal agar bisa disesuaikan.")
    await H.close()


if __name__ == "__main__":
    _prep()
    if sys.platform.startswith("win"):
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())
