COUNTRIES = {
    "US": dict(name="United States", label="UNITED STATES", flag="us", cb="Federal Reserve", cb_short="FED", currency="USD", imf="USA", bis="US", m49=842, stooq="us", iso3="USA", wgb="united-states", fred_cb="FEDFUNDS", index="^GSPC", tz="America/New_York"),
    "CN": dict(name="China", label="CHINA", flag="cn", cb="People's Bank of China", cb_short="PBOC", currency="CNY", imf="CHN", bis="CN", m49=156, stooq="cn", iso3="CHN", wgb="china", index="000300.SS", tz="Asia/Shanghai"),
    "EU": dict(name="Euro Zone", label="EURO ZONE", flag="eu", cb="European Central Bank", cb_short="ECB", currency="EUR", imf="EURO", bis="XM", m49=97, stooq="de", iso3="EUR", wgb="germany", index="^STOXX50E", tz="Europe/Berlin"),
    "JP": dict(name="Japan", label="JAPAN", flag="jp", cb="Bank of Japan", cb_short="BOJ", currency="JPY", imf="JPN", bis="JP", m49=392, stooq="jp", iso3="JPN", wgb="japan", index="^N225", tz="Asia/Tokyo"),
    "GB": dict(name="United Kingdom", label="UNITED KINGDOM", flag="gb", cb="Bank of England", cb_short="BOE", currency="GBP", imf="GBR", bis="GB", m49=826, stooq="uk", iso3="GBR", wgb="united-kingdom", index="^FTSE", tz="Europe/London"),
    "CA": dict(name="Canada", label="CANADA", flag="ca", cb="Bank of Canada", cb_short="BOC", currency="CAD", imf="CAN", bis="CA", m49=124, stooq="ca", iso3="CAN", wgb="canada", index="^GSPTSE", tz="America/Toronto"),
    "AU": dict(name="Australia", label="AUSTRALIA", flag="au", cb="Reserve Bank of Australia", cb_short="RBA", currency="AUD", imf="AUS", bis="AU", m49=36, stooq="au", iso3="AUS", wgb="australia", index="^AXJO", tz="Australia/Sydney"),
    "NZ": dict(name="New Zealand", label="NEW ZEALAND", flag="nz", cb="Reserve Bank of New Zealand", cb_short="RBNZ", currency="NZD", imf="NZL", bis="NZ", m49=554, stooq="nz", iso3="NZL", wgb="new-zealand", index="^NZ50", tz="Pacific/Auckland"),
    "CH": dict(name="Switzerland", label="SWITZERLAND", flag="ch", cb="Swiss National Bank", cb_short="SNB", currency="CHF", imf="CHE", bis="CH", m49=756, stooq="ch", iso3="CHE", wgb="switzerland", index="^SSMI", tz="Europe/Zurich"),
    "ID": dict(name="Indonesia", label="INDONESIA", flag="id", cb="Bank Indonesia", cb_short="BI", currency="IDR", imf="IDN", bis="ID", m49=360, stooq="id", iso3="IDN", wgb="indonesia", index="^JKSE", tz="Asia/Jakarta"),
}
COUNTRY_ORDER = ["US", "CN", "EU", "JP", "GB", "CA", "AU", "ID", "CH", "NZ"]
CURRENCY_TO_CC = {v["currency"]: k for k, v in COUNTRIES.items()}
CB_FEEDS = {
    "US": "https://www.federalreserve.gov/feeds/press_monetary.xml",
    "EU": "https://www.ecb.europa.eu/rss/press.html",
    "GB": "https://www.bankofengland.co.uk/rss/news",
    "AU": "https://www.rba.gov.au/rss/rss-cb-media-releases.xml",
    "CA": "https://www.bankofcanada.ca/content_type/press-releases/feed/",
}
CB_NEWS_QUERY = {
    "US": "Federal Reserve FOMC", "CN": "People's Bank of China PBOC", "EU": "European Central Bank ECB",
    "JP": "Bank of Japan BOJ", "GB": "Bank of England", "CA": "Bank of Canada", "AU": "Reserve Bank of Australia RBA",
    "NZ": "Reserve Bank of New Zealand RBNZ", "CH": "Swiss National Bank SNB", "ID": "Bank Indonesia suku bunga",
}
RATINGS = {"US": "AA+", "GB": "AA", "JP": "A+", "EU": "AAA", "CN": "A+", "CA": "AAA", "NZ": "AA+", "ID": "BBB", "AU": "AAA", "CH": "AAA"}

INDICES = [
    ("US500", "^GSPC", "S&P 500"), ("US100", "^NDX", "Nasdaq 100"), ("US30", "^DJI", "Dow Jones"), ("US2000", "^RUT", "Russell 2000"),
    ("IXIC", "^IXIC", "Nasdaq Composite"), ("DAX30", "^GDAXI", "DAX 40"), ("FTSE100", "^FTSE", "FTSE 100"), ("CAC40", "^FCHI", "CAC 40"),
    ("EU50", "^STOXX50E", "Euro Stoxx 50"), ("CH20", "^SSMI", "SMI"), ("AEX", "^AEX", "AEX"), ("IBEX35", "^IBEX", "IBEX 35"),
    ("Nikkei225", "^N225", "Nikkei 225"), ("HK50", "^HSI", "Hang Seng"), ("CSI1000", "000852.SS", "CSI 1000"), ("SSEC", "000001.SS", "Shanghai Composite"),
    ("CSI300", "000300.SS", "CSI 300"), ("KOSPI", "^KS11", "KOSPI"), ("TWII", "^TWII", "Taiwan Weighted"), ("SENSEX", "^BSESN", "BSE Sensex"),
    ("NIFTY50", "^NSEI", "Nifty 50"), ("ASX200", "^AXJO", "ASX 200"), ("NZ50", "^NZ50", "NZX 50"), ("TSX", "^GSPTSE", "TSX Composite"),
    ("IDX Composite", "^JKSE", "IDX Composite"), ("IDX LQ45", "^JKLQ45", "IDX LQ45"), ("BOVESPA", "^BVSP", "Bovespa"), ("STI", "^STI", "Straits Times"),
]
_FX_PAIRS = [
    "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "USDCAD", "AUDUSD", "NZDUSD", "EURGBP", "EURJPY", "EURCHF", "EURCAD", "EURAUD", "EURNZD",
    "GBPJPY", "GBPCHF", "GBPCAD", "GBPAUD", "GBPNZD", "AUDJPY", "AUDCAD", "AUDCHF", "AUDNZD", "CADJPY", "CADCHF", "CHFJPY", "NZDJPY", "NZDCAD", "NZDCHF",
    "USDIDR", "USDCNY", "USDSGD", "USDMXN", "USDZAR", "USDTRY", "USDINR",
]
FX = [("USD Index", "DX-Y.NYB", "US Dollar Index")] + [(p, f"{p}=X", f"{p[:3]}/{p[3:]}") for p in _FX_PAIRS]
FX_CORE = _FX_PAIRS[:28]
COMMODITIES = [
    ("Gold", "GC=F", "Gold"), ("Silver", "SI=F", "Silver"), ("Copper", "HG=F", "Copper"), ("Platinum", "PL=F", "Platinum"), ("Palladium", "PA=F", "Palladium"),
    ("Crude Oil WTI", "CL=F", "Crude Oil WTI"), ("Brent Oil", "BZ=F", "Brent Oil"), ("Natural Gas", "NG=F", "Natural Gas"), ("Gasoline", "RB=F", "Gasoline RBOB"),
    ("Heating Oil", "HO=F", "Heating Oil"), ("Corn", "ZC=F", "Corn"), ("Wheat", "ZW=F", "Wheat"), ("Soybeans", "ZS=F", "Soybeans"), ("Coffee", "KC=F", "Coffee"),
    ("Cocoa", "CC=F", "Cocoa"), ("Cotton", "CT=F", "Cotton"), ("Sugar", "SB=F", "Sugar"), ("Aluminum", "ALI=F", "Aluminum"),
]
CRYPTO = [
    ("Bitcoin", "BTC-USD", "Bitcoin"), ("Ethereum", "ETH-USD", "Ethereum"), ("Ripple", "XRP-USD", "XRP"), ("Solana", "SOL-USD", "Solana"),
    ("Binance Coin", "BNB-USD", "BNB"), ("Dogecoin", "DOGE-USD", "Dogecoin"), ("Cardano", "ADA-USD", "Cardano"), ("Avalanche", "AVAX-USD", "Avalanche"),
    ("Chainlink", "LINK-USD", "Chainlink"), ("Tron", "TRX-USD", "Tron"),
]
BONDS_US = [("US 13W", "^IRX", "US 13-Week Bill"), ("US 5Y", "^FVX", "US 5-Year Yield"), ("US 10Y", "^TNX", "US 10-Year Yield"), ("US 30Y", "^TYX", "US 30-Year Yield")]
ASSET_CLASSES = {"INDEX": INDICES, "FX": FX, "COMMODITY": COMMODITIES, "CRYPTO": CRYPTO, "BOND": BONDS_US}
ALL_ASSETS = [dict(sym=s, y=y, name=n, cls=c) for c, rows in ASSET_CLASSES.items() for s, y, n in rows]
BY_SYM = {a["sym"].upper(): a for a in ALL_ASSETS}
BY_Y = {a["y"].upper(): a for a in ALL_ASSETS}

DASH_INDICES = ["ASX200", "CH20", "CSI1000", "DAX30", "FTSE100", "HK50", "IDX Composite", "IDX LQ45", "NZ50", "Nikkei225", "TSX", "US100", "US2000", "US30", "US500"]
DASH_COMMODITIES = ["Brent Oil", "Cocoa", "Coffee", "Copper", "Crude Oil WTI", "Gold", "Silver", "Natural Gas", "Corn", "Wheat"]
HEATMAP_GROUPS = {
    "INDICES": ["US100", "US500", "US30", "US2000", "DAX30", "FTSE100", "CAC40", "CH20", "Nikkei225", "HK50", "CSI1000", "ASX200", "NZ50", "TSX", "IDX Composite", "KOSPI", "SENSEX"],
    "COMMODITIES": ["Gold", "Silver", "Copper", "Crude Oil WTI", "Brent Oil", "Natural Gas", "Corn", "Soybeans", "Coffee", "Cocoa"],
    "CRYPTO": ["Bitcoin", "Ethereum", "Ripple", "Solana", "Binance Coin", "Dogecoin"],
    "CURRENCIES": ["EURUSD", "GBPUSD", "USDJPY", "USDCHF", "USDCAD", "AUDUSD", "NZDUSD", "USDIDR"],
}

SECTOR_ETFS = [
    ("IXN", "Information Technology"), ("KXI", "Consumer Staples"), ("EXI", "Industrials"), ("MXI", "Materials"), ("IXJ", "Health Care"),
    ("IXC", "Energy"), ("IXG", "Financials"), ("IXP", "Communication Services"), ("JXI", "Utilities"), ("RXI", "Consumer Discretionary"), ("REET", "Real Estate"),
]

FUTURES_ROOTS = {
    "COMMODITIES": [("CL", "NYM", "Crude Oil WTI"), ("BZ", "NYM", "Brent Oil"), ("GC", "CMX", "Gold"), ("SI", "CMX", "Silver"), ("HG", "CMX", "Copper"),
                    ("NG", "NYM", "Natural Gas"), ("KC", "NYB", "Coffee"), ("CC", "NYB", "Cocoa"), ("CT", "NYB", "Cotton"), ("ZC", "CBT", "Corn"),
                    ("ZS", "CBT", "Soybeans"), ("ZW", "CBT", "Wheat"), ("SB", "NYB", "Sugar"), ("ALI", "CMX", "Aluminum")],
    "INDICES": [("ES", "CME", "E-mini S&P 500"), ("NQ", "CME", "E-mini Nasdaq 100"), ("YM", "CBT", "E-mini Dow"), ("RTY", "CME", "E-mini Russell 2000")],
    "CURRENCIES": [("6E", "CME", "Euro FX"), ("6J", "CME", "Japanese Yen"), ("6B", "CME", "British Pound"), ("6A", "CME", "Australian Dollar"),
                   ("6C", "CME", "Canadian Dollar"), ("6S", "CME", "Swiss Franc"), ("6N", "CME", "NZ Dollar")],
    "RATES": [("ZN", "CBT", "10-Year T-Note"), ("ZB", "CBT", "30-Year T-Bond"), ("ZF", "CBT", "5-Year T-Note"), ("ZT", "CBT", "2-Year T-Note")],
}
MONTH_CODES = "FGHJKMNQUVXZ"
MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

COT_TFF = {
    "US Dollar Index": ("098662", "USD INDEX", "currency"), "Euro FX": ("099741", "EURO FX", "currency"), "Japanese Yen": ("097741", "JAPANESE YEN", "currency"),
    "British Pound": ("096742", "BRITISH POUND", "currency"), "Canadian Dollar": ("090741", "CANADIAN DOLLAR", "currency"),
    "Australian Dollar": ("232741", "AUSTRALIAN DOLLAR", "currency"), "New Zealand Dollar": ("112741", "NZ DOLLAR", "currency"),
    "Swiss Franc": ("092741", "SWISS FRANC", "currency"), "Dow Jones": ("124603", "DJIA", "index"), "S&P 500": ("13874A", "E-MINI S&P 500", "index"),
    "Nasdaq 100": ("209742", "NASDAQ MINI", "index"), "10Y Treasury": ("043602", "UST 10Y NOTE", "rate"), "Fed Funds": ("045601", "FED FUNDS", "rate"),
    "Bitcoin": ("133741", "BITCOIN", "crypto"), "Ether": ("146021", "ETHER", "crypto"), "XRP": ("", "XRP", "crypto"),
}
COT_DISAGG = {
    "Gold": ("088691", "GOLD", "commodity"), "Silver": ("084691", "SILVER", "commodity"), "Copper": ("085692", "COPPER", "commodity"),
    "Crude Oil (WTI)": ("067651", "CRUDE OIL, LIGHT SWEET", "commodity"), "Natural Gas": ("023651", "NATURAL GAS", "commodity"),
    "Corn": ("002602", "CORN", "commodity"), "Wheat": ("001602", "WHEAT-SRW", "commodity"), "Soybeans": ("005602", "SOYBEANS", "commodity"),
    "Coffee": ("083731", "COFFEE C", "commodity"), "Cocoa": ("073732", "COCOA", "commodity"), "Cotton": ("033661", "COTTON NO. 2", "commodity"),
    "Platinum": ("076651", "PLATINUM", "commodity"), "Palladium": ("075651", "PALLADIUM", "commodity"), "Sugar": ("080732", "SUGAR NO. 11", "commodity"),
    "Aluminum": ("191693", "ALUMINUM", "commodity"),
}
COT_ASSET_CLASSES = {
    "Currencies": ["US Dollar Index", "Euro FX", "Japanese Yen", "British Pound", "Canadian Dollar", "Australian Dollar", "New Zealand Dollar", "Swiss Franc"],
    "Indices": ["Dow Jones", "S&P 500", "Nasdaq 100"],
    "Rates": ["10Y Treasury", "Fed Funds"],
    "Crypto": ["Bitcoin", "Ether", "XRP"],
    "Commodities": ["Gold", "Silver", "Copper", "Crude Oil (WTI)", "Natural Gas", "Corn", "Wheat", "Soybeans", "Coffee", "Cocoa", "Cotton", "Platinum", "Palladium", "Sugar", "Aluminum"],
}

RETAIL_SYMBOLS = ["AUDCAD", "AUDCHF", "AUDJPY", "AUDNZD", "AUDUSD", "CADCHF", "CADJPY", "CHFJPY", "EURAUD", "EURCAD", "EURCHF", "EURGBP", "EURJPY", "EURNZD", "EURUSD",
                  "GBPAUD", "GBPCAD", "GBPCHF", "GBPJPY", "GBPNZD", "GBPUSD", "NZDCAD", "NZDCHF", "NZDJPY", "NZDUSD", "USDCAD", "USDCHF", "USDJPY", "XAUUSD", "XAGUSD", "USOIL", "BTCUSD", "ETHUSD"]

CHOKEPOINTS = [
    dict(id="hormuz", name="Strait of Hormuz", lat=26.57, lon=56.25, pw=["hormuz"], kw=["hormuz", "persian gulf", "iran", "tanker seized", "gulf of oman"], note="Crude Oil & Energy Flows"),
    dict(id="redsea", name="Red Sea / Suez", lat=20.0, lon=39.0, pw=["mandeb", "suez"], kw=["red sea", "suez", "houthi", "bab el-mandeb", "bab al-mandab"], note="Global Container Trade"),
    dict(id="blacksea", name="Black Sea", lat=43.5, lon=34.0, pw=["bosporus", "bosphorus", "kerch"], kw=["black sea", "odesa", "odessa", "crimea", "novorossiysk"], note="Grain & Energy Exports"),
    dict(id="malacca", name="Strait of Malacca", lat=2.5, lon=101.5, pw=["malacca"], kw=["malacca", "singapore strait"], note="Asia-Europe Shipping"),
    dict(id="panama", name="Panama Canal", lat=9.1, lon=-79.7, pw=["panama"], kw=["panama canal"], note="Americas Container Routes"),
    dict(id="taiwan", name="Taiwan Strait", lat=24.5, lon=119.5, pw=["taiwan"], kw=["taiwan strait", "taiwan"], note="Semiconductor Supply Chain"),
    dict(id="bosphorus", name="Bosphorus", lat=41.1, lon=29.05, pw=["bosporus", "bosphorus", "dardanelles"], kw=["bosphorus", "bosporus", "dardanelles"], note="Black Sea Access"),
    dict(id="danish", name="Danish Straits", lat=55.7, lon=12.6, pw=["oresund", "oeresund", "great belt", "danish"], kw=["baltic sea", "danish straits", "gulf of finland"], note="Baltic Energy Flows"),
]
