"""Klien AI lokal via Ollama (tanpa API key, tanpa langganan).

Alur:
- probe() memeriksa server Ollama dan model yang terpasang.
- ensure_server()/ensure_model() menyalakan `ollama serve` dan mengunduh model bila belum ada.
- complete() membuat teks. Satu permintaan pada satu waktu (model kecil di CPU).
- Narasi dibuat di latar belakang (narrative_job) dan disimpan di SQLite; endpoint web hanya membaca hasilnya,
  jadi halaman tidak pernah menunggu model.
"""
import asyncio
import hashlib
import os
import json
import shutil
import subprocess
import sys
import time
import httpx
from . import config, store, health

_state = dict(ok=False, models=[], error=None, checked=0, pulling=False, pull_status="", spawned=False)
_sem = None

# AI lokal bersifat OPSIONAL: tanpa Ollama seluruh aplikasi tetap berjalan (narasi rule-based, pengalaman rule-based).
# Karena itu kegagalan Ollama tidak boleh muncul sebagai "sumber data bermasalah" di lencana admin.
health.mark_optional("ollama")


def _lock():
    global _sem
    if _sem is None:
        _sem = asyncio.Semaphore(1)
    return _sem


def _model_ok(installed, wanted):
    if wanted in installed:
        return True
    if ":" not in wanted and f"{wanted}:latest" in installed:
        return True
    return False


def enabled():
    return bool(config.LLM_ENABLED and _state["ok"] and _model_ok(_state["models"], config.OLLAMA_MODEL))


def status():
    return dict(enabled=config.LLM_ENABLED, available=enabled(), server=_state["ok"], model=config.OLLAMA_MODEL, installed=list(_state["models"]),
                pulling=_state["pulling"], pull_status=_state["pull_status"], error=_state["error"])


async def probe(force=False):
    if not config.LLM_ENABLED:
        _state.update(ok=False, error="dimatikan (LLM_ENABLED=0)")
        return _state["ok"]
    if not force and time.time() - _state["checked"] < 20:
        return _state["ok"]
    _state["checked"] = time.time()
    try:
        async with httpx.AsyncClient(timeout=4.0) as c:
            r = await c.get(f"{config.OLLAMA_HOST}/api/tags")
            r.raise_for_status()
            names = [m.get("name") or m.get("model") for m in (r.json().get("models") or [])]
        _state.update(ok=True, models=[n for n in names if n], error=None)
        health.host_ok("ollama")
    except Exception as exc:
        _state.update(ok=False, models=[], error=f"Ollama tidak merespons: {type(exc).__name__}")
        health.host_fail("ollama", exc)
    return _state["ok"]


def _find_binary():
    found = shutil.which("ollama")
    if found:
        return found
    if sys.platform.startswith("win"):
        import os
        for base in (os.environ.get("LOCALAPPDATA", ""), os.environ.get("ProgramFiles", "")):
            cand = os.path.join(base, "Programs", "Ollama", "ollama.exe") if base else ""
            if cand and os.path.exists(cand):
                return cand
    return None


async def ensure_server(wait=25):
    """Nyalakan `ollama serve` bila belum berjalan dan binary-nya ada."""
    if await probe(force=True):
        return True
    exe = _find_binary()
    if not exe:
        _state["error"] = "Ollama belum terpasang (jalankan install.bat)"
        return False
    if not _state["spawned"]:
        try:
            flags, pre = 0, None
            if sys.platform.startswith("win"):
                # prioritas di bawah normal: AI tidak merebut CPU dari server website/tunnel
                flags = (getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
                         | getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0))
            else:
                pre = lambda: os.nice(10)   # noqa: E731
            subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                             creationflags=flags, preexec_fn=pre)
            _state["spawned"] = True
        except Exception as exc:
            _state["error"] = f"gagal menjalankan ollama serve: {exc}"
            return False
    for _ in range(wait):
        await asyncio.sleep(1)
        if await probe(force=True):
            return True
    return False


async def ensure_model():
    """Unduh model bila belum ada (sekali, di latar belakang)."""
    if not await probe(force=True) or _model_ok(_state["models"], config.OLLAMA_MODEL) or _state["pulling"]:
        return enabled()
    _state["pulling"] = True
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(None, connect=10.0)) as c:
            async with c.stream("POST", f"{config.OLLAMA_HOST}/api/pull", json={"model": config.OLLAMA_MODEL, "stream": True}) as r:
                async for line in r.aiter_lines():
                    if not line:
                        continue
                    try:
                        j = json.loads(line)
                    except Exception:
                        continue
                    if j.get("error"):
                        raise RuntimeError(j["error"])
                    tot, done = j.get("total"), j.get("completed")
                    _state["pull_status"] = f"{j.get('status', '')} {int(done / tot * 100)}%" if tot and done else j.get("status", "")
    except Exception as exc:
        _state["error"] = f"gagal mengunduh model: {str(exc)[:120]}"
    finally:
        _state["pulling"] = False
    await probe(force=True)
    return enabled()


async def complete(prompt, max_tokens=300, system=None, temperature=0.3):
    """Hasilkan teks dari model lokal. Melempar exception bila Ollama/model tidak tersedia."""
    if not enabled():
        await probe()
        if not enabled():
            raise RuntimeError(_state["error"] or f"model {config.OLLAMA_MODEL} belum terpasang")
    body = {"model": config.OLLAMA_MODEL, "prompt": prompt, "stream": False, "keep_alive": "30m",
            "options": {"num_predict": max_tokens, "temperature": temperature, "num_ctx": 2048, "num_thread": config.OLLAMA_THREADS}}
    if system:
        body["system"] = system
    async with _lock():
        async with httpx.AsyncClient(timeout=httpx.Timeout(config.OLLAMA_TIMEOUT, connect=5.0)) as c:
            r = await c.post(f"{config.OLLAMA_HOST}/api/generate", json=body)
            r.raise_for_status()
            text = (r.json().get("response") or "").strip()
    if not text:
        raise ValueError("LLM kosong")
    return text


SYSTEM_ID = ("Kamu analis pasar keuangan. Tulis dalam Bahasa Indonesia yang ringkas dan netral. "
             "Gunakan hanya informasi pada headline yang diberikan. Jangan mengarang angka, tanggal, atau kutipan. Tanpa tanda bintang atau markdown.")


# ---- narasi tersimpan -------------------------------------------------------------------------------------------
def fingerprint(headlines):
    return hashlib.sha1("|".join(sorted(h["title"] for h in headlines[:6])).encode()).hexdigest()[:12]


def stored(kind, cid, fp):
    v = store.kv_get(f"narr:{kind}:{cid}")
    if v and v.get("fp") == fp:
        return v.get("text")
    return None


def _prompt(kind, cat):
    heads = "\n".join(f"- {h['title']} ({h['source']})" for h in cat["headlines"][:5])
    if kind == "analysis":
        return f"Tulis analisis pasar 3 kalimat tentang tema '{cat['title']}' berdasarkan headline berikut.\n{heads}"
    return f"Tulis ringkasan riset portofolio singkat (maksimal 80 kata) untuk tema '{cat['title']}' beserta implikasi bagi aset ({cat['asset']}). Headline:\n{heads}"


async def narrate(cats, limit=6):
    """Buat narasi untuk katalis teratas yang headline-nya berubah. Dipanggil dari loop latar belakang."""
    done = 0
    if not enabled():
        return 0
    for c in cats[:limit]:
        fp = fingerprint(c["headlines"])
        for kind, mx in (("analysis", 220), ("research", 200)):
            if stored(kind, c["id"], fp):
                continue
            try:
                text = await complete(_prompt(kind, c), mx, SYSTEM_ID)
            except Exception:
                return done
            store.kv_set(f"narr:{kind}:{c['id']}", dict(fp=fp, text=text))
            done += 1
    return done
