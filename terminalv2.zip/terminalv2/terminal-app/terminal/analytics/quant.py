import asyncio
import numpy as np
import pandas as pd
from ..http import cached
from ..providers import yahoo
from ..universe import FX_CORE, BY_SYM


def _df(rows):
    df = pd.DataFrame(rows)
    df["date"] = pd.to_datetime(df["d"])
    return df.set_index("date")[["o", "h", "l", "c", "v"]].astype(float).dropna(subset=["c"])


def _rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    rs = up / dn.replace(0, np.nan)
    return 100 - 100 / (1 + rs)


def _atr(df, n=14):
    pc = df["c"].shift()
    tr = pd.concat([df["h"] - df["l"], (df["h"] - pc).abs(), (df["l"] - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def _levels(df, n=3, lookback=140):
    t = df.iloc[-lookback:]
    hi, lo = t["h"].values, t["l"].values
    piv = []
    for i in range(3, len(t) - 3):
        if hi[i] == hi[i - 3:i + 4].max():
            piv.append(float(hi[i]))
        if lo[i] == lo[i - 3:i + 4].min():
            piv.append(float(lo[i]))
    last = float(df["c"].iloc[-1])
    tol = float(_atr(df).iloc[-1]) * 0.6 or last * 0.002
    piv.sort()
    clusters = []
    for p in piv:
        if clusters and abs(p - clusters[-1][-1]) <= tol:
            clusters[-1].append(p)
        else:
            clusters.append([p])
    lv = sorted([(len(c), float(np.mean(c))) for c in clusters], reverse=True)[: n * 2]
    return sorted([p for _, p in lv])


def technical(df):
    c = df["c"]
    sma20, sma50, sma200 = c.rolling(20).mean(), c.rolling(50).mean(), c.rolling(200).mean()
    ema20 = c.ewm(span=20, adjust=False).mean()
    atr = _atr(df)
    rsi = _rsi(c)
    macd = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    macd_h = macd - macd.ewm(span=9, adjust=False).mean()
    state = pd.Series(np.where((c > sma50) & (sma50 > sma200), 1, np.where((c < sma50) & (sma50 < sma200), -1, 0)), index=c.index)
    state = state.where(sma200.notna(), np.where(c > sma50, 1, -1))
    cur = int(state.iloc[-1])
    run = 1
    for v in state.iloc[::-1].iloc[1:]:
        if int(v) == cur:
            run += 1
        else:
            break
    since = str(state.index[-run].date())
    tail = df.iloc[-120:]
    idx = tail.index

    def ser(s):
        return [None if pd.isna(x) else round(float(x), 6) for x in s.reindex(idx)]

    return dict(
        dates=[str(d.date()) for d in idx], close=ser(c), sma20=ser(sma20), sma50=ser(sma50), sma200=ser(sma200), ema20=ser(ema20), upper=ser(ema20 + 2 * atr), lower=ser(ema20 - 2 * atr), rsi=ser(rsi),
        regime={1: "BULLISH", -1: "BEARISH", 0: "NEUTRAL"}[cur], since=since, run=run, rsi_last=float(rsi.iloc[-1]), atr=float(atr.iloc[-1]), macd=float(macd_h.iloc[-1]),
        sma=dict(s20=float(sma20.iloc[-1]), s50=float(sma50.iloc[-1]) if not pd.isna(sma50.iloc[-1]) else None, s200=float(sma200.iloc[-1]) if not pd.isna(sma200.iloc[-1]) else None),
        levels=_levels(df), last=float(c.iloc[-1]),
    )


def hurst(x):
    x = np.asarray(x, dtype=float)
    if len(x) < 64:
        return None
    sizes = [8, 16, 32, 64, min(128, len(x) // 2)]
    rs = []
    for n in sizes:
        chunks = len(x) // n
        vals = []
        for i in range(chunks):
            seg = x[i * n:(i + 1) * n]
            dev = np.cumsum(seg - seg.mean())
            s = seg.std()
            if s > 0:
                vals.append((dev.max() - dev.min()) / s)
        if vals:
            rs.append((np.log(n), np.log(np.mean(vals))))
    if len(rs) < 3:
        return None
    a = np.array(rs)
    return float(np.polyfit(a[:, 0], a[:, 1], 1)[0])


def statistical(df):
    r = np.log(df["c"]).diff().dropna().iloc[-252:]
    mu, sd = r.mean(), r.std()
    neg = r[r < 0].std()
    hist, edges = np.histogram(r, bins=15)
    h = hurst(r.values)
    return dict(
        sharpe=float(mu / sd * np.sqrt(252)) if sd else None, sortino=float(mu / neg * np.sqrt(252)) if neg else None, skew=float(r.skew()), kurt=float(r.kurt()), var95=float(np.percentile(r, 5)),
        hurst=h, hurst_label=None if h is None else ("TRENDING (PERSISTENT)" if h > 0.55 else ("MEAN-REVERTING" if h < 0.45 else "RANDOM WALK")), ann_return=float(mu * 252 * 100), ann_vol=float(sd * np.sqrt(252) * 100),
        hist=dict(counts=[int(x) for x in hist], edges=[float(e) for e in edges]),
    )


def volatility(df):
    r = np.log(df["c"]).diff().dropna()
    rv30 = r.rolling(30).std() * np.sqrt(252) * 100
    rv90 = r.rolling(90).std() * np.sqrt(252) * 100
    tail = r.index[-180:]
    wins = [5, 10, 20, 60, 120, 250]
    offsets = [0, 21, 63, 126]
    term = []
    for off in offsets:
        row = []
        for w in wins:
            seg = r.iloc[: len(r) - off].iloc[-w:] if len(r) - off > w else None
            row.append(float(seg.std() * np.sqrt(252) * 100) if seg is not None and len(seg) > 2 else None)
        term.append(row)
    return dict(dates=[str(d.date()) for d in tail], rv30=[None if pd.isna(x) else round(float(x), 3) for x in rv30.reindex(tail)], rv90=[None if pd.isna(x) else round(float(x), 3) for x in rv90.reindex(tail)],
                current=float(rv30.iloc[-1]) if not pd.isna(rv30.iloc[-1]) else None, windows=wins, term=term, offsets=["Current", "1M ago", "3M ago", "6M ago"])


def seasonality(df):
    c = df["c"]
    r = c.pct_change().dropna() * 100
    monthly = c.resample("ME").last().pct_change().dropna() * 100
    by_month = monthly.groupby(monthly.index.month).mean()
    months = [None if m not in by_month.index else float(by_month[m]) for m in range(1, 13)]
    dow = r.groupby(r.index.dayofweek).mean()
    days = [None if d not in dow.index else float(dow[d]) for d in range(5)]
    doy = r.groupby(r.index.dayofyear).mean().reindex(range(1, 367)).fillna(0)
    model = doy.rolling(7, min_periods=1, center=True).mean().cumsum()
    valid = [(i, m) for i, m in enumerate(months) if m is not None]
    best = max(valid, key=lambda x: x[1]) if valid else None
    worst = min(valid, key=lambda x: x[1]) if valid else None
    names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return dict(months=months, dow=days, model=[float(x) for x in model.values], best=dict(m=names[best[0]], v=best[1]) if best else None, worst=dict(m=names[worst[0]], v=worst[1]) if worst else None)


@cached(900)
async def asset_bundle(symbol):
    rows = await asyncio.to_thread(yahoo._history_sync, symbol, "3y", "1d")
    if len(rows) < 60:
        raise ValueError("data tidak cukup")
    df = _df(rows)
    return dict(symbol=symbol, last=float(df["c"].iloc[-1]), change=float(df["c"].pct_change().iloc[-1] * 100), technical=technical(df), statistical=statistical(df), volatility=volatility(df), seasonality=seasonality(df))


@cached(1800)
async def correlation_matrix(symbols=tuple(FX_CORE)):
    ys = [f"{s}=X" for s in symbols]
    data = await yahoo.closes(tuple(ys), "1y")
    df = pd.DataFrame({k.replace("=X", ""): v for k, v in data.items()})
    r = np.log(df).diff().dropna(how="all")
    corr = r.corr().fillna(0)
    names = list(corr.columns)
    m = corr.values
    off = [(abs(m[i, j]), names[i], names[j], m[i, j]) for i in range(len(names)) for j in range(i + 1, len(names))]
    hi = max(off, key=lambda x: x[0]) if off else None
    lo = min(off, key=lambda x: x[3]) if off else None
    pos = max(off, key=lambda x: x[3]) if off else None
    score = float(np.mean([o[0] for o in off]) * 100) if off else 0
    return dict(names=names, matrix=[[round(float(x), 2) for x in row] for row in m], score=score, highest=dict(pair=f"{pos[1]}/{pos[2]}", v=float(pos[3])) if pos else None, lowest=dict(pair=f"{lo[1]}/{lo[2]}", v=float(lo[3])) if lo else None)


@cached(1800)
async def rolling_corr(a, b, window=60):
    data = await yahoo.closes((a, b), "2y")
    if a not in data or b not in data:
        raise ValueError("data tidak cukup")
    df = pd.concat([data[a], data[b]], axis=1, keys=["a", "b"]).dropna()
    r = np.log(df).diff().dropna()
    rc = r["a"].rolling(window).corr(r["b"]).dropna().iloc[-250:]
    return dict(dates=[str(d.date()) for d in rc.index], values=[round(float(x), 3) for x in rc.values])
