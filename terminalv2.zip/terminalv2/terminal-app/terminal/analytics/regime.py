import numpy as np
import pandas as pd

DESC = {
    "REFLATION": "Growth is picking up from a soft base while price pressure stays contained or starts to build. Early-cycle conditions tend to reward cyclicals, commodities and value. Policy usually stays supportive, so risk assets are favored and curves steepen as recovery is priced in.",
    "EXPANSION": "Output is growing solidly while inflation stays under control. This is the most benign backdrop: earnings and credit conditions are healthy, quality and growth equities do well, and policy has room to stay neutral to accommodative.",
    "STAGFLATION": "Growth is losing momentum while inflation stays elevated. Central banks are boxed in, real yields are squeezed and margins come under pressure. Defensive sectors, hard assets and short-duration positioning tend to hold up better.",
    "DEFLATION": "Both activity and prices are contracting, which is a classic recessionary signal. Safe-haven assets and long-duration bonds usually outperform, defensives lead equities, and easing from the central bank becomes more likely as credit stress emerges.",
}
COLOR = {"REFLATION": "#f59e0b", "EXPANSION": "#10b981", "STAGFLATION": "#fb923c", "DEFLATION": "#ef4444"}


def classify(g, i):
    if g >= 0 and i >= 0:
        return "REFLATION"
    if g >= 0 and i < 0:
        return "EXPANSION"
    if g < 0 and i >= 0:
        return "STAGFLATION"
    return "DEFLATION"


def zscore_last(values, window=None):
    s = pd.Series([v for v in values if v is not None and not np.isnan(v)], dtype=float)
    if window:
        s = s.iloc[-window:]
    if len(s) < 6 or s.std(ddof=0) == 0:
        return None, None, None
    return float((s.iloc[-1] - s.mean()) / s.std(ddof=0)), float(s.mean()), float(s.std(ddof=0))


def z_series(values, window=None):
    s = pd.Series(values, dtype=float)
    base = s.iloc[-window:] if window else s
    sd = base.std(ddof=0)
    if len(base) < 6 or sd == 0:
        return pd.Series([np.nan] * len(s), index=s.index)
    return (s - base.mean()) / sd


def correlation(a, b):
    n = min(len(a), len(b))
    if n < 4:
        return None
    x, y = np.array(a[-n:], dtype=float), np.array(b[-n:], dtype=float)
    if x.std() == 0 or y.std() == 0:
        return None
    return float(np.corrcoef(x, y)[0, 1])


def alignment_label(rho, gdiff, idiff):
    if rho is None:
        return "INSUFFICIENT DATA"
    spread = max(abs(gdiff or 0), abs(idiff or 0))
    if rho > 0.6 and spread < 1:
        return "STRONG ALIGNMENT"
    if rho > 0.2 and spread < 1.5:
        return "MODERATE ALIGNMENT"
    if rho < -0.3 or spread > 2:
        return "STRONG DIVERGENCE"
    return "MODERATE DIVERGENCE"
