import re

STRONG_BULL = ["surge", "soar", "skyrocket", "record high", "all-time high", "rally", "jumps", "spike", "boom", "best day", "blowout", "melt-up", "naik tajam", "melonjak"]
BULL = ["rise", "rises", "gain", "gains", "climb", "higher", "beat", "beats", "upgrade", "boost", "rebound", "recover", "strong", "growth", "optimism", "approve", "inflow", "bull", "buys", "bought", "naik", "menguat", "positif", "ekspansi"]
BEAR = ["fall", "falls", "drop", "drops", "slip", "slips", "decline", "lower", "miss", "misses", "downgrade", "weak", "slow", "fear", "cut", "outflow", "bear", "warn", "risk", "slide", "slides", "sink", "sinks", "retreat", "retreats", "turun", "melemah", "negatif", "kontraksi", "defisit"]
STRONG_BEAR = ["plunge", "crash", "tumble", "collapse", "slump", "sell-off", "selloff", "worst", "panic", "plummet", "wipe", "default", "anjlok", "ambruk", "terpuruk"]

CRIT_KW = ["killed", "kills", "kill ", "dead", "attack", "missile", "strike", "explosion", "invasion", "airstrike", "bomb", "war", "assassin", "coup", "nuclear", "hack", "cyber", "default", "crash", "emergency", "evacuat", "shot down", "drone", "serang", "tewas", "perang"]
HIGH_KW = ["sanction", "tariff", "fed ", "fomc", "ecb", "boe", "boj", "rate cut", "rate hike", "rate decision", "inflation", "cpi", "recession", "opec", "bankruptcy", "downgrade", "crisis", "embargo", "shutdown", "veto", "suku bunga", "inflasi"]
FLASH_KW = ["breaking", "just in", "flash", "urgent", "developing", "alert"]
TIER1 = ["reuters", "bloomberg", "cnbc", "financial times", "ft.com", "wsj", "wall street journal", "bbc", "associated press", "ap news", "al jazeera", "the economist", "barron", "marketwatch", "nikkei", "axios", "politico"]

TAG_KW = {
    "SECURITY": ["cyber", "hack", "breach", "ransomware", "malware", "espionage"],
    "GEOPOL": ["war", "sanction", "military", "nato", "missile", "ceasefire", "troops", "invasion", "strait", "hormuz", "houthi", "diplomat", "geopolit"],
    "SUPPLY": ["supply", "shortage", "output", "production", "opec", "stockpile", "inventory", "export ban", "pasokan", "produksi"],
    "MACRO": ["pmi", "cpi", "gdp", "jobs", "payroll", "unemployment", "retail sales", "inflation", "central bank", "rate decision", "pdb", "inflasi"],
    "M&A DEAL": ["acquire", "acquisition", "merger", "takeover", "buys", "to buy", "buyout", "stake", "deal to"],
    "EARNINGS": ["earnings", "revenue", "profit", "guidance", "quarterly results", "eps", "laba"],
}

CAT_KW = {
    "CRYPTO": ["bitcoin", "btc", "ethereum", "ether", "crypto", "stablecoin", "solana", "ripple", "xrp", "binance", "coinbase", "etf inflow", "altcoin", "defi", "token"],
    "COMMODITIES": ["oil", "crude", "brent", "wti", "opec", "gold", "silver", "copper", "natural gas", "lng", "wheat", "corn", "soybean", "coffee", "cocoa", "commodity", "commodities", "aluminium", "aluminum", "nickel", "lithium", "minyak", "emas", "batu bara", "coal"],
    "FOREX": ["forex", "dollar", "usd/", "eur/usd", "gbp/", "yen", "euro ", "sterling", "currency", "exchange rate", "fx ", "dxy", "rupiah", "kurs"],
    "TECH": ["ai ", "artificial intelligence", "chip", "semiconductor", "nvidia", "apple", "microsoft", "google", "alphabet", "meta ", "openai", "software", "cloud", "tesla", "amazon", "tech"],
    "UNITED STATES": ["u.s.", "us ", "united states", "fed ", "federal reserve", "fomc", "trump", "biden", "white house", "congress", "senate", "treasury", "wall street", "nasdaq", "s&p", "dow "],
    "EUROPE": ["europe", "eu ", "ecb", "euro zone", "eurozone", "germany", "france", "italy", "spain", "uk ", "britain", "london", "ftse", "dax", "brexit", "ukraine", "russia"],
    "ASIA": ["asia", "china", "chinese", "japan", "tokyo", "nikkei", "india", "korea", "taiwan", "hong kong", "singapore", "beijing", "pboc", "boj", "yuan", "asean"],
    "MIDDLE EAST": ["iran", "israel", "gaza", "saudi", "yemen", "houthi", "iraq", "syria", "lebanon", "hormuz", "gulf", "opec", "qatar", "uae", "middle east", "jordan", "tehran", "hamas", "hezbollah"],
    "INDONESIA": ["indonesia", "indonesian", "jakarta", "rupiah", "ihsg", "idx", "bank indonesia", "prabowo", "danantara", "bursa efek", "saham", "ojk", "bi rate", "apbn"],
    "GEOPOLITICS": ["war", "sanction", "military", "nato", "missile", "ceasefire", "troops", "invasion", "diplomat", "summit", "treaty", "coup", "protest", "election", "refugee", "terror", "airstrike", "drone strike", "peace talks"],
    "MARKETS": ["stocks", "shares", "equities", "index", "futures", "bond", "yield", "market", "rally", "sell-off", "ipo", "dividend", "etf", "earnings", "wall street", "bursa", "saham"],
}

_WORD = re.compile(r"[a-z0-9\.\-/&']+")


def _has(text, kws):
    hit = [k for k in kws if k in text]
    return sum(1 for k in hit if not any(k != o and k in o for o in hit))


def score(title):
    t = f" {title.lower()} "
    s = 2 * _has(t, STRONG_BULL) + _has(t, BULL) - _has(t, BEAR) - 2 * _has(t, STRONG_BEAR)
    return s


def sentiment_label(title):
    s = score(title)
    if s >= 2:
        return "STRONG BULL"
    if s == 1:
        return "BULL"
    if s <= -2:
        return "STRONG BEAR"
    if s == -1:
        return "BEAR"
    return ""


def priority(title):
    t = f" {title.lower()} "
    if _has(t, CRIT_KW):
        return "CRIT"
    if _has(t, HIGH_KW):
        return "HIGH"
    return ""


def is_flash(title, source=""):
    t = title.lower()
    if any(k in t for k in FLASH_KW):
        return True
    return title.isupper() and len(title) > 18


def tier1(source):
    s = (source or "").lower()
    return any(k in s for k in TIER1)


def tags(title):
    t = f" {title.lower()} "
    return [name for name, kws in TAG_KW.items() if _has(t, kws)][:2]


def categories(title, hints=()):
    t = f" {title.lower()} "
    out = list(hints)
    for cat, kws in CAT_KW.items():
        if cat in out:
            continue
        if _has(t, kws):
            out.append(cat)
    return out
