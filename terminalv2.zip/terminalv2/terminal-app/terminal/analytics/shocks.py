"""SHOCK EVENT: kejadian mendadak dari berita (pesawat jatuh, kapal tanker diserang, gempa, peretasan bursa, kudeta, ...).

Alur untuk agent & menu SIGNAL:
  1. classify(): judul berita -> jenis kejadian + tingkat (CRIT/HIGH) + lokasi (negara). Hanya berita 12 jam terakhir,
     dan hanya yang benar-benar "kejadian" (bukan analisis/opini).
  2. Laporan yang sama dari beberapa sumber digabung (jenis + negara, jendela 3 jam) -> jumlah sumber = keyakinan.
  3. effects(): dampak yang DIHARAPKAN per aset dari templat jenis kejadian + negara lokasi. Bobot sengaja kecil untuk
     kejadian yang biasanya tidak menggerakkan pasar makro (mis. kecelakaan pesawat sipil) - agent tetap mencatatnya.
  4. Di menu SIGNAL (signals/service.py) dampak itu DIUJI dengan reaksi harga aset sendiri sejak berita terbit
     (hanya bar yang sudah tutup): reaksi besar (>= 1 ATR) -> entry baru ditahan sampai pasar tenang; reaksi
     berlawanan dengan templat -> templat diabaikan (pasar tidak setuju). Tanpa data masa depan.
"""
import math
import re
import time

from ..providers import news as N

WINDOW_H = 12
MERGE_S = 3 * 3600

# jenis kejadian: (pola regex, paruh-hidup dampak dalam jam). Urutan = prioritas bila satu judul cocok beberapa jenis.
TYPES = [
    ("MARITIME", r"(?:tanker|cargo ship|container ship|bulk carrier|vessel|ship|freighter)s? (?:was |were |is |are )?(?:hit|attacked|seized|sunk|sinks|struck|"
                 r"ablaze|on fire|explod|targeted|hijack|boarded)|(?:attack|strike|missile|drone)s? (?:on|at|against) (?:a |an )?(?:\w+ )?(?:tanker|ship|vessel|port)s?|"
                 r"strait of hormuz (?:closed|closure|shut)|close(?:s|d)? the strait|houthis? (?:attack|strike|target|hit)|naval blockade|hits? (?:a )?mine", 8),
    # pesawat (bukan drone) ditembak jatuh: AVIATION yang dieskalasi (risk-off), dicek sebelum CONFLICT agar labelnya spesifik
    ("AVIATION", r"(?:passenger |civilian |commercial )?(?:plane|jet|airliner|aircraft)s? (?:was |is |were )?shot down|shoots? down (?:a )?(?:passenger |civilian )?(?:plane|jet|airliner)", 6),
    ("CONFLICT", r"missile|airstrike|air strike|drones? (?:strike|attack)|drones? (?:were |was )?(?:shot down|intercepted)|invasion|invades|"
                 r"troops (?:enter|cross)|shelling|bombard|declares war|military strike|rocket fire|nuclear (?:test|strike|threat)|ballistic", 12),
    ("AVIATION", r"plane crash|jet crash|airliner|aircraft crash|(?:plane|jet|aircraft|helicopter)s? crash|crash(?:ed|es)? (?:after take ?off|on landing)|"
                 r"passenger (?:jet|plane)|emergency landing|(?:plane|jet|airliner|aircraft) (?:was |is )?shot down|airspace (?:closed|closure|shut)|"
                 r"airport (?:attack|closed|shut)|helicopter crash|military plane", 4),
    ("TERROR", r"terror|suicide bomb|gunman|mass shooting|hostage|car bomb|bombing at|explosion (?:at|in) (?:a )?(?:market|station|mall|church|mosque|hotel)", 6),
    ("DISASTER", r"earthquake|tsunami|hurricane|typhoon|cyclone|volcan|eruption|flash flood|floods? (?:kill|hit|swamp)|wildfire|landslide", 12),
    ("CYBER", r"cyberattack|cyber attack|cyber-attack|hacked|hackers|hack of|ransomware|ddos|data breach|exploit(?:ed)? (?:drain|stole)|stolen crypto|exchange hack", 8),
    ("POLITICAL", r"\bcoup\b|assassinat|martial law|impeach|resigns|resignation|government collapse|snap election|state of emergency|no-confidence|toppled", 12),
    ("FINANCIAL", r"bank (?:failure|collapse|run)|bankruptcy|bankrupt|defaults? on|sovereign default|liquidity crisis|trading halt|circuit breaker|flash crash|bailout|insolven", 12),
    ("ENERGY", r"refinery (?:fire|explosion|attack|outage)|refinery attacks?|pipeline (?:attack|explosion|leak|shut)|power outage|blackout|grid (?:failure|collapse)|"
               r"lng (?:plant|terminal) (?:fire|outage|shut)", 10),
    ("HEALTH", r"outbreak|pandemic|epidemic|new virus|bird flu|h5n1|ebola|mpox", 24),
]
_RX = [(t, re.compile(p, re.I), hl) for t, p, hl in TYPES]
# bukan kejadian (analisis, opini, ulasan, peringatan hari jadi, ramalan pasar)
_NOT_EVENT = re.compile(r"\b(?:how|why|what (?:we|you)|analysis|opinion|explainer|explained|review|lessons from|anniversary|years after|could|might|would|"
                        r"what to know|preview|podcast|interview|watch:|live updates?|economists?|analysts?|experts? say|shows|rates? climb|rates? fall|"
                        r"stock has|shares (?:of|rise|fall|jump)|maker's|backlog|earnings|outlook|forecast)\b", re.I)
_SHOT_DOWN = re.compile(r"shot down|missile|attack|terror|hijack", re.I)

RISK_OFF = {"Gold": 1.0, "USDJPY": -0.7, "USDCHF": -0.6, "US500": -0.8, "US100": -0.8, "US30": -0.7, "VIX": 1.0, "AUDUSD": -0.5, "Bitcoin": -0.5, "US 10Y": -0.5}
TEMPLATES = {
    "MARITIME": dict(scale=1.0, effects={"Brent Oil": 1.0, "Crude Oil WTI": 1.0, "Natural Gas": 0.5, "Gold": 0.4, "USDCAD": -0.4, "US500": -0.3}),
    "CONFLICT": dict(scale=1.0, effects=dict(RISK_OFF, **{"Brent Oil": 0.6, "Crude Oil WTI": 0.6})),
    "TERROR": dict(scale=0.6, effects=RISK_OFF, local=-0.6),
    "POLITICAL": dict(scale=0.5, effects={}, local=-1.0),
    "FINANCIAL": dict(scale=0.8, effects=dict(RISK_OFF, **{"US 10Y": -0.8})),
    "DISASTER": dict(scale=0.5, effects={}, local=-0.7),
    "ENERGY": dict(scale=0.8, effects={"Brent Oil": 0.8, "Crude Oil WTI": 0.8, "Natural Gas": 0.8}),
    "HEALTH": dict(scale=0.6, effects=dict(RISK_OFF, **{"Brent Oil": -0.6, "Crude Oil WTI": -0.6})),
    # kecelakaan pesawat sipil jarang menggerakkan pasar makro: dicatat & dipantau, dampak harga hanya bila ditembak/diserang
    "AVIATION": dict(scale=0.15, effects={}, local=-0.3, escalate=dict(scale=0.9, effects=RISK_OFF)),
    # peretasan: kripto bila menyebut kripto/bursa kripto, selain itu hanya negara lokasi
    "CYBER": dict(scale=0.3, effects={}, local=-0.4, crypto=dict(scale=0.9, effects={"Bitcoin": -1.0, "Ethereum": -1.0, "Solana": -1.0})),
}
_CRYPTO = re.compile(r"crypto|bitcoin|ethereum|exchange|binance|coinbase|defi|token|wallet|stablecoin|bybit|okx", re.I)

# negara lokasi -> kode negara terminal (indeks & mata uang lokal)
COUNTRY_CC = {"united states": "US", "u.s.": "US", "usa": "US", "washington": "US", "china": "CN", "beijing": "CN", "hong kong": "CN", "japan": "JP",
              "tokyo": "JP", "uk": "GB", "britain": "GB", "london": "GB", "germany": "EU", "france": "EU", "paris": "EU", "italy": "EU", "spain": "EU",
              "netherlands": "EU", "belgium": "EU", "ireland": "EU", "greece": "EU", "canada": "CA", "australia": "AU", "indonesia": "ID", "jakarta": "ID",
              "switzerland": "CH", "new zealand": "NZ"}
LOCAL_INDEX = {"US": ["US500", "US100", "US30"], "CN": ["HK50", "CSI1000"], "JP": ["Nikkei225"], "GB": ["FTSE100"], "EU": ["DAX30", "EU50"],
               "CA": ["TSX"], "AU": ["ASX200"], "ID": ["IDX Composite"], "CH": ["CH20"], "NZ": ["NZ50"]}
LOCAL_FX = {"CN": ("USDCNY", -1), "JP": ("USDJPY", -1), "GB": ("GBPUSD", 1), "EU": ("EURUSD", 1), "CA": ("USDCAD", -1), "AU": ("AUDUSD", 1),
            "ID": ("USDIDR", -1), "CH": ("USDCHF", -1), "NZ": ("NZDUSD", 1)}
GUARD_MIN = {"scalp": 20, "intraday": 60, "swing": 180}        # jendela penahan entry sesudah kejadian CRIT


def classify(title):
    """(jenis, paruh-hidup jam) atau (None, None)."""
    if not title or _NOT_EVENT.search(title):
        return None, None
    for t, rx, hl in _RX:
        if rx.search(title):
            return t, hl
    return None, None


def _place(title):
    from ..providers import geo
    p, ll = geo.locate_one(title)
    return p, ll


def events(now=None, hours=WINDOW_H, items=None):
    """Kejadian mendadak 12 jam terakhir, digabung per (jenis, tempat). Hanya berita CRIT/HIGH atau berita cepat (squawk)."""
    now = now or time.time()
    items = items if items is not None else N.all_items(hours * 3600)
    out = []
    for it in sorted(items, key=lambda i: i["ts"]):
        if now - it["ts"] > hours * 3600 or it["ts"] > now:
            continue
        if not (it.get("prio") in ("CRIT", "HIGH") or it.get("fast") or it.get("flash")):
            continue
        typ, hl = classify(it["title"])
        if not typ:
            continue
        place, ll = _place(it["title"])
        cc = COUNTRY_CC.get(place or "")
        sev = "CRIT" if it.get("prio") == "CRIT" else "HIGH"
        hit = next((e for e in out if e["type"] == typ and e["place"] == place and abs(it["ts"] - e["last_ts"]) <= MERGE_S), None)
        src = it.get("source") or ""
        if hit:
            hit["last_ts"] = max(hit["last_ts"], it["ts"])
            hit["n"] += 1
            if src not in hit["sources"]:
                hit["sources"].append(src)
            if sev == "CRIT":
                hit["sev"] = "CRIT"
            if len(hit["titles"]) < 4:
                hit["titles"].append(it["title"])
            continue
        out.append(dict(type=typ, half_life_h=hl, sev=sev, title=it["title"], titles=[it["title"]], place=place, cc=cc, lat=ll[0] if ll else None,
                        lon=ll[1] if ll else None, ts=it["ts"], last_ts=it["ts"], n=1, sources=[src], link=it.get("link"),
                        crypto=bool(_CRYPTO.search(it["title"])), escalated=bool(_SHOT_DOWN.search(it["title"]))))
    out.sort(key=lambda e: -e["ts"])
    return out


def _template(e):
    t = TEMPLATES[e["type"]]
    if e["type"] == "AVIATION" and e.get("escalated"):
        t = dict(t["escalate"], local=t.get("local"))
    if e["type"] == "CYBER" and e.get("crypto"):
        t = dict(t["crypto"], local=t.get("local"))
    return t


def weight(e, now=None):
    """Bobot kejadian 0..1: tingkat x jumlah sumber x peluruhan (paruh-hidup per jenis)."""
    now = now or time.time()
    age_h = max(0.0, (now - e["ts"]) / 3600)
    sev = 1.0 if e["sev"] == "CRIT" else 0.6
    conf = min(1.0, 0.55 + 0.15 * len(e["sources"]))          # 1 sumber 0,70 ... >= 3 sumber 1,0
    return sev * conf * 0.5 ** (age_h / e["half_life_h"])


# konflik hanya menaikkan minyak bila terjadi di kawasan produsen / jalur energi (Gaza, Sudan, dst. tidak)
ENERGY_PLACES = {"iran", "tehran", "iraq", "saudi", "yemen", "houthi", "kuwait", "qatar", "uae", "oman", "libya", "russia", "moscow", "ukraine", "kyiv",
                 "kharkiv", "odesa", "crimea", "venezuela", "nigeria", "algeria"}
OIL = ("Brent Oil", "Crude Oil WTI")


def effects(e):
    """{nama aset: arah x skala} yang diharapkan dari satu kejadian (sebelum dikalikan bobot)."""
    t = _template(e)
    out = {k: v * t["scale"] for k, v in t["effects"].items()}
    if e["type"] == "CONFLICT":
        k = 1.0 if (e.get("place") or "") in ENERGY_PLACES else (0.4 if not e.get("place") else 0.0)
        for o in OIL:
            if o in out:
                out[o] *= k
            if not out.get(o):
                out.pop(o, None)
    loc = t.get("local")
    if loc and e.get("cc"):
        for sym in LOCAL_INDEX.get(e["cc"], []):
            out[sym] = out.get(sym, 0.0) + loc
        fx = LOCAL_FX.get(e["cc"])
        if fx:
            out[fx[0]] = out.get(fx[0], 0.0) + loc * fx[1] * 0.6
    return out


def for_asset(name, evs, now=None, mode="intraday"):
    """Dampak kejadian aktif terhadap satu aset: dict(score -1..1, matched=[...], guard=kejadian CRIT terbaru dalam jendela penahan)."""
    now = now or time.time()
    key = str(name).upper()
    by_type, matched, guard = {}, [], None
    for e in evs:
        eff = {k.upper(): v for k, v in effects(e).items()}
        v = eff.get(key)
        if not v:
            continue
        w = weight(e, now)
        # banyak laporan tentang konflik yang sama tidak dijumlahkan: per jenis diambil dampak terkuat (cegah hitung ganda)
        cur = by_type.get(e["type"])
        if cur is None or abs(v * w) > abs(cur):
            by_type[e["type"]] = v * w
        matched.append(dict(type=e["type"], title=e["title"], place=e["place"], ts=e["ts"], sev=e["sev"], sources=len(e["sources"]),
                            expected=1 if v > 0 else -1, impact=round(v * w, 3)))
        if e["sev"] == "CRIT" and abs(v) >= 0.4 and (now - e["ts"]) / 60 <= GUARD_MIN.get(mode, 60) and (guard is None or e["ts"] > guard["ts"]):
            guard = dict(type=e["type"], title=e["title"], ts=e["ts"], expected=1 if v > 0 else -1)
    if not matched:
        return None
    tot = sum(by_type.values())
    return dict(score=max(-1.0, min(1.0, math.tanh(tot / 1.5))), matched=matched, guard=guard, by_type={k: round(v, 3) for k, v in by_type.items()})


def reaction(guard, idx_ts, close, atr, bar_sec):
    """Reaksi harga aset sejak kejadian, HANYA dari bar yang sudah tutup (tanpa data masa depan).

    idx_ts = waktu BUKA tiap bar (detik epoch, UTC), close = harga tutup, atr = ATR bar terakhir, bar_sec = panjang bar.
    Patokan = harga tutup bar terakhir yang selesai SEBELUM berita terbit. Mengembalikan dict(move_atr, peak_atr, agrees)
    atau None bila belum ada bar yang tutup sesudah berita (reaksi belum bisa dibaca)."""
    if not guard or atr is None or not atr > 0 or not len(idx_ts):
        return None
    ts = guard["ts"]
    k = None
    for j in range(len(idx_ts) - 1, -1, -1):
        if idx_ts[j] + bar_sec <= ts:
            k = j
            break
    if k is None or k >= len(idx_ts) - 1:
        return None
    base = float(close[k])
    seg = [float(c) for c in close[k + 1:]]
    peak = max(seg, key=lambda c: abs(c - base))
    move = (seg[-1] - base) / atr
    return dict(move_atr=round(move, 2), peak_atr=round(abs(peak - base) / atr, 2), agrees=(move * guard["expected"]) >= 0, bars=len(seg))
