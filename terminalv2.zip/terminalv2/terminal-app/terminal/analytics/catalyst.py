import math
import re
from ..providers import news as N
from ..analytics import sentiment as S

THEMES = [
    dict(id="oil_supply", kw=["opec", "crude", "oil prices", "brent", "hormuz", "tanker", "oil supply", "oil output", "wti"], region="Commodity", title="Pasokan Minyak & Harga Energi", asset="Commodity",
         fx={"Brent Oil": 1, "Crude Oil WTI": 1, "USDCAD": -1, "Inflation Expectation": 1}, text="Pergerakan harga minyak mengubah ekspektasi inflasi dan arus perdagangan energi; importir energi tertekan sementara eksportir diuntungkan."),
    dict(id="fed", kw=["federal reserve", "fed ", "fomc", "powell", "rate cut", "rate hike", "treasury yield"], region="United States", title="Arah Kebijakan The Fed", asset="Rates",
         fx={"US 10Y": 1, "USD Index": 1, "Gold": -1, "US100": -1}, text="Sinyal kebijakan The Fed menggeser ekspektasi suku bunga, yield obligasi AS dan penguatan dolar."),
    dict(id="us_equity", kw=["wall street", "s&p 500", "nasdaq", "dow jones", "stocks rally", "stock market", "equities"], region="United States", title="Pasar Saham AS", asset="Equity",
         fx={"US500": 1, "US100": 1, "US30": 1, "VIX": -1}, text="Sentimen risiko di pasar saham AS menjadi acuan selera risiko global."),
    dict(id="us_inflation", kw=["inflation", "cpi", "pce", "consumer prices", "producer prices"], region="United States", title="Data Inflasi & Harga", asset="Macro",
         fx={"US 10Y": 1, "USD Index": 1, "Gold": -1}, text="Data harga yang lebih panas dari perkiraan menaikkan yield dan menekan aset berdurasi panjang."),
    dict(id="jobs", kw=["jobs report", "payroll", "unemployment", "jobless claims", "labor market"], region="United States", title="Pasar Tenaga Kerja AS", asset="Macro",
         fx={"USD Index": 1, "US 10Y": 1, "US500": 1}, text="Kondisi tenaga kerja memengaruhi jalur pemangkasan suku bunga dan arah dolar."),
    dict(id="ecb_euro", kw=["ecb", "lagarde", "euro zone", "eurozone", "bund", "european central bank"], region="Europe", title="Kebijakan ECB & Zona Euro", asset="Rates",
         fx={"EURUSD": 1, "DAX30": 1, "Bund 10Y": 1}, text="Keputusan dan sinyal ECB menggeser valuasi euro dan ekuitas Eropa."),
    dict(id="boe_uk", kw=["bank of england", "boe", "gilt", "sterling", "uk inflation"], region="Europe", title="Bank of England & Poundsterling", asset="Rates",
         fx={"GBPUSD": 1, "FTSE100": 1}, text="Arah kebijakan BoE dan yield gilt menentukan tekanan pada poundsterling."),
    dict(id="boj_yen", kw=["bank of japan", "boj", "yen", "nikkei", "ueda"], region="Asia", title="Bank of Japan & Yen", asset="FX",
         fx={"USDJPY": -1, "Nikkei225": 1}, text="Normalisasi kebijakan BoJ memengaruhi yen, carry trade dan ekuitas Jepang."),
    dict(id="china", kw=["china economy", "pboc", "yuan", "china stimulus", "beijing", "china exports", "china's"], region="Asia", title="Ekonomi & Stimulus China", asset="Equity",
         fx={"HK50": 1, "CSI1000": 1, "Copper": 1, "AUDUSD": 1}, text="Stimulus dan data ekonomi China menentukan permintaan komoditas dan sentimen pasar Asia."),
    dict(id="midEast", kw=["iran", "israel", "gaza", "houthi", "red sea", "yemen", "strait"], region="Middle East", title="Eskalasi Timur Tengah", asset="Geopolitical",
         fx={"Gold": 1, "Brent Oil": 1, "USDCHF": -1, "US500": -1}, text="Eskalasi konflik mendorong aset safe-haven dan premi risiko pasokan energi."),
    dict(id="ukraine", kw=["ukraine", "russia", "kyiv", "moscow", "nato", "sanctions on russia"], region="Europe", title="Perang Rusia–Ukraina", asset="Geopolitical",
         fx={"Wheat": 1, "Natural Gas": 1, "EURUSD": -1}, text="Perkembangan perang dan sanksi memengaruhi pasokan gas, biji-bijian dan sentimen Eropa."),
    dict(id="crypto", kw=["bitcoin", "ethereum", "crypto", "stablecoin", "spot etf", "solana"], region="Crypto", title="Pasar Kripto", asset="Crypto",
         fx={"Bitcoin": 1, "Ethereum": 1, "Solana": 1}, text="Arus ETF dan regulasi menentukan sentimen aset kripto."),
    dict(id="gold", kw=["gold price", "gold rally", "bullion", "safe haven", "gold hits"], region="Commodity", title="Emas & Aset Safe-Haven", asset="Commodity",
         fx={"Gold": 1, "Silver": 1, "USD Index": -1}, text="Permintaan safe-haven dan ekspektasi suku bunga riil menggerakkan emas."),
    dict(id="tech_ai", kw=["nvidia", "artificial intelligence", "ai stocks", "semiconductor", "chipmaker", "big tech"], region="United States", title="Teknologi & AI", asset="Equity",
         fx={"US100": 1, "Nvidia": 1}, text="Siklus belanja AI dan laporan keuangan big tech menentukan arah indeks teknologi."),
    dict(id="tariff", kw=["tariff", "trade war", "trade deal", "export controls", "trade talks"], region="Global", title="Tarif & Perang Dagang", asset="Macro",
         fx={"USDCNY": 1, "US500": -1, "Copper": -1}, text="Kebijakan tarif menekan perdagangan global dan rantai pasok."),
    dict(id="indonesia", kw=["ihsg", "rupiah", "bank indonesia", "bi rate", "indonesia economy", "danantara", "saham indonesia"], region="Indonesia", title="Pasar Indonesia (IHSG & Rupiah)", asset="Equity",
         fx={"IDX Composite": 1, "USDIDR": -1}, text="Arus asing, kebijakan BI dan sentimen global menentukan IHSG dan rupiah."),
]
_N = re.compile(r"[^a-z0-9 .&%/-]")


def build(hours=36):
    items = N.all_items(hours * 3600)
    out = []
    for th in THEMES:
        hits = []
        for it in items:
            t = f" {it['title'].lower()} "
            if any(k in t for k in th["kw"]):
                hits.append(it)
        if not hits:
            continue
        sent = sum(S.score(i["title"]) for i in hits)
        crit = sum(1 for i in hits if i["prio"] == "CRIT")
        high = sum(1 for i in hits if i["prio"] == "HIGH")
        t1 = sum(1 for i in hits if i["t1"])
        strength = math.log1p(len(hits)) * 20 + crit * 8 + high * 3 + t1 * 2
        sign = 1 if sent > 0 else (-1 if sent < 0 else 0)
        bias = "BULLISH" if sign > 0 else ("BEARISH" if sign < 0 else "NEUTRAL")
        impact = "HIGH" if strength >= 55 else ("MEDIUM" if strength >= 32 else "LOW")
        instruments = []
        for sym, d in th["fx"].items():
            instruments.append(dict(sym=sym, dir=("BULLISH" if d * (sign or 1) > 0 else "BEARISH") if sign else "NEUTRAL", weight=min(99, int(strength))))
        out.append(dict(id=th["id"], title=th["title"], region=th["region"], asset=th["asset"], text=th["text"], impact=impact, bias=bias, strength=round(strength, 1), count=len(hits), crit=crit, sent=sent,
                        instruments=instruments, headlines=[dict(title=i["title"], source=i["source"], ts=i["ts"], link=i["link"]) for i in hits[:6]], ts=hits[0]["ts"]))
    out.sort(key=lambda x: -x["strength"])
    return out


def graph(cats):
    nodes, links, seen = [], [], set()

    def add(id_, name, cat, size):
        if id_ not in seen:
            seen.add(id_)
            nodes.append(dict(id=id_, name=name, category=cat, symbolSize=size))
    for c in cats[:8]:
        cid, tid = "c:" + c["id"], "t:" + c["id"]
        add(cid, c["title"], 0, 18 + min(c["count"], 30))
        add(tid, c["bias"] + " · " + c["asset"], 1, 22)
        links.append(dict(source=cid, target=tid, value=c["strength"], bias=c["bias"]))
        ids = "i:" + c["asset"]
        add(ids, c["asset"] + " impact", 2, 26)
        links.append(dict(source=tid, target=ids, value=c["strength"], bias=c["bias"]))
        for ins in c["instruments"][:4]:
            iid = "s:" + ins["sym"]
            add(iid, ins["sym"], 3, 16)
            links.append(dict(source=ids, target=iid, value=ins["weight"], bias=ins["dir"]))
    return dict(nodes=nodes, links=links, categories=["Catalyst", "Thesis", "Impact", "Instrument"])
