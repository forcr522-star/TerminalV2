"""KONTEKS DUNIA untuk agent & menu SIGNAL: semua informasi website diringkas menjadi satu potret bertanggal.

Sumber (semuanya sudah dipakai website; tidak ada permintaan tambahan ke internet kecuali yang memang di-cache):
  - risiko negara (berita ter-geolokasi + titik panas GDELT)        -> menu GEOPOLITICAL RISK / layer Risk
  - choke point (berita + transit harian IMF PortWatch)             -> layer Maritime
  - kunjungan kapal per negara 7 hari vs 28 hari (IMF PortWatch)    -> layer Maritime
  - pesawat militer per kawasan (adsb.lol, HANYA dari cache)        -> layer Airplane (informasi, tanpa skor: belum ada baseline)
  - serangan siber terkait kripto (pers + berita)                   -> layer Cyber
  - kejadian mendadak (analytics/shocks)                            -> semua berita cepat / squawk

drivers() mengubah potret itu menjadi komponen skor per aset (-1..1) beserta teks alasannya. Bobotnya kecil: fundamental
di bot ini hanya mengatur UKURAN posisi & boleh menahan entry, tidak membalik arah sinyal teknikal.
"""
import asyncio
import math
import time

from . import shocks as SH

CC_WORLD = {"US": ["United States of America"], "EU": ["Germany", "France", "Italy", "Spain", "Netherlands", "Belgium"], "JP": ["Japan"],
            "GB": ["United Kingdom"], "CN": ["China"], "CA": ["Canada"], "AU": ["Australia"], "ID": ["Indonesia"], "CH": ["Switzerland"], "NZ": ["New Zealand"]}
CC_PORT = {"US": ["United States of America"], "EU": ["Germany", "Netherlands", "Belgium", "France", "Italy", "Spain"], "JP": ["Japan"], "GB": ["United Kingdom"],
           "CN": ["China"], "CA": ["Canada"], "AU": ["Australia"], "ID": ["Indonesia"], "NZ": ["New Zealand"]}
MIDEAST = ["Iran", "Iraq", "Saudi Arabia", "Yemen", "Israel", "United Arab Emirates", "Qatar", "Kuwait", "Oman", "Russia"]
LVL = {"CRITICAL": 1.0, "HIGH": 0.6, "ELEVATED": 0.3, "NORMAL": 0.0}
CCY_ENERGY = {"CAD": 0.5, "NOK": 0.5, "JPY": -0.4, "EUR": -0.2, "INR": -0.3}   # eksportir energi (+) / importir (-)
_memo = dict(at=0.0, val=None)
TTL = 60


def _t(x, s):
    return math.tanh(x / s)


async def snapshot(force=False):
    """Potret dunia (cache 60 dtk). Tidak pernah melempar error; bagian yang gagal ditandai di `sources`."""
    if not force and _memo["val"] and time.time() - _memo["at"] < TTL:
        return _memo["val"]
    from ..providers import geo, portwatch, airtraffic, cyber
    src = {}

    async def safe(name, coro, t=12):
        try:
            v = await asyncio.wait_for(coro, t)
            src[name] = "ok"
            return v
        except Exception as exc:
            src[name] = type(exc).__name__
            return None
    hot, summ, act = await asyncio.gather(safe("gdelt", geo.gdelt_hotspots()), safe("portwatch", portwatch.summary()), safe("ports", portwatch.port_activity()))
    from .. import cpu
    risk = await cpu.run(geo.risk_map, geo.events(400), hot or [])
    cps = geo.chokepoints()
    pwmap = portwatch.for_chokepoints(summ) if summ else {}
    for c in cps:
        c["pw"] = pwmap.get(c["id"])
    ports = {}
    if act:
        names = {}
        for iso, v in (act.get("countries") or {}).items():
            names[portwatch.WORLD_NAME.get(iso, iso)] = v
        ports = dict(date=act.get("date"), countries=names, by_iso={k: v for k, v in (act.get("countries") or {}).items()})
    air, air_at = airtraffic.military.peek()                       # tanpa permintaan baru: kuota adsb.lol dijaga
    src["air"] = "cache" if air else "belum ada (layer Airplane belum dibuka)"
    press, _ = cyber.press_attacks.peek()
    vic, _ = cyber.ransomware.peek()
    from .. import cpu
    try:
        news_cy = await cpu.run(cyber.cyber_news, hours=24)       # regex atas ribuan judul: bukan di event loop
    except Exception:
        news_cy = []
    now = time.time()
    crypto_cy = [a for a in (press or []) if a.get("ts") and now - a["ts"] < 86400 and SH._CRYPTO.search(a.get("title") or "")]
    crypto_cy += [n for n in news_cy if SH._CRYPTO.search(n["title"])]
    evs = await cpu.run(SH.events, now)                          # klasifikasi + pencarian lokasi ratusan judul
    val = dict(ts=now, risk=risk, chokepoints=cps, ports=ports, air=dict(regions=(air or {}).get("regions") or [], total=(air or {}).get("total"), at=air_at),
               cyber=dict(crypto_24h=len(crypto_cy), crypto_titles=[c["title"] for c in crypto_cy[:3]], ransomware_recent=len(vic or [])),
               shocks=evs, sources=src)
    _memo.update(at=time.time(), val=val)
    return val


def _risk(world, names):
    rs = [world["risk"].get(n, {}).get("score", 0.0) for n in names]
    return max(rs) if rs else 0.0


def _cp(world, cid):
    c = next((x for x in world.get("chokepoints") or [] if x["id"] == cid), None)
    if not c:
        return 0.0, None
    lvl = LVL.get(c["level"], 0.0)
    chg = ((c.get("pw") or {}).get("chg_pct"))
    drop = max(0.0, min(1.0, -(chg or 0.0) / 30.0))
    return min(1.0, 0.6 * lvl + 0.4 * drop), c


def _port_chg(world, cc):
    pc = (world.get("ports") or {}).get("countries") or {}
    vals = [(pc.get(n) or {}).get("chg") for n in CC_PORT.get(cc, [])]
    vals = [v for v in vals if v is not None]
    return sum(vals) / len(vals) if vals else None


def drivers(info, world):
    """Komponen skor dari konteks dunia untuk satu aset: [(skor -1..1, teks)]. `info` = signals.fundamental.entity()."""
    if not world:
        return []
    kind, name = info["kind"], info["name"].upper()
    out = []

    def add(score, text):
        if score is not None and abs(score) >= 0.05:
            out.append((max(-1.0, min(1.0, float(score))), text))
    # 1. risiko negara (berita + GDELT): negara yang lebih berisiko -> mata uang/indeksnya lebih lemah
    if kind == "FX" and info.get("base") and info.get("quote"):
        from ..universe import CURRENCY_TO_CC
        cb, cq = CURRENCY_TO_CC.get(info["base"]), CURRENCY_TO_CC.get(info["quote"])
        rb, rq = _risk(world, CC_WORLD.get(cb, [])), _risk(world, CC_WORLD.get(cq, []))
        if max(rb, rq) >= 2.0:
            add(_t(rq - rb, 20), f"risiko negara {info['base']} {rb:.0f} vs {info['quote']} {rq:.0f}")
    elif kind == "INDEX" and info.get("cc"):
        r = _risk(world, CC_WORLD.get(info["cc"], []))
        if r >= 2.0:
            add(-_t(r, 20), f"risiko negara {info['cc']} skor {r:.0f}")
    top = sorted((v.get("score", 0.0) for v in world["risk"].values()), reverse=True)[:5]
    g = _t(sum(top), 120)
    me = _t(_risk(world, MIDEAST), 30)
    if kind == "METAL" and name in ("GOLD", "SILVER"):
        add(0.5 * g, f"risiko global (5 negara teratas) {sum(top):.0f}")
    elif kind == "CRYPTO":
        add(-0.3 * g, f"risiko global {sum(top):.0f} (risk-off)")
    elif kind == "ENERGY":
        add(0.4 * me, f"risiko kawasan produsen energi {me:+.2f}")
    # 2. choke point energi: level berita + penurunan transit harian PortWatch
    s_h, c_h = _cp(world, "hormuz")
    s_r, c_r = _cp(world, "redsea")
    s_b, c_b = _cp(world, "blacksea")
    s_t, c_t = _cp(world, "taiwan")
    es = max(s_h, s_r)
    lab = ", ".join(f"{c['name']} {c['level']}" + (f" transit {c['pw']['chg_pct']:+.0f}%" if (c.get("pw") or {}).get("chg_pct") is not None else "")
                    for c in (c_h, c_r) if c and LVL.get(c["level"], 0) > 0)
    if es > 0:
        if kind == "ENERGY":
            add(es if "GAS" not in name else max(es * 0.6, s_b), f"tekanan jalur energi: {lab}")
        elif kind == "METAL" and name == "GOLD":
            add(0.3 * es, f"tekanan jalur energi: {lab}")
        elif kind == "INDEX":
            add(-0.2 * es, f"tekanan jalur energi: {lab}")
        elif kind == "FX":
            e = CCY_ENERGY.get(info.get("base"), 0) - CCY_ENERGY.get(info.get("quote"), 0)
            if e:
                add(e * es, f"tekanan jalur energi ({'eksportir' if e > 0 else 'importir'} energi): {lab}")
    if s_t > 0 and kind == "INDEX" and info.get("cc") in ("US", "CN", "JP"):
        add(-0.3 * s_t, f"Selat Taiwan {c_t['level']} (rantai pasok chip)")
    # 3. aktivitas pelabuhan (nowcast ekonomi riil): China -> tembaga, AUD, indeks China; negara sendiri -> indeksnya
    cn = _port_chg(world, "CN")
    if cn is not None:
        if name == "COPPER":
            add(_t(cn, 15), f"kunjungan kapal China {cn:+.0f}% (7h vs 28h)")
        elif kind == "FX" and "AUD" in (info.get("base"), info.get("quote")):
            add((1 if info.get("base") == "AUD" else -1) * 0.5 * _t(cn, 15), f"kunjungan kapal China {cn:+.0f}% (permintaan komoditas)")
    if kind == "INDEX" and info.get("cc"):
        pc = _port_chg(world, info["cc"])
        if pc is not None:
            add(0.3 * _t(pc, 15), f"kunjungan kapal {info['cc']} {pc:+.0f}% (7h vs 28h)")
    # 4. serangan siber terkait kripto 24 jam
    n = (world.get("cyber") or {}).get("crypto_24h") or 0
    if kind == "CRYPTO" and n:
        add(-0.6 * _t(n, 3), f"{n} serangan/peretasan terkait kripto 24 jam")
    return out


def air_context(world):
    """Teks informasi pesawat militer per kawasan (tanpa skor: belum ada baseline historis)."""
    regs = (world.get("air") or {}).get("regions") or []
    return ", ".join(f"{r['name']} {r['count']}" for r in regs[:4]) if regs else None


def summary(world, limit=6):
    """Ringkasan pendek untuk log agent & menu THINKING."""
    lines = []
    top = sorted(world["risk"].items(), key=lambda kv: -kv[1].get("score", 0))[:4]
    if top:
        lines.append("Risiko negara: " + ", ".join(f"{n} {v['level']}" for n, v in top))
    hot = [c for c in world.get("chokepoints") or [] if c["level"] in ("CRITICAL", "HIGH")]
    if hot:
        lines.append("Choke point: " + ", ".join(f"{c['name']} {c['level']}" for c in hot[:4]))
    ac = air_context(world)
    if ac:
        lines.append("Pesawat militer: " + ac)
    cy = (world.get("cyber") or {}).get("crypto_24h")
    if cy:
        lines.append(f"Siber kripto 24 jam: {cy}")
    for e in (world.get("shocks") or [])[:limit]:
        lines.append(f"SHOCK {e['type']} {e['sev']} {e['place'] or ''} ({len(e['sources'])} sumber): {e['title'][:90]}")
    return lines
