"""Muat-awal: saat program dijalankan, semua menu & fitur dimuat dulu, lalu disimpan ke DB (data/terminal.db).

Tahap 1 (ditunggu sebelum URL ditampilkan): setiap menu beserta semua tab/negara/kelas aset di dalamnya.
    - Hanya yang BELUM punya snapshot yang ditunggu. Bila snapshot dari sesi sebelumnya ada, program langsung siap dan
      data lama itu diperbarui di latar belakang (PRELOAD_FORCE=1 memaksa menunggu muat-ulang penuh).
    - Batas waktu PRELOAD_TIMEOUT: sumber yang macet tidak menahan URL selamanya; sisanya selesai di latar belakang.
Tahap 2 (latar belakang): ekor panjang (semua simbol, instrumen COT, kontrak futures, mitra dagang, dst.).
Sesudah itu pembaruan otomatis berjalan terus (snapshots.refresher) sesuai TTL tiap data.
"""
import asyncio
import time
from . import config, watchdog
from . import snapshots as S
from .api import state


def say(msg):
    print(msg, flush=True)


def _label(j):
    ps = ",".join(f"{k}={v}" for k, v in j.params.items())
    return f"{j.path}" + (f" [{ps}]" if ps else "")


def _kb(n):
    return f"{n / 1024:.0f} KB" if n < 1024 * 1024 else f"{n / 1048576:.1f} MB"


class _Run:
    def __init__(self, jobs, concurrency, force, verbose, every=None, gentle=False):
        self.jobs, self.force, self.verbose = jobs, force, verbose
        self.gentle = gentle          # latar: tunggu server tenang sesudah tertahan sebelum pekerjaan berikutnya
        self.sem = asyncio.Semaphore(max(1, concurrency))
        self.done = self.ok = self.bad = 0
        self.fail = []
        self.every = every
        self._next_mark = every or 0
        self.tasks = [asyncio.ensure_future(self._one(j)) for j in jobs]

    async def _one(self, j):
        async with self.sem:
            if self.gentle:
                await watchdog.calm()
            r = await S.refresh(j.path, j.params, force=self.force, timeout=config.JOB_TIMEOUT, bg=True)
        self.done += 1
        st = state["preload"]
        st["done"] = st.get("done", 0) + 1
        if r.ok:
            self.ok += 1
        else:
            self.bad += 1
            self.fail.append((j, "kosong" if r.empty else "gagal", r.error))
        n = len(self.jobs)
        if self.verbose:
            mark = "ok   " if r.ok else ("kosong" if r.empty else "GAGAL")
            say(f"  [{self.done:>3}/{n}] {mark:<6} {_label(j):<58} {r.ms / 1000:5.1f}s {_kb(len(r.body)) if r.ok else ''}")
        elif self.every and self.done * 100 // n >= self._next_mark:
            say(f"[data] tahap 2: {self.done}/{n} ({self.done * 100 // n}%) ...")
            self._next_mark += self.every
        return r

    async def wait(self, timeout=None):
        if not self.tasks:
            return True
        done, pending = await asyncio.wait(self.tasks, timeout=timeout)
        return not pending


def _failures(run, limit=12):
    for j, kind, err in run.fail[:limit]:
        say(f"   - {kind}: {_label(j)}  ({(err or '')[:90]})")
    if len(run.fail) > limit:
        say(f"   ... dan {len(run.fail) - limit} lainnya (lihat menu Status di website)")


async def wait_done(limit=600, grace=30.0):
    """Tunggu preload tahap 1 selesai (maks. `limit` dtk) - dipakai pekerjaan berat (analisa sinyal, backfill heatmap)
    agar tidak berebut CPU saat start. Hanya menunggu bila preload MEMANG berjalan: bila sesudah `grace` dtk sejak server
    mulai fasenya masih "idle" (server dijalankan tanpa main.py / tanpa preload), langsung lanjut - dulu ditunggu 10 menit."""
    t0 = time.time()
    while time.time() - t0 < limit:
        st = state.get("preload") or {}
        ph = st.get("phase")
        if ph in ("ready", None):
            return "ready"
        if ph == "idle" and time.time() - (state.get("started") or t0) >= grace:
            return "no-preload"
        await asyncio.sleep(1.0 if ph == "idle" else 5.0)
    return "timeout"


async def phase1():
    """Muat semua menu. Mengembalikan setelah selesai atau PRELOAD_TIMEOUT habis."""
    st = state["preload"]
    jobs = S.plan_jobs(1)
    need = [j for j in jobs if config.PRELOAD_FORCE or S.age(j.key) is None]
    stale = [j for j in jobs if j not in need and (S.age(j.key) or 0) >= j.ttl]
    st.update(phase="phase1", done=0, total=len(need), started=time.time(), finished=None)
    have = len([j for j in jobs if S.age(j.key) is not None])
    if have:
        say(f"[data] {have} dari {len(jobs)} menu sudah tersimpan dari sesi sebelumnya ({config.DB_PATH.name}) - langsung tersedia.")
    if need:
        say(f"[preload] memuat {len(need)} menu/fitur dulu (tahap 1) ...")
    t0 = time.time()
    run = _Run(need, config.PRELOAD_CONCURRENCY, force=True, verbose=True)
    # Snapshot lama yang sudah kedaluwarsa disegarkan di latar belakang; pengunjung tidak menunggu.
    bg = _Run(stale, config.REFRESH_CONCURRENCY, force=True, verbose=False) if stale else None
    finished = await run.wait(timeout=config.PRELOAD_TIMEOUT)
    S.enable()
    st.update(phase="ready", finished=time.time())
    if need:
        took = time.time() - t0
        if finished:
            say(f"[preload] selesai dalam {took:.0f} dtk: {run.ok}/{len(need)} siap" + (f", {run.bad} bermasalah:" if run.bad else "."))
            _failures(run)
        else:
            say(f"[preload] batas {config.PRELOAD_TIMEOUT} dtk tercapai: {run.done}/{len(need)} siap; sisanya selesai di latar belakang.")
            _failures(run)
    s = S.summary()
    say(f"[data] tersimpan di {config.DB_PATH}: {s['stored']} snapshot, {_kb(s['bytes'])}.")
    if bg:
        say(f"[data] {len(stale)} data lama sedang diperbarui di latar belakang.")
    return run


async def phase2():
    """Muat ekor panjang di latar belakang (tidak menahan apa pun)."""
    if not config.PRELOAD_DEEP:
        return None
    jobs = S.plan_jobs(2)
    need = [j for j in jobs if config.PRELOAD_FORCE or S.age(j.key) is None]
    if not need:
        return None
    say(f"[data] memuat {len(need)} data pendukung di latar belakang (semua simbol, instrumen, kontrak) ...")
    run = _Run(need, config.REFRESH_CONCURRENCY, force=True, verbose=False, every=25, gentle=True)
    await run.wait()
    say(f"[data] tahap 2 selesai: {run.ok}/{len(need)} siap" + (f", {run.bad} bermasalah (dicoba ulang otomatis)." if run.bad else "."))
    return run
