import asyncio
import contextlib
import contextvars
import hashlib
import time
import functools
from urllib.parse import urlparse
import httpx
from .config import UA
from . import health

_client = None
_client_loop = None
_cache = {}
_locks = {}
_inflight = set()
_bg = set()
_host_sems = {}
_rev = {"n": 0}

HOST_CONCURRENCY = 6
# Batas entri cache di memori. Tanpa batas, terminal yang berjalan berhari-hari (semua simbol x semua parameter)
# menumpuk puluhan ribu entri dan memori terus naik. Entri tertua dibuang saat melewati batas; nilai ber-persist
# tetap tersedia di SQLite sehingga pembuangan hanya memicu satu baca ulang.
MAX_CACHE_KEYS = 4000
MAX_LOCKS = 4000

# Mode "segarkan paksa": dipakai pembaruan latar belakang snapshot. Di dalam blok ini, data ber-cache yang umurnya
# lebih dari FORCE_MAX_AGE detik diambil ulang dari sumber (bukan dikembalikan basi sambil menyegarkan diam-diam).
# Batas FORCE_MAX_AGE mencegah banyak endpoint yang berbagi satu sumber mengambilnya berulang kali dalam satu putaran.
_force = contextvars.ContextVar("force_refresh", default=False)
FORCE_MAX_AGE = 30


@contextlib.contextmanager
def force_refresh():
    tok = _force.set(True)
    try:
        yield
    finally:
        _force.reset(tok)


def rev():
    """Naik setiap kali ada data ber-cache yang nilainya berubah (dipakai klien untuk tahu kapan perlu menyegarkan)."""
    return _rev["n"]


def bump():
    _rev["n"] += 1


def client():
    """Klien HTTP bersama. Dibuat ulang bila event loop berganti (mis. server restart di dalam proses yang sama
    atau pengujian) supaya koneksi lama tidak menempel pada loop yang sudah ditutup."""
    global _client, _client_loop
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if _client is not None and (_client.is_closed or (loop is not None and _client_loop is not loop)):
        _client = None
        _host_sems.clear()
    if _client is None:
        _client = httpx.AsyncClient(
            headers={"User-Agent": UA, "Accept": "application/json, text/csv, text/plain, */*;q=0.8", "Accept-Language": "en-US,en;q=0.9"},
            timeout=httpx.Timeout(25.0, connect=10.0),
            follow_redirects=True,
            limits=httpx.Limits(max_connections=40, max_keepalive_connections=10),
        )
        _client_loop = loop
    return _client


async def close():
    global _client
    if _client is not None and not _client.is_closed:
        await _client.aclose()


def _sem(host):
    s = _host_sems.get(host)
    if s is None:
        s = _host_sems[host] = asyncio.Semaphore(HOST_CONCURRENCY)
    return s


class HttpError(Exception):
    """Dipakai untuk respons error dari jalur penyamaran TLS (curl_cffi)."""

    def __init__(self, status, url):
        super().__init__(f"HTTP {status} untuk {url[:120]}")
        self.status = status


def _status(exc):
    resp = getattr(exc, "response", None)
    if resp is not None and getattr(resp, "status_code", None):
        return resp.status_code
    return getattr(exc, "status", None)


# 403/406 pada host yang menolak klien non-browser (RBA, IMF, FRED, bisnis.com, ...) biasanya karena sidik jari TLS,
# bukan karena User-Agent. Percobaan terakhir dilakukan dengan TLS Chrome sungguhan (curl_cffi) bila terpasang.
_IMPERSONATE_STATUS = (401, 403, 406, 429, 503)
_PERMANENT = (404, 410)
STRIKES_TO_DISABLE = 3
_strikes = {}


async def _impersonated(method, url, params, headers, json, data, timeout):
    try:
        from curl_cffi.requests import AsyncSession
    except Exception:
        return None
    hdr = {k: v for k, v in (headers or {}).items() if k.lower() != "user-agent"}
    async with AsyncSession(impersonate="chrome") as sess:
        r = await sess.request(method, url, params=params, headers=hdr or None, json=json, data=data, timeout=timeout or 25, allow_redirects=True)
    if r.status_code >= 400:
        raise HttpError(r.status_code, url)
    return r


def _key(url):
    p = urlparse(url)
    return p.netloc + p.path


async def fetch(url, params=None, headers=None, retries=2, method="GET", json=None, data=None, timeout=None, quiet=False):
    """GET/POST dengan retry. quiet=True: kegagalan tidak dicatat sebagai masalah host (dipakai saat mencoba beberapa URL kandidat)."""
    host = urlparse(url).netloc
    ukey = _key(url)
    if health.is_disabled(ukey):
        raise HttpError(410, url + " (dinonaktifkan sementara)")
    last = None
    for attempt in range(retries + 1):
        try:
            async with _sem(host):
                kw = {}
                if timeout:
                    kw["timeout"] = timeout
                r = await client().request(method, url, params=params, headers=headers, json=json, data=data, **kw)
            if r.status_code in (429, 500, 502, 503, 504) and attempt < retries:
                await asyncio.sleep(1.2 * (attempt + 1))
                continue
            r.raise_for_status()
            health.host_ok(host)
            _strikes.pop(ukey, None)
            return r
        except Exception as exc:
            last = exc
            if _status(exc) in _PERMANENT:
                break  # URL mati: retry tidak berguna
            if attempt < retries:
                await asyncio.sleep(0.8 * (attempt + 1))
    # Percobaan terakhir: sidik jari TLS Chrome (hanya untuk penolakan anti-bot / koneksi diputus, bukan timeout koneksi)
    st = _status(last)
    transport = isinstance(last, (httpx.ReadError, httpx.RemoteProtocolError, httpx.ReadTimeout, httpx.WriteError))
    if st in _IMPERSONATE_STATUS or transport:
        try:
            r = await _impersonated(method, url, params, headers, json, data, timeout)
            if r is not None:
                health.host_ok(host, via="tls-chrome")
                _strikes.pop(ukey, None)
                return r
        except Exception as exc:
            last = exc
            st = _status(exc) or st
    # Circuit breaker: URL yang terus 404/410/403 dinonaktifkan sementara agar tidak mengotori status dan membuang waktu.
    if st in _PERMANENT or st in (401, 403):
        n = _strikes[ukey] = _strikes.get(ukey, 0) + 1
        if n >= STRIKES_TO_DISABLE:
            health.disable(ukey, f"HTTP {st} berulang", 6 * 3600 if st in _PERMANENT else 3600)
            _strikes.pop(ukey, None)
    if not quiet:
        health.host_fail(host, last, url)
    raise last


async def get_json(url, **kw):
    r = await fetch(url, **kw)
    return r.json()


async def get_text(url, **kw):
    r = await fetch(url, **kw)
    return r.text


def _name(fn):
    return f"{fn.__module__.rsplit('.', 1)[-1]}.{fn.__name__}"


def _ckey(fn, key, args, kwargs):
    # Penting: kunci memuat modul. Sebelumnya hanya __qualname__, sehingga fiscal.overview()
    # dan rates.overview() berbagi satu entri cache dan saling menimpa hasil.
    return (key or f"{fn.__module__}.{fn.__qualname__}", args, tuple(sorted(kwargs.items())))


def _disk_key(k):
    return hashlib.sha1(repr(k).encode()).hexdigest()


def _changed(old, new):
    try:
        return bool(old != new)
    except Exception:
        return True


async def _disk_load(k):
    from . import store
    try:
        return await asyncio.to_thread(store.cache_get, _disk_key(k))
    except Exception:
        return None


def _prune_cache():
    if len(_cache) <= MAX_CACHE_KEYS:
        return
    drop = max(1, len(_cache) - MAX_CACHE_KEYS + MAX_CACHE_KEYS // 10)
    for k, _ in sorted(_cache.items(), key=lambda kv: kv[1][0])[:drop]:
        _cache.pop(k, None)
    if len(_locks) > MAX_LOCKS:
        for k in [k for k, lk in _locks.items() if not lk.locked()][: len(_locks) - MAX_LOCKS]:
            _locks.pop(k, None)


def _put(k, val, persist):
    old = _cache.get(k)
    ts = time.time()
    _cache[k] = (ts, val)
    _prune_cache()
    if old is None or _changed(old[1], val):
        bump()
    if persist:
        from . import store
        t = asyncio.get_running_loop().run_in_executor(None, store.cache_set, _disk_key(k), ts, val)
        _bg.add(t)
        t.add_done_callback(_bg.discard)


def cached(ttl, key=None, stale_on_error=True, persist=False, stale_ok=None):
    """Cache hasil coroutine.

    - Kunci cache menyertakan nama modul (bug tabrakan kunci sudah diperbaiki).
    - stale-while-revalidate: data kedaluwarsa tetap langsung dikembalikan sambil disegarkan di latar belakang
      (selama umurnya < stale_ok), sehingga pindah menu tidak menunggu sumber lambat.
    - persist=True: disimpan di SQLite sehingga data tetap ada setelah bot restart.
    - Jika sumber error, nilai lama (seberapa pun umurnya) dikembalikan.
    """
    def deco(fn):
        name = _name(fn)
        max_stale = stale_ok if stale_ok is not None else (7 * 86400 if persist else ttl * 3)

        async def _compute(k, a, kw, force=False):
            lock = _locks.setdefault(k, asyncio.Lock())
            async with lock:
                hit = _cache.get(k)
                if hit and time.time() - hit[0] < (min(ttl, FORCE_MAX_AGE) if force else ttl):
                    return hit[1]
                try:
                    val = await fn(*a, **kw)
                except Exception as exc:
                    health.func_fail(name, exc)
                    if stale_on_error and hit:
                        return hit[1]
                    raise
                health.func_ok(name)
                _put(k, val, persist)
                return val

        async def _refresh(k, a, kw):
            try:
                await _compute(k, a, kw)
            except Exception:
                pass
            finally:
                _inflight.discard(k)

        @functools.wraps(fn)
        async def wrapper(*args, **kwargs):
            k = _ckey(fn, key, args, kwargs)
            now = time.time()
            hit = _cache.get(k)
            if hit is None and persist:
                disk = await _disk_load(k)
                if disk:
                    hit = _cache[k] = (disk[0], disk[1])
            if hit:
                age = now - hit[0]
                if _force.get():
                    if age < min(ttl, FORCE_MAX_AGE):
                        return hit[1]
                    return await _compute(k, args, kwargs, force=True)
                if age < ttl:
                    return hit[1]
                if age < max_stale:
                    if k not in _inflight:
                        _inflight.add(k)
                        t = asyncio.create_task(_refresh(k, args, kwargs))
                        _bg.add(t)
                        t.add_done_callback(_bg.discard)
                    return hit[1]
            return await _compute(k, args, kwargs, force=_force.get())
        wrapper._ttl = ttl
        return wrapper
    return deco


def clear_cache():
    _cache.clear()
    _inflight.clear()
