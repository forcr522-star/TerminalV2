"""Akses website lewat kunci akses (tanpa akun pihak ketiga), dengan DUA peran.

URL tunnel Cloudflare bersifat publik, jadi website dijaga kunci akses. Ada dua kunci:
  - ADMIN_KEY (developer): akses penuh. Mengontrol bot sinyal dan melihat halaman INSIDE/ANALISIS + status sumber data.
  - USER_KEY (pengguna biasa): menu SIGNAL hanya-baca (chart, list pair, order). Tidak ada kontrol, tidak ada isi analisa bot, tidak ada peringatan sumber masalah.
  Keduanya diatur lewat .env. Bila kosong dibuat acak sekali dan disimpan di data/ (admin: access_key.txt, user: user_key.txt).
  - URL yang dicetak saat start sudah memuat kunci: https://xxxx.trycloudflare.com/?key=...
    Buka sekali -> server memasang cookie sesi (HttpOnly) berisi peran, lalu menghapus kunci dari alamat. Kunjungan berikutnya
    dari browser yang sama tidak perlu kunci lagi.
  - ACCESS_KEY=none (atau ADMIN_KEY=none) mematikan penjagaan: siapa pun yang tahu alamat masuk sebagai admin.
Cookie berisi HMAC dari kunci (berbeda untuk tiap peran), bukan kunci itu sendiri.
"""
import hashlib
import html
import hmac
import secrets
from . import config

COOKIE = "terminal_session"
HEADER = "x-access-key"
ADMIN, USER = "admin", "user"
DEV_NO_AUTH = config.DEV_NO_AUTH
_cache = {}


def _admin_setting():
    return (config.ADMIN_KEY or config.ACCESS_KEY or "").strip()


def enabled():
    if DEV_NO_AUTH or config.DEV_NO_AUTH:
        return False
    return _admin_setting().lower() != "none"


def _file_key(name):
    """Kunci acak yang disimpan di data/<name> (dibuat bila belum ada)."""
    path = config.DATA_DIR / name
    hit = _cache.get(str(path))
    if hit:
        return hit
    key = ""
    try:
        key = path.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    if not key:
        key = secrets.token_urlsafe(18)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(key + "\n", encoding="utf-8")
        except Exception:
            pass  # tidak bisa menulis: kunci hanya berlaku selama proses ini
    _cache[str(path)] = key
    return key


def access_key():
    """Kunci ADMIN aktif: ADMIN_KEY, atau ACCESS_KEY lama, atau file data/access_key.txt (dibuat bila belum ada)."""
    s = _admin_setting()
    if s and s.lower() != "none":
        return s
    return _file_key("access_key.txt")


admin_key = access_key


def user_key_conflict():
    """True bila USER_KEY di .env sama dengan kunci admin (tidak boleh: kunci itu akan memberi akses admin)."""
    u = config.USER_KEY
    return bool(u) and u.lower() != "none" and hmac.compare_digest(u, access_key())


def user_key_disabled():
    return config.USER_KEY.lower() == "none"


def user_key():
    """Kunci USER aktif ('' bila dimatikan dengan USER_KEY=none). USER_KEY yang sama dengan kunci admin diabaikan -> kunci acak."""
    if user_key_disabled():
        return ""
    u = config.USER_KEY
    if u and not user_key_conflict():
        return u
    return _file_key("user_key.txt")


def _token(key, label):
    return hmac.new(key.encode(), label, hashlib.sha256).hexdigest()


def session_token(role=ADMIN):
    if role == USER:
        return _token(user_key(), b"terminal-session-user-v1")
    return _token(access_key(), b"terminal-session-v1")


def role_for_key(candidate):
    """'admin' / 'user' / None untuk kunci yang diketik."""
    if not candidate:
        return None
    c = str(candidate)
    if hmac.compare_digest(c, access_key()):
        return ADMIN
    uk = user_key()
    if uk and hmac.compare_digest(c, uk):
        return USER
    return None


def check_key(candidate):
    return role_for_key(candidate) is not None


def role_for_cookie(value):
    if not value:
        return None
    v = str(value)
    if hmac.compare_digest(v, session_token(ADMIN)):
        return ADMIN
    if user_key() and hmac.compare_digest(v, session_token(USER)):
        return USER
    return None


def check_cookie(value):
    return role_for_cookie(value) is not None


def role_of(cookies=None, headers=None):
    """Peran permintaan: 'admin' / 'user' / None (ditolak). Penjagaan mati -> 'admin'."""
    if not enabled():
        return ADMIN
    cookies, headers = cookies or {}, headers or {}
    return role_for_cookie(cookies.get(COOKIE)) or role_for_key(headers.get(HEADER))


def authorize(cookies=None, headers=None):
    """True bila permintaan membawa cookie sesi yang sah atau header x-access-key yang benar (peran apa pun)."""
    return role_of(cookies, headers) is not None


def login_page(error=False):
    msg = '<p class="e">Kunci salah. Coba lagi.</p>' if error else ""
    name, title = html.escape(config.TERMINAL_NAME), html.escape(config.TERMINAL_NAME.upper())
    return f"""<!doctype html><html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#07090c">
<title>{name}</title>
<style>
@font-face{{font-family:"IBM Plex Sans Condensed";font-weight:400;src:url(/vendor/fonts/plex-cond-400.woff2) format("woff2");font-display:swap}}
@font-face{{font-family:"IBM Plex Sans Condensed";font-weight:600;src:url(/vendor/fonts/plex-cond-600.woff2) format("woff2");font-display:swap}}
@font-face{{font-family:"IBM Plex Mono";font-weight:400;src:url(/vendor/fonts/plex-mono-400.woff2) format("woff2");font-display:swap}}
html,body{{margin:0;height:100%;color:#e8e3d6;font:14px/1.5 "IBM Plex Sans Condensed","Arial Narrow",system-ui,sans-serif;
  background:radial-gradient(700px 400px at 50% 0%,rgba(240,169,46,.10),transparent 65%),
  linear-gradient(rgba(255,255,255,.02) 1px,transparent 1px) 0 0/32px 32px,linear-gradient(90deg,rgba(255,255,255,.02) 1px,transparent 1px) 0 0/32px 32px,#07090c}}
body{{display:flex;align-items:center;justify-content:center}}
form{{width:min(360px,88vw);padding:28px 26px 24px;border:1px solid #252e3b;border-radius:16px;background:linear-gradient(180deg,#131922,#0d1117 180px);
  box-shadow:0 40px 90px -30px #000,inset 0 1px 0 rgba(255,255,255,.05)}}
.mk{{display:flex;align-items:center;gap:12px;margin-bottom:16px;color:#f0a92e}}
.mk svg{{width:34px;height:34px}}
h1{{margin:0;font-size:17px;font-weight:600;letter-spacing:.24em;color:#e8e3d6}}
small{{display:block;font-size:9.5px;letter-spacing:.2em;color:#5d6371;margin-top:3px}}
p{{margin:0 0 16px;color:#8d919c;font-size:12.5px}}
input{{width:100%;box-sizing:border-box;padding:11px 12px;border:1px solid #252e3b;border-radius:9px;background:#090c10;color:#e8e3d6;font:14px "IBM Plex Mono",monospace;letter-spacing:.08em}}
input:focus{{outline:0;border-color:rgba(240,169,46,.7);box-shadow:0 0 0 3px rgba(240,169,46,.14)}}
button{{margin-top:12px;width:100%;padding:11px;border:0;border-radius:9px;background:#f0a92e;color:#1a1206;font:600 13px "IBM Plex Sans Condensed",sans-serif;letter-spacing:.16em;cursor:pointer;box-shadow:0 10px 24px -10px rgba(240,169,46,.7)}}
button:hover{{background:#ffcf7a}}
.e{{color:#ff8f9a;background:rgba(255,91,107,.1);border:1px solid rgba(255,91,107,.3);border-radius:8px;padding:7px 10px}}
</style></head><body>
<form method="get" action="/"><div class="mk"><svg viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="13" stroke="currentColor" stroke-opacity=".35" stroke-width="1.4"/><path d="M16 3a13 13 0 0 1 13 13" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M8.5 19.5l4.2-5 3.6 3 6.2-7.2" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><circle cx="22.5" cy="10.3" r="1.6" fill="currentColor"/></svg><div><h1>{title}</h1><small>MACRO · FLOW · SIGNAL</small></div></div>
<p>Masukkan kunci akses. Kunci admin &amp; user diatur di .env (ADMIN_KEY / USER_KEY) dan tercetak di jendela tempat program dijalankan.</p>{msg}
<input name="key" type="password" autocomplete="current-password" autofocus placeholder="Kunci akses"><button type="submit">MASUK</button></form>
</body></html>"""
