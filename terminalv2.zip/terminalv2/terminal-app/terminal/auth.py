"""Akses website lewat kunci akses (tanpa akun pihak ketiga), dengan DUA peran.

URL tunnel Cloudflare bersifat publik, jadi website dijaga kunci akses. Ada dua kunci:
  - ADMIN_KEY (developer): akses penuh. Mengontrol bot sinyal dan melihat halaman INSIDE/ANALISIS + status sumber data.
  - USER_KEY (pengguna biasa): menu SIGNAL hanya-baca (chart, list pair, order). Tidak ada kontrol, tidak ada isi analisa bot, tidak ada peringatan sumber masalah.
  Keduanya diatur lewat .env. Bila kosong dibuat acak sekali dan disimpan di data/ (admin: access_key.txt, user: user_key.txt).
  - URL yang dicetak saat start sudah memuat kunci: https://xxxx.trycloudflare.com/?key=...
    Buka sekali -> server memasang cookie sesi (HttpOnly) berisi peran, lalu menghapus kunci dari alamat. Kunjungan berikutnya
    dari browser yang sama tidak perlu kunci lagi.
  - ACCESS_KEY=none (atau ADMIN_KEY=none) mematikan penjagaan: siapa pun yang tahu alamat masuk sebagai admin.
Cookie berisi HMAC dari kunci (berbeda untuk tiap peran), bukan kunci itu sendiri.
"""
import hashlib
import hmac
import secrets
from . import config

COOKIE = "terminal_session"
HEADER = "x-access-key"
ADMIN, USER = "admin", "user"
DEV_NO_AUTH = config.DEV_NO_AUTH
_cache = {}


def _admin_setting():
    return (config.ADMIN_KEY or config.ACCESS_KEY or "").strip()


def enabled():
    if DEV_NO_AUTH or config.DEV_NO_AUTH:
        return False
    return _admin_setting().lower() != "none"


def _file_key(name):
    """Kunci acak yang disimpan di data/<name> (dibuat bila belum ada)."""
    path = config.DATA_DIR / name
    hit = _cache.get(str(path))
    if hit:
        return hit
    key = ""
    try:
        key = path.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    if not key:
        key = secrets.token_urlsafe(18)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(key + "\n", encoding="utf-8")
        except Exception:
            pass  # tidak bisa menulis: kunci hanya berlaku selama proses ini
    _cache[str(path)] = key
    return key


def access_key():
    """Kunci ADMIN aktif: ADMIN_KEY, atau ACCESS_KEY lama, atau file data/access_key.txt (dibuat bila belum ada)."""
    s = _admin_setting()
    if s and s.lower() != "none":
        return s
    return _file_key("access_key.txt")


admin_key = access_key


def user_key_conflict():
    """True bila USER_KEY di .env sama dengan kunci admin (tidak boleh: kunci itu akan memberi akses admin)."""
    u = config.USER_KEY
    return bool(u) and u.lower() != "none" and hmac.compare_digest(u, access_key())


def user_key_disabled():
    return config.USER_KEY.lower() == "none"


def user_key():
    """Kunci USER aktif ('' bila dimatikan dengan USER_KEY=none). USER_KEY yang sama dengan kunci admin diabaikan -> kunci acak."""
    if user_key_disabled():
        return ""
    u = config.USER_KEY
    if u and not user_key_conflict():
        return u
    return _file_key("user_key.txt")


def _token(key, label):
    return hmac.new(key.encode(), label, hashlib.sha256).hexdigest()


def session_token(role=ADMIN):
    if role == USER:
        return _token(user_key(), b"terminal-session-user-v1")
    return _token(access_key(), b"terminal-session-v1")


def role_for_key(candidate):
    """'admin' / 'user' / None untuk kunci yang diketik."""
    if not candidate:
        return None
    c = str(candidate)
    if hmac.compare_digest(c, access_key()):
        return ADMIN
    uk = user_key()
    if uk and hmac.compare_digest(c, uk):
        return USER
    return None


def check_key(candidate):
    return role_for_key(candidate) is not None


def role_for_cookie(value):
    if not value:
        return None
    v = str(value)
    if hmac.compare_digest(v, session_token(ADMIN)):
        return ADMIN
    if user_key() and hmac.compare_digest(v, session_token(USER)):
        return USER
    return None


def check_cookie(value):
    return role_for_cookie(value) is not None


def role_of(cookies=None, headers=None):
    """Peran permintaan: 'admin' / 'user' / None (ditolak). Penjagaan mati -> 'admin'."""
    if not enabled():
        return ADMIN
    cookies, headers = cookies or {}, headers or {}
    return role_for_cookie(cookies.get(COOKIE)) or role_for_key(headers.get(HEADER))


def authorize(cookies=None, headers=None):
    """True bila permintaan membawa cookie sesi yang sah atau header x-access-key yang benar (peran apa pun)."""
    return role_of(cookies, headers) is not None


def login_page(error=False):
    msg = '<p class="e">Kunci salah. Coba lagi.</p>' if error else ""
    name = config.TERMINAL_NAME
    return f"""<!doctype html><html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0b0d12">
<title>{name}</title>
<style>
html,body{{margin:0;height:100%;background:#0b0d12;color:#d7dbe6;font:14px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}}
body{{display:flex;align-items:center;justify-content:center}}
form{{width:min(340px,88vw);padding:24px;border:1px solid #2a3042;border-radius:10px;background:#11151d}}
h1{{margin:0 0 4px;font-size:16px;letter-spacing:.12em}}p{{margin:0 0 14px;color:#8b93a7;font-size:12px}}
input{{width:100%;box-sizing:border-box;padding:10px;border:1px solid #2a3042;border-radius:6px;background:#0b0d12;color:#d7dbe6;font:inherit}}
button{{margin-top:12px;width:100%;padding:10px;border:0;border-radius:6px;background:#2563eb;color:#fff;font:inherit;cursor:pointer}}
.e{{color:#ef4444}}
</style></head><body>
<form method="get" action="/"><h1>{name.upper()}</h1><p>Masukkan kunci akses. Kunci admin &amp; user diatur di .env (ADMIN_KEY / USER_KEY) dan tercetak di jendela tempat program dijalankan.</p>{msg}
<input name="key" type="password" autocomplete="current-password" autofocus placeholder="Kunci akses"><button type="submit">Masuk</button></form>
</body></html>"""
