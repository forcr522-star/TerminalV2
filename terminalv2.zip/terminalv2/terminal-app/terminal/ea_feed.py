"""Feed sinyal untuk EA MetaTrader 5 (TerminalSignalEA.mq5) — dipakai banyak pengguna sekaligus.

GET /api/ea/feed   (header  X-Access-Key: <kunci USER atau ADMIN>)
  - teks ringkas (bukan JSON) supaya mudah & andal diurai di MQL5; satu baris per sinyal, kolom dipisah '|'
  - dibangun SEKALI tiap TTL detik untuk semua pengguna, dengan ETag -> EA yang tidak ada perubahan menerima 304 (hampir 0 byte)
  - berisi sinyal AKTIF (PENDING / OPEN) kedua strategi + sinyal yang SELESAI/BATAL dalam KEEP_CLOSED detik terakhir
    (agar EA bisa menghapus limit order yang dibatalkan server)
  - jurnal hanya DIBACA; logika strategi (10 METODE & STRATEGI ONE) tidak disentuh

Format v1
  TSIG|1|<waktu_server_epoch>|<jumlah_sinyal>
  S|uid|strat|sym|side|status|created|expiry|e1|f1|e2|f2|sl|tp1|tp2|tp3|c1|c2|c3|be|beoff|cut2|ref|refts|r|hold
    uid      M<id> (10 METODE) / O<id> (STRATEGI ONE) — unik & tetap
    strat    MULTI / ONE
    sym      nama pair di terminal (EURUSD, Gold, US500, Bitcoin, ...) -> EA memetakan ke simbol broker
    side     BUY / SELL
    status   PENDING, OPEN, atau status akhir (TP1, TP2, TPMAX, SL, TIME, CANCEL, EXPIRED, MISSED, NOFILL)
    created  epoch UTC sinyal terbit (bar keputusan tutup)
    expiry   epoch UTC: limit yang belum terisi sampai waktu ini wajib dibatalkan
    e1,f1    harga entry kaki 1 & porsi volume rencana; e2,f2 kaki 2 (10 METODE: 0,0)
    sl       stop loss (sama untuk semua kaki)
    tp1..3   target; 0 = tidak dipakai. TP terakhir yang bukan 0 = TP akhir (dipasang di broker)
    c1..3    porsi volume TERBUKA yang ditutup saat TPk tersentuh (1 = tutup semua)
    be       1 = sesudah TP1, SL dipindah ke rata-rata harga entry (+beoff searah posisi)
    beoff    offset harga breakeven (STRATEGI ONE: 0,05 ATR)
    cut2     1 = sesudah TP1, limit kaki 2 yang belum terisi dihapus
    ref      harga acuan server saat feed dibuat (EA mengoreksi selisih harga broker vs sumber data)
    refts    epoch harga acuan
    r        hasil R (sinyal selesai), selain itu 0
    hold     detik maksimum posisi ditahan sejak terisi, lalu sisa ditutup (10 METODE: max_hold bar; 0 = tanpa batas waktu)
  Kolom baru hanya akan DITAMBAHKAN di belakang (EA lama tetap bisa membaca).
"""
import asyncio
import hashlib
import json
import time

import pandas as pd

from . import store
from .signals.config import MODES
from .universe import BY_SYM

VERSION = 1
TTL = 3.0
KEEP_CLOSED = 6 * 3600
_cache = dict(at=0.0, body=b"", etag='"0"', n=0)
_lock = asyncio.Lock()


def _f(x):
    """Angka ringkas tanpa kehilangan presisi harga (repr float), kosong/None -> 0."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "0"
    if v != v:
        return "0"
    s = repr(v)
    return s[:-2] if s.endswith(".0") else s


def _epoch(bar_ts):
    """bar_ts jurnal ('2026-11-27 13:00:00', UTC tanpa zona) -> epoch UTC."""
    try:
        t = pd.Timestamp(bar_ts)
        return int((t.tz_convert(None) if t.tzinfo else t).timestamp())
    except Exception:
        return 0


def _plan(row):
    p = row.get("plan")
    if isinstance(p, dict):
        return p
    try:
        return json.loads(p or "{}")
    except Exception:
        return {}


def multi_line(row, ref=None, refts=0):
    """Baris feed untuk sinyal 10 METODE (satu limit order; TP bertahap TP1/TP2/TP MAX; BE opsional)."""
    pl = _plan(row)
    tp = list(pl.get("tp") or []) + [0, 0, 0]
    w = list(pl.get("w") or (0.4, 0.3, 0.3))
    mins = MODES.get(row.get("mode") or "intraday", MODES["intraday"])["minutes"]
    issued = _epoch(row.get("bar_ts")) + mins * 60
    expiry = issued + int(pl.get("expiry") or 0) * mins * 60
    c1 = w[0]
    c2 = (w[1] / max(1e-9, 1.0 - w[0])) if len(w) > 1 else 1.0
    side = row.get("side") or ("BUY" if (pl.get("d") or 1) > 0 else "SELL")
    r = row.get("r") if row.get("status") not in ("PENDING", "OPEN") else 0
    f = ["S", f"M{row['id']}", "MULTI", row["sym"], side, row["status"], str(int(row.get("created") or issued)), str(expiry),
         _f(pl.get("entry")), "1", "0", "0", _f(pl.get("sl")), _f(tp[0]), _f(tp[1]), _f(tp[2]),
         _f(round(c1, 4)), _f(round(min(1.0, c2), 4)), "1", "1" if row.get("be") else "0", "0", "0",
         _f(ref), str(int(refts or 0)), _f(r), str(int(pl.get("max_hold") or 0) * mins * 60)]
    return "|".join(f)


def one_line(row, ref=None, refts=0):
    """Baris feed untuk STRATEGI ONE (dua limit E1/E2; TP1 tutup 50% volume terbuka + SL ke rata-rata entry + 0,05 ATR,
    limit E2 yang belum terisi dihapus; sisa ke TP2). Nilai diambil dari rencana di jurnal (aturan strategi tidak diubah)."""
    from .signals.one.params import PARAMS                       # hanya dibaca
    pl = _plan(row)
    mins = int(pl.get("tf_minutes") or MODES.get(row.get("mode") or "scalp", MODES["scalp"])["minutes"])
    issued = int(pl.get("created_ts") or 0) + mins * 60
    expiry = issued + int(pl.get("expiry_bars") or PARAMS["Pending_Expiry_Bars"]) * mins * 60
    lots = pl.get("lots") or {}
    split = float(PARAMS.get("Ladder_Lot_Split", 0.5))
    f1, f2 = (1.0, 0.0) if lots.get("only_e1") else (split, 1.0 - split)
    beoff = PARAMS["BE_Offset_ATR"] * float(pl.get("atr") or 0.0)
    r = row.get("r") if row.get("status") not in ("PENDING", "OPEN") else 0
    f = ["S", f"O{row['id']}", "ONE", row["sym"], row.get("side") or pl.get("side") or "BUY", row["status"], str(int(row.get("created") or issued)), str(expiry),
         _f(pl.get("E1")), _f(f1), _f(pl.get("E2") if f2 else 0), _f(f2), _f(pl.get("SL")), _f(pl.get("TP1")), _f(pl.get("TP2")), "0",
         _f(PARAMS["TP1_Close_Fraction"]), "1", "0", "1", _f(beoff), "1", _f(ref), str(int(refts or 0)), _f(r), "0"]
    return "|".join(f)


def rows(now=None):
    """(baris 10 METODE, baris STRATEGI ONE) yang aktif atau selesai dalam KEEP_CLOSED detik."""
    now = now or time.time()
    cut = now - KEEP_CLOSED
    m = store.query("SELECT * FROM signal_log WHERE status IN ('PENDING','OPEN') OR (closed IS NOT NULL AND closed > ?) ORDER BY id", (cut,))
    try:
        o = store.query("SELECT * FROM one_log WHERE status IN ('PENDING','OPEN') OR (closed IS NOT NULL AND closed > ?) ORDER BY id", (cut,))
    except Exception:
        o = []
    return m, o


def render(multi, one, refs, now=None):
    now = now or time.time()
    lines = []
    for r in multi:
        ref, ts = refs.get(r["sym"], (None, 0))
        lines.append(multi_line(r, ref, ts))
    for r in one:
        ref, ts = refs.get(r["sym"], (None, 0))
        lines.append(one_line(r, ref, ts))
    head = f"TSIG|{VERSION}|{int(now)}|{len(lines)}"
    return ("\n".join([head] + lines) + "\n").encode("utf-8")


async def _refs(syms):
    """Harga acuan server (sumber yang sama dengan analisa) untuk pair yang ada di feed."""
    if not syms:
        return {}
    from .providers import yahoo
    ys = tuple(sorted({BY_SYM[s.upper()]["y"] for s in syms if s.upper() in BY_SYM}))
    try:
        q = await asyncio.wait_for(yahoo.quotes(ys), 8)
        _, ts = yahoo.quotes.peek(ys)
    except Exception:
        return {}
    out = {}
    for s in syms:
        a = BY_SYM.get(s.upper())
        p = (q.get(a["y"]) or {}).get("price") if a else None
        if p:
            out[s] = (float(p), int(ts or time.time()))
    return out


async def build(now=None):
    now = now or time.time()
    multi, one = await asyncio.to_thread(rows, now)
    syms = sorted({r["sym"] for r in multi + one if r["status"] in ("PENDING", "OPEN")})
    refs = await _refs(syms)
    body = render(multi, one, refs, now)
    # ETag dari isi tanpa waktu server (baris pertama) -> EA menerima 304 selama sinyal & harga acuan tidak berubah
    etag = '"' + hashlib.sha1(body.split(b"\n", 1)[1]).hexdigest()[:20] + '"'
    return body, etag, len(multi) + len(one)


async def get():
    """Feed terbaru (dibangun ulang paling sering tiap TTL detik; permintaan serentak berbagi satu pembangunan)."""
    if time.time() - _cache["at"] < TTL:
        return _cache["body"], _cache["etag"]
    async with _lock:
        if time.time() - _cache["at"] < TTL:
            return _cache["body"], _cache["etag"]
        try:
            body, etag, n = await build()
            _cache.update(at=time.time(), body=body, etag=etag, n=n)
        except Exception:
            if not _cache["body"]:
                raise
            _cache["at"] = time.time() - TTL / 2                  # sumber sementara gagal: pakai feed terakhir
    return _cache["body"], _cache["etag"]
