"""Thread pool untuk kerja sinkron, dipisah menurut lamanya.

Masalah yang diperbaiki ("sumber bermasalah" ConnectTimeout serentak di banyak host sehat):
  httpx/anyio melakukan resolusi DNS setiap koneksi baru lewat `loop.getaddrinfo`, yang berjalan di thread pool
  BAWAAN event loop. Pool itu juga dipakai semua `asyncio.to_thread` - termasuk unduhan yfinance dan permintaan
  TLS Chrome (curl_cffi) yang bisa menahan satu thread hingga 25 dtk. Ukuran bawaannya min(32, jumlah_core + 4):
  di RDP 2 core hanya 6 thread. Begitu 6 unduhan panjang berjalan, DNS untuk BBC, Al Jazeera, FRED, dst. ikut antre
  dan batas connect 10 dtk habis sebelum koneksi dimulai -> belasan sumber "ConnectTimeout" bersamaan.

Perbaikan:
  - pool bawaan diperbesar (64 thread) -> DNS & kerja singkat (parse, baca/tulis DB) selalu dapat thread;
  - panggilan JARINGAN sinkron yang lama (yfinance, curl_cffi, Web Push) memakai pool sendiri `net()`,
    sehingga tidak pernah lagi menghabiskan pool bawaan.
"""
import asyncio
import concurrent.futures as cf
import contextvars
import functools
import os

DEFAULT_WORKERS = max(32, int(os.getenv("IO_THREADS", "64") or 64))
NET_WORKERS = max(4, int(os.getenv("NET_THREADS", "16") or 16))
_net_pool = None
_installed = set()


def install(loop=None):
    """Pasang pool bawaan yang lebih besar pada event loop ini (aman dipanggil berkali-kali)."""
    loop = loop or asyncio.get_running_loop()
    if id(loop) in _installed:
        return
    loop.set_default_executor(cf.ThreadPoolExecutor(max_workers=DEFAULT_WORKERS, thread_name_prefix="io"))
    _installed.add(id(loop))


def _pool():
    global _net_pool
    if _net_pool is None:
        _net_pool = cf.ThreadPoolExecutor(max_workers=NET_WORKERS, thread_name_prefix="net")
    return _net_pool


async def net(fn, *args, **kwargs):
    """Seperti asyncio.to_thread, tetapi untuk panggilan jaringan sinkron yang lama (pool terpisah dari DNS)."""
    ctx = contextvars.copy_context()
    return await asyncio.get_running_loop().run_in_executor(_pool(), functools.partial(ctx.run, fn, *args, **kwargs))
