"""Thread pool untuk kerja sinkron, dipisah menurut lamanya.

Masalah yang diperbaiki ("sumber bermasalah" ConnectTimeout serentak di banyak host sehat):
  httpx/anyio melakukan resolusi DNS setiap koneksi baru lewat `loop.getaddrinfo`, yang berjalan di thread pool
  BAWAAN event loop. Pool itu juga dipakai semua `asyncio.to_thread` - termasuk unduhan yfinance dan permintaan
  TLS Chrome (curl_cffi) yang bisa menahan satu thread hingga 25 dtk. Ukuran bawaannya min(32, jumlah_core + 4):
  di RDP 2 core hanya 6 thread. Begitu 6 unduhan panjang berjalan, DNS untuk BBC, Al Jazeera, FRED, dst. ikut antre
  dan batas connect 10 dtk habis sebelum koneksi dimulai -> belasan sumber "ConnectTimeout" bersamaan.

Perbaikan:
  - pool bawaan diperbesar (64 thread) -> DNS & kerja singkat (parse, baca/tulis DB) selalu dapat thread;
  - panggilan JARINGAN sinkron yang lama (yfinance, curl_cffi, Web Push) memakai pool sendiri `net()`,
    sehingga tidak pernah lagi menghabiskan pool bawaan.

Masalah kedua (watchdog di Windows/RDP, Python 3.11: "server tertahan 25.9 dtk - threading.py:320 wait <- ...
getaddrinfo" dan "28.7 dtk - futures/thread.py:162 submit"): ThreadPoolExecutor membuat thread SAAT DIBUTUHKAN, di
dalam submit(), sambil memegang kunci global modul (_global_shutdown_lock) lalu MENUNGGU thread baru itu berjalan.
Thread baru butuh GIL untuk mulai; saat preload membuat CPU sibuk, itu bisa puluhan detik - dan selama itu setiap
submit() di proses (termasuk dari event loop: DNS, to_thread, parse) ikut menunggu kunci yang sama. Perbaikan:
  - SEMUA pool dibuat lengkap saat start (`prestart`), ketika CPU masih senggang -> submit() berikutnya tidak pernah
    membuat thread lagi (uji 2 core + 12 thread pengurai JSON: submit terlama 4,5 dtk -> 0 ms);
  - yfinance tidak lagi membuat pool baru di setiap download (lihat `yf_map` dan providers/yahoo.py);
  - di Windows thread event loop diberi prioritas "di atas normal" sehingga OS menjadwalkannya lebih dulu saat GIL
    dilepas (`MAIN_THREAD_BOOST=0` mematikannya).
"""
import asyncio
import concurrent.futures as cf
import contextvars
import functools
import os
import threading
import weakref

DEFAULT_WORKERS = max(32, int(os.getenv("IO_THREADS", "64") or 64))
NET_WORKERS = max(4, int(os.getenv("NET_THREADS", "16") or 16))
YF_WORKERS = max(2, int(os.getenv("YF_THREADS", "6") or 6))
_net_pool = None
_yf_pool = None
_installed = set()
_warm = weakref.WeakSet()   # pool yang thread-nya sudah dibuat semua (prestart hanya sekali per pool)
_lock = threading.Lock()
STATUS = dict(prestarted={}, boost=None)


def prestart(ex, n, timeout=10.0):
    """Buat n thread pool `ex` SEKARANG: n tugas kecil yang saling menunggu sampai semuanya berjalan, sehingga
    submit() memang membuat thread baru untuk masing-masing. Sesudahnya semua thread menganggur dan submit() berikutnya
    hanya memasukkan tugas ke antrean. Mengembalikan jumlah thread yang benar-benar berjalan."""
    if ex in _warm:
        return n
    _warm.add(ex)
    gate, up = threading.Event(), threading.Semaphore(0)

    def hold():
        up.release()
        gate.wait(timeout)
    for _ in range(n):
        ex.submit(hold)
    got = sum(1 for _ in range(n) if up.acquire(timeout=timeout))
    gate.set()
    return got


def boost_main_thread():
    """Windows: thread pemanggil (event loop) berprioritas THREAD_PRIORITY_ABOVE_NORMAL. Sistem lain: tidak diubah."""
    if os.name != "nt" or os.getenv("MAIN_THREAD_BOOST", "1").strip() == "0":
        return False
    try:
        import ctypes
        k = ctypes.windll.kernel32
        return bool(k.SetThreadPriority(k.GetCurrentThread(), 1))
    except Exception:
        return False


def install(loop=None):
    """Pasang pool bawaan yang lebih besar pada event loop ini dan buat semua thread pool sekarang (aman dipanggil
    berkali-kali). Dipanggil dari thread event loop."""
    loop = loop or asyncio.get_running_loop()
    if id(loop) in _installed:
        return
    ex = cf.ThreadPoolExecutor(max_workers=DEFAULT_WORKERS, thread_name_prefix="io")
    loop.set_default_executor(ex)
    _installed.add(id(loop))
    if os.getenv("PRESTART_THREADS", "1").strip() != "0":
        from . import cpu
        st = STATUS["prestarted"]
        st["io"] = prestart(ex, DEFAULT_WORKERS)
        st["net"] = prestart(_pool(), NET_WORKERS)
        st["yf"] = prestart(_yf(), YF_WORKERS)
        st["cpu"] = prestart(cpu._executor(), 1)
        st["parse"] = prestart(cpu._parse_executor(), cpu.PARSE_THREADS)
    STATUS["boost"] = boost_main_thread()


ANYIO_WORKERS = max(2, int(os.getenv("ANYIO_THREADS", "8") or 8))


async def prestart_anyio(n=ANYIO_WORKERS, keep=7 * 86400):
    """Starlette melayani berkas statis lewat anyio.to_thread. anyio membuat thread pekerjanya DARI THREAD EVENT LOOP
    saat dibutuhkan (dan menunggu thread itu mulai), lalu membuangnya setelah 10 dtk menganggur - jadi setiap kunjungan
    sesudah sepi membuat thread baru lagi. Di sini n pekerja dibuat sekali saat start dan dibiarkan hidup."""
    try:
        import anyio.to_thread
        from anyio._backends import _asyncio as _ab
        if hasattr(_ab, "WorkerThread"):
            _ab.WorkerThread.MAX_IDLE_TIME = keep
        gate = threading.Event()
        tasks = [asyncio.ensure_future(anyio.to_thread.run_sync(gate.wait, 10)) for _ in range(n)]
        await asyncio.sleep(0.05)
        gate.set()
        await asyncio.gather(*tasks, return_exceptions=True)
        STATUS["prestarted"]["anyio"] = n
    except Exception:
        STATUS["prestarted"]["anyio"] = 0


def _pool():
    global _net_pool
    with _lock:
        if _net_pool is None:
            _net_pool = cf.ThreadPoolExecutor(max_workers=NET_WORKERS, thread_name_prefix="net")
    return _net_pool


def _yf():
    global _yf_pool
    with _lock:
        if _yf_pool is None:
            _yf_pool = cf.ThreadPoolExecutor(max_workers=YF_WORKERS, thread_name_prefix="yf")
    return _yf_pool


def yf_map(fn, items):
    """Jalankan fn(item) paralel di pool yfinance BERSAMA (thread sudah dibuat saat start) dan kembalikan hasilnya
    berurutan. Dipanggil dari thread pool lain (bukan dari pool yf sendiri)."""
    items = list(items)
    if len(items) <= 1:
        return [fn(it) for it in items]
    futs = [_yf().submit(fn, it) for it in items]
    return [f.result() for f in futs]


async def net(fn, *args, **kwargs):
    """Seperti asyncio.to_thread, tetapi untuk panggilan jaringan sinkron yang lama (pool terpisah dari DNS)."""
    ctx = contextvars.copy_context()
    return await asyncio.get_running_loop().run_in_executor(_pool(), functools.partial(ctx.run, fn, *args, **kwargs))
