"""Langkah 4: konfirmasi KUANTITATIF.

Model (semua dalam satuan R = jarak entry-SL):
  1. Peluang empiris tiap metode: posterior Beta-Binomial dari hasil sinyal historis metode itu pada pair/timeframe yang sama,
     dengan prior = campuran peluang acak (1/(1+R1)) dan rata-rata gabungan semua metode (empirical Bayes / shrinkage).
  2. Drift tersirat: dari peluang posterior TP1 dicari drift theta pada gerak Brown berdrift (barrier hitting) yang menghasilkan peluang itu.
  3. Dengan theta itu dihitung peluang TP2/TP MAX/BE secara analitik -> distribusi hasil -> EV (R), varians, Kelly pecahan.
  4. Penyesuaian ulang: SL dan TP1 dicari dari grid kecil yang memaksimalkan EV dengan batas peluang minimum.
  5. Rezim: eksponen Hurst, Variance-Ratio (Lo-MacKinlay), Efficiency Ratio, persentil volatilitas.
"""
import math

import numpy as np

from . import ta
from .config import TP_WEIGHTS


# ----------------------------------------------------------------------------------------- barrier (Brownian motion with drift)
def p_up_first(a, b, th):
    """Peluang menyentuh +a sebelum -b (satuan R), gerak Brown berdrift; th = 2*mu/sigma^2 (1/R). th=0 -> b/(a+b)."""
    if a <= 0:
        return 1.0
    if b <= 0:
        return 0.0
    if abs(th) < 1e-9:
        return b / (a + b)
    try:
        num = 1.0 - math.exp(th * b)
        den = math.exp(-th * a) - math.exp(th * b)
        p = num / den
    except OverflowError:
        p = 1.0 if th > 0 else 0.0
    return min(1.0, max(0.0, p))


def implied_theta(p1, a1, lo=-8.0, hi=8.0):
    """Cari th sehingga p_up_first(a1, 1, th) = p1 (monoton naik terhadap th)."""
    p1 = min(0.995, max(0.005, p1))
    for _ in range(60):
        mid = (lo + hi) / 2
        if p_up_first(a1, 1.0, mid) < p1:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def outcomes(rs, th, be=True, cost_r=0.0, w=TP_WEIGHTS):
    """Distribusi hasil trade: daftar (peluang, R bersih). rs = (R1,R2,R3) kelipatan R dari TP."""
    r1, r2, r3 = rs
    p1 = p_up_first(r1, 1.0, th)
    out = [(1 - p1, -1.0 - cost_r)]
    base1 = w[0] * r1
    if be:
        p21 = p_up_first(r2 - r1, r1, th)       # dari TP1 sebelum kembali ke entry
        p32 = p_up_first(r3 - r2, r2, th)       # dari TP2 sebelum kembali ke entry
        out.append((p1 * (1 - p21), base1 - cost_r))
        out.append((p1 * p21 * (1 - p32), base1 + w[1] * r2 - cost_r))
        out.append((p1 * p21 * p32, base1 + w[1] * r2 + w[2] * r3 - cost_r))
    else:
        q21 = p_up_first(r2 - r1, 1.0 + r1, th)  # SL tetap di -1R
        q32 = p_up_first(r3 - r2, 1.0 + r2, th)
        out.append((p1 * (1 - q21), base1 - (w[1] + w[2]) * 1.0 - cost_r))
        out.append((p1 * q21 * (1 - q32), base1 + w[1] * r2 - w[2] * 1.0 - cost_r))
        out.append((p1 * q21 * q32, base1 + w[1] * r2 + w[2] * r3 - cost_r))
    return out


def moments(outs):
    ev = sum(p * r for p, r in outs)
    var = sum(p * (r - ev) ** 2 for p, r in outs)
    return ev, var


def kelly_risk(outs, cap=0.005, floor=0.0, frac=0.25):
    """Risiko per trade disarankan (pecahan ekuitas): maksimalkan pertumbuhan log E[ln(1 + r*R)] pada distribusi hasil,
    lalu pakai `frac` dari Kelly penuh, dibatasi [floor, cap]. 0 bila EV <= 0.
    Default diubah hasil audit: cap 0,5% dan TANPA floor (floor memaksa overbetting pada edge marginal)."""
    ev = sum(p * r for p, r in outs)
    if ev <= 0:
        return 0.0
    best, bg = 0.0, 0.0
    for k in range(1, 201):
        r = k * 0.001
        if any(1 + r * x <= 0 for _, x in outs):
            break
        g = sum(p * math.log(1 + r * x) for p, x in outs)
        if g > bg:
            best, bg = r, g
    return float(min(cap, max(floor, frac * best))) if best > 0 else 0.0


# ----------------------------------------------------------------------------------------- posterior metode
def baseline_p(r1):
    return 1.0 / (1.0 + r1)


def lcb(mean, sd, n, z=1.0):
    """Lower confidence bound rata-rata R: mean - z*sd/sqrt(n). n=0 -> -inf (tidak ada bukti)."""
    if not n:
        return -float("inf")
    import math as _m
    return float(mean - z * sd / _m.sqrt(max(1, n)))


def posterior(wins, n, r1, pooled=None, strength=12.0):
    """Posterior Beta untuk peluang TP1. Prior: 50% peluang acak + 50% rata-rata gabungan (bila ada)."""
    p0 = baseline_p(r1)
    prior = p0 if pooled is None else 0.5 * p0 + 0.5 * pooled
    a, b = prior * strength, (1 - prior) * strength
    return (a + wins) / (a + b + n)


# ----------------------------------------------------------------------------------------- rezim
def regime(x, i, window=300):
    """Hurst, VR z-stat, ER, persentil ATR pada bar i. Hanya memakai data sampai bar i."""
    lo = max(1, i - window)
    c = x.c[lo - 1: i + 1]
    r = np.diff(np.log(c))
    H = ta.hurst_vr(r)
    vr, z = ta.variance_ratio(r, 4) if len(r) >= 60 else (None, None)
    a = x.atr[max(0, i - 500): i + 1]
    a = a[np.isfinite(a)]
    pr = float((a <= a[-1]).mean()) if len(a) > 20 else 0.5
    if H is None:
        label = "TIDAK CUKUP DATA"
    elif H > 0.55 and (vr or 1) > 1.0:
        label = "TRENDING"
    elif H < 0.45 and (vr or 1) < 1.0:
        label = "MEAN-REVERTING"
    else:
        label = "CAMPURAN"
    return dict(hurst=None if H is None else round(H, 3), vr=None if vr is None else round(vr, 3), vr_z=None if z is None else round(z, 2),
                er=float(x.er[i]) if np.isfinite(x.er[i]) else None, adx=float(x.adx[i]) if np.isfinite(x.adx[i]) else None, atr_pct=round(pr, 2), label=label)


# ----------------------------------------------------------------------------------------- penyesuaian ulang rencana
def refine(entry, sl, tps, d, p1_post, cost, be, atr, pmin=0.52, grid="safe"):
    """Cari (skala SL, kelipatan TP1) dari grid kecil yang memaksimalkan EV bersih dengan peluang TP1 >= pmin.

    Drift tersirat dikalibrasi pada geometri awal. Mengembalikan dict(entry, sl, tp[3], ev, p1, scale_sl, m1, outs)."""
    risk0 = abs(entry - sl)
    r_base = [abs(t - entry) / risk0 for t in tps]
    th = implied_theta(p1_post, r_base[0])
    best = None
    scales, m1s = {"none": ((1.0,), (None,)), "safe": ((1.0, 1.15), (0.6, 0.7, 0.8))}[grid]
    for s in scales:
        risk = risk0 * s
        for m1 in m1s:
            m1 = r_base[0] if m1 is None else m1
            d1 = m1 * risk0
            if d1 < 0.3 * atr:
                continue
            # jarak TP dalam satuan harga dipertahankan, kecuali TP1; TP2/TPMAX tetap relatif terhadap harga awal
            t1 = d1
            t2 = max(abs(tps[1] - entry), t1 + 0.4 * risk)
            t3 = max(abs(tps[2] - entry), t2 + 0.4 * risk)
            rs = (t1 / risk, t2 / risk, t3 / risk)
            outs = outcomes(rs, th, be, cost / risk)
            ev, var = moments(outs)
            p1 = p_up_first(rs[0], 1.0, th)
            if p1 < pmin:
                continue
            score = ev
            if best is None or score > best["ev"] + 1e-9:
                best = dict(ev=ev, var=var, p1=p1, scale_sl=s, m1=m1, rs=rs, outs=outs, risk=risk,
                            sl=entry - d * risk, tp=[entry + d * t1, entry + d * t2, entry + d * t3], th=th)
    if best is None:   # tak ada kombinasi memenuhi pmin: pakai geometri awal
        rs = tuple(r_base)
        outs = outcomes(rs, th, be, cost / risk0)
        ev, var = moments(outs)
        best = dict(ev=ev, var=var, p1=p_up_first(rs[0], 1.0, th), scale_sl=1.0, m1=rs[0], rs=rs, outs=outs, risk=risk0, sl=sl, tp=list(tps), th=th)
    best["entry"] = entry
    return best
