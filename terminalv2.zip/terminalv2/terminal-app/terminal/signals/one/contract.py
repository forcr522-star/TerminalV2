"""Spesifikasi kontrak untuk lot (Bagian 14.2): nilai 1.0 pergerakan harga per 1 lot, dalam mata uang kuotasi.
Sama dengan tabel kalkulator ukuran posisi di website (v_tools.js); bisa berbeda dengan broker Anda."""
SPEC = {
    "Gold": (100, "oz", 1), "Silver": (5000, "oz", 1), "Platinum": (50, "oz", 1), "Palladium": (100, "oz", 1),
    "Copper": (25000, "lb", 1), "Aluminum": (25, "ton", 1), "Crude Oil WTI": (1000, "barel", 1), "Brent Oil": (1000, "barel", 1),
    "Natural Gas": (10000, "MMBtu", 1), "Gasoline": (42000, "galon", 1), "Heating Oil": (42000, "galon", 1),
    "Corn": (5000, "bushel", 0.01), "Wheat": (5000, "bushel", 0.01), "Soybeans": (5000, "bushel", 0.01),
    "Coffee": (37500, "lb", 0.01), "Cotton": (50000, "lb", 0.01), "Sugar": (112000, "lb", 0.01), "Cocoa": (10, "ton", 1),
    "USD Index": (1000, "x indeks", 1),
}
QUOTE_IDX = {"DAX30": "EUR", "EU50": "EUR", "CAC40": "EUR", "AEX": "EUR", "IBEX35": "EUR", "FTSE100": "GBP", "CH20": "CHF", "Nikkei225": "JPY",
             "HK50": "HKD", "CSI1000": "CNY", "SSEC": "CNY", "CSI300": "CNY", "KOSPI": "KRW", "TWII": "TWD", "SENSEX": "INR", "NIFTY50": "INR",
             "ASX200": "AUD", "NZ50": "NZD", "TSX": "CAD", "IDX Composite": "IDR", "IDX LQ45": "IDR", "BOVESPA": "BRL", "STI": "SGD"}


def is_pair(a):
    s = a["sym"]
    return a["cls"] == "FX" and len(s) == 6 and s.isalpha() and s.isupper()


def quote_of(a):
    if is_pair(a):
        return a["sym"][3:]
    if a["cls"] == "INDEX":
        return QUOTE_IDX.get(a["sym"], "USD")
    return "USD"


def spec_of(a):
    """(ukuran kontrak per lot, satuan, skala harga)."""
    if is_pair(a):
        return 100000, a["sym"][:3], 1
    if a["sym"] in SPEC:
        return SPEC[a["sym"]]
    return 1, ("koin" if a["cls"] == "CRYPTO" else "x indeks" if a["cls"] == "INDEX" else "unit"), 1
