"""Strategi ONE - setup A-E, tangga target, validasi, filter, skor, order bertingkat (E1/E2) dan siklus hidupnya.

Engine memutar ulang data bar demi bar (hanya bar tertutup) persis seperti pseudocode Bagian 19:
    kelola posisi & order pada bar t -> update swing/pivot/BOS/zona/likuiditas -> pembatalan berbasis close ->
    filter konteks -> kandidat setup (A/C saat pivot berganti, B saat swing baru sesudah break, D saat BOS sesudah sweep,
    E & re-entry dari trade yang baru tutup) -> validasi -> skor -> pasang yang terbaik.
Karena kontrol risiko dokumen (K3/K4, re-entry, Setup E, kunci arah RE3) bergantung pada hasil trade sebelumnya, engine
juga mensimulasikan siklus hidup order (Bagian 14.4/14.5) dengan aturan konservatif R8 (SL lebih dulu bila satu bar
menyentuh SL & TP). Setiap kandidat valid juga disimulasikan sebagai "bayangan" (tanpa K3) untuk statistik walk-forward
per tipe setup - dipakai filter quant (dokumen Bagian 22: "matikan tipe yang negatif") tanpa melihat masa depan.
"""
import math

from .core import ATR, Structure, HIGH, LOW, atr_mt5
from .params import PARAMS

TYPES = ("A", "B", "C", "D", "E")
FINAL = ("TP2", "TP1", "SL", "CANCEL", "EXPIRED", "MISSED", "VETO")


class Setup:
    """Satu setup (Bagian 5). Harga disimpan dalam harga asli; *_n = ternormalisasi arah d."""

    def __init__(self, typ, d, t, atr, E1n, SLn, tp1n, tp2n, info):
        self.type, self.d, self.created, self.atr = typ, d, t, atr
        self.E1n, self.SLn, self.TP1n, self.TP2n = E1n, SLn, tp1n, tp2n
        self.E2n = None
        self.info = info                      # zona, pivot, sumber TP, catatan, dll.
        self.id = None
        self.key = None
        self.score = 0
        self.reentry_no = info.get("reentry_no", 0)
        self.status = "PENDING"
        self.reason = None
        self.legs = []                        # dict(entry_n, frac, filled_bar, open)
        self.e2_active = True
        self.tp1_done = False
        self.sl_now_n = SLn
        self.be_pending = None
        self.pnl = 0.0
        self.cost_acc = 0.0
        self.swap_acc = 0.0
        self.closed_bar = None
        self.exit_reason = None
        self.fill_bar = None
        self.mfe = 0.0
        self.mae = 0.0
        self.armed = None                     # C2 aktif sesudah harga berada di antara E1 dan TP1 (lihat life())
        self.shadow = False
        self.filters = {}
        self.blocked = None

    # harga asli
    def px(self, vn):
        return None if vn is None else self.d * vn

    @property
    def unit(self):
        sp = self.info["split"]
        eavg = sp * self.E1n + (1 - sp) * self.E2n
        return max(1e-12, eavg - self.SLn)

    def rr_final(self):
        return (self.TP2n - self.E1n) / max(1e-12, self.E1n - self.SLn)

    def open_frac(self):
        return sum(g["open"] for g in self.legs)

    def as_dict(self, ts=None):
        d = self.d
        r = self.pnl - self.cost_acc - self.swap_acc
        out = dict(id=self.id, key=self.key, type=self.type, side="BUY" if d > 0 else "SELL", d=d, created=self.created,
                   created_ts=ts[self.created] if ts else None, atr=self.atr,
                   E1=self.px(self.E1n), E2=self.px(self.E2n), SL=self.px(self.info["SL0n"]), sl_now=self.px(self.sl_now_n),
                   TP1=self.px(self.TP1n), TP2=self.px(self.TP2n), rr_final=self.rr_final(), score=self.score, status=self.status,
                   reason=self.reason, reentry_no=self.reentry_no, fill_bar=self.fill_bar, closed_bar=self.closed_bar,
                   exit_reason=self.exit_reason, r=r, mfe=self.mfe, mae=self.mae, tp1_done=self.tp1_done,
                   legs=[dict(entry=self.px(g["entry_n"]), frac=g["frac"], filled_bar=g["filled_bar"], open=g["open"]) for g in self.legs],
                   e2_active=self.e2_active, filters=self.filters, blocked=self.blocked, shadow=self.shadow)
        inf = self.info
        out.update(zone=inf.get("zone"), backup=inf.get("backup_out"), invalidation=self.px(inf.get("inv_n")), pivots=inf.get("pivots"),
                   tp1_src=inf.get("tp1_src"), tp2_src=inf.get("tp2_src"), checks=inf.get("checks", []), notes=inf.get("notes", []),
                   trigger=inf.get("trigger"), sl_adjusted=inf.get("sl_adjusted", False), unit=self.unit,
                   ladder=inf.get("ladder") or [])
        return out


class Engine:
    def __init__(self, o, h, l, c, ts, v=None, params=None, atr=None, cost=0.0, swap_bar=0.0, spread_frac=0.0,
                 bar_sec=300, veto=None, bias=None, apply_terminal=True):
        self.P = dict(PARAMS, **(params or {}))
        self.o, self.h, self.l, self.c = list(map(float, o)), list(map(float, h)), list(map(float, l)), list(map(float, c))
        self.v = [float(x) for x in v] if v is not None else None
        self.ts = list(ts)
        self.n = len(self.c)
        self._atr_state = None
        if atr is not None:
            self.atr = list(atr)
        else:
            self._atr_state = ATR(self.P["ATR_Period"])
            self.atr = self._atr_state.extend(self.h, self.l, self.c)              # list yang sama diteruskan oleh extend()
        self.cost_frac, self.swap_bar_frac, self.spread_frac = cost, swap_bar, spread_frac
        self.bar_sec = bar_sec
        self.veto = set(veto or ())
        self.bias = bias
        self.apply_terminal = apply_terminal
        self.S = Structure(self.o, self.h, self.l, self.c, self.atr, self.P)
        self.setups, self.active, self.shadow_active, self.shadow_done = [], [], [], []
        self.seq = 0
        self.btrig = {1: None, -1: None}
        self.locks = {1: False, -1: False}
        self.daily = {}
        self.diag = {}
        self.last_t = -1
        self.events = []
        self._atr_sorted = None
        self._has_volume = bool(self.v) and sum(1 for x in self.v[-500:] if x > 0) > 50   # tampilan (bar terakhir)

    def _volume_at(self, t):
        """Sumber punya volume nyata pada bar t? Dihitung KAUSAL dari 500 bar sampai t (tanpa melihat bar sesudahnya)."""
        return bool(self.v) and sum(1 for x in self.v[max(0, t - 499):t + 1] if x > 0) > 50

    # ------------------------------------------------------------------ waktu, sesi, hari
    def _day(self, t):
        sec = self.ts[t] + self.bar_sec + self.P["Session_TZ_Hours"] * 3600     # keputusan diambil saat bar tutup
        return int(sec // 86400)

    def _session_ok(self, t):
        sec = self.ts[t] + self.bar_sec + self.P["Session_TZ_Hours"] * 3600
        m = int(sec // 60) % 1440
        return self.P["Session_Start_Min"] <= m < self.P["Session_End_Min"]

    # ------------------------------------------------------------------ tangga target (Bagian 8)
    def ladder(self, t, d, E1n, SLn, swing_cands, atr):
        P, S = self.P, self.S
        risk = E1n - SLn
        cands = []
        for p, ref in swing_cands:                                                        # T1a
            cands.append(dict(px=p - P["TP_Swing_Offset_ATR"] * atr, kind="swing", ref=ref, fresh=False))
        for z in S.live_zones:
            if z.dir != -d:
                continue
            if z.state in ("FRESH", "TESTED"):                                           # T1b (termasuk zona FLIP)
                cands.append(dict(px=z.lo_n(d) - P["TP_Zone_Offset_ATR"] * atr, kind="zone", ref=z.id, fresh=z.state == "FRESH",
                                  flip=z.is_flip, zone_state=z.state))
            elif z.state == "WEAK":                                                       # T1d
                cands.append(dict(px=z.hi_n(d) + P["TP_Liq_Offset_ATR"] * atr, kind="weakzone", ref=z.id, fresh=False))
        for lv in S.live_levels:                                                          # T1c
            if lv.dir == d and lv.state == "ACTIVE":
                cands.append(dict(px=d * lv.price + P["TP_Liq_Offset_ATR"] * atr, kind="liq", ref=lv.id, fresh=False, liq_kind=lv.kind))
        cands = sorted((x for x in cands if x["px"] > E1n), key=lambda x: x["px"])        # T2
        for i, x in enumerate(cands):                                                     # T5 zona fresh = penghalang
            if x["kind"] == "zone" and x["fresh"]:
                cands = cands[:i + 1]
                break
        for x in cands:
            x["rr"] = (x["px"] - E1n) / risk if risk > 0 else 0.0
        tp1 = next((x for x in cands if x["rr"] >= P["TP1_Min_RR"]), None)                # T3
        if tp1 is None:
            return None, None, cands
        after = cands[cands.index(tp1) + 1:]
        tp2 = next((x for x in after if x["rr"] >= P["Min_RR_Final"]), None)              # T4
        if tp2 is None:
            tp2 = tp1 if tp1["rr"] >= P["Min_RR_Final"] else None
        return tp1, tp2, cands

    # ------------------------------------------------------------------ bantu
    def _diag(self, typ, d, t, ok, code, msg, values=None):
        self.diag[f"{typ}{'+' if d > 0 else '-'}"] = dict(type=typ, side="BUY" if d > 0 else "SELL", bar=t, ok=ok, code=code, msg=msg, values=values or {})
        return None

    def _backup_zone(self, d, SLn, near_n=None, atr=None):
        best = None
        for z in self.S.live_zones:
            if z.dir != d or not z.usable():
                continue
            top = z.hi_n(d)
            if top >= SLn:
                continue
            if near_n is not None and not (z.lo_n(d) <= near_n + 0.5 * atr and top >= near_n - 0.5 * atr):
                continue
            if best is None or top > best.hi_n(d):
                best = z
        return best

    def _invalidation(self, d, E1n, SLn):
        """K6: batas distal zona searah terdekat di sisi SL dari E1 (atau SL bila tidak ada)."""
        best = None
        for z in self.S.live_zones:
            if z.dir == d and z.hi_n(d) <= E1n + 1e-12 and z.state in ("FRESH", "TESTED", "WEAK"):
                if best is None or z.hi_n(d) > best.hi_n(d):
                    best = z
        return best.lo_n(d) if best else SLn

    def _swing_highs_above(self, d, above_n, before):
        """Swing peran HIGH' terkonfirmasi di atas `above_n` yang belum dilewati harga sejak terbentuk."""
        out = []
        for s in self.S.by_type[d][-30:]:
            pn = d * s.price
            if s.confirmed_at <= before and pn > above_n and self.S.max_high_n(s.index + 1, before, d) < pn:
                out.append((pn, f"swing@{s.index}"))
        return out

    def _zone_out(self, z):
        return z.as_dict() if z else None

    # ------------------------------------------------------------------ SETUP A (Bagian 9)
    def setup_a(self, t, d):
        P, S = self.P, self.S
        a = self.atr[t]
        pv = S.pivots
        if len(pv) < 4:
            return self._diag("A", d, t, False, "A1", "belum ada 4 pivot")
        L0, H1, L1, H2 = pv[-4:]
        if not (L0.type == -d and H1.type == d and L1.type == -d and H2.type == d):
            return self._diag("A", d, t, False, "A1", "urutan pivot bukan L0-H1-L1-H2")
        l0, h1, l1, h2 = d * L0.price, d * H1.price, d * L1.price, d * H2.price
        vals = dict(L0=L0.price, H1=H1.price, L1=L1.price, H2=H2.price)
        if h1 - l0 < P["A_MinImpulse_ATR"] * a:
            return self._diag("A", d, t, False, "A2", f"impuls {(h1 - l0) / a:.2f} ATR < {P['A_MinImpulse_ATR']}", vals)
        if not S.bos_in(d, L0.index, H1.index):
            return self._diag("A", d, t, False, "A3", "tidak ada BOS searah di antara L0 dan H1", vals)
        if not (l1 > l0 and h2 < h1):
            return self._diag("A", d, t, False, "A4", "L1 harus di atas L0 dan H2 di bawah H1", vals)
        rb = (h2 - l1) / (h1 - l1) if h1 > l1 else 0
        if not (P["A_B_MinRetrace"] <= rb <= P["A_B_MaxRetrace"]):
            return self._diag("A", d, t, False, "A5", f"retrace B {rb:.3f} di luar {P['A_B_MinRetrace']}-{P['A_B_MaxRetrace']}", vals)
        c100 = h2 - P["A_C_ExtMin"] * (h1 - l1)
        c127 = h2 - P["A_C_ExtMax"] * (h1 - l1)
        vals.update(retrace_B=rb, C_100=d * c100, C_127=d * c127)
        if not c100 > l0:
            return self._diag("A", d, t, False, "A6", "C_100 melewati awal impuls L0", vals)
        zone = None
        for z in S.live_zones:                                                            # A7
            if z.dir != d or not z.usable():
                continue
            if z.lo_n(d) <= c100 and z.hi_n(d) >= c127:
                if zone is None or (z.score(), -abs(z.hi_n(d) - c100)) > (zone.score(), -abs(zone.hi_n(d) - c100)):
                    zone = z
        if zone is None and P["Require_Zone_SetupA"]:
            return self._diag("A", d, t, False, "A7", "tidak ada zona FRESH/TESTED/FLIP yang beririsan dengan proyeksi C", vals)
        top, bot = (zone.hi_n(d), zone.lo_n(d)) if zone else (c100, c127)
        E1 = max(top, c100)
        if E1 >= l1:
            E1 = c100
        SL = min(bot, c127) - P["SL_Buffer_ATR"] * a
        disc = (h1 - E1) / (h1 - l0)
        vals.update(E1=d * E1, discount=disc)
        if not (P["A_Disc_Min"] <= disc <= P["A_Disc_Max"]):
            return self._diag("A", d, t, False, "A-disc", f"diskon {disc:.3f} di luar {P['A_Disc_Min']}-{P['A_Disc_Max']}", vals)
        if not S.min_low_n(H2.index + 1, t, d) > E1:                                      # A8
            return self._diag("A", d, t, False, "A8", "harga sudah menyentuh E1 sejak H2", vals)
        back = self._backup_zone(d, SL)
        info = dict(zone=self._zone_out(zone), zone_obj=zone, pivots=dict(L0=L0.price, H1=H1.price, L1=L1.price, H2=H2.price),
                    pivot_ref=H2.index, swing_cands=[(h2, f"H2@{H2.index}"), (h1, f"H1@{H1.index}")], backup=("zone", back) if back else None,
                    trigger_bars=list(range(zone.impulse_start, zone.born + 1)) if zone and zone.impulse_start is not None else [],
                    virtual_zone=zone is None, values=vals)
        self._diag("A", d, t, True, "A", "kandidat setup A terbentuk", vals)
        return dict(type="A", d=d, E1n=E1, SLn=SL, info=info)

    # ------------------------------------------------------------------ SETUP B (Bagian 10)
    def b_triggers(self, t):
        P, S = self.P, self.S
        for ev in S.ev_bos:                                                               # (i)/(iii) BOS / CHoCH
            d = ev["dir"]
            sw = ev["swing"]
            self.btrig[d] = dict(t=t, lvl_n=d * sw.price, origin=sw.index, kind="CHoCH" if ev["choch"] else "BOS")
        pr = S.prev_range
        if pr and t >= 1:                                                                 # (ii) close keluar range aktif
            for d, edge in ((1, pr["top"]), (-1, pr["bottom"])):
                en = d * edge
                if d * self.c[t] > en >= d * self.c[t - 1]:
                    cur = self.btrig[d]
                    if cur is None or cur["t"] != t:
                        self.btrig[d] = dict(t=t, lvl_n=en, origin=pr["first_index"], kind="RANGE")

    def setup_b(self, t, d):
        P, S = self.P, self.S
        tr = self.btrig[d]
        if tr is None:
            return None
        a = self.atr[t]
        if tr["t"] < t and S.close_n(t, d) < tr["lvl_n"] - P["B_FailClose_ATR"] * a:   # B3 breakout gagal
            self.btrig[d] = None
            return self._diag("B", d, t, False, "B3", "breakout gagal: close kembali jauh di bawah level")
        hnew = next((s for s in S.ev_swings if s.type == d and s.index > tr["t"]), None)
        if hnew is None:
            return None
        self.btrig[d] = None
        lvl = tr["lvl_n"]
        lo = S.min_low_n(tr["origin"], tr["t"], d)
        zone = None
        for z in S.live_zones:                                                            # (a) zona FLIP dekat LVL
            if z.dir == d and z.is_flip and z.usable() and lvl - a <= z.hi_n(d) <= lvl + a:
                if zone is None or abs(z.hi_n(d) - lvl) < abs(zone.hi_n(d) - lvl):
                    zone = z
        if zone:
            E1, SL, how = zone.hi_n(d), zone.lo_n(d) - P["SL_Buffer_ATR"] * a, "zona flip"
        else:                                                                             # (b) garis LVL
            E1 = lvl + P["B_RetestOffset_ATR"] * a
            SL = max(lo, lvl - P["B_LineSL_ATR"] * a) - P["SL_Buffer_ATR"] * a
            how = "garis level"
        vals = dict(LVL=d * lvl, LO=d * lo, H_new=hnew.price, E1=d * E1, trigger=tr["kind"])
        if not S.min_low_n(tr["t"] + 1, t, d) > E1:                                       # B4
            return self._diag("B", d, t, False, "B4", "harga sudah menyentuh E1 sejak break (tidak mengejar)", vals)
        swings = [(d * hnew.price, f"H_new@{hnew.index}")] + self._swing_highs_above(d, d * hnew.price, t)
        back = self._backup_zone(d, SL, near_n=lo, atr=a) or self._backup_zone(d, SL)
        info = dict(zone=self._zone_out(zone), zone_obj=zone, pivots=dict(LVL=d * lvl, LO=d * lo, H_new=hnew.price), pivot_ref=None,
                    swing_cands=swings, backup=("zone", back) if back else None, trigger=dict(kind=tr["kind"], bar=tr["t"]),
                    trigger_bars=[tr["t"]], how=how, values=vals)
        self._diag("B", d, t, True, "B", f"kandidat setup B ({tr['kind']}, {how})", vals)
        return dict(type="B", d=d, E1n=E1, SLn=SL, info=info)

    # ------------------------------------------------------------------ SETUP C harmonic (Bagian 11)
    def setup_c(self, t, d):
        P, S = self.P, self.S
        a = self.atr[t]
        pv = S.pivots
        if len(pv) < 4:
            return self._diag("C", d, t, False, "C1", "belum ada 4 pivot")
        X, A, B, Cp = pv[-4:]
        if not (X.type == -d and A.type == d and B.type == -d and Cp.type == d):
            return self._diag("C", d, t, False, "C1", "urutan pivot bukan X-A-B-C")
        x, aa, b, cc = d * X.price, d * A.price, d * B.price, d * Cp.price
        xa = aa - x
        vals = dict(X=X.price, A=A.price, B=B.price, C=Cp.price)
        if xa <= 0 or aa <= b:
            return self._diag("C", d, t, False, "C2", "kaki XA/AB tidak valid", vals)
        ab = (aa - b) / xa
        bc = (cc - b) / (aa - b)
        vals.update(AB_XA=ab, BC_AB=bc)
        if not (P["C_AB_Min"] <= ab <= P["C_AB_Max"]):
            return self._diag("C", d, t, False, "C2", f"AB/XA {ab:.3f} di luar {P['C_AB_Min']}-{P['C_AB_Max']}", vals)
        if not (P["C_BC_Min"] <= bc <= P["C_BC_Max"]):
            return self._diag("C", d, t, False, "C3", f"BC/AB {bc:.3f} di luar {P['C_BC_Min']}-{P['C_BC_Max']}", vals)
        dxa = [(aa - k * xa, k) for k in P["C_XA_Levels"] if aa - k * xa < b]
        dbc = [(cc - m * (cc - b), m) for m in P["C_BC_Levels"] if cc - m * (cc - b) < b]
        tol = P["C_ClusterTol_XA"] * xa
        clusters = []
        for v1, k in dxa:
            for v2, m in dbc:
                if abs(v1 - v2) <= tol:
                    clusters.append(dict(top=max(v1, v2), bottom=min(v1, v2), xa=k, bc=m, gap=abs(v1 - v2)))
        if not clusters:
            return self._diag("C", d, t, False, "C5", "tidak ada klaster Fibonacci XA/BC", vals)
        prz = max(clusters, key=lambda q: (q["top"], -q["gap"]))
        buf = max(P["C_SL_Buffer_XA"] * xa, P["SL_Buffer_ATR"] * a)
        SL = prz["bottom"] - buf
        backup = max((q for q in clusters if q["top"] < SL), key=lambda q: (q["top"], -q["gap"]), default=None)
        vals.update(PRZ_top=d * prz["top"], PRZ_bottom=d * prz["bottom"], PRZ_xa=prz["xa"], PRZ_bc=prz["bc"])
        zone_hit = None
        for z in S.live_zones:                                                            # C6 / skor +2
            if z.dir == d and z.usable() and z.lo_n(d) <= prz["top"] + 0.5 * a and z.hi_n(d) >= prz["bottom"] - 0.5 * a:
                zone_hit = z
                break
        liq_hit = any(lv.dir == -d and lv.state == "ACTIVE" and prz["bottom"] - 0.5 * a <= d * lv.price <= prz["top"] + 0.5 * a for lv in S.live_levels)
        if P["C_RequireZone"] and not (zone_hit or liq_hit):
            return self._diag("C", d, t, False, "C6", "PRZ tidak beririsan zona / equal lows", vals)
        if not S.min_low_n(Cp.index + 1, t, d) > prz["top"]:                             # C7
            return self._diag("C", d, t, False, "C7", "harga sudah menyentuh PRZ", vals)
        E1 = prz["top"]
        AD = aa - E1
        tp1 = E1 + 0.382 * AD
        tp2 = E1 + 0.618 * AD
        tp2_src = dict(kind="fib", ref="0.618 AD")
        for z in sorted((z for z in S.live_zones if z.dir == -d and z.state == "FRESH"), key=lambda z: z.lo_n(d)):   # pengecek tangga
            px = z.lo_n(d) - P["TP_Zone_Offset_ATR"] * a
            if E1 < px < tp2:
                tp2, tp2_src = px, dict(kind="zone", ref=z.id, fresh=True, flip=z.is_flip)
                break
        tp1 = min(tp1, tp2)
        info = dict(zone=self._zone_out(zone_hit), zone_obj=None, pivots=dict(X=X.price, A=A.price, B=B.price, C=Cp.price),
                    pivot_ref=Cp.index, prz=dict(top=d * prz["top"], bottom=d * prz["bottom"], xa=prz["xa"], bc=prz["bc"]),
                    clusters=[dict(top=d * q["top"], bottom=d * q["bottom"], xa=q["xa"], bc=q["bc"]) for q in sorted(clusters, key=lambda q: -q["top"])[:8]],
                    backup=("prz", dict(top=backup["top"], bottom=backup["bottom"], xa_len=xa)) if backup else None,
                    fixed_tp=(tp1, tp2, dict(kind="fib", ref="0.382 AD"), tp2_src), harmonic_buf=buf, xa_len=xa,
                    prz_zone=bool(zone_hit or liq_hit), swing_cands=[(aa, f"A@{A.index}")], trigger_bars=[], values=vals)
        self._diag("C", d, t, True, "C", "kandidat harmonic XABCD terbentuk", vals)
        return dict(type="C", d=d, E1n=E1, SLn=SL, info=info)

    # ------------------------------------------------------------------ SETUP D sweep (Bagian 12)
    def setup_d(self, t, d):
        P, S = self.P, self.S
        bos = next((ev for ev in S.ev_bos if ev["dir"] == d), None)
        if bos is None:
            return None
        sw = next((e for e in reversed(S.sweeps) if e["dir"] == d and not e["used"] and e["r"] < t <= e["r"] + P["Sweep_MaxBarsToBOS"]), None)
        if sw is None:
            return None
        sw["used"] = True
        a = self.atr[t]
        E1 = d * sw["price"] + P["B_RetestOffset_ATR"] * a
        zone = None
        for z in S.live_zones:
            if z.dir == d and sw["r"] < z.born <= t and z.hi_n(d) > E1 and z.usable():
                if zone is None or z.hi_n(d) > zone.hi_n(d):
                    zone = z
        if zone:
            E1 = zone.hi_n(d)
        SL = sw["sweep_low_n"] - P["SL_Buffer_ATR"] * a
        hi = S.max_high_n(sw["r"], t, d)
        vals = dict(level=sw["price"], sweep_bar=sw["r"], sweep_low=d * sw["sweep_low_n"], E1=d * E1, max_high=d * hi)
        info = dict(zone=self._zone_out(zone), zone_obj=zone, pivots=dict(level=sw["price"], sweep=d * sw["sweep_low_n"]), pivot_ref=None,
                    swing_cands=[(hi, f"maxHigh@{sw['r']}-{t}")], backup=None, trigger=dict(kind="SWEEP+BOS", bar=t, sweep_bar=sw["r"]),
                    trigger_bars=[t], values=vals)
        self._diag("D", d, t, True, "D", "kandidat liquidity sweep + BOS", vals)
        return dict(type="D", d=d, E1n=E1, SLn=SL, info=info)

    # ------------------------------------------------------------------ SETUP E & re-entry (Bagian 13 & 15)
    def setup_e(self, t, s):
        """Setup lawan arah di zona fresh/flip yang menjadi TP2 trade yang baru selesai di TP2."""
        P, S = self.P, self.S
        src = s.info.get("tp2_src") or {}
        if src.get("kind") != "zone" or not (src.get("fresh") or src.get("flip")):
            return None
        z = next((z for z in S.live_zones if z.id == src.get("ref")), None)
        d = -s.d
        if z is None or z.dir != d or z.state in ("BROKEN", "EXPIRED"):
            return self._diag("E", d, t, False, "E1", "zona TP2 sudah tidak berlaku")
        a = self.atr[t]
        E1 = z.hi_n(d)
        SL = z.lo_n(d) - P["SL_Buffer_ATR"] * a
        info = dict(zone=self._zone_out(z), zone_obj=z, pivots=dict(from_setup=s.id), pivot_ref=None,
                    swing_cands=[(d * s.px(s.E1n), f"E1 setup #{s.id}")], backup=None, trigger=dict(kind="TP2", bar=t, from_setup=s.id),
                    trigger_bars=[], values=dict(E1=d * E1, zone=z.id))
        self._diag("E", d, t, True, "E", f"rencana dua arah dari setup #{s.id}", info["values"])
        return dict(type="E", d=d, E1n=E1, SLn=SL, info=info)

    def reentry(self, t, s):
        P, S = self.P, self.S
        if s.reentry_no >= P["Max_ReEntry"] or not s.info.get("backup"):
            return None
        kind, bk = s.info["backup"]
        d, a = s.d, self.atr[t]
        if kind == "zone":
            z = bk
            if not z.usable():
                return self._diag(s.type, d, t, False, "RE2", "zona cadangan sudah tidak FRESH/TESTED atau sedang disentuh")
            E1, SL = z.hi_n(d), z.lo_n(d) - P["SL_Buffer_ATR"] * a
            zone_out, zobj, tb = self._zone_out(z), z, (list(range(z.impulse_start, z.born + 1)) if z.impulse_start is not None else [])
        else:
            E1 = bk["top"]
            SL = bk["bottom"] - max(P["C_SL_Buffer_XA"] * bk["xa_len"], P["SL_Buffer_ATR"] * a)
            zone_out, zobj, tb = None, None, []
            if S.min_low_n(t, t, d) <= E1:
                return self._diag(s.type, d, t, False, "RE2", "PRZ cadangan sudah disentuh")
        if s.info["SL0n"] - E1 > P["ReEntry_MaxGap_ATR"] * a:
            return self._diag(s.type, d, t, False, "RE2", "zona cadangan terlalu jauh dari SL lama")
        info = dict(zone=zone_out, zone_obj=zobj, pivots=s.info.get("pivots"), pivot_ref=None, swing_cands=list(s.info.get("swing_cands") or []),
                    backup=None, reentry_no=s.reentry_no + 1, trigger=dict(kind="RE-ENTRY", bar=t, from_setup=s.id), trigger_bars=tb,
                    values=dict(E1=d * E1, from_setup=s.id))
        return dict(type=s.type, d=d, E1n=E1, SLn=SL, info=info)

    # ------------------------------------------------------------------ validasi 14.1 + E2 + target
    def validate(self, t, cand):
        P = self.P
        d, a = cand["d"], self.atr[t]
        E1, SL, info = cand["E1n"], cand["SLn"], cand["info"]
        checks = []
        r = P["Ladder_E2_Ratio"]
        dist = E1 - SL
        if dist <= 0:
            return None, "SL tidak berada di sisi yang benar"
        if dist < P["SL_Min_ATR"] * a:                                                    # V1
            SL = E1 - P["SL_Min_ATR"] * a
            info["sl_adjusted"] = True
            checks.append(("V1", True, f"SL diperlebar ke {P['SL_Min_ATR']} ATR"))
        elif dist > P["SL_Max_ATR"] * a:
            return None, f"V1: jarak SL {dist / a:.2f} ATR > {P['SL_Max_ATR']}"
        else:
            checks.append(("V1", True, f"jarak SL {dist / a:.2f} ATR"))
        E2 = E1 - r * (E1 - SL)
        if "fixed_tp" in info:                                                            # harmonic: TP dari kaki AD
            tp1n, tp2n, s1, s2 = info["fixed_tp"]
            tp1 = dict(px=tp1n, kind=s1["kind"], ref=s1["ref"])
            tp2 = dict(px=tp2n, **s2)
            if tp2n <= E1:
                return None, "TP harmonic tidak di atas E1"
        else:
            tp1, tp2, cands = self.ladder(t, d, E1, SL, info.get("swing_cands") or [], a)
            info["ladder"] = [dict(px=d * x["px"], kind=x["kind"], ref=x["ref"], rr=round(x["rr"], 3)) for x in cands[:10]]
            if tp1 is None:
                return None, f"T3: tidak ada target dengan RR >= {P['TP1_Min_RR']}"
            if tp2 is None:
                return None, f"T4: tidak ada target kedua dengan RR >= {P['Min_RR_Final']}"
        rr = (tp2["px"] - E1) / (E1 - SL)
        if rr < P["Min_RR_Final"]:                                                        # V2
            return None, f"V2: RR akhir {rr:.2f} < {P['Min_RR_Final']}"
        checks.append(("V2", True, f"RR akhir {rr:.2f}"))
        if not self.S.close_n(t, d) > E1:                                                 # V3 limit sah
            return None, "V3: harga sekarang sudah melewati E1 (limit tidak sah)"
        checks.append(("V3", True, "limit sah (harga belum mencapai E1)"))
        s = Setup(cand["type"], d, t, a, E1, SL, tp1["px"], tp2["px"], info)
        s.E2n = E2
        info["SL0n"] = SL
        info["split"] = P["Ladder_Lot_Split"]
        info["tp1_src"] = {k: v for k, v in tp1.items() if k not in ("px", "rr")}
        info["tp2_src"] = {k: v for k, v in tp2.items() if k not in ("px", "rr")}
        info["inv_n"] = self._invalidation(d, E1, SL)
        info["checks"] = checks
        bk = info.get("backup")
        if bk:
            info["backup_out"] = dict(kind="zone", zone=bk[1].as_dict()) if bk[0] == "zone" else dict(kind="prz", top=d * bk[1]["top"], bottom=d * bk[1]["bottom"])
        s.score = self._score(s)
        s.key = f"{cand['type']}|{'B' if d > 0 else 'S'}|{self.ts[t]}|{round(d * E1, 8)}"
        return s, None

    def _score(self, s):
        """Bagian 17."""
        sc = 0
        z = s.info.get("zone_obj")
        if z is not None:
            sc += z.score()
        if s.type == "C" and s.info.get("prz_zone"):
            sc += 2
        if (s.info.get("tp2_src") or {}).get("kind") == "liq":
            sc += 1
        if self.S.last_bos_dir == s.d:
            sc += 1
        if s.rr_final() >= 2.5:
            sc += 1
        return sc

    # ------------------------------------------------------------------ filter konteks (Bagian 7) + terminal
    def _dstat(self, t):
        return self.daily.setdefault(self._day(t), dict(n=0, r=0.0))

    def context(self, t, s):
        """None bila lolos, selain itu (kode, alasan). Juga mengisi s.filters untuk tampilan."""
        P = self.P
        d, a = s.d, s.atr
        f = s.filters
        spread = self.spread_frac * self.c[t]
        f["spread"] = dict(ok=spread <= P["Max_Spread_vs_SL"] * (s.E1n - s.SLn), spread=spread, max=P["Max_Spread_vs_SL"] * (s.E1n - s.SLn))
        if not f["spread"]["ok"]:
            return "K1", "spread terlalu besar dibanding jarak SL"
        f["session"] = dict(ok=self._session_ok(t))
        if not f["session"]["ok"]:
            return "K2", "di luar sesi 07:00-23:00 (UTC+7)"
        others = [x for x in self.active if x.status in ("PENDING", "OPEN")]
        if s.type == "E":
            clash = [x for x in others if x.d == d]
        else:
            clash = others
        if clash:
            return "K3", f"sudah ada setup aktif #{clash[0].id} ({clash[0].type} {'BUY' if clash[0].d > 0 else 'SELL'})"
        ds = self._dstat(t)
        if ds["r"] <= -P["Max_Daily_Loss_R"]:
            return "K4", f"rugi hari ini {ds['r']:.2f}R >= batas {P['Max_Daily_Loss_R']}R"
        if ds["n"] >= P["Max_NewSetups_Per_Day"]:
            return "K4", f"sudah {ds['n']} setup baru hari ini (maks {P['Max_NewSetups_Per_Day']})"
        if P["UseBiasFilter"] and self.bias is not None and self.bias[t] == -d:
            return "K5", "bias TF_Bias berlawanan"
        if self.locks.get(d):
            return "RE3", "arah dikunci setelah re-entry kena SL (menunggu BOS searah baru)"
        if s.key in self.veto:
            return "VETO", "ditahan filter terminal saat terbit (berita/risiko portofolio)"
        if not self.apply_terminal:
            return None
        # -- filter TERMINAL yang tetap jalan (volume, quant)
        tb = [k for k in (s.info.get("trigger_bars") or []) if 0 <= k <= t]
        if tb and self._volume_at(t):
            base0 = min(tb)
            prev = sorted(self.v[max(0, base0 - 20):base0])
            med = prev[len(prev) // 2] if prev else 0.0
            vol = sum(self.v[k] for k in tb) / len(tb)
            rvol = vol / med if med > 0 else None
            f["volume"] = dict(ok=rvol is None or rvol >= P["Term_Volume_MinRVOL"], rvol=rvol)
            if not f["volume"]["ok"]:
                return "VOL", f"volume pemicu lemah (RVOL {rvol:.2f} < {P['Term_Volume_MinRVOL']})"
        else:
            f["volume"] = dict(ok=True, rvol=None, note="tanpa bar pemicu" if not tb else "tidak ada data volume")
        pct = self._atr_pct(t)
        f["quant_spike"] = dict(ok=pct is None or pct <= P["Term_Quant_SpikePct"], atr_pct=pct)
        if not f["quant_spike"]["ok"]:
            return "QNT", f"volatilitas ekstrem (ATR persentil {pct:.2f})"
        st = self.type_stats(s.type, t)
        f["quant_type"] = dict(ok=True, **st)
        if st["n"] >= P["Term_Quant_MinN"] and st["lcb"] <= P["Term_Quant_GateLCB"]:
            f["quant_type"]["ok"] = False
            return "QNT", f"setup {s.type} di pair ini negatif secara statistik ({st['n']} trade, LCB {st['lcb']:+.2f}R)"
        return None

    def _atr_pct(self, t):
        a = self.atr[t]
        if a is None:
            return None
        win = [x for x in self.atr[max(0, t - 499):t + 1] if x is not None]
        if len(win) < 100:
            return None
        return sum(1 for x in win if x <= a) / len(win)

    def type_stats(self, typ, t=None):
        rs = [x.pnl - x.cost_acc - x.swap_acc for x in self.shadow_done if x.type == typ and x.status in ("TP2", "TP1", "SL") and (t is None or x.closed_bar < t)]
        n = len(rs)
        if n == 0:
            return dict(n=0, avg=None, lcb=None, win=None)
        m = sum(rs) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in rs) / (n - 1)) if n > 1 else 0.0
        return dict(n=n, avg=m, lcb=m - sd / math.sqrt(n) if n > 1 else m, win=sum(1 for v in rs if v > 0) / n)

    # ------------------------------------------------------------------ siklus hidup order (14.3-14.5)
    def _final(self, s, t, status, reason=None):
        s.status, s.closed_bar = status, t
        if reason:
            s.reason = reason
        if s in self.active:
            self.active.remove(s)
        if s in self.shadow_active:
            self.shadow_active.remove(s)
            self.shadow_done.append(s)
        elif not s.shadow and status in ("TP2", "TP1", "SL"):
            self._dstat(t)["r"] += s.pnl - s.cost_acc - s.swap_acc

    def _close(self, s, frac, px_n):
        rem = frac
        for g in s.legs:                                                                  # tutup mulai dari posisi E1
            if rem <= 1e-12:
                break
            take = min(g["open"], rem)
            if take <= 0:
                continue
            s.pnl += take * (px_n - g["entry_n"]) / s.unit
            s.cost_acc += take * self.cost_frac * abs(px_n) / s.unit        # biaya per leg yang keluar (harga x pecahan biaya)
            g["open"] -= take
            rem -= take

    def life(self, s, k):
        """Proses bar k untuk setup s (dibuat di bar < k). Aturan konservatif R8."""
        P, S = self.P, self.S
        d = s.d
        op, lo, hi = d * self.o[k], S.low_n(k, d), S.high_n(k, d)
        if s.status == "PENDING":
            if op <= s.SLn:
                return self._final(s, k, "CANCEL", "C3: harga membuka di luar SL sebelum terisi")
            # C2 "harga menyentuh TP1 sebelum E1 terisi" = pasar sampai ke target TANPA kembali ke entry. Bila saat setup dibuat
            # harga masih di seberang TP1 (mis. harmonic: harga di sekitar C, TP1 di antara harga dan PRZ), harga memang akan
            # melewati TP1 dalam perjalanan ke E1 - itu bukan "basi". Karena itu C2 baru berlaku sesudah harga berada di antara
            # E1 dan TP1 (armed).
            if s.armed is None:
                s.armed = self.S.close_n(s.created, d) < s.TP1n
            hit_e1, hit_tp1 = lo <= s.E1n, hi >= s.TP1n
            if hit_tp1 and s.armed:
                return self._final(s, k, "MISSED", "C2: TP1 tersentuh sebelum E1 terisi" + (" (satu bar dengan E1: konservatif)" if hit_e1 else ""))
            if lo < s.TP1n:
                s.armed = True
            if not hit_e1:
                return None
            sp = s.info["split"]
            s.legs = [dict(entry_n=min(op, s.E1n), frac=sp, filled_bar=k, open=sp)]
            s.fill_bar = k
            s.status = "OPEN"
            if lo <= s.E2n:
                s.legs.append(dict(entry_n=min(op, s.E2n), frac=1 - sp, filled_bar=k, open=1 - sp))
                s.e2_active = False
            z = s.info.get("zone_obj")
            if z is not None and not s.shadow:
                z.mitigated = True                                                       # 6.6: zona dipakai setup yang terisi
            if lo <= s.SLn:
                self._close(s, s.open_frac(), s.SLn)
                s.exit_reason = "SL"
                return self._final(s, k, "SL", "SL tersentuh pada bar pengisian")
            self._excursion(s, lo, hi)
            return None
        if s.status != "OPEN":
            return None
        s.swap_acc += s.open_frac() * self.swap_bar_frac * self.c[k] / s.unit
        if s.be_pending is not None:
            s.sl_now_n, s.be_pending = s.be_pending, None
        if s.e2_active and not s.tp1_done and lo <= s.E2n:
            sp = s.info["split"]
            s.legs.append(dict(entry_n=min(op, s.E2n), frac=1 - sp, filled_bar=k, open=1 - sp))
            s.e2_active = False
        if op <= s.sl_now_n or lo <= s.sl_now_n:
            px = op if op <= s.sl_now_n else s.sl_now_n
            self._close(s, s.open_frac(), px)
            s.exit_reason = "BE" if s.tp1_done else "SL"
            self._excursion(s, lo, hi)
            return self._final(s, k, "TP1" if s.tp1_done else "SL", "stop di breakeven sesudah TP1" if s.tp1_done else "kena SL")
        if not s.tp1_done and hi >= s.TP1n:
            px = op if op >= s.TP1n else s.TP1n
            self._close(s, P["TP1_Close_Fraction"] * s.open_frac(), px)
            s.tp1_done = True
            s.e2_active = False                                                          # M2: order #2 dihapus
            filled = [g for g in s.legs]
            eavg = sum(g["entry_n"] * g["frac"] for g in filled) / sum(g["frac"] for g in filled)
            s.be_pending = eavg + P["BE_Offset_ATR"] * s.atr                              # M1 (berlaku mulai bar berikutnya)
            if s.TP2n <= s.TP1n + 1e-12:
                self._close(s, s.open_frac(), px)
                s.exit_reason = "TP2"
                return self._final(s, k, "TP2", "TP tercapai")
        if s.tp1_done and hi >= s.TP2n:
            px = op if op >= s.TP2n else s.TP2n
            self._close(s, s.open_frac(), px)
            s.exit_reason = "TP2"
            self._excursion(s, lo, hi)
            return self._final(s, k, "TP2", "TP2 tercapai")
        self._excursion(s, lo, hi)
        return None

    def _excursion(self, s, lo, hi):
        if not s.legs:
            return
        e = sum(g["entry_n"] * g["frac"] for g in s.legs) / sum(g["frac"] for g in s.legs)
        s.mfe = max(s.mfe, (hi - e) / s.unit)
        s.mae = min(s.mae, (lo - e) / s.unit)

    def _cancel_on_close(self, t, pool):
        """C1, C3-C6 pada close bar t untuk setup yang belum terisi."""
        P, S = self.P, self.S
        for s in list(pool):
            if s.status != "PENDING" or s.created >= t:
                continue
            d = s.d
            cl = S.close_n(t, d)
            if t - s.created >= P["Pending_Expiry_Bars"]:
                self._final(s, t, "EXPIRED", f"C1: tidak terisi dalam {P['Pending_Expiry_Bars']} bar")
            elif cl < s.SLn:
                self._final(s, t, "CANCEL", "C3: close di luar SL sebelum terisi (zona jebol)")
            elif cl < s.info.get("inv_n", s.SLn):
                self._final(s, t, "CANCEL", "C4: level invalidasi (K6) ditembus")
            elif any(ev["dir"] == -d for ev in S.ev_bos):
                self._final(s, t, "CANCEL", "C5: BOS berlawanan arah sebelum terisi")
            elif s.info.get("pivot_ref") is not None and s.info["pivot_ref"] in S.ev_replaced:
                self._final(s, t, "CANCEL", "C6: pivot pembentuk setup berganti (high/low baru)")

    # ------------------------------------------------------------------ satu bar
    def step(self, t):
        S, P = self.S, self.P
        closed = []
        for s in list(self.active):
            before = s.status
            self.life(s, t)
            if s.status in FINAL and before not in FINAL:
                closed.append(s)
        for s in list(self.shadow_active):
            self.life(s, t)
        S.step(t)
        for ev in S.ev_bos:                                                               # RE3: kunci dibuka oleh BOS searah baru
            if self.locks.get(ev["dir"]):
                self.locks[ev["dir"]] = False
        self._cancel_on_close(t, self.active)
        self._cancel_on_close(t, self.shadow_active)
        a = self.atr[t]
        self.b_triggers(t)
        if a is None or a <= 0:
            return
        cands = []
        for d in (1, -1):
            if S.ev_pivot_changed[d]:
                cands += [self.setup_a(t, d), self.setup_c(t, d)]
            cands.append(self.setup_b(t, d))
            cands.append(self.setup_d(t, d))
        for s in closed:
            if s.status == "TP2":
                cands.append(self.setup_e(t, s))
            if s.status == "SL":
                if s.reentry_no >= 1:
                    self.locks[s.d] = True                                                # RE3
                cands.append(self.reentry(t, s))
        valid = []
        for c in cands:
            if not c:
                continue
            s, why = self.validate(t, c)
            if s is None:
                self._diag(c["type"], c["d"], t, False, "V", why, c["info"].get("values"))
                continue
            sh = self._shadow_copy(s)                                                     # statistik walk-forward tanpa K3
            self.shadow_active.append(sh)
            blk = self.context(t, s)
            if blk:
                s.blocked = dict(code=blk[0], msg=blk[1])
                self._diag(s.type, s.d, t, False, blk[0], blk[1], s.info.get("values"))
                self.events.append(dict(bar=t, kind="blocked", type=s.type, side="BUY" if s.d > 0 else "SELL", code=blk[0], msg=blk[1], key=s.key))
                continue
            valid.append(s)
        if not valid:
            return
        order = {id(s): i for i, s in enumerate(valid)}
        valid.sort(key=lambda s: (-s.score, (s.E1n - s.SLn) / max(1e-12, s.atr), -order[id(s)]))   # P1 skor, P2 SL terkecil (ATR), P3 terbaru
        best = valid[0]
        self.seq += 1
        best.id = self.seq
        self.setups.append(best)
        self.active.append(best)
        ds = self._dstat(t)
        ds["n"] += 1
        self.events.append(dict(bar=t, kind="placed", id=best.id, type=best.type, side="BUY" if best.d > 0 else "SELL", key=best.key, score=best.score))
        self._diag(best.type, best.d, t, True, "PLACED", f"setup #{best.id} dipasang (skor {best.score})", best.info.get("values"))

    def _shadow_copy(self, s):
        sh = Setup(s.type, s.d, s.created, s.atr, s.E1n, s.SLn, s.TP1n, s.TP2n, dict(s.info, zone_obj=None))
        sh.E2n = s.E2n
        sh.shadow = True
        return sh

    def extend(self, o, h, l, c, ts, v=None):
        """Tambahkan bar BARU yang sudah tertutup (lanjutan langsung dari bar terakhir) tanpa memutar ulang dari awal.
        Hasil sesudah run() identik dengan membangun mesin dari seluruh data sekaligus (diuji di test_strategy_one)."""
        if self._atr_state is None or self.bias is not None:
            raise ValueError("extend() butuh ATR internal dan tanpa seri bias (mesin dibuat tanpa atr=/bias=)")
        if ts and self.ts and ts[0] <= self.ts[-1]:
            raise ValueError("bar baru harus sesudah bar terakhir")
        self.o.extend(map(float, o)); self.h.extend(map(float, h)); self.l.extend(map(float, l)); self.c.extend(map(float, c))
        self.ts.extend(ts)
        if self.v is not None:
            self.v.extend(float(x) for x in (v if v is not None else [0.0] * len(c)))
            self._has_volume = sum(1 for x in self.v[-500:] if x > 0) > 50
        self._atr_state.extend(self.h, self.l, self.c)
        self.n = self.S.n = len(self.c)
        return self

    def run(self, upto=None):
        end = self.n if upto is None else min(self.n, upto + 1)
        for t in range(self.last_t + 1, end):
            self.step(t)
            self.last_t = t
        return self

    # ------------------------------------------------------------------ lot (Bagian 14.2)


def lots(equity, risk_pct, E1, E2, SL, value_per_unit, step=0.01, min_vol=0.01, split=0.5):
    """LotTotal = RiskMoney / (|Eavg - SL| * nilai per 1.0 harga per lot); dibagi E1/E2 dan dibulatkan ke bawah."""
    risk_money = equity * risk_pct / 100.0
    eavg = split * E1 + (1 - split) * E2

    def floor(x):
        return math.floor(x / step + 1e-9) * step

    dist = abs(eavg - SL)
    if dist <= 0 or value_per_unit <= 0:
        return None
    total = risk_money / (dist * value_per_unit)
    l1, l2 = floor(total * split), floor(total * (1 - split))
    out = dict(risk_money=risk_money, eavg=eavg, dist=dist, total=total, lot1=round(l1, 8), lot2=round(l2, 8), only_e1=False, ok=True)
    if l1 < min_vol - 1e-12:
        out.update(ok=False, note="Lot E1 di bawah volume minimum: setup dibatalkan (14.2)")
    elif l2 < min_vol - 1e-12:
        out.update(lot1=round(floor(risk_money / (abs(E1 - SL) * value_per_unit)), 8), lot2=0.0, only_e1=True,
                   note="Lot E2 di bawah minimum: hanya E1 (14.2)")
    return out
