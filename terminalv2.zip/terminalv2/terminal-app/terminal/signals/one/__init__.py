"""Strategi ONE: ZONA + STRUKTUR + HARMONIC (dokumen aturan v2.0).

Mesin bar-per-bar (hanya bar tertutup, tanpa repaint) yang menjadi alternatif "10 metode analisa" di menu SIGNAL.
Filter terminal (berita, volume, quant, risiko portofolio) tetap dijalankan di atas aturan dokumen.
"""
