"""Menu SIGNAL saat strategi ONE aktif (admin & user): list pair, chart live, order ONE terbuka / limit / tertutup.
Sama seperti board 10 metode: TIDAK memuat isi analisa (zona, struktur, checklist) - itu hanya di signal/detail (admin)."""
import time

from ...providers import yahoo
from ...universe import BY_SYM
from .. import control
from ..board import CHART_PERIOD, CHART_BARS, CLOSED_SHOWN, _epoch, _num
from ..config import MODES
from . import journal as J, service as OS

STATUS_TXT = {"TP2": "TP2 tercapai", "TP1": "TP1 lalu breakeven", "SL": "Kena SL", "CANCEL": "Dibatalkan", "EXPIRED": "Batal (tidak terisi 36 bar)",
              "MISSED": "Batal (TP1 tersentuh lebih dulu)", "PENDING": "Menunggu E1/E2", "OPEN": "Berjalan"}


async def chart(sym, mode):
    a = BY_SYM[sym.upper()]
    cfg = MODES[mode]
    df = await yahoo.live_ohlcv(a["y"], CHART_PERIOD[mode], cfg["yf_interval"])
    if df is None or len(df) == 0:
        raise ValueError(f"data harga {a['sym']} tidak tersedia dari sumber")
    price = float(df["c"].iloc[-1])
    nd = OS.digits(price)
    tail = df.iloc[-CHART_BARS:]
    candles = [[_epoch(t), _num(o, nd), _num(h, nd), _num(l, nd), _num(c, nd)] for t, o, h, l, c in zip(tail.index, tail["o"].values, tail["h"].values, tail["l"].values, tail["c"].values)]
    prev = float(df["c"].iloc[-2]) if len(df) > 1 else price
    act = [r for r in J.active_all(a["sym"]) if r["mode"] == mode]
    orders = [OS.summary_row(r) for r in act]
    for o in orders:
        if o.get("price") is None:
            o["price"] = _num(price, nd)
    return dict(symbol=a["sym"], name=a["name"], tf=cfg["tf"], minutes=cfg["minutes"], digits=nd, price=_num(price, nd), prev=_num(prev, nd),
                candles=candles, asof=_epoch(df.index[-1]), orders=orders, order=orders[-1] if orders else None)


async def build(symbol=""):
    ctl = control.get()
    mode = ctl["mode"]
    cfg = MODES[mode]
    assets = [BY_SYM[s.upper()] for s in ctl["pairs"] if s.upper() in BY_SYM]
    syms = [a["sym"] for a in assets]
    want = BY_SYM.get(str(symbol).strip().upper(), {}).get("sym")
    sel = want if want in syms else (syms[0] if syms else None)
    quotes = {}
    if assets:
        try:
            quotes = await yahoo.quotes(tuple(a["y"] for a in assets))
        except Exception:
            quotes = {}
    ch, err = None, None
    if sel:
        try:
            ch = await chart(sel, mode)
        except Exception as exc:
            err = f"{type(exc).__name__}: {str(exc)[:160]}"
    rows = J.recent(2000)
    opens, limits, closed, marks = [], [], [], {}
    for r in rows:
        st = r["status"]
        if st in J.ACTIVE:
            o = OS.summary_row(r)
            if o.get("price") is None:
                q = quotes.get((BY_SYM.get(r["sym"].upper()) or {}).get("y"))
                if q and q.get("price") is not None:
                    o["price"] = _num(q["price"], o["digits"])
            (limits if st == "PENDING" else opens).append(o)
            m = marks.setdefault(r["sym"], dict(open=0, limit=0, side=o["side"], type=o["type"]))
            m["limit" if st == "PENDING" else "open"] += 1
        elif len(closed) < CLOSED_SHOWN:
            o = OS.summary_row(r)
            o["status_txt"] = STATUS_TXT.get(st, st)
            closed.append(o)
    for o in opens + limits:
        o["status_txt"] = STATUS_TXT.get(o["status"], o["status"])
    st = J.stats()
    stats = dict(n=st["n"], win=st["win"], sum_r=round(st["sum_r"], 2), avg_r=round(st["avg_r"], 2) if st["avg_r"] is not None else None,
                 float_r=round(sum((o.get("r") or 0.0) for o in opens), 2), cancelled=st["signals"] - st["n"],
                 fill_rate=round(st["fill_rate"], 3) if st["fill_rate"] is not None else None, by_type=st["by_type"])
    pairs = []
    for a in assets:
        q = quotes.get(a["y"]) or {}
        price = ch["price"] if ch and a["sym"] == sel else q.get("price")
        m = marks.get(a["sym"])
        pairs.append(dict(sym=a["sym"], name=a["name"], cls=a["cls"], price=price, pct=q.get("pct"), digits=OS.digits(price) if price else 5,
                          open=m["open"] if m else 0, limit=m["limit"] if m else 0, side=m["side"] if m else None, type=m["type"] if m else None))
    return dict(strategy="one", now=int(time.time()), mode=mode, mode_label=cfg["label"], tf=cfg["tf"], symbol=sel, pairs=pairs, chart=ch, chart_error=err,
                orders=dict(open=opens, limit=limits, closed=closed, stats=stats))
