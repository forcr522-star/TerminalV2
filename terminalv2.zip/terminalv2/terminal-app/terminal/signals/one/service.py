"""Strategi ONE untuk satu pair: data -> engine (bar tertutup saja) -> filter terminal -> jurnal -> payload menu SIGNAL.

Filter dokumen (K1-K6, batas harian, kunci re-entry) dan filter terminal yang bisa dihitung per bar tanpa melihat masa
depan (volume pemicu, lonjakan volatilitas, statistik walk-forward per tipe setup) dijalankan DI DALAM engine. Filter yang
hanya ada "saat ini" - berita/kejadian mendadak (fundamental), batas risiko portofolio, aturan JPY (RM4) dan rugi harian
seluruh akun - diperiksa saat setup akan diterbitkan. Setup yang ditahan dicatat (veto) dan engine diputar ulang tanpa
setup itu, sehingga keadaan engine (K3, batas harian) selalu sama dengan yang benar-benar diterbitkan.
"""
import json
import math
import time
import types

import pandas as pd

from ... import store
from ...universe import BY_SYM
from ..config import MODES, RISK, SWAP_FRAC_PER_DAY, cluster_of
from . import journal as J
from .contract import quote_of, spec_of
from .engine import Engine, lots
from .params import PARAMS, SPREAD_FRAC

ONE_BARS = 4000            # bar tertutup terakhir yang diputar ulang (M5: +-14 hari pasar 24 jam)
MIN_BARS = 300
EQUITY = 10000.0           # contoh ekuitas untuk lot di tampilan (USD); risiko = Risk_Percent dokumen
LIVE = {}                  # key setup -> keadaan live untuk tabel order
VETO_KEY = "one_veto:"


def digits(price):
    p = abs(price or 0)
    return 2 if p >= 1000 else 3 if p >= 100 else 4 if p >= 10 else 5


def _r(v, nd=6):
    if v is None:
        return None
    try:
        f = float(v)
    except Exception:
        return None
    return None if not math.isfinite(f) else round(f, nd)


def completed(df, minutes, now=None):
    from ..service import completed as _c
    return _c(df, minutes, now)


# ------------------------------------------------------------------------------------------- veto (filter "saat ini")
def veto_get(sym, mode):
    try:
        v = store.kv_get(f"{VETO_KEY}{sym}:{mode}", []) or []
    except Exception:
        v = []
    return v


def veto_add(sym, mode, key, reason):
    v = [x for x in veto_get(sym, mode) if x.get("key") != key]
    v.append(dict(key=key, reason=reason, at=time.time()))
    try:
        store.kv_set(f"{VETO_KEY}{sym}:{mode}", v[-300:])
    except Exception:
        pass


def live_veto(sym, side, fund):
    """Filter terminal yang hanya bisa dinilai saat ini. None bila lolos."""
    blk = (fund or {}).get("block")
    if blk:
        return f"BERITA: {blk}"
    if J.day_r(PARAMS["Session_TZ_Hours"]) <= -PARAMS["Max_Daily_Loss_R"]:
        return f"RM2: rugi akun hari ini >= {PARAMS['Max_Daily_Loss_R']}R (semua pair)"
    from .. import journal as MJ
    rows_one = J.active_all()
    rows_multi = MJ.active_all()
    n_open = len(rows_one) + len(rows_multi)
    if n_open >= RISK["max_open"]:
        return f"RISIKO: batas posisi terbuka ({RISK['max_open']}) tercapai"
    cl = cluster_of(sym)
    if sum(1 for r in rows_one + rows_multi if cluster_of(r["sym"]) == cl) >= RISK["max_cluster"]:
        return f"RISIKO: batas posisi per cluster {cl} ({RISK['max_cluster']}) tercapai"
    risk_open = len(rows_one) * PARAMS["Risk_Percent"] / 100 + sum(float((r["plan"] or {}).get("risk_pct") or 0) / 100 for r in rows_multi)
    if risk_open + PARAMS["Risk_Percent"] / 100 > RISK["max_open_risk"] + 1e-9:
        return f"RISIKO: batas risiko portofolio ({RISK['max_open_risk'] * 100:.1f}%) tercapai"
    if sym.upper().endswith("JPY"):
        same = [r for r in rows_one if r["sym"].upper().endswith("JPY") and r["side"] == side and r["sym"] != sym]
        if len(same) >= 2:
            return "RM4: sudah 2 pasangan JPY dengan arah yang sama"
    return None


# ------------------------------------------------------------------------------------------- engine
def _engine(df, a, mode, veto_keys):
    cfg = MODES[mode]
    ts = [int(pd.Timestamp(x).timestamp()) for x in df.index]
    sp = SPREAD_FRAC.get(a["cls"], 0.0001)
    swap = SWAP_FRAC_PER_DAY.get(a["cls"], 0.00001) / max(1, cfg["bars_per_day"])
    vol = df["v"].values if "v" in df else None
    E = Engine(df["o"].values, df["h"].values, df["l"].values, df["c"].values, ts, v=vol, cost=2 * sp, swap_bar=swap, spread_frac=sp,
               bar_sec=cfg["minutes"] * 60, veto=veto_keys)
    return E.run()


def _plan_of(s, E, a, mode, nd, vpu):
    d = s.as_dict(E.ts)
    lt = lots(EQUITY, PARAMS["Risk_Percent"], d["E1"], d["E2"], d["SL"], vpu) if vpu else None
    keep = ("type", "side", "E1", "E2", "SL", "sl_now", "TP1", "TP2", "rr_final", "score", "reentry_no", "invalidation", "tp1_src", "tp2_src",
            "zone", "backup", "pivots", "trigger", "checks", "filters", "atr", "unit", "sl_adjusted", "status", "reason", "exit_reason", "tp1_done",
            "fill_bar", "closed_bar", "mfe", "mae")
    out = {k: d.get(k) for k in keep}
    out.update(created_ts=d["created_ts"], expiry_bars=PARAMS["Pending_Expiry_Bars"], digits=nd, tf=MODES[mode]["tf"], tf_minutes=MODES[mode]["minutes"],
               lots=lt, equity=EQUITY, risk_pct=PARAMS["Risk_Percent"], strategy="one",
               fill_ts=E.ts[s.fill_bar] if s.fill_bar is not None else None, closed_ts=E.ts[s.closed_bar] if s.closed_bar is not None else None)
    return out


def _live(s, price):
    """R terealisasi + mengambang posisi terbuka (harga terakhir, termasuk bar berjalan)."""
    r_real = s.pnl - s.cost_acc - s.swap_acc
    r_float = 0.0
    if s.status == "OPEN" and price is not None:
        pn = s.d * price
        r_float = sum(g["open"] * (pn - g["entry_n"]) / s.unit for g in s.legs)
    return dict(status=s.status, price=price, r_real=r_real, r_float=r_float, r_total=r_real + r_float, tp1_done=s.tp1_done,
                sl_now=s.px(s.sl_now_n), e2_filled=len(s.legs) > 1, fill_bar=s.fill_bar)


# ------------------------------------------------------------------------------------------- inti sinkron (thread CPU)
def analyze_frame(df_all, sym, mode, fund=None, now=None, use_journal=True, new_ok=None, vpu=None, issue=True):
    cfg = MODES[mode]
    a = BY_SYM[sym.upper()]
    df = completed(df_all, cfg["minutes"], now).iloc[-ONE_BARS:]
    if len(df) < MIN_BARS:
        raise ValueError(f"data {cfg['tf']} tidak cukup untuk strategi ONE ({len(df)} bar, perlu {MIN_BARS})")
    veto = veto_get(a["sym"], mode) if use_journal else []
    veto_keys = {v["key"] for v in veto}
    E = _engine(df, a, mode, veto_keys)
    last = E.n - 1
    price_live = float(df_all["c"].iloc[-1])
    nd = digits(price_live)
    issued, vetoed_now = [], []
    if use_journal:
        known = {r["key"]: r for r in J.recent(400, a["sym"], mode)}
        for _ in range(3):                                         # terbitkan setup PENDING baru; veto -> putar ulang tanpa setup itu
            fresh = [s for s in E.active if s.status == "PENDING" and s.key not in known and s.key not in veto_keys]
            if not fresh or not issue or (new_ok is not None and not new_ok()):
                break
            changed = False
            for s in fresh:
                why = live_veto(a["sym"], "BUY" if s.d > 0 else "SELL", fund)
                if why:
                    veto_add(a["sym"], mode, s.key, why)
                    veto_keys.add(s.key)
                    vetoed_now.append(dict(key=s.key, type=s.type, side="BUY" if s.d > 0 else "SELL", reason=why))
                    changed = True
            if changed:
                E = _engine(df, a, mode, veto_keys)
                continue
            for s in fresh:
                plan = _plan_of(s, E, a, mode, nd, vpu)
                rid = J.create(s.key, a["sym"], mode, s.type, "BUY" if s.d > 0 else "SELL", str(df.index[s.created]), plan)
                issued.append(rid)
                known[s.key] = J.by_key(s.key)
            break
        eng = {s.key: s for s in E.setups}
        for row in J.active_all(a["sym"]):
            if row["mode"] != mode:
                continue
            s = eng.get(row["key"])
            if s is None:
                continue                                           # di luar jendela putar ulang: status terakhir dipertahankan
            r = s.pnl - s.cost_acc - s.swap_acc
            plan = _plan_of(s, E, a, mode, nd, vpu)
            if s.status != row["status"] or s.status in ("PENDING", "OPEN"):
                J.update(row["id"], s.status, r if s.status not in ("CANCEL", "EXPIRED", "MISSED") else 0.0, plan=plan, note=s.reason)
            if s.status in ("PENDING", "OPEN"):
                LIVE[s.key] = dict(_live(s, price_live), sym=a["sym"], asof=int(time.time()))
            else:
                LIVE.pop(s.key, None)
    return build_payload(E, df, df_all, a, mode, fund, nd, vpu, issued, vetoed_now, veto)


# ------------------------------------------------------------------------------------------- payload
def build_payload(E, df, df_all, a, mode, fund, nd, vpu, issued, vetoed_now, veto):
    cfg = MODES[mode]
    S, P = E.S, E.P
    last = E.n - 1
    ts = E.ts
    T = lambda i: ts[i] if i is not None and 0 <= i < len(ts) else None   # noqa: E731
    price = float(df_all["c"].iloc[-1])
    atr = E.atr[last]
    act = [s for s in E.active if s.status in ("PENDING", "OPEN")]
    cur = act[-1] if act else None
    new = [s for s in E.setups if s.created == last]
    since = max(0, last - 200)

    def zone_out(z):
        d = z.as_dict()
        d.update(born_ts=T(z.born), base_first_ts=T(z.base_first), ended_ts=T(z.ended), impulse_ts=T(z.impulse_start))
        return d
    zones = [zone_out(z) for z in S.zones if (z.state not in ("BROKEN", "EXPIRED") or (z.ended or 0) >= since) and z.born >= since - 300]
    zones = sorted(zones, key=lambda z: -z["born"])[:40]
    levels = []
    for lv in S.levels:
        if lv.state == "ACTIVE" or (lv.ended or 0) >= since:
            dd = lv.as_dict()
            first = min(lv.swings) if lv.swings else lv.born
            dd.update(first_ts=T(first), born_ts=T(lv.born), ended_ts=T(lv.ended))
            if lv.sweep:
                dd["sweep"] = dict(lv.sweep, r_ts=T(lv.sweep["r"]), s_ts=T(lv.sweep["s"]))
            levels.append(dd)
    levels = sorted(levels, key=lambda x: -x["born"])[:30]
    swings = [dict(s.as_dict(), ts=T(s.index)) for s in S.swings[-60:]]
    pivots = [dict(p.as_dict(), ts=T(p.index)) for p in S.pivots[-14:]]
    bos = [dict(dir="BULL" if e["dir"] > 0 else "BEAR", bar=e["bar"], ts=T(e["bar"]), level=e["swing"].price, swing_ts=T(e["swing"].index), choch=e["choch"])
           for e in S.bos[-14:]]
    rng = dict(S.range, first_ts=T(S.range["first_index"]), last_ts=T(S.range["last_index"])) if S.range else None
    recent = sorted(E.setups, key=lambda s: -s.created)[:14]
    setups = [dict(s.as_dict(ts), created_ts=T(s.created), fill_ts=T(s.fill_bar), closed_ts=T(s.closed_bar)) for s in recent]
    for x in setups:
        x["live"] = _live(next(s for s in recent if s.key == x["key"]), price)
    diag = {k: dict(v, ts=T(v["bar"])) for k, v in E.diag.items()}
    real = [s for s in E.setups if s.status in ("TP2", "TP1", "SL")]
    rs = [s.pnl - s.cost_acc - s.swap_acc for s in real]
    type_stats = {t: E.type_stats(t) for t in "ABCDE"}
    day = E._dstat(last)
    pct = E._atr_pct(last)
    # ---------------------------------------------------------------- daftar cek keputusan (Bagian 21) untuk bar terakhir
    trig = []
    if S.ev_pivot_changed.get(1):
        trig.append("pivot HIGH baru (A/C buy)")
    if S.ev_pivot_changed.get(-1):
        trig.append("pivot LOW baru (A/C sell)")
    if S.ev_bos:
        trig.append(", ".join(("CHoCH " if e["choch"] else "BOS ") + ("bullish" if e["dir"] > 0 else "bearish") for e in S.ev_bos))
    if E.btrig[1] or E.btrig[-1]:
        trig.append("menunggu swing baru sesudah break (setup B)")
    if S.ev_sweeps:
        trig.append(f"{len(S.ev_sweeps)} sweep likuiditas")
    last_diag = max(E.diag.values(), key=lambda v: v["bar"]) if E.diag else None
    ses_ok = E._session_ok(last)
    check = [
        dict(item="Bar baru tertutup", ok=True, note=f"bar {str(df.index[-1])[:16]} UTC"),
        dict(item="Update swing, pivot, BOS, zona, likuiditas", ok=True,
             note=f"{len(S.swings)} swing · {len(S.bos)} BOS · {sum(1 for z in S.live_zones if z.state in ('FRESH', 'TESTED'))} zona FRESH/TESTED · {sum(1 for lv in S.live_levels)} level likuiditas aktif"),
        dict(item="Filter konteks (sesi, harian, setup aktif)", ok=ses_ok and day["r"] > -P["Max_Daily_Loss_R"] and day["n"] < P["Max_NewSetups_Per_Day"],
             note=("sesi 07:00-23:00 UTC+7 " + ("buka" if ses_ok else "TUTUP")) + f" · hari ini {day['n']} setup, {day['r']:+.2f}R" + (f" · setup aktif #{cur.id}" if cur else "")),
        dict(item="Ada pemicu (pivot A/C, BOS B, sweep+BOS D, TP2 E)?", ok=bool(trig), note="; ".join(trig) if trig else "tidak ada pemicu di bar terakhir"),
    ]
    if last_diag:
        check.append(dict(item="Evaluasi setup terakhir", ok=last_diag["ok"], note=f"{last_diag['type']} {last_diag['side']} ({str(df.index[last_diag['bar']])[:16]}): {last_diag['code']} - {last_diag['msg']}"))
    if cur:
        dd = cur.as_dict(ts)
        risk_atr = (cur.E1n - cur.SLn) / max(1e-12, cur.atr)
        check += [
            dict(item="Zona FRESH/TESTED/FLIP yang cocok (atau PRZ / garis LVL)?", ok=True,
                 note=(f"zona #{dd['zone']['id']} {dd['zone']['state']}" + (" FLIP" if dd['zone']['is_flip'] else "") if dd.get("zone") else "tanpa zona (PRZ / garis level / proyeksi)")),
            dict(item=f"SL dalam [{P['SL_Min_ATR']}, {P['SL_Max_ATR']}] ATR?", ok=P["SL_Min_ATR"] - 1e-9 <= risk_atr <= P["SL_Max_ATR"], note=f"{risk_atr:.2f} ATR" + (" (diperlebar V1)" if dd.get("sl_adjusted") else "")),
            dict(item="TP1 RR >= 1.0 dan TP2 RR >= 1.5?", ok=True, note=f"TP1 {(cur.TP1n - cur.E1n) / (cur.E1n - cur.SLn):.2f}R · TP2 {cur.rr_final():.2f}R"),
            dict(item="Harga belum melewati E1 saat dipasang?", ok=True, note="lolos V3"),
            dict(item="Skor tertinggi -> lot -> 2 limit order", ok=True, note=f"skor {cur.score} · tipe {cur.type}"),
            dict(item="Zona cadangan & level invalidasi disimpan", ok=True,
                 note=("cadangan: " + ("zona" if (dd.get("backup") or {}).get("kind") == "zone" else "PRZ" if dd.get("backup") else "tidak ada")) + f" · invalidasi {dd['invalidation']:.{nd}f}"),
        ]
    # ---------------------------------------------------------------- filter
    fl = (fund or {})
    sh = fl.get("shock") or {}
    filters = dict(
        news=dict(ok=not fl.get("block"), block=fl.get("block"), note=fl.get("note"),
                  shock=dict(score=sh.get("score"), guard=bool(sh.get("guard")), n=len(sh.get("matched") or [])) if sh else None),
        volume=dict(has_volume=E._has_volume, min_rvol=P["Term_Volume_MinRVOL"],
                    last=(cur.filters.get("volume") if cur else None)),
        quant=dict(atr_pct=pct, spike_max=P["Term_Quant_SpikePct"], spike=bool(pct is not None and pct > P["Term_Quant_SpikePct"]),
                   min_n=P["Term_Quant_MinN"], gate_lcb=P["Term_Quant_GateLCB"],
                   types={t: dict(v, blocked=bool(v["n"] >= P["Term_Quant_MinN"] and v["lcb"] is not None and v["lcb"] <= P["Term_Quant_GateLCB"])) for t, v in type_stats.items()}),
        risk=dict(day_r=day["r"], day_n=day["n"], max_day_r=P["Max_Daily_Loss_R"], max_day_n=P["Max_NewSetups_Per_Day"],
                  account_day_r=J.day_r(P["Session_TZ_Hours"]), locks={("BUY" if k > 0 else "SELL"): v for k, v in E.locks.items()}),
        vetoed=vetoed_now, veto_recent=veto[-8:],
    )
    blocked = [e for e in E.events if e["kind"] == "blocked"][-12:]
    for e in blocked:
        e["ts"] = T(e["bar"])
    lt = None
    if cur and vpu:
        lt = lots(EQUITY, P["Risk_Percent"], cur.px(cur.E1n), cur.px(cur.E2n), cur.px(cur.SLn), vpu)
    size, unit, scale = spec_of(a)
    signal = ("BUY" if cur.d > 0 else "SELL") if cur else "WAIT"
    state = ("NEW" if cur and cur.created == last else cur.status) if cur else "WAIT"
    reason = None
    if not cur:
        bl = blocked[-1] if blocked and blocked[-1]["bar"] >= last - 3 else None
        reason = (f"{bl['type']} {bl['side']} ditahan {bl['code']}: {bl['msg']}" if bl else
                  (f"{last_diag['type']} {last_diag['side']}: {last_diag['code']} - {last_diag['msg']}" if last_diag else "belum ada setup"))
    k = min(E.n, 160)
    candles = [[ts[i], _r(E.o[i], nd), _r(E.h[i], nd), _r(E.l[i], nd), _r(E.c[i], nd)] for i in range(E.n - k, E.n)]
    one = dict(
        setup=(dict(cur.as_dict(ts), created_ts=T(cur.created), fill_ts=T(cur.fill_bar), live=_live(cur, price)) if cur else None),
        new=[s.key for s in new], issued=issued, setups=setups,
        structure=dict(trend=S.trend(), last_bos=bos[-1] if bos else None, swings=swings, pivots=pivots, bos=bos),
        zones=zones, liquidity=levels, range=rng, diag=diag, checklist=check, filters=filters, blocked=blocked,
        stats=dict(window=dict(n=len(rs), sum_r=sum(rs), win=(sum(1 for x in rs if x > 0) / len(rs)) if rs else None,
                               placed=len(E.setups), bars=E.n, first_ts=ts[0], last_ts=ts[-1]),
                   types=type_stats, journal=J.stats(a["sym"], mode)),
        lots=lt, contract=dict(size=size, unit=unit, scale=scale, quote=quote_of(a), value_per_unit_usd=vpu, equity=EQUITY, risk_pct=P["Risk_Percent"]),
        params=dict(tf=cfg["tf"], fractal=[P["Fractal_Left"], P["Fractal_Right"]], session="07:00-23:00 UTC+7", expiry=P["Pending_Expiry_Bars"]),
        candles=candles,
    )
    sh_out = None
    if sh:
        sh_out = dict(score=sh.get("score"), guard=sh.get("guard"), reaction=sh.get("reaction"),
                      events=[dict(type=m["type"], title=m["title"][:140], place=m["place"], ts=m["ts"], sev=m["sev"], sources=m["sources"], expected=m["expected"])
                              for m in (sh.get("matched") or [])[:4]])
    return dict(strategy="one", symbol=a["sym"], name=a["name"], cls=a["cls"], mode=mode, mode_label=cfg["label"], tf=cfg["tf"], htf=cfg["htf_label"],
                be=True, bars=E.n, asof=str(df.index[-1] + pd.Timedelta(minutes=cfg["minutes"])), price=_r(price, nd), atr=_r(atr, nd), digits=nd,
                signal=signal, state=state, reason=reason, plan=None, votes=None, one=one,
                layers=dict(fundamental=dict(score=_r(fl.get("score"), 2), conf=_r(fl.get("conf"), 2), block=fl.get("block"), drivers=fl.get("drivers", []),
                                             note=fl.get("note"), shock=sh_out, world=fl.get("world")),
                            quant=dict(atr_pct=_r(pct, 3))))


# ------------------------------------------------------------------------------------------- async
async def usd_per_unit(a):
    """Nilai 1.0 pergerakan harga per 1 lot dalam USD (ukuran kontrak x skala x kurs kuotasi->USD)."""
    size, _u, scale = spec_of(a)
    q = quote_of(a)
    if q == "USD":
        return size * scale
    from ...providers import yahoo
    direct, inv = BY_SYM.get((q + "USD").upper()), BY_SYM.get(("USD" + q).upper())
    try:
        if direct:
            p = (await yahoo.quotes((direct["y"],))).get(direct["y"], {}).get("price")
            return size * scale * p if p else None
        if inv:
            p = (await yahoo.quotes((inv["y"],))).get(inv["y"], {}).get("price")
            return size * scale / p if p else None
        y = f"{q}=X"
        p = (await yahoo.quotes((y,))).get(y, {}).get("price")
        return size * scale / p if p else None
    except Exception:
        return None


async def analyze(sym, mode, new_ok=None, issue=True):
    from ... import cpu
    from ...providers import yahoo
    from .. import fundamental
    a = BY_SYM.get(sym.upper())
    if not a:
        raise ValueError(f"simbol tidak dikenal: {sym}")
    if mode not in MODES:
        raise ValueError("mode harus scalp/intraday/swing")
    cfg = MODES[mode]
    df = await yahoo.ohlcv(a["y"], cfg["yf_period"], cfg["yf_interval"])
    if df is None or len(df) == 0:
        raise ValueError(f"data harga {sym} tidak tersedia dari sumber")
    fund = None
    try:
        fund = await fundamental.gather(a["sym"], mode)
        fund = _shock(fund, df, mode)
    except Exception:
        fund = None
    vpu = await usd_per_unit(a)
    return await cpu.run(analyze_frame, df, a["sym"], mode, fund, None, True, new_ok, vpu, issue)


def _shock(fund, df, mode):
    """Penahan kejadian mendadak memakai fungsi yang sama dengan strategi 10 metode (reaksi harga bar tutup)."""
    if not fund or not fund.get("shock"):
        return fund
    from ..service import shock_check, completed as _c
    from .core import atr_mt5
    cfg = MODES[mode]
    d2 = _c(df, cfg["minutes"])
    h, l, c = d2["h"].tolist(), d2["l"].tolist(), d2["c"].tolist()
    atr = [x if x is not None else float("nan") for x in atr_mt5(h, l, c, PARAMS["ATR_Period"])]
    x = types.SimpleNamespace(n=len(c), c=c, atr=atr)
    try:
        return shock_check(fund, d2, x, mode)
    except Exception:
        return fund


def summary_row(row, live=None):
    """Satu order ONE untuk tabel menu SIGNAL."""
    pl = row["plan"] or {}
    st = row["status"]
    nd = pl.get("digits") or digits(pl.get("E1"))
    e1, sl = pl.get("E1"), pl.get("SL")
    risk = abs((e1 or 0) - (sl or 0))
    rr = [round(abs(t - e1) / risk, 2) if (t is not None and risk) else None for t in (pl.get("TP1"), pl.get("TP2"))]
    out = dict(id=row["id"], key=row["key"], sym=row["sym"], name=(BY_SYM.get(row["sym"].upper()) or {}).get("name", row["sym"]), type=row["type"],
               side="LONG" if row["side"] == "BUY" else "SHORT", kind=(("BUY" if row["side"] == "BUY" else "SELL") + (" LIMIT" if st == "PENDING" else "")),
               digits=nd, tf=pl.get("tf"), tf_minutes=pl.get("tf_minutes"), E1=e1, E2=pl.get("E2"), SL=sl, TP1=pl.get("TP1"), TP2=pl.get("TP2"), rr=rr,
               rr_final=pl.get("rr_final"), score=pl.get("score"), status=st, reason=row.get("note") or pl.get("reason"), created=row["created"],
               closed=row["closed"], issued=pl.get("created_ts"), expiry_bars=pl.get("expiry_bars"), lots=pl.get("lots"), r=None, tp1_done=pl.get("tp1_done"),
               sl_now=pl.get("sl_now"), fill_ts=pl.get("fill_ts"), reentry_no=pl.get("reentry_no"), zone=pl.get("zone"), strategy="one")
    if st in J.ACTIVE:
        lv = live or LIVE.get(row["key"]) or {}
        out.update(price=lv.get("price"), r=_r(lv.get("r_total"), 2) if lv else None, r_real=_r(lv.get("r_real"), 2) if lv else None,
                   tp1_done=lv.get("tp1_done", out["tp1_done"]), sl_now=lv.get("sl_now", out["sl_now"]), e2_filled=lv.get("e2_filled"))
        if st == "PENDING" and lv.get("price") is not None and risk:
            out["dist_r"] = round(abs(lv["price"] - e1) / risk, 2)
    else:
        out["r"] = None if st in J.CANCELLED else round(float(row["r"]), 2)
    return out
