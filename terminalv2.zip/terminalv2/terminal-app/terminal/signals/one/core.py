"""Strategi ONE - algoritma dasar (dokumen Bagian 6): ATR, swing (fractal), pivot bergantian, BOS/CHoCH, zona
demand/supply + status + flip, level likuiditas (equal highs/lows, range) dan sweep.

Semua diproses BAR DEMI BAR hanya dengan bar yang sudah tertutup (Bagian 4, R1-R7):
  - swing di bar i baru dipakai mulai bar i + Fractal_Right (confirmed_at);
  - zona lahir pada close bar impuls; status zona diperbarui berurutan;
  - break/BOS hanya dengan CLOSE.

Arah: d = +1 (BUY / demand / swing low dibutuhkan untuk entry) atau -1 (SELL). Aturan ditulis untuk BUY lalu dipakai
untuk SELL lewat "ruang ternormalisasi": harga' = d * harga, low' = low bila d=+1 atau -high bila d=-1 (cerminan
Bagian 6.10: High<->Low, atas<->bawah, max<->min, demand<->supply).
"""
import math

HIGH, LOW = 1, -1


class Swing:
    __slots__ = ("type", "index", "price", "confirmed_at", "broken")

    def __init__(self, typ, index, price, confirmed_at):
        self.type, self.index, self.price, self.confirmed_at, self.broken = typ, index, price, confirmed_at, False

    def as_dict(self):
        return dict(type="HIGH" if self.type == HIGH else "LOW", index=self.index, price=self.price, confirmed_at=self.confirmed_at)


class Zone:
    __slots__ = ("id", "dir", "born", "impulse_start", "base_first", "base_last", "wick_top", "wick_bottom", "body_top", "body_bottom",
                 "validated", "is_flip", "visits", "inside", "state", "ended", "mitigated")

    def __init__(self, zid, d, born, s, bf, bl, wt, wb, bt, bb, is_flip=False):
        self.id, self.dir, self.born, self.impulse_start, self.base_first, self.base_last = zid, d, born, s, bf, bl
        self.wick_top, self.wick_bottom, self.body_top, self.body_bottom = wt, wb, bt, bb
        self.validated, self.is_flip, self.visits, self.inside = False, is_flip, 0, False
        self.state, self.ended, self.mitigated = "FRESH", None, False

    # interval dalam ruang ternormalisasi arah d: (bawah', atas')
    def lo_n(self, d):
        return self.wick_bottom if d > 0 else -self.wick_top

    def hi_n(self, d):
        return self.wick_top if d > 0 else -self.wick_bottom

    def usable(self):
        """Boleh dipakai entry: FRESH/TESTED (termasuk zona flip), tidak sedang disentuh (6.6)."""
        return self.state in ("FRESH", "TESTED") and not self.inside and not self.mitigated

    def score(self):
        """Komponen skor zona (Bagian 17): +2 FRESH, +1 TESTED, +2 FLIP, +2 validated."""
        return (2 if self.state == "FRESH" else 1 if self.state == "TESTED" else 0) + (2 if self.is_flip else 0) + (2 if self.validated else 0)

    def as_dict(self):
        return dict(id=self.id, dir="DEMAND" if self.dir > 0 else "SUPPLY", born=self.born, impulse_start=self.impulse_start,
                    base_first=self.base_first, base_last=self.base_last, wick_top=self.wick_top, wick_bottom=self.wick_bottom,
                    body_top=self.body_top, body_bottom=self.body_bottom, validated=self.validated, is_flip=self.is_flip,
                    visits=self.visits, inside=self.inside, state="MITIGATED" if self.mitigated and self.state in ("FRESH", "TESTED", "WEAK") else self.state,
                    ended=self.ended)


class Liq:
    """Level likuiditas (6.8): dir = +1 HIGHS (di atas harga), -1 LOWS. kind EQUAL | RANGE."""
    __slots__ = ("id", "dir", "price", "swings", "state", "kind", "born", "pending", "ended", "sweep")

    def __init__(self, lid, d, price, swings, kind, born):
        self.id, self.dir, self.price, self.swings, self.kind, self.born = lid, d, price, list(swings), kind, born
        self.state, self.pending, self.ended, self.sweep = "ACTIVE", None, None, None

    def as_dict(self):
        return dict(id=self.id, dir="HIGHS" if self.dir > 0 else "LOWS", price=self.price, swings=list(self.swings), state=self.state,
                    kind=self.kind, born=self.born, ended=self.ended, sweep=self.sweep)


def atr_mt5(h, l, c, period):
    """ATR seperti iATR MetaTrader 5: rata-rata sederhana True Range `period` bar (bar pertama: High-Low)."""
    n = len(c)
    tr = [0.0] * n
    for i in range(n):
        tr[i] = h[i] - l[i] if i == 0 else max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
    out = [None] * n
    s = 0.0
    for i in range(n):
        s += tr[i]
        if i >= period:
            s -= tr[i - period]
        if i >= period:
            out[i] = s / period
    return out


class Structure:
    """Keadaan struktur pasar yang diperbarui per bar tertutup (Bagian 6). Dipakai Engine (setup & order)."""

    def __init__(self, o, h, l, c, atr, P):
        self.o, self.h, self.l, self.c, self.atr, self.P = o, h, l, c, atr, P
        self.n = len(c)
        self.swings = []                          # semua swing terkonfirmasi, urut konfirmasi
        self.by_type = {HIGH: [], LOW: []}
        self.unbroken = {HIGH: [], LOW: []}       # swing yang belum ditembus BOS (urut index)
        self.pivots = []
        self.bos = []                             # dict(dir, bar, swing, choch)
        self.last_bos_dir = 0
        self.zones = []
        self.live_zones = []                      # zona yang belum BROKEN/EXPIRED (diperbarui tiap bar)
        self.zone_seq = 0
        self._by_impulse = set()
        self._pending_valid = []                  # zona yang masih menunggu BOS dalam jendela validasi
        self.levels = []
        self.live_levels = []                     # level ACTIVE
        self.liq_seq = 0
        self.range = None
        self.prev_range = None
        self.sweeps = []                          # dict(dir=arah trade (+1 sapu lows), level, price, r, sweep_low_n)
        # peristiwa bar terakhir (diisi ulang setiap step)
        self.ev_swings, self.ev_pivot_changed, self.ev_replaced, self.ev_bos, self.ev_sweeps = [], {HIGH: False, LOW: False}, [], [], []

    # ------------------------------------------------------------------ util ternormalisasi
    def low_n(self, k, d):
        return self.l[k] if d > 0 else -self.h[k]

    def high_n(self, k, d):
        return self.h[k] if d > 0 else -self.l[k]

    def close_n(self, k, d):
        return d * self.c[k]

    def min_low_n(self, a, b, d):
        """min low' pada bar a..b (inklusif); +inf bila kosong."""
        if b < a:
            return math.inf
        return min(self.l[a:b + 1]) if d > 0 else -max(self.h[a:b + 1])

    def max_high_n(self, a, b, d):
        if b < a:
            return -math.inf
        return max(self.h[a:b + 1]) if d > 0 else -min(self.l[a:b + 1])

    # ------------------------------------------------------------------ 6.2 swing
    def _is_high(self, i):
        L, R, h = self.P["Fractal_Left"], self.P["Fractal_Right"], self.h
        hi = h[i]
        for j in range(i - L, i):
            if not hi > h[j]:
                return False
        for j in range(i + 1, i + R + 1):
            if not hi >= h[j]:
                return False
        return True

    def _is_low(self, i):
        L, R, l = self.P["Fractal_Left"], self.P["Fractal_Right"], self.l
        lo = l[i]
        for j in range(i - L, i):
            if not lo < l[j]:
                return False
        for j in range(i + 1, i + R + 1):
            if not lo <= l[j]:
                return False
        return True

    def confirm_swings(self, t):
        i = t - self.P["Fractal_Right"]
        out = []
        if i - self.P["Fractal_Left"] < 0:
            return out
        hi, lo = self._is_high(i), self._is_low(i)
        if hi and lo:                                    # bar outside: urutan menurut warna bar (6.2)
            order = (LOW, HIGH) if self.c[i] >= self.o[i] else (HIGH, LOW)
        else:
            order = (HIGH,) if hi else (LOW,) if lo else ()
        for typ in order:
            s = Swing(typ, i, self.h[i] if typ == HIGH else self.l[i], t)
            self.swings.append(s)
            self.by_type[typ].append(s)
            self.unbroken[typ].append(s)
            out.append(s)
        return out

    # ------------------------------------------------------------------ 6.3 pivot bergantian
    def update_pivots(self, s):
        """Mengembalikan ('add'|'replace'|None, pivot_lama_yang_diganti)."""
        pv = self.pivots
        if not pv or pv[-1].type != s.type:
            pv.append(s)
            return "add", None
        last = pv[-1]
        if (s.type == HIGH and s.price > last.price) or (s.type == LOW and s.price < last.price):
            pv[-1] = s
            return "replace", last
        return None, None

    # ------------------------------------------------------------------ 6.4 BOS
    def update_bos(self, t):
        out = []
        for d in (HIGH, LOW):                          # d=+1: BOS bullish menembus swing HIGH; d=-1: bearish menembus swing LOW
            ub = self.unbroken[d]
            while ub and ub[-1].broken:
                ub.pop()
            if not ub:
                continue
            sh = ub[-1]                                  # konfirmasi selalu Fractal_Right bar sesudah swing -> terakhir = index terbesar
            if d * self.c[t] > d * sh.price:
                sh.broken = True
                ub.pop()
                ev = dict(dir=d, bar=t, swing=sh, choch=self.last_bos_dir == -d)
                self.last_bos_dir = d
                self.bos.append(ev)
                out.append(ev)
        return out

    def bos_in(self, d, a, b):
        """Ada BOS arah d dengan bar di (a, b]?"""
        for ev in reversed(self.bos):
            if ev["bar"] <= a:
                break
            if ev["dir"] == d and ev["bar"] <= b:
                return ev
        return None

    # ------------------------------------------------------------------ 6.5 zona
    def detect_zones(self, t):
        a = self.atr[t]
        if a is None or a <= 0:
            return []
        P, o, h, l, c = self.P, self.o, self.h, self.l, self.c
        made = []
        for d in (1, -1):
            body = d * (c[t] - o[t])
            if body < P["Run_MinBody_ATR"] * a:                                     # Z1
                continue
            s = t
            while s - 1 >= 0 and (t - (s - 1) + 1) <= P["Impulse_MaxBars"] and d * (c[s - 1] - o[s - 1]) >= P["Run_MinBody_ATR"] * a:
                s -= 1                                                              # Z2
            ok3 = False
            for k in range(s, t + 1):                                               # Z3
                b = d * (c[k] - o[k])
                rng = h[k] - l[k]
                if b >= P["Impulse_MinBody_ATR"] * a and rng > 0 and b / rng >= P["Impulse_MinBody_Ratio"]:
                    ok3 = True
                    break
            if not ok3 or (d, s) in self._by_impulse:                               # Z4
                continue
            best = None                                                             # Z5
            for n in range(P["Base_MinBars"], P["Base_MaxBars"] + 1):
                first = s - n
                if first < 0:
                    break
                new_bars = range(first, s) if n == P["Base_MinBars"] else (first,)   # tiap bar base <= Base_BarMaxRange
                if any(h[k] - l[k] > P["Base_BarMaxRange_ATR"] * a for k in new_bars):
                    break
                top, bot = max(h[first:s]), min(l[first:s])
                if top - bot <= P["Base_MaxRange_ATR"] * a:
                    best = n
                else:
                    break
            if best is None:
                continue
            first = s - best
            top, bot = max(h[first:s]), min(l[first:s])
            edge = top if d > 0 else -bot                                           # tepi base sisi impuls (ternormalisasi)
            if d * c[t] < edge + P["Impulse_MinMove_ATR"] * a:                      # Z6
                continue
            self.zone_seq += 1
            z = Zone(self.zone_seq, d, t, s, first, s - 1, top, bot,
                     max(max(o[k], c[k]) for k in range(first, s)), min(min(o[k], c[k]) for k in range(first, s)))
            self._by_impulse.add((d, s))
            if any(ev["dir"] == d and s <= ev["bar"] <= s + P["Validate_Window_Bars"] for ev in self.bos):   # Z7
                z.validated = True
            elif t < s + P["Validate_Window_Bars"]:
                self._pending_valid.append(z)
            self.zones.append(z)
            self.live_zones.append(z)
            made.append(z)
        return made

    def validate_pending(self, t, bos_now):
        if not self._pending_valid:
            return
        keep = []
        for z in self._pending_valid:
            if any(ev["dir"] == z.dir and z.impulse_start <= ev["bar"] <= z.impulse_start + self.P["Validate_Window_Bars"] for ev in bos_now):
                z.validated = True
            elif t < z.impulse_start + self.P["Validate_Window_Bars"]:
                keep.append(z)
        self._pending_valid = keep

    # ------------------------------------------------------------------ 6.6 / 6.7 status zona & flip
    def update_zone_states(self, t):
        flips = []
        P = self.P
        for z in self.live_zones:
            if t <= z.born:
                continue
            d = z.dir
            cl = d * self.c[t]
            if cl < z.lo_n(d):                                                       # 1. close menembus sisi distal
                z.state, z.ended = "BROKEN", t
                self.zone_seq += 1
                f = Zone(self.zone_seq, -d, t, None, z.base_first, z.base_last, z.wick_top, z.wick_bottom, z.body_top, z.body_bottom, is_flip=True)
                flips.append(f)
                continue
            lo = self.low_n(t, d)
            if lo <= z.hi_n(d) and not z.inside:                                     # 2. kunjungan baru
                z.visits += 1
                z.inside = True
            if lo > z.hi_n(d):                                                       # 3.
                z.inside = False
            z.state = "FRESH" if z.visits == 0 else "TESTED" if z.visits == 1 else "WEAK"   # 4.
            if t - z.born > P["Zone_MaxAge_Bars"]:                                   # 5.
                z.state, z.ended = "EXPIRED", t
        self.zones.extend(flips)
        self.live_zones = [z for z in self.live_zones if z.state not in ("BROKEN", "EXPIRED")] + flips
        return flips

    # ------------------------------------------------------------------ 6.8 / 6.9 likuiditas & sweep
    def _level_near(self, d, price, tol, kind=None):
        for lv in self.live_levels:
            if lv.dir == d and lv.state == "ACTIVE" and abs(lv.price - price) <= tol and (kind is None or lv.kind == kind):
                return lv
        return None

    def _equal_levels(self, t, typ):
        P, a = self.P, self.atr[t]
        if a is None:
            return
        tol = P["EqualLevel_Tol_ATR"] * a
        sw = self.by_type[typ][-P["EqualLevel_Lookback_Swings"]:]
        pts = sorted(sw, key=lambda s: s.price * (-typ))             # LOW: naik dari terendah; HIGH: turun dari tertinggi
        groups, cur = [], []
        for s in pts:
            if cur and abs(s.price - cur[0].price) > tol:
                groups.append(cur)
                cur = []
            cur.append(s)
        if cur:
            groups.append(cur)
        d = typ                                                       # HIGH -> level HIGHS (+1), LOW -> LOWS (-1)
        for g in groups:
            if len(g) < 2:
                continue
            price = min(s.price for s in g) if typ == LOW else max(s.price for s in g)
            anchor = min(s.index for s in g)
            if typ == LOW:
                ok = min(self.c[anchor:t + 1]) >= price
            else:
                ok = max(self.c[anchor:t + 1]) <= price
            lv = self._level_near(d, price, tol, "EQUAL")
            if lv:
                lv.price, lv.swings = price, sorted(s.index for s in g)
            elif ok:
                self.liq_seq += 1
                lv = Liq(self.liq_seq, d, price, sorted(s.index for s in g), "EQUAL", t)
                self.levels.append(lv)
                self.live_levels.append(lv)

    def _range(self, t):
        P, a = self.P, self.atr[t]
        self.prev_range = self.range
        self.range = None
        nb = P["Range_MinBars"]
        if a is None or t + 1 < nb:
            return
        first = t - nb + 1
        top, bot = max(self.h[first:t + 1]), min(self.l[first:t + 1])
        hgt = top - bot
        if hgt <= 0 or hgt > P["Range_MaxHeight_ATR"] * a:
            return
        band = P["Range_EdgeBand"] * hgt
        nh = sum(1 for s in self.by_type[HIGH] if s.index >= first and s.price >= top - band)
        nl = sum(1 for s in self.by_type[LOW] if s.index >= first and s.price <= bot + band)
        if nh < P["Range_MinTouchesPerSide"] or nl < P["Range_MinTouchesPerSide"]:
            return
        self.range = dict(top=top, bottom=bot, first_index=first, last_index=t, active=True)
        tol = P["EqualLevel_Tol_ATR"] * a
        for d, price in ((HIGH, top), (LOW, bot)):
            lv = self._level_near(d, price, tol, "RANGE")
            if lv:
                lv.price = price
            else:
                self.liq_seq += 1
                lv = Liq(self.liq_seq, d, price, [], "RANGE", t)
                self.levels.append(lv)
                self.live_levels.append(lv)

    def update_liquidity(self, t, new_swings):
        a = self.atr[t]
        self.ev_sweeps = []
        if a is None:
            return
        for typ in (HIGH, LOW):
            if any(s.type == typ for s in new_swings):
                self._equal_levels(t, typ)
        self._range(t)
        P = self.P
        for lv in self.live_levels:
            if lv.state != "ACTIVE" or lv.born >= t:
                continue
            side = -lv.dir                       # LOWS (dir -1) disapu oleh trade BUY (+1)
            # ruang ternormalisasi arah trade `side`: level lows di bawah harga = price' ; tembus = low' < price'
            pn = side * lv.price
            lo = self.low_n(t, side)
            cl = self.close_n(t, side)
            if lv.pending is None:
                if lo < pn:
                    lv.pending = t
                elif cl < pn:
                    lv.state, lv.ended = "BROKEN", t
                    continue
            if lv.pending is not None:
                s = lv.pending
                if cl > pn:                                                             # reclaim -> SWEEP di bar t
                    sl_n = self.min_low_n(s, t, side)
                    lv.state, lv.ended, lv.pending = "SWEPT", t, None
                    lv.sweep = dict(s=s, r=t, sweep=side * sl_n)
                    ev = dict(dir=side, level=lv.id, price=lv.price, r=t, s=s, sweep_low_n=sl_n, used=False, kind=lv.kind)
                    self.sweeps.append(ev)
                    self.ev_sweeps.append(ev)
                elif cl < pn - 0.5 * a or t >= s + P["Sweep_MaxReclaimBars"] - 1:     # close jauh / jendela reclaim habis
                    lv.state, lv.ended, lv.pending = "BROKEN", t, None
        self.live_levels = [lv for lv in self.live_levels if lv.state == "ACTIVE"]

    # ------------------------------------------------------------------ satu bar
    def step(self, t):
        self.ev_swings = self.confirm_swings(t)
        self.ev_pivot_changed = {HIGH: False, LOW: False}
        self.ev_replaced = []
        for s in self.ev_swings:
            how, old = self.update_pivots(s)
            if how:
                self.ev_pivot_changed[s.type] = True
            if old is not None:
                self.ev_replaced.append(old.index)
        self.ev_bos = self.update_bos(t)
        self.validate_pending(t, self.ev_bos)
        self.ev_zones = self.detect_zones(t)
        self.ev_flips = self.update_zone_states(t)
        self.update_liquidity(t, self.ev_swings)

    # ------------------------------------------------------------------ ringkasan untuk tampilan
    def trend(self):
        return "BULL" if self.last_bos_dir > 0 else "BEAR" if self.last_bos_dir < 0 else "—"
