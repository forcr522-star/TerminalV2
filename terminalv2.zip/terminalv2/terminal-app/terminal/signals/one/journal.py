"""Jurnal strategi ONE (tabel one_log, terpisah dari jurnal 10 metode). Satu baris = satu setup (E1+E2) yang diterbitkan bot.

Status: PENDING (limit E1/E2 menunggu), OPEN (terisi; TP1 bisa sudah tercapai), lalu salah satu hasil akhir:
TP2, TP1 (TP1 lalu sisa kena breakeven), SL, CANCEL (C3-C6), EXPIRED (C1), MISSED (C2)."""
import json
import time

from ... import store

ACTIVE = ("PENDING", "OPEN")
DONE = ("TP2", "TP1", "SL")
CANCELLED = ("CANCEL", "EXPIRED", "MISSED")


def _row(r):
    r = dict(r)
    r["plan"] = json.loads(r["plan"])
    return r


def by_key(key):
    rows = store.query("SELECT * FROM one_log WHERE key=?", (key,))
    return _row(rows[0]) if rows else None


def active_all(sym=None):
    q = "SELECT * FROM one_log WHERE status IN ('PENDING','OPEN')" + (" AND sym=?" if sym else "") + " ORDER BY id"
    return [_row(r) for r in store.query(q, (sym,) if sym else ())]


def recent(limit=200, sym=None, mode=None):
    w, p = [], []
    if sym:
        w.append("sym=?")
        p.append(sym)
    if mode:
        w.append("mode=?")
        p.append(mode)
    q = "SELECT * FROM one_log" + (" WHERE " + " AND ".join(w) if w else "") + " ORDER BY id DESC LIMIT ?"
    p.append(int(limit))
    return [_row(r) for r in store.query(q, tuple(p))]


def create(key, sym, mode, typ, side, bar_ts, plan):
    cur = store.execute("INSERT OR IGNORE INTO one_log(key,sym,mode,type,side,created,bar_ts,plan,status,r,closed,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                        (key, sym, mode, typ, side, time.time(), bar_ts, json.dumps(plan), "PENDING", 0.0, None, ""))
    sid = cur.lastrowid
    try:
        from ... import notify
        notify.signal_new(f"one-{sid}", sym, side, dict(entry=plan.get("E1"), sl=plan.get("SL"), tp=[plan.get("TP1"), plan.get("TP2")], strategy="one"))
    except Exception:
        pass
    return sid


def update(row_id, status, r, plan=None, note=None):
    prev = store.query("SELECT status, sym, side, plan FROM one_log WHERE id=?", (row_id,))
    closed = time.time() if status not in ACTIVE else None
    store.execute("UPDATE one_log SET status=?, r=?, closed=COALESCE(?, closed), note=COALESCE(?, note), plan=COALESCE(?, plan) WHERE id=?",
                  (status, float(r), closed, note, json.dumps(plan) if plan is not None else None, row_id))
    if prev and prev[0]["status"] == "PENDING" and status == "OPEN":
        try:
            from ... import notify
            pl = json.loads(prev[0]["plan"])
            notify.signal_filled(f"one-{row_id}", prev[0]["sym"], prev[0]["side"], dict(entry=pl.get("E1"), sl=pl.get("SL"), tp=[pl.get("TP1"), pl.get("TP2")], strategy="one"))
        except Exception:
            pass


def stats(sym=None, mode=None, limit=3000):
    rows = recent(limit, sym, mode)
    done = [r for r in rows if r["status"] in DONE]
    canc = [r for r in rows if r["status"] in CANCELLED]
    n = len(done)
    sig = n + len(canc)
    if not n:
        return dict(n=0, win=None, avg_r=None, pf=None, sum_r=0.0, signals=sig, fill_rate=(n / sig) if sig else None, max_dd=None, by_type={})
    rs = [float(r["r"]) for r in sorted(done, key=lambda z: z["id"])]
    gp, gl = sum(x for x in rs if x > 0), -sum(x for x in rs if x < 0)
    eq = peak = dd = 0.0
    for x in rs:
        eq += x
        peak = max(peak, eq)
        dd = min(dd, eq - peak)
    by = {}
    for r in done:
        b = by.setdefault(r["type"], dict(n=0, sum_r=0.0, wins=0))
        b["n"] += 1
        b["sum_r"] += float(r["r"])
        b["wins"] += 1 if float(r["r"]) > 0 else 0
    return dict(n=n, win=sum(1 for x in rs if x > 0) / n, avg_r=sum(rs) / n, pf=(gp / gl) if gl > 0 else None, sum_r=sum(rs), signals=sig,
                fill_rate=n / sig if sig else None, max_dd=dd, by_type=by)


def day_r(tz_hours=7, day=None):
    """R yang sudah terealisasi hari ini (zona waktu sesi strategi, bawaan UTC+7), semua pair."""
    off = tz_hours * 3600
    day = day if day is not None else int((time.time() + off) // 86400)
    rows = store.query("SELECT r, closed FROM one_log WHERE status IN ('TP2','TP1','SL') AND closed IS NOT NULL", ())
    return sum(float(r["r"] or 0) for r in rows if int((float(r["closed"]) + off) // 86400) == day)
