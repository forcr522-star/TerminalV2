"""Parameter strategi ONE ("ZONA + STRUKTUR + HARMONIC", dokumen aturan v2.0, Bagian 3). Nilai bawaan = nilai dokumen.

Tanda sumber mengikuti dokumen: [F] fakta dari sinyal analis, [D] dihitung dari 41 sinyal asli, [A] asumsi teknis.
Parameter tambahan TERMINAL (bukan dari dokumen) diberi awalan Term_ dan dijelaskan di bawah.
"""

PARAMS = dict(
    TF_Entry="M5",                 # [F] dipakai sesuai gaya di menu (M5 = SCALPING disarankan)
    TF_Bias="M30",                 # [A] hanya untuk filter opsional K5
    UseBiasFilter=False,           # [A]
    ATR_Period=14,                 # [A]
    Fractal_Left=3,                # [A]
    Fractal_Right=3,               # [A] = jeda konfirmasi swing
    # -- Zona
    Run_MinBody_ATR=0.5,           # [A]
    Impulse_MaxBars=4,             # [A]
    Impulse_MinBody_ATR=0.8,       # [A]
    Impulse_MinBody_Ratio=0.6,     # [A]
    Impulse_MinMove_ATR=1.5,       # [A]
    Base_MinBars=2,                # [A]
    Base_MaxBars=12,               # [A]
    Base_BarMaxRange_ATR=0.8,      # [A]
    Base_MaxRange_ATR=1.2,         # [A]
    Zone_MaxAge_Bars=300,          # [A]
    Zone_MaxVisits_Entry=1,        # [A]
    Validate_Window_Bars=10,       # [A]
    # -- Likuiditas
    EqualLevel_Tol_ATR=0.15,       # [A]
    EqualLevel_Lookback_Swings=10,  # [A]
    Range_MinBars=20,              # [A]
    Range_MaxHeight_ATR=5.0,       # [A]
    Range_EdgeBand=0.25,           # [A]
    Range_MinTouchesPerSide=2,     # [A]
    Sweep_MaxReclaimBars=3,        # [A]
    Sweep_MaxBarsToBOS=20,         # [A]
    # -- Setup A
    A_MinImpulse_ATR=3.0,          # [A]
    A_B_MinRetrace=0.382,          # [A]
    A_B_MaxRetrace=0.886,          # [A]
    A_C_ExtMin=1.000,              # [A]
    A_C_ExtMax=1.272,              # [A]
    A_Disc_Min=0.5,                # [A]
    A_Disc_Max=0.886,              # [A]
    Require_Zone_SetupA=True,      # [A]
    # -- Setup B
    B_RetestOffset_ATR=0.10,       # [A]
    B_LineSL_ATR=1.0,              # [A]
    B_FailClose_ATR=0.5,           # [A]
    # -- Setup C (harmonic)
    C_AB_Min=0.38, C_AB_Max=0.89,  # [D]
    C_BC_Min=0.38, C_BC_Max=1.33,  # [D]
    C_XA_Levels=(0.786, 0.886, 1.0, 1.13, 1.272, 1.414, 1.618),   # [A]
    C_BC_Levels=(1.618, 2.0, 2.24, 2.618, 3.14, 3.618),           # [D]
    C_ClusterTol_XA=0.08,          # [A]
    C_SL_Buffer_XA=0.10,           # [A]
    C_RequireZone=False,           # [A]
    # -- Order
    Ladder_E2_Ratio=0.32,          # [D]
    Ladder_Lot_Split=0.5,          # [A]
    SL_Buffer_ATR=0.15,            # [A]
    SL_Min_ATR=0.5,                # [A]
    SL_Max_ATR=4.0,                # [A]
    TP1_Min_RR=1.0,                # [D]
    Min_RR_Final=1.5,              # [D]
    TP_Zone_Offset_ATR=0.10,       # [A]
    TP_Liq_Offset_ATR=0.20,        # [A]
    TP_Swing_Offset_ATR=0.05,      # [A]
    TP1_Close_Fraction=0.5,        # [A]
    BE_Offset_ATR=0.05,            # [A]
    Pending_Expiry_Bars=36,        # [A]
    Max_ReEntry=1,                 # [F]
    ReEntry_MaxGap_ATR=3.0,        # [A]
    # -- Risiko & filter
    Risk_Percent=0.5,              # [A]
    Max_Daily_Loss_R=3.0,          # [A]
    Max_NewSetups_Per_Day=3,       # [A] per simbol
    Max_Spread_vs_SL=0.15,         # [A]
    Session_Start_Min=7 * 60,      # [A] 07:00 ...
    Session_End_Min=23 * 60,       # [A] ... 23:00
    Session_TZ_Hours=7,            # zona waktu sesi & "hari ini": sinyal analis memakai UTC+7 (dokumen Bagian 3)
    News_Block_Minutes=15,         # [A] opsional (dipenuhi filter berita terminal)
    # -- Tambahan TERMINAL (bukan dari dokumen; filter yang tetap jalan saat strategi ONE dipakai)
    Term_Volume_MinRVOL=1.0,       # volume bar pemicu >= median 20 bar sebelumnya (hanya bila sumber punya data volume)
    Term_Quant_SpikePct=0.98,      # ATR di atas persentil 98% 500 bar terakhir = lonjakan -> tahan entry
    Term_Quant_MinN=30,            # statistik walk-forward per tipe setup dipakai setelah >= 30 trade bayangan tuntas
    Term_Quant_GateLCB=-0.05,      # batas bawah (rata-rata R - sd/sqrt(n)) <= -0,05R -> tipe itu dimatikan (dokumen Bagian 22)
)

# Spread tipikal sebagai pecahan harga, untuk K1 (Yahoo tidak memberi spread broker): [A] terminal.
SPREAD_FRAC = {"FX": 0.00003, "COMMODITY": 0.00010, "INDEX": 0.00006, "CRYPTO": 0.00040, "BOND": 0.00010}
