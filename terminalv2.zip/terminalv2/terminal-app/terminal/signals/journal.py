"""Jurnal sinyal: sinyal yang sudah terbit dikunci (latch) sampai selesai, supaya tidak berubah-ubah tiap penyegaran data.

Metrik di sini adalah metrik PER SINYAL (hasil audit): fill rate, positive-R rate (bukan TP1-touch), rata-rata R,
profit factor, dan max drawdown. Order batal (EXPIRED/MISSED) tetap dihitung di penyebut fill rate.
"""
import json
import time

from .. import store


def active(sym, mode):
    rows = store.query("SELECT * FROM signal_log WHERE sym=? AND mode=? AND status IN ('PENDING','OPEN') ORDER BY id DESC LIMIT 1", (sym, mode))
    return _row(rows[0]) if rows else None


def active_all():
    """Semua sinyal yang belum selesai (PENDING = limit menunggu entry, OPEN = posisi berjalan), semua pair & gaya."""
    return [_row(r) for r in store.query("SELECT * FROM signal_log WHERE status IN ('PENDING','OPEN') ORDER BY id")]


def get(sid):
    rows = store.query("SELECT * FROM signal_log WHERE id=?", (int(sid),))
    return _row(rows[0]) if rows else None


def _row(r):
    r = dict(r)
    r["plan"] = json.loads(r["plan"])
    return r


def create(sym, mode, be, side, bar_ts, plan, note=""):
    cur = store.execute("INSERT INTO signal_log(sym,mode,be,side,created,bar_ts,plan,status,r,tp_hits,closed,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                        (sym, mode, int(be), side, time.time(), bar_ts, json.dumps(plan), "PENDING", 0.0, 0, None, note))
    sid = cur.lastrowid
    try:
        from .. import notify
        notify.signal_new(sid, sym, side, plan)                  # notifikasi: bot memasang order limit baru
    except Exception:
        pass
    return sid


def update(sid, status, r, tp_hits, note=None, be=None):
    """Breakeven adalah pengaturan manajemen yang bisa diganti pengguna kapan saja; hasil dicatat dengan pengaturan terakhir."""
    prev = store.query("SELECT status, sym, side, plan FROM signal_log WHERE id=?", (sid,)) if status == "OPEN" else None
    closed = time.time() if status not in ("PENDING", "OPEN") else None
    store.execute("UPDATE signal_log SET status=?, r=?, tp_hits=?, closed=COALESCE(?, closed), note=COALESCE(?, note), be=COALESCE(?, be) WHERE id=?",
                  (status, float(r), int(tp_hits), closed, note, None if be is None else int(bool(be)), sid))
    if prev and prev[0]["status"] == "PENDING":                  # PENDING -> OPEN = harga menyentuh entry (order terisi)
        try:
            from .. import notify
            notify.signal_filled(sid, prev[0]["sym"], prev[0]["side"], json.loads(prev[0]["plan"]))
        except Exception:
            pass


def recent(limit=60, sym=None, mode=None, only_closed=False):
    q, p = "SELECT * FROM signal_log", []
    w = []
    if sym:
        w.append("sym=?")
        p.append(sym)
    if mode:
        w.append("mode=?")
        p.append(mode)
    if only_closed:
        w.append("status NOT IN ('PENDING','OPEN')")
    if w:
        q += " WHERE " + " AND ".join(w)
    q += " ORDER BY id DESC LIMIT ?"
    p.append(int(limit))
    return [_row(r) for r in store.query(q, tuple(p))]


DONE = ("TP1", "TP2", "TPMAX", "SL", "TIME")
CANCELLED = ("EXPIRED", "MISSED")


def stats(sym=None, mode=None, limit=2000):
    """Statistik per sinyal: n = trade tuntas (terisi), positive rate, rata-rata R, PF, fill rate, max DD."""
    rows = recent(limit, sym, mode)
    done = [r for r in rows if r["status"] in DONE]
    cancelled = [r for r in rows if r["status"] in CANCELLED]
    n = len(done)
    signals = n + len(cancelled)
    if not n:
        return dict(n=0, win=None, avg_r=None, pf=None, positives=None, pos_rate=None, sum_r=0.0,
                    signals=signals, fill_rate=(n / signals) if signals else None, max_dd=None)
    wins = [r for r in done if float(r["r"]) > 0]
    gp = sum(float(r["r"]) for r in done if float(r["r"]) > 0)
    gl = -sum(float(r["r"]) for r in done if float(r["r"]) < 0)
    sum_r = sum(float(r["r"]) for r in done)
    eq = peak = dd = 0.0
    for r in sorted(done, key=lambda z: z["id"]):
        eq += float(r["r"])
        peak = max(peak, eq)
        dd = min(dd, eq - peak)
    return dict(n=n, win=len(wins) / n, avg_r=sum_r / n, pf=(gp / gl) if gl > 0 else None,
                positives=len(wins), pos_rate=len(wins) / n, sum_r=sum_r, max_dd=dd,
                signals=signals, fill_rate=(n / signals) if signals else None)


def last_done(sym, mode):
    rows = store.query("SELECT * FROM signal_log WHERE sym=? AND mode=? AND status NOT IN ('PENDING','OPEN') ORDER BY id DESC LIMIT 1", (sym, mode))
    return _row(rows[0]) if rows else None


def day_r(mode=None, day=None):
    """Total R yang sudah terealisasi hari ini (UTC) untuk batas drawdown harian."""
    day = day or time.strftime("%Y-%m-%d", time.gmtime())
    rows = store.query("SELECT r, closed, mode FROM signal_log WHERE status NOT IN ('PENDING','OPEN') AND closed IS NOT NULL", ())
    tot = 0.0
    for r in rows:
        if mode and r["mode"] != mode:
            continue
        if time.strftime("%Y-%m-%d", time.gmtime(float(r["closed"]))) == day:
            tot += float(r["r"] or 0.0)
    return tot