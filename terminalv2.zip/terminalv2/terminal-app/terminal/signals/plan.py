"""Langkah 2: validasi hipotesis teknikal terhadap Volume Profile & Liquidity, lalu bangun rencana lengkap (Entry, SL, TP1/TP2/TP MAX).

Perbaikan hasil audit:
  - level validasi DIKLASIFIKASIKAN per sisi: BUY hanya level di bawah/entry, SELL hanya di atas/entry;
  - SL hanya boleh MELEBAR saat menghindari pool likuiditas (sebelumnya bisa mengetat);
  - jarak limit entry dibatasi MAX_ENTRY_ATR (limit terlalu jauh = adverse selection);
  - TP1 tidak boleh lebih dekat dari TP_MIN_R setelah dikunci ke level (sebelumnya bisa ~0,5R).
"""
import numpy as np

from . import structure
from .config import TP_R, TP_MIN_R, MAX_ENTRY_ATR


def nodes_at(x, i, with_fvg=True):
    """Kumpulan level di bar i: dict(levels=[(harga, jenis)], pools=[...], c, atr) — hanya data sampai bar i."""
    a = x.atr[i]
    c = x.c[i]
    lv = []
    if x.pidx[i] >= 0:
        p = x.profs[x.pidx[i]]
        lv += [(p["poc"], "POC"), (p["vah"], "VAH"), (p["val"], "VAL")] + [(v, "HVN") for v in p["hvn"]]
    for L, nm in ((x.ema50[i], "EMA50"), (x.ema200[i], "EMA200")):
        if np.isfinite(L):
            lv.append((float(L), nm))
    pools = structure.pools_at(x.piv, i, x.cfg["pool_lb"], 0.1 * a, x.pdh[i], x.pdl[i])
    for p in pools:
        lv.append((p["price"], "LIQ-" + p["src"]))
    if with_fvg:
        for z in structure.fvg_zones(x.h, x.l, i, 60):
            lv.append((z["hi"] if z["dir"] > 0 else z["lo"], "FVG" + ("+" if z["dir"] > 0 else "-")))
    return dict(levels=lv, pools=pools, c=float(c), atr=float(a))


def _on_side(p, e, d, tol):
    """Level hanya dianggap support untuk BUY bila di bawah/entry; resistance untuk SELL bila di atas/entry."""
    return (p <= e + tol) if d > 0 else (p >= e - tol)


def _nearest(levels, price, lo, hi, kinds=None, d=None, tol=0.0):
    best = None
    for p, k in levels:
        if kinds and not any(k.startswith(t) for t in kinds):
            continue
        if d is not None and not _on_side(p, price, d, tol):
            continue
        dist = abs(p - price)
        if lo <= dist <= hi and (best is None or dist < best[0]):
            best = (dist, p, k)
    return best


def build_plan(x, i, d, e0, sl0, q0, nodes=None):
    """Mengembalikan dict rencana tervalidasi atau None (abstain). Kunci: d, entry, sl, tp[3], q, status, notes."""
    a, c = float(x.atr[i]), float(x.c[i])
    if not (np.isfinite(a) and a > 0 and np.isfinite(e0) and np.isfinite(sl0)):
        return None
    nd = nodes or nodes_at(x, i)
    lv = nd["levels"]
    notes = []
    tol = 0.35 * a
    max_dist = MAX_ENTRY_ATR[x.mode] * a
    # --- titik entry: tidak boleh limit-beli di atas harga / limit-jual di bawah harga
    if d * (c - e0) < 0:
        e0 = c
    # limit terlalu jauh dari harga -> potong ke batas (fill rate terlalu rendah / adverse selection)
    dist_c = d * (c - e0)
    if dist_c > max_dist:
        e0 = c - d * max_dist
        notes.append(f"entry dipotong ke {MAX_ENTRY_ATR[x.mode]:.1f} ATR dari harga (limit terlalu jauh)")
    value_kinds = ("POC", "VAL", "VAH", "HVN", "FVG", "EMA50", "EMA200", "LIQ")
    hit = _nearest(lv, e0, 0.0, tol, value_kinds, d=d, tol=tol)
    status = "valid"
    if hit:
        e1 = (e0 + hit[1]) / 2          # dirata-ratakan dengan level valid
        notes.append(f"entry divalidasi di {hit[2]} ({hit[1]:.5g})")
        qm = 1.0
    else:
        cand = None
        for p, k in lv:
            if not any(k.startswith(t) for t in value_kinds):
                continue
            if not _on_side(p, e0, d, tol):
                continue
            dist = d * (c - p)                      # jarak ke sisi pullback
            if 0.15 * a <= dist <= min(1.3 * a, max_dist) and abs(p - e0) <= 1.2 * a:
                if cand is None or abs(p - e0) < abs(cand[0] - e0):
                    cand = (p, k)
        if cand:
            e1 = cand[0] + d * 0.05 * a
            status = "recalc"
            qm = 0.8
            notes.append(f"entry dihitung ulang ke {cand[1]} ({cand[0]:.5g})")
        else:
            e1 = e0
            status = "weak"
            qm = 0.55
            notes.append("tidak ada level volume/likuiditas di dekat entry")
    if d * (c - e1) < 0:
        e1 = c
    if d * (c - e1) > max_dist:                 # ratifikasi level tidak boleh mendorong limit terlalu jauh
        e1 = c - d * max_dist
    # --- SL: batas risiko 0.6..2.2 ATR, boleh MELEBAR ke luar pool likuiditas (tidak boleh mengetat)
    risk = abs(e1 - sl0)
    risk = min(max(risk, 0.6 * a), 2.2 * a)
    sl = e1 - d * risk
    for p in nd["pools"]:
        side_ok = (p["kind"] == "low") if d > 0 else (p["kind"] == "high")
        if not side_ok:
            continue
        inside = (sl < p["price"] < e1) if d > 0 else (e1 < p["price"] < sl)
        if not inside:
            continue
        cand_sl = p["price"] - d * 0.15 * a
        wider = (cand_sl < sl) if d > 0 else (cand_sl > sl)
        if wider and abs(e1 - cand_sl) <= 2.4 * a:      # hanya melebar, dan total risk tetap wajar
            sl = cand_sl
            notes.append(f"SL digeser (melebar) di luar pool likuiditas ({p['src']})")
    risk = abs(e1 - sl)
    if risk < 0.4 * a or risk > 2.6 * a:
        return None
    # --- TP: kelipatan R, boleh dikunci ke level lawan yang LEBIH JAUH dari minimum TP1
    ms = TP_R[x.mode]
    floor = TP_MIN_R[x.mode][0]
    opp = [(p, k) for p, k in lv if d * (p - e1) > 0.3 * risk and not k.startswith("EMA")]
    tps = []
    prev = 0.0
    for n_tp, m in enumerate(ms):
        tgt = m * risk
        best = None
        for p, k in opp:
            dist = d * (p - e1)
            if 0.8 * tgt <= dist <= 1.15 * tgt and (best is None or abs(dist - tgt) < abs(best[0] - tgt)):
                best = (dist, p, k)
        dist = best[0] - 0.1 * a if best else tgt
        if n_tp == 0:
            dist = max(dist, floor * risk)          # TP1 tidak boleh lebih dekat dari minimum
        dist = max(dist, prev + 0.4 * risk)
        tps.append(e1 + d * dist)
        prev = dist
    if abs(tps[0] - e1) < floor * risk - 1e-9:
        return None
    return dict(d=int(d), entry=float(e1), sl=float(sl), tp=[float(t) for t in tps], q=float(q0) * qm, status=status, notes=notes, risk=float(risk), atr=a)
