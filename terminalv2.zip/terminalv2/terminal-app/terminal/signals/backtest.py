"""Menu BACKTEST: uji seluruh strategi sinyal pada data historis nyata, dengan metrik per SINYAL.

Permintaan pengguna:
  - pilih gaya (scalping/intraday/swing), rentang tanggal mulai..selesai, dan Breakeven ON/OFF;
  - selama backtest berjalan, fitur terminal lain dijeda sementara (runner.set_paused) agar PC ringan;
  - hasil + "log belajar": catatan kenapa sebuah posisi kena SL atau profit, yang dipakai lagi oleh menu SIGNAL
    untuk mengonfirmasi sinyal berikutnya (lihat learn.py).

Metrik yang dilaporkan adalah metrik JUJUR hasil audit: jumlah sinyal, fill rate, positive-R rate,
rata-rata R per trade terisi dan per sinyal, profit factor, max drawdown, dan distribusi TP.
"""
import asyncio
import json
import math
import threading
import time
import traceback

import numpy as np
import pandas as pd

from .. import store
from ..providers import yahoo
from ..universe import BY_SYM
from . import ctx as C, engine, runner, tracker
from .config import MODES, MODE_ORDER, COST_FRAC, SWAP_FRAC_PER_DAY, TP_WEIGHTS

_lock = threading.Lock()
STOP = threading.Event()
STATE = dict(running=False, started=None, finished=None, mode=None, be=None, start=None, end=None, pairs=[],
             done=0, total=0, current=None, error=None, progress=[], run_id=None)

MAX_PAIRS = 12
MIN_BARS = {"scalp": 400, "intraday": 400, "swing": 250}
TABLES = """
CREATE TABLE IF NOT EXISTS bt_runs(
    id INTEGER PRIMARY KEY AUTOINCREMENT, created REAL, mode TEXT, be INTEGER, start TEXT, end TEXT,
    pairs TEXT, signals INTEGER, filled INTEGER, fill_rate REAL, pos_rate REAL, avg_r REAL, avg_r_signal REAL,
    pf REAL, max_dd REAL, sum_r REAL, payload TEXT
);
CREATE TABLE IF NOT EXISTS bt_trades(
    id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER, sym TEXT, mode TEXT, ts TEXT, side TEXT, status TEXT,
    r REAL, tp_hits INTEGER, entry REAL, sl REAL, tp TEXT, context TEXT, lesson TEXT
);
CREATE INDEX IF NOT EXISTS ix_bt_trades ON bt_trades(run_id);
"""


def ensure_tables():
    for stmt in TABLES.split(";"):
        if stmt.strip():
            store.execute(stmt)


def _period(mode, start, end):
    cfg = MODES[mode]
    days = max(1, (pd.Timestamp(end) - pd.Timestamp(start)).days)
    if mode == "scalp":
        return "59d" if days <= 59 else "59d"
    if mode == "intraday":
        return "360d" if days <= 360 else "730d"
    return "5y" if days <= 1825 else "10y"


def _context(res, regime, sym):
    """Konteks ringkas sebuah trade untuk log belajar (apa yang terjadi saat sinyal terbit).
    regime = dict rezim dari analisa (label, atr_pct, ...). Dulu yang dikirim hanya LABEL (teks) lalu dipanggil
    .get("atr_pct") -> AttributeError di sinyal pertama, pair itu gagal diam-diam dan backtest berakhir 0 sinyal."""
    reg = regime if isinstance(regime, dict) else {"label": regime}
    return dict(sym=sym, families=[f["family"] for f in (res.get("families") or []) if f["vote"] > 0],
                against=[f["family"] for f in (res.get("families") or []) if f["vote"] < 0],
                regime=reg.get("label"), n_agree=res.get("n_agree"), p_tp1=round(float(res.get("p_tp1") or 0), 3),
                ev=round(float(res.get("ev") or 0), 3), htf=int(res.get("htf") or 0), atr_pct=reg.get("atr_pct"))


def _lesson(res, s, ctx):
    """Pelajaran singkat: kenapa profit / kenapa kena SL."""
    hits = int(s.get("tp_hits") or 0)
    r = float(s.get("r") or 0.0)
    fams = "+".join(ctx.get("families") or []) or "—"
    reg = ctx.get("regime") or "?"
    if r > 0:
        return f"PROFIT {r:+.2f}R: {hits} TP tercapai, keluarga {fams}, rezim {reg}."
    if s.get("exit_reason") == "GAP-SL":
        return f"LOSS {r:+.2f}R: gap melewati SL (risiko tail), keluarga {fams}, rezim {reg}."
    if hits >= 1:
        return f"LOSS {r:+.2f}R: TP1 tercapai tetapi sisa kena SL/BE — TP1 terlalu dekat relatif ke sisa posisi, keluarga {fams}, rezim {reg}."
    return f"LOSS {r:+.2f}R: SL kena sebelum TP1, keluarga {fams}, rezim {reg}."


def _metrics(rows):
    if not rows:
        return dict(signals=0, filled=0, fill_rate=None, pos_rate=None, avg_r=None, avg_r_signal=None, pf=None,
                    max_dd=None, sum_r=0.0, tp1=0.0, tp2=0.0, tp3=0.0)
    filled = [r for r in rows if r["filled"]]
    n = len(filled)
    pos = [r for r in filled if r["r"] > 0]
    gp = sum(r["r"] for r in filled if r["r"] > 0)
    gl = -sum(r["r"] for r in filled if r["r"] < 0)
    eq = peak = dd = 0.0
    for r in sorted(filled, key=lambda z: z["t"]):
        eq += r["r"]
        peak = max(peak, eq)
        dd = min(dd, eq - peak)
    return dict(signals=len(rows), filled=n, fill_rate=(n / len(rows)) if rows else None,
                pos_rate=(len(pos) / n) if n else None, avg_r=(sum(r["r"] for r in filled) / n) if n else None,
                avg_r_signal=(sum(r["r"] for r in filled) / len(rows)) if rows else None,
                pf=(gp / gl) if gl > 0 else None, max_dd=dd, sum_r=sum(r["r"] for r in filled),
                tp1=sum(1 for r in filled if r["tp_hits"] >= 1) / n if n else 0.0,
                tp2=sum(1 for r in filled if r["tp_hits"] >= 2) / n if n else 0.0,
                tp3=sum(1 for r in filled if r["tp_hits"] >= 3) / n if n else 0.0)


def _run_pair(df, sym, mode, be, start, end, params=None):
    """Backtest satu pair: analisa tiap bar (dengan cooldown expiry), simulasi trade, kembalikan daftar trade."""
    cfg = MODES[mode]
    a = BY_SYM.get(sym.upper())
    if not a:
        return []
    # Data SEBELUM tanggal mulai dipakai sebagai pemanasan indikator & statistik metode (masa lalu, tanpa bocoran masa
    # depan); sinyal hanya dicari di [start, end]. Dulu data dipotong ke [start, end] lebih dulu, sehingga MIN_BARS bar
    # pertama rentang pilihan (setahun penuh di D1) habis untuk pemanasan dan backtest swing hampir selalu 0 sinyal.
    df = df[df.index <= _ts_like(df.index, end) + pd.Timedelta(days=1)]
    first = int(df.index.searchsorted(_ts_like(df.index, start)))
    begin = max(MIN_BARS[mode], first)
    if len(df) - begin < 20:
        raise ValueError(f"data pada rentang itu tidak cukup ({max(0, len(df) - first)} bar; perlu {MIN_BARS[mode]} bar sebelumnya untuk pemanasan)")
    cost_frac = COST_FRAC.get(a["cls"], 0.00022)
    swap_frac = SWAP_FRAC_PER_DAY.get(a["cls"], 0.00001) / max(1, cfg["bars_per_day"])
    x = C.build(df, mode)
    book = engine.Book(x, be, cost_frac, swap_frac).build(start=min(250, x.n // 3))
    rows, last = [], -10 ** 9
    step = 1                                  # setiap bar dianalisa, sama seperti bot live (dulu tiap expiry/2 bar)
    for i in range(min(begin, x.n - 1), x.n - 1, step):
        if STOP.is_set():
            break
        if i - last < cfg["expiry"]:
            continue
        r = engine.analyze_at(x, i, book, None, be, params, cost_frac)
        if r["signal"] == "WAIT":
            continue
        last = i
        pl = dict(r["plan"], swap=swap_frac * x.c[i])
        s = tracker.simulate(pl, x.o, x.h, x.l, x.c, i, be)
        if s["status"] in ("PENDING", "OPEN"):
            continue
        ctx = _context(r, r["regime"], sym)
        rows.append(dict(t=str(x.df.index[i]), t_epoch=int(pd.Timestamp(x.df.index[i]).timestamp()), sym=sym, side=r["signal"],
                         status=s["status"], r=float(s["r"]), tp_hits=int(s["tp_hits"]), filled=s["status"] == "CLOSED",
                         entry=float(pl["entry"]), sl=float(pl["sl"]), tp=list(pl["tp"]), context=ctx,
                         lesson=_lesson(r, s, ctx)))
    return rows


def _ts_like(idx, d):
    """Tanggal (str) sebagai Timestamp dengan zona waktu yang sama dengan indeks data."""
    t = pd.Timestamp(d)
    tz = getattr(idx, "tz", None)
    if tz is not None:
        t = t.tz_localize(tz) if t.tzinfo is None else t.tz_convert(tz)
    elif t.tzinfo is not None:
        t = t.tz_convert(None)
    return t


def run_sync(mode, start, end, be=True, pairs=None, params=None, on_progress=None):
    """Backtest lengkap (sinkron). Mengembalikan dict hasil + log belajar; menyimpan ke database."""
    ensure_tables()
    if mode not in MODES:
        raise ValueError("mode harus scalp/intraday/swing")
    pairs = [p for p in (pairs or []) if p.upper() in BY_SYM][:MAX_PAIRS]
    if not pairs:
        raise ValueError("tidak ada pair yang valid untuk diuji")
    t0 = time.time()
    allrows, per_pair, errors = [], {}, []
    for n, sym in enumerate(pairs, start=1):
        if STOP.is_set():
            break
        if on_progress:
            on_progress(n - 1, len(pairs), sym)
        try:
            a = BY_SYM[sym.upper()]
            cfg = MODES[mode]
            df = asyncio.run(_fetch(a, mode, start, end))
            if df is None or len(df) == 0:
                raise ValueError("data harga kosong")
            rows = _run_pair(df, a["sym"], mode, be, start, end, params)
            allrows.extend(rows)
            per_pair[a["sym"]] = _metrics(rows)
        except Exception as exc:
            errors.append(f"{sym}: {type(exc).__name__}: {str(exc)[:140]}")
            per_pair[sym] = _metrics([])
    met = _metrics(allrows)
    by_side = {s: _metrics([r for r in allrows if r["side"] == s]) for s in ("BUY", "SELL")}
    by_regime = {}
    for reg in sorted({(r["context"] or {}).get("regime") or "?" for r in allrows}):
        by_regime[reg] = _metrics([r for r in allrows if ((r["context"] or {}).get("regime") or "?") == reg])
    lessons = build_lessons(allrows)
    out = dict(mode=mode, mode_label=MODES[mode]["label"], be=bool(be), start=str(start), end=str(end), pairs=pairs,
               seconds=round(time.time() - t0, 1), metrics=met, by_pair=per_pair, by_side=by_side, by_regime=by_regime,
               lessons=lessons, trades=allrows[-400:], errors=errors, n_trades=len(allrows))
    run_id = _save(out)
    out["run_id"] = run_id
    return out


async def _fetch(a, mode, start, end):
    cfg = MODES[mode]
    df = await yahoo.ohlcv(a["y"], _period(mode, start, end), cfg["yf_interval"])
    if df is None or len(df) == 0:
        return None
    return df


def build_lessons(rows, min_n=20):
    """Kelompokkan trade per konteks (keluarga + rezim + sisi) lalu hitung kinerja tiap kelompok.

    Kelompok dengan LCB rata-rata R <= 0 menjadi larangan (penalty) di menu SIGNAL; yang positif menjadi bonus.
    """
    groups = {}
    for r in rows:
        if not r["filled"]:
            continue
        c = r["context"] or {}
        key = (r["side"], "+".join(sorted(c.get("families") or [])) or "—", c.get("regime") or "?")
        groups.setdefault(key, []).append(float(r["r"]))
    out = []
    for (side, fams, reg), rs in groups.items():
        n = len(rs)
        if n < min_n:
            continue
        m = float(np.mean(rs))
        sd = float(np.std(rs, ddof=1)) if n > 1 else 0.0
        lcb = m - sd / math.sqrt(n)
        out.append(dict(side=side, families=fams, regime=reg, n=n, avg_r=round(m, 3), lcb=round(lcb, 3),
                        pos_rate=round(sum(1 for v in rs if v > 0) / n, 3),
                        verdict="AVOID" if lcb <= 0 else ("GOOD" if lcb > 0.05 else "NETRAL")))
    out.sort(key=lambda z: (z["lcb"], -z["n"]))
    return out


def _save(out):
    run_id = None
    try:
        cur = store.execute("INSERT INTO bt_runs(created,mode,be,start,end,pairs,signals,filled,fill_rate,pos_rate,avg_r,avg_r_signal,pf,max_dd,sum_r,payload) "
                            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (time.time(), out["mode"], int(out["be"]), out["start"], out["end"], json.dumps(out["pairs"]),
                             out["metrics"]["signals"], out["metrics"]["filled"], out["metrics"]["fill_rate"], out["metrics"]["pos_rate"],
                             out["metrics"]["avg_r"], out["metrics"]["avg_r_signal"], out["metrics"]["pf"], out["metrics"]["max_dd"],
                             out["metrics"]["sum_r"], json.dumps({k: out[k] for k in ("by_pair", "by_side", "by_regime", "lessons", "errors")}, default=str)))
        run_id = cur.lastrowid
        store.executemany("INSERT INTO bt_trades(run_id,sym,mode,ts,side,status,r,tp_hits,entry,sl,tp,context,lesson) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          [(run_id, r["sym"], out["mode"], r["t"], r["side"], r["status"], r["r"], r["tp_hits"], r["entry"], r["sl"],
                            json.dumps(r["tp"]), json.dumps(r["context"]), r["lesson"]) for r in out["trades"]])
        store.kv_set("bt_last", dict(run_id=run_id, mode=out["mode"], created=time.time(), metrics=out["metrics"], lessons=out["lessons"],
                                     errors=out["errors"], pairs=out["pairs"], start=out["start"], end=out["end"]))
        store.kv_set("bt_lessons", out["lessons"])
    except Exception:
        traceback.print_exc()
    return run_id


def last_run():
    return store.kv_get("bt_last")


def lessons():
    return store.kv_get("bt_lessons", []) or []


# ----------------------------------------------------------------------------------------------- job latar (API)
def start(mode, start, end, be=True, pairs=None):
    """Mulai backtest di thread latar. Selama berjalan, runner (analisa & tracker) dijeda."""
    with _lock:
        if STATE["running"]:
            raise ValueError("backtest lain sedang berjalan")
        if mode not in MODES:
            raise ValueError("mode harus scalp/intraday/swing")
        if not start or not end:
            today = pd.Timestamp.utcnow().date()
            end = str(today)
            start = str(today - pd.Timedelta(days=365 if mode == "intraday" else (30 if mode == "scalp" else 1825)))
        if pd.Timestamp(start) >= pd.Timestamp(end):
            raise ValueError("tanggal mulai harus sebelum tanggal selesai")
        STOP.clear()
        STATE.update(running=True, started=time.time(), finished=None, mode=mode, be=bool(be), start=str(start), end=str(end),
                     pairs=list(pairs or []), done=0, total=len(pairs or []), current=None, error=None, progress=[], run_id=None)
    runner.set_paused(True, f"backtest {mode}")

    def worker():
        try:
            res = run_sync(mode, start, end, be, pairs, on_progress=_progress)
            with _lock:
                STATE.update(running=False, finished=time.time(), error=None, run_id=res.get("run_id"))
        except Exception as exc:
            traceback.print_exc()
            with _lock:
                STATE.update(running=False, finished=time.time(), error=f"{type(exc).__name__}: {exc}")
        finally:
            runner.set_paused(False)

    threading.Thread(target=worker, name="backtest", daemon=True).start()
    return status()


def stop():
    """Hentikan backtest yang berjalan (perubahan selesai pada pair saat ini)."""
    STOP.set()
    with _lock:
        if STATE["running"]:
            STATE.update(error="dihentikan pengguna")
    runner.set_paused(False)
    return status()


def _progress(done, total, sym):
    with _lock:
        STATE.update(done=done, total=total, current=sym, progress=(STATE["progress"] + [dict(sym=sym, at=time.time())])[-20:])


def status():
    with _lock:
        st = dict(STATE)
    st["last"] = last_run()
    return st