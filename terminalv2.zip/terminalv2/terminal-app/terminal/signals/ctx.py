"""Konteks analisa: semua indikator, struktur, profil volume, dan keluaran 10 metode dihitung SEKALI per dataset (vektor)."""
import numpy as np
import pandas as pd

from . import ta, structure, profile
from .config import MODES


def prep(df):
    """Normalisasi DataFrame OHLCV -> kolom o,h,l,c,v bertipe float, indeks waktu naik tanpa duplikat."""
    d = df.copy()
    d.columns = [str(c).lower()[:1] if str(c).lower() in ("open", "high", "low", "close", "volume") else str(c).lower() for c in d.columns]
    d = d[["o", "h", "l", "c"] + (["v"] if "v" in d.columns else [])].astype(float)
    if "v" not in d:
        d["v"] = 0.0
    d = d[~d.index.duplicated(keep="last")].sort_index()
    d = d.replace([np.inf, -np.inf], np.nan).dropna(subset=["o", "h", "l", "c"])
    d["v"] = d["v"].fillna(0.0)
    return d


def resample(df, rule):
    g = df.resample(rule, label="left", closed="left")
    out = pd.DataFrame({"o": g["o"].first(), "h": g["h"].max(), "l": g["l"].min(), "c": g["c"].last(), "v": g["v"].sum()}).dropna(subset=["c"])
    return out


def htf_direction(df, rule):
    """Arah tren timeframe lebih tinggi per bar LTF. Hanya memakai bar HTF yang sudah TUTUP (digeser 1 bar)."""
    h = resample(df, rule)
    if len(h) < 60:
        return pd.Series(0, index=df.index, dtype=float)
    c = h["c"]
    e21, e55 = ta.ema(c, 21), ta.ema(c, 55)
    d = pd.Series(np.where((c > e55) & (e21 > e55), 1, np.where((c < e55) & (e21 < e55), -1, 0)), index=h.index, dtype=float)
    d = d.shift(1)
    return d.reindex(df.index, method="ffill").fillna(0.0)


def prev_period_hl(df, rule):
    g = df[["h", "l"]].resample(rule, label="left", closed="left").agg({"h": "max", "l": "min"}).dropna().shift(1)
    return g.reindex(df.index, method="ffill")


class Ctx:
    pass


def build(df, mode, with_methods=True):
    from . import methods   # impor lambat: methods memakai Ctx
    cfg = MODES[mode]
    d = prep(df)
    x = Ctx()
    x.mode, x.cfg, x.df = mode, cfg, d
    x.n = len(d)
    c = d["c"]
    x.o, x.h, x.l, x.c, x.v = (d[k].values for k in ("o", "h", "l", "c", "v"))
    x.atr = ta.atr(d, 14).values
    x.ema20, x.ema50, x.ema200 = (ta.ema(c, n).values for n in (20, 50, 200))
    x.sma5 = ta.sma(c, 5).values
    x.rsi14, x.rsi2 = ta.rsi(c, 14).values, ta.rsi(c, 2).values
    a, pdi, mdi = ta.adx(d, 14)
    x.adx, x.pdi, x.mdi = a.values, pdi.values, mdi.values
    x.macd_h = ta.macd_hist(c).values
    mid, up, lo, z, bw = ta.bollinger(c, cfg["bb_n"], 2.0)
    x.bb_mid, x.bb_up, x.bb_lo, x.bb_z = mid.values, up.values, lo.values, z.values
    x.bw_rank = bw.rolling(cfg["squeeze_lb"]).rank(pct=True).values
    nd = cfg["donch"]
    x.dc_hi, x.dc_lo = d["h"].rolling(nd).max().shift(1).values, d["l"].rolling(nd).min().shift(1).values
    x.er = ta.efficiency_ratio(c, 20).values
    x.htf = htf_direction(d, cfg["htf_rule"]).values
    sh1, sh2, sl1, sl2 = ta.pivots(d, cfg["pivot_n"])
    x.sh1, x.sh2, x.sl1, x.sl2 = sh1.values, sh2.values, sl1.values, sl2.values
    x.piv = structure.pivot_arrays(d, cfg["pivot_n"])
    pp = prev_period_hl(d, "W-FRI" if mode == "swing" else "D")
    x.pdh, x.pdl = pp["h"].values, pp["l"].values
    x.has_vol = bool(np.nansum(x.v) > 0)
    x.profs, x.pidx = profile.rolling_profiles(d, cfg["prof_window"], cfg["prof_step"])
    pv = np.full((3, x.n), np.nan)
    for key, row in (("poc", 0), ("vah", 1), ("val", 2)):
        arr = np.array([p[key] for p in x.profs] + [np.nan])
        pv[row] = np.where(x.pidx >= 0, arr[x.pidx], np.nan)
    x.poc, x.vah, x.val = pv
    x.out = methods.run_all(x) if with_methods else {}
    return x
