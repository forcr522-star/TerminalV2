"""Konfigurasi menu SIGNAL: gaya trading, biaya, struktur TP, ambang keputusan, batas risiko.

Angka di sini adalah hasil audit & perbaikan (lihat _audit/strategy-audit.md dan docs/SIGNAL_RISET.md).
Prinsip: ukur dulu dengan jujur (positive-R per sinyal), eksekusi realistis (gap, swap, biaya per leg),
geometri aman (TP1 >= 1R, SL hanya melebar), lalu konsensus per KELUARGA faktor (bukan 10 indikator berkorelasi).
"""

MODES = {
    "scalp": dict(
        label="SCALPING (M5)", tf="M5", yf_interval="5m", yf_period="59d", htf_rule="1h", htf_label="H1", bars_per_day=288,
        tsmom=(12, 48, 144), donch=20, sweep_lb=24, pivot_n=3, pool_lb=288, prof_window=288, prof_step=12, bb_n=20, squeeze_lb=120,
        max_hold=48, expiry=12, ttl=120, minutes=5,
    ),
    "intraday": dict(
        label="INTRADAY (H1)", tf="H1", yf_interval="60m", yf_period="360d", htf_rule="4h", htf_label="H4", bars_per_day=24,
        tsmom=(24, 120, 480), donch=20, sweep_lb=24, pivot_n=3, pool_lb=240, prof_window=120, prof_step=6, bb_n=20, squeeze_lb=120,
        max_hold=48, expiry=8, ttl=300, minutes=60,
    ),
    "swing": dict(
        label="SWING (D1)", tf="D1", yf_interval="1d", yf_period="5y", htf_rule="W-FRI", htf_label="W1", bars_per_day=1,
        tsmom=(21, 63, 252), donch=20, sweep_lb=20, pivot_n=3, pool_lb=120, prof_window=120, prof_step=5, bb_n=20, squeeze_lb=120,
        max_hold=30, expiry=5, ttl=1800, minutes=1440,
    ),
}
MODE_ORDER = ["scalp", "intraday", "swing"]

# Biaya bolak-balik (spread + komisi + slippage) sebagai pecahan harga, per kelas aset.
# Versi lama (FX 0,00010) terlalu optimistis untuk broker retail; 0,00022 = 2,2 pip EURUSD.
COST_FRAC = {"FX": 0.00022, "COMMODITY": 0.00035, "INDEX": 0.00020, "CRYPTO": 0.0012, "BOND": 0.00025}
# Biaya pembiayaan/swap per HARI sebagai pecahan harga (dikenakan pada posisi yang ditahan).
SWAP_FRAC_PER_DAY = {"FX": 0.000010, "COMMODITY": 0.000020, "INDEX": 0.000020, "CRYPTO": 0.000030, "BOND": 0.000010}

# Pembagian posisi & kelipatan R. TP1 tidak lagi "dekat agar win rate tinggi": TP1 = 1R.
TP_WEIGHTS = (0.4, 0.3, 0.3)
TP_R = {"scalp": (0.9, 1.7, 2.8), "intraday": (1.0, 1.8, 3.0), "swing": (1.0, 1.9, 3.2)}
TP_MIN_R = dict(TP_R)                       # batas bawah TP1 setelah dikunci ke level (tidak boleh lebih dekat)
SL_ATR = {"scalp": 1.3, "intraday": 1.4, "swing": 1.5}
MAX_ENTRY_ATR = {"scalp": 0.8, "intraday": 0.9, "swing": 1.0}   # limit entry terlalu jauh = adverse selection

# Keputusan akhir. min_agree = minimal KELUARGA faktor searah (dari 6 keluarga), min_margin = selisih keluarga.
MIN_VOTES = 3
MIN_MARGIN = 1
MIN_P_TP1 = 0.58
MIN_EV = 0.12
LCB_Z = 1.0             # lower confidence bound: rata-rata R - z * sd / sqrt(n)

# Parameter engine.
PARAMS = dict(
    min_hist=30,        # minimal trade efektif sebelum statistik metode dipakai (dulu 10, terlalu berisik)
    hist_k=120,         # jendela statistik (dulu 40)
    gate_ev=-0.05,      # LCB rata-rata R metode <= -0,05R -> metode abstain
    min_agree=MIN_VOTES,
    min_margin=MIN_MARGIN,
    min_p=MIN_P_TP1,
    min_ev=MIN_EV,
    refine="none",      # grid refinement dinonaktifkan: dulu menurunkan TP1 dan memakai theta yang salah
    prior=None,
    by_weight=True,     # arah mengikuti bobot (statistik, fundamental, rezim), bukan sekadar jumlah suara
    need_valid=True,    # hanya entry yang tervalidasi volume/likuiditas yang boleh vote
    need_htf=True,
    fund_w=0.10,        # fundamental = overlay kecil pada UKURAN posisi, bukan veto arah
    family_vote=True,   # satu suara per KELUARGA faktor orthogonal
    strength=24.0,      # kekuatan prior Beta-Binomial (mengurangi overconfidence)
    session=True,       # filter sesi likuid (diterapkan di service, bukan di engine murni)
)
MODE_PARAMS = {
    "scalp": dict(min_agree=3, min_margin=2, min_p=0.60),
    "intraday": dict(min_agree=2, min_margin=1),
    "swing": dict(min_agree=2, min_margin=1),
}

# Batas risiko portofolio. Dulu tidak ada: 6 pair USD-correlated x 1,5% = drawdown berkorelasi.
RISK = dict(max_open=4, max_cluster=2, max_open_risk=0.02, daily_dd_r=3.0, cooldown_loss_bars=2, max_risk_per_trade=0.005)
# Sesi UTC yang diizinkan untuk entry baru (None = sepanjang hari). Hindari rollover & Asia tipis untuk FX.
SESSION_UTC = {"scalp": (7, 16), "intraday": (6, 20), "swing": None}
FRIDAY_CUTOFF_UTC = 15

# Pemetaan keluarga faktor: satu keluarga = satu suara. Mencegah 6 indikator tren dihitung sebagai 6 konfirmasi.
FAMILY = {
    "tsmom": "TREND", "emapb": "TREND", "macdadx": "TREND",
    "donch": "BREAKOUT", "squeeze": "BREAKOUT",
    "rsi2": "REVERSION", "bbz": "REVERSION",
    "struct": "STRUCTURE", "sweep": "LIQUIDITY", "value": "PROFILE",
}
FAMILIES = ["TREND", "BREAKOUT", "REVERSION", "STRUCTURE", "LIQUIDITY", "PROFILE"]
# Bobot keluarga per rezim. None/0 = keluarga abstain (playbook per rezim, bukan pengali kosmetik).
REGIME_W = {
    "TRENDING":       {"TREND": 1.0, "BREAKOUT": 1.0, "REVERSION": 0.0, "STRUCTURE": 0.9, "LIQUIDITY": 0.8, "PROFILE": 0.7},
    "MEAN-REVERTING": {"TREND": 0.0, "BREAKOUT": 0.0, "REVERSION": 1.0, "STRUCTURE": 0.7, "LIQUIDITY": 0.8, "PROFILE": 1.0},
    "CAMPURAN":       {"TREND": 0.8, "BREAKOUT": 0.8, "REVERSION": 0.8, "STRUCTURE": 0.8, "LIQUIDITY": 0.9, "PROFILE": 0.8},
    "TIDAK CUKUP DATA": {"TREND": 0.6, "BREAKOUT": 0.6, "REVERSION": 0.6, "STRUCTURE": 0.6, "LIQUIDITY": 0.6, "PROFILE": 0.6},
}

# Cluster korelasi untuk batas risiko portofolio (maks. RISK["max_cluster"] posisi terbuka per cluster).
CLUSTER = {
    "EURUSD": "USD", "GBPUSD": "USD", "AUDUSD": "USD", "NZDUSD": "USD", "USDCAD": "USD", "USDCHF": "USD", "USDJPY": "USD",
    "EURJPY": "JPY", "GBPJPY": "JPY", "AUDJPY": "JPY",
    "Gold": "METALS", "Silver": "METALS",
    "Bitcoin": "CRYPTO", "Ethereum": "CRYPTO",
    "US500": "EQUITY", "US100": "EQUITY", "US30": "EQUITY", "DAX30": "EQUITY",
    "Crude Oil WTI": "ENERGY", "Brent Oil": "ENERGY", "Natural Gas": "ENERGY",
}


def cluster_of(sym):
    """Cluster korelasi sebuah simbol (fallback: kelas aset)."""
    return CLUSTER.get(sym, "OTHER")