"""Orkestrasi satu pair: ambil data -> analisa 10 metode -> kunci sinyal di jurnal -> payload JSON untuk menu SIGNAL."""
import asyncio
import datetime as dt
import threading
import time
import traceback

import numpy as np
import pandas as pd

from ..universe import BY_SYM
from ..providers import yahoo
from . import ctx as C, engine, explain, fundamental, journal, learn, tracker
from .config import (MODES, MODE_ORDER, COST_FRAC, SWAP_FRAC_PER_DAY, TP_WEIGHTS, RISK, SESSION_UTC,
                     FRIDAY_CUTOFF_UTC, FAMILIES, cluster_of)
from .methods import NAMES, LABEL, KIND

MIN_BARS = {"scalp": 600, "intraday": 600, "swing": 400}
# Jurnal dibaca-ubah-tulis dari beberapa jalur (analisa bot, pelacak order, panggilan manual): satu kunci agar tidak ada sinyal ganda / status yang saling menimpa.
JLOCK = threading.RLock()


def digits(price):
    p = abs(price)
    return 2 if p >= 1000 else 3 if p >= 100 else 4 if p >= 10 else 5


def _r(v, nd):
    return None if v is None or (isinstance(v, float) and not np.isfinite(v)) else round(float(v), nd)


def completed(df, minutes, now=None):
    """Buang bar yang masih berjalan (belum tutup)."""
    now = now or dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
    if len(df) == 0:
        return df
    end = df.index[-1] + pd.Timedelta(minutes=minutes)
    return df.iloc[:-1] if end > pd.Timestamp(now) else df


def management_text(be, plan, nd):
    if be:
        return (f"Breakeven ON: setelah TP1 ({plan['tp'][0]:.{nd}f}) tercapai, geser SL ke Entry ({plan['entry']:.{nd}f}). "
                f"Tutup {int(TP_WEIGHTS[0]*100)}% di TP1, {int(TP_WEIGHTS[1]*100)}% di TP2, sisa {int(TP_WEIGHTS[2]*100)}% di TP MAX.")
    return (f"Breakeven OFF: SL ({plan['sl']:.{nd}f}) dan semua TP tetap (fixed). "
            f"Tutup {int(TP_WEIGHTS[0]*100)}% di TP1, {int(TP_WEIGHTS[1]*100)}% di TP2, sisa {int(TP_WEIGHTS[2]*100)}% di TP MAX.")


def _plan_out(pl, nd, be, c, atr, extra=None):
    risk = abs(pl["entry"] - pl["sl"])
    rr = [abs(t - pl["entry"]) / risk for t in pl["tp"]]
    side = pl["d"]
    near = abs(pl["entry"] - c) <= 0.1 * atr
    order = ("BUY" if side > 0 else "SELL") + (" (market)" if near else " LIMIT")
    out = dict(side="BUY" if side > 0 else "SELL", order=order, entry=_r(pl["entry"], nd), sl=_r(pl["sl"], nd), tp1=_r(pl["tp"][0], nd), tp2=_r(pl["tp"][1], nd), tpmax=_r(pl["tp"][2], nd),
               rr=[_r(x, 2) for x in rr], risk=_r(risk, nd), weights=list(TP_WEIGHTS), expiry_bars=pl["expiry"], max_hold=pl["max_hold"], be=bool(be),
               management=management_text(be, pl, nd))
    if extra:
        out.update(extra)
    return out


def _method_rows(rows, nd):
    out = []
    for r in rows:
        o = dict(key=r["key"], label=r["label"], kind=r["kind"], family=r.get("family"), bias=r["bias"], vote=r["vote"], status=r["status"], why=r.get("why"),
                 regime_w=_r(r.get("regime_w"), 2))
        if r.get("plan"):
            p = r["plan"]
            o.update(entry=_r(p["entry"], nd), sl=_r(p["sl"], nd), tp1=_r(p["tp"][0], nd), validation=p["status"], notes=p["notes"], q=_r(r.get("q") or p["q"], 2))
            o.update(p=_r(r["p_post"], 3), ev=_r(r["ev"], 3), ev_model=_r(r.get("ev_model"), 3), lcb_r=_r(r.get("lcb_r"), 3),
                     n_hist=r["n_hist"], win_hist=_r(r["wins_hist"] / r["n_hist"], 3) if r["n_hist"] else None,
                     avg_r_hist=_r(r["avg_r_hist"], 3) if r["n_hist"] else None, fund_align=_r(r.get("fund_align"), 2))
        out.append(o)
    return out


def _levels(x, i, nd):
    p = x.profs[x.pidx[i]] if x.pidx[i] >= 0 else None
    pools = [dict(price=_r(q["price"], nd), kind=q["kind"], src=q["src"], n=q["n"]) for q in engine.P.nodes_at(x, i, with_fvg=False)["pools"]]
    near = sorted(pools, key=lambda q: abs(q["price"] - x.c[i]))[:8]
    return dict(poc=_r(p["poc"], nd), vah=_r(p["vah"], nd), val=_r(p["val"], nd), hvn=[_r(v, nd) for v in p["hvn"][:6]], lvn=[_r(v, nd) for v in p["lvn"][:6]], src=p["src"], pools=near) if p else dict(pools=near)


def session_ok(mode, now=None, cls=None):
    """Filter sesi likuid (UTC). Hasil audit: hindari rollover/Asia tipis untuk FX & indeks; kripto 24 jam."""
    if cls == "CRYPTO":
        return True
    now = now or dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
    wd = now.weekday()
    if wd >= 5:
        return False
    if wd == 4 and now.hour >= FRIDAY_CUTOFF_UTC:
        return False
    ses = SESSION_UTC.get(mode)
    return True if ses is None else (ses[0] <= now.hour < ses[1])


def _open_book():
    """Total risiko terbuka dan jumlah posisi per cluster (untuk batas risiko portofolio)."""
    rows = journal.active_all()
    tot, per = 0.0, {}
    for r in rows:
        rp = float((r["plan"] or {}).get("risk_pct") or 0.0) / 100.0
        tot += max(0.0, rp)
        c = cluster_of(r["sym"])
        per[c] = per.get(c, 0) + 1
    return len(rows), tot, per


def entry_allowed(sym, mode, risk_pct, now=None, cls=None):
    """Gate portofolio untuk sinyal BARU: sesi, jumlah posisi, cluster korelasi, total risiko, DD harian, cooldown."""
    if not session_ok(mode, now, cls):
        return False, "di luar sesi likuid (UTC)"
    n_open, open_risk, per = _open_book()
    if n_open >= RISK["max_open"]:
        return False, f"batas posisi terbuka ({RISK['max_open']}) tercapai"
    cl = cluster_of(sym)
    if per.get(cl, 0) >= RISK["max_cluster"]:
        return False, f"batas posisi per cluster {cl} ({RISK['max_cluster']}) tercapai"
    rp = max(0.0, float(risk_pct or 0.0)) / 100.0
    if open_risk + rp > RISK["max_open_risk"] + 1e-9:
        return False, f"batas risiko portofolio ({RISK['max_open_risk']*100:.1f}%) tercapai"
    if journal.day_r(mode) <= -RISK["daily_dd_r"]:
        return False, f"drawdown harian {RISK['daily_dd_r']:.1f}R tercapai — berhenti sampai besok"
    last = journal.last_done(sym, mode)
    if last and float(last["r"]) < 0 and last.get("closed"):
        cool = RISK["cooldown_loss_bars"] * MODES[mode]["minutes"] * 60
        if time.time() - float(last["closed"]) < cool:
            return False, f"cooldown setelah loss ({RISK['cooldown_loss_bars']} bar)"
    return True, None


def _label(res):
    """Status jurnal dari hasil simulasi."""
    st = res["status"]
    if st in ("PENDING", "OPEN", "NOFILL", "MISSED"):
        return "PENDING" if st == "PENDING" else "OPEN" if st == "OPEN" else "EXPIRED" if st == "NOFILL" else "MISSED"
    hits = res["tp_hits"]
    return "TPMAX" if hits >= 3 else "TP2" if hits == 2 else "TP1" if hits == 1 else ("SL" if res["stopped"] else "TIME")


def _simulate_on(act, frame, be_flag, pos):
    pl = act["plan"]
    return tracker.simulate(pl, frame["o"].values, frame["h"].values, frame["l"].values, frame["c"].values, int(pos), bool(be_flag))


def evaluate_latched(act, df_all, be_flag):
    """Evaluasi sinyal terkunci HANYA pada bar yang sudah TUTUP (finalisasi status; anti bar berjalan)."""
    cfg = MODES.get(act.get("mode") or "intraday", MODES["intraday"])
    df = completed(df_all, cfg["minutes"])
    pos = df.index.get_indexer([pd.Timestamp(act["bar_ts"])])[0]
    if pos < 0:
        return "EXPIRED", None
    res = _simulate_on(act, df, be_flag, pos)
    return _label(res), res


def live_state(act, df_all, be):
    """Keadaan order terkunci terhadap data harga terbaru (tanpa menulis jurnal) — termasuk bar berjalan (tampilan sementara).

    Mengembalikan (label_jurnal, hasil_simulasi, dict live). r_total = RR terealisasi + RR mengambang posisi yang masih terbuka
    (SL = 1R, TP = kelipatan R). fill_ts = detik epoch bar saat entry terisi."""
    pos = df_all.index.get_indexer([pd.Timestamp(act["bar_ts"])])[0]
    if pos < 0:
        label, res = "EXPIRED", None
    else:
        res = _simulate_on(act, df_all, be, pos)
        label = _label(res)
    pl = act["plan"]
    d, e = pl["d"], pl["entry"]
    risk = abs(e - pl["sl"])
    price = float(df_all["c"].iloc[-1])
    live = dict(status=label, price=price, hits=0, sl_now=pl["sl"], r_real=0.0, r_float=0.0, r_total=0.0, fill_ts=None, asof=int(pd.Timestamp(df_all.index[-1]).timestamp()))
    if res:
        live["hits"] = int(res.get("tp_hits", 0))
        live["sl_now"] = float(res.get("sl_now", pl["sl"]))
        live["r_real"] = float(res["r"])
        if res.get("fill") is not None:
            live["fill_ts"] = int(pd.Timestamp(df_all.index[res["fill"]]).timestamp())
        if label == "OPEN" and risk > 0:
            live["r_float"] = float(res.get("rem", 0.0)) * d * (price - e) / risk
        live["r_total"] = live["r_real"] + live["r_float"]
    return label, res, live


def analyze_frame(df_all, sym, mode, be, fund=None, now=None, use_journal=True, new_ok=None):
    """Inti sinkron (CPU) — dipanggil di thread. df_all = OHLCV semua bar (termasuk yang masih berjalan).
    new_ok: fungsi tanpa argumen; bila diberikan dan mengembalikan False, sinyal BARU tidak dicatat (dipakai saklar SINYAL OFF)."""
    cfg = MODES[mode]
    a = BY_SYM[sym.upper()]
    df = completed(df_all, cfg["minutes"], now)
    if len(df) < MIN_BARS[mode]:
        raise ValueError(f"data {cfg['tf']} tidak cukup ({len(df)} bar, perlu {MIN_BARS[mode]})")
    cost_frac = COST_FRAC.get(a["cls"], 0.00022)
    swap_frac = SWAP_FRAC_PER_DAY.get(a["cls"], 0.00001) / max(1, cfg["bars_per_day"])
    x = C.build(df, mode)
    book = engine.Book(x, be, cost_frac, swap_frac).build(start=min(250, x.n // 3))
    i = x.n - 1
    res = engine.analyze_at(x, i, book, fund, be, dict(prior=learn.prior()), cost_frac)
    c, atr = float(x.c[i]), float(x.atr[i])
    nd = digits(c)
    price_live = float(df_all["c"].iloc[-1])
    bar_ts = str(df.index[i])
    issued_at = str(df.index[i] + pd.Timedelta(minutes=cfg["minutes"]))
    payload = dict(symbol=a["sym"], name=a["name"], cls=a["cls"], mode=mode, mode_label=cfg["label"], tf=cfg["tf"], htf=cfg["htf_label"], be=bool(be), bars=int(x.n),
                   asof=issued_at, price=_r(price_live, nd), atr=_r(atr, nd), digits=nd, signal="WAIT", state="WAIT", reason=res.get("reason"), plan=None, last=None)
    payload["votes"] = dict(bull=res["bull"], bear=res["bear"],
                            abstain=len(FAMILIES) - res["bull"] - res["bear"], total=len(FAMILIES),
                            basis="keluarga", method_bull=res["method_bull"], method_bear=res["method_bear"],
                            method_total=len(NAMES), families=res["families"], rows=_method_rows(res["rows"], nd))
    payload["layers"] = dict(
        technical=dict(htf=int(x.htf[i]), htf_label=cfg["htf_label"], adx=_r(x.adx[i], 1), rsi=_r(x.rsi14[i], 1), ema=[_r(x.ema20[i], nd), _r(x.ema50[i], nd), _r(x.ema200[i], nd)]),
        profile=_levels(x, i, nd),
        fundamental=dict(score=_r((fund or {}).get("score", 0.0), 2), conf=_r((fund or {}).get("conf", 0.0), 2), block=(fund or {}).get("block"), drivers=(fund or {}).get("drivers", []), note=(fund or {}).get("note")),
        quant=dict(regime=res["regime"], pooled_p=_r(res.get("pooled_p"), 3)),
    )
    try:
        payload["explain"] = explain.build(x, i, res, fund, mode, bool(be), nd)
    except Exception:
        traceback.print_exc()
        payload["explain"] = None
    k = min(x.n, 110)
    payload["candles"] = [[int(pd.Timestamp(t).timestamp()), _r(o, nd), _r(h, nd), _r(l, nd), _r(cc, nd)] for t, o, h, l, cc in zip(df.index[-k:], x.o[-k:], x.h[-k:], x.l[-k:], x.c[-k:])]
    new_plan = None
    gate_reason = None
    lv = learn.verdict(dict(res, mode=mode), a["sym"])
    payload["layers"]["quant"]["learn"] = dict(block=lv["block"], note=lv["note"])
    if res["signal"] != "WAIT" and lv["block"]:
        payload["reason"] = lv["note"]
        res["signal"] = "WAIT"
    if res["signal"] != "WAIT":
        pl = res["plan"]
        rp = _r(res["kelly"] * 100, 2)
        payload["layers"]["quant"].update(p_tp1=_r(res["p_tp1"], 3), ev=_r(res["ev"], 3), ev_model=_r(res.get("ev_model"), 3),
                                           theta=_r(res["theta"], 3), risk_pct=rp, agree=res["agree"],
                                           outcomes=[dict(p=_r(p, 3), r=_r(r, 2)) for p, r in res["outs"]], refine=res["refine"])
        if use_journal:
            ok, gate_reason = entry_allowed(a["sym"], mode, rp, now, a["cls"])
            if not ok:
                payload["reason"] = gate_reason
        if gate_reason is None:
            new_plan = dict(pl, swap=swap_frac * c)
        else:
            res["signal"] = "WAIT"
    if not use_journal:
        if new_plan:
            payload.update(signal=res["signal"], state="NEW", plan=_plan_out(new_plan, nd, be, c, atr, dict(p_tp1=_r(res["p_tp1"], 3), ev=_r(res["ev"], 3), risk_pct=_r(res["kelly"] * 100, 2))))
        return payload
    # --- jurnal: sinyal terkunci
    with JLOCK:
        act = journal.active(a["sym"], mode)
        if act:
            st, sr = evaluate_latched(act, df_all, be)
            if st in ("PENDING", "OPEN"):
                journal.update(act["id"], st, sr["r"] if sr else 0.0, sr["tp_hits"] if sr else 0, be=be)
                pl = act["plan"]
                extra = dict(id=act["id"], hits=(sr or {}).get("tp_hits", 0), sl_now=_r((sr or {}).get("sl_now", pl["sl"]), nd), p_tp1=act["plan"].get("p_tp1"), ev=act["plan"].get("ev"), risk_pct=act["plan"].get("risk_pct"))
                payload.update(signal="BUY" if pl["d"] > 0 else "SELL", state=st, plan=_plan_out(pl, nd, be, c, atr, extra), reason=None)
                payload["issued"] = act["bar_ts"]
                payload["track"] = journal.stats(a["sym"], mode)
                explain.add_latched(payload.get("explain"), payload)
                return payload
            journal.update(act["id"], st, sr["r"] if sr else 0.0, sr["tp_hits"] if sr else 0, be=be)
            payload["last"] = dict(id=act["id"], side=act["side"], status=st, r=_r(sr["r"] if sr else 0.0, 2), hits=(sr or {}).get("tp_hits", 0), bar_ts=act["bar_ts"])
        if new_plan and (new_ok is None or new_ok()):
            store_plan = dict(new_plan, w=list(TP_WEIGHTS), p_tp1=_r(res["p_tp1"], 3), ev=_r(res["ev"], 3), risk_pct=_r(res["kelly"] * 100, 2),
                              families=[f["family"] for f in (res.get("families") or []) if f["vote"] > 0],
                              regime=res["regime"]["label"], agree=list(res.get("agree") or []),
                              learn_note=lv.get("note"))
            sid = journal.create(a["sym"], mode, be, res["signal"], bar_ts, store_plan)
            payload.update(signal=res["signal"], state="NEW", reason=None, plan=_plan_out(new_plan, nd, be, c, atr, dict(id=sid, hits=0, p_tp1=_r(res["p_tp1"], 3), ev=_r(res["ev"], 3), risk_pct=_r(res["kelly"] * 100, 2))))
            payload["issued"] = bar_ts
        payload["track"] = journal.stats(a["sym"], mode)
    return payload


async def analyze(sym, mode, be, new_ok=None):
    a = BY_SYM.get(sym.upper())
    if not a:
        raise ValueError(f"simbol tidak dikenal: {sym}")
    if mode not in MODES:
        raise ValueError("mode harus scalp/intraday/swing")
    cfg = MODES[mode]
    df = await yahoo.ohlcv(a["y"], cfg["yf_period"], cfg["yf_interval"])
    if df is None or len(df) == 0:
        raise ValueError(f"data harga {sym} tidak tersedia dari sumber")
    fund = await fundamental.gather(a["sym"], mode)
    return await asyncio.to_thread(analyze_frame, df, a["sym"], mode, bool(be), fund, None, True, new_ok)
