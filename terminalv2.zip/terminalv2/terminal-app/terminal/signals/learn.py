"""Log belajar lintas sesi: konfirmasi ulang sinyal baru dengan pengalaman dari JURNAL SINYAL LIVE.

Permintaan pengguna: terminal harus belajar dari posisi yang kena SL maupun yang profit, dan pengalaman itu
dipakai untuk mengonfirmasi posisi berikutnya. Modul ini:
  1. mengubah jurnal sinyal live (posisi yang sudah tuntas) menjadi aturan konteks (sisi + keluarga + rezim);
  2. memblokir sinyal baru bila konteks yang sama terbukti rugi secara statistik (LCB <= 0, n cukup);
  3. menyediakan ringkasan teks "pengalaman".
(Menu BACKTEST beserta pelajaran & bobot metode dari hasil backtest sudah dihapus.)
"""
import math

from . import journal

MIN_N = 20


def _lcb(rs):
    n = len(rs)
    if n < 2:
        return -99.0
    m = sum(rs) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in rs) / (n - 1))
    return m - sd / math.sqrt(n)


def _journal_groups(sym=None, mode=None):
    rows = journal.recent(2000, sym, mode, only_closed=True)
    groups = {}
    for r in rows:
        pl = r.get("plan") or {}
        fams = "+".join(sorted(pl.get("families") or [])) or "—"
        reg = pl.get("regime") or "?"
        key = (r.get("side"), fams, reg)
        groups.setdefault(key, []).append(float(r.get("r") or 0.0))
    return groups


def journal_lessons(sym=None, mode=None, min_n=MIN_N):
    out = []
    for (side, fams, reg), rs in _journal_groups(sym, mode).items():
        n = len(rs)
        if n < min_n:
            continue
        lcb = _lcb(rs)
        out.append(dict(side=side, families=fams, regime=reg, n=n, avg_r=round(sum(rs) / n, 3), lcb=round(lcb, 3),
                        pos_rate=round(sum(1 for x in rs if x > 0) / n, 3), verdict="AVOID" if lcb <= 0 else ("GOOD" if lcb > 0.05 else "NETRAL"),
                        source="live"))
    return out


def all_lessons(sym=None, mode=None):
    return journal_lessons(sym, mode)


def _match(lesson, side, families, regime):
    if lesson.get("side") != side:
        return False
    if (lesson.get("regime") or "?") != (regime or "?"):
        return False
    lf = set((lesson.get("families") or "—").split("+")) - {"—", ""}
    return lf.issubset(set(families or []))


def verdict(res, sym=None):
    """Periksa apakah pengalaman menolak sinyal ini. Mengembalikan dict(block, note, matched)."""
    if res.get("signal") in (None, "WAIT"):
        return dict(block=False, note=None, matched=[])
    side = res["signal"]
    families = [f["family"] for f in (res.get("families") or []) if f["vote"] > 0] if side == "BUY" else \
               [f["family"] for f in (res.get("families") or []) if f["vote"] < 0]
    regime = (res.get("regime") or {}).get("label")
    bad = []
    for l in all_lessons(sym, res.get("mode")):
        if l.get("verdict") == "AVOID" and l.get("n", 0) >= MIN_N and _match(l, side, families, regime):
            bad.append(l)
    if bad:
        b = max(bad, key=lambda z: z["n"])
        return dict(block=True, note=f"pengalaman menolak: konteks {b['side']} keluarga {b['families']} rezim {b['regime']} "
                                     f"rugi {b['avg_r']:+.2f}R dari {b['n']} trade (LCB {b['lcb']:+.2f}R)",
                    matched=[b])
    good = [l for l in all_lessons(sym, res.get("mode")) if l.get("verdict") == "GOOD" and _match(l, side, families, regime)]
    note = None
    if good:
        g = max(good, key=lambda z: z["n"])
        note = f"pengalaman mendukung: konteks serupa profit {g['avg_r']:+.2f}R dari {g['n']} trade (LCB {g['lcb']:+.2f}R)"
    return dict(block=False, note=note, matched=good)


def summary_text(limit=12):
    """Teks pengalaman untuk LLM/explain (Ollama membaca ini sebagai konteks, bukan mengubah angka)."""
    ls = all_lessons()
    if not ls:
        return f"Belum ada pengalaman tercatat: perlu minimal {MIN_N} posisi tuntas dengan konteks yang sama di jurnal sinyal live."
    ls = sorted(ls, key=lambda z: (z.get("lcb") or 0))[:limit]
    lines = []
    for l in ls:
        lines.append(f"- {l.get('source')}: {l.get('side')} keluarga {l.get('families')} rezim {l.get('regime')}: "
                     f"{l.get('n')} trade, rata-rata {l.get('avg_r'):+.2f}R, LCB {l.get('lcb'):+.2f}R → {l.get('verdict')}.")
    return "\n".join(lines)