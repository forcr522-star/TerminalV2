"""Penjelasan "KENAPA" untuk halaman INSIDE/ANALISIS (khusus admin).

Untuk tiap dari 10 analisa (metode) dan untuk keputusan akhir, dibuat teks Bahasa Indonesia yang menjawab:
  TEKNIKAL            kenapa metode ini BUY / SELL / WAITING (nilai indikator nyata pada bar terakhir, bukan teks tetap)
  VOLUME & LIQUIDITY  apakah titik entry berada di level bernilai (POC/VAH/VAL/HVN/FVG/EMA) dan di mana pool likuiditas terdekat
  FUNDAMENTAL         skor fundamental dan apakah searah / berlawanan dengan arah metode
  QUANTITATIVE        rezim pasar, rekam jejak metode, peluang TP1 dan EV
  KESIMPULAN          alasan akhir BULLISH / BEARISH / WAITING

Semua angka diambil dari objek analisa yang sama dengan yang dipakai engine (ctx `x`, hasil `analyze_at`), jadi teks selalu cocok dengan keputusan bot.
Fungsi murni (tanpa jaringan)."""
import math

import numpy as np

from .config import PARAMS, MODE_PARAMS, TP_WEIGHTS
from .methods import METHODS, LABEL, KIND

STATE_TXT = {1: "BULLISH", -1: "BEARISH", 0: "WAITING"}
SIDE_TXT = {1: "BUY", -1: "SELL"}
STATUS_NOTE = {"no-setup": "tanpa setup", "abstain": "abstain", "gated": "ditolak quant", "veto-fund": "veto fundamental", "ok": "lolos"}

KIND_TXT = {"TREND": "mengikuti tren", "BREAKOUT": "mengejar breakout", "MOMENTUM": "mengikuti momentum", "REVERSION": "mean-reversion (berbalik ke rata-rata)",
            "STRUCTURE": "struktur pasar", "LIQUIDITY": "perburuan likuiditas", "PROFILE": "rotasi value area / POC"}


def _fin(v):
    try:
        return v is not None and math.isfinite(float(v))
    except Exception:
        return False


def _f(v, nd):
    return f"{float(v):.{nd}f}" if _fin(v) else "—"


def _dir(d):
    return STATE_TXT[1 if d > 0 else -1 if d < 0 else 0]


def _at(arr, j):
    return float(arr[j]) if 0 <= j < len(arr) and _fin(arr[j]) else None


def state_of(row):
    v = row.get("vote", 0)
    return STATE_TXT[1 if v > 0 else -1 if v < 0 else 0]


def tile_note(row, nd):
    """Teks pendek di bawah nama analisa pada kartu. `row` = baris metode dari payload analisa (votes.rows)."""
    v = row.get("vote", 0)
    if v:
        side = SIDE_TXT[1 if v > 0 else -1]
        return f"{side} · entry {_f(row.get('entry'), nd)}" if _fin(row.get("entry")) else side
    st = row.get("status")
    if st == "abstain":
        return row.get("why") or "abstain"
    if st == "gated":
        return "ditolak quant"
    if st == "veto-fund":
        return "veto fundamental"
    return "tanpa setup"


# ------------------------------------------------------------------------------------------------ TEKNIKAL per metode
def _tech_lines(key, x, i, nd, d_out):
    """(daftar kalimat kondisi, kalimat putusan). Kondisi = aturan metode yang sama dengan methods.py, dievaluasi pada bar i."""
    c, a = _at(x.c, i), _at(x.atr, i)
    L = []
    verdict = ""
    if key == "tsmom":
        l1, l2, l3 = x.cfg["tsmom"]
        sc = []
        for lb in (l1, l2, l3):
            p = _at(x.c, i - lb)
            if p is None or c is None:
                L.append(f"Data {lb} bar lalu belum cukup.")
                continue
            s = 1 if c > p else -1 if c < p else 0
            sc.append(s)
            L.append(f"Dibanding {lb} bar lalu ({_f(p, nd)}): harga {_f(c, nd)} → {'NAIK' if s > 0 else 'TURUN' if s < 0 else 'DATAR'}.")
        m = sum(sc) / 3 if len(sc) == 3 else 0.0
        L.append(f"Skor momentum tiga horizon = {m:+.2f}; arah baru ditetapkan bila ketiganya searah (skor ±1.00).")
        if abs(m) >= 0.99:
            verdict = f"Ketiga horizon searah {'naik' if m > 0 else 'turun'} → momentum tren {_dir(1 if m > 0 else -1)}."
        else:
            verdict = "Horizon tidak searah → tidak ada setup momentum."
    elif key == "emapb":
        e20, e50, e200, adx = _at(x.ema20, i), _at(x.ema50, i), _at(x.ema200, i), _at(x.adx, i)
        L.append(f"EMA20 {_f(e20, nd)} · EMA50 {_f(e50, nd)} · EMA200 {_f(e200, nd)}; harga {_f(c, nd)}.")
        if None not in (e20, e50, e200, c):
            up, dn = e20 > e50 > e200, e20 < e50 < e200
            L.append("Susunan EMA: " + ("NAIK (20>50>200)" if up else "TURUN (20<50<200)" if dn else "campur / belum searah") + f"; harga {'di atas' if c > e200 else 'di bawah'} EMA200.")
        L.append(f"ADX {_f(adx, 1)} ({'tren cukup kuat' if adx is not None and adx > 18 else 'tren lemah'}; syarat > 18).")
        verdict = ("Tren naik rapi dan cukup kuat → cari pullback BUY." if d_out > 0 else "Tren turun rapi dan cukup kuat → cari pullback SELL." if d_out < 0 else "Susunan EMA/ADX belum memenuhi syarat tren.")
    elif key == "donch":
        n = x.cfg["donch"]
        hi, lo = _at(x.dc_hi, i), _at(x.dc_lo, i)
        L.append(f"Kanal Donchian({n}): tertinggi {_f(hi, nd)} · terendah {_f(lo, nd)}; harga {_f(c, nd)}.")
        up = any(_fin(x.dc_hi[j]) and x.c[j] > x.dc_hi[j] for j in range(max(0, i - 5), i + 1))
        dn = any(_fin(x.dc_lo[j]) and x.c[j] < x.dc_lo[j] for j in range(max(0, i - 5), i + 1))
        L.append("Dalam 6 bar terakhir: " + ("ada breakout NAIK" if up and not dn else "ada breakout TURUN" if dn and not up else "breakout naik dan turun sama-sama ada (ambigu)" if up and dn else "tidak ada breakout") + ".")
        verdict = ("Breakout naik → tunggu retest level (BUY)." if d_out > 0 else "Breakout turun → tunggu retest level (SELL)." if d_out < 0 else "Tidak ada breakout yang bisa dipakai (atau berlawanan bias timeframe besar).")
    elif key == "macdadx":
        mh, mh1, pdi, mdi = _at(x.macd_h, i), _at(x.macd_h, i - 1), _at(x.pdi, i), _at(x.mdi, i)
        adx, adx2 = _at(x.adx, i), _at(x.adx, i - 2)
        L.append(f"Histogram MACD {_f(mh, nd + 1)} ({'menguat' if None not in (mh, mh1) and mh > mh1 else 'melemah' if None not in (mh, mh1) and mh < mh1 else 'datar'}).")
        L.append(f"+DI {_f(pdi, 1)} vs -DI {_f(mdi, 1)}; ADX {_f(adx, 1)} ({'naik' if None not in (adx, adx2) and adx > adx2 else 'tidak naik'}; syarat > 20 dan naik).")
        verdict = ("MACD positif & menguat, +DI dominan, ADX kuat dan naik → momentum BUY." if d_out > 0 else "MACD negatif & melemah, -DI dominan, ADX kuat dan naik → momentum SELL." if d_out < 0 else "Syarat momentum (MACD + DI + ADX) belum lengkap.")
    elif key == "squeeze":
        rk = _at(x.bw_rank, i)
        sq = any(_fin(x.bw_rank[j]) and x.bw_rank[j] <= 0.2 for j in range(max(0, i - 11), i + 1))
        L.append(f"Lebar Bollinger berada di persentil {_f(rk * 100 if rk is not None else None, 0)}% dari {x.cfg['squeeze_lb']} bar terakhir ({'SEMPIT' if rk is not None and rk <= 0.2 else 'normal'}); squeeze dalam 12 bar terakhir: {'ya' if sq else 'tidak'}.")
        L.append(f"Harga {_f(c, nd)} vs band atas {_f(_at(x.bb_up, i), nd)} / bawah {_f(_at(x.bb_lo, i), nd)}.")
        verdict = ("Keluar dari squeeze ke atas → breakout BUY." if d_out > 0 else "Keluar dari squeeze ke bawah → breakout SELL." if d_out < 0 else "Tidak ada breakout dari kondisi squeeze.")
    elif key == "rsi2":
        r2, e200 = _at(x.rsi2, i), _at(x.ema200, i)
        L.append(f"RSI(2) = {_f(r2, 1)} (jenuh jual < 10, jenuh beli > 90); harga {_f(c, nd)} {'di atas' if None not in (c, e200) and c > e200 else 'di bawah'} EMA200 {_f(e200, nd)}.")
        verdict = ("Jenuh jual di tren naik (di atas EMA200) → rebound BUY." if d_out > 0 else "Jenuh beli di tren turun (di bawah EMA200) → pantulan turun SELL." if d_out < 0 else "RSI(2) tidak ekstrem atau tidak searah tren EMA200.")
    elif key == "bbz":
        z, adx, er = _at(x.bb_z, i), _at(x.adx, i), _at(x.er, i)
        rng = adx is not None and er is not None and adx < 22 and er < 0.35
        L.append(f"Z-score Bollinger {_f(z, 2)} (ekstrem bila < −1.9 atau > +1.9).")
        L.append(f"ADX {_f(adx, 1)} (syarat < 22) · Efficiency Ratio {_f(er, 2)} (syarat < 0.35) → pasar {'SIDEWAYS (cocok untuk mean-reversion)' if rng else 'BERTREN (mean-reversion tidak dipakai)'}.")
        verdict = ("Harga terlalu jauh di bawah rata-rata saat sideways → BUY." if d_out > 0 else "Harga terlalu jauh di atas rata-rata saat sideways → SELL." if d_out < 0 else "Tidak ekstrem atau pasar sedang bertren.")
    elif key == "struct":
        sh, sl = _at(x.sh1, i), _at(x.sl1, i)
        L.append(f"Swing high terakhir {_f(sh, nd)} · swing low terakhir {_f(sl, nd)}; harga {_f(c, nd)}.")
        L.append("Break of Structure (BOS) naik = close menembus swing high; BOS turun = close menembus swing low; entry di pullback ke area tengah (equilibrium).")
        verdict = ("BOS naik terkonfirmasi dan harga masih di atas swing low → BUY pullback." if d_out > 0 else "BOS turun terkonfirmasi dan harga masih di bawah swing high → SELL pullback." if d_out < 0 else "Belum ada BOS yang valid.")
    elif key == "sweep":
        lb = x.cfg["sweep_lb"]
        lo_pool = float(np.nanmin(x.l[max(0, i - lb):i])) if i > 0 else None
        hi_pool = float(np.nanmax(x.h[max(0, i - lb):i])) if i > 0 else None
        L.append(f"Pool likuiditas {lb} bar terakhir: bawah ≈ {_f(lo_pool, nd)} · atas ≈ {_f(hi_pool, nd)}.")
        verdict = ("Dalam 3 bar terakhir harga menyapu pool bawah lalu ditutup kembali di atasnya → reversal BUY." if d_out > 0 else
                   "Dalam 3 bar terakhir harga menyapu pool atas lalu ditutup kembali di bawahnya → reversal SELL." if d_out < 0 else "Tidak ada sapuan likuiditas yang ditutup kembali dalam 3 bar terakhir.")
    elif key == "value":
        poc, vah, val = _at(x.poc, i), _at(x.vah, i), _at(x.val, i)
        pos = "—"
        if None not in (c, vah, val):
            pos = "DI ATAS value area" if c > vah else "DI BAWAH value area" if c < val else "DI DALAM value area"
        L.append(f"Value area: VAL {_f(val, nd)} · POC {_f(poc, nd)} · VAH {_f(vah, nd)}; harga {_f(c, nd)} {pos}.")
        verdict = ("Harga kembali masuk value area dari bawah / berada di atas POC searah bias → rotasi BUY." if d_out > 0 else
                   "Harga kembali masuk value area dari atas / berada di bawah POC searah bias → rotasi SELL." if d_out < 0 else "Tidak ada penutupan kembali ke value area dan harga tidak searah bias-POC.")
    return L, verdict


def _profile_text(x, i, nd, nodes):
    c = _at(x.c, i)
    out = []
    p = x.profs[x.pidx[i]] if x.pidx[i] >= 0 else None
    if p:
        src = "profil waktu-harga (volume tidak tersedia dari sumber)" if p.get("src") == "tpo" else "volume"
        pos = "di dalam value area" if p["val"] <= c <= p["vah"] else "di atas value area" if c > p["vah"] else "di bawah value area"
        out.append(f"Profil {src}: POC {_f(p['poc'], nd)} · VAH {_f(p['vah'], nd)} · VAL {_f(p['val'], nd)}; harga {_f(c, nd)} {pos}.")
        if p.get("hvn"):
            out.append("Area volume tinggi (HVN): " + ", ".join(_f(v, nd) for v in p["hvn"][:4]) + ".")
    else:
        out.append("Profil volume belum tersedia (data belum cukup).")
    pools = sorted(nodes.get("pools", []), key=lambda q: abs(q["price"] - c))[:4]
    if pools:
        out.append("Pool likuiditas terdekat: " + " · ".join(f"{'▲' if q['kind'] == 'high' else '▼'} {_f(q['price'], nd)} ({q['src']})" for q in pools) + ".")
    return out


def _fund_lines(fund, d, mode):
    L = []
    if not fund or (not fund.get("drivers") and not fund.get("conf")):
        L.append("Data fundamental belum tersedia untuk aset ini → konfirmasi dilewati (netral, tidak memengaruhi suara).")
        if fund and fund.get("note"):
            L.append(str(fund["note"]))
        return L, 0.0
    sc, conf = float(fund.get("score") or 0.0), float(fund.get("conf") or 0.0)
    L.append(f"Skor fundamental {sc:+.2f} (−1 sangat bearish … +1 sangat bullish), cakupan data {conf * 100:.0f}%.")
    drv = sorted(fund.get("drivers") or [], key=lambda r: abs(r["score"] * r["weight"]), reverse=True)[:4]
    for r in drv:
        L.append(f"• {str(r['key']).upper()} {r['score']:+.2f} (bobot {r['weight'] * 100:.0f}%): {r['text']}")
    fs = sc * conf
    if d:
        fa = d * fs
        word = "SEARAH" if fa > 0.1 else "BERLAWANAN" if fa < -0.1 else "NETRAL terhadap"
        L.append(f"Terhadap arah {SIDE_TXT[d]} metode ini: {word} (keselarasan {fa:+.2f}); bobot suara ×{1 + PARAMS['fund_w'] * fa:.2f}."
                 + (" Berlawanan kuat (≤ −0.60) → VETO (tidak berlaku untuk scalping)." if fa <= -0.6 and mode != "scalp" else ""))
    if fund.get("block"):
        L.append(f"⚠ {fund['block']}")
    return L, fs


# ------------------------------------------------------------------------------------------------ satu metode
def _method(i_n, key, row, x, i, nd, res, fund, mode):
    d_out = int(x.out[key]["d"][i])
    st = row.get("status")
    state = state_of(row)
    tech, tverdict = _tech_lines(key, x, i, nd, d_out)
    htf = int(x.htf[i])
    head = f"Metode: {LABEL[key]} ({KIND_TXT.get(KIND[key], KIND[key])}). Timeframe {x.cfg['tf']}; bias {x.cfg['htf_label']}: {_dir(htf)}; ATR {_f(_at(x.atr, i), nd)}."
    tl = [head] + tech
    if d_out:
        tl.append(f"Hipotesis {SIDE_TXT[d_out]}: pullback ke {_f(x.out[key]['e'][i], nd)}, SL awal {_f(x.out[key]['sl'][i], nd)}.")
    tl.append(tverdict)

    vl = _profile_text(x, i, nd, res["nodes"])
    plan = row.get("plan")
    if plan:
        qual = {"valid": "VALID — entry berada di level bernilai", "recalc": "DIHITUNG ULANG — entry digeser ke level bernilai terdekat", "weak": "LEMAH — tidak ada level volume/likuiditas dekat entry"}.get(plan["status"], plan["status"])
        vl.append(f"Validasi titik entry {_f(plan['entry'], nd)}: {qual}.")
        for n in plan.get("notes") or []:
            vl.append("• " + n)
        vl.append(f"SL {_f(plan['sl'], nd)} (1R = {_f(abs(plan['entry'] - plan['sl']), nd)}), TP1 {_f(plan['tp'][0], nd)}.")
    elif d_out:
        vl.append("Plan tidak lolos validasi (jarak SL/TP1 terhadap ATR atau level tidak memenuhi syarat) → metode abstain.")
    else:
        vl.append("Tidak ada entry yang divalidasi karena tidak ada setup teknikal.")

    fl, _ = _fund_lines(fund, d_out, mode)

    reg = res["regime"]
    ql = [f"Rezim pasar: {reg['label']} (Hurst {_f(reg.get('hurst'), 2)}, Variance-Ratio {_f(reg.get('vr'), 2)} z {_f(reg.get('vr_z'), 2)}, ER {_f(reg.get('er'), 2)}, persentil ATR {_f(reg.get('atr_pct'), 2)})."]
    if plan:
        rg = row.get("regime_w", 1.0)
        ql.append(("Metode " + KIND[key].lower() + f" kurang cocok dengan rezim {reg['label']} → bobot ×{rg:.1f}.") if rg < 1 else "Cocok dengan rezim → bobot penuh.")
        if row.get("n_hist"):
            ql.append(f"Rekam jejak metode ini di pair & timeframe ini: {row['n_hist']} sinyal tuntas, TP1 tersentuh {row['wins_hist'] / row['n_hist'] * 100:.0f}%, "
                      f"rata-rata {row['avg_r_hist']:+.2f}R, batas bawah (LCB) {row.get('lcb_r', 0):+.2f}R.")
        else:
            ql.append("Belum ada rekam jejak historis yang cukup → peluang memakai prior (campuran peluang acak dan rata-rata semua metode).")
        ql.append(f"Peluang TP1 (posterior Bayes) {row['p_post'] * 100:.0f}% · EV {row['ev']:+.2f}R. Ambang rencana gabungan: peluang TP1 ≥ {PARAMS['min_p'] * 100:.0f}% dan EV ≥ {PARAMS['min_ev']:+.2f}R.")
    else:
        ql.append("Tidak ada rencana trade untuk dihitung peluang/EV-nya.")

    if state != "WAITING":
        k = (f"{state}: {LABEL[key]} (keluarga {row.get('family')}) menyarankan {SIDE_TXT[row['vote']]} (entry {_f(plan['entry'], nd)}). Lolos validasi level, "
             f"searah bias {x.cfg['htf_label']}, EV {row['ev']:+.2f}R. Satu suara dihitung untuk keluarga ini.")
    elif st == "abstain":
        k = f"WAITING: {row.get('why') or 'metode abstain'} — suara tidak dihitung."
    elif st == "gated":
        k = "WAITING: EV historis metode ini pada pair ini tidak positif → ditolak oleh filter kuantitatif."
    elif st == "veto-fund":
        k = "WAITING: arah metode bertentangan kuat dengan fundamental → diveto."
    else:
        k = "WAITING: kondisi metode belum terpenuhi (tidak ada setup)."
    return dict(n=i_n, key=key, label=LABEL[key], kind=KIND[key], state=state, status=st,
                sections=[dict(title="TEKNIKAL", lines=tl), dict(title="VOLUME & LIQUIDITY", lines=vl), dict(title="FUNDAMENTAL", lines=fl),
                          dict(title="QUANTITATIVE", lines=ql), dict(title=f"KESIMPULAN ANALISA {i_n}", lines=[k])])


# ------------------------------------------------------------------------------------------------ keputusan akhir
def _overall(x, i, nd, res, fund, mode, be):
    pr = {**PARAMS, **MODE_PARAMS.get(mode, {})}
    rows = res["rows"]
    bull, bear = res["bull"], res["bear"]
    wait = len(res.get("families") or []) - bull - bear
    htf = int(x.htf[i])
    name = lambda r: r["label"]
    fam = res.get("families") or []
    sec = []
    sec.append(dict(title="HASIL SUARA KELUARGA FAKTOR", lines=[
        f"{bull} keluarga BULLISH · {bear} keluarga BEARISH · {max(0, wait)} netral/abstain "
        f"(dari {len(rows)} metode: {res.get('method_bull', 0)} bullish, {res.get('method_bear', 0)} bearish).",
        f"Syarat sinyal gaya {x.cfg['tf']}: minimal {pr['min_agree']} KELUARGA searah dan selisih ≥ {pr['min_margin']} keluarga.",
        "BULLISH: " + (", ".join(f["family"] for f in fam if f["vote"] > 0) or "—"),
        "BEARISH: " + (", ".join(f["family"] for f in fam if f["vote"] < 0) or "—")]))
    tl = [f"Bias timeframe besar ({x.cfg['htf_label']}): {_dir(htf)}. Hanya analisa yang searah bias ini yang ikut memilih."
          if pr.get("need_htf") else f"Bias {x.cfg['htf_label']}: {_dir(htf)}.",
          f"ADX {_f(_at(x.adx, i), 1)} · RSI(14) {_f(_at(x.rsi14, i), 1)} · EMA20/50/200 {_f(_at(x.ema20, i), nd)} / {_f(_at(x.ema50, i), nd)} / {_f(_at(x.ema200, i), nd)}."]
    sec.append(dict(title="TEKNIKAL", lines=tl))
    vl = _profile_text(x, i, nd, res["nodes"])
    plans = [r["plan"] for r in rows if r["vote"] and r.get("plan")]
    if plans:
        cnt = {k: sum(1 for p in plans if p["status"] == k) for k in ("valid", "recalc", "weak")}
        vl.append(f"Entry analisa yang memilih: {cnt['valid']} valid, {cnt['recalc']} dihitung ulang, {cnt['weak']} lemah.")
    sec.append(dict(title="VOLUME & LIQUIDITY", lines=vl))
    fl, _ = _fund_lines(fund, 0, mode)
    sec.append(dict(title="FUNDAMENTAL", lines=fl))
    reg = res["regime"]
    ql = [f"Rezim pasar: {reg['label']} (Hurst {_f(reg.get('hurst'), 2)}, VR {_f(reg.get('vr'), 2)}, ER {_f(reg.get('er'), 2)})."]
    if _fin(res.get("pooled_p")):
        ql.append(f"Peluang TP1 gabungan semua metode (historis) {res['pooled_p'] * 100:.0f}%.")
    if res["signal"] != "WAIT":
        ql.append(f"Rencana gabungan: peluang TP1 {res['p_tp1'] * 100:.0f}% · EV empiris {res['ev']:+.2f}R "
                  f"(model {res.get('ev_model', res['ev']):+.2f}R) · drift tersirat θ {res['theta']:.2f}.")
    else:
        ql.append("Quant tidak menghitung rencana final karena belum ada konsensus yang lolos." if not str(res.get("reason") or "").startswith("quant") else str(res["reason"]))
    sec.append(dict(title="QUANTITATIVE", lines=ql))
    if res["signal"] != "WAIT":
        pl = res["plan"]
        side = pl["d"]
        risk = abs(pl["entry"] - pl["sl"])
        rr = [abs(t - pl["entry"]) / risk for t in pl["tp"]]
        agree = ", ".join(LABEL[k] for k in res["agree"])
        k = [f"{SIDE_TXT[side]} — {len(res['agree'])} metode dari {res.get('n_agree', len(res['agree']))} keluarga searah ({agree}); "
             f"searah bias {x.cfg['htf_label']}, lolos ambang quant. Fundamental hanya menyesuaikan ukuran posisi, bukan arah.",
             f"Entry {_f(pl['entry'], nd)} · SL {_f(pl['sl'], nd)} (−1R) · TP1 {_f(pl['tp'][0], nd)} (+{rr[0]:.2f}R) · TP2 {_f(pl['tp'][1], nd)} (+{rr[1]:.2f}R) · TP MAX {_f(pl['tp'][2], nd)} (+{rr[2]:.2f}R).",
             f"Pembagian posisi {int(TP_WEIGHTS[0] * 100)}% / {int(TP_WEIGHTS[1] * 100)}% / {int(TP_WEIGHTS[2] * 100)}%. " + ("Breakeven ON: setelah TP1 tercapai SL dipindah ke entry." if be else "Breakeven OFF: SL & TP tetap.")]
        verdict = SIDE_TXT[side]
    else:
        k = [f"WAIT — {res.get('reason') or 'belum ada konsensus'}."]
        verdict = "WAIT"
    sec.append(dict(title="KESIMPULAN AKHIR", lines=k))
    return dict(state=verdict, sections=sec)


def build(x, i, res, fund, mode, be, nd):
    """Kembalikan dict(methods={key: {...}}, overall={...}) untuk satu hasil analisa."""
    methods = {}
    for n, (key, _, _) in enumerate(METHODS, start=1):
        row = next(r for r in res["rows"] if r["key"] == key)
        methods[key] = _method(n, key, row, x, i, nd, res, fund, mode)
    return dict(methods=methods, overall=_overall(x, i, nd, res, fund, mode, be))


def add_latched(ex, payload):
    """Tambahkan catatan ke kesimpulan akhir bila yang tampil adalah order terkunci dari sinyal sebelumnya (bukan hasil analisa saat ini)."""
    pl = payload.get("plan")
    if not ex or not pl or payload.get("state") not in ("PENDING", "OPEN"):
        return
    nd = payload.get("digits", 5)
    st = "menunggu harga menyentuh entry (LIMIT)" if payload["state"] == "PENDING" else "sedang berjalan"
    ex["overall"]["sections"][-1]["lines"].append(
        f"Catatan: order {payload['signal']} dari sinyal sebelumnya masih {st} — entry {_f(pl['entry'], nd)}, SL {_f(pl['sl'], nd)}. Sinyal yang sudah terbit dikunci sampai selesai, jadi tidak berubah mengikuti analisa terbaru.")
