"""Simulasi/pelacakan satu rencana trade pada bar-bar nyata (dipakai pelacak sinyal live & statistik metode).

Aturan (konservatif, hasil audit):
  - Entry = limit di titik pullback. Batal bila tidak terisi dalam `expiry` bar, atau TP1 tersentuh lebih dulu (MISSED).
  - Bar yang menyentuh entry DAN TP1 sekaligus = MISSED (urutan intrabar tidak diketahui; jangan menguntungkan diri sendiri).
  - Gap: SL diisi di harga open bila open sudah melewati SL (bukan tepat di harga SL); TP diisi di open bila open sudah melewati TP.
  - Di satu bar yang menyentuh SL dan TP sekaligus, SL dianggap lebih dulu.
  - Breakeven (BE) ON: setelah TP1 tercapai, SL dipindah ke harga entry mulai bar BERIKUTNYA. OFF: SL dan TP tetap.
  - Biaya (spread+komisi+slippage) dikenakan pada SETIAP leg yang keluar, bukan sekali per trade.
  - Swap/financing diakrualkan per bar pada sisa posisi (`plan["swap"]` = pecahan harga per bar).
  - Posisi dibagi TP1/TP2/TP MAX menurut bobot `w`. Sisa ditutup di harga bar terakhir bila `max_hold` habis.
"""


def simulate(plan, o, h, l, c, i0, be=True):
    """i0 = indeks bar keputusan (sinyal terbit di penutupan bar i0). Mengembalikan dict hasil.

    status: NOFILL (tidak terisi/kedaluwarsa), MISSED (TP1 tersentuh sebelum terisi), PENDING (masih menunggu, data habis),
            OPEN (sudah terisi, belum selesai), CLOSED (selesai: lihat r, tp_hits, exit)."""
    d, e, sl0 = plan["d"], plan["entry"], plan["sl"]
    tps, w = plan["tp"], plan["w"]
    risk = abs(e - sl0)
    n = len(c)
    res = dict(status="PENDING", r=0.0, tp_hits=0, fill=None, exit=None, exit_reason=None, sl_now=sl0, stopped=False,
               cost=0.0, swap=0.0, bars_held=0)
    if risk <= 0:
        res["status"] = "NOFILL"
        return res
    cost_r = plan.get("cost", 0.0) / risk
    swap_bar = plan.get("swap", 0.0) / risk
    exp_end = min(n, i0 + 1 + plan["expiry"])
    fill = None
    for k in range(i0 + 1, exp_end):
        if d > 0:
            hit_e, hit_tp = l[k] <= e, h[k] >= tps[0]
            hit_sl = l[k] <= sl0
        else:
            hit_e, hit_tp = h[k] >= e, l[k] <= tps[0]
            hit_sl = h[k] >= sl0
        if hit_e and hit_tp and not hit_sl:       # ambigu: entry + TP1 tanpa SL di bar yang sama -> konservatif MISSED
            res.update(status="MISSED", exit=k)
            return res
        if hit_e:
            fill = k
            break
        if hit_tp:
            res.update(status="MISSED", exit=k)
            return res
    if fill is None:
        res["status"] = "NOFILL" if (i0 + plan["expiry"] < n - 1 or exp_end - (i0 + 1) >= plan["expiry"]) else "PENDING"
        return res
    res["fill"] = fill
    sl, stage, rem, pnl = sl0, 0, 1.0, 0.0
    be_pending = False
    cost_acc = swap_acc = 0.0
    end = min(n, fill + plan["max_hold"] + 1)

    def _close_leg(frac, price, k):
        nonlocal rem, pnl, cost_acc
        pnl += frac * d * (price - e) / risk
        cost_acc += frac * cost_r
        rem -= frac

    for k in range(fill, end):
        if be_pending:
            sl, be_pending = e, False
        swap_acc += rem * swap_bar
        if d > 0:
            gap_sl, gap_tp = o[k] <= sl, o[k] >= tps[stage]
        else:
            gap_sl, gap_tp = o[k] >= sl, o[k] <= tps[stage]
        if gap_sl:                                # gap menembus SL: keluar di open (lebih buruk)
            px = min(o[k], sl) if d > 0 else max(o[k], sl)
            _close_leg(rem, px, k)
            res.update(stopped=True, exit=k, exit_reason="GAP-SL" if stage == 0 else ("BE" if (be and sl == e) else "SL"))
            break
        while gap_tp and stage < 3:               # gap melewati TP: isi di open (harga lebih baik, tapi realistis)
            _close_leg(w[stage], o[k], k)
            stage += 1
            if stage == 1 and be:
                be_pending = True
            if stage >= 3:
                break
            gap_tp = (o[k] >= tps[stage]) if d > 0 else (o[k] <= tps[stage])
        if stage >= 3 or rem <= 1e-9:
            rem = 0.0
            res.update(exit=k, exit_reason="TPMAX")
            break
        lo, hi = l[k], h[k]
        hit_sl = (lo <= sl) if d > 0 else (hi >= sl)
        if hit_sl:
            _close_leg(rem, sl, k)
            res.update(stopped=True, exit=k, exit_reason="BE" if (stage >= 1 and be and sl == e) else "SL")
            break
        while stage < 3 and ((hi >= tps[stage]) if d > 0 else (lo <= tps[stage])):
            _close_leg(w[stage], tps[stage], k)
            stage += 1
            if stage == 1 and be:
                be_pending = True
        res["sl_now"] = e if be_pending else sl
        if stage >= 3 or rem <= 1e-9:
            rem = 0.0
            res.update(exit=k, exit_reason="TPMAX")
            break
    else:
        if end - fill < plan["max_hold"] + 1 and end >= n:
            res.update(status="OPEN", r=pnl - cost_acc - swap_acc, tp_hits=stage, rem=rem, cost=cost_acc, swap=swap_acc, bars_held=end - fill)
            res["sl_now"] = e if (stage >= 1 and be) else sl0
            return res
        k = end - 1
        _close_leg(rem, c[k], k)
        res.update(exit=k, exit_reason="TIME")
    res.update(status="CLOSED", r=pnl - cost_acc - swap_acc, tp_hits=stage, rem=rem, cost=cost_acc, swap=swap_acc, bars_held=(res["exit"] or fill) - fill + 1)
    return res
