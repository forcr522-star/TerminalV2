"""Bot sinyal di latar belakang.

analysis_loop : saat SINYAL = ON, menganalisa SEMUA pair terpilih terus-menerus (24 jam), berulang tiap `ttl` gaya trading
                (scalping 2 mnt, intraday 5 mnt, swing 30 mnt). Saat SINYAL = OFF tidak ada satu pair pun yang dianalisa
                dan tidak ada sinyal baru yang dicatat.
tracker_loop  : memantau order yang sudah terbit (limit menunggu entry / posisi berjalan): entry terisi, SL, TP1/TP2/TP MAX,
                kedaluwarsa. Berjalan terus walau SINYAL = OFF supaya daftar order tetap akurat (ini bukan analisa pasar).

Hasil analisa terakhir tiap pair disimpan di memori + tabel kv (bertahan setelah restart) dan dipakai halaman INSIDE/ANALISIS.
"""
import asyncio
import json
import time
import traceback

from .. import store
from .. import snapshots as S
from ..providers import yahoo
from ..universe import BY_SYM
from . import control, explain, journal, service
from .config import MODES

RESULTS = {}      # sym -> payload analisa terakhir (tanpa candles) + at (detik epoch)
ERRORS = {}       # sym -> (detik epoch, pesan)
LIVE = {}         # id order -> dict keadaan live (lihat service.live_state)
STATE = dict(last_cycle=None, last_track=None)

ANALYZE_TIMEOUT = 180
ERROR_BACKOFF = 45
TRACK_EVERY = 20
KV_PREFIX = "sig_res:"


def _slim(payload):
    p = dict(payload)
    p.pop("candles", None)
    return p


def load():
    """Muat hasil analisa terakhir dari database (dipanggil saat start)."""
    RESULTS.clear()
    try:
        rows = store.query("SELECT k, v FROM kv WHERE k LIKE ?", (KV_PREFIX + "%",))
    except Exception:
        traceback.print_exc()
        return 0
    keep = set(control.get()["pairs"])
    for r in rows:
        sym = r["k"][len(KV_PREFIX):]
        try:
            if sym in keep:
                RESULTS[sym] = json.loads(r["v"])
            else:
                store.execute("DELETE FROM kv WHERE k=?", (r["k"],))
        except Exception:
            continue
    return len(RESULTS)


def forget(sym):
    RESULTS.pop(sym, None)
    ERRORS.pop(sym, None)
    try:
        store.execute("DELETE FROM kv WHERE k=?", (KV_PREFIX + sym,))
    except Exception:
        pass


def on_control_changed(state):
    """Pair yang dikeluarkan dari daftar analisa: hasil analisanya dibuang. Strategi diganti: bot hanya fokus ke strategi terpilih."""
    keep = set(state["pairs"])
    for sym in [s for s in list(RESULTS) + list(ERRORS) if s not in keep]:
        forget(sym)
    try:
        focus_strategy(state.get("strategy", "multi"))
    except Exception:
        traceback.print_exc()


FOCUS_NOTE = {"one": "strategi diganti ke STRATEGI ONE", "multi": "strategi diganti ke 10 METODE"}


def focus_strategy(strategy):
    """Bot hanya menjalankan strategi terpilih: limit order (PENDING) strategi LAIN dibatalkan (status CANCEL) supaya tidak terisi lagi.
    Posisi yang sudah terisi (OPEN) tetap dipantau sampai SL/TP/waktu habis, agar jurnal, menu SIGNAL dan EA tetap benar.
    Aturan strategi tidak diubah; hanya status jurnal yang ditulis. Mengembalikan jumlah limit yang dibatalkan."""
    n = 0
    note = FOCUS_NOTE.get(strategy, "strategi diganti")
    if strategy == "one":
        for r in store.query("SELECT id FROM signal_log WHERE status='PENDING'"):
            with service.JLOCK:
                act = journal.get(r["id"])
                if act and act["status"] == "PENDING":
                    journal.update(act["id"], "CANCEL", 0.0, 0, note=note)
                    LIVE.pop(act["id"], None)
                    n += 1
    else:
        from .one import journal as one_journal, service as one_service
        for r in one_journal.active_all():
            if r["status"] == "PENDING":
                one_journal.update(r["id"], "CANCEL", 0.0, note=note)
                one_service.LIVE.pop(r["key"], None)
                n += 1
    return n


def reset():
    """Dipakai pengujian."""
    RESULTS.clear()
    ERRORS.clear()
    LIVE.clear()
    STATE.update(last_cycle=None, last_track=None)


# ------------------------------------------------------------------------------------------------ analisa
def _strategy(r):
    return (r or {}).get("strategy") or "multi"


def _fresh(r, c):
    """Hasil analisa masih sesuai pengaturan sekarang (strategi, gaya, breakeven untuk 10 metode)."""
    if not r or _strategy(r) != c.get("strategy", "multi") or r.get("mode") != c["mode"]:
        return False
    return _strategy(r) == "one" or bool(r.get("be")) == bool(c["be"])


def _due(sym, mode, be, now, strategy="multi"):
    e = ERRORS.get(sym)
    if e and now - e[0] < ERROR_BACKOFF:
        return False
    r = RESULTS.get(sym)
    if not _fresh(r, dict(mode=mode, be=be, strategy=strategy)):
        return True
    return now - r.get("at", 0) >= MODES[mode]["ttl"]


WOKEN = {}        # sym -> (waktu, alasan) analisa ulang dipicu kejadian


def wake(syms, reason=""):
    """Kejadian mendadak memengaruhi pair ini -> analisa ulang segera (tidak menunggu TTL mode). Mengembalikan pair yang dipicu."""
    c = control.get()
    out = []
    for sym in syms:
        if sym in c["pairs"] and sym in RESULTS:
            RESULTS[sym]["at"] = 0.0
            WOKEN[sym] = (time.time(), reason)
            out.append(sym)
    return out


async def analyze_one(sym):
    """Analisa satu pair dengan pengaturan kontrol TERBARU. Mengembalikan True bila hasil disimpan."""
    c = control.get()
    if not c["on"] or sym not in c["pairs"]:
        return False
    try:
        if c.get("strategy") == "one":
            from .one import service as one_service
            payload = await asyncio.wait_for(one_service.analyze(sym, c["mode"], new_ok=control.is_on), ANALYZE_TIMEOUT)
        else:
            payload = await asyncio.wait_for(service.analyze(sym, c["mode"], c["be"], new_ok=control.is_on), ANALYZE_TIMEOUT)
    except Exception as exc:
        ERRORS[sym] = (time.time(), f"{type(exc).__name__}: {str(exc)[:160] or 'timeout'}")
        return False
    now = control.get()
    if sym not in now["pairs"]:
        return False     # dikeluarkan dari daftar selagi dianalisa
    slim = json.loads(S.encode(_slim(payload)))     # bersih: NaN -> null, angka numpy -> angka biasa (aman disimpan & dikirim sebagai JSON)
    slim["at"] = time.time()
    RESULTS[sym] = slim
    ERRORS.pop(sym, None)
    try:
        await asyncio.to_thread(store.kv_set, KV_PREFIX + sym, slim)
    except Exception:
        traceback.print_exc()
    return True


async def run_once(concurrency=3):
    """Satu putaran: analisa semua pair yang sudah waktunya. Mengembalikan jumlah pair yang dikerjakan (0 bila OFF / tidak ada yang jatuh tempo)."""
    c = control.get()
    if not c["on"]:
        return 0
    now = time.time()
    todo = [s for s in c["pairs"] if _due(s, c["mode"], c["be"], now, c.get("strategy", "multi"))]
    todo.sort(key=lambda s: RESULTS.get(s, {}).get("at", 0))
    if not todo:
        return 0
    sem = asyncio.Semaphore(max(1, concurrency))

    async def one(s):
        async with sem:
            if control.is_on():
                await analyze_one(s)

    await asyncio.gather(*[one(s) for s in todo])
    STATE["last_cycle"] = time.time()
    return len(todo)


async def analysis_loop(first=0):
    await asyncio.sleep(first)
    try:                                   # tunggu preload tahap 1 (maks. 10 mnt) bila sedang berjalan: CPU dipakai memuat menu
        from .. import preload
        await preload.wait_done(600)
    except Exception:
        pass
    while True:
        try:
            n = await run_once()
        except asyncio.CancelledError:
            raise
        except Exception:
            traceback.print_exc()
            n = 0
        await asyncio.sleep(0.5 if n else 3)


# ------------------------------------------------------------------------------------------------ pelacak order
def _track_rows(rows, df, be):
    """Evaluasi order aktif terhadap data harga; perbarui jurnal + keadaan live. Berjalan di thread."""
    for row in rows:
        with service.JLOCK:
            act = journal.get(row["id"])
            if not act or act["status"] not in ("PENDING", "OPEN"):
                LIVE.pop(row["id"], None)
                continue
            label, res, live = service.live_state(act, df, be)
            journal.update(act["id"], label, res["r"] if res else 0.0, res["tp_hits"] if res else 0, be=be)
        if label in ("PENDING", "OPEN"):
            LIVE[act["id"]] = live
        else:
            LIVE.pop(act["id"], None)


ONE_TRACK_EVERY = 60
_one_tracked = {}


async def track_one():
    """Order strategi ONE: status (terisi, TP1/BE, TP2, SL, batal C1-C6) dihitung ulang oleh engine ONE pada bar tutup.
    Tetap berjalan saat SINYAL OFF (tanpa menerbitkan setup baru)."""
    from .one import journal as one_journal, service as one_service
    rows = await asyncio.to_thread(one_journal.active_all)
    live = {r["key"] for r in rows}
    for k in [k for k in one_service.LIVE if k not in live]:
        one_service.LIVE.pop(k, None)
    groups = {(r["sym"], r["mode"]) for r in rows}
    now = time.time()
    for sym, mode in groups:
        if now - _one_tracked.get((sym, mode), 0) < ONE_TRACK_EVERY:
            continue
        _one_tracked[(sym, mode)] = now
        try:
            await asyncio.wait_for(one_service.analyze(sym, mode, issue=False), ANALYZE_TIMEOUT)
        except Exception:
            traceback.print_exc()
    return len(rows)


async def track_once(concurrency=3):
    try:                                   # sisa limit strategi lain (mis. dari sebelum restart) tidak dibiarkan terisi
        await asyncio.to_thread(focus_strategy, control.get().get("strategy", "multi"))
    except Exception:
        traceback.print_exc()
    try:
        await track_one()
    except Exception:
        traceback.print_exc()
    rows = await asyncio.to_thread(journal.active_all)
    ids = {r["id"] for r in rows}
    for k in [k for k in LIVE if k not in ids]:
        LIVE.pop(k, None)
    if not rows:
        STATE["last_track"] = time.time()
        return 0
    be = control.get()["be"]
    groups = {}
    for r in rows:
        groups.setdefault((r["sym"], r["mode"]), []).append(r)
    sem = asyncio.Semaphore(max(1, concurrency))

    async def one(sym, mode, rs):
        a = BY_SYM.get(sym.upper())
        if not a or mode not in MODES:
            return
        async with sem:
            try:
                cfg = MODES[mode]
                df = await yahoo.ohlcv(a["y"], cfg["yf_period"], cfg["yf_interval"])
                if df is None or len(df) == 0:
                    return
                df = service.completed(df, cfg["minutes"])     # finalisasi status hanya pada bar yang sudah tutup
                await asyncio.to_thread(_track_rows, rs, df, be)
            except Exception:
                traceback.print_exc()

    await asyncio.gather(*[one(s, m, rs) for (s, m), rs in groups.items()])
    STATE["last_track"] = time.time()
    return len(rows)


async def tracker_loop(first=0):
    await asyncio.sleep(first)
    while True:
        try:
            await track_once()
        except asyncio.CancelledError:
            raise
        except Exception:
            traceback.print_exc()
        await asyncio.sleep(TRACK_EVERY)


# ------------------------------------------------------------------------------------------------ data untuk halaman admin
def _dominance(votes):
    return "BUY" if votes["bull"] > votes["bear"] else "SELL" if votes["bear"] > votes["bull"] else "NEUTRAL"


def overview():
    """Ringkasan tiap pair terpilih: dominasi 10 analisa (titik hijau/merah/abu di list pair)."""
    c = control.get()
    out = []
    for s in c["pairs"]:
        a = BY_SYM[s.upper()]
        item = dict(sym=a["sym"], name=a["name"], cls=a["cls"], ready=False, fresh=False, dom=None, bull=0, bear=0, wait=0, signal=None, state=None, price=None, at=None)
        r = RESULTS.get(s)
        if r and _strategy(r) == "one":
            st = (r.get("one") or {}).get("setup")
            item.update(ready=True, fresh=_fresh(r, c), strategy="one", dom=r["signal"] if r["signal"] in ("BUY", "SELL") else "NEUTRAL",
                        signal=r["signal"], state=r["state"], price=r.get("price"), at=r.get("at"), asof=r.get("asof"),
                        one=dict(type=st["type"], status=st["status"], rr=st["rr_final"], score=st["score"]) if st else None,
                        trend=((r.get("one") or {}).get("structure") or {}).get("trend"), reason=r.get("reason"))
        elif r:
            V = r["votes"]
            mb, mr = V.get("method_bull", V["bull"]), V.get("method_bear", V["bear"])
            item.update(ready=True, fresh=_fresh(r, c), dom=_dominance(V), bull=mb, bear=mr, wait=V.get("method_total", 10) - mb - mr,
                        signal=r["signal"], state=r["state"], price=r.get("price"), at=r.get("at"), asof=r.get("asof"))
            sh = ((r.get("layers") or {}).get("fundamental") or {}).get("shock")
            if sh and sh.get("events"):
                item["shock"] = dict(score=sh.get("score"), guard=bool(sh.get("guard")), n=len(sh["events"]), top=sh["events"][0]["title"][:120])
        e = ERRORS.get(s)
        if e:
            item["error"], item["error_at"] = e[1], e[0]
        out.append(item)
    return out


def status():
    c = control.get()
    ov = overview()
    return dict(on=c["on"], total=len(ov), analyzed=sum(1 for o in ov if o["fresh"]), errors=sum(1 for o in ov if o.get("error")),
                last_cycle=STATE["last_cycle"], last_track=STATE["last_track"], active_orders=len(LIVE) + _one_live(), strategy=c.get("strategy", "multi"))


def bot_summary():
    """Ringkasan kerja bot untuk tabel order (admin & user): bot hidup, berapa pair sudah dianalisa, jam entry.
    Tanpa isi analisa (aman untuk user). Menjawab "24 jam tidak ada order: bot mati atau memang tidak ada setup?"."""
    from .config import SESSION_UTC, FRIDAY_CUTOFF_UTC
    c = control.get()
    ov = overview()
    ats = [o["at"] for o in ov if o.get("at")]
    strat = c.get("strategy", "multi")
    se = SESSION_UTC.get(c["mode"])                          # jam entry 10 METODE (board STRATEGI ONE tidak memakai ringkasan ini)
    ses = (f"entry baru {se[0]:02d}:00-{se[1]:02d}:00 UTC Senin-Jumat (Jumat s/d {FRIDAY_CUTOFF_UTC:02d}:00), kripto 24 jam" if se
           else "entry baru sepanjang hari (Jumat s/d %02d:00 UTC), kripto 24 jam" % FRIDAY_CUTOFF_UTC)
    return dict(on=c["on"], strategy=strat, mode_label=MODES[c["mode"]]["label"], total=len(ov), analyzed=sum(1 for o in ov if o["fresh"]),
                last_at=max(ats) if ats else None, with_signal=sum(1 for o in ov if o.get("signal") in ("BUY", "SELL")), session=ses)


def _one_live():
    try:
        from .one import service as one_service
        return len(one_service.LIVE)
    except Exception:
        return 0


def detail(symbol):
    """Isi halaman INSIDE/ANALISIS untuk satu pair: 10 kartu analisa + teks penjelasan (hasil analisa)."""
    c = control.get()
    a = BY_SYM.get(str(symbol).upper())
    if not a or a["sym"] not in c["pairs"]:
        raise ValueError("pair tidak ada di daftar yang dianalisa")
    r = RESULTS.get(a["sym"])
    base = dict(symbol=a["sym"], name=a["name"], cls=a["cls"], mode=c["mode"], mode_label=MODES[c["mode"]]["label"], tf=MODES[c["mode"]]["tf"], on=c["on"], ready=False, fresh=False)
    e = ERRORS.get(a["sym"])
    if e:
        base["error"] = e[1]
    if not r:
        return base
    base["strategy"] = c.get("strategy", "multi")
    if _strategy(r) == "one":
        base.update(ready=True, fresh=_fresh(r, c), at=r.get("at"), asof=r.get("asof"), price=r.get("price"), digits=r.get("digits", 5), atr=r.get("atr"),
                    signal=r["signal"], state=r["state"], reason=r.get("reason"), analysis_mode=r.get("mode"), result_strategy="one",
                    one=r.get("one"), shock=((r.get("layers") or {}).get("fundamental") or {}).get("shock"), woken=WOKEN.get(a["sym"]),
                    fundamental=(r.get("layers") or {}).get("fundamental"))
        return base
    nd = r.get("digits", 5)
    V = r["votes"]
    tiles = []
    for n, row in enumerate(V["rows"], start=1):
        tiles.append(dict(n=n, key=row["key"], label=row["label"], kind=row["kind"], state=explain.state_of(row), status=row["status"], note=explain.tile_note(row, nd),
                          entry=row.get("entry"), sl=row.get("sl"), tp1=row.get("tp1"), p=row.get("p"), ev=row.get("ev")))
    base.update(ready=True, fresh=_fresh(r, c), at=r.get("at"), asof=r.get("asof"), price=r.get("price"), digits=nd, result_strategy="multi",
                signal=r["signal"], state=r["state"], reason=r.get("reason"), bull=V.get("method_bull", V["bull"]), bear=V.get("method_bear", V["bear"]),
                wait=V.get("method_total", 10) - V.get("method_bull", V["bull"]) - V.get("method_bear", V["bear"]),
                families=V.get("families", []), dom=_dominance(V),
                tiles=tiles, explain=r.get("explain"), analysis_mode=r.get("mode"), plan=r.get("plan"), track=r.get("track"),
                shock=((r.get("layers") or {}).get("fundamental") or {}).get("shock"), woken=WOKEN.get(a["sym"]))
    return base
