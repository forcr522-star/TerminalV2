"""Bot sinyal di latar belakang.

analysis_loop : saat SINYAL = ON, menganalisa SEMUA pair terpilih terus-menerus (24 jam), berulang tiap `ttl` gaya trading
                (scalping 2 mnt, intraday 5 mnt, swing 30 mnt). Saat SINYAL = OFF tidak ada satu pair pun yang dianalisa
                dan tidak ada sinyal baru yang dicatat.
tracker_loop  : memantau order yang sudah terbit (limit menunggu entry / posisi berjalan): entry terisi, SL, TP1/TP2/TP MAX,
                kedaluwarsa. Berjalan terus walau SINYAL = OFF supaya daftar order tetap akurat (ini bukan analisa pasar).

Hasil analisa terakhir tiap pair disimpan di memori + tabel kv (bertahan setelah restart) dan dipakai halaman INSIDE/ANALISIS.
"""
import asyncio
import json
import time
import traceback

from .. import store
from .. import snapshots as S
from ..providers import yahoo
from ..universe import BY_SYM
from . import control, explain, journal, service
from .config import MODES

RESULTS = {}      # sym -> payload analisa terakhir (tanpa candles) + at (detik epoch)
ERRORS = {}       # sym -> (detik epoch, pesan)
LIVE = {}         # id order -> dict keadaan live (lihat service.live_state)
STATE = dict(last_cycle=None, last_track=None)

# Saat menu BACKTEST berjalan, semua fitur terminal dijeda sementara (sesuai permintaan) agar PC ringan.
PAUSE = dict(on=False, reason=None)


def paused():
    return bool(PAUSE["on"])


def set_paused(on, reason=None):
    PAUSE.update(on=bool(on), reason=reason)
    return dict(PAUSE)

ANALYZE_TIMEOUT = 180
ERROR_BACKOFF = 45
TRACK_EVERY = 20
KV_PREFIX = "sig_res:"


def _slim(payload):
    p = dict(payload)
    p.pop("candles", None)
    return p


def load():
    """Muat hasil analisa terakhir dari database (dipanggil saat start)."""
    RESULTS.clear()
    try:
        rows = store.query("SELECT k, v FROM kv WHERE k LIKE ?", (KV_PREFIX + "%",))
    except Exception:
        traceback.print_exc()
        return 0
    keep = set(control.get()["pairs"])
    for r in rows:
        sym = r["k"][len(KV_PREFIX):]
        try:
            if sym in keep:
                RESULTS[sym] = json.loads(r["v"])
            else:
                store.execute("DELETE FROM kv WHERE k=?", (r["k"],))
        except Exception:
            continue
    return len(RESULTS)


def forget(sym):
    RESULTS.pop(sym, None)
    ERRORS.pop(sym, None)
    try:
        store.execute("DELETE FROM kv WHERE k=?", (KV_PREFIX + sym,))
    except Exception:
        pass


def on_control_changed(state):
    """Pair yang dikeluarkan dari daftar analisa: hasil analisanya dibuang."""
    keep = set(state["pairs"])
    for sym in [s for s in list(RESULTS) + list(ERRORS) if s not in keep]:
        forget(sym)


def reset():
    """Dipakai pengujian."""
    RESULTS.clear()
    ERRORS.clear()
    LIVE.clear()
    STATE.update(last_cycle=None, last_track=None)


# ------------------------------------------------------------------------------------------------ analisa
def _due(sym, mode, be, now):
    e = ERRORS.get(sym)
    if e and now - e[0] < ERROR_BACKOFF:
        return False
    r = RESULTS.get(sym)
    if not r or r.get("mode") != mode or bool(r.get("be")) != bool(be):
        return True
    return now - r.get("at", 0) >= MODES[mode]["ttl"]


async def analyze_one(sym):
    """Analisa satu pair dengan pengaturan kontrol TERBARU. Mengembalikan True bila hasil disimpan."""
    c = control.get()
    if not c["on"] or sym not in c["pairs"]:
        return False
    try:
        payload = await asyncio.wait_for(service.analyze(sym, c["mode"], c["be"], new_ok=control.is_on), ANALYZE_TIMEOUT)
    except Exception as exc:
        ERRORS[sym] = (time.time(), f"{type(exc).__name__}: {str(exc)[:160] or 'timeout'}")
        return False
    now = control.get()
    if sym not in now["pairs"]:
        return False     # dikeluarkan dari daftar selagi dianalisa
    slim = json.loads(S.encode(_slim(payload)))     # bersih: NaN -> null, angka numpy -> angka biasa (aman disimpan & dikirim sebagai JSON)
    slim["at"] = time.time()
    RESULTS[sym] = slim
    ERRORS.pop(sym, None)
    try:
        await asyncio.to_thread(store.kv_set, KV_PREFIX + sym, slim)
    except Exception:
        traceback.print_exc()
    return True


async def run_once(concurrency=3):
    """Satu putaran: analisa semua pair yang sudah waktunya. Mengembalikan jumlah pair yang dikerjakan (0 bila OFF / tidak ada yang jatuh tempo)."""
    c = control.get()
    if not c["on"] or paused():
        return 0
    now = time.time()
    todo = [s for s in c["pairs"] if _due(s, c["mode"], c["be"], now)]
    todo.sort(key=lambda s: RESULTS.get(s, {}).get("at", 0))
    if not todo:
        return 0
    sem = asyncio.Semaphore(max(1, concurrency))

    async def one(s):
        async with sem:
            if control.is_on():
                await analyze_one(s)

    await asyncio.gather(*[one(s) for s in todo])
    STATE["last_cycle"] = time.time()
    return len(todo)


async def analysis_loop(first=0):
    await asyncio.sleep(first)
    try:                                   # tunggu preload tahap 1 (maks. 10 mnt): saat start CPU dipakai memuat menu
        from ..api import state
        t0 = time.time()
        while time.time() - t0 < 600 and (state.get("preload") or {}).get("phase") not in ("ready", None):
            await asyncio.sleep(5)
    except Exception:
        pass
    while True:
        try:
            n = await run_once()
        except asyncio.CancelledError:
            raise
        except Exception:
            traceback.print_exc()
            n = 0
        await asyncio.sleep(0.5 if n else 3)


# ------------------------------------------------------------------------------------------------ pelacak order
def _track_rows(rows, df, be):
    """Evaluasi order aktif terhadap data harga; perbarui jurnal + keadaan live. Berjalan di thread."""
    for row in rows:
        with service.JLOCK:
            act = journal.get(row["id"])
            if not act or act["status"] not in ("PENDING", "OPEN"):
                LIVE.pop(row["id"], None)
                continue
            label, res, live = service.live_state(act, df, be)
            journal.update(act["id"], label, res["r"] if res else 0.0, res["tp_hits"] if res else 0, be=be)
        if label in ("PENDING", "OPEN"):
            LIVE[act["id"]] = live
        else:
            LIVE.pop(act["id"], None)


async def track_once(concurrency=3):
    if paused():
        return 0
    rows = await asyncio.to_thread(journal.active_all)
    ids = {r["id"] for r in rows}
    for k in [k for k in LIVE if k not in ids]:
        LIVE.pop(k, None)
    if not rows:
        STATE["last_track"] = time.time()
        return 0
    be = control.get()["be"]
    groups = {}
    for r in rows:
        groups.setdefault((r["sym"], r["mode"]), []).append(r)
    sem = asyncio.Semaphore(max(1, concurrency))

    async def one(sym, mode, rs):
        a = BY_SYM.get(sym.upper())
        if not a or mode not in MODES:
            return
        async with sem:
            try:
                cfg = MODES[mode]
                df = await yahoo.ohlcv(a["y"], cfg["yf_period"], cfg["yf_interval"])
                if df is None or len(df) == 0:
                    return
                df = service.completed(df, cfg["minutes"])     # finalisasi status hanya pada bar yang sudah tutup
                await asyncio.to_thread(_track_rows, rs, df, be)
            except Exception:
                traceback.print_exc()

    await asyncio.gather(*[one(s, m, rs) for (s, m), rs in groups.items()])
    STATE["last_track"] = time.time()
    return len(rows)


async def tracker_loop(first=0):
    await asyncio.sleep(first)
    while True:
        try:
            await track_once()
        except asyncio.CancelledError:
            raise
        except Exception:
            traceback.print_exc()
        await asyncio.sleep(TRACK_EVERY)


# ------------------------------------------------------------------------------------------------ data untuk halaman admin
def _dominance(votes):
    return "BUY" if votes["bull"] > votes["bear"] else "SELL" if votes["bear"] > votes["bull"] else "NEUTRAL"


def overview():
    """Ringkasan tiap pair terpilih: dominasi 10 analisa (titik hijau/merah/abu di list pair)."""
    c = control.get()
    out = []
    for s in c["pairs"]:
        a = BY_SYM[s.upper()]
        item = dict(sym=a["sym"], name=a["name"], cls=a["cls"], ready=False, fresh=False, dom=None, bull=0, bear=0, wait=0, signal=None, state=None, price=None, at=None)
        r = RESULTS.get(s)
        if r:
            V = r["votes"]
            mb, mr = V.get("method_bull", V["bull"]), V.get("method_bear", V["bear"])
            item.update(ready=True, fresh=(r.get("mode") == c["mode"] and bool(r.get("be")) == bool(c["be"])), dom=_dominance(V), bull=mb, bear=mr, wait=V.get("method_total", 10) - mb - mr,
                        signal=r["signal"], state=r["state"], price=r.get("price"), at=r.get("at"), asof=r.get("asof"))
        e = ERRORS.get(s)
        if e:
            item["error"], item["error_at"] = e[1], e[0]
        out.append(item)
    return out


def status():
    c = control.get()
    ov = overview()
    return dict(on=c["on"], total=len(ov), analyzed=sum(1 for o in ov if o["fresh"]), errors=sum(1 for o in ov if o.get("error")),
                last_cycle=STATE["last_cycle"], last_track=STATE["last_track"], active_orders=len(LIVE))


def detail(symbol):
    """Isi halaman INSIDE/ANALISIS untuk satu pair: 10 kartu analisa + teks penjelasan (hasil analisa)."""
    c = control.get()
    a = BY_SYM.get(str(symbol).upper())
    if not a or a["sym"] not in c["pairs"]:
        raise ValueError("pair tidak ada di daftar yang dianalisa")
    r = RESULTS.get(a["sym"])
    base = dict(symbol=a["sym"], name=a["name"], cls=a["cls"], mode=c["mode"], mode_label=MODES[c["mode"]]["label"], tf=MODES[c["mode"]]["tf"], on=c["on"], ready=False, fresh=False)
    e = ERRORS.get(a["sym"])
    if e:
        base["error"] = e[1]
    if not r:
        return base
    nd = r.get("digits", 5)
    V = r["votes"]
    tiles = []
    for n, row in enumerate(V["rows"], start=1):
        tiles.append(dict(n=n, key=row["key"], label=row["label"], kind=row["kind"], state=explain.state_of(row), status=row["status"], note=explain.tile_note(row, nd),
                          entry=row.get("entry"), sl=row.get("sl"), tp1=row.get("tp1"), p=row.get("p"), ev=row.get("ev")))
    base.update(ready=True, fresh=(r.get("mode") == c["mode"] and bool(r.get("be")) == bool(c["be"])), at=r.get("at"), asof=r.get("asof"), price=r.get("price"), digits=nd,
                signal=r["signal"], state=r["state"], reason=r.get("reason"), bull=V.get("method_bull", V["bull"]), bear=V.get("method_bear", V["bear"]),
                wait=V.get("method_total", 10) - V.get("method_bull", V["bull"]) - V.get("method_bear", V["bear"]),
                families=V.get("families", []), dom=_dominance(V),
                tiles=tiles, explain=r.get("explain"), analysis_mode=r.get("mode"))
    return base
