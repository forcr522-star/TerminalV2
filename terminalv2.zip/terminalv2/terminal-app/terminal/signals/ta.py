"""Indikator teknikal vektor (pandas/numpy). Semua fungsi memakai kolom o,h,l,c,v dan TIDAK melihat bar masa depan."""
import numpy as np
import pandas as pd


def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def sma(s, n):
    return s.rolling(n).mean()


def rma(s, n):
    return s.ewm(alpha=1.0 / n, adjust=False).mean()


def true_range(df):
    pc = df["c"].shift()
    return pd.concat([df["h"] - df["l"], (df["h"] - pc).abs(), (df["l"] - pc).abs()], axis=1).max(axis=1)


def atr(df, n=14):
    return rma(true_range(df), n)


def rsi(c, n=14):
    d = c.diff()
    up, dn = rma(d.clip(lower=0), n), rma((-d).clip(lower=0), n)
    rs = up / dn.replace(0, np.nan)
    out = 100 - 100 / (1 + rs)
    return out.where(dn != 0, 100.0).where(~((up == 0) & (dn == 0)), 50.0)


def adx(df, n=14):
    up, dn = df["h"].diff(), -df["l"].diff()
    plus = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    minus = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    a = rma(true_range(df), n).replace(0, np.nan)
    pdi, mdi = 100 * rma(plus, n) / a, 100 * rma(minus, n) / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return rma(dx.fillna(0), n), pdi, mdi


def macd_hist(c, fast=12, slow=26, sig=9):
    m = ema(c, fast) - ema(c, slow)
    return m - ema(m, sig)


def bollinger(c, n=20, k=2.0):
    mid = sma(c, n)
    sd = c.rolling(n).std(ddof=0)
    up, lo = mid + k * sd, mid - k * sd
    z = (c - mid) / sd.replace(0, np.nan)
    bw = (up - lo) / mid.replace(0, np.nan)
    return mid, up, lo, z, bw


def efficiency_ratio(c, n=20):
    net = (c - c.shift(n)).abs()
    path = c.diff().abs().rolling(n).sum()
    return net / path.replace(0, np.nan)


def pivots(df, n=3):
    """Pivot fraktal n-kiri/n-kanan. Dikonfirmasi n bar SETELAH pivot (tidak ada look-ahead).

    Mengembalikan seri harga pivot-high / pivot-low terakhir yang sudah terkonfirmasi (sh1, sl1) dan sebelumnya (sh2, sl2).
    """
    h, l = df["h"], df["l"]
    w = 2 * n + 1
    is_h = (h == h.rolling(w, center=True).max())
    is_l = (l == l.rolling(w, center=True).min())
    ph = h.where(is_h).shift(n)   # nilai pivot-high muncul di bar konfirmasi
    pl = l.where(is_l).shift(n)

    def last_two(p):
        ev = p.dropna()
        cur = p.ffill()
        prev = pd.Series(np.nan, index=p.index)
        if len(ev) > 1:
            prev.loc[ev.index[1:]] = ev.values[:-1]
            prev = prev.ffill()
        return cur, prev
    sh1, sh2 = last_two(ph)
    sl1, sl2 = last_two(pl)
    return sh1, sh2, sl1, sl2


def hurst_vr(x, qs=(1, 2, 4, 8, 16)):
    """Eksponen Hurst dari skala simpangan baku return teragregasi: std(r_q) ~ q^H (0.5 = acak, >0.5 tren, <0.5 revert)."""
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    if len(x) < 8 * max(qs):
        return None
    pts = []
    for q in qs:
        m = len(x) // q
        if m < 8:
            continue
        agg = x[: m * q].reshape(m, q).sum(axis=1)
        s = agg.std()
        if s > 0:
            pts.append((np.log(q), np.log(s)))
    if len(pts) < 3:
        return None
    a = np.array(pts)
    return float(np.polyfit(a[:, 0], a[:, 1], 1)[0])


def variance_ratio(x, q=4):
    """Lo-MacKinlay VR(q) dan statistik z (homoskedastik). VR>1 tren, VR<1 mean-reversion."""
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    n = len(x)
    if n < q * 10:
        return None, None
    mu = x.mean()
    s1 = ((x - mu) ** 2).sum() / (n - 1)
    xq = np.convolve(x, np.ones(q), mode="valid")
    m = q * (n - q + 1) * (1 - q / n)
    sq = ((xq - q * mu) ** 2).sum() / m
    vr = sq / s1 if s1 > 0 else None
    if vr is None:
        return None, None
    var = 2 * (2 * q - 1) * (q - 1) / (3 * q * n)
    return float(vr), float((vr - 1) / np.sqrt(var))
