"""10 metode analisa TEKNIKAL (langkah 1). Tiap metode menghasilkan, untuk SETIAP bar, hipotesis: arah (+1/-1/0), titik pullback (entry),
SL struktural, dan kekuatan setup 0..1. Langkah 2-4 (Volume Profile & Liquidity, Fundamental, Quantitative) ada di engine.py.

Semua perhitungan hanya memakai data sampai bar itu (tanpa look-ahead)."""
import numpy as np
import pandas as pd

from .config import SL_ATR, MAX_ENTRY_ATR

METHODS = [
    ("tsmom", "Time-Series Momentum", "TREND"),
    ("emapb", "EMA Stack Pullback", "TREND"),
    ("donch", "Donchian Breakout + Retest", "BREAKOUT"),
    ("macdadx", "MACD + ADX Momentum", "MOMENTUM"),
    ("squeeze", "Volatility Squeeze Breakout", "BREAKOUT"),
    ("rsi2", "RSI(2) Mean Reversion", "REVERSION"),
    ("bbz", "Bollinger Z-Score Reversion", "REVERSION"),
    ("struct", "Market Structure BOS + Pullback", "STRUCTURE"),
    ("sweep", "Liquidity Sweep Reversal", "LIQUIDITY"),
    ("value", "Value Area / POC Rotation", "PROFILE"),
]
NAMES = [m[0] for m in METHODS]
KIND = {m[0]: m[2] for m in METHODS}
LABEL = {m[0]: m[1] for m in METHODS}


def _active(event, n):
    return pd.Series(event).rolling(n, min_periods=1).max().fillna(0).values > 0


def _held(event, values, n):
    """Nilai `values` pada bar event, dipertahankan n bar."""
    return pd.Series(np.where(event, values, np.nan)).ffill(limit=n - 1).values


def _pull(x, d, extra=()):
    """Titik pullback: level nilai (EMA20/EMA50/...) terdekat di sisi pullback dalam 0.25..MAX_ENTRY_ATR ATR;
    bila tidak ada, 0.5 ATR dari harga. Batas atas hasil audit: limit yang terlalu jauh jarang terisi dan rentan adverse selection."""
    c, a = x.c, np.where(x.atr > 0, x.atr, np.nan)
    best = c - d * 0.5 * a
    bd = np.full(x.n, np.inf)
    lim = MAX_ENTRY_ATR[x.mode]
    for L in (x.ema20, x.ema50) + tuple(extra):
        dist = (c - L) * d / a
        ok = (dist >= 0.25) & (dist <= lim) & (dist < bd)
        best = np.where(ok, L, best)
        bd = np.where(ok, dist, bd)
    return best


def _sl(x, d, entry):
    return entry - d * SL_ATR[x.mode] * x.atr


def _q(*parts):
    return np.clip(np.nan_to_num(parts[0], nan=0.0), 0.0, 1.0)


def _align(x, d, q):
    """Bonus bila searah timeframe lebih tinggi."""
    return np.clip(np.where(x.htf == d, q * 1.15, q), 0, 1)


def _trend_gate(x, d):
    return np.where(x.htf == -d, 0, d)


def m_tsmom(x):
    L1, L2, L3 = x.cfg["tsmom"]
    c = pd.Series(x.c)
    sc = (np.sign(c - c.shift(L1)) + np.sign(c - c.shift(L2)) + np.sign(c - c.shift(L3))).values / 3
    d = np.where(sc >= 0.99, 1, np.where(sc <= -0.99, -1, 0))
    d = _trend_gate(x, d)
    z = (x.c - c.shift(L2).values) / (x.atr * np.sqrt(L2))
    q = _align(x, d, np.clip(np.abs(z) / 2.5, 0.25, 1))
    e = _pull(x, d)
    return d, e, _sl(x, d, e), q


def m_emapb(x):
    up = (x.ema20 > x.ema50) & (x.ema50 > x.ema200) & (x.c > x.ema200) & (x.adx > 18)
    dn = (x.ema20 < x.ema50) & (x.ema50 < x.ema200) & (x.c < x.ema200) & (x.adx > 18)
    d = np.where(up, 1, np.where(dn, -1, 0))
    d = _trend_gate(x, d)
    e = _pull(x, d)
    q = _align(x, d, np.clip(x.adx / 40, 0.3, 1))
    return d, e, _sl(x, d, e), q


def m_donch(x):
    bu, bd = x.c > x.dc_hi, x.c < x.dc_lo
    n = 6
    au, ad = _active(bu, n), _active(bd, n)
    lvl_u, lvl_d = _held(bu, x.dc_hi, n), _held(bd, x.dc_lo, n)
    d = np.where(au & ~ad, 1, np.where(ad & ~au, -1, 0))
    d = _trend_gate(x, d)
    lvl = np.where(d > 0, lvl_u, lvl_d)
    e = lvl + d * 0.1 * x.atr
    e = np.where(d * (x.c - e) < 0, x.c, e)   # tidak boleh limit-beli di atas harga
    sl = lvl - d * 1.0 * x.atr
    q = _align(x, d, np.clip(x.adx / 40, 0.3, 1))
    return d, e, sl, q


def m_macdadx(x):
    mh = pd.Series(x.macd_h)
    rising, falling = (mh > mh.shift(1)).values, (mh < mh.shift(1)).values
    adxs = pd.Series(x.adx)
    adx_up = (adxs > adxs.shift(2)).values
    up = (x.macd_h > 0) & rising & (x.pdi > x.mdi) & (x.adx > 20) & adx_up
    dn = (x.macd_h < 0) & falling & (x.mdi > x.pdi) & (x.adx > 20) & adx_up
    d = np.where(up, 1, np.where(dn, -1, 0))
    d = _trend_gate(x, d)
    e = _pull(x, d)
    q = _align(x, d, np.clip(x.adx / 40, 0.3, 1))
    return d, e, _sl(x, d, e), q


def m_squeeze(x):
    sq = _active(x.bw_rank <= 0.2, 12)
    bu = (x.c > x.bb_up) & sq
    bd = (x.c < x.bb_lo) & sq
    n = 4
    au, ad = _active(bu, n), _active(bd, n)
    d = np.where(au & ~ad, 1, np.where(ad & ~au, -1, 0))
    d = _trend_gate(x, d)
    e = _pull(x, d, extra=(x.bb_mid,))
    q = _align(x, d, np.clip(1 - np.nan_to_num(x.bw_rank, nan=0.5), 0.3, 1))
    return d, e, _sl(x, d, e), q


def m_rsi2(x):
    up = (x.rsi2 < 10) & (x.c > x.ema200)
    dn = (x.rsi2 > 90) & (x.c < x.ema200)
    d = np.where(up, 1, np.where(dn, -1, 0))
    e = x.c - d * 0.1 * x.atr
    q = np.clip(np.where(d > 0, (10 - x.rsi2) / 10, (x.rsi2 - 90) / 10), 0.3, 1)
    return d, e, _sl(x, d, e), np.where(d != 0, q, 0)


def m_bbz(x):
    rng = (x.adx < 22) & (x.er < 0.35)
    d = np.where(rng & (x.bb_z < -1.9), 1, np.where(rng & (x.bb_z > 1.9), -1, 0))
    e = x.c - d * 0.05 * x.atr
    q = np.clip((np.abs(x.bb_z) - 1.5) / 1.5, 0.3, 1)
    return d, e, _sl(x, d, e), np.where(d != 0, q, 0)


def m_struct(x):
    c, a = x.c, x.atr
    sh1p, sl1p = pd.Series(x.sh1).shift(1).values, pd.Series(x.sl1).shift(1).values
    cp = pd.Series(c).shift(1).values
    ev_up = (c > sh1p) & (cp <= sh1p)
    ev_dn = (c < sl1p) & (cp >= sl1p)
    st = pd.Series(np.where(ev_up, 1.0, np.where(ev_dn, -1.0, np.nan))).ffill().fillna(0).values
    d = np.where((st > 0) & (c > x.sl1), 1, np.where((st < 0) & (c < x.sh1), -1, 0))
    d = _trend_gate(x, d)
    hh = pd.Series(x.h).rolling(30).max().values
    ll = pd.Series(x.l).rolling(30).min().values
    eq_up = x.sl1 + 0.5 * (hh - x.sl1)
    eq_dn = x.sh1 - 0.5 * (x.sh1 - ll)
    e = np.where(d > 0, eq_up, eq_dn)
    e = np.where(d > 0, np.clip(e, x.sl1 + 0.3 * a, c - 0.2 * a), np.clip(e, c + 0.2 * a, x.sh1 - 0.3 * a))
    sl = np.where(d > 0, x.sl1 - 0.15 * a, x.sh1 + 0.15 * a)
    q = _align(x, d, np.clip(np.abs(c - np.where(d > 0, x.sl1, x.sh1)) / (3 * a), 0.3, 1))
    return d, e, sl, q


def m_sweep(x):
    lb = x.cfg["sweep_lb"]
    pool_lo = np.fmin(pd.Series(x.l).rolling(lb).min().shift(1).values, np.where(np.isnan(x.sl1), np.inf, x.sl1))
    pool_hi = np.fmax(pd.Series(x.h).rolling(lb).max().shift(1).values, np.where(np.isnan(x.sh1), -np.inf, x.sh1))
    rng = x.h - x.l
    ok = rng >= 0.8 * x.atr
    sw_lo = ok & (x.l < pool_lo) & (x.c > pool_lo) & ((x.c - x.l) >= 0.5 * rng)
    sw_hi = ok & (x.h > pool_hi) & (x.c < pool_hi) & ((x.h - x.c) >= 0.5 * rng)
    n = 3
    au, ad = _active(sw_lo, n), _active(sw_hi, n)
    d = np.where(au & ~ad, 1, np.where(ad & ~au, -1, 0))
    mid = (x.h + x.l) / 2
    e = np.where(d > 0, _held(sw_lo, mid, n), _held(sw_hi, mid, n))
    e = np.where(d * (x.c - e) < 0, x.c, e)
    sl = np.where(d > 0, _held(sw_lo, x.l, n) - 0.15 * x.atr, _held(sw_hi, x.h, n) + 0.15 * x.atr)
    q = _align(x, d, np.clip(rng / (2 * x.atr), 0.4, 1))
    return d, e, sl, np.where(d != 0, q, 0)


def m_value(x):
    c, a = x.c, x.atr
    cp = pd.Series(c).shift(1).values
    valp, vahp = pd.Series(x.val).shift(1).values, pd.Series(x.vah).shift(1).values
    re_up = (cp < valp) & (c > x.val)
    re_dn = (cp > vahp) & (c < x.vah)
    n = 3
    au, ad = _active(re_up, n), _active(re_dn, n)
    d1 = np.where(au & ~ad, 1, np.where(ad & ~au, -1, 0))
    d2 = np.where((x.htf > 0) & (c > x.poc) & (c < x.vah), 1, np.where((x.htf < 0) & (c < x.poc) & (c > x.val), -1, 0))
    d = np.where(d1 != 0, d1, d2)
    e1 = c - d * 0.2 * a
    e = np.where(d1 != 0, e1, x.poc)
    e = np.where(d * (c - e) < 0, c, e)
    l3 = pd.Series(x.l).rolling(3).min().values
    h3 = pd.Series(x.h).rolling(3).max().values
    sl = np.where(d1 != 0, np.where(d > 0, l3 - 0.2 * a, h3 + 0.2 * a), e - d * 1.2 * a)
    q = _align(x, d, np.where(d1 != 0, 0.8, 0.6))
    return d, e, sl, np.where(d != 0, q, 0)


FUNCS = dict(tsmom=m_tsmom, emapb=m_emapb, donch=m_donch, macdadx=m_macdadx, squeeze=m_squeeze, rsi2=m_rsi2, bbz=m_bbz, struct=m_struct, sweep=m_sweep, value=m_value)


def run_all(x):
    out = {}
    with np.errstate(all="ignore"):
        for k in NAMES:
            d, e, sl, q = FUNCS[k](x)
            bad = ~np.isfinite(e) | ~np.isfinite(sl) | ~np.isfinite(x.atr) | (x.atr <= 0)
            d = np.where(bad, 0, d).astype(np.int8)
            out[k] = dict(d=d, e=e, sl=sl, q=np.where(d != 0, q, 0.0))
    return out
