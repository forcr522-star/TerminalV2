"""Data untuk menu SIGNAL tampilan baru (chart live + list pair + order terbuka / limit / tertutup).

Dipakai oleh admin DAN user, jadi di sini TIDAK ADA isi analisa bot (suara 10 metode, alasan, fundamental, quant) — hanya yang boleh dilihat user:
daftar pair yang dianalisa, harga, chart, dan order (entry, SL, TP, arah, RR)."""
import time

import pandas as pd

from ..providers import yahoo
from ..universe import BY_SYM
from . import control, journal, runner, service
from .config import MODES

CHART_PERIOD = {"scalp": "7d", "intraday": "60d", "swing": "2y"}   # cukup untuk chart + order yang masih hidup
CHART_BARS = 220
CLOSED_SHOWN = 150
STATUS_TXT = {"TP1": "TP1 tercapai", "TP2": "TP2 tercapai", "TPMAX": "TP MAX tercapai", "SL": "Kena SL", "TIME": "Ditutup (waktu habis)",
              "EXPIRED": "Batal (tidak terisi)", "MISSED": "Batal (TP1 tersentuh)", "PENDING": "Menunggu entry", "OPEN": "Berjalan"}
CANCELLED = ("EXPIRED", "MISSED")


def _epoch(ts):
    return int(pd.Timestamp(ts).timestamp())


def _num(v, nd):
    return None if v is None else round(float(v), nd)


def order_out(row, live=None):
    """Satu order untuk tabel & chart. SL = 1R; TP = kelipatan R (rr)."""
    pl = row["plan"]
    mode = row["mode"]
    cfg = MODES.get(mode, MODES["intraday"])
    e, sl = float(pl["entry"]), float(pl["sl"])
    risk = abs(e - sl)
    nd = service.digits(e)
    d = int(pl["d"])
    rr = [round(abs(float(t) - e) / risk, 2) if risk > 0 else None for t in pl["tp"]]
    live = live or {}
    status = row["status"]
    issued = _epoch(row["bar_ts"]) + cfg["minutes"] * 60
    out = dict(id=row["id"], sym=row["sym"], name=(BY_SYM.get(row["sym"].upper()) or {}).get("name", row["sym"]), digits=nd, mode=mode, tf=cfg["tf"], side="LONG" if d > 0 else "SHORT",
               kind=("BUY LIMIT" if d > 0 else "SELL LIMIT") if status == "PENDING" else ("BUY" if d > 0 else "SELL"),
               entry=_num(e, nd), sl=_num(sl, nd), tp=[_num(t, nd) for t in pl["tp"]], rr=rr, risk=_num(risk, nd), weights=list(pl.get("w") or []),
               status=status, status_txt=STATUS_TXT.get(status, status), be=bool(row.get("be")), created=row["created"], closed=row["closed"], issued=issued,
               expiry_bars=pl.get("expiry"), max_hold=pl.get("max_hold"), tf_minutes=cfg["minutes"])
    if status in ("PENDING", "OPEN"):
        out.update(price=_num(live.get("price"), nd), hits=live.get("hits", 0), sl_now=_num(live.get("sl_now", sl), nd), r=_num(live.get("r_total"), 2) if live else None,
                   r_real=_num(live.get("r_real"), 2) if live else None, fill_ts=live.get("fill_ts"), live_at=live.get("asof"))
        if status == "PENDING" and live.get("price") is not None and risk > 0:
            out["dist_r"] = round(abs(live["price"] - e) / risk, 2)
    else:
        out.update(hits=row.get("tp_hits", 0), r=None if status in CANCELLED else round(float(row["r"]), 2))
    return out


async def chart(sym, mode, be):
    """Chart live satu pair: candle terbaru (bar yang sedang berjalan ikut), harga sekarang, dan order aktif pair itu pada gaya ini."""
    a = BY_SYM[sym.upper()]
    cfg = MODES[mode]
    df = await yahoo.live_ohlcv(a["y"], CHART_PERIOD[mode], cfg["yf_interval"])
    if df is None or len(df) == 0:
        raise ValueError(f"data harga {a['sym']} tidak tersedia dari sumber")
    price = float(df["c"].iloc[-1])
    nd = service.digits(price)
    tail = df.iloc[-CHART_BARS:]
    candles = [[_epoch(t), _num(o, nd), _num(h, nd), _num(l, nd), _num(c, nd)] for t, o, h, l, c in zip(tail.index, tail["o"].values, tail["h"].values, tail["l"].values, tail["c"].values)]
    prev = float(df["c"].iloc[-2]) if len(df) > 1 else price
    out = dict(symbol=a["sym"], name=a["name"], tf=cfg["tf"], minutes=cfg["minutes"], digits=nd, price=_num(price, nd), prev=_num(prev, nd), candles=candles, asof=_epoch(df.index[-1]), order=None)
    act = journal.active(a["sym"], mode)
    live = None
    if act:
        label, _res, live = service.live_state(act, df, be)
        if label in ("PENDING", "OPEN"):
            row = dict(act, status=label)
            out["order"] = order_out(row, live)
        else:
            live = None
    return out, live


async def build(symbol=""):
    ctl = control.get()
    mode, be = ctl["mode"], ctl["be"]
    cfg = MODES[mode]
    assets = [BY_SYM[s.upper()] for s in ctl["pairs"] if s.upper() in BY_SYM]
    syms = [a["sym"] for a in assets]
    want = BY_SYM.get(str(symbol).strip().upper(), {}).get("sym")
    sel = want if want in syms else (syms[0] if syms else None)
    quotes = {}
    if assets:
        try:
            quotes = await yahoo.quotes(tuple(a["y"] for a in assets))
        except Exception:
            quotes = {}
    ch, ch_live, err = None, None, None
    if sel:
        try:
            ch, ch_live = await chart(sel, mode, be)
        except Exception as exc:
            err = f"{type(exc).__name__}: {str(exc)[:160]}"
    rows = journal.recent(2000)
    opens, limits, closed = [], [], []
    marks = {}
    for r in rows:
        st = r["status"]
        if st in ("PENDING", "OPEN"):
            live = runner.LIVE.get(r["id"])
            if ch_live is not None and r["sym"] == sel and r["mode"] == mode and ch and ch.get("order") and ch["order"]["id"] == r["id"]:
                live = ch_live
            o = order_out(r, live)
            if o["price"] is None:
                q = quotes.get((BY_SYM.get(r["sym"].upper()) or {}).get("y"))
                if q and q.get("price") is not None:
                    o["price"] = _num(q["price"], o["digits"])
            (limits if st == "PENDING" else opens).append(o)
            m = marks.setdefault(r["sym"], dict(open=0, limit=0, side=o["side"]))
            m["limit" if st == "PENDING" else "open"] += 1
        elif len(closed) < CLOSED_SHOWN:
            closed.append(order_out(r))
    done = [r for r in rows if r["status"] in ("TP1", "TP2", "TPMAX", "SL", "TIME")]
    # Metrik jujur: "menang" = R bersih POSITIF, bukan sekadar TP1 tersentuh (TP1 lalu sisa kena SL bisa negatif).
    wins = [r for r in done if float(r["r"]) > 0]
    sum_r = sum(float(r["r"]) for r in done)
    cancelled = sum(1 for r in rows if r["status"] in CANCELLED)
    stats = dict(n=len(done), win=(len(wins) / len(done)) if done else None, sum_r=round(sum_r, 2), avg_r=round(sum_r / len(done), 2) if done else None,
                 float_r=round(sum((o["r"] or 0.0) for o in opens), 2), cancelled=cancelled,
                 fill_rate=round(len(done) / (len(done) + cancelled), 3) if (len(done) + cancelled) else None)
    pairs = []
    for a in assets:
        q = quotes.get(a["y"]) or {}
        price = q.get("price")
        if ch and a["sym"] == sel:
            price = ch["price"]
        m = marks.get(a["sym"])
        pairs.append(dict(sym=a["sym"], name=a["name"], cls=a["cls"], price=price, pct=q.get("pct"), digits=service.digits(price) if price else 5, open=m["open"] if m else 0,
                          limit=m["limit"] if m else 0, side=m["side"] if m else None))
    return dict(now=int(time.time()), mode=mode, mode_label=cfg["label"], tf=cfg["tf"], symbol=sel, pairs=pairs, chart=ch, chart_error=err,
                orders=dict(open=opens, limit=limits, closed=closed, stats=stats))
