"""Struktur pasar & Liquidity: pivot, pool likuiditas (swing / equal highs-lows / PDH-PDL), sweep, Fair Value Gap."""
import numpy as np


def pivot_arrays(df, n=3):
    """Pivot fraktal dengan indeks konfirmasi (idx + n). Array terurut menurut indeks konfirmasi."""
    h, l = df["h"].values, df["l"].values
    N = len(h)
    ph, pl = [], []
    for j in range(n, N - n):
        seg_h, seg_l = h[j - n: j + n + 1], l[j - n: j + n + 1]
        if np.argmax(seg_h) == n:
            ph.append((j + n, j, float(h[j])))
        if np.argmin(seg_l) == n:
            pl.append((j + n, j, float(l[j])))
    return dict(h=np.array(ph, float).reshape(-1, 3), l=np.array(pl, float).reshape(-1, 3))


def pools_at(piv, i, lookback, tol, pdh=None, pdl=None):
    """Pool likuiditas yang terlihat pada bar i. Mengembalikan daftar dict(price, kind, n, src) terurut dari harga terendah."""
    out = []
    for kind, key in (("high", "h"), ("low", "l")):
        a = piv[key]
        if len(a) == 0:
            continue
        m = (a[:, 0] <= i) & (a[:, 1] >= i - lookback)
        vals = np.sort(a[m, 2])
        cl = []
        for p in vals:
            if cl and abs(p - cl[-1][-1]) <= tol:
                cl[-1].append(p)
            else:
                cl.append([p])
        for c in cl:
            out.append(dict(price=float(np.mean(c)), kind=kind, n=len(c), src="equal" if len(c) > 1 else "swing"))
    if pdh is not None and np.isfinite(pdh):
        out.append(dict(price=float(pdh), kind="high", n=2, src="PDH"))
    if pdl is not None and np.isfinite(pdl):
        out.append(dict(price=float(pdl), kind="low", n=2, src="PDL"))
    out.sort(key=lambda x: x["price"])
    return out


def fvg_zones(h, l, i, lookback=80):
    """Fair Value Gap yang belum termitigasi pada bar i. Mengembalikan list dict(lo, hi, dir)."""
    out = []
    start = max(2, i - lookback)
    for k in range(start, i + 1):
        if l[k] > h[k - 2]:   # bullish gap antara high[k-2] dan low[k]
            lo, hi = h[k - 2], l[k]
            if k + 1 > i or l[k + 1:i + 1].min() > lo:
                out.append(dict(lo=float(lo), hi=float(hi), dir=1, k=k))
        if h[k] < l[k - 2]:   # bearish gap
            lo, hi = h[k], l[k - 2]
            if k + 1 > i or h[k + 1:i + 1].max() < hi:
                out.append(dict(lo=float(lo), hi=float(hi), dir=-1, k=k))
    return out
