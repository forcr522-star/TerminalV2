"""Volume Profile (POC / Value Area / HVN / LVN). Bila volume tidak tersedia (mis. FX di Yahoo), dipakai profil waktu-harga (TPO): tiap bar berbobot sama."""
import numpy as np


def volume_profile(h, l, v=None, bins=48, va=0.70):
    h, l = np.asarray(h, float), np.asarray(l, float)
    if len(h) < 5:
        return None
    lo, hi = float(np.nanmin(l)), float(np.nanmax(h))
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        return None
    vol = np.ones(len(h)) if v is None else np.nan_to_num(np.asarray(v, float), nan=0.0, posinf=0.0, neginf=0.0)
    src = "volume"
    if vol.sum() <= 0:
        vol, src = np.ones(len(h)), "tpo"
    edges = np.linspace(lo, hi, bins + 1)
    ov = np.clip(np.minimum(h[:, None], edges[None, 1:]) - np.maximum(l[:, None], edges[None, :-1]), 0, None)
    rng = h - l
    flat = rng <= 1e-12
    w = np.zeros_like(ov)
    ok = ~flat
    w[ok] = ov[ok] / rng[ok, None]
    if flat.any():
        b = np.clip(np.searchsorted(edges, l[flat], side="right") - 1, 0, bins - 1)
        w[np.where(flat)[0], b] = 1.0
    hist = (w * vol[:, None]).sum(axis=0)
    tot = hist.sum()
    if tot <= 0:
        return None
    k = np.array([1, 2, 3, 2, 1], float)
    sm = np.convolve(hist, k / k.sum(), mode="same")
    ctr = (edges[:-1] + edges[1:]) / 2
    ip = int(np.argmax(sm))
    lo_i = hi_i = ip
    acc = hist[ip]
    while acc < va * tot and (lo_i > 0 or hi_i < bins - 1):
        up = hist[hi_i + 1] if hi_i < bins - 1 else -1
        dn = hist[lo_i - 1] if lo_i > 0 else -1
        if up >= dn:
            hi_i += 1
            acc += hist[hi_i]
        else:
            lo_i -= 1
            acc += hist[lo_i]
    mean = sm.mean()
    hvn, lvn = [], []
    for i in range(1, bins - 1):
        if sm[i] >= sm[i - 1] and sm[i] > sm[i + 1] and sm[i] >= 1.15 * mean:
            hvn.append(float(ctr[i]))
        if sm[i] <= sm[i - 1] and sm[i] < sm[i + 1] and sm[i] <= 0.6 * mean:
            lvn.append(float(ctr[i]))
    return dict(poc=float(ctr[ip]), vah=float(edges[hi_i + 1]), val=float(edges[lo_i]), hvn=hvn, lvn=lvn, lo=lo, hi=hi, src=src,
                hist=[float(x) for x in sm], edges=[float(x) for x in edges])


def rolling_profiles(df, window, step, bins=48):
    """Profil bergulir yang dihitung tiap `step` bar dari `window` bar terakhir (hanya data s.d. bar tsb: tanpa look-ahead).

    Mengembalikan (daftar profil, array indeks profil per bar; -1 bila belum ada)."""
    n = len(df)
    h, l = df["h"].values, df["l"].values
    v = df["v"].values if "v" in df else None
    profs, pidx = [], np.full(n, -1, dtype=int)
    cur = -1
    for i in range(window - 1, n):
        if (i - (window - 1)) % step == 0:
            p = volume_profile(h[i - window + 1: i + 1], l[i - window + 1: i + 1], None if v is None else v[i - window + 1: i + 1], bins)
            if p:
                p["i0"] = i
                profs.append(p)
                cur = len(profs) - 1
        pidx[i] = cur
    return profs, pidx
