"""Engine sinyal: 10 metode -> KELUARGA faktor orthogonal -> konfirmasi kuantitatif -> rencana akhir.

Perbaikan hasil audit (lihat _audit/strategy-audit.md):
  1. Konsensus per KELUARGA (TREND/BREAKOUT/REVERSION/STRUCTURE/LIQUIDITY/PROFILE), satu suara per keluarga,
     sehingga 3 indikator tren tidak dihitung sebagai 3 konfirmasi independen.
  2. Statistik Book: pool prior MENGELUARKAN metode yang sedang dinilai, memakai TP1 R aktual (bukan 0,8R tetap),
     prior lebih kuat, gate memakai lower-confidence-bound rata-rata R (bukan EV model in-sample).
  3. Fundamental tidak lagi memveto arah; hanya overlay kecil pada ukuran posisi (event block tetap boleh).
  4. Playbook per rezim: keluarga yang tidak cocok abstain, bukan pengali kosmetik.
  5. TP1 minimal TP_MIN_R, SL dibatasi, refine grid tidak dipakai secara default.
"""
import numpy as np

from . import plan as P, quant as Q, tracker
from .config import (PARAMS, MODE_PARAMS, TP_WEIGHTS, TP_R, TP_MIN_R, COST_FRAC, LCB_Z,
                     FAMILY, FAMILIES, REGIME_W, RISK)
from .methods import NAMES, LABEL, KIND


class Book:
    """Daftar sinyal historis tiap metode (rencana tervalidasi + hasil simulasi) untuk statistik kuantitatif."""

    def __init__(self, x, be=True, cost_frac=0.0001, swap_frac=0.0):
        self.x, self.be, self.cost_frac, self.swap_frac = x, be, cost_frac, swap_frac
        self.ev = {}
        self.built_to = -1

    def build(self, start=250, end=None):
        x = self.x
        cfg = x.cfg
        end = x.n - 1 if end is None else end
        for name in NAMES:
            o = x.out[name]
            rows, last = [], -10 ** 9
            for i in range(start, end):
                d = o["d"][i]
                if d == 0 or i - last < cfg["expiry"]:
                    continue
                pl = P.build_plan(x, i, int(d), o["e"][i], o["sl"][i], o["q"][i])
                if pl is None:
                    continue
                last = i
                pl.update(w=TP_WEIGHTS, expiry=cfg["expiry"], max_hold=cfg["max_hold"],
                          cost=self.cost_frac * x.c[i], swap=self.swap_frac * x.c[i])
                r = tracker.simulate(pl, x.o, x.h, x.l, x.c, i, self.be)
                if r["status"] == "CLOSED":
                    settle = r["exit"]
                    rows.append((i, settle, 1.0 if r["tp_hits"] >= 1 else 0.0, r["r"], 1, r["tp_hits"]))
                elif r["status"] in ("NOFILL", "MISSED"):
                    rows.append((i, i + cfg["expiry"], 0.0, 0.0, 0, 0))
            a = np.array(rows, float).reshape(-1, 6)
            self.ev[name] = dict(i=a[:, 0], settle=a[:, 1], tp1=a[:, 2], r=a[:, 3], filled=a[:, 4], hits=a[:, 5])
        self.built_to = end
        return self

    def stats(self, name, i, k):
        e = self.ev[name]
        m = (e["settle"] < i) & (e["filled"] > 0)
        idx = np.where(m)[0][-k:]
        n = len(idx)
        if n == 0:
            return dict(n=0, tp1=0.0, tp2=0.0, tp3=0.0, wins=0.0, avg_r=0.0, sd=0.0, sum_r=0.0)
        rr = e["r"][idx]
        hh = e["hits"][idx]
        return dict(n=n, tp1=float((hh >= 1).sum()), tp2=float((hh >= 2).sum()), tp3=float((hh >= 3).sum()),
                    wins=float((rr > 0).sum()), avg_r=float(rr.mean()), sd=float(rr.std(ddof=1)) if n > 1 else 0.0,
                    sum_r=float(rr.sum()))

    def pooled_p(self, i, k, exclude=None):
        """Peluang TP1 gabungan metode LAIN (metode yang sedang dinilai tidak ikut, menghindari self-reference)."""
        w = n = 0.0
        for name in NAMES:
            if name == exclude:
                continue
            s = self.stats(name, i, k)
            w += s["tp1"]
            n += s["n"]
        return (w / n) if n >= 30 else None


def _wmedian(vals, ws):
    o = np.argsort(vals)
    v, w = np.asarray(vals)[o], np.asarray(ws)[o]
    cs = np.cumsum(w)
    return float(v[np.searchsorted(cs, cs[-1] / 2)])


def _family_of(name):
    return FAMILY.get(name, "OTHER")


def why_idle(rows, htf_label="TF besar"):
    """Ringkasan kenapa metode yang PUNYA setup tidak ikut vote (untuk alasan WAIT yang bisa ditindaklanjuti)."""
    with_setup = [r for r in rows if r.get("bias")]
    if not with_setup:
        return "tidak ada metode yang memberi setup di bar ini"
    cnt = {}
    for r in with_setup:
        if r["status"] == "ok":
            continue
        w = r.get("why") or r["status"]
        k = ("hasil historisnya negatif di pair & mode ini (LCB R <= -0,05)" if r["status"] == "gated" else
             f"tidak searah bias {htf_label}" if "bias timeframe" in w else
             "entry tidak di level bernilai" if "level bernilai" in w else
             "rezim pasar tidak cocok" if "rezim" in w else
             "rencana RR/level tidak valid" if "plan tidak valid" in w else w)
        cnt[k] = cnt.get(k, 0) + 1
    parts = [f"{n} {k}" for k, n in sorted(cnt.items(), key=lambda z: -z[1])]
    ok = sum(1 for r in with_setup if r["status"] == "ok")
    return f"{len(with_setup)} metode punya setup, {ok} lolos" + (": " + ", ".join(parts) if parts else "")


def analyze_at(x, i, book, fund=None, be=True, params=None, cost_frac=0.0001):
    """Analisa lengkap pada bar i. Mengembalikan dict. Tidak melihat bar > i."""
    pr = {**PARAMS, **MODE_PARAMS.get(x.mode, {}), **(params or {})}
    a, c = float(x.atr[i]), float(x.c[i])
    nodes = P.nodes_at(x, i)
    regime = Q.regime(x, i)
    rw_all = REGIME_W.get(regime["label"], REGIME_W["CAMPURAN"])
    fscore = (fund or {}).get("score", 0.0) * (fund or {}).get("conf", 1.0) if fund else 0.0
    rows = []
    for name in NAMES:
        o = x.out[name]
        d = int(o["d"][i])
        fam = _family_of(name)
        row = dict(key=name, label=LABEL[name], kind=KIND[name], family=fam, bias=d, vote=0, status="no-setup", q=0.0,
                   regime_w=float(rw_all.get(fam, 0.8)))
        if d != 0:
            pl = P.build_plan(x, i, d, o["e"][i], o["sl"][i], o["q"][i], nodes)
            if pl is None:
                row["status"] = "abstain"
                row["why"] = "plan tidak valid (RR/level)"
            else:
                st = book.stats(name, i, pr["hist_k"])
                r1 = abs(pl["tp"][0] - pl["entry"]) / pl["risk"]
                pooled = book.pooled_p(i, pr["hist_k"] * 3, exclude=name)
                p_post = Q.posterior(st["tp1"], st["n"], r1, pooled, pr["strength"])
                th = Q.implied_theta(p_post, r1)
                rs = tuple(abs(t - pl["entry"]) / pl["risk"] for t in pl["tp"])
                outs = Q.outcomes(rs, th, be, cost_frac * c / pl["risk"])
                ev_model, _ = Q.moments(outs)
                ev = (st["n"] * st["avg_r"] + pr["strength"] * ev_model) / (st["n"] + pr["strength"]) if st["n"] else ev_model
                lcb_r = Q.lcb(st["avg_r"], st["sd"], st["n"], LCB_Z)
                fa = d * fscore                      # arah fundamental searah/metang metode
                fm = 1 + pr["fund_w"] * fa           # overlay UKURAN saja, bukan veto arah
                rw = float(rw_all.get(fam, 0.8))
                row.update(plan=pl, p_post=p_post, ev=ev, ev_model=ev_model, lcb_r=lcb_r, n_hist=st["n"], wins_hist=st["tp1"],
                           avg_r_hist=st["avg_r"], fund_align=fa, regime_w=rw)
                allow_rev = fam in ("REVERSION", "PROFILE") and regime["label"] == "MEAN-REVERTING"
                if pr.get("family_vote") and rw <= 0:
                    row.update(status="abstain", why=f"rezim {regime['label']} tidak mendukung keluarga {fam}")
                elif pr.get("need_valid") and pl["status"] != "valid":
                    row.update(status="abstain", why="entry tidak berada di level bernilai (validasi lemah)")
                elif pr.get("need_htf") and d != int(x.htf[i]) and not allow_rev:
                    row.update(status="abstain", why="tidak searah bias timeframe lebih tinggi")
                elif st["n"] >= pr["min_hist"] and lcb_r <= pr["gate_ev"]:
                    row.update(status="gated", why="lower-bound R historis metode ini <= 0 pada pair ini")
                else:
                    row.update(status="ok", vote=d, q=pl["q"] * fm * rw, w=pl["q"] * fm * rw)
        rows.append(row)
    prior = pr.get("prior") or {}
    for r in rows:
        if r["vote"]:
            r["w"] *= prior.get(r["key"], 1.0)

    bull_methods = [r for r in rows if r["vote"] > 0]
    bear_methods = [r for r in rows if r["vote"] < 0]
    fam_rows = []
    for f in FAMILIES:
        members = [r for r in rows if r["vote"] and r["family"] == f]
        if not members:
            continue
        s = sum(r["w"] * r["vote"] for r in members)
        fam_rows.append(dict(family=f, vote=(1 if s > 0 else -1 if s < 0 else 0), strength=abs(s),
                             n=len(members), keys=[r["key"] for r in members]))
    res = dict(rows=rows, bull=0, bear=0, method_bull=len(bull_methods), method_bear=len(bear_methods),
               families=fam_rows, regime=regime, nodes=nodes, signal="WAIT", reason=None, price=c, atr=a,
               pooled_p=book.pooled_p(i, pr["hist_k"] * 3))

    if pr.get("family_vote"):
        bull = [f for f in fam_rows if f["vote"] > 0]
        bear = [f for f in fam_rows if f["vote"] < 0]
        res["bull"], res["bear"] = len(bull), len(bear)
        net = sum(f["strength"] * f["vote"] for f in fam_rows)
        side = 1 if net > 0 else (-1 if net < 0 else 0)
        agree_f = bull if side > 0 else bear
        opp = bear if side > 0 else bull
        n_agree = len(agree_f)
        margin = n_agree - len(opp)
        if side == 0 or n_agree < pr["min_agree"]:
            res["reason"] = (f"keluarga faktor belum cukup ({len(bull)} bullish vs {len(bear)} bearish; minimal {pr['min_agree']} keluarga searah)"
                             f" — {why_idle(rows, x.cfg.get('htf_label', 'TF besar'))}")
            return res
        if margin < pr["min_margin"]:
            res["reason"] = f"keluarga faktor terlalu tipis ({len(bull)} vs {len(bear)}; margin minimal {pr['min_margin']})"
            return res
        agree_keys = {k for f in agree_f for k in f["keys"]}
        agree = [r for r in rows if r["key"] in agree_keys]
        for r in agree:
            r["plan_weight"] = r["w"] / max(1, len([m for m in agree if m["family"] == r["family"]]))
    else:
        res["bull"], res["bear"] = len(bull_methods), len(bear_methods)
        sw = sum(r["w"] for r in bull_methods) - sum(r["w"] for r in bear_methods)
        side = 1 if sw > 0 else (-1 if sw < 0 else 0)
        agree = bull_methods if side > 0 else bear_methods
        opp = bear_methods if side > 0 else bull_methods
        n_agree = len(agree)
        if side == 0 or n_agree < pr["min_agree"]:
            res["reason"] = f"suara belum cukup ({len(bull_methods)} bullish vs {len(bear_methods)} bearish; minimal {pr['min_agree']} searah)"
            return res
        if n_agree - len(opp) < pr["min_margin"]:
            res["reason"] = f"suara terlalu tipis ({len(bull_methods)} vs {len(bear_methods)})"
            return res
        for r in agree:
            r["plan_weight"] = r["w"]

    if fund and fund.get("block"):                 # event eksekusi (NFP/FOMC dsb) tetap boleh memblokir entry
        res["reason"] = fund["block"]
        return res

    # --- rencana akhir: rata-rata berbobot metode searah yang entry-nya berkelompok
    ws = np.array([r.get("plan_weight", r["w"]) for r in agree], float)
    ent = [r["plan"]["entry"] for r in agree]
    med = _wmedian(ent, ws)
    cl = [r for r in agree if abs(r["plan"]["entry"] - med) <= 0.8 * a]
    if len(cl) < max(2, min(2, n_agree)):
        res["reason"] = "entry antar metode tersebar (tidak ada kesepakatan titik pullback)"
        return res
    w = np.array([r.get("plan_weight", r["w"]) for r in cl], float)
    w = w / w.sum()
    entry = float(sum(wi * r["plan"]["entry"] for wi, r in zip(w, cl)))
    risk = float(sum(wi * abs(r["plan"]["entry"] - r["plan"]["sl"]) for wi, r in zip(w, cl)))
    risk = min(max(risk, 0.5 * a), 2.4 * a)
    dists = [float(sum(wi * abs(r["plan"]["tp"][k] - r["plan"]["entry"]) for wi, r in zip(w, cl))) for k in range(3)]
    floor_r = TP_MIN_R[x.mode][0]
    dists[0] = max(dists[0], floor_r * risk)
    for k in (1, 2):
        dists[k] = max(dists[k], dists[k - 1] + 0.4 * risk)
    tps = [entry + side * dk for dk in dists]
    sl = entry - side * risk
    p_fin = float(sum(wi * r["p_post"] for wi, r in zip(w, cl)))
    ev_fin = float(sum(wi * r["ev"] for wi, r in zip(w, cl)))
    cost = cost_frac * c
    rs = tuple(dk / risk for dk in dists)
    th = Q.implied_theta(p_fin, rs[0])
    outs = Q.outcomes(rs, th, be, cost / risk)
    ev_model, _ = Q.moments(outs)
    p1 = Q.p_up_first(rs[0], 1.0, th)
    best = dict(entry=entry, sl=sl, tp=tps, ev=ev_model, p1=p1, scale_sl=1.0, m1=rs[0], rs=rs, outs=outs, risk=risk, th=th)
    if pr.get("refine") not in (None, "none"):
        best = Q.refine(entry, sl, tps, side, p_fin, cost, be, a, pmin=pr["min_p"], grid=pr["refine"])
    res.update(agree=[r["key"] for r in cl], p_tp1=best["p1"], ev=ev_fin, ev_model=best["ev"], refine=dict(scale_sl=best["scale_sl"], m1=best["m1"]),
               theta=best["th"], outs=best["outs"], n_agree=n_agree)
    if best["p1"] < pr["min_p"] or ev_fin < pr["min_ev"]:
        res["reason"] = f"quant menolak: peluang TP1 {best['p1']*100:.0f}% / EV {ev_fin:+.2f}R di bawah ambang"
        return res
    rk = abs(best["entry"] - best["sl"])
    if not (0.45 * a <= rk <= 2.6 * a):
        res["reason"] = "jarak SL di luar batas wajar volatilitas"
        return res
    if regime["atr_pct"] < 0.08:
        res["reason"] = "volatilitas terlalu rendah (pasar mati)"
        return res
    if regime["atr_pct"] > 0.98:
        res["reason"] = "volatilitas ekstrem (spike); tunggu normalisasi"
        return res
    res.update(signal="BUY" if side > 0 else "SELL", plan=dict(d=side, entry=best["entry"], sl=best["sl"], tp=best["tp"], w=TP_WEIGHTS,
                                                                 rs=best["rs"], risk=rk, expiry=x.cfg["expiry"], max_hold=x.cfg["max_hold"],
                                                                 cost=cost, swap=0.0),
               kelly=Q.kelly_risk(best["outs"], cap=RISK["max_risk_per_trade"], floor=0.0))
    return res