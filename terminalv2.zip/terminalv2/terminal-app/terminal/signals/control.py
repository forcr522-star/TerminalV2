"""Kontrol bot sinyal (hanya admin yang boleh mengubah). Disimpan di database (tabel kv) sehingga bertahan setelah restart.

  on    : True  -> bot menganalisa semua pair terpilih 24 jam dan boleh menerbitkan sinyal baru.
          False -> bot TIDAK menganalisa pair mana pun dan tidak menerbitkan sinyal baru
                   (order yang sudah berjalan tetap dipantau SL/TP-nya supaya daftar order akurat).
  be    : True  -> Breakeven ON: setelah TP1 tercapai, SL dipindah ke harga entry. False -> SL & TP tetap.
  mode  : scalp | intraday | swing  (menentukan timeframe chart & analisa: M5 / H1 / D1).
  pairs : daftar pair yang dianalisa bot (dipilih developer; ini juga daftar yang dilihat user).
  strategy : multi (bawaan: konsensus 10 metode analisa) | one (strategi "ZONA + STRUKTUR + HARMONIC" dari dokumen aturan,
             signals/one). Keduanya menganalisa SEMUA pair terpilih; filter berita/volume/quant/risiko tetap jalan.
"""
import copy
import threading

from .. import store
from ..universe import BY_SYM
from .config import MODES, MODE_ORDER

KEY = "sig_control"
STRATEGIES = {"multi": "10 METODE", "one": "STRATEGI ONE"}
DEFAULT_PAIRS = ["EURUSD", "GBPUSD", "USDJPY", "Gold", "Bitcoin", "US500"]
MAX_PAIRS = 300

_lock = threading.RLock()
_state = None


def _defaults():
    return dict(on=True, be=True, mode="intraday", pairs=list(DEFAULT_PAIRS), rev=0, strategy="multi")


def canon_pairs(pairs):
    """Daftar simbol -> simbol kanonik (urutan dipertahankan, tanpa duplikat). ValueError bila ada simbol yang tidak dikenal."""
    if not isinstance(pairs, (list, tuple)):
        raise ValueError("pairs harus berupa daftar simbol")
    out, bad = [], []
    for p in pairs:
        a = BY_SYM.get(str(p).strip().upper())
        if not a:
            bad.append(str(p))
        elif a["sym"] not in out:
            out.append(a["sym"])
    if bad:
        raise ValueError("pair tidak dikenal: " + ", ".join(bad[:8]))
    if len(out) > MAX_PAIRS:
        raise ValueError(f"maksimal {MAX_PAIRS} pair")
    return out


def _clean(raw):
    """Validasi data tersimpan; bagian yang rusak diganti nilai bawaan."""
    st = _defaults()
    if isinstance(raw, dict):
        if isinstance(raw.get("on"), bool):
            st["on"] = raw["on"]
        if isinstance(raw.get("be"), bool):
            st["be"] = raw["be"]
        if raw.get("mode") in MODES:
            st["mode"] = raw["mode"]
        if isinstance(raw.get("pairs"), list):
            try:
                st["pairs"] = canon_pairs(raw["pairs"])
            except ValueError:
                st["pairs"] = [p for p in (BY_SYM.get(str(x).upper(), {}).get("sym") for x in raw["pairs"]) if p]
        if isinstance(raw.get("rev"), int):
            st["rev"] = raw["rev"]
        if raw.get("strategy") in STRATEGIES:
            st["strategy"] = raw["strategy"]
    return st


def reload():
    """Baca ulang dari database (dipakai saat start dan pengujian)."""
    global _state
    with _lock:
        try:
            raw = store.kv_get(KEY)
        except Exception:
            raw = None
        _state = _clean(raw)
        return copy.deepcopy(_state)


def get():
    with _lock:
        if _state is None:
            reload()
        return copy.deepcopy(_state)


def is_on():
    return bool(get()["on"])


def update(on=None, be=None, mode=None, pairs=None, strategy=None):
    """Ubah kontrol. Semua nilai divalidasi dulu; bila ada yang salah, tidak ada yang berubah (ValueError). Mengembalikan status baru."""
    global _state
    with _lock:
        cur = get()
        new = dict(cur)
        if on is not None:
            if not isinstance(on, bool):
                raise ValueError("'on' harus true/false")
            new["on"] = on
        if be is not None:
            if not isinstance(be, bool):
                raise ValueError("'be' harus true/false")
            new["be"] = be
        if mode is not None:
            if mode not in MODES:
                raise ValueError("mode harus salah satu dari: " + ", ".join(MODE_ORDER))
            new["mode"] = mode
        if pairs is not None:
            new["pairs"] = canon_pairs(pairs)
        if strategy is not None:
            if strategy not in STRATEGIES:
                raise ValueError("strategy harus salah satu dari: " + ", ".join(STRATEGIES))
            new["strategy"] = strategy
        if new != cur:
            new["rev"] = cur["rev"] + 1
            _state = new
            store.kv_set(KEY, new)
        return copy.deepcopy(new)
