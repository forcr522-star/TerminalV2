"""Menu SIGNAL: analisa gabungan (Teknikal -> Volume Profile & Liquidity -> Fundamental -> Quantitative) dengan 10 metode dan suara mayoritas.

Modul murni (tanpa jaringan): ta, structure, profile, methods, quant, engine, tracker, backtest.
Modul async (memakai data bot): fundamental, service.
"""
