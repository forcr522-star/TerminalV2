"""Langkah 3: konfirmasi FUNDAMENTAL memakai data yang sudah ada di bot (suku bunga & yield, regime makro, COT, sentimen retail, katalis berita, GPR, kalender).

Skor akhir -1..+1 (positif = bullish untuk aset). Bobot tiap driver mengikuti gaya trading (scalping lebih ke berita/kalender, swing lebih ke makro).
`score_drivers` adalah fungsi murni (mudah diuji); `gather` mengambil data dengan batas waktu dan tidak pernah melempar error."""
import asyncio
import datetime as dt
import math

from ..universe import BY_SYM, CURRENCY_TO_CC, COUNTRIES

SAFE_HAVEN = {"JPY", "CHF"}
RISK_CCY = {"AUD", "NZD", "CAD"}
METALS = {"GOLD", "SILVER", "PLATINUM", "PALLADIUM"}
ENERGY = {"CRUDE OIL WTI", "BRENT OIL", "NATURAL GAS", "GASOLINE", "HEATING OIL"}
INDEX_CC = {"US500": "US", "US100": "US", "US30": "US", "US2000": "US", "IXIC": "US", "DAX30": "EU", "CAC40": "EU", "EU50": "EU", "AEX": "EU", "IBEX35": "EU", "FTSE100": "GB",
            "NIKKEI225": "JP", "CH20": "CH", "ASX200": "AU", "NZ50": "NZ", "TSX": "CA", "IDX COMPOSITE": "ID", "IDX LQ45": "ID", "HK50": "CN", "CSI1000": "CN", "SSEC": "CN", "CSI300": "CN"}
COT_BY_CC = {"US": "US Dollar Index", "EU": "Euro FX", "JP": "Japanese Yen", "GB": "British Pound", "CA": "Canadian Dollar", "AU": "Australian Dollar", "NZ": "New Zealand Dollar", "CH": "Swiss Franc"}
COT_OTHER = {"GOLD": ("disagg", "Gold", "mm_net"), "SILVER": ("disagg", "Silver", "mm_net"), "CRUDE OIL WTI": ("disagg", "Crude Oil (WTI)", "mm_net"), "BRENT OIL": ("disagg", "Crude Oil (WTI)", "mm_net"),
             "COPPER": ("disagg", "Copper", "mm_net"), "US500": ("tff", "S&P 500", "lev_net"), "US100": ("tff", "Nasdaq 100", "lev_net"), "US30": ("tff", "Dow Jones", "lev_net"),
             "BITCOIN": ("tff", "Bitcoin", "lev_net"), "ETHEREUM": ("tff", "Ether", "lev_net"),
             "NATURAL GAS": ("disagg", "Natural Gas", "mm_net"), "PLATINUM": ("disagg", "Platinum", "mm_net"), "PALLADIUM": ("disagg", "Palladium", "mm_net")}
RETAIL = {"GOLD": "XAUUSD", "SILVER": "XAGUSD", "CRUDE OIL WTI": "USOIL", "BITCOIN": "BTCUSD", "ETHEREUM": "ETHUSD"}

# bobot driver per gaya
WEIGHTS = {
    "scalp": dict(news=0.35, retail=0.25, gpr=0.10, cot=0.05, rate=0.05, regime=0.05, yld=0.05, pm=0.10),
    "intraday": dict(news=0.25, retail=0.15, gpr=0.10, cot=0.15, rate=0.15, regime=0.15, yld=0.05, pm=0.10),
    "swing": dict(news=0.10, retail=0.05, gpr=0.10, cot=0.20, rate=0.25, regime=0.20, yld=0.10, pm=0.10),
}
BLOCK_MIN = {"scalp": (30, 15), "intraday": (120, 30), "swing": (240, 60)}   # (menit sebelum, menit sesudah)


def entity(sym):
    """Petakan simbol ke entitas fundamental: dict(kind, base, quote, ccs, name)."""
    a = BY_SYM.get(sym.upper())
    if not a:
        return dict(kind="OTHER", ccs=[], name=sym)
    cls, name = a["cls"], a["sym"]
    up = name.upper()
    if cls == "FX":
        if name == "USD Index":
            return dict(kind="DXY", base="USD", quote=None, ccs=["US"], name=name)
        b, q = name[:3], name[3:]
        ccs = [c for c in (CURRENCY_TO_CC.get(b), CURRENCY_TO_CC.get(q)) if c]
        return dict(kind="FX", base=b, quote=q, ccs=ccs, name=name)
    if cls == "COMMODITY":
        k = "METAL" if up in METALS else ("ENERGY" if up in ENERGY else "COMMODITY")
        return dict(kind=k, ccs=["US"], name=name)
    if cls == "INDEX":
        cc = INDEX_CC.get(up)
        return dict(kind="INDEX", ccs=[cc] if cc else ["US"], name=name, cc=cc)
    if cls == "CRYPTO":
        return dict(kind="CRYPTO", ccs=["US"], name=name)
    return dict(kind="OTHER", ccs=[], name=name)


def _t(x, s):
    return math.tanh(x / s)


def _ccy_cc(ccy):
    return CURRENCY_TO_CC.get(ccy)


def _rate_at(rows, days_ago):
    if not rows:
        return None
    try:
        target = (dt.date.today() - dt.timedelta(days=days_ago)).isoformat()
        prev = [v for d, v in rows if str(d)[:10] <= target]
        return prev[-1] if prev else rows[0][1]
    except Exception:
        return None


def score_drivers(info, data, mode):
    """info = entity(); data = dict(policy, overview, regime, cot, retail, catalysts, gpr). Mengembalikan (score, conf, drivers)."""
    W = WEIGHTS[mode]
    kind = info["kind"]
    drv = []

    def add(key, score, text):
        if score is None:
            return
        drv.append(dict(key=key, score=max(-1.0, min(1.0, float(score))), weight=W[key], text=text))

    pol = data.get("policy") or {}
    ov = {r["cc"]: r for r in (data.get("overview") or [])}
    reg = data.get("regime") or {}

    def pair_diff(fn):
        b, q = _ccy_cc(info.get("base")), _ccy_cc(info.get("quote"))
        vb, vq = (fn(b) if b else None), (fn(q) if q else None)
        return vb, vq, b, q

    if kind in ("FX", "DXY"):
        # suku bunga: selisih level (carry) + arah 6 bulan
        def lvl(cc):
            r = pol.get(cc)
            return r[-1][1] if r else None

        def chg(cc):
            r = pol.get(cc)
            if not r:
                return None
            old = _rate_at(r, 180)
            return None if old is None else r[-1][1] - old
        if kind == "FX":
            lb, lq, b, q = pair_diff(lvl)
            cb, cq, _, _ = pair_diff(chg)
            if lb is not None and lq is not None:
                s = 0.6 * _t(lb - lq, 2.0) + (0.4 * _t((cb or 0) - (cq or 0), 0.75) if cb is not None and cq is not None else 0)
                add("rate", s, f"Suku bunga {info['base']} {lb:.2f}% vs {info['quote']} {lq:.2f}% (6 bln: {(cb or 0):+.2f} vs {(cq or 0):+.2f})")
            yb, yq, _, _ = pair_diff(lambda cc: (ov.get(cc) or {}).get("y10"))
            if yb is not None and yq is not None:
                add("yld", _t(yb - yq, 1.5), f"Yield 10Y {info['base']} {yb:.2f}% vs {info['quote']} {yq:.2f}%")

            def rg(cc):
                r = reg.get(cc)
                return None if not r else 0.6 * r["g"] + 0.4 * r["i"]
            gb, gq, _, _ = pair_diff(rg)
            if gb is not None and gq is not None:
                add("regime", _t(gb - gq, 1.5), f"Regime makro {info['base']} ({(reg.get(_ccy_cc(info['base'])) or {}).get('regime', '-')}) vs {info['quote']} ({(reg.get(_ccy_cc(info['quote'])) or {}).get('regime', '-')})")
            cot = data.get("cot") or {}
            cb_, cq_ = cot.get(_ccy_cc(info["base"])), cot.get(_ccy_cc(info["quote"]))
            if cb_ is not None or cq_ is not None:
                add("cot", _t((cb_ or 0) - (cq_ or 0), 1.2), f"COT leveraged funds (z): {info['base']} {cb_ if cb_ is not None else 0:+.1f} vs {info['quote']} {cq_ if cq_ is not None else 0:+.1f}")
        else:
            add("cot", _t((data.get("cot") or {}).get("US") or 0, 1.2) if (data.get("cot") or {}).get("US") is not None else None, "COT US Dollar Index")
        g = data.get("gpr")
        if g and g.get("latest") is not None and g.get("avg90"):
            hi = (g["latest"] - g["avg90"]) / g["avg90"]
            if kind == "FX":
                sh = (1 if info["base"] in SAFE_HAVEN else 0) - (1 if info["quote"] in SAFE_HAVEN else 0)
                rk = (1 if info["base"] in RISK_CCY else 0) - (1 if info["quote"] in RISK_CCY else 0)
                s = _t(hi, 0.25) * (sh - 0.5 * rk)
                if sh or rk:
                    add("gpr", s, f"Risiko geopolitik {g['level']} ({g['latest']:.0f}) -> {'safe-haven' if sh else 'mata uang risiko'}")
        rt = (data.get("retail") or {}).get("long_pct")
        if rt is not None:
            add("retail", -_t(rt - 50, 18), f"Sentimen retail {rt:.0f}% long (kontrarian)")
    elif kind in ("METAL", "ENERGY", "COMMODITY", "INDEX", "CRYPTO"):
        cc = info.get("cc") or "US"
        r = reg.get(cc)
        if r and kind in ("INDEX", "CRYPTO"):
            add("regime", _t(0.7 * r["g"] - 0.3 * max(0, r["i"]), 1.5), f"Regime makro {cc}: {r['regime']}")
        if kind in ("METAL", "ENERGY", "COMMODITY") and reg.get("US"):
            r = reg["US"]
            add("regime", _t((-0.4 if kind == "METAL" else 0.6) * r["g"] + (0.3 * r["i"] if kind != "ENERGY" else 0), 1.5), f"Regime makro AS: {r['regime']}")
        pr = pol.get(cc)
        if pr and len(pr) > 1:
            old = _rate_at(pr, 180)
            if old is not None and kind in ("METAL", "INDEX", "CRYPTO"):
                d6 = pr[-1][1] - old
                add("rate", _t(-d6, 0.75), f"Arah suku bunga {cc} 6 bln: {d6:+.2f} (pemangkasan mendukung aset ini)")
        y = (ov.get("US") or {}).get("y10")
        if y is not None and kind == "METAL":
            add("yld", _t(3.5 - y, 1.5), f"Yield 10Y AS {y:.2f}% (yield tinggi menekan emas)")
        cot = (data.get("cot") or {}).get("self")
        if cot is not None:
            add("cot", _t(cot, 1.2), f"COT posisi spekulan (z) {cot:+.1f}")
        g = data.get("gpr")
        if g and g.get("latest") is not None and g.get("avg90"):
            hi = (g["latest"] - g["avg90"]) / g["avg90"]
            sgn = 1 if kind == "METAL" else (-1 if kind in ("INDEX", "CRYPTO") else (0.5 if kind == "ENERGY" else 0))
            if sgn:
                add("gpr", sgn * _t(hi, 0.25), f"Risiko geopolitik {g['level']} ({g['latest']:.0f})")
        rt = (data.get("retail") or {}).get("long_pct")
        if rt is not None:
            add("retail", -_t(rt - 50, 18), f"Sentimen retail {rt:.0f}% long (kontrarian)")
    ns = data.get("news")
    if ns is not None:
        add("news", _t(ns["net"], 60), f"Katalis berita: {ns['text']}")
    pm = pm_score(info, data.get("pm"))
    if pm is not None:
        add("pm", pm[0], pm[1])
    tot_w = sum(W.values())
    got = sum(d["weight"] for d in drv)
    if got <= 0:
        return 0.0, 0.0, drv
    score = sum(d["score"] * d["weight"] for d in drv) / got
    return float(score), float(got / tot_w), drv


SAFE_CCY = {"JPY": 1.0, "CHF": 0.7}            # mata uang safe haven: melemah saat risk-on
RISK_CCY = {"AUD": 0.7, "NZD": 0.7, "CAD": 0.4}  # mata uang berisiko: menguat saat risk-on


def pm_score(info, pm):
    """Driver Polymarket: arah taruhan uang sungguhan (risk-on/off, Fed dovish/hawkish, harga kripto) -> arah aset ini.
    pm = polymarket.overview(). Mengembalikan (skor -1..1, teks) atau None bila tidak relevan / data kosong."""
    if not pm:
        return None
    R, F, X = pm.get("risk"), pm.get("fed"), pm.get("crypto")
    kind = info["kind"]
    parts = []
    if kind == "INDEX":
        parts = [(R, 1.0), (F, 0.5)]
    elif kind == "CRYPTO":
        parts = [(X, 1.0), (R, 0.5), (F, 0.4)]
    elif kind == "METAL":
        parts = [(R, -0.8), (F, 0.8)]
    elif kind == "ENERGY":
        parts = [(R, -0.6)]                           # eskalasi (risk-off) menaikkan risiko pasokan minyak
    elif kind == "DXY":
        parts = [(F, -1.0), (R, -0.3)]
    elif kind == "FX":
        b, q = info.get("base"), info.get("quote")
        usd = (-1.0 if b == "USD" else 1.0 if q == "USD" else 0.0)       # Fed dovish -> USD melemah
        rs = -SAFE_CCY.get(b, 0) + SAFE_CCY.get(q, 0) + RISK_CCY.get(b, 0) - RISK_CCY.get(q, 0)
        parts = [(F, usd), (R, rs)]
    parts = [(v, w) for v, w in parts if v is not None and w]
    if not parts:
        return None
    s = sum(v * w for v, w in parts) / sum(abs(w) for _, w in parts)
    txt = []
    if R is not None:
        txt.append(f"risk {'on' if R > 0 else 'off'} {R:+.2f} ({pm.get('n_risk', 0)} pasar)")
    if F is not None:
        txt.append(f"Fed {'dovish' if F > 0 else 'hawkish'} {F:+.2f} ({pm.get('n_fed', 0)})")
    if X is not None and kind == "CRYPTO":
        txt.append(f"harga kripto {X:+.2f} ({pm.get('n_crypto', 0)})")
    o = pm.get("overall") or {}
    return max(-1.0, min(1.0, s)), "Polymarket 24j: " + ", ".join(txt) + (f"; dominan {o.get('verdict')}" if o.get("verdict") else "")


def news_net(info, cats):
    """Jumlah (arah x kekuatan) katalis yang menyebut aset ini; USD Index dibalik untuk pair USD."""
    names = {info["name"].upper()}
    net, hits = 0.0, []
    for c in cats or []:
        for ins in c.get("instruments", []):
            s = str(ins["sym"]).upper()
            sign = 1 if ins["dir"] == "BULLISH" else (-1 if ins["dir"] == "BEARISH" else 0)
            if not sign:
                continue
            if s in names:
                net += sign * ins["weight"]
                hits.append(f"{c['title']} ({ins['dir'].lower()})")
            elif info["kind"] == "FX" and s == "USD INDEX":
                if info["quote"] == "USD":
                    net -= sign * ins["weight"] * 0.6
                    hits.append(f"{c['title']} (USD {ins['dir'].lower()})")
                elif info["base"] == "USD":
                    net += sign * ins["weight"] * 0.6
                    hits.append(f"{c['title']} (USD {ins['dir'].lower()})")
    if not hits:
        return None
    return dict(net=net, text="; ".join(hits[:3]))


def event_block(info, events, mode, now=None):
    """Rilis berdampak tinggi mendekat -> pesan penahan, atau None."""
    before, after = BLOCK_MIN[mode]
    now = now or dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
    ccs = set(info.get("ccs") or [])
    best = None
    for e in events or []:
        if e.get("impact") != "HIGH":
            continue
        cc = e.get("cc") or CURRENCY_TO_CC.get(e.get("cur") or "")
        if cc not in ccs:
            continue
        try:
            t = dt.datetime.strptime(e["date"], "%Y-%m-%d %H:%M")
        except Exception:
            continue
        m = (t - now).total_seconds() / 60
        if -after <= m <= before and (best is None or abs(m) < abs(best[0])):
            best = (m, e)
    if not best:
        return None
    m, e = best
    when = f"dalam {int(m)} menit" if m >= 0 else f"{int(-m)} menit lalu"
    return f"Rilis berdampak tinggi: {e.get('event')} ({cc_label(e)}) {when} - tunggu volatilitas mereda"


def cc_label(e):
    return e.get("cc") or e.get("cur") or "?"


def _z(rows, key, n=52):
    vals = [r.get(key) for r in rows[:n] if r.get(key) is not None]
    if len(vals) < 8:
        return None
    cur = vals[0]
    mu = sum(vals) / len(vals)
    sd = (sum((v - mu) ** 2 for v in vals) / len(vals)) ** 0.5
    return None if sd == 0 else (cur - mu) / sd


async def _safe(coro, t=10):
    try:
        return await asyncio.wait_for(coro, t)
    except Exception:
        return None


async def gather(sym, mode):
    """Ambil semua data fundamental yang relevan lalu skor. Selalu mengembalikan dict (tidak pernah error)."""
    from ..providers import rates, macro, cftc, myfxbook, gpr, calendar, polymarket
    from ..analytics import catalyst
    info = entity(sym)
    out = dict(score=0.0, conf=0.0, block=None, drivers=[], entity=info["kind"], note=None)
    if info["kind"] == "OTHER":
        out["note"] = "tidak ada pemetaan fundamental untuk aset ini"
        return out
    ccs = list(info.get("ccs") or [])
    tasks = dict(policy=_safe(rates.policy_map()), overview=_safe(rates.overview()), gpr=_safe(gpr.daily()), events=_safe(calendar.events()),
                 pm=_safe(asyncio.shield(asyncio.ensure_future(polymarket.overview()))))   # shield: pengambilan tetap selesai di latar
    tasks["regmap"] = _safe(macro.regime_map(), 25)
    cot_jobs = {}
    if info["kind"] == "FX":
        for ccy in (info["base"], info["quote"]):
            cc = _ccy_cc(ccy)
            if cc in COT_BY_CC:
                cot_jobs[cc] = ("tff", COT_BY_CC[cc], "lev_net")
    elif info["kind"] == "DXY":
        cot_jobs["US"] = ("tff", COT_BY_CC["US"], "lev_net")
    elif info["name"].upper() in COT_OTHER:
        cot_jobs["self"] = COT_OTHER[info["name"].upper()]
    for k, (kind, nm, _) in cot_jobs.items():
        tasks["cot_" + k] = _safe(cftc.instrument(kind, nm, 52))
    keys = list(tasks)
    res = dict(zip(keys, await asyncio.gather(*tasks.values())))
    ov = (res.get("overview") or {}).get("rows") or []
    regime = {cc: v for cc, v in (res.get("regmap") or {}).items() if cc in ccs}
    cot = {}
    for k, (kind, nm, fld) in cot_jobs.items():
        r = res.get("cot_" + k)
        if r and r.get("rows"):
            z = _z(r["rows"], fld)
            if z is not None:
                cot[k] = z
    retail = None
    try:
        rsym = RETAIL.get(info["name"].upper(), info["name"] if info["kind"] == "FX" else None)
        if rsym:
            row = next((r for r in myfxbook.latest_table() if r["symbol"] == rsym), None)
            if row and row.get("long_pct") is not None:
                retail = dict(long_pct=row["long_pct"])
    except Exception:
        retail = None
    try:
        cats = await catalyst.build_async()
    except Exception:
        cats = []
    data = dict(policy=res.get("policy"), overview=ov, regime=regime, cot=cot, retail=retail, gpr=res.get("gpr"), news=news_net(info, cats),
                pm=res.get("pm"))
    score, conf, drv = score_drivers(info, data, mode)
    out.update(score=score, conf=conf, drivers=drv, block=event_block(info, res.get("events"), mode))
    return out
