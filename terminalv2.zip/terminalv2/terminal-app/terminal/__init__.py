"""Paket terminal."""
import importlib.util as _ilu
import sys as _sys

# httpcore memanggil `import sniffio` di SETIAP operasi kunci/koneksi. anyio versi baru tidak lagi memasang sniffio, dan
# impor yang GAGAL tidak pernah di-cache oleh Python: tiap panggilan mencari ulang di semua folder sys.path (di Windows +
# antivirus: lambat, terlihat di watchdog sebagai "importlib ... _path_stat <- httpcore ... current_async_library").
# Bila sniffio memang tidak terpasang, catat sekali sebagai "tidak ada" -> ImportError seketika (httpcore memakai asyncio).
if "sniffio" not in _sys.modules and _ilu.find_spec("sniffio") is None:
    _sys.modules["sniffio"] = None
