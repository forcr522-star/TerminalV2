import asyncio
import io
import re
import datetime as dt
import pandas as pd
from ..http import fetch, get_text, cached
from ..universe import COUNTRIES, COUNTRY_ORDER, CB_FEEDS, CB_NEWS_QUERY
from . import fred, annual, yields
from . import news as N

BIS = "https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/D.{codes}"
FRED_POLICY = {"US": "DFEDTARU", "EU": "ECBDFR", "JP": "IRSTCB01JPM156N", "GB": "IUDSOIA", "CA": "IRSTCB01CAM156N", "AU": "IRSTCB01AUM156N"}
FRED_BS = {"US": ("WALCL", 1e6, "USD"), "EU": ("ECBASSETSW", 1e6, "EUR"), "JP": ("JPNASSETS", 1e8, "JPY")}
BS_NOTE = "Neraca bank sentral ini tidak dipublikasikan lewat sumber gratis terbuka (tersedia untuk AS, Zona Euro, Jepang)."


@cached(6 * 3600, persist=True, stale_ok=30 * 86400)
async def policy_all():
    codes = "+".join(COUNTRIES[c]["bis"] for c in COUNTRY_ORDER)
    start = (dt.date.today() - dt.timedelta(days=365 * 6)).isoformat()
    r = await fetch(BIS.format(codes=codes), params={"startPeriod": start, "format": "csv"}, headers={"Accept": "text/csv"}, retries=1)
    df = pd.read_csv(io.StringIO(r.text))
    cols = {c.upper(): c for c in df.columns}
    area = cols.get("REF_AREA") or next(c for c in df.columns if "REF_AREA" in c.upper())
    per = cols.get("TIME_PERIOD") or next(c for c in df.columns if "TIME_PERIOD" in c.upper())
    val = cols.get("OBS_VALUE") or next(c for c in df.columns if "OBS_VALUE" in c.upper())
    df[area] = df[area].astype(str).str.split(":").str[0].str.strip()
    out = {}
    inv = {COUNTRIES[c]["bis"]: c for c in COUNTRY_ORDER}
    for a, g in df.groupby(area):
        cc = inv.get(a)
        if not cc:
            continue
        g = g.sort_values(per)
        out[cc] = [(str(d)[:10], float(v)) for d, v in zip(g[per], g[val]) if pd.notna(v)]
    if not out:
        raise ValueError("BIS kosong")
    return out


async def policy(cc):
    try:
        allp = await policy_all()
        if cc in allp and allp[cc]:
            return allp[cc]
    except Exception:
        pass
    sid = FRED_POLICY.get(cc)
    if sid:
        try:
            return await fred.series(sid, start=str(dt.date.today().year - 6) + "-01-01")
        except Exception:
            return []
    return []


async def policy_map():
    """Suku bunga kebijakan semua negara; bila BIS gagal, lengkapi dari FRED per negara."""
    try:
        return await policy_all()
    except Exception:
        res = await asyncio.gather(*[policy(c) for c in COUNTRY_ORDER], return_exceptions=True)
        return {c: r for c, r in zip(COUNTRY_ORDER, res) if not isinstance(r, Exception) and r}


def decisions(rows):
    out = []
    prev = None
    for d, v in rows:
        if prev is None or abs(v - prev) > 1e-9:
            out.append(dict(date=d, rate=v, change=(v - prev) if prev is not None else None))
        prev = v
    return out[-14:]


@cached(1800, persist=True, stale_ok=14 * 86400)
async def yields_for(cc):
    return await yields.collect(cc)


async def _yields(cc):
    return await yields_for(cc)


def _by(curve, tenor):
    return next((c for c in curve if c["tenor"] == tenor), None)


@cached(21600, persist=True, stale_ok=30 * 86400)
async def cds(cc):
    wgb = COUNTRIES[cc]["wgb"]
    html = await get_text(f"https://www.worldgovernmentbonds.com/cds-historical-data/{wgb}/5-years/", retries=0)
    m = re.search(r"5 Years CDS[^0-9]{0,80}([0-9]+(?:\.[0-9]+)?)", re.sub(r"<[^>]+>", " ", html))
    if not m:
        raise ValueError("CDS tidak ditemukan di halaman")
    return float(m.group(1))


async def _cds(cc):
    try:
        return await cds(cc)
    except Exception:
        return None


async def _bs_ecb():
    """Neraca konsolidasi Eurosystem (total aset, mingguan, juta EUR) langsung dari ECB Data Portal."""
    start = (dt.date.today() - dt.timedelta(days=3 * 365)).isoformat()
    txt = await get_text("https://data-api.ecb.europa.eu/service/data/ILM/W.U2.C.T000000.Z5.Z01", params={"format": "csvdata", "startPeriod": start}, retries=1)
    rows = yields.parse_ecb_csv(txt)
    if not rows:
        raise ValueError("ECB ILM kosong")
    return [(d, v * 1e6) for d, v in rows], "EUR"


async def _bs_fred(cc):
    sid, scale, ccy = FRED_BS[cc]
    rows = await fred.series(sid, start=str(dt.date.today().year - 3) + "-01-01")
    if not rows:
        raise ValueError("FRED kosong")
    return [(d, v * scale) for d, v in rows], ccy


@cached(21600, persist=True, stale_ok=30 * 86400)
async def balance_sheet(cc):
    """Total aset bank sentral. Rantai: (EU) ECB -> FRED. Negara tanpa sumber gratis: series kosong dan UI menyembunyikan panelnya."""
    if cc not in FRED_BS:
        return dict(series=[], latest=None, unit=None, reason=BS_NOTE, src=None)
    chain = ([("ECB Data Portal", _bs_ecb)] if cc == "EU" else []) + [("FRED", lambda: _bs_fred(cc))]
    err = None
    for name, fn in chain:
        try:
            rows, ccy = await fn()
            from .. import health
            if err:
                health.cover("fred.stlouisfed.org", name)
            return dict(series=rows[-60:], latest=rows[-1][1], unit=ccy, reason=None, src=name)
        except Exception as exc:
            err = exc
    return dict(series=[], latest=None, unit=None, reason=f"Sumber neraca tidak dapat dijangkau ({type(err).__name__})", src=None)


async def inflation(cc):
    """Inflasi CPI YoY terbaru: AS dari FRED (bulanan), negara lain dari IMF/World Bank (tahunan)."""
    try:
        if cc == "US":
            rows = await fred.series("CPIAUCSL", start=str(dt.date.today().year - 3) + "-01-01")
            if len(rows) > 13:
                return dict(value=(rows[-1][1] / rows[-13][1] - 1) * 100, asof=rows[-1][0], src="FRED (bulanan)")
        s = await annual.series("PCPIPCH", cc)
        y, v = annual.latest(s)
        if v is not None:
            return dict(value=v, asof=str(y), src="IMF/World Bank (tahunan)")
    except Exception:
        pass
    return None


@cached(900)
async def overview():
    pol = await policy_map()
    ys = await asyncio.gather(*[_yields(c) for c in COUNTRY_ORDER], return_exceptions=True)
    cs = await asyncio.gather(*[_cds(c) for c in COUNTRY_ORDER])
    us10 = None
    if not isinstance(ys[0], Exception):
        c = _by(ys[0]["curve"], "10Y")
        us10 = c["y"] if c else None
    rows = []
    for i, cc in enumerate(COUNTRY_ORDER):
        rate = pol.get(cc, [])[-1][1] if pol.get(cc) else None
        y10 = y2 = None
        ysrc, ynote = None, None
        if not isinstance(ys[i], Exception):
            c10, c2 = _by(ys[i]["curve"], "10Y"), _by(ys[i]["curve"], "2Y")
            y10, y2 = (c10["y"] if c10 else None), (c2["y"] if c2 else None)
            ysrc = ys[i]["src"]
            if y10 is None or y2 is None:
                ynote = "; ".join(f"{k}: {v}" for k, v in ys[i]["missing"].items())
        else:
            ynote = str(ys[i])[:120]
        rows.append(dict(cc=cc, name=COUNTRIES[cc]["name"], cb=COUNTRIES[cc]["cb"], policy=rate, y10=y10, y2=y2, spread_us=((y10 - us10) * 100) if y10 is not None and us10 is not None else None,
                         curve=((y10 - y2) * 100) if y10 is not None and y2 is not None else None, cds=cs[i], ysrc=ysrc, ynote=ynote))
    rates = [r["policy"] for r in rows if r["policy"] is not None]
    y10s = [r["y10"] for r in rows if r["y10"] is not None]
    inv = len([r for r in rows if r["curve"] is not None and r["curve"] < 0])
    n_curve = len([r for r in rows if r["curve"] is not None])
    cd = [r["cds"] for r in rows if r["cds"] is not None]
    return dict(rows=rows, avg_policy=sum(rates) / len(rates) if rates else None, avg_y10=sum(y10s) / len(y10s) if y10s else None, inverted=inv, n_curve=n_curve,
                avg_cds=sum(cd) / len(cd) if cd else None, n_yield=len(y10s), n_policy=len(rates))


@cached(900)
async def country(cc):
    pol, yl, bs, cd, infl = await asyncio.gather(policy(cc), _yields(cc), balance_sheet(cc), _cds(cc), inflation(cc), return_exceptions=True)
    pol = [] if isinstance(pol, Exception) else pol
    yl = dict(curve=[], h10=[], h2=[], hist={}, src=None, notes=[], missing={"2Y": "sumber gagal", "10Y": "sumber gagal"}) if isinstance(yl, Exception) else yl
    bs = dict(series=[], latest=None, unit=None, reason=BS_NOTE, src=None) if isinstance(bs, Exception) else bs
    cd = None if isinstance(cd, Exception) else cd
    infl = None if isinstance(infl, Exception) else infl
    c10, c2 = _by(yl["curve"], "10Y"), _by(yl["curve"], "2Y")
    spread = ((c10["y"] - c2["y"]) * 100) if c10 and c2 else None
    official = []
    if cc in CB_FEEDS:
        official = await N.fetch_feed_url(CB_FEEDS[cc], COUNTRIES[cc]["cb"], [], 6)
    wire = await N.fetch_feed_url(N.gn(CB_NEWS_QUERY[cc], "id" if cc == "ID" else "en", "3d"), "Google", ["MARKETS"], 16)
    stmt = official[0] if official else (wire[0] if wire else None)
    cat = wire[1] if len(wire) > 1 else (wire[0] if wire else None)
    ds = decisions(pol)
    ph = pol[-1500:]
    if len(ph) > 400:
        step = len(ph) // 400 + 1
        ph = ph[::step] + [ph[-1]]
    rate = pol[-1][1] if pol else None
    chg12 = None
    if pol:
        cut = (dt.date.fromisoformat(pol[-1][0]) - dt.timedelta(days=365)).isoformat()
        old = [v for d, v in pol if d <= cut]
        chg12 = rate - old[-1] if old else None
    real = rate - infl["value"] if rate is not None and infl else None
    return dict(cc=cc, name=COUNTRIES[cc]["name"], cb=COUNTRIES[cc]["cb"], policy=rate, policy_asof=pol[-1][0] if pol else None, policy_chg_12m=chg12, spread_2s10s=spread,
                y10=c10["y"] if c10 else None, y2=c2["y"] if c2 else None, y10_chg=(c10["y"] - c10["prev"]) if c10 and c10["prev"] is not None else None, cds=cd,
                inflation=infl, real_rate=real, curve=yl["curve"], h10=yl["h10"][-250:], h2=yl["h2"][-250:], ysrc=yl.get("src"), ymissing=yl.get("missing", {}), ynotes=yl.get("notes", []),
                policy_hist=ph, decisions=ds, balance=bs, statement=stmt, catalyst=cat, wire=wire, official=official)
