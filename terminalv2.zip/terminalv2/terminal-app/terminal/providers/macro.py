import asyncio
import datetime as dt
import numpy as np
import pandas as pd
from ..http import cached
from ..universe import COUNTRIES, COUNTRY_ORDER
from ..analytics import regime as R
from . import fred, annual, calendar, cftc, rates, yahoo
from .annual import IMF_KEYS, IMF_LABEL

US_IND = [
    ("GDPNOW", "Federal Reserve Bank of Atlanta GDPNow", "GDPNOW", "level", "growth", 1, "%", "HIGH"),
    ("GDP_QOQ", "U.S. Gross Domestic Product Annualized QoQ", "A191RL1Q225SBEA", "level", "growth", 1, "%", "HIGH"),
    ("CPI_YOY", "U.S. Consumer Price Index CPI YoY", "CPIAUCSL", "yoy", "inflation", 1, "%", "HIGH"),
    ("CPI_MOM", "U.S. Consumer Price Index CPI MoM", "CPIAUCSL", "mom", "inflation", 1, "%", "HIGH"),
    ("CORE_CPI_YOY", "U.S. Core CPI YoY", "CPILFESL", "yoy", "inflation", 1, "%", "HIGH"),
    ("PCE_YOY", "U.S. PCE Price Index YoY", "PCEPI", "yoy", "inflation", 1, "%", "MODERATE"),
    ("CORE_PCE_YOY", "U.S. Core PCE Price Index YoY", "PCEPILFE", "yoy", "inflation", 1, "%", "HIGH"),
    ("PPI_YOY", "U.S. Producer Price Index (All Commodities) YoY", "PPIACO", "yoy", "inflation", 1, "%", "MODERATE"),
    ("UNRATE", "U.S. Unemployment Rate", "UNRATE", "level", "growth", -1, "%", "HIGH"),
    ("NFP", "U.S. Nonfarm Payrolls Change", "PAYEMS", "diff", "growth", 1, "K", "HIGH"),
    ("NFP_YOY", "U.S. Nonfarm Payrolls YoY", "PAYEMS", "yoy", "growth", 1, "%", "MODERATE"),
    ("INDPRO_YOY", "U.S. Industrial Production YoY", "INDPRO", "yoy", "growth", 1, "%", "MODERATE"),
    ("INDPRO_MOM", "U.S. Industrial Production MoM", "INDPRO", "mom", "growth", 1, "%", "MODERATE"),
    ("RETAIL_MOM", "U.S. Retail Sales MoM", "RSAFS", "mom", "growth", 1, "%", "HIGH"),
    ("RETAIL_YOY", "U.S. Retail Sales YoY", "RSAFS", "yoy", "growth", 1, "%", "MODERATE"),
    ("CFNAI", "U.S. Chicago Fed National Activity Index", "CFNAI", "level", "growth", 1, "", "LOW"),
    ("UMICH", "U.S. University of Michigan Consumer Sentiment", "UMCSENT", "level", "growth", 1, "", "MODERATE"),
    ("CLAIMS", "U.S. Initial Jobless Claims", "ICSA", "level", "growth", -1, "", "MODERATE"),
    ("HOUSING", "U.S. Housing Starts", "HOUST", "level", "growth", 1, "K", "LOW"),
    ("DURABLE", "U.S. Durable Goods Orders MoM", "DGORDER", "mom", "growth", 1, "%", "MODERATE"),
    ("CAPU", "U.S. Capacity Utilization", "TCU", "level", "growth", 1, "%", "LOW"),
    ("JOLTS", "U.S. JOLTS Job Openings", "JTSJOL", "level", "growth", 1, "K", "MODERATE"),
    ("M2_YOY", "U.S. M2 Money Supply YoY", "M2SL", "yoy", "neutral", 1, "%", "LOW"),
    ("FFR", "U.S. Federal Funds Rate", "FEDFUNDS", "level", "neutral", 1, "%", "HIGH"),
    ("TRADE", "U.S. Trade Balance", "BOPGSTB", "level", "neutral", 1, "M", "LOW"),
]
GROWTH_SET = ["GDP_QOQ", "INDPRO_YOY", "NFP_YOY", "RETAIL_YOY", "CFNAI", "UNRATE", "UMICH"]
INFL_SET = ["CPI_YOY", "CORE_CPI_YOY", "PCE_YOY", "CORE_PCE_YOY", "PPI_YOY"]


def _period(rows):
    if len(rows) < 3:
        return 12
    d = pd.to_datetime([r[0] for r in rows[-8:]])
    gap = np.median(np.diff(d.values).astype("timedelta64[D]").astype(float))
    if gap < 10:
        return 52
    if gap < 45:
        return 12
    if gap < 120:
        return 4
    return 1


def transform(rows, tf):
    if not rows:
        return []
    if tf == "level":
        return rows
    per = _period(rows)
    vals = [v for _, v in rows]
    out = []
    for i in range(len(rows)):
        if tf == "mom" and i >= 1 and vals[i - 1]:
            out.append((rows[i][0], (vals[i] / vals[i - 1] - 1) * 100))
        elif tf == "yoy" and i >= per and vals[i - per]:
            out.append((rows[i][0], (vals[i] / vals[i - per] - 1) * 100))
        elif tf == "diff" and i >= 1:
            out.append((rows[i][0], vals[i] - vals[i - 1]))
    return out


@cached(3600)
async def us_data():
    ids = sorted({i[2] for i in US_IND})
    raw = await fred.many(ids, start=str(dt.date.today().year - 12) + "-01-01")
    out = {}
    for key, label, sid, tf, kind, sign, unit, impact in US_IND:
        rows = transform(raw.get(sid) or [], tf)
        if len(rows) < 2:
            continue
        win = 260 if _period(raw[sid]) == 52 else 120
        z, mean, sd = R.zscore_last([v for _, v in rows], win)
        out[key] = dict(key=key, label=label, kind=kind, sign=sign, unit=unit, impact=impact, date=rows[-1][0], actual=rows[-1][1], previous=rows[-2][1], history=[v for _, v in rows[-12:]],
                        dates=[d for d, _ in rows[-12:]], z=z, mean=mean, std=sd, series=rows)
    return out


def _fmt_ind(r):
    return {k: r[k] for k in ("key", "label", "kind", "unit", "impact", "date", "actual", "previous", "history", "z", "mean", "std")}


async def us_regime():
    d = await us_data()
    def block(keys):
        cols = {}
        for k in keys:
            if k in d:
                s = pd.Series({pd.Timestamp(a): b for a, b in d[k]["series"]})
                z = R.z_series(s.values, 120)
                zs = pd.Series(z.values, index=s.index) * d[k]["sign"]
                cols[k] = zs.resample("ME").last().ffill()
        return pd.DataFrame(cols)
    g, i = block(GROWTH_SET), block(INFL_SET)
    if g.empty or i.empty:
        raise ValueError("US regime data unavailable")
    idx = g.index.intersection(i.index)[-18:]
    gs, is_ = g.loc[idx].mean(axis=1), i.loc[idx].mean(axis=1)
    path = [dict(label=ts.strftime("%b %Y"), g=float(a), i=float(b)) for ts, a, b in zip(idx, gs, is_) if not (np.isnan(a) or np.isnan(b))]
    drivers = []
    for k in GROWTH_SET + INFL_SET:
        if k in d:
            r = d[k]
            drivers.append(dict(label=r["label"], actual=r["actual"], mean=r["mean"], std=r["std"], z=(r["z"] or 0) * r["sign"], type="GROWTH" if k in GROWTH_SET else "INFLATION", unit=r["unit"]))
    return dict(path=path, drivers=drivers, mode="monthly")


async def imf_all():
    """Data tahunan semua negara: IMF DataMapper, cadangan World Bank."""
    return await annual.all_countries()


def _imf_series(d, key, cc):
    return [(y, v) for y, v in d.get(key, {}).get(COUNTRIES[cc]["imf"], [])]


async def imf_regime(cc):
    d = await imf_all()
    this = dt.date.today().year
    gdp = [(y, v) for y, v in _imf_series(d, "NGDP_RPCH", cc) if 1995 <= y]
    cpi = [(y, v) for y, v in _imf_series(d, "PCPIPCH", cc) if 1995 <= y]
    lur = [(y, v) for y, v in _imf_series(d, "LUR", cc) if 1995 <= y]
    if len(gdp) < 8 or len(cpi) < 8:
        raise ValueError("IMF data unavailable")
    gz = R.z_series([v for _, v in gdp])
    cz = R.z_series([v for _, v in cpi])
    gmap = {y: float(z) for (y, _), z in zip(gdp, gz)}
    cmap = {y: float(z) for (y, _), z in zip(cpi, cz)}
    lmap = {}
    if len(lur) >= 8:
        diff = [lur[i][1] - lur[i - 1][1] for i in range(1, len(lur))]
        lz = R.z_series(diff)
        lmap = {lur[i + 1][0]: -float(z) for i, z in enumerate(lz)}
    years = [y for y in sorted(set(gmap) & set(cmap)) if y <= this][-8:]
    path = []
    for y in years:
        g = gmap[y] if y not in lmap or np.isnan(lmap[y]) else (gmap[y] + lmap[y]) / 2
        path.append(dict(label=str(y), g=g, i=cmap[y]))
    drivers = []
    for key in IMF_KEYS:
        s = [(y, v) for y, v in _imf_series(d, key, cc) if y <= this]
        if len(s) < 6:
            continue
        z, mean, sd = R.zscore_last([v for _, v in s[-25:]])
        kind = "GROWTH" if key in ("NGDP_RPCH", "LUR", "BCA_NGDPD") else ("INFLATION" if key == "PCPIPCH" else "NEUTRAL")
        sign = -1 if key == "LUR" else 1
        drivers.append(dict(label=f"{COUNTRIES[cc]['name']} {IMF_LABEL[key]}", actual=s[-1][1], mean=mean, std=sd, z=(z or 0) * sign, type=kind, unit="%", year=s[-1][0]))
    return dict(path=path, drivers=drivers, mode="annual")


@cached(21600, persist=True, stale_ok=30 * 86400)
async def regime(cc):
    base, errs = None, []
    if cc == "US":
        try:
            base = await us_regime()
        except Exception as exc:
            errs.append(f"FRED: {str(exc)[:80]}")
    if base is None:
        try:
            base = await imf_regime(cc)
        except Exception as exc:
            errs.append(f"IMF/World Bank: {str(exc)[:80]}")
    if base is None or not base["path"]:
        raise ValueError("Data regime belum tersedia (" + "; ".join(errs) + ")")
    cur = base["path"][-1]
    name = R.classify(cur["g"], cur["i"])
    avg_z = float(np.mean([d["z"] for d in base["drivers"]])) if base["drivers"] else 0
    return dict(cc=cc, regime=name, color=R.COLOR[name], growth=cur["g"], inflation=cur["i"], description=R.DESC[name], path=base["path"], drivers=base["drivers"], avg_z=avg_z, mode=base["mode"], asof=cur["label"],
                source=("FRED" if base["mode"] == "monthly" else (annual.SRC.get("NGDP_RPCH") or "IMF/World Bank")))


async def regime_map():
    res = await asyncio.gather(*[regime(c) for c in COUNTRY_ORDER], return_exceptions=True)
    out = {}
    for c, r in zip(COUNTRY_ORDER, res):
        if not isinstance(r, Exception):
            out[c] = dict(regime=r["regime"], g=r["growth"], i=r["inflation"], color=r["color"])
    return out


CCY_COT = {"US": "US Dollar Index", "EU": "Euro FX", "JP": "Japanese Yen", "GB": "British Pound", "CA": "Canadian Dollar", "AU": "Australian Dollar", "NZ": "New Zealand Dollar", "CH": "Swiss Franc"}
# (simbol Yahoo, tanda): tanda -1 bila kuotasi USD/XXX sehingga kenaikan berarti mata uang melemah
FX_STR = {"US": ("DX-Y.NYB", 1, "US Dollar Index"), "EU": ("EURUSD=X", 1, "EUR/USD"), "GB": ("GBPUSD=X", 1, "GBP/USD"), "AU": ("AUDUSD=X", 1, "AUD/USD"), "NZ": ("NZDUSD=X", 1, "NZD/USD"),
          "JP": ("JPY=X", -1, "JPY vs USD"), "CA": ("CAD=X", -1, "CAD vs USD"), "CH": ("CHF=X", -1, "CHF vs USD"), "CN": ("CNY=X", -1, "CNY vs USD"), "ID": ("IDR=X", -1, "IDR vs USD")}
OV_US = ["GDPNOW", "CPI_YOY", "UNRATE", "NFP", "RETAIL_MOM", "INDPRO_MOM", "CORE_PCE_YOY", "FFR"]
HEAT_US = ["CPI_YOY", "CORE_CPI_YOY", "CORE_PCE_YOY", "UNRATE", "NFP", "RETAIL_MOM", "INDPRO_MOM", "UMICH", "FFR"]


def weekly_pct(series, n=6):
    w = series.dropna().resample("W-FRI").last().dropna()
    r = (w.pct_change().dropna() * 100).iloc[-n:]
    return [float(x) for x in r.values][::-1], [str(i)[:10] for i in r.index][::-1]


def _annual_rows(imf, cc, n=6):
    this = dt.date.today().year
    rows = []
    for key in IMF_KEYS:
        s = [(y, v) for y, v in _imf_series(imf, key, cc) if y <= this][-n:]
        if s:
            rows.append(dict(name=f"{IMF_LABEL[key]}", values=[v for _, v in s][::-1], dates=[str(y) for y, _ in s][::-1], unit="%"))
    return rows


async def _macro_group(cc):
    cols = [f"T-{i}" for i in range(6)]
    if cc == "US":
        try:
            d = await us_data()
            rows = [dict(name=d[k]["label"].replace("U.S. ", ""), values=d[k]["history"][-6:][::-1], dates=d[k]["dates"][-6:][::-1], unit=d[k]["unit"]) for k in HEAT_US if k in d]
            if rows:
                return dict(title="Indikator makro AS (6 rilis terakhir, FRED)", cols=cols, rows=rows, kind="level")
        except Exception:
            pass
    imf = await imf_all()
    rows = _annual_rows(imf, cc)
    if not rows:
        raise ValueError("data tahunan IMF/World Bank tidak tersedia")
    return dict(title=f"Indikator makro {COUNTRIES[cc]['name']} (6 tahun terakhir, {annual.SRC.get('NGDP_RPCH') or 'IMF/World Bank'})", cols=[f"Y-{i}" for i in range(6)], rows=rows, kind="level")


async def _market_group(cc):
    sym, sign, label = FX_STR[cc]
    idx = COUNTRIES[cc]["index"]
    data = await yahoo.closes((idx, sym), "1y")
    rows = []
    cols = [f"W-{i}" for i in range(6)]
    if idx in data:
        v, d = weekly_pct(data[idx])
        rows.append(dict(name=f"Indeks saham ({idx}) % mingguan", values=v, dates=d, unit="%"))
    if sym in data:
        v, d = weekly_pct(data[sym])
        rows.append(dict(name=f"{label} % mingguan" + (" (naik = menguat)" if sign < 0 else ""), values=[x * sign for x in v], dates=d, unit="%"))
    try:
        y = await rates.yields_for(cc)
        h = y.get("h10") or []
        if len(h) > 40 and (dt.date.fromisoformat(h[-1][0]) - dt.date.fromisoformat(h[-30][0])).days < 90:
            s = pd.Series([v for _, v in h], index=pd.to_datetime([d for d, _ in h]))
            w = s.resample("W-FRI").last().dropna().diff().dropna().iloc[-6:] * 100
            rows.append(dict(name="Yield 10Y perubahan mingguan (bp)", values=[float(x) for x in w.values][::-1], dates=[str(i)[:10] for i in w.index][::-1], unit="bp"))
    except Exception:
        pass
    if not rows:
        raise ValueError("Yahoo Finance tidak mengembalikan harga")
    return dict(title=f"Pasar {COUNTRIES[cc]['name']} (6 minggu terakhir, Yahoo Finance)", cols=cols, rows=rows, kind="market")


async def _cot_group(cc):
    """Posisi spekulatif CFTC TFF untuk mata uang negara. None (panel TIDAK ditampilkan) bila CFTC tidak menerbitkan data
    terkini: IDR tidak punya kontrak futures yang dilaporkan, CNH (CME) terakhir dilaporkan April 2024."""
    name = CCY_COT.get(cc)
    if not name:
        return None
    r = await cftc.instrument("tff", name, 8)
    rows = []
    for gid, lab in (("lev", "Leveraged funds"), ("asset", "Asset managers")):
        vals = [x.get(gid + "_net") for x in r["rows"][:6]]
        if any(v is not None for v in vals):
            rows.append(dict(name=f"{name} · {lab} net (kontrak)", values=vals, dates=[x["date"] for x in r["rows"][:6]], unit=""))
    if not rows:
        raise ValueError("CFTC kosong")
    return dict(title=f"Posisi spekulatif mata uang {COUNTRIES[cc]['currency']} (CFTC TFF, 6 minggu)", cols=[f"T-{i}" for i in range(6)], rows=rows, kind="cot")


@cached(900)
async def overview(cc):
    cards, cerr = [], None
    if cc == "US":
        try:
            d = await us_data()
            cards = [dict(label=d[k]["label"], value=d[k]["actual"], unit=d[k]["unit"], date=d[k]["date"], previous=d[k]["previous"]) for k in OV_US if k in d]
        except Exception as exc:
            cerr = f"FRED: {str(exc)[:80]}"
    if not cards:
        try:
            imf = await imf_all()
            this = dt.date.today().year
            for key in IMF_KEYS:
                s = [(y, v) for y, v in _imf_series(imf, key, cc) if y <= this]
                if s:
                    cards.append(dict(label=f"{COUNTRIES[cc]['name']} {IMF_LABEL[key]}", value=s[-1][1], unit="%", date=str(s[-1][0]), previous=s[-2][1] if len(s) > 1 else None))
        except Exception as exc:
            cerr = (cerr + "; " if cerr else "") + f"IMF/WB: {str(exc)[:80]}"
    res = await asyncio.gather(_macro_group(cc), _market_group(cc), _cot_group(cc), return_exceptions=True)
    groups, errors = [], []
    for g, label in zip(res, ("makro", "pasar", "COT")):
        if isinstance(g, Exception):
            errors.append(f"{label}: {str(g)[:100]}")
        elif g:
            groups.append(g)
    return dict(cc=cc, name=COUNTRIES[cc]["name"], cards=cards, groups=groups, errors=errors + ([cerr] if cerr and not cards else []), source=annual.SRC.get("NGDP_RPCH"), heat=[])


async def data_rows(cc):
    rows = []
    if cc == "US":
        try:
            d = await us_data()
            for r in d.values():
                s = r["actual"] - r["previous"]
                rows.append(dict(date=r["date"], event=r["label"], impact=r["impact"], actual=r["actual"], forecast=None, previous=r["previous"], surprise=None, history=r["history"], unit=r["unit"], z=r["z"], src="FRED"))
        except Exception:
            pass
    try:
        ev = await calendar.events()
        for e in ev:
            if calendar.cc_of(e) != cc:
                continue
            a, f_ = e["actual"], e["forecast"]
            sur = (a - f_) if isinstance(a, (int, float)) and isinstance(f_, (int, float)) else None
            rows.append(dict(date=e["date"], event=e["event"], impact=e["impact"], actual=a, forecast=f_, previous=e["previous"], surprise=sur, history=[], unit=e.get("unit", ""), z=None, src="CAL"))
    except Exception:
        pass
    if cc != "US":
        try:
            imf = await imf_all()
            this = dt.date.today().year
            for key in IMF_KEYS:
                s = [(y, v) for y, v in _imf_series(imf, key, cc) if y <= this]
                if len(s) >= 2:
                    rows.append(dict(date=f"{s[-1][0]}-12-31", event=f"{COUNTRIES[cc]['name']} {IMF_LABEL[key]} (annual)", impact="LOW", actual=s[-1][1], forecast=None, previous=s[-2][1], surprise=None,
                                     history=[v for _, v in s[-12:]], unit="%", z=R.zscore_last([v for _, v in s[-25:]])[0], src="IMF"))
        except Exception:
            pass
    rows.sort(key=lambda r: r["date"], reverse=True)
    return rows


@cached(21600)
async def compare(a, b):
    ra, rb = await asyncio.gather(regime(a), regime(b))
    d = await imf_all()
    pa = [(y, v) for y, v in _imf_series(d, "NGDP_RPCH", a) if y <= dt.date.today().year][-15:]
    pb = [(y, v) for y, v in _imf_series(d, "NGDP_RPCH", b) if y <= dt.date.today().year][-15:]
    ca = [(y, v) for y, v in _imf_series(d, "PCPIPCH", a) if y <= dt.date.today().year][-15:]
    cb_ = [(y, v) for y, v in _imf_series(d, "PCPIPCH", b) if y <= dt.date.today().year][-15:]
    ma = {y: v for y, v in pa}
    mb = {y: v for y, v in pb}
    common = sorted(set(ma) & set(mb))
    rho = R.correlation([ma[y] for y in common], [mb[y] for y in common])
    gdiff = ra["growth"] - rb["growth"]
    idiff = ra["inflation"] - rb["inflation"]
    matrix = []
    for key in IMF_KEYS:
        sa = [(y, v) for y, v in _imf_series(d, key, a) if y <= dt.date.today().year]
        sb = [(y, v) for y, v in _imf_series(d, key, b) if y <= dt.date.today().year]
        if sa and sb:
            matrix.append(dict(concept=IMF_LABEL[key], a=sa[-1][1], b=sb[-1][1], delta=sa[-1][1] - sb[-1][1], year=sa[-1][0], hist_a=[v for _, v in sa[-12:]], hist_b=[v for _, v in sb[-12:]]))
    try:
        ov = await rates.overview()
        ra_r = next(r for r in ov["rows"] if r["cc"] == a)
        rb_r = next(r for r in ov["rows"] if r["cc"] == b)
        for label, k in (("Policy Rate", "policy"), ("10Y Yield", "y10")):
            if ra_r[k] is not None and rb_r[k] is not None:
                matrix.append(dict(concept=label, a=ra_r[k], b=rb_r[k], delta=ra_r[k] - rb_r[k], year=None, hist_a=[], hist_b=[]))
    except Exception:
        pass
    return dict(a=ra, b=rb, correlation=rho, growth_diff=gdiff, inflation_diff=idiff, alignment=R.alignment_label(rho, gdiff, idiff), matrix=matrix,
                series=dict(a_gdp=pa, b_gdp=pb, a_cpi=ca, b_cpi=cb_))
