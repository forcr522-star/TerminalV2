import asyncio
import datetime as dt
from ..http import get_json, cached
from ..universe import COUNTRIES, COUNTRY_ORDER, RATINGS
from . import news as N
from . import annual, auctions

FD = "https://api.fiscaldata.treasury.gov/services/api/fiscal_service"
# Semua dari IMF (WEO + Fiscal Monitor, termasuk proyeksi) dengan cadangan World Bank/BIS - sama untuk SEMUA negara.
# GGXONLB_NGDP & GGXWDG lama sudah tidak tersedia di DataMapper (dulu primary balance & total utang hanya muncul untuk AS).
FISCAL_KEYS = ["GGXWDG_NGDP", "GGXCNL_NGDP", "GGXONLB_G01_GDP_PT", "GGR_G01_GDP_PT", "G_X_G01_GDP_PT", "GGXWDN_G01_GDP_PT",
               "GGCB_G01_PGDP_PT", "ie", "NGDPD"]
K_DEBT, K_BAL, K_PRI, K_REV, K_EXP, K_NET, K_CAB, K_INT, K_GDP = FISCAL_KEYS


def net_interest(pri, bal):
    """Bunga NETO (% PDB) = saldo primer - saldo total (definisi IMF: primer = tanpa bunga neto), termasuk proyeksi."""
    b = dict(bal)
    return sorted((y, round(p - b[y], 3)) for y, p in pri if y in b)


def interest_pick(ie, pri, bal, year=None):
    """(nilai, tahun, jenis): bunga BRUTO yang dibayar (IMF 'Interest paid on public debt', historis) bila ada,
    selain itu bunga neto dari saldo primer - total (mis. kawasan euro yang tidak punya seri bruto)."""
    y, v = _latest(ie, year)
    if v is not None:
        return v, y, "gross"
    y, v = _latest(net_interest(pri, bal), year)
    return v, y, ("net" if v is not None else None)


def _at(series, year):
    for y, v in series:
        if y == year:
            return v
    return None


async def imf_multi(indicators, codes):
    # IMF DataMapper, dengan cadangan World Bank (lihat annual.py)
    return await annual.multi(indicators, codes)


def _latest(series, year=None):
    year = year or dt.date.today().year
    past = [(y, v) for y, v in series if y <= year]
    return past[-1] if past else (None, None)


@cached(600)
async def overview():
    codes = [COUNTRIES[c]["imf"] for c in COUNTRY_ORDER]
    d = await imf_multi(FISCAL_KEYS, codes)
    rows = []
    for cc in COUNTRY_ORDER:
        code = COUNTRIES[cc]["imf"]
        g = lambda k: d[k].get(code, [])                                    # noqa: E731
        debt, bal, pri = _latest(g(K_DEBT)), _latest(g(K_BAL)), _latest(g(K_PRI))
        rev, exp_, net, gdp = _latest(g(K_REV)), _latest(g(K_EXP)), _latest(g(K_NET)), _latest(g(K_GDP))
        intr = interest_pick(g(K_INT), g(K_PRI), g(K_BAL))
        debt_usd = debt[1] / 100 * _at(g(K_GDP), debt[0]) * 1e9 if debt[1] is not None and _at(g(K_GDP), debt[0]) else None
        rows.append(dict(cc=cc, name=COUNTRIES[cc]["name"], rating=RATINGS.get(cc, "—"), debt_gdp=debt[1], balance=bal[1], primary=pri[1],
                         revenue=rev[1], expenditure=exp_[1], net_debt=net[1], interest=intr[0], interest_kind=intr[2], gdp_usd=gdp[1], debt_usd=debt_usd, year=debt[0],
                         has_data=any(v is not None for v in (debt[1], bal[1], pri[1], rev[1]))))
    valid = [r for r in rows if r["debt_gdp"] is not None]
    summary = dict(avg_debt=sum(r["debt_gdp"] for r in valid) / len(valid) if valid else None,
                   avg_balance=(sum(r["balance"] for r in rows if r["balance"] is not None) / max(1, len([r for r in rows if r["balance"] is not None]))) if rows else None,
                   high_debt=len([r for r in rows if r["debt_gdp"] and r["debt_gdp"] > 100]),
                   avg_interest=(lambda xs: sum(xs) / len(xs) if xs else None)([r["interest"] for r in rows if r["interest"] is not None]))
    st = annual.status()
    srcs = sorted({annual.SRC.get(k) for k in FISCAL_KEYS if annual.SRC.get(k)})
    n_ok = sum(1 for r in rows if r["has_data"])
    # Negara tanpa data di IMF/World Bank/BIS disembunyikan - tetapi hanya bila sumber jelas berfungsi (>=3 negara punya data);
    # bila hampir semuanya kosong itu tanda sumber sedang gangguan, sehingga semua negara tetap ditampilkan.
    hide_missing = n_ok >= 3
    return dict(rows=rows, summary=summary, source=" + ".join(srcs) or None, errors=st["errors"], complete=len(valid) == len(rows),
                available=[r["cc"] for r in rows if r["has_data"] or not hide_missing], hidden=[r["cc"] for r in rows if hide_missing and not r["has_data"]])


async def _fd(path, params):
    return (await get_json(f"{FD}/{path}", params=params, retries=1)).get("data", [])


@cached(3600)
async def us_extras():
    debt, tga, interest = await asyncio.gather(
        _fd("v2/accounting/od/debt_to_penny", {"sort": "-record_date", "page[size]": 1}),
        _fd("v1/accounting/dts/operating_cash_balance", {"filter": "account_type:eq:Treasury General Account (TGA) Closing Balance", "sort": "-record_date", "page[size]": 1}),
        _fd("v2/accounting/od/interest_expense", {"sort": "-record_date", "page[size]": 1}),
        return_exceptions=True,
    )
    out = dict(debt=None, debt_date=None, tga=None, interest=None)
    if not isinstance(debt, Exception) and debt:
        out["debt"] = float(debt[0]["tot_pub_debt_out_amt"])
        out["debt_date"] = debt[0]["record_date"]
    if not isinstance(tga, Exception) and tga:
        r = tga[0]
        v = r.get("open_today_bal") or r.get("close_today_bal")
        out["tga"] = float(v) * 1e6 if v not in (None, "null") else None
    if not isinstance(interest, Exception) and interest:
        out["interest"] = interest[0]
    return out


@cached(600)
async def country(cc):
    code = COUNTRIES[cc]["imf"]
    d = await imf_multi(FISCAL_KEYS, [code])
    g = lambda k: d[k].get(code, [])                                        # noqa: E731
    debt, bal, pri, rev, exp_, net, cab, gdp = (g(k) for k in (K_DEBT, K_BAL, K_PRI, K_REV, K_EXP, K_NET, K_CAB, K_GDP))
    ie = g(K_INT)
    nint = net_interest(pri, bal)
    year = dt.date.today().year
    ly, lv = _latest(debt)
    by, bv = _latest(bal)
    py, pv = _latest(pri)
    ry, rv = _latest(rev)
    ey, ev = _latest(exp_)
    ny, nv = _latest(net)
    cy, cv = _latest(cab)
    iv, iy, ikind = interest_pick(ie, pri, bal)
    _ny, niv = _latest(nint)
    ry_i = _at(rev, iy) if iy else None
    gdp_y = _at(gdp, ly) if ly else None
    debt_usd = lv / 100 * gdp_y * 1e9 if lv is not None and gdp_y else None
    past = [(y, v) for y, v in debt if y <= year]
    peak = max(past, key=lambda x: x[1]) if past else (None, None)
    proj = _at(debt, year + 5) or (debt[-1][1] if debt and debt[-1][0] > year else None)
    proj_y = year + 5 if _at(debt, year + 5) is not None else (debt[-1][0] if debt and debt[-1][0] > year else None)
    prev = _at(debt, ly - 5) if ly else None
    extras = None
    if cc == "US":
        try:
            extras = await us_extras()
        except Exception:
            extras = None
    try:
        headlines = await N.fetch_feed_url(N.gn(f"{COUNTRIES[cc]['name']} budget deficit OR government debt OR fiscal", "en", "7d"), "Google", ["MARKETS"], 8)
    except Exception:
        headlines = []
    try:
        auc = await auctions.for_country(cc)
    except Exception:
        auc = dict(upcoming=[], history=[], sources=[], available=False)
    name = COUNTRIES[cc]["name"]
    parts = []
    if lv is not None:
        parts.append(f"Utang pemerintah {name} {lv:.1f}% dari PDB ({ly})" + (f" ≈ ${debt_usd / 1e12:.2f} triliun" if debt_usd else ""))
        if extras and extras.get("debt"):
            parts[-1] = f"Utang publik AS ${extras['debt'] / 1e12:.2f} triliun per {extras['debt_date']} ({lv:.0f}% PDB)"
        if prev is not None:
            parts.append(f"{'naik' if lv > prev else 'turun'} {abs(lv - prev):.1f} poin dalam 5 tahun")
        if proj is not None:
            parts.append(f"proyeksi IMF {proj:.1f}% pada {proj_y}")
    if bv is not None:
        parts.append(f"saldo anggaran {bv:+.1f}% PDB" + (f" (primer {pv:+.1f}%)" if pv is not None else ""))
    if iv is not None:
        parts.append(f"bunga utang {'dibayar' if ikind == 'gross' else 'neto'} {iv:.1f}% PDB ({iy})" + (f" = {iv / ry_i * 100:.0f}% pendapatan" if ry_i else ""))
    txt = (", ".join(parts) + ".") if parts else ""
    rng = lambda xs, a=2005: [dict(y=y, v=v) for y, v in xs if a <= y <= year + 6]   # noqa: E731
    return dict(cc=cc, name=name, rating=RATINGS.get(cc, "—"), debt_gdp=lv, debt_year=ly, balance=bv, balance_year=by, primary=pv, revenue=rv, expenditure=ev,
                net_debt=nv, cab=cv, interest=iv, interest_year=iy, interest_kind=ikind, interest_rev=(iv / ry_i * 100 if iv is not None and ry_i else None),
                net_interest=niv, debt_usd=debt_usd,
                gdp_usd=gdp_y, debt_proj=proj, debt_proj_year=proj_y, peak=peak,
                history_debt=rng(debt), history_net=rng(net), history_balance=rng(bal, 2010), history_primary=rng(pri, 2010), history_cab=rng(cab, 2010),
                history_revenue=rng(rev, 2010), history_expenditure=rng(exp_, 2010), history_interest=rng(ie, 2005), history_net_interest=rng(nint, 2005),
                commentary=txt, extras=extras, auctions=auc, news=headlines, this_year=year, source=annual.SRC.get("GGXWDG_NGDP"),
                sources={k: annual.SRC.get(k) for k in FISCAL_KEYS}, has_data=any(v is not None for v in (lv, bv, pv, rv)))
