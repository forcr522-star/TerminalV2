import asyncio
import datetime as dt
from ..http import get_json, cached
from ..universe import COUNTRIES, COUNTRY_ORDER, RATINGS
from . import news as N
from . import annual, auctions

FD = "https://api.fiscaldata.treasury.gov/services/api/fiscal_service"
FISCAL_KEYS = ["GGXWDG_NGDP", "GGXCNL_NGDP", "GGXONLB_NGDP", "GGXWDG"]


async def imf_multi(indicators, codes):
    # IMF DataMapper, dengan cadangan World Bank (lihat annual.py)
    return await annual.multi(indicators, codes)


def _latest(series, year=None):
    year = year or dt.date.today().year
    past = [(y, v) for y, v in series if y <= year]
    return past[-1] if past else (None, None)


@cached(600)
async def overview():
    codes = [COUNTRIES[c]["imf"] for c in COUNTRY_ORDER]
    d = await imf_multi(FISCAL_KEYS, codes)
    rows = []
    for cc in COUNTRY_ORDER:
        code = COUNTRIES[cc]["imf"]
        debt = _latest(d["GGXWDG_NGDP"].get(code, []))
        bal = _latest(d["GGXCNL_NGDP"].get(code, []))
        pri = _latest(d["GGXONLB_NGDP"].get(code, []))
        gross = _latest(d["GGXWDG"].get(code, []))
        rows.append(dict(cc=cc, name=COUNTRIES[cc]["name"], rating=RATINGS.get(cc, "—"), debt_gdp=debt[1], balance=bal[1], primary=pri[1], gross_debt=gross[1], year=debt[0],
                         has_data=any(v is not None for v in (debt[1], bal[1], pri[1], gross[1]))))
    valid = [r for r in rows if r["debt_gdp"] is not None]
    summary = dict(avg_debt=sum(r["debt_gdp"] for r in valid) / len(valid) if valid else None,
                   avg_balance=(sum(r["balance"] for r in rows if r["balance"] is not None) / max(1, len([r for r in rows if r["balance"] is not None]))) if rows else None,
                   high_debt=len([r for r in rows if r["debt_gdp"] and r["debt_gdp"] > 100]))
    st = annual.status()
    srcs = sorted({v for k, v in st["source"].items() if v and k in FISCAL_KEYS})
    n_ok = sum(1 for r in rows if r["has_data"])
    # Negara tanpa data di IMF/World Bank/BIS disembunyikan - tetapi hanya bila sumber jelas berfungsi (>=3 negara punya data);
    # bila hampir semuanya kosong itu tanda sumber sedang gangguan, sehingga semua negara tetap ditampilkan.
    hide_missing = n_ok >= 3
    return dict(rows=rows, summary=summary, source=" + ".join(srcs) or None, errors=st["errors"], complete=len(valid) == len(rows),
                available=[r["cc"] for r in rows if r["has_data"] or not hide_missing], hidden=[r["cc"] for r in rows if hide_missing and not r["has_data"]])


async def _fd(path, params):
    return (await get_json(f"{FD}/{path}", params=params, retries=1)).get("data", [])


@cached(3600)
async def us_extras():
    debt, tga, interest = await asyncio.gather(
        _fd("v2/accounting/od/debt_to_penny", {"sort": "-record_date", "page[size]": 1}),
        _fd("v1/accounting/dts/operating_cash_balance", {"filter": "account_type:eq:Treasury General Account (TGA) Closing Balance", "sort": "-record_date", "page[size]": 1}),
        _fd("v2/accounting/od/interest_expense", {"sort": "-record_date", "page[size]": 1}),
        return_exceptions=True,
    )
    out = dict(debt=None, debt_date=None, tga=None, interest=None)
    if not isinstance(debt, Exception) and debt:
        out["debt"] = float(debt[0]["tot_pub_debt_out_amt"])
        out["debt_date"] = debt[0]["record_date"]
    if not isinstance(tga, Exception) and tga:
        r = tga[0]
        v = r.get("open_today_bal") or r.get("close_today_bal")
        out["tga"] = float(v) * 1e6 if v not in (None, "null") else None
    if not isinstance(interest, Exception) and interest:
        out["interest"] = interest[0]
    return out


@cached(600)
async def country(cc):
    code = COUNTRIES[cc]["imf"]
    d = await imf_multi(FISCAL_KEYS, [code])
    debt = d["GGXWDG_NGDP"].get(code, [])
    bal = d["GGXCNL_NGDP"].get(code, [])
    pri = d["GGXONLB_NGDP"].get(code, [])
    gross = d["GGXWDG"].get(code, [])
    ly, lv = _latest(debt)
    by, bv = _latest(bal)
    py, pv = _latest(pri)
    gy, gv = _latest(gross)
    peak = max(debt, key=lambda x: x[1]) if debt else (None, None)
    extras = None
    if cc == "US":
        try:
            extras = await us_extras()
        except Exception:
            extras = None
    try:
        headlines = await N.fetch_feed_url(N.gn(f"{COUNTRIES[cc]['name']} budget deficit OR government debt OR fiscal", "en", "7d"), "Google", ["MARKETS"], 8)
    except Exception:
        headlines = []
    try:
        auc = await auctions.for_country(cc)
    except Exception:
        auc = dict(upcoming=[], history=[], sources=[], available=False)
    name = COUNTRIES[cc]["name"]
    if lv is not None:
        txt = f"Utang pemerintah {name} tercatat {lv:.1f}% dari PDB ({ly})" + (f", dengan saldo anggaran {bv:+.1f}% PDB." if bv is not None else ".")
        if extras and extras.get("debt"):
            txt = f"Utang publik AS mencapai ${extras['debt'] / 1e12:.2f} Triliun per {extras['debt_date']} ({lv:.0f}% PDB); saldo anggaran {bv:+.1f}% PDB." if bv is not None else txt
    else:
        txt = ""
    return dict(cc=cc, name=name, rating=RATINGS.get(cc, "—"), debt_gdp=lv, debt_year=ly, balance=bv, primary=pv, gross_debt=gv, peak=peak, history_debt=[dict(y=y, v=v) for y, v in debt if 2005 <= y <= dt.date.today().year + 3],
                history_balance=[dict(y=y, v=v) for y, v in bal if 2010 <= y <= dt.date.today().year + 3], history_primary=[dict(y=y, v=v) for y, v in pri if 2010 <= y <= dt.date.today().year + 3],
                commentary=txt, extras=extras, auctions=auc, news=headlines, this_year=dt.date.today().year, source=annual.SRC.get("GGXWDG_NGDP"), has_data=any(v is not None for v in (lv, bv, pv, gv)))
