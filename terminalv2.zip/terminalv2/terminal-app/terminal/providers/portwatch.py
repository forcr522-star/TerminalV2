import asyncio
import datetime as dt
from ..http import get_json, cached
from ..universe import CHOKEPOINTS

BASE = "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services"
DAILY = BASE + "/Daily_Chokepoints_Data/FeatureServer/0/query"
DB = BASE + "/PortWatch_chokepoints_database/FeatureServer/0/query"


def _date(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return dt.datetime.fromtimestamp(v / 1000, dt.timezone.utc).strftime("%Y-%m-%d")
    return str(v)[:10]


@cached(6 * 3600, persist=True, stale_ok=14 * 86400)
async def database():
    j = await get_json(DB, params={"where": "1=1", "outFields": "*", "outSR": 4326, "f": "json"}, retries=1)
    out = {}
    for f in j.get("features", []):
        a = f.get("attributes", {})
        if a.get("portid"):
            out[a["portid"]] = dict(name=a.get("portname", ""), lat=a.get("lat"), lon=a.get("lon"), yearly=a.get("vessel_count_total"))
    return out


@cached(6 * 3600, persist=True, stale_ok=14 * 86400)
async def daily():
    j = await get_json(DAILY, params={"where": "1=1", "outFields": "*", "orderByFields": "date DESC", "resultRecordCount": 1000, "f": "json"}, retries=1)
    out = {}
    for f in j.get("features", []):
        a = f.get("attributes", {})
        pid = a.get("portid")
        if not pid:
            continue
        out.setdefault(pid, []).append(dict(date=_date(a.get("date")), total=a.get("n_total") or 0, tanker=a.get("n_tanker") or 0, cargo=a.get("n_cargo") or 0, name=a.get("portname", "")))
    for v in out.values():
        v.sort(key=lambda r: r["date"] or "")
    return out


def _stats(rows):
    tot = [r["total"] for r in rows]
    if not tot:
        return None
    a7 = sum(tot[-7:]) / len(tot[-7:])
    a30 = sum(tot[-30:]) / len(tot[-30:])
    return dict(date=rows[-1]["date"], latest=tot[-1], avg7=a7, avg30=a30, chg_pct=(a7 / a30 - 1) * 100 if a30 else None, tanker=rows[-1]["tanker"], cargo=rows[-1]["cargo"], series=tot[-30:])


async def summary():
    db, dl = await database(), await daily()
    out = []
    for pid, rows in dl.items():
        st = _stats(rows)
        if not st:
            continue
        meta = db.get(pid, {})
        out.append(dict(portid=pid, name=meta.get("name") or rows[-1]["name"], lat=meta.get("lat"), lon=meta.get("lon"), **st))
    out.sort(key=lambda x: -x["avg30"])
    return out


def for_chokepoints(summ):
    res = {}
    for c in CHOKEPOINTS:
        hit = [s for s in summ if any(f in s["name"].lower() for f in c.get("pw", []))]
        if not hit:
            continue
        n = max(len(s["series"]) for s in hit)
        series = [sum((s["series"][len(s["series"]) - n + i] if len(s["series"]) - n + i >= 0 else 0) for s in hit) for i in range(n)]
        a7 = sum(series[-7:]) / len(series[-7:])
        a30 = sum(series) / len(series)
        res[c["id"]] = dict(transits=series[-1], avg7=a7, avg30=a30, chg_pct=(a7 / a30 - 1) * 100 if a30 else None, date=hit[0]["date"], series=series)
    return res


# ---------------------------------------------------------------------------------------------- globe: layer MARITIME
PORTS_DB = BASE + "/PortWatch_ports_database/FeatureServer/0/query"
PORTS_DAILY = BASE + "/Daily_Ports_Data/FeatureServer/0/query"
ROUTES = BASE + "/Global_Shipping_Routes/FeatureServer/15/query"
AIRPORTS = BASE + "/FR24_airports/FeatureServer/0/query"


async def _all_rows(url, params, page=2000):
    """Semua baris layer ArcGIS (dibagi per halaman resultOffset)."""
    out, off = [], 0
    while True:
        j = await get_json(url, params=dict(params, resultOffset=off, resultRecordCount=page, f="json"), retries=1)
        fs = j.get("features", [])
        out += [f.get("attributes", {}) for f in fs]
        if not fs or not j.get("exceededTransferLimit") and len(fs) < page:
            return out
        off += len(fs)
        if off > 20000:
            return out


@cached(24 * 3600, persist=True, stale_ok=30 * 86400)
async def ports():
    """2.000+ pelabuhan dunia (IMF PortWatch): nama, negara, koordinat, kapal per tahun, industri utama."""
    rows = await _all_rows(PORTS_DB, {"where": "1=1", "outFields": "portid,portname,country,ISO3,lat,lon,vessel_count_total,industry_top1", "returnGeometry": "false"})
    return [dict(id=a["portid"], name=a.get("portname") or "", country=a.get("country") or "", iso3=a.get("ISO3") or "", lat=a.get("lat"), lon=a.get("lon"),
                 yearly=a.get("vessel_count_total") or 0, industry=a.get("industry_top1") or "") for a in rows if a.get("lat") is not None and a.get("portid")]


def _stat_params(where):
    return {"where": where, "groupByFieldsForStatistics": "portid,ISO3",
            "outStatistics": '[{"statisticType":"sum","onStatisticField":"portcalls","outStatisticFieldName":"pc"}]'}


@cached(6 * 3600, persist=True, stale_ok=7 * 86400)
async def port_activity():
    """Kunjungan kapal per pelabuhan & negara: rata-rata harian 7 hari terakhir vs 28 hari sebelumnya (tanggal data
    terakhir PortWatch, biasanya tertinggal 4-6 hari). Dari penjumlahan resmi Daily_Ports_Data, bukan perkiraan."""
    j = await get_json(PORTS_DAILY, params={"where": "1=1", "outStatistics": '[{"statisticType":"max","onStatisticField":"date","outStatisticFieldName":"mx"}]', "f": "json"}, retries=1)
    last = dt.date.fromisoformat(str(j["features"][0]["attributes"]["mx"])[:10])
    d7, d35 = (last - dt.timedelta(days=6)).isoformat(), (last - dt.timedelta(days=34)).isoformat()
    cur = await _all_rows(PORTS_DAILY, _stat_params(f"date>='{d7}'"), page=1000)
    prev = await _all_rows(PORTS_DAILY, _stat_params(f"date>='{d35}' AND date<'{d7}'"), page=1000)
    pm = {a["portid"]: (a.get("pc") or 0) for a in prev}
    ports_out, by_c = {}, {}
    for a in cur:
        c7 = (a.get("pc") or 0) / 7
        c28 = pm.get(a["portid"], 0) / 28
        ports_out[a["portid"]] = dict(d7=round(c7, 2), d28=round(c28, 2), chg=round((c7 / c28 - 1) * 100, 1) if c28 >= 0.5 else None)
        r = by_c.setdefault(a.get("ISO3") or "", [0.0, 0.0])
        r[0] += c7
        r[1] += c28
    countries = {iso: dict(d7=round(v[0], 1), d28=round(v[1], 1), chg=round((v[0] / v[1] - 1) * 100, 1) if v[1] >= 2 else None) for iso, v in by_c.items() if iso}
    return dict(date=last.isoformat(), ports=ports_out, countries=countries)


@cached(7 * 86400, persist=True, stale_ok=60 * 86400)
async def routes():
    """Jaringan rute pelayaran global (IMF PortWatch) sebagai MultiLineString [lon, lat] (disederhanakan ±0,1°)."""
    j = await get_json(ROUTES, params={"where": "1=1", "outFields": "FID", "returnGeometry": "true", "outSR": 4326, "geometryPrecision": 2,
                                       "maxAllowableOffset": 0.1, "f": "json"}, retries=1)
    paths = []
    for f in j.get("features", []):
        paths += [p for p in (f.get("geometry") or {}).get("paths", []) if len(p) > 1]
    return dict(type="MultiLineString", coordinates=paths)


@cached(7 * 86400, persist=True, stale_ok=60 * 86400)
async def airports():
    """Bandara dunia berkode IATA (data FlightRadar24 di layanan IMF): [lat, lon, iata, nama, negara]."""
    rows = await _all_rows(AIRPORTS, {"where": "iata_code IS NOT NULL AND iata_code<>''", "outFields": "name,latitude,longitude,iata_code,country_name", "returnGeometry": "false"})
    out = []
    for a in rows:
        try:
            out.append([round(float(a["latitude"]), 3), round(float(a["longitude"]), 3), a.get("iata_code") or "", (a.get("name") or "")[:60], a.get("country_name") or ""])
        except (TypeError, ValueError, KeyError):
            continue
    return out


# nama negara PortWatch (ISO3) -> nama di world.geojson (hanya yang berbeda)
WORLD_NAME = {
    "ATG": "Antigua and Barb.", "BHS": "Bahamas", "BLM": "St-Barthélemy", "BRN": "Brunei", "COD": "Dem. Rep. Congo", "COG": "Congo", "COK": "Cook Is.",
    "CYM": "Cayman Is.", "DOM": "Dominican Rep.", "FRO": "Faeroe Is.", "GMB": "Gambia", "GNQ": "Eq. Guinea", "HKG": "Hong Kong", "KNA": "St. Kitts and Nevis",
    "KOR": "South Korea", "LCA": "Saint Lucia", "MAC": "Macao", "MAF": "St-Martin", "MHL": "Marshall Is.", "MNP": "N. Mariana Is.", "NLD": "Netherlands",
    "PYF": "Fr. Polynesia", "RUS": "Russia", "SLB": "Solomon Is.", "STP": "São Tomé and Principe", "TCA": "Turks and Caicos Is.", "TUR": "Turkey", "TWN": "Taiwan",
    "USA": "United States of America", "VCT": "St. Vin. and Gren.", "VGB": "British Virgin Is.", "VIR": "U.S. Virgin Is.",
}


async def sea_static():
    """Bagian layer MARITIME yang jarang berubah (dimuat sekali per sesi): pelabuhan + aktivitas, negara, rute, choke point."""
    ps, act, rt, summ = await asyncio.gather(ports(), port_activity(), routes(), summary(), return_exceptions=True)
    ps = [] if isinstance(ps, Exception) else ps
    act = {"ports": {}, "countries": {}, "date": None} if isinstance(act, Exception) else act
    rt = None if isinstance(rt, Exception) else rt
    summ = [] if isinstance(summ, Exception) else summ
    names = {}
    out_ports = []
    for p in ps:
        a = act["ports"].get(p["id"], {})
        names.setdefault(p["iso3"], WORLD_NAME.get(p["iso3"], p["country"]))
        out_ports.append([round(p["lat"], 3), round(p["lon"], 3), p["name"], p["country"], a.get("d7"), a.get("chg"), p["industry"], p["yearly"]])
    countries = {names[iso]: v for iso, v in act["countries"].items() if iso in names}
    cps = [dict(name=s["name"], lat=s["lat"], lon=s["lon"], latest=s["latest"], avg7=round(s["avg7"], 1), avg30=round(s["avg30"], 1), chg_pct=s["chg_pct"],
                tanker=s["tanker"], cargo=s["cargo"], date=s["date"]) for s in summ if s.get("lat") is not None]
    return dict(ports=out_ports, countries=countries, activity_date=act.get("date"), routes=rt, pw_chokepoints=cps,
                fields=["lat", "lon", "name", "country", "calls_per_day_7d", "chg_pct_vs_28d", "industry", "vessels_per_year"])
