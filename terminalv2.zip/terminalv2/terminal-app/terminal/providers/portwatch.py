import datetime as dt
from ..http import get_json, cached
from ..universe import CHOKEPOINTS

BASE = "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services"
DAILY = BASE + "/Daily_Chokepoints_Data/FeatureServer/0/query"
DB = BASE + "/PortWatch_chokepoints_database/FeatureServer/0/query"


def _date(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return dt.datetime.fromtimestamp(v / 1000, dt.timezone.utc).strftime("%Y-%m-%d")
    return str(v)[:10]


@cached(6 * 3600, persist=True, stale_ok=14 * 86400)
async def database():
    j = await get_json(DB, params={"where": "1=1", "outFields": "*", "outSR": 4326, "f": "json"}, retries=1)
    out = {}
    for f in j.get("features", []):
        a = f.get("attributes", {})
        if a.get("portid"):
            out[a["portid"]] = dict(name=a.get("portname", ""), lat=a.get("lat"), lon=a.get("lon"), yearly=a.get("vessel_count_total"))
    return out


@cached(6 * 3600, persist=True, stale_ok=14 * 86400)
async def daily():
    j = await get_json(DAILY, params={"where": "1=1", "outFields": "*", "orderByFields": "date DESC", "resultRecordCount": 1000, "f": "json"}, retries=1)
    out = {}
    for f in j.get("features", []):
        a = f.get("attributes", {})
        pid = a.get("portid")
        if not pid:
            continue
        out.setdefault(pid, []).append(dict(date=_date(a.get("date")), total=a.get("n_total") or 0, tanker=a.get("n_tanker") or 0, cargo=a.get("n_cargo") or 0, name=a.get("portname", "")))
    for v in out.values():
        v.sort(key=lambda r: r["date"] or "")
    return out


def _stats(rows):
    tot = [r["total"] for r in rows]
    if not tot:
        return None
    a7 = sum(tot[-7:]) / len(tot[-7:])
    a30 = sum(tot[-30:]) / len(tot[-30:])
    return dict(date=rows[-1]["date"], latest=tot[-1], avg7=a7, avg30=a30, chg_pct=(a7 / a30 - 1) * 100 if a30 else None, tanker=rows[-1]["tanker"], cargo=rows[-1]["cargo"], series=tot[-30:])


async def summary():
    db, dl = await database(), await daily()
    out = []
    for pid, rows in dl.items():
        st = _stats(rows)
        if not st:
            continue
        meta = db.get(pid, {})
        out.append(dict(portid=pid, name=meta.get("name") or rows[-1]["name"], lat=meta.get("lat"), lon=meta.get("lon"), **st))
    out.sort(key=lambda x: -x["avg30"])
    return out


def for_chokepoints(summ):
    res = {}
    for c in CHOKEPOINTS:
        hit = [s for s in summ if any(f in s["name"].lower() for f in c.get("pw", []))]
        if not hit:
            continue
        n = max(len(s["series"]) for s in hit)
        series = [sum((s["series"][len(s["series"]) - n + i] if len(s["series"]) - n + i >= 0 else 0) for s in hit) for i in range(n)]
        a7 = sum(series[-7:]) / len(series[-7:])
        a30 = sum(series) / len(series)
        res[c["id"]] = dict(transits=series[-1], avg7=a7, avg30=a30, chg_pct=(a7 / a30 - 1) * 100 if a30 else None, date=hit[0]["date"], series=series)
    return res
