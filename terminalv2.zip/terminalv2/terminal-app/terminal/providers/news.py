import asyncio
import hashlib
import re
import time
import calendar
import json
from urllib.parse import quote_plus
import feedparser
from ..http import fetch
from .. import store
from ..analytics import sentiment as S

G = "https://news.google.com/rss/search?q={q}&hl=en-US&gl=US&ceid=US:en"
GID = "https://news.google.com/rss/search?q={q}&hl=id&gl=ID&ceid=ID:id"


def gn(q, lang="en", when="1d"):
    base = GID if lang == "id" else G
    return base.format(q=quote_plus(f"{q} when:{when}"))


FEEDS = [
    ("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml", ["GEOPOLITICS"]),
    ("BBC Business", "https://feeds.bbci.co.uk/news/business/rss.xml", ["MARKETS"]),
    ("BBC Technology", "https://feeds.bbci.co.uk/news/technology/rss.xml", ["TECH"]),
    ("BBC Middle East", "https://feeds.bbci.co.uk/news/world/middle_east/rss.xml", ["MIDDLE EAST"]),
    ("BBC Asia", "https://feeds.bbci.co.uk/news/world/asia/rss.xml", ["ASIA"]),
    ("BBC Europe", "https://feeds.bbci.co.uk/news/world/europe/rss.xml", ["EUROPE"]),
    ("BBC US & Canada", "https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml", ["UNITED STATES"]),
    # CNBC: feed RSS search.cnbc.com sering menolak (403) / macet -> diganti pencarian Google News per situs
    ("Google: CNBC Markets", gn("site:cnbc.com markets OR economy OR stocks"), ["MARKETS"]),
    ("Google: CNBC World", gn("site:cnbc.com world OR geopolitics OR energy"), ["GEOPOLITICS"]),
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss", ["CRYPTO"]),
    ("Cointelegraph", "https://cointelegraph.com/rss", ["CRYPTO"]),
    ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml", ["GEOPOLITICS"]),
    ("MarketWatch", "https://feeds.content.dowjones.io/public/rss/mw_topstories", ["MARKETS"]),
    ("MarketWatch Pulse", "https://feeds.content.dowjones.io/public/rss/mw_marketpulse", ["MARKETS"]),
    ("Investing.com Forex", "https://www.investing.com/rss/news_1.rss", ["FOREX"]),
    ("MarketWatch Markets", "https://feeds.a.dj.com/rss/RSSMarketsMain.xml", ["MARKETS"]),
    ("Investing.com", "https://www.investing.com/rss/news.rss", ["MARKETS"]),
    ("EIA Today in Energy", "https://www.eia.gov/rss/todayinenergy.xml", ["COMMODITIES"]),
    ("Rigzone", "https://www.rigzone.com/news/rss/rigzone_latest.aspx", ["COMMODITIES"]),
    ("CNBC Indonesia", "https://www.cnbcindonesia.com/news/rss", ["INDONESIA"]),
    ("Kontan", "https://www.kontan.co.id/rss", ["INDONESIA"]),
    ("Antara Ekonomi", "https://www.antaranews.com/rss/ekonomi.xml", ["INDONESIA"]),
    ("CNBC Indonesia Market", "https://www.cnbcindonesia.com/market/rss", ["INDONESIA"]),
    ("Tempo Bisnis", "https://rss.tempo.co/bisnis", ["INDONESIA"]),
    ("Google: Markets", gn("stock market OR Wall Street"), ["MARKETS"]),
    ("Google: Oil", gn("oil prices OPEC crude"), ["COMMODITIES"]),
    ("Google: Gold", gn("gold price OR silver price OR copper"), ["COMMODITIES"]),
    ("Google: Forex", gn("forex dollar euro yen sterling"), ["FOREX"]),
    ("Google: Fed", gn("Federal Reserve OR FOMC OR Treasury yields"), ["UNITED STATES"]),
    ("Google: ECB", gn("ECB OR Bank of England OR eurozone"), ["EUROPE"]),
    ("Google: Crypto", gn("bitcoin OR ethereum OR crypto"), ["CRYPTO"]),
    ("Google: MidEast", gn("Iran OR Israel OR Houthi OR Gaza OR Yemen"), ["MIDDLE EAST", "GEOPOLITICS"]),
    ("Google: Ukraine", gn("Ukraine Russia"), ["EUROPE", "GEOPOLITICS"]),
    ("Google: Asia", gn("China economy OR Japan economy OR Asia markets"), ["ASIA"]),
    ("Google: Tech", gn("AI OR semiconductor OR Nvidia OR Big Tech"), ["TECH"]),
    ("Google: Indonesia", gn("IHSG OR rupiah OR Bank Indonesia OR ekonomi Indonesia", "id"), ["INDONESIA"]),
    ("Google: Indonesia Saham", gn("saham OR obligasi OR emas Indonesia", "id"), ["INDONESIA"]),
    # Media utama lewat pencarian Google News per situs (satu host andal; penerbit diambil dari akhiran judul)
    ("Google: Reuters Markets", gn("site:reuters.com markets OR economy OR business"), ["MARKETS"]),
    ("Google: Reuters World", gn("site:reuters.com world"), ["GEOPOLITICS"]),
    ("Google: Bloomberg", gn("site:bloomberg.com markets OR economy"), ["MARKETS"]),
    ("Google: Financial Times", gn("site:ft.com markets OR economy"), ["MARKETS"]),
    ("Google: WSJ", gn("site:wsj.com markets OR economy"), ["MARKETS"]),
    ("Google: Nikkei Asia", gn("site:asia.nikkei.com"), ["ASIA"]),
    ("Google: SCMP", gn("site:scmp.com economy OR china"), ["ASIA"]),
    ("Google: FXStreet", gn("site:fxstreet.com"), ["FOREX"]),
    ("Google: investingLive", gn("site:forexlive.com OR site:investinglive.com"), ["FOREX"]),
    ("Google: Kitco", gn("site:kitco.com gold"), ["COMMODITIES"]),
    ("Google: OilPrice", gn("site:oilprice.com"), ["COMMODITIES"]),
    ("Google: The Block / Decrypt", gn("site:theblock.co OR site:decrypt.co"), ["CRYPTO"]),
    ("Google: Bisnis.com", gn("site:bisnis.com", "id"), ["INDONESIA"]),
    # Rilis resmi bank sentral
    ("Federal Reserve", "https://www.federalreserve.gov/feeds/press_all.xml", ["UNITED STATES"]),
    ("Fed Speeches", "https://www.federalreserve.gov/feeds/speeches.xml", ["UNITED STATES"]),
    ("ECB Press", "https://www.ecb.europa.eu/rss/press.html", ["EUROPE"]),
    ("Bank of England", "https://www.bankofengland.co.uk/rss/news", ["EUROPE"]),
    ("Bank of Canada", "https://www.bankofcanada.ca/content_type/press-releases/feed/", ["MARKETS"]),
]
OFFICIAL = {"Federal Reserve", "Fed Speeches", "ECB Press", "Bank of England", "Bank of Canada"}


def _every(name):
    """Jeda minimal antar pengambilan per feed (detik): Google News 5 menit (hindari pembatasan), bank sentral 15 menit."""
    if name.startswith("Google"):
        return 300
    if name in OFFICIAL:
        return 900
    return 90

# Feed dihapus karena endpoint sudah mati/ditolak (terlihat di "Status sumber data"):
#   finance.yahoo.com/news/rssindex (404), oilprice.com/rss/main (500), bisnis.com/rss (403 anti-bot),
#   search.cnbc.com (403 / timeout). OilPrice, Bisnis.com & CNBC kini lewat pencarian Google News per situs.
# Puluhan feed saling menggantikan, jadi kegagalan satu feed tidak boleh memunculkan lencana "sumber bermasalah".
from urllib.parse import urlparse as _up
from .. import health as _health
from ..universe import CB_FEEDS as _CBF
for _n, _u, _h in FEEDS:
    if _up(_u).netloc != "news.google.com":
        _health.mark_optional(_up(_u).netloc)
for _u in _CBF.values():
    _health.mark_optional(_up(_u).netloc)

SECTIONS = ["FAST NEWS", "MARKETS", "GEOPOLITICS", "CRYPTO", "COMMODITIES", "FOREX", "TECH", "UNITED STATES", "EUROPE", "ASIA", "MIDDLE EAST", "INDONESIA"]
_items = {}
_state = dict(last_fetch=0, new_last=0, errors={}, ok={})
_pulled = {}               # nama feed -> waktu pengambilan terakhir
_G_SPLIT = re.compile(r"\s+-\s+([^-]{2,40})$")


def _norm(title):
    return re.sub(r"[^a-z0-9 ]", "", title.lower())[:90].strip()


def _parse(name, text, hints):
    fp = feedparser.parse(text)
    out = []
    now = time.time()
    for e in fp.entries[:60]:
        title = (e.get("title") or "").strip()
        if not title or len(title) < 12:
            continue
        src = name
        if name.startswith("Google"):
            m = _G_SPLIT.search(title)
            if m:
                src = m.group(1).strip()
                title = title[: m.start()].strip()
            elif getattr(e, "source", None):
                src = e.source.get("title", name)
        ts = now
        for k in ("published_parsed", "updated_parsed"):
            if e.get(k):
                ts = calendar.timegm(e[k])
                break
        if ts > now + 600:
            ts = now
        if now - ts > 3 * 86400:
            continue
        summary = re.sub(r"<[^>]+>", " ", e.get("summary", "") or "")[:240].strip()
        out.append(dict(title=title, source=src, link=e.get("link", ""), ts=int(ts), summary=summary, hints=list(hints), feed=name))
    return out


def _enrich(it):
    title = it["title"]
    cats = S.categories(title, it["hints"])
    it["cats"] = cats
    it["sent"] = S.sentiment_label(title)
    it["prio"] = S.priority(title)
    it["flash"] = S.is_flash(title, it["source"])
    it["t1"] = S.tier1(it["source"]) or S.tier1(it["feed"])
    it["tags"] = S.tags(title)
    it["id"] = hashlib.sha1(_norm(title).encode()).hexdigest()[:16]
    return it


async def _pull(name, url, hints):
    try:
        r = await fetch(url, retries=1, headers={"Accept": "application/rss+xml, application/xml, text/xml, */*"})
        items = await asyncio.to_thread(_parse, name, r.text, hints)
        _state["ok"][name] = len(items)
        _state["errors"].pop(name, None)
        return items
    except Exception as exc:
        _state["errors"][name] = str(exc)[:120]
        _state["ok"].pop(name, None)
        return []


async def refresh(force=False):
    now = time.time()
    due = [(n, u, h) for n, u, h in FEEDS if force or now - _pulled.get(n, 0) >= _every(n)]
    for n, _, _ in due:
        _pulled[n] = now
    results = await asyncio.gather(*[_pull(n, u, h) for n, u, h in due])
    added = 0
    rows = []
    for items in results:
        for it in items:
            it = _enrich(it)
            old = _items.get(it["id"])
            if old:
                if it["t1"] and not old["t1"]:
                    old["t1"] = True
                continue
            _items[it["id"]] = it
            added += 1
            rows.append((it["id"], it["ts"], it["source"], it["title"], it["link"], json.dumps({k: it[k] for k in ("cats", "sent", "prio", "flash", "t1", "tags")})))
    cutoff = time.time() - 3 * 86400
    for k in [k for k, v in _items.items() if v["ts"] < cutoff]:
        _items.pop(k, None)
    if rows:
        try:
            await asyncio.to_thread(store.executemany, "INSERT OR IGNORE INTO news(id,ts,source,title,link,payload) VALUES(?,?,?,?,?,?)", rows)
        except Exception:
            pass
    _state["last_fetch"] = int(time.time())
    _state["new_last"] = added
    return added


def load_cached():
    try:
        rows = store.query("SELECT * FROM news WHERE ts>? ORDER BY ts DESC LIMIT 1500", (int(time.time()) - 2 * 86400,))
    except Exception:
        return
    for r in rows:
        try:
            p = json.loads(r["payload"])
        except Exception:
            continue
        _items[r["id"]] = dict(id=r["id"], ts=r["ts"], source=r["source"], title=r["title"], link=r["link"], summary="", hints=[], feed=r["source"], **p)


def all_items(max_age=86400):
    now = time.time()
    return sorted([v for v in _items.values() if now - v["ts"] <= max_age], key=lambda x: -x["ts"])


def _public(it):
    return dict(id=it["id"], ts=it["ts"], title=it["title"], source=it["source"], link=it["link"], sent=it["sent"], prio=it["prio"], flash=it["flash"], t1=it["t1"], tags=it["tags"])


def session_label():
    h = time.gmtime().tm_hour
    if 0 <= h < 7:
        return "ASIA MKT"
    if 7 <= h < 13:
        return "EUROPE MKT"
    if 13 <= h < 21:
        return "US MKT"
    return "ASIA MKT"


def board(per=14):
    items = all_items()
    now = time.time()
    sections = {}
    for sec in SECTIONS:
        if sec == "FAST NEWS":
            pool = [i for i in items if i["flash"] or i["prio"] == "CRIT" or (i["t1"] and i["prio"])]
        else:
            pool = [i for i in items if sec in i["cats"]]
        recent = [i for i in pool if now - i["ts"] < 600]
        base = max(1, len([i for i in pool if now - i["ts"] < 86400]) / 144)
        sections[sec] = dict(items=[_public(i) for i in pool[:per]], total=len(pool), recent=len(recent), spike=int(len(recent) >= max(3, 2 * base)) * len(recent))
    last30 = [i for i in items if now - i["ts"] < 1800]
    stats = dict(session=session_label(), articles=len(items), flow=round(len(last30) / 30, 1), spikes=sum(1 for s in sections.values() if s["spike"]),
                 priority=sum(1 for i in items if i["prio"] or i["flash"]), delta=_state["new_last"], last_fetch=_state["last_fetch"], feeds_ok=len(_state["ok"]), feeds_total=len(FEEDS))
    return dict(sections=sections, stats=stats)


def ticker_alert():
    for i in all_items(6 * 3600):
        if i["prio"] == "CRIT" and i["t1"]:
            return _public(i)
    for i in all_items(6 * 3600):
        if i["prio"]:
            return _public(i)
    return None


def live_feed(n=40):
    return [_public(i) for i in all_items(12 * 3600)[:n]]


def search(q, n=40):
    q = q.lower()
    return [_public(i) for i in all_items(3 * 86400) if q in i["title"].lower()][:n]


def status():
    return dict(ok=_state["ok"], errors=_state["errors"], items=len(_items), last_fetch=_state["last_fetch"])


async def fetch_feed_url(url, name="feed", hints=(), n=15):
    try:
        r = await fetch(url, retries=1)
        items = await asyncio.to_thread(_parse, name, r.text, list(hints))
        return [_public(_enrich(i)) for i in sorted(items, key=lambda x: -x["ts"])[:n]]
    except Exception:
        return []
