"""Akun "squawk" di X (Twitter) sebagai sumber berita tercepat - utamanya Walter Bloomberg (@DeItaone), yang memposting
ulang headline terminal Bloomberg dalam hitungan detik.

X tidak menyediakan feed publik tanpa login, jadi ada dua jalur RESMI/terkendali (pilih salah satu di .env):

1) X API v2 (disarankan, paling cepat):  X_BEARER_TOKEN=<token dari developer.x.com>
   - GET /2/users/by/username/<akun>  -> id akun (disimpan, hanya sekali)
   - GET /2/users/<id>/tweets?since_id=<terakhir>  -> HANYA posting baru (hemat kuota baca)
   - Membaca posting di X API butuh paket berbayar; atur X_POLL_SEC sesuai kuota paket Anda (bawaan 60 dtk).
     429 (kuota habis) -> menunggu sampai waktu reset yang dikirim X; 401/403 -> berhenti dengan pesan jelas.

2) Jembatan RSS milik Anda sendiri:  X_RSS_URLS=<url feed RSS akun itu>  (mis. dari layanan "X ke RSS" seperti
   rss.app, atau RSSHub / Nitter yang Anda jalankan sendiri). Terminal hanya membaca RSS tersebut.

Tanpa keduanya, modul ini mati dan halaman SQUAWK menjelaskan cara mengaktifkannya. Sumber cepat lain yang tidak
butuh akun (FinancialJuice, Bloomberg RSS) tetap berjalan - lihat providers/news.py.
"""
import asyncio
import datetime as dt
import html
import re
import time

from .. import config, health, store
from .. import cpu
from ..http import fetch

API = "https://api.x.com/2"
NAMES = {"deitaone": "Walter Bloomberg"}        # nama tampilan akun yang dikenal
health.mark_optional("api.x.com")               # sumber opsional: kegagalannya tidak memunculkan lencana merah

_state = dict(mode="off", ok=None, last_ok=None, last_error=None, wait_until=0.0, polls=0, items=0, accounts={})
_URL = re.compile(r"https?://\S+")


def mode():
    if config.X_BEARER_TOKEN:
        return "api"
    if config.X_RSS_URLS:
        return "rss"
    return "off"


def label(account):
    a = account.lstrip("@")
    return f"{NAMES.get(a.lower(), '@' + a)} (X)"


def clean_text(text):
    """Teks posting -> headline: buang tautan t.co, rapikan spasi & entitas HTML. Kosong bila tinggal tautan."""
    t = html.unescape(_URL.sub("", text or "")).replace("\n", " ")
    return re.sub(r"\s{2,}", " ", t).strip(" -–|")


def _iso_ts(s):
    try:
        return int(dt.datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp())
    except Exception:
        return int(time.time())


def parse_tweets(payload, account):
    """Respons /2/users/:id/tweets -> item berita (format sama dengan news._parse)."""
    out = []
    for tw in (payload or {}).get("data") or []:
        title = clean_text(tw.get("text"))
        if len(title) < 8:
            continue
        out.append(dict(title=title, source=label(account), link=f"https://x.com/{account}/status/{tw.get('id')}",
                        ts=_iso_ts(tw.get("created_at")), summary="", hints=["MARKETS"], feed="X", fast=True, xid=str(tw.get("id"))))
    return out


def _auth():
    return {"Authorization": f"Bearer {config.X_BEARER_TOKEN}"}


async def _user_id(account):
    key = f"x_uid_{account.lower()}"
    uid = await asyncio.to_thread(store.kv_get, key)
    if uid:
        return uid
    r = await fetch(f"{API}/users/by/username/{account}", headers=_auth(), retries=0, quiet=True)
    uid = ((r.json() or {}).get("data") or {}).get("id")
    if not uid:
        raise ValueError(f"akun @{account} tidak ditemukan")
    await asyncio.to_thread(store.kv_set, key, uid)
    return uid


def _rate_wait(exc):
    """Waktu tunggu dari header x-rate-limit-reset (detik epoch) pada 429; bawaan 15 menit."""
    resp = getattr(exc, "response", None)
    try:
        reset = float(resp.headers.get("x-rate-limit-reset"))
        return max(30.0, reset - time.time() + 2)
    except Exception:
        return 900.0


async def _poll_api(account):
    uid = await _user_id(account)
    key = f"x_since_{account.lower()}"
    since = await asyncio.to_thread(store.kv_get, key)
    params = {"max_results": 20 if since else 10, "tweet.fields": "created_at", "exclude": "retweets,replies"}
    if since:
        params["since_id"] = since
    r = await fetch(f"{API}/users/{uid}/tweets", params=params, headers=_auth(), retries=0, quiet=True)
    payload = r.json()
    items = parse_tweets(payload, account)
    newest = ((payload or {}).get("meta") or {}).get("newest_id")
    if newest:
        await asyncio.to_thread(store.kv_set, key, newest)
    return items


async def _poll_rss(url):
    from . import news
    r = await fetch(url, retries=0, quiet=True, headers={"Accept": "application/rss+xml, application/xml, text/xml, */*"})
    acct = (re.search(r"(?:x|twitter|nitter[^/]*|xcancel)\.(?:com|net)/([A-Za-z0-9_]{1,15})", url) or [None, config.X_ACCOUNTS[0] if config.X_ACCOUNTS else "X"])[1]
    items = await cpu.parse(news._parse, label(acct), r.text, ["MARKETS"])
    for it in items:
        it["source"], it["feed"], it["fast"] = label(acct), "X", True
        it["title"] = clean_text(it["title"])
    return [it for it in items if len(it["title"]) >= 8]


async def poll_once():
    """Satu putaran: ambil posting baru semua akun, masukkan ke feed berita. Mengembalikan jumlah item baru."""
    from . import news
    m = mode()
    _state["mode"] = m
    if m == "off" or time.time() < _state["wait_until"]:
        return 0
    got, errs = [], []
    jobs = [(a, _poll_api(a)) for a in config.X_ACCOUNTS] if m == "api" else [(u, _poll_rss(u)) for u in config.X_RSS_URLS]
    for name, coro in jobs:
        try:
            items = await coro
            got += items
            _state["accounts"][name] = dict(ok=True, at=time.time(), n=len(items))
        except Exception as exc:
            code = getattr(getattr(exc, "response", None), "status_code", None) or getattr(exc, "status", None)
            msg = f"{type(exc).__name__}: {str(exc)[:140]}"
            if code == 429:
                _state["wait_until"] = time.time() + _rate_wait(exc)
                msg = "kuota X API habis (429) - menunggu reset"
            elif code in (401, 403):
                _state["wait_until"] = time.time() + 3600
                msg = f"X API menolak token ({code}): periksa X_BEARER_TOKEN / paket API Anda (membaca posting butuh paket berbayar)"
            errs.append(msg)
            _state["accounts"][name] = dict(ok=False, at=time.time(), error=msg)
    _state["polls"] += 1
    added = news.ingest(got) if got else 0
    _state["items"] += added
    if got or not errs:
        _state.update(ok=True, last_ok=time.time(), last_error=errs[0] if errs else None)
    else:
        _state.update(ok=False, last_error=errs[0])
    return added


async def run():
    """Putaran latar: tiap X_POLL_SEC detik (mode API) / 60 dtk (mode RSS). Tidak berjalan bila belum dikonfigurasi."""
    while True:
        try:
            n = await poll_once()
            if n:
                from .. import http as H
                H.bump()                 # klien menyegarkan feed yang terbuka
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            _state.update(ok=False, last_error=f"{type(exc).__name__}: {str(exc)[:140]}")
        await asyncio.sleep(config.X_POLL_SEC if mode() == "api" else 60)


def status():
    s = dict(_state, mode=mode(), accounts_cfg=list(config.X_ACCOUNTS), poll_sec=config.X_POLL_SEC, rss=len(config.X_RSS_URLS))
    s["wait_until"] = s["wait_until"] if s["wait_until"] > time.time() else None
    return s
