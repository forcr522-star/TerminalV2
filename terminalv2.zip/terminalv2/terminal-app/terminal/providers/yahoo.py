import asyncio
import math
import time
import datetime as dt
from urllib.parse import quote as _urlquote
import httpx
import pandas as pd
import numpy as np
import logging
import yfinance as yf
from ..config import UA
from ..http import cached
from ..universe import MONTH_CODES, MONTH_NAMES

# yfinance mencetak setiap simbol gagal ("No data found, symbol may be delisted", "HTTP Error 404 ...") langsung ke
# konsol. Kegagalan sudah ditangani di sini (cadangan Chart API / baris kosong) dan tercatat di menu Status.
logging.getLogger("yfinance").setLevel(logging.CRITICAL)

# Yahoo Chart API dipakai sebagai CADANGAN bila yfinance gagal (crumb kedaluwarsa / 429 setelah terminal
# berjalan lama). Endpoint ini tidak memerlukan cookie/crumb dan memakai rentang standar Yahoo.
_RANGES = {"59d": "2mo", "7d": "1mo", "5d": "5d", "60d": "2mo", "360d": "2y", "1d": "5d", "1mo": "1mo", "1y": "1y", "2y": "2y", "5y": "5y"}


def _chart_frame(symbol, period, interval):
    rng = _RANGES.get(period, period)
    path = f"https://query1.finance.yahoo.com/v8/finance/chart/{_urlquote(symbol, safe='=^-')}"
    last = None
    for host in (path, path.replace("query1.", "query2.")):
        try:
            r = httpx.get(host, params={"range": rng, "interval": interval, "includeAdjustedClose": "false"},
                          headers={"User-Agent": UA, "Accept": "application/json"}, timeout=20.0)
            r.raise_for_status()
            res = ((r.json().get("chart") or {}).get("result") or [None])[0]
            if not res:
                continue
            ts = res.get("timestamp") or []
            q = ((res.get("indicators") or {}).get("quote") or [{}])[0]
            if not ts or not q:
                continue
            idx = pd.to_datetime(ts, unit="s", utc=True).tz_localize(None)
            out = pd.DataFrame({c: q.get(k) for k, c in (("open", "Open"), ("high", "High"), ("low", "Low"), ("close", "Close"), ("volume", "Volume"))}, index=idx)
            out["Volume"] = out["Volume"].fillna(0.0)
            return out.dropna(subset=["Close"])
        except Exception as exc:
            last = exc
    raise last or ValueError(f"chart API kosong untuk {symbol}")


def num(v):
    try:
        f = float(v)
    except Exception:
        return None
    if math.isnan(f) or math.isinf(f):
        return None
    return f


def _frames(df, symbols):
    out = {}
    if df is None or df.empty:
        return out
    if isinstance(df.columns, pd.MultiIndex):
        lv0 = list(df.columns.get_level_values(0).unique())
        lv1 = list(df.columns.get_level_values(1).unique())
        if any(s in lv0 for s in symbols):
            for s in symbols:
                if s in lv0:
                    sub = df[s].dropna(how="all")
                    if not sub.empty:
                        out[s] = sub
        else:
            for s in symbols:
                if s in lv1:
                    sub = df.xs(s, axis=1, level=1).dropna(how="all")
                    if not sub.empty:
                        out[s] = sub
    else:
        if len(symbols) == 1:
            out[symbols[0]] = df.dropna(how="all")
    return out


def _download(symbols, period, interval):
    return yf.download(tickers=list(symbols), period=period, interval=interval, group_by="ticker", auto_adjust=False, progress=False, threads=True)


def _quote_from_frame(f):
    close = f["Close"].dropna()
    if close.empty:
        return None
    price = num(close.iloc[-1])
    prev = num(close.iloc[-2]) if len(close) > 1 else None
    row = f.iloc[-1]
    hi, lo = num(row.get("High")), num(row.get("Low"))
    rng = None
    if hi is not None and lo is not None and hi > lo and price is not None:
        rng = max(0.0, min(1.0, (price - lo) / (hi - lo)))
    tail = close.iloc[-60:]
    z = None
    if len(tail) >= 10 and tail.std() > 0:
        z = num((close.iloc[-1] - tail.mean()) / tail.std())
    chg = (price - prev) if price is not None and prev is not None else None
    pct = (chg / prev * 100) if chg is not None and prev else None
    return dict(price=price, prev=prev, chg=chg, pct=pct, high=hi, low=lo, volume=num(row.get("Volume")), range_pos=rng, z=z,
                spark=[num(x) for x in close.iloc[-30:].tolist()], asof=str(close.index[-1])[:10])


def _quotes_sync(symbols):
    result = {}
    symbols = list(dict.fromkeys(symbols))
    for i in range(0, len(symbols), 50):
        chunk = symbols[i:i + 50]
        try:
            df = _download(chunk, "6mo", "1d")
        except Exception:
            df = None
        got = _frames(df, chunk)
        for s, f in got.items():
            q = _quote_from_frame(f)
            if q:
                result[s] = q
        # yfinance gagal/kosong (crumb basi, 429): ambil lewat Chart API untuk simbol yang belum ada.
        for s in [x for x in chunk if x not in result][:50]:
            try:
                f = _chart_frame(s, "5y", "1d")
                q = _quote_from_frame(f) if f is not None and len(f) else None
                if q:
                    result[s] = q
            except Exception:
                break
    return result


# ------------------------------------------------------------------ cadangan bila Yahoo sesekali gagal (429 / crumb basi)
# 1) Yield Treasury AS punya seri harian resmi di FRED (persen, sama dengan ^IRX/^FVX/^TNX/^TYX Yahoo).
FRED_FALLBACK = {"^IRX": "DTB3", "^FVX": "DGS5", "^TNX": "DGS10", "^TYX": "DGS30"}
# 2) Harga TERAKHIR yang valid per simbol (bukan angka rekaan): dipakai maks. LAST_MAX_AGE detik dan ditandai stale=True
#    beserta tanggal 'asof'-nya, supaya tabel tidak berisi "—" hanya karena satu permintaan gagal.
LAST_KEY = "yahoo_last_quotes"
LAST_MAX_AGE = 5 * 86400
_last = None
_last_saved = 0.0


def quote_from_rows(rows):
    """[(tanggal, nilai)] harian -> bentuk quote yang sama dengan Yahoo (dipakai cadangan FRED)."""
    rows = [r for r in rows if r[1] is not None][-60:]
    if not rows:
        return None
    vals = [v for _, v in rows]
    price, prev = vals[-1], (vals[-2] if len(vals) > 1 else None)
    chg = price - prev if prev is not None else None
    tail = vals[-60:]
    sd = float(np.std(tail)) if len(tail) >= 10 else 0.0
    return dict(price=price, prev=prev, chg=chg, pct=(chg / prev * 100) if chg is not None and prev else None, high=None, low=None,
                volume=None, range_pos=None, z=(price - float(np.mean(tail))) / sd if sd > 0 else None, spark=vals[-30:], asof=rows[-1][0])


async def _fill_missing(res, missing):
    global _last, _last_saved
    from .. import store
    from . import fred
    bonds = [s for s in missing if s in FRED_FALLBACK]
    if bonds:
        got = await asyncio.gather(*[fred.series(FRED_FALLBACK[s], start=str(dt.date.today().year - 1) + "-01-01") for s in bonds], return_exceptions=True)
        for s, rows in zip(bonds, got):
            q = quote_from_rows(rows) if not isinstance(rows, Exception) else None
            if q:
                res[s] = dict(q, src="FRED")
    if _last is None:
        _last = await asyncio.to_thread(store.kv_get, LAST_KEY, {}) or {}
    now = time.time()
    for s in missing:
        old = _last.get(s)
        if s not in res and old and now - old.get("_at", 0) <= LAST_MAX_AGE:
            res[s] = dict({k: v for k, v in old.items() if k != "_at"}, stale=True)


async def _remember(res):
    global _last, _last_saved
    from .. import store
    if _last is None:
        _last = await asyncio.to_thread(store.kv_get, LAST_KEY, {}) or {}
    now = time.time()
    for s, q in res.items():
        if q and not q.get("stale"):
            _last[s] = dict(q, _at=now)
    if now - _last_saved > 300:              # tulis ke DB paling sering tiap 5 menit, di thread (tidak menahan server)
        _last_saved = now
        snap = dict(_last)
        await asyncio.to_thread(store.kv_set, LAST_KEY, snap)


@cached(60)
async def quotes(symbols):
    res = await asyncio.to_thread(_quotes_sync, tuple(symbols))
    if res:
        try:
            await _remember(res)
        except Exception:
            pass
    missing = [s for s in dict.fromkeys(symbols) if s not in res]
    if missing:
        try:
            await _fill_missing(res, missing)
        except Exception:
            pass
    return res


PERIODS = {
    "1D": ("1d", "5m"), "5D": ("5d", "15m"), "1M": ("1mo", "1d"), "3M": ("3mo", "1d"), "6M": ("6mo", "1d"),
    "1Y": ("1y", "1d"), "5Y": ("5y", "1wk"), "ALL": ("max", "1mo"),
}


def _history_sync(symbol, period, interval):
    try:
        df = yf.Ticker(symbol).history(period=period, interval=interval, auto_adjust=False)
    except Exception:
        df = None
    if df is None or df.empty:
        df = _chart_frame(symbol, period, interval)
    if df is None or df.empty:
        return []
    rows = []
    for ts, r in df.iterrows():
        c = num(r.get("Close"))
        if c is None:
            continue
        t = ts.to_pydatetime()
        rows.append(dict(t=int(t.timestamp() * 1000), d=t.strftime("%Y-%m-%d"), o=num(r.get("Open")), h=num(r.get("High")), l=num(r.get("Low")), c=c, v=num(r.get("Volume")) or 0))
    return rows


@cached(180)
async def history(symbol, rng="1Y"):
    period, interval = PERIODS.get(rng, PERIODS["1Y"])
    return await asyncio.to_thread(_history_sync, symbol, period, interval)


def _ohlcv_sync(symbol, period, interval):
    """OHLCV mentah untuk menu SIGNAL: DataFrame kolom o,h,l,c,v, indeks UTC tanpa zona waktu."""
    df = None
    try:
        df = yf.Ticker(symbol).history(period=period, interval=interval, auto_adjust=False)
    except Exception:
        df = None
    if df is None or df.empty:
        df = _chart_frame(symbol, period, interval)     # cadangan: tanpa cookie/crumb
    if df is None or df.empty:
        return None
    idx = df.index
    if getattr(idx, "tz", None) is not None:
        idx = idx.tz_convert("UTC").tz_localize(None)
    out = pd.DataFrame({"o": df["Open"].values, "h": df["High"].values, "l": df["Low"].values, "c": df["Close"].values,
                        "v": df["Volume"].values if "Volume" in df else 0.0}, index=idx)
    return out.dropna(subset=["c"])


@cached(45)
async def ohlcv(symbol, period, interval):
    return await asyncio.to_thread(_ohlcv_sync, symbol, period, interval)


@cached(10, stale_ok=0)
async def live_ohlcv(symbol, period, interval):
    """OHLCV untuk chart live (menu SIGNAL): cache sangat singkat (10 dtk), data basi tidak pernah dikembalikan bila sumber sehat."""
    return await asyncio.to_thread(_ohlcv_sync, symbol, period, interval)


def _series_sync(symbols, period="2y"):
    df = _download(symbols, period, "1d")
    out = {}
    for s, f in _frames(df, list(symbols)).items():
        c = f["Close"].dropna()
        if len(c) > 5:
            out[s] = c
    return out


@cached(900)
async def closes(symbols, period="2y"):
    data = await asyncio.to_thread(_series_sync, tuple(symbols), period)
    return data


def _stmt(df, max_cols=5):
    if df is None or getattr(df, "empty", True):
        return dict(cols=[], rows=[])
    cols = list(df.columns)[:max_cols]
    cols = sorted(cols)
    rows = []
    for metric in df.index:
        vals = [num(df.loc[metric, c]) for c in cols]
        if all(v is None for v in vals):
            continue
        last, prev = vals[-1], None
        basis = "qoq"
        if len(vals) >= 5 and vals[0] not in (None, 0):
            prev = vals[0]
            basis = "yoy"
        elif len(vals) >= 2:
            prev = vals[-2]
        chg = None
        if last is not None and prev not in (None, 0):
            chg = (last - prev) / abs(prev) * 100
        rows.append(dict(metric=str(metric), values=vals, change=chg, basis=basis))
    labels = [pd.Timestamp(c).strftime("%b %Y") for c in cols]
    return dict(cols=labels, rows=rows)


def _financials_sync(ticker):
    t = yf.Ticker(ticker)
    try:
        info = t.get_info() or {}
    except Exception:
        info = {}
    def safe(attr):
        try:
            return getattr(t, attr)
        except Exception:
            return None
    inc, bal, cf = safe("quarterly_income_stmt"), safe("quarterly_balance_sheet"), safe("quarterly_cashflow")
    ins = safe("insider_transactions")
    insiders = []
    if ins is not None and not getattr(ins, "empty", True):
        for _, r in ins.head(12).iterrows():
            insiders.append(dict(name=str(r.get("Insider", "")), position=str(r.get("Position", "")), text=str(r.get("Text", ""))[:80],
                                 shares=num(r.get("Shares")), value=num(r.get("Value")), date=str(r.get("Start Date", ""))[:10]))
    px = []
    try:
        h = t.history(period="1y", interval="1d")
        px = [dict(t=int(i.timestamp() * 1000), c=num(r["Close"])) for i, r in h.iterrows() if num(r["Close"]) is not None]
    except Exception:
        pass
    income = _stmt(inc)
    chart = dict(cols=income["cols"], revenue=[], net=[])
    for r in income["rows"]:
        if r["metric"] == "Total Revenue":
            chart["revenue"] = r["values"]
        if r["metric"] == "Net Income":
            chart["net"] = r["values"]
    return dict(
        ticker=ticker,
        profile=dict(name=info.get("longName") or info.get("shortName") or ticker, summary=info.get("longBusinessSummary", ""), sector=info.get("sector", ""),
                     industry=info.get("industry", ""), currency=info.get("currency", ""), country=info.get("country", "")),
        metrics=dict(market_cap=num(info.get("marketCap")), ev=num(info.get("enterpriseValue")), pe=num(info.get("trailingPE")), pb=num(info.get("priceToBook")),
                     insiders=num(info.get("heldPercentInsiders")), institutions=num(info.get("heldPercentInstitutions")), eps=num(info.get("trailingEps")),
                     price=num(info.get("currentPrice") or info.get("regularMarketPrice"))),
        analyst=dict(target=num(info.get("targetMeanPrice")), low=num(info.get("targetLowPrice")), high=num(info.get("targetHighPrice")),
                     rec=str(info.get("recommendationKey", "")).replace("_", " ").upper(), count=num(info.get("numberOfAnalystOpinions"))),
        insiders=insiders, income=income, balance=_stmt(bal), cashflow=_stmt(cf), chart=chart, price=px,
    )


@cached(900)
async def financials(ticker):
    return await asyncio.to_thread(_financials_sync, ticker)


def _holdings_sync(etf):
    t = yf.Ticker(etf)
    try:
        fd = t.funds_data
        top = fd.top_holdings
    except Exception:
        return []
    out = []
    if top is None or getattr(top, "empty", True):
        return out
    for sym, r in top.iterrows():
        pct = num(r.get("Holding Percent"))
        out.append(dict(symbol=str(sym), name=str(r.get("Name", sym)), weight=(pct * 100 if pct is not None and pct <= 1 else pct)))
    return out


@cached(3600)
async def etf_holdings(etf):
    return await asyncio.to_thread(_holdings_sync, etf)


# Bulan kontrak yang benar-benar terdaftar per produk (siklus CME/ICE). Dulu SEMUA 12 bulan dibuat, mulai bulan berjalan:
# kontrak bulan ini sering sudah kedaluwarsa (mis. CLX26 di bulan November) dan bulan di luar siklus (ZBQ27, YMK27, ...)
# tidak pernah ada -> puluhan permintaan sia-sia + "symbol may be delisted" di konsol.
CYCLES = {"GC": "GJMQVZ", "SI": "FHKNUZ", "HG": "HKNUZ", "KC": "HKNUZ", "CC": "HKNUZ", "CT": "HKNVZ", "SB": "HKNV",
          "ZC": "HKNUZ", "ZS": "FHKNQUX", "ZW": "HKNUZ", "ES": "HMUZ", "NQ": "HMUZ", "YM": "HMUZ", "RTY": "HMUZ",
          "6E": "HMUZ", "6J": "HMUZ", "6B": "HMUZ", "6A": "HMUZ", "6C": "HMUZ", "6S": "HMUZ", "6N": "HMUZ",
          "ZN": "HMUZ", "ZB": "HMUZ", "ZF": "HMUZ", "ZT": "HMUZ"}


def futures_symbols(root, exch, n=None, today=None):
    """Kontrak berikutnya (mulai bulan depan) yang ada di siklus produk; bulanan (CL, NG, ...) = semua bulan."""
    today = today or dt.date.today()
    cyc = CYCLES.get(root, MONTH_CODES)
    n = n or (12 if len(cyc) == 12 else min(8, 2 * len(cyc)))
    y, m = today.year, today.month
    out = []
    for i in range(1, 37):
        mm = (m - 1 + i) % 12
        yy = y + (m - 1 + i) // 12
        if MONTH_CODES[mm] in cyc:
            out.append((f"{MONTH_NAMES[mm]} {str(yy)[2:]}", f"{root}{MONTH_CODES[mm]}{str(yy)[2:]}.{exch}"))
            if len(out) >= n:
                break
    return out


@cached(300)
async def futures_curve(root, exch):
    pairs = futures_symbols(root, exch)
    syms = [p[1] for p in pairs] + [f"{root}=F"]
    q = await quotes(tuple(syms))
    rows = []
    cash = q.get(f"{root}=F")
    if cash:
        rows.append(dict(label="Cash", symbol=f"{root}=F", price=cash["price"], chg=cash["chg"], pct=cash["pct"], volume=cash["volume"]))
    for label, s in pairs:
        v = q.get(s)
        if v:
            rows.append(dict(label=label, symbol=s, price=v["price"], chg=v["chg"], pct=v["pct"], volume=v["volume"]))
    return rows
