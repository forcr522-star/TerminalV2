"""Layer AIRPLANE globe: pesawat MILITER real-time dari jaringan ADS-B terbuka adsb.lol (gratis, tanpa key, data ODbL).

Batas gratis adsb.lol: 500 permintaan per hari per IP (header `x-ratelimit-limit: 500;w=86400`). Karena itu pesawat
militer diambil paling sering tiap AIR_POLL_SEC (bawaan 240 dtk = ±360/hari) dan squawk darurat 7700 sipil tiap
20 menit (±72/hari), HANYA saat layer AIRPLANE dibuka, dan satu hasil dipakai bersama semua pengguna. Posisi yang ditampilkan = posisi terakhir yang dilaporkan pesawat (umurnya
ditulis), tanpa perkiraan/ekstrapolasi.
"""
import os

from ..http import get_json, cached
from .. import health

URL = "https://api.adsb.lol/v2/mil"
POLL_SEC = max(120, int(os.getenv("AIR_POLL_SEC", "240") or 240))
SQK_URL = "https://api.adsb.lol/v2/sqk/7700"
health.mark_optional("api.adsb.lol")

# kode tipe ICAO -> peran (hanya tipe yang jelas; sisanya OTHER)
ROLE = {}
for role, codes in {
    "ISR": "R135 E3TF E3CF E6 E7 E8 P8 P3 Q4 U2 EP3 RC12 GLEX E2 E767 SB39 C26 MC12 Q9 MQ9 H25B",
    "TANKER": "K35R K35E KC10 DC10 A332 A339 B762 B763 A310 K46 KC2 IL78",
    "BOMBER": "B52 B1 B2 TU95 T160 TU22 H6",
    "TRANSPORT": "C17 C5 C5M A400 C30J C130 C27J C295 CN35 C2 Y20 IL76 AN12 AN26 A124 C160 BE20 B350 C12 DHC6 L410 C560 GLF4 GLF5 GLF6 F900 CL60 B737 B738 B736 A319 A320 A321 B752 B744 B748",
    "FIGHTER": "F16 F15 F18 F18S F35 EUFI RFAL GRPN TOR F22 F5 SU27 SU30 SU35 MG29 J10 AJET M2000",
    "TRAINER": "T38 TEX2 PC21 PC9 PC7 HAWK T6 M346 L39 G120 SR22 T45 K8 KT1",
    "HELICOPTER": "H60 H47 H64 H53 EC45 EC35 EC25 MI8 MI17 MI24 NH90 A139 A169 LYNX PUMA AS32 AS65 H1 UH1 B412 V22 TIGR",
}.items():
    for c in codes.split():
        ROLE.setdefault(c, role)

# kawasan pantauan geopolitik (s, w, n, e)
REGIONS = [
    ("Black Sea", (40.5, 27.0, 47.5, 42.0)), ("Baltic", (53.5, 9.0, 66.0, 31.0)), ("Poland / Ukraine border", (48.0, 21.0, 54.5, 25.5)),
    ("Eastern Mediterranean", (30.0, 25.0, 38.0, 37.0)), ("Persian Gulf", (23.0, 47.0, 31.0, 57.5)), ("Red Sea / Gulf of Aden", (11.0, 32.0, 28.0, 51.0)),
    ("Taiwan Strait", (21.5, 116.0, 26.5, 123.0)), ("South China Sea", (3.0, 105.0, 21.5, 121.0)), ("Korea / Sea of Japan", (33.0, 124.0, 43.0, 136.0)),
    ("Arctic / High North", (66.0, -30.0, 80.0, 60.0)),
]


def role_of(t):
    return ROLE.get(str(t or "").upper(), "OTHER")


def _alt(v):
    if v == "ground":
        return 0
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


@cached(POLL_SEC, stale_ok=1800)
async def military():
    j = await get_json(URL, retries=1, quiet=True)
    now = (j.get("now") or 0) / 1000
    out = []
    for a in j.get("ac") or []:
        lat, lon = a.get("lat"), a.get("lon")
        seen = a.get("seen_pos", a.get("seen"))
        if lat is None or lon is None or (seen is not None and seen > 300):
            continue                                           # tanpa posisi / posisi lebih tua dari 5 menit
        t = str(a.get("t") or "").upper() or None
        sq = str(a.get("squawk") or "") or None
        out.append(dict(hex=a.get("hex"), cs=(a.get("flight") or "").strip() or None, reg=a.get("r"), type=t, role=role_of(t),
                        lat=round(lat, 4), lon=round(lon, 4), alt=_alt(a.get("alt_baro")), gs=a.get("gs"), trk=a.get("track"),
                        sqk=sq, emergency=sq in ("7500", "7600", "7700"), seen=round(seen or 0, 1)))
    roles = {}
    for x in out:
        roles[x["role"]] = roles.get(x["role"], 0) + 1
    regions = []
    for name, (s, w, n, e) in REGIONS:
        inside = [x for x in out if s <= x["lat"] <= n and w <= x["lon"] <= e]
        if inside:
            rr = {}
            for x in inside:
                rr[x["role"]] = rr.get(x["role"], 0) + 1
            regions.append(dict(name=name, count=len(inside), roles=rr, lat=(s + n) / 2, lon=(w + e) / 2))
    regions.sort(key=lambda r: -r["count"])
    return dict(ts=now, aircraft=out, total=len(out), roles=roles, regions=regions, emergencies=[x for x in out if x["emergency"]],
                source="adsb.lol (ODbL)", poll_sec=POLL_SEC)


@cached(1200, stale_ok=3 * 3600)
async def emergencies():
    """Semua pesawat (sipil & militer) yang memancarkan squawk 7700 (darurat umum) saat ini."""
    j = await get_json(SQK_URL, retries=1, quiet=True)
    out = []
    for a in j.get("ac") or []:
        if a.get("lat") is None or a.get("lon") is None:
            continue
        t = str(a.get("t") or "").upper() or None
        out.append(dict(hex=a.get("hex"), cs=(a.get("flight") or "").strip() or None, reg=a.get("r"), type=t, role=role_of(t), lat=round(a["lat"], 4),
                        lon=round(a["lon"], 4), alt=_alt(a.get("alt_baro")), gs=a.get("gs"), trk=a.get("track"), sqk="7700", emergency=True,
                        seen=round(a.get("seen_pos", a.get("seen")) or 0, 1), civil=not (a.get("dbFlags") or 0) & 1))
    return out


async def layer():
    """Layer AIRPLANE lengkap: militer + darurat 7700 + jumlah pesawat militer per negara (wilayah udara) + berita penerbangan."""
    try:
        d = dict(await military())
        err = None
    except Exception as exc:
        d, err = dict(aircraft=[], total=0, roles={}, regions=[], emergencies=[], ts=None, source="adsb.lol (ODbL)", poll_sec=POLL_SEC), type(exc).__name__
    try:
        em = await emergencies()
    except Exception:
        em = []
    seen = {a["hex"] for a in d["emergencies"]}
    d["emergencies"] = d["emergencies"] + [a for a in em if a["hex"] not in seen]
    from .. import cpu
    by_c, news = await cpu.run(_by_country, d["aircraft"])    # ratusan pencarian poligon + regex berita: bukan di event loop
    d.update(countries=by_c, news=news, error=err)
    return d


def _by_country(aircraft):
    """(jumlah pesawat militer per negara wilayah udara, berita penerbangan)."""
    from . import geo
    by_c = {}
    for a in aircraft:
        c = geo.country_at(a["lat"], a["lon"])
        if c:
            r = by_c.setdefault(c, dict(count=0, roles={}))
            r["count"] += 1
            r["roles"][a["role"]] = r["roles"].get(a["role"], 0) + 1
    return by_c, geo.aviation_events()
