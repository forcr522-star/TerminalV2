import io
import pandas as pd
from .. import cpu
from ..http import fetch, cached

URL = "https://www.matteoiacoviello.com/ai_gpr_files/ai_gpr_data_daily.csv"


def level(v):
    if v is None:
        return "N/A"
    if v >= 150:
        return "EXTREME"
    if v >= 120:
        return "HIGH"
    if v >= 90:
        return "ELEVATED"
    return "MODERATE"


@cached(6 * 3600, persist=True, stale_ok=30 * 86400)
async def daily():
    r = await fetch(URL)
    df = await cpu.parse(pd.read_csv, io.StringIO(r.text))
    cols = {c.lower(): c for c in df.columns}
    dcol = next((cols[c] for c in cols if "date" in c or c == "day"), df.columns[0])
    vcol = None
    for cand in ("gpr_ai", "ai_gpr", "gpr_ai_daily", "gpr"):
        if cand in cols:
            vcol = cols[cand]
            break
    if vcol is None:
        vcol = next(c for c in df.columns if c != dcol and pd.api.types.is_numeric_dtype(df[c]))
    df[dcol] = pd.to_datetime(df[dcol], errors="coerce")
    df = df.dropna(subset=[dcol, vcol]).sort_values(dcol)
    s = df.set_index(dcol)[vcol].astype(float)
    tail = s.iloc[-400:]
    last = float(s.iloc[-1])
    prev = float(s.iloc[-2]) if len(s) > 1 else last
    return dict(
        latest=last, change=last - prev, change_pct=(last - prev) / prev * 100 if prev else 0, level=level(last), asof=str(s.index[-1])[:10],
        avg30=float(s.iloc[-30:].mean()), avg90=float(s.iloc[-90:].mean()), hi180=float(s.iloc[-180:].max()), lo180=float(s.iloc[-180:].min()),
        series=[dict(d=str(i)[:10], v=round(float(v), 2)) for i, v in tail.items()],
    )
