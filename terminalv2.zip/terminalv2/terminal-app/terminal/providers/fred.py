import asyncio
import io
import pandas as pd
from ..http import fetch, cached

BASE = "https://fred.stlouisfed.org/graph/fredgraph.csv"
TXT = "https://fred.stlouisfed.org/data/{sid}.txt"
_sem = None


def _limit():
    # FRED menolak/menunda banyak permintaan paralel; batasi agar tidak kena 429.
    global _sem
    if _sem is None:
        _sem = asyncio.Semaphore(4)
    return _sem


def parse_csv(text, sid=""):
    df = pd.read_csv(io.StringIO(text))
    if df.shape[1] < 2:
        raise ValueError(f"FRED kosong {sid}")
    df = df.iloc[:, :2]
    df.columns = ["date", "value"]
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    df = df.dropna()
    return [(d.strftime("%Y-%m-%d"), float(v)) for d, v in zip(df["date"], df["value"])]


def parse_txt(text):
    rows, on = [], False
    for line in text.splitlines():
        if line.strip().upper().startswith("DATE"):
            on = True
            continue
        if not on:
            continue
        parts = line.split()
        if len(parts) >= 2:
            try:
                rows.append((parts[0], float(parts[1])))
            except ValueError:
                continue
    return rows


@cached(1800, persist=True, stale_ok=30 * 86400)
async def series(sid, start=None):
    params = {"id": sid}
    if start:
        params["cosd"] = start
    async with _limit():
        try:
            r = await fetch(BASE, params=params)
            rows = parse_csv(r.text, sid)
        except Exception as first:
            try:
                r = await fetch(TXT.format(sid=sid), retries=1)
                rows = parse_txt(r.text)
                if start:
                    rows = [x for x in rows if x[0] >= start]
            except Exception:
                raise first
    if not rows:
        raise ValueError(f"FRED kosong {sid}")
    return rows


async def many(ids, start=None):
    res = await asyncio.gather(*[series(i, start) for i in ids], return_exceptions=True)
    return {i: (r if not isinstance(r, Exception) else []) for i, r in zip(ids, res)}


def last(rows, n=1):
    return rows[-n:] if rows else []
