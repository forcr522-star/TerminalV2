import asyncio
import io
import pandas as pd
from ..http import fetch, cached

BASE = "https://fred.stlouisfed.org/graph/fredgraph.csv"
# FRED (Akamai) MENAHAN permintaan yang mengaku browser Chrome tetapi sidik jari TLS-nya bukan Chrome: koneksi digantung
# sampai timeout (terlihat sebagai "FRED bermasalah"). Klien yang jujur menyebut dirinya program dijawab < 1 dtk.
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; TerminalV2/2.0; macro data client)", "Accept": "text/csv, text/plain, */*;q=0.8"}
_sem = None


def _limit():
    # FRED menolak/menunda banyak permintaan paralel; batasi agar tidak kena 429.
    global _sem
    if _sem is None:
        _sem = asyncio.Semaphore(4)
    return _sem


def parse_csv(text, sid=""):
    df = pd.read_csv(io.StringIO(text))
    if df.shape[1] < 2:
        raise ValueError(f"FRED kosong {sid}")
    df = df.iloc[:, :2]
    df.columns = ["date", "value"]
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    df = df.dropna()
    return [(d.strftime("%Y-%m-%d"), float(v)) for d, v in zip(df["date"], df["value"])]


@cached(1800, persist=True, stale_ok=30 * 86400)
async def series(sid, start=None):
    params = {"id": sid}
    if start:
        params["cosd"] = start
    async with _limit():
        # Jalur lama /data/<id>.txt sudah dihapus FRED (selalu 404) - tidak dipakai lagi.
        r = await fetch(BASE, params=params, headers=HEADERS, retries=1)
        rows = await asyncio.to_thread(parse_csv, r.text, sid)
    if not rows:
        raise ValueError(f"FRED kosong {sid}")
    return rows


async def many(ids, start=None):
    res = await asyncio.gather(*[series(i, start) for i in ids], return_exceptions=True)
    return {i: (r if not isinstance(r, Exception) else []) for i, r in zip(ids, res)}


def last(rows, n=1):
    return rows[-n:] if rows else []
