import asyncio
import json
import time
from ..config import AISSTREAM_API_KEY
from ..http import get_json

DIGITRAFFIC = "https://meri.digitraffic.fi/api/ais/v1"
DIGI_HEADERS = {"Digitraffic-User": "terminal-miniapp/1.0", "Accept-Encoding": "gzip"}
_v = {}
_state = dict(connected=False, error=None, msgs=0, last=0, digi_ok=False, digi_error=None, digi_last=0)
MAX = 9000


def enabled():
    return True


def global_enabled():
    return bool(AISSTREAM_API_KEY)


def _kind(t):
    if t is None:
        return "other"
    t = int(t)
    if 80 <= t <= 89:
        return "tanker"
    if 70 <= t <= 79:
        return "cargo"
    if 60 <= t <= 69:
        return "passenger"
    if t == 30:
        return "fishing"
    if t in (31, 32, 52):
        return "tug"
    if 35 <= t <= 36 or t in (50, 51, 53, 55):
        return "service"
    return "other"


def _handle(msg):
    mt = msg.get("MessageType")
    meta = msg.get("MetaData", {})
    mmsi = meta.get("MMSI")
    if not mmsi:
        return
    cur = _v.get(mmsi)
    if mt == "PositionReport":
        pr = msg.get("Message", {}).get("PositionReport", {})
        lat, lon = pr.get("Latitude", meta.get("latitude")), pr.get("Longitude", meta.get("longitude"))
        if lat is None or lon is None:
            return
        hd = pr.get("TrueHeading")
        cog = pr.get("Cog", 0)
        rec = cur or dict(kind="other", name="")
        rec.update(lat=lat, lon=lon, cog=hd if hd is not None and hd < 360 else cog, sog=pr.get("Sog", 0), ts=time.time())
        nm = (meta.get("ShipName") or "").strip()
        if nm:
            rec["name"] = nm
        if len(_v) < MAX or cur:
            _v[mmsi] = rec
        _state["msgs"] += 1
        _state["last"] = time.time()
    elif mt == "ShipStaticData":
        st = msg.get("Message", {}).get("ShipStaticData", {})
        if cur is not None:
            cur["kind"] = _kind(st.get("Type"))
            nm = (st.get("Name") or "").strip()
            if nm:
                cur["name"] = nm
            cur["dest"] = (st.get("Destination") or "").strip()


def _prune():
    cutoff = time.time() - 1800
    for k in [k for k, r in _v.items() if r["ts"] < cutoff]:
        _v.pop(k, None)


def _digi_apply(locations, meta):
    n = 0
    for f in locations.get("features", []):
        try:
            p = f.get("properties", {})
            mmsi = f.get("mmsi") or p.get("mmsi")
            lon, lat = f["geometry"]["coordinates"][:2]
        except Exception:
            continue
        if mmsi is None or lat is None or lon is None:
            continue
        ts = (p.get("timestampExternal") or 0) / 1000 or time.time()
        if time.time() - ts > 1800:
            continue
        hd = p.get("heading")
        cog = p.get("cog", 0)
        m = meta.get(mmsi) or {}
        rec = _v.get(mmsi) or dict(kind="other", name="")
        rec.update(lat=lat, lon=lon, cog=hd if hd is not None and hd < 360 else (cog if cog is not None and cog < 360 else 0), sog=p.get("sog") or 0, ts=ts, src="digitraffic")
        if m:
            rec["kind"] = _kind(m.get("shipType"))
            rec["name"] = (m.get("name") or rec.get("name") or "").strip()
            rec["dest"] = (m.get("destination") or "").strip()
        if len(_v) < MAX or mmsi in _v:
            _v[mmsi] = rec
            n += 1
    return n


async def run_digitraffic():
    meta = {}
    meta_ts = 0
    while True:
        try:
            if time.time() - meta_ts > 1800:
                vs = await get_json(f"{DIGITRAFFIC}/vessels", headers=DIGI_HEADERS, retries=1)
                if isinstance(vs, list):
                    meta = {v.get("mmsi"): v for v in vs if v.get("mmsi") is not None}
                    meta_ts = time.time()
            loc = await get_json(f"{DIGITRAFFIC}/locations", headers=DIGI_HEADERS, retries=1)
            _digi_apply(loc, meta)
            _state["digi_ok"], _state["digi_error"], _state["digi_last"] = True, None, time.time()
            _prune()
        except Exception as exc:
            _state["digi_ok"] = False
            _state["digi_error"] = str(exc)[:140]
        await asyncio.sleep(60)


async def run():
    tasks = [asyncio.create_task(run_digitraffic())]
    if global_enabled():
        tasks.append(asyncio.create_task(run_aisstream()))
    await asyncio.gather(*tasks)


async def run_aisstream():
    import websockets
    backoff = 3
    while True:
        try:
            async with websockets.connect("wss://stream.aisstream.io/v0/stream", max_size=2 ** 22, ping_interval=20) as ws:
                await ws.send(json.dumps({"APIKey": AISSTREAM_API_KEY, "BoundingBoxes": [[[-90, -180], [90, 180]]], "FilterMessageTypes": ["PositionReport", "ShipStaticData"]}))
                _state["connected"], _state["error"] = True, None
                backoff = 3
                n = 0
                async for raw in ws:
                    try:
                        _handle(json.loads(raw))
                    except Exception:
                        continue
                    n += 1
                    if n % 2000 == 0:
                        _prune()
                        await asyncio.sleep(0)
        except Exception as exc:
            _state["connected"] = False
            _state["error"] = str(exc)[:140]
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 120)


def vessels():
    return [(r["lat"], r["lon"]) for r in _v.values()]


def snapshot(bounds=None, limit=3500):
    out = []
    for mmsi, r in _v.items():
        if bounds:
            s, w, n, e = bounds
            if not (s <= r["lat"] <= n and w <= r["lon"] <= e):
                continue
        out.append([round(r["lat"], 4), round(r["lon"], 4), round(r.get("cog") or 0), round(r.get("sog") or 0, 1), r.get("kind", "other"), r.get("name", ""), mmsi])
        if len(out) >= limit:
            break
    return out


def status():
    kinds = {}
    for r in _v.values():
        kinds[r.get("kind", "other")] = kinds.get(r.get("kind", "other"), 0) + 1
    return dict(enabled=True, connected=_state["connected"] or _state["digi_ok"], error=_state["error"] if global_enabled() else _state["digi_error"], vessels=len(_v), kinds=kinds, last=max(_state["last"], _state["digi_last"]),
                sources=dict(digitraffic=_state["digi_ok"], aisstream=_state["connected"], aisstream_configured=global_enabled()), coverage="GLOBAL" if _state["connected"] else "BALTIC / N. EUROPE")
