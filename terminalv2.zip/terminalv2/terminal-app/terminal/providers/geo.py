import json
import math
import re
import time
from ..config import WEB_DIR
from ..http import get_json, cached
from ..universe import CHOKEPOINTS
from .. import health
from . import news as N
from . import ais as A
from . import gdelt as G


PLACES = {
    "ukraine": (49.0, 31.4), "kyiv": (50.45, 30.52), "kharkiv": (49.99, 36.23), "odesa": (46.48, 30.73), "russia": (61.5, 105.3), "moscow": (55.75, 37.62), "crimea": (45.3, 34.4),
    "belarus": (53.7, 27.9), "poland": (52.1, 19.4), "germany": (51.2, 10.4), "france": (46.6, 2.5), "paris": (48.85, 2.35), "uk": (54.0, -2.5), "britain": (54.0, -2.5), "london": (51.5, -0.12),
    "spain": (40.4, -3.7), "italy": (42.8, 12.5), "greece": (39.0, 22.0), "serbia": (44.0, 21.0), "kosovo": (42.6, 20.9), "turkey": (39.0, 35.2), "hungary": (47.2, 19.5), "sweden": (62.0, 15.0), "belgium": (50.6, 4.6),
    "israel": (31.0, 34.9), "gaza": (31.4, 34.3), "west bank": (32.0, 35.3), "lebanon": (33.9, 35.9), "beirut": (33.89, 35.5), "syria": (34.8, 38.9), "iran": (32.4, 53.7), "tehran": (35.7, 51.4), "iraq": (33.2, 43.7),
    "yemen": (15.5, 47.6), "houthi": (15.4, 44.2), "saudi": (24.0, 45.0), "jordan": (31.2, 36.5), "qatar": (25.3, 51.2), "uae": (24.3, 54.4), "oman": (21.5, 55.9), "kuwait": (29.3, 47.5), "egypt": (26.8, 30.8), "libya": (27.0, 17.0),
    "sudan": (15.6, 30.2), "south sudan": (7.0, 30.0), "ethiopia": (9.1, 40.5), "somalia": (5.2, 46.2), "somaliland": (9.6, 44.0), "kenya": (0.0, 37.9), "nigeria": (9.1, 8.7), "mali": (17.6, -4.0), "niger": (17.6, 8.1),
    "burkina": (12.2, -1.6), "congo": (-2.9, 23.7), "drc": (-2.9, 23.7), "uganda": (1.4, 32.3), "south africa": (-30.6, 22.9), "mozambique": (-18.7, 35.5), "zimbabwe": (-19.0, 29.2), "algeria": (28.0, 1.7), "morocco": (31.8, -7.1),
    "afghanistan": (33.9, 67.7), "pakistan": (30.4, 69.3), "india": (21.0, 78.0), "kashmir": (34.0, 76.0), "bangladesh": (23.7, 90.4), "myanmar": (21.9, 95.9), "china": (35.0, 103.0), "beijing": (39.9, 116.4), "taiwan": (23.7, 121.0),
    "hong kong": (22.3, 114.2), "north korea": (40.3, 127.5), "south korea": (36.5, 127.9), "japan": (36.2, 138.3), "philippines": (12.9, 121.8), "vietnam": (14.1, 108.3), "thailand": (15.9, 100.9), "cambodia": (12.6, 104.9),
    "indonesia": (-2.5, 118.0), "jakarta": (-6.2, 106.8), "malaysia": (4.2, 102.0), "singapore": (1.35, 103.8), "australia": (-25.3, 133.8), "new zealand": (-41.0, 174.0), "papua": (-6.3, 143.9),
    "usa": (39.8, -98.6), "u.s.": (39.8, -98.6), "united states": (39.8, -98.6), "washington": (38.9, -77.0), "canada": (56.1, -106.3), "mexico": (23.6, -102.5), "cuba": (21.5, -77.8), "venezuela": (6.4, -66.6), "colombia": (4.6, -74.1),
    "brazil": (-14.2, -51.9), "argentina": (-38.4, -63.6), "chile": (-35.7, -71.5), "peru": (-9.2, -75.0), "ecuador": (-1.8, -78.2), "haiti": (18.9, -72.3), "panama": (8.5, -80.8), "bolivia": (-16.3, -63.6),
    "kazakhstan": (48.0, 66.9), "armenia": (40.1, 45.0), "azerbaijan": (40.1, 47.6), "georgia": (42.3, 43.4), "ireland": (53.4, -8.2), "norway": (60.5, 8.5), "finland": (61.9, 25.7), "denmark": (56.3, 9.5), "netherlands": (52.1, 5.3),
    "switzerland": (46.8, 8.2), "austria": (47.5, 14.6), "romania": (45.9, 25.0), "bulgaria": (42.7, 25.5), "moldova": (47.4, 28.4), "tunisia": (33.9, 9.5), "ghana": (7.9, -1.0), "senegal": (14.5, -14.5), "cameroon": (7.4, 12.4),
    "angola": (-11.2, 17.9), "tanzania": (-6.4, 34.9), "nepal": (28.4, 84.1), "sri lanka": (7.9, 80.8), "mongolia": (46.9, 103.8), "laos": (19.9, 102.5), "jordan valley": (32.1, 35.5),
}
_PLACE_RE = [(k, re.compile(r"(?<![a-z])" + re.escape(k) + r"(?![a-z])")) for k in sorted(PLACES, key=len, reverse=True)]

SEV_CRIT = ["kill", "dead", "death toll", "massacre", "airstrike", "missile", "explosion", "bomb", "invasion", "assassin", "shelling", "drone strike", "attack"]
CATS = [
    ("ARMED CONFLICT", ["war", "missile", "airstrike", "strike", "attack", "killed", "kills", "shelling", "troops", "drone", "bomb", "offensive", "ceasefire", "clashes"]),
    ("CIVIL UNREST", ["protest", "riot", "demonstrat", "unrest", "strike action", "rally against", "crackdown"]),
    ("SECURITY", ["cyber", "hack", "terror", "hostage", "kidnap", "espionage", "ransomware"]),
    ("GEOPOLITICAL", ["sanction", "diplomat", "talks", "summit", "treaty", "tension", "embargo", "tariff", "election", "nuclear"]),
]


def locate(text):
    t = text.lower()
    for k, rx in _PLACE_RE:
        if rx.search(t):
            return k, PLACES[k]
    return None, None


def locate_one(text):
    """Seperti locate(), tetapi hanya bila teks menyebut tepat SATU tempat yang dikenal (lokasi tidak ambigu)."""
    t = text.lower()
    found, spans = [], []
    for k, rx in _PLACE_RE:                    # kunci terpanjang dulu: "south korea" tidak dihitung lagi sebagai "korea"
        m = rx.search(t)
        if m and not any(a <= m.start() < b for a, b in spans):
            found.append(k)
            spans.append((m.start(), m.end()))
    coords = {PLACES[k] for k in found}
    return (found[0], PLACES[found[0]]) if len(coords) == 1 else (None, None)


def classify(title):
    t = title.lower()
    for name, kws in CATS:
        if any(k in t for k in kws):
            return name
    return None


def severity(title, prio):
    t = title.lower()
    if prio == "CRIT" or any(k in t for k in SEV_CRIT):
        return "CRITICAL"
    if prio == "HIGH":
        return "HIGH"
    return "ACTIVE"


def events(limit=70):
    out = []
    now = time.time()
    seen = set()
    for it in N.all_items(36 * 3600):
        if not ({"GEOPOLITICS", "MIDDLE EAST"} & set(it["cats"])) and it["prio"] != "CRIT":
            continue
        cat = classify(it["title"])
        if not cat:
            continue
        place, ll = locate(it["title"] + " " + it.get("summary", ""))
        if not ll or it["id"] in seen:
            continue
        seen.add(it["id"])
        out.append(dict(id=it["id"], title=it["title"], source=it["source"], link=it["link"], ts=it["ts"], lat=ll[0], lon=ll[1], place=place.title(), cat=cat, sev=severity(it["title"], it["prio"])))
        if len(out) >= limit:
            break
    return out


def chokepoints():
    items = N.all_items(24 * 3600)
    vessels = A.vessels()
    out = []
    for c in CHOKEPOINTS:
        hits = [i for i in items if any(k in i["title"].lower() for k in c["kw"])]
        crit = sum(1 for i in hits if i["prio"] == "CRIT")
        high = sum(1 for i in hits if i["prio"] == "HIGH")
        lvl = "NORMAL"
        if crit >= 2 or len(hits) >= 8:
            lvl = "CRITICAL"
        elif crit >= 1 or high >= 2 or len(hits) >= 4:
            lvl = "HIGH"
        elif hits:
            lvl = "ELEVATED"
        near = 0
        for v in vessels:
            if abs(v[0] - c["lat"]) < 2.5 and abs(v[1] - c["lon"]) < 3.5:
                near += 1
        out.append(dict(id=c["id"], name=c["name"], lat=c["lat"], lon=c["lon"], note=c["note"], level=lvl, mentions=len(hits), vessels=near, headline=hits[0]["title"] if hits else ""))
    order = {"CRITICAL": 0, "HIGH": 1, "ELEVATED": 2, "NORMAL": 3}
    return sorted(out, key=lambda x: (order[x["level"]], -x["mentions"]))


SEA_KW = ["tanker", "tankers", "vessel", "vessels", "ship", "ships", "shipping", "cargo ship", "container ship", "freighter", "maritime", "navy", "naval",
          "warship", "warships", "destroyer", "frigate", "pirates", "piracy", "hijacked", "strait", "port of", "coast guard", "shadow fleet",
          "undersea cable", "subsea cable", "sea mine", "hits mine", "hit a mine", "naval mine", "blockade"]
_SEA_RE = re.compile(r"(?<![a-z])(" + "|".join(re.escape(k) for k in sorted(SEA_KW, key=len, reverse=True)) + r")(?![a-z])", re.I)


_LAND_RE = re.compile(r"(?<![a-z])(highway|truck|road|motorway|railway|lorry)(?![a-z])", re.I)   # truk tangki dsb. bukan insiden laut


def _sea_kw(c):
    """Kata kunci choke point yang benar-benar nama perairan (bukan nama negara seperti "iran"/"taiwan")."""
    return [k for k in c["kw"] if k not in PLACES]


def maritime_events(hours=48, limit=60):
    """Insiden maritim dari berita (kapal diserang/disita, perompakan, armada, kabel bawah laut). Lokasi: choke point yang
    disebut di judul, kalau tidak ada dari nama tempat. Berita tanpa lokasi tetap masuk daftar, tidak di globe."""
    out, seen = [], set()
    for it in N.all_items(hours * 3600):
        t = it["title"]
        if not _SEA_RE.search(t) or _LAND_RE.search(t) or it["id"] in seen:
            continue
        seen.add(it["id"])
        low = t.lower()
        cp = next((c for c in CHOKEPOINTS if any(k in low for k in _sea_kw(c))), None)
        place, ll = (cp["name"], (cp["lat"], cp["lon"])) if cp else locate_one(t)
        out.append(dict(id=it["id"], title=t, source=it["source"], link=it["link"], ts=it["ts"], place=(place.title() if place and not cp else place),
                        lat=ll[0] if ll else None, lon=ll[1] if ll else None, sev=severity(t, it.get("prio"))))
        if len(out) >= limit:
            break
    return out


AIR_KW = ["airspace", "airport", "airports", "flight", "flights", "airline", "airlines", "airliner", "aircraft", "plane", "planes", "jet", "jets",
          "fighter jet", "fighter jets", "helicopter", "drone", "drones", "air force", "air defense", "air defence", "bomber", "bombers", "no-fly",
          "air traffic", "aviation", "intercepted", "shot down", "emergency landing"]
_AIR_RE = re.compile(r"(?<![a-z])(" + "|".join(re.escape(k) for k in sorted(AIR_KW, key=len, reverse=True)) + r")(?![a-z])", re.I)


def aviation_events(hours=48, limit=60):
    """Berita penerbangan & wilayah udara (penutupan ruang udara, drone, jet tempur dicegat, bandara diserang, ...).
    Lokasi hanya bila judul menyebut satu tempat; berita tanpa lokasi tetap di daftar."""
    out, seen = [], set()
    for it in N.all_items(hours * 3600):
        t = it["title"]
        if not _AIR_RE.search(t) or it["id"] in seen:
            continue
        seen.add(it["id"])
        place, ll = locate_one(t)
        out.append(dict(id=it["id"], title=t, source=it["source"], link=it["link"], ts=it["ts"], place=place.title() if place else None,
                        lat=ll[0] if ll else None, lon=ll[1] if ll else None, sev=severity(t, it.get("prio"))))
        if len(out) >= limit:
            break
    return out


async def gdelt_hotspots():
    """Titik panas konflik 24 jam dari file ekspor GDELT 2.0 (lihat providers/gdelt.py). Sumber PELENGKAP: bila gagal,
    peta tetap memakai event berita lokal & choke point, dan kegagalannya tidak dihitung sebagai "sumber bermasalah"."""
    try:
        return await G.hotspots()
    except Exception:
        return []


# ---------------------------------------------------------------------------------------------- risiko per negara (peta berwarna)
_WORLD = None
PLACE_COUNTRY = {"gaza": "Palestine", "west bank": "Palestine", "gaza strip": "Palestine"}
CAT_W = {"ARMED CONFLICT": 1.0, "SECURITY": 0.8, "CIVIL UNREST": 0.7, "GEOPOLITICAL": 0.35}
SEV_W = {"CRITICAL": 3.0, "HIGH": 1.5, "ACTIVE": 1.0}
LEVELS = [(10.0, "CRITICAL"), (5.0, "HIGH"), (2.0, "ELEVATED"), (0.0001, "LOW")]
HOT_CAP = 2.5        # batas sumbangan titik panas GDELT per negara (< ambang HIGH 5.0)


def _world():
    """[(nama, [(bbox, ring)])] dari world.geojson lokal (hanya cincin luar; cukup untuk penentuan negara)."""
    global _WORLD
    if _WORLD is None:
        try:
            g = json.loads((WEB_DIR / "vendor" / "world.geojson").read_text(encoding="utf-8"))
        except Exception:
            g = {"features": []}
        out = []
        for f in g.get("features", []):
            geom = f.get("geometry") or {}
            polys = geom.get("coordinates") or []
            if geom.get("type") == "Polygon":
                polys = [polys]
            items = []
            nm = (f.get("properties") or {}).get("n", "?")
            if nm == "Antarctica":
                continue
            for p in polys:
                if not p:
                    continue
                ring = p[0]
                xs, ys = [c[0] for c in ring], [c[1] for c in ring]
                rings = [ring]
                if max(xs) - min(xs) > 180:
                    # Cincin yang melintasi garis tanggal internasional (Rusia, Fiji): jadikan kontinu, plus salinan -360 agar sisi barat tetap terdeteksi.
                    fixed = [[c[0] + 360 if c[0] < 0 else c[0], c[1]] for c in ring]
                    rings = [fixed, [[c[0] - 360, c[1]] for c in fixed]]
                for r in rings:
                    xs, ys = [c[0] for c in r], [c[1] for c in r]
                    items.append(((min(xs), min(ys), max(xs), max(ys)), r))
            out.append(((f.get("properties") or {}).get("n", "?"), items))
        _WORLD = out
    return _WORLD


def _inside(lon, lat, ring):
    ins = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-12) + xi:
            ins = not ins
        j = i
    return ins


def point_in_country(name, seed):
    """Titik acak-tetap (deterministik dari `seed`) di dalam wilayah negara - untuk peta titik "1 titik = 1 kejadian"
    bila sumber hanya mencatat NEGARA. Cincin dipilih sebanding luas kotaknya (pulau kecil jarang terpilih)."""
    import random
    polys = next((p for n, p in _world() if n == name), None)
    if not polys:
        return None
    rnd = random.Random(seed)
    areas = [(b[2] - b[0]) * (b[3] - b[1]) for b, _ in polys]
    tot = sum(areas) or 1
    for _ in range(40):
        x = rnd.random() * tot
        k = 0
        while k < len(areas) - 1 and x > areas[k]:
            x -= areas[k]
            k += 1
        (x0, y0, x1, y1), ring = polys[k]
        lon, lat = x0 + rnd.random() * (x1 - x0), y0 + rnd.random() * (y1 - y0)
        if _inside(lon, lat, ring):
            lon = ((lon + 180) % 360) - 180
            return round(lat, 3), round(lon, 3)
    return None


def country_at(lat, lon):
    """Nama negara (sesuai world.geojson) untuk sebuah titik; titik di laut/pantai dicocokkan ke negara terdekat (<4 derajat)."""
    best, bd = None, 4.0
    for name, polys in _world():
        for (x0, y0, x1, y1), ring in polys:
            if x0 <= lon <= x1 and y0 <= lat <= y1 and _inside(lon, lat, ring):
                return name
            d = math.hypot(max(x0 - lon, 0, lon - x1), max(y0 - lat, 0, lat - y1))
            if d < bd:
                best, bd = name, d
    return best


def level_of(score):
    for th, name in LEVELS:
        if score >= th:
            return name
    return "NONE"


def risk_map(evs, hotspots=None):
    """Skor risiko per negara dari event berita 36 jam terakhir (bobot keparahan, kategori, kesegaran) + titik panas GDELT."""
    now = time.time()
    acc = {}
    for e in evs:
        name = PLACE_COUNTRY.get(str(e.get("place", "")).lower()) or country_at(e["lat"], e["lon"])
        if not name:
            continue
        age = max(0, (now - e["ts"]) / 3600)
        rec = 1.0 if age < 6 else (0.7 if age < 24 else 0.45)
        w = SEV_W.get(e["sev"], 1.0) * CAT_W.get(e["cat"], 0.5) * rec
        r = acc.setdefault(name, dict(score=0.0, events=0, critical=0, top=None, top_w=-1))
        r["score"] += w
        r["events"] += 1
        r["critical"] += 1 if e["sev"] == "CRITICAL" else 0
        if w > r["top_w"]:
            r["top"], r["top_w"] = dict(title=e["title"], source=e["source"], link=e["link"], ts=e["ts"]), w
    # titik panas GDELT (dikodekan mesin, berisik): sumbangannya per negara DIBATASI HOT_CAP sehingga GDELT saja paling
    # tinggi membuat negara "ELEVATED"; level HIGH/CRITICAL tetap harus datang dari event berita.
    hot = {}
    for h in hotspots or []:
        name = country_at(h["lat"], h["lon"])
        if name:
            hot[name] = hot.get(name, 0.0) + min(1.5, 0.3 * math.log1p(h.get("count", 1)))
    for name, v in hot.items():
        r = acc.setdefault(name, dict(score=0.0, events=0, critical=0, top=None, top_w=-1))
        r["score"] += min(HOT_CAP, v)
    out = {}
    for name, r in acc.items():
        out[name] = dict(score=round(r["score"], 2), level=level_of(r["score"]), events=r["events"], critical=r["critical"], top=r["top"])
    return out
