"""Sentimen retail dari Myfxbook Community Outlook (gratis, perlu akun).

Snapshot disimpan di SQLite (tabel retail_snap) tiap polling sehingga grafik histori terbentuk selama bot berjalan.
Semua angka dibulatkan saat disimpan dan saat ditampilkan: API mentah/hasil hitung float menghasilkan
nilai seperti -678.1999999999998 atau 38.20285125461587% di UI.
"""
import time
from ..http import get_json
from ..config import MYFXBOOK_EMAIL, MYFXBOOK_PASSWORD
from .. import store

BASE = "https://www.myfxbook.com/api"
POLL_EVERY = 20 * 60
_session = dict(id=None, ts=0, error=None, last_ok=0)


def enabled():
    return bool(MYFXBOOK_EMAIL and MYFXBOOK_PASSWORD)


def _f(v, nd):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return round(x, nd) if x == x else None


def _i(v):
    try:
        return int(round(float(v)))
    except (TypeError, ValueError):
        return None


async def _login():
    j = await get_json(f"{BASE}/login.json", params={"email": MYFXBOOK_EMAIL, "password": MYFXBOOK_PASSWORD})
    if j.get("error"):
        raise RuntimeError(j.get("message", "login failed"))
    _session["id"] = j["session"]
    _session["ts"] = time.time()
    return _session["id"]


def parse_outlook(j, ts):
    """Respons get-community-outlook -> baris siap simpan. Simbol tanpa nama / tanpa posisi dibuang, angka dibulatkan."""
    rows = []
    for s in j.get("symbols", []):
        name = (s.get("name") or "").strip()
        if not name:
            continue
        lv, sv = _f(s.get("longVolume"), 2), _f(s.get("shortVolume"), 2)
        lp, sp = _i(s.get("longPositions")), _i(s.get("shortPositions"))
        lpct, spct = _f(s.get("longPercentage"), 2), _f(s.get("shortPercentage"), 2)
        if lpct is None and spct is None and lv is None:
            continue
        if lpct is None and spct is not None:
            lpct = round(100 - spct, 2)
        if spct is None and lpct is not None:
            spct = round(100 - lpct, 2)
        rows.append((ts, name, lpct, spct, lv, sv, lp, sp, _f(s.get("avgLongPrice"), 5), _f(s.get("avgShortPrice"), 5)))
    return rows


async def poll_once():
    if not enabled():
        _session["error"] = "MYFXBOOK_EMAIL / MYFXBOOK_PASSWORD belum diisi"
        return 0
    try:
        if not _session["id"]:
            await _login()
        j = await get_json(f"{BASE}/get-community-outlook.json", params={"session": _session["id"]})
        if j.get("error"):
            _session["id"] = None
            await _login()
            j = await get_json(f"{BASE}/get-community-outlook.json", params={"session": _session["id"]})
        if j.get("error"):
            raise RuntimeError(j.get("message", "outlook error"))
    except Exception as exc:
        _session["error"] = str(exc)[:160]
        _session["id"] = None
        return 0
    ts = int(time.time())
    rows = parse_outlook(j, ts)
    if rows:
        store.executemany("INSERT INTO retail_snap VALUES(?,?,?,?,?,?,?,?,?,?)", rows)
    _session["error"] = None
    _session["last_ok"] = ts
    return len(rows)


def status():
    return dict(enabled=enabled(), error=_session["error"], last_ok=_session["last_ok"], interval=POLL_EVERY)


def _net(lv, sv):
    return round((lv or 0) - (sv or 0), 2)


def _clean(r):
    """Bulatkan juga saat membaca: baris lama di SQLite (versi sebelumnya) bisa berisi float mentah seperti 38.20285125461587."""
    r = dict(r)
    for k, nd in (("long_pct", 2), ("short_pct", 2), ("long_vol", 2), ("short_vol", 2), ("avg_long", 5), ("avg_short", 5)):
        if r.get(k) is not None:
            r[k] = round(r[k], nd)
    return r


def latest_table():
    """Satu baris per simbol: snapshot terbaru + Δ volume + tren. Tiga query total (sebelumnya 2 query PER simbol)."""
    latest = [_clean(r) for r in store.query(
        "SELECT s.* FROM retail_snap s JOIN (SELECT symbol, MAX(ts) m FROM retail_snap GROUP BY symbol) x ON s.symbol=x.symbol AND s.ts=x.m ORDER BY s.symbol"
    )]
    if not latest:
        return []
    horizon = max(r["ts"] for r in latest) - 6 * 3600
    recent = store.query("SELECT symbol, ts, long_vol, short_vol FROM retail_snap WHERE ts>=? ORDER BY symbol, ts", (horizon,))
    by = {}
    for r in recent:
        by.setdefault(r["symbol"], []).append(r)
    out = []
    for r in latest:
        hist = by.get(r["symbol"], [])
        net = _net(r["long_vol"], r["short_vol"])
        # Δ Vol = perubahan net volume dibanding snapshot ±1 jam lalu; bila histori < 1 jam, dibanding snapshot paling awal yang ada.
        dvol = None
        older = [x for x in hist if x["ts"] < r["ts"]]
        if older:
            target = r["ts"] - 3600
            ref = min(older, key=lambda x: abs(x["ts"] - target))
            dvol = round(net - _net(ref["long_vol"], ref["short_vol"]), 2)
        trend = [_net(x["long_vol"], x["short_vol"]) for x in hist[-24:]]
        lp, sp = r["long_pos"] or 0, r["short_pos"] or 0
        out.append(dict(symbol=r["symbol"], net_vol=net, total_pos=lp + sp, long_pct=r["long_pct"], short_pct=r["short_pct"], long_pos=r["long_pos"], short_pos=r["short_pos"],
                        long_vol=r["long_vol"], short_vol=r["short_vol"], dvol=dvol, trend=trend, avg_long=r["avg_long"], avg_short=r["avg_short"], ts=r["ts"]))
    return out


def history(symbol, days=14, max_points=600):
    """Histori satu simbol (urut waktu). Bila terlalu banyak titik, diambil merata dan titik terakhir selalu dipertahankan."""
    days = max(1, min(int(days), 120))
    since = int(time.time()) - days * 86400
    rows = [_clean(r) for r in store.query("SELECT * FROM retail_snap WHERE symbol=? AND ts>=? ORDER BY ts ASC", (symbol, since))]
    out = [dict(r, net_vol=_net(r["long_vol"], r["short_vol"]), total_pos=(r["long_pos"] or 0) + (r["short_pos"] or 0)) for r in rows]
    if len(out) > max_points:
        step = len(out) / max_points
        out = [out[int(i * step)] for i in range(max_points - 1)] + [out[-1]]
    return out
