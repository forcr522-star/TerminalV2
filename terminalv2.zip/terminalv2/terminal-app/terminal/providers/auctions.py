"""Lelang surat utang negara: jadwal mendatang + riwayat hasil, dari sumber gratis tanpa key.

AS      : US Treasury FiscalData (upcoming_auctions + auctions_query), cadangan TreasuryDirect (TA_WS).
Lainnya : kalender ekonomi TradingView (judul memuat "Auction"/"Tender"; nilai actual = yield lelang),
          cadangan ForexFactory (hanya minggu ini & depan). Kalender memuat lelang JGB, Gilt, Bund, Bond AU/NZ/CA/ID dst.

Hasil per negara: dict(upcoming=[...], history=[...], sources=[...], available=bool).
Negara tanpa satu pun baris -> available=False dan UI menyembunyikan panelnya (tidak ada panel kosong).
"""
import asyncio
import datetime as dt
import re
from ..http import get_json
from .. import http
from ..universe import COUNTRY_ORDER
from . import calendar as cal

FD = "https://api.fiscaldata.treasury.gov/services/api/fiscal_service"
TD = "https://www.treasurydirect.gov/TA_WS/securities"
AUCTION_RE = re.compile(r"auction|tender", re.I)
UP_MAX, HIST_MAX = 12, 15


def _f(v):
    try:
        x = float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None
    return x if x == x else None


def _d(v):
    """'2026-11-05', '2026-11-05T00:00:00', '2026-11-05 13:30' -> '2026-11-05'."""
    m = re.match(r"(\d{4}-\d{2}-\d{2})", str(v or ""))
    return m.group(1) if m else None


def _row(date, cc, name, status, src, **kw):
    r = dict(date=date, cc=cc, name=name, status=status, src=src, term=None, type=None, amount=None, rate=None, btc=None, forecast=None, previous=None, unit=None, importance=None)
    r.update(kw)
    return r


# ----------------------------------------------------------------------------------------- parser murni (diuji dengan fixture)
def parse_fd_upcoming(rows):
    out = []
    for a in rows or []:
        d = _d(a.get("auction_date"))
        if not d:
            continue
        term, typ = (a.get("security_term") or "").strip(), (a.get("security_type") or "").strip()
        out.append(_row(d, "US", (term + " " + typ).strip() or "Treasury", "upcoming", "US Treasury FiscalData", term=term, type=typ, amount=_f(a.get("offering_amt")),
                        issue=_d(a.get("issue_date")), reopening=(a.get("reopening") or "").strip() or None))
    return out


def parse_fd_history(rows):
    out = []
    for a in rows or []:
        d = _d(a.get("auction_date"))
        if not d:
            continue
        rate = next((v for v in (_f(a.get(k)) for k in ("high_yield", "high_investment_rate", "high_discnt_rate", "avg_med_yield")) if v is not None), None)
        term, typ = (a.get("security_term") or "").strip(), (a.get("security_type") or "").strip()
        out.append(_row(d, "US", (term + " " + typ).strip() or "Treasury", "done", "US Treasury FiscalData", term=term, type=typ, amount=_f(a.get("offering_amt")),
                        rate=rate, btc=_f(a.get("bid_to_cover_ratio")), accepted=_f(a.get("total_accepted"))))
    return out


def parse_td(rows, status):
    """TreasuryDirect TA_WS (camelCase)."""
    out = []
    for a in rows or []:
        d = _d(a.get("auctionDate"))
        if not d:
            continue
        term, typ = (a.get("securityTerm") or "").strip(), (a.get("securityType") or "").strip()
        rate = next((v for v in (_f(a.get(k)) for k in ("highYield", "highInvestmentRate", "highDiscountRate", "averageMedianYield")) if v is not None), None)
        out.append(_row(d, "US", (term + " " + typ).strip() or "Treasury", status, "TreasuryDirect", term=term, type=typ, amount=_f(a.get("offeringAmount")),
                        rate=rate if status == "done" else None, btc=_f(a.get("bidToCoverRatio")) if status == "done" else None, issue=_d(a.get("issueDate"))))
    return out


def parse_tv(result, now=None):
    """Kalender TradingView -> {cc: [row]}. Hanya peristiwa berjudul Auction/Tender; lewat+punya actual = riwayat, mendatang = jadwal."""
    now = now or dt.datetime.now(dt.timezone.utc)
    out = {}
    for r in result or []:
        title = r.get("title") or r.get("indicator") or ""
        if not AUCTION_RE.search(title):
            continue
        try:
            when = dt.datetime.fromisoformat(str(r.get("date")).replace("Z", "+00:00")).astimezone(dt.timezone.utc)
        except Exception:
            continue
        cc = r.get("country")
        if not cc:
            continue
        actual = _f(r.get("actual"))
        status = "upcoming" if when >= now - dt.timedelta(hours=3) and actual is None else ("done" if actual is not None else None)
        if status is None:
            continue
        unit = f"{r.get('scale') or ''}{r.get('unit') or ''}"
        row = _row(when.strftime("%Y-%m-%d"), cc, title.strip(), status, "TradingView Calendar", time=when.strftime("%H:%M"), rate=actual, forecast=_f(r.get("forecast")),
                   previous=_f(r.get("previous")), unit=unit or None, importance=r.get("importance"))
        out.setdefault(cc, []).append(row)
    return out


def parse_ff(rows, now=None):
    """ForexFactory: judul '10-y Bond Auction'; actual bisa 'yield|bid-to-cover'."""
    now = now or dt.datetime.now(dt.timezone.utc)
    out = {}
    for r in rows or []:
        if not AUCTION_RE.search(r.get("event") or ""):
            continue
        cc = r.get("cc")
        if not cc:
            continue
        try:
            when = dt.datetime.strptime(r["date"], "%Y-%m-%d %H:%M").replace(tzinfo=dt.timezone.utc)
        except Exception:
            continue
        actual = r.get("actual")
        rate = btc = None
        if actual not in (None, ""):
            parts = str(actual).replace("%", "").split("|")
            rate = _f(parts[0])
            btc = _f(parts[1]) if len(parts) > 1 else None
        status = "done" if rate is not None else ("upcoming" if when >= now - dt.timedelta(hours=3) else None)
        if status is None:
            continue
        out.setdefault(cc, []).append(_row(when.strftime("%Y-%m-%d"), cc, r["event"].strip(), status, "ForexFactory", time=when.strftime("%H:%M"), rate=rate, btc=btc))
    return out


def merge(rows):
    """Buang duplikat (tanggal+nama), urutkan: upcoming naik, history turun."""
    seen, up, hist = set(), [], []
    for r in rows:
        k = (r["date"], r["name"].lower())
        if k in seen:
            continue
        seen.add(k)
        (up if r["status"] == "upcoming" else hist).append(r)
    up.sort(key=lambda r: (r["date"], r.get("time") or ""))
    hist.sort(key=lambda r: (r["date"], r.get("time") or ""), reverse=True)
    return up[:UP_MAX], hist[:HIST_MAX]


# ----------------------------------------------------------------------------------------- jaringan
async def _fd(path, params):
    return (await get_json(f"{FD}/{path}", params=params, retries=1)).get("data", [])


async def _us():
    today = dt.date.today().isoformat()
    since = (dt.date.today() - dt.timedelta(days=120)).isoformat()
    up, hist = await asyncio.gather(
        _fd("v1/accounting/od/upcoming_auctions", {"sort": "-auction_date", "page[size]": 80}),
        _fd("v1/accounting/od/auctions_query", {"sort": "-auction_date", "filter": f"auction_date:gte:{since},auction_date:lte:{today}", "page[size]": 60}),
        return_exceptions=True,
    )
    rows, srcs = [], []
    up_rows = [r for r in (parse_fd_upcoming(up) if not isinstance(up, Exception) else []) if r["date"] >= today]
    hi_rows = [r for r in (parse_fd_history(hist) if not isinstance(hist, Exception) else []) if r["date"] <= today]
    if not up_rows or not hi_rows:  # cadangan: TreasuryDirect
        try:
            if not up_rows:
                up_rows = [r for r in parse_td(await get_json(f"{TD}/upcoming", params={"format": "json"}, retries=1), "upcoming") if r["date"] >= today]
            if not hi_rows:
                hi_rows = parse_td(await get_json(f"{TD}/auctioned", params={"format": "json", "days": 120}, retries=1), "done")
        except Exception:
            pass
    rows = up_rows + hi_rows
    srcs = sorted({r["src"] for r in rows})
    return rows, srcs


async def _tv_all():
    now = dt.datetime.now(dt.timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    params = {"from": (now - dt.timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%S.000Z"), "to": (now + dt.timedelta(days=45)).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
              "countries": ",".join(COUNTRY_ORDER)}
    j = await get_json(cal.TV, params=params, headers=cal.TV_HEADERS, retries=1)
    return parse_tv(j.get("result", []))


@http.cached(1800, persist=True, stale_ok=7 * 86400)
async def tv_by_country():
    return await _tv_all()


@http.cached(1800, persist=True, stale_ok=7 * 86400)
async def _ff_by_country():
    return parse_ff(await cal.ff_calendar())


async def for_country(cc):
    rows, srcs = [], []
    if cc == "US":
        try:
            rows, srcs = await _us()
        except Exception:
            rows, srcs = [], []
    if not rows or cc != "US":
        try:
            tv = (await tv_by_country()).get(cc, [])
        except Exception:
            tv = []
        if not tv:
            try:
                tv = (await _ff_by_country()).get(cc, [])
            except Exception:
                tv = []
        rows = rows + tv
        srcs = sorted(set(srcs) | {r["src"] for r in tv})
    up, hist = merge(rows)
    return dict(upcoming=up, history=hist, sources=srcs, available=bool(up or hist))
