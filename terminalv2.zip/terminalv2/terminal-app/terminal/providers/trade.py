"""Perdagangan internasional (ekspor/impor, mitra, sektor) — sumber: OEC Tesseract (BACI/CEPII).

UN Comtrade `preview` kini menolak akses tanpa kunci (HTTP 403 pada semua permintaan), sehingga panel
SUPPLY CHAIN kehilangan data setiap kali terminal berjalan lama. Penggantinya OEC Tesseract yang memakai
dataset BACI (CEPII) — HS6, tahunan, tanpa kunci API, dan sudah diverifikasi menerima permintaan publik.

Fungsi publik: partners(), overview(), pair(), sectors(). Tiap mitra membawa `oid` (kode OEC) dan `code` yang stabil
(kode STATIC bila dikenal, selain itu dari iso3) sehingga daftar ekspor & impor selalu cocok satu sama lain.
"""
import asyncio
import datetime as dt
from ..http import get_json, cached
from ..universe import COUNTRIES

API = "https://api.oec.world/tesseract/data.jsonrecords"
CUBE = "trade_i_baci_a_92"          # BACI HS6, tahunan (1995-2024)
MEASURE = "Trade Value"

STATIC = {
    842: ("United States", "US", 39.8, -98.6), 156: ("China", "CN", 35.0, 103.0), 124: ("Canada", "CA", 56.1, -106.3), 484: ("Mexico", "MX", 23.6, -102.5),
    826: ("United Kingdom", "GB", 54.0, -2.5), 276: ("Germany", "DE", 51.2, 10.4), 392: ("Japan", "JP", 36.2, 138.3), 410: ("South Korea", "KR", 36.5, 127.9),
    36: ("Australia", "AU", -25.3, 133.8), 554: ("New Zealand", "NZ", -41.0, 174.0), 756: ("Switzerland", "CH", 46.8, 8.2), 360: ("Indonesia", "ID", -2.5, 118.0),
    528: ("Netherlands", "NL", 52.1, 5.3), 250: ("France", "FR", 46.6, 2.5), 380: ("Italy", "IT", 42.8, 12.5), 724: ("Spain", "ES", 40.4, -3.7), 56: ("Belgium", "BE", 50.6, 4.6),
    699: ("India", "IN", 21.0, 78.0), 76: ("Brazil", "BR", -14.2, -51.9), 702: ("Singapore", "SG", 1.35, 103.8), 704: ("Vietnam", "VN", 14.1, 108.3), 764: ("Thailand", "TH", 15.9, 100.9),
    458: ("Malaysia", "MY", 4.2, 102.0), 608: ("Philippines", "PH", 12.9, 121.8), 344: ("Hong Kong", "HK", 22.3, 114.2), 490: ("Taiwan", "TW", 23.7, 121.0), 643: ("Russia", "RU", 61.5, 105.3),
    792: ("Turkiye", "TR", 39.0, 35.2), 682: ("Saudi Arabia", "SA", 24.0, 45.0), 784: ("UAE", "AE", 24.3, 54.4), 710: ("South Africa", "ZA", -30.6, 22.9), 616: ("Poland", "PL", 52.1, 19.4),
    203: ("Czechia", "CZ", 49.8, 15.5), 372: ("Ireland", "IE", 53.4, -8.2), 752: ("Sweden", "SE", 62.0, 15.0), 578: ("Norway", "NO", 60.5, 8.5), 208: ("Denmark", "DK", 56.3, 9.5),
    40: ("Austria", "AT", 47.5, 14.6), 246: ("Finland", "FI", 61.9, 25.7), 620: ("Portugal", "PT", 39.4, -8.2), 300: ("Greece", "GR", 39.0, 22.0), 348: ("Hungary", "HU", 47.2, 19.5),
    152: ("Chile", "CL", -35.7, -71.5), 170: ("Colombia", "CO", 4.6, -74.1), 604: ("Peru", "PE", -9.2, -75.0), 32: ("Argentina", "AR", -38.4, -63.6), 818: ("Egypt", "EG", 26.8, 30.8),
    586: ("Pakistan", "PK", 30.4, 69.3), 50: ("Bangladesh", "BD", 23.7, 90.4), 634: ("Qatar", "QA", 25.3, 51.2), 376: ("Israel", "IL", 31.0, 34.9),
    566: ("Nigeria", "NG", 9.1, 8.7), 12: ("Algeria", "DZ", 28.0, 1.7), 504: ("Morocco", "MA", 31.8, -7.1), 804: ("Ukraine", "UA", 49.0, 31.4), 642: ("Romania", "RO", 45.9, 25.0),
    398: ("Kazakhstan", "KZ", 48.0, 66.9), 417: ("Kyrgyzstan", "KG", 41.2, 74.8), 116: ("Cambodia", "KH", 12.6, 104.9), 104: ("Myanmar", "MM", 21.9, 95.9), 496: ("Mongolia", "MN", 46.9, 103.8),
    854: ("Burkina Faso", "BF", 12.2, -1.6), 384: ("Cote d'Ivoire", "CI", 7.5, -5.5), 894: ("Zambia", "ZM", -13.1, 27.8), 368: ("Iraq", "IQ", 33.2, 43.7), 860: ("Uzbekistan", "UZ", 41.4, 64.6),
    703: ("Slovakia", "SK", 48.7, 19.7), 705: ("Slovenia", "SI", 46.2, 14.9), 414: ("Kuwait", "KW", 29.3, 47.5), 364: ("Iran", "IR", 32.4, 53.7), 512: ("Oman", "OM", 21.5, 55.9),
    442: ("Luxembourg", "LU", 49.8, 6.1), 218: ("Ecuador", "EC", -1.8, -78.2), 862: ("Venezuela", "VE", 6.4, -66.6), 24: ("Angola", "AO", -11.2, 17.9), 144: ("Sri Lanka", "LK", 7.9, 80.8),
    404: ("Kenya", "KE", -0.02, 37.9), 288: ("Ghana", "GH", 7.9, -1.0), 231: ("Ethiopia", "ET", 9.1, 40.5), 100: ("Bulgaria", "BG", 42.7, 25.5), 191: ("Croatia", "HR", 45.1, 15.2),
    688: ("Serbia", "RS", 44.0, 21.0), 440: ("Lithuania", "LT", 55.2, 23.9), 428: ("Latvia", "LV", 56.9, 24.6), 233: ("Estonia", "EE", 58.6, 25.0), 112: ("Belarus", "BY", 53.7, 27.9),
    31: ("Azerbaijan", "AZ", 40.1, 47.6), 268: ("Georgia", "GE", 42.3, 43.4), 434: ("Libya", "LY", 26.3, 17.2), 788: ("Tunisia", "TN", 33.9, 9.5), 400: ("Jordan", "JO", 30.6, 36.2),
    422: ("Lebanon", "LB", 33.9, 35.9), 48: ("Bahrain", "BH", 26.0, 50.6), 418: ("Laos", "LA", 19.9, 102.5), 96: ("Brunei", "BN", 4.5, 114.7), 598: ("Papua New Guinea", "PG", -6.3, 143.9),
    242: ("Fiji", "FJ", -17.7, 178.1), 540: ("New Caledonia", "NC", -20.9, 165.6), 446: ("Macao", "MO", 22.2, 113.5), 188: ("Costa Rica", "CR", 9.7, -83.8), 591: ("Panama", "PA", 8.5, -80.8),
    214: ("Dominican Republic", "DO", 18.7, -70.2), 320: ("Guatemala", "GT", 15.8, -90.2), 858: ("Uruguay", "UY", -32.5, -55.8), 600: ("Paraguay", "PY", -23.4, -58.4), 68: ("Bolivia", "BO", -16.3, -63.6),
    508: ("Mozambique", "MZ", -18.7, 35.5), 180: ("DR Congo", "CD", -4.0, 21.8), 834: ("Tanzania", "TZ", -6.4, 34.9),
}
# ISO3 tiap kode di STATIC: kode OEC = <benua><iso3>, jadi iso3 menghubungkan baris OEC ke kode/koordinat di atas
ISO3 = {
    842: "USA", 156: "CHN", 124: "CAN", 484: "MEX", 826: "GBR", 276: "DEU", 392: "JPN", 410: "KOR", 36: "AUS", 554: "NZL", 756: "CHE", 360: "IDN", 528: "NLD", 250: "FRA",
    380: "ITA", 724: "ESP", 56: "BEL", 699: "IND", 76: "BRA", 702: "SGP", 704: "VNM", 764: "THA", 458: "MYS", 608: "PHL", 344: "HKG", 490: "TWN", 643: "RUS", 792: "TUR",
    682: "SAU", 784: "ARE", 710: "ZAF", 616: "POL", 203: "CZE", 372: "IRL", 752: "SWE", 578: "NOR", 208: "DNK", 40: "AUT", 246: "FIN", 620: "PRT", 300: "GRC", 348: "HUN",
    152: "CHL", 170: "COL", 604: "PER", 32: "ARG", 818: "EGY", 586: "PAK", 50: "BGD", 634: "QAT", 376: "ISR", 566: "NGA", 12: "DZA", 504: "MAR", 804: "UKR", 642: "ROU",
    398: "KAZ", 417: "KGZ", 116: "KHM", 104: "MMR", 496: "MNG", 854: "BFA", 384: "CIV", 894: "ZMB", 368: "IRQ", 860: "UZB", 703: "SVK", 705: "SVN", 414: "KWT", 364: "IRN",
    512: "OMN", 442: "LUX", 218: "ECU", 862: "VEN", 24: "AGO", 144: "LKA", 404: "KEN", 288: "GHA", 231: "ETH", 100: "BGR", 191: "HRV", 688: "SRB", 440: "LTU", 428: "LVA",
    233: "EST", 112: "BLR", 31: "AZE", 268: "GEO", 434: "LBY", 788: "TUN", 400: "JOR", 422: "LBN", 48: "BHR", 418: "LAO", 96: "BRN", 598: "PNG", 242: "FJI", 540: "NCL",
    446: "MAC", 188: "CRI", 591: "PAN", 214: "DOM", 320: "GTM", 858: "URY", 600: "PRY", 68: "BOL", 508: "MOZ", 180: "COD", 834: "TZA",
}
_CODE_BY_ISO3 = {v: k for k, v in ISO3.items()}
HS2 = {
    "01": "Live animals", "02": "Meat", "03": "Fish & seafood", "04": "Dairy & eggs", "07": "Vegetables", "08": "Fruit & nuts", "09": "Coffee, tea, spices", "10": "Cereals", "12": "Oil seeds",
    "15": "Fats & oils", "17": "Sugars", "18": "Cocoa", "21": "Misc. food", "22": "Beverages", "24": "Tobacco", "25": "Salt, stone, cement", "26": "Ores", "27": "Mineral fuels & oil",
    "28": "Inorganic chemicals", "29": "Organic chemicals", "30": "Pharmaceuticals", "31": "Fertilizers", "32": "Dyes & paints", "33": "Cosmetics", "38": "Misc. chemicals", "39": "Plastics",
    "40": "Rubber", "41": "Hides", "44": "Wood", "47": "Pulp", "48": "Paper", "52": "Cotton", "54": "Man-made filaments", "61": "Knit apparel", "62": "Woven apparel", "63": "Textile articles",
    "64": "Footwear", "68": "Stone articles", "69": "Ceramics", "70": "Glass", "71": "Precious metals & gems", "72": "Iron & steel", "73": "Iron/steel articles", "74": "Copper", "76": "Aluminium",
    "79": "Zinc", "81": "Other base metals", "82": "Tools", "83": "Misc. metal articles", "84": "Machinery", "85": "Electrical machinery", "86": "Railway", "87": "Vehicles", "88": "Aircraft",
    "89": "Ships", "90": "Optical & medical instruments", "91": "Clocks", "94": "Furniture", "95": "Toys & games", "96": "Misc. manufactured", "97": "Art", "99": "Unclassified",
}

# Kode negara OEC = <benua><ISO3>. Satu-satunya pemetaan yang perlu dirawat bila OEC menambah negara.
_CONT = {
    "US": "na", "CN": "as", "JP": "as", "KR": "as", "IN": "as", "ID": "as", "SG": "as", "VN": "as", "TH": "as", "MY": "as",
    "PH": "as", "HK": "as", "TW": "as", "PK": "as", "BD": "as", "KZ": "as", "KG": "as", "KH": "as", "MM": "as", "MN": "as",
    "RU": "as", "TR": "as", "SA": "sa", "AE": "as", "QA": "as", "IL": "as", "ZA": "af", "NG": "af", "EG": "af", "DZ": "af",
    "MA": "af", "BR": "sa", "AR": "sa", "CL": "sa", "CO": "sa", "PE": "sa", "MX": "na", "CA": "na",
    "GB": "eu", "DE": "eu", "FR": "eu", "IT": "eu", "ES": "eu", "NL": "eu", "BE": "eu", "CH": "eu", "PL": "eu", "CZ": "eu",
    "IE": "eu", "SE": "eu", "NO": "eu", "DK": "eu", "AT": "eu", "FI": "eu", "PT": "eu", "GR": "eu", "HU": "eu", "RO": "eu",
    "UA": "eu",
    "AU": "oc", "NZ": "oc",
}
_OEC = {cc: _CONT.get(cc, "eu") + COUNTRIES[cc]["iso3"].lower() for cc in COUNTRIES}
# Euro Zone = 20 anggota kawasan euro; OEC menjumlahkan beberapa negara dalam satu permintaan. Mitra yang juga anggota
# dibuang sehingga angkanya = perdagangan EXTRA-euro area (dulu: Jerman saja sebagai pengganti, dan kosong di pasangan).
EA20 = ["euaut", "eubel", "euhrv", "eucyp", "euest", "eufin", "eufra", "eudeu", "eugrc", "euirl", "euita", "eulva", "eultu",
        "eulux", "eumlt", "eunld", "euprt", "eusvk", "eusvn", "euesp"]
_OEC["EU"] = ",".join(EA20)
_M49 = {cc: COUNTRIES[cc]["m49"] for cc in COUNTRIES}
_CC_BY_M49 = {v: k for k, v in _M49.items()}
_OEC_BY_CC = _OEC
_CC_BY_OEC = {v: k for k, v in _OEC.items()}


def _id(cc):
    return _OEC.get(cc) or ("eu" + COUNTRIES[cc]["iso3"].lower())


def _num(v):
    try:
        return float(v or 0)
    except Exception:
        return 0.0


def code_of(oid):
    """Kode mitra STABIL dari kode OEC (<benua><iso3>): kode di STATIC bila dikenal, selain itu angka negatif dari iso3.

    Dulu mitra di luar 10 negara utama diberi kode menurut URUTAN baris (-1, -2, ...). Urutan itu berbeda antara
    data ekspor dan impor, sehingga kode bertabrakan: heatmap menampilkan nama yang salah ("Yemen" dengan nilai
    Vietnam) dan impor mitra seperti Hong Kong terbaca $0. Kode berbasis iso3 sama di semua daftar."""
    iso3 = str(oid or "")[2:].upper()
    if iso3 in _CODE_BY_ISO3:
        return _CODE_BY_ISO3[iso3]
    return -int(iso3.lower(), 36) if iso3.isalnum() and iso3 else 0


async def _query(drill, exporter=None, importer=None, year=None, limit=500):
    """Satu permintaan Tesseract (tanpa kunci API)."""
    params = {"cube": CUBE, "drilldowns": drill, "measures": MEASURE, "limit": limit}
    if year:
        params["Year"] = year
    if exporter:
        params["Exporter Country"] = exporter
    if importer:
        params["Importer Country"] = importer
    j = await get_json(API, params=params, retries=1)
    return (j or {}).get("data") or []


def _members(oid):
    return set(str(oid).split(","))


@cached(86400, persist=True, stale_ok=30 * 86400)
async def _flow_rows(oid, flow, year):
    """Semua mitra satu negara/kelompok (kode OEC, boleh dipisah koma) untuk satu arus & tahun:
    {total, rows:[{oid, code, name, value}]} urut nilai. Anggota kelompok sendiri tidak dihitung sebagai mitra.

    Jawaban KOSONG dilempar sebagai error, bukan disimpan: tahun yang belum terbit di BACI dicoba lagi lain waktu, dan
    jawaban kosong sesaat dari OEC (server sibuk saat preload; kueri EU 20 anggota paling berat) tidak tersimpan sehari
    penuh di cache permanen - dulu itu membuat "kosong: supply/overview [cc=EU]". (Nama fungsi baru = kunci cache baru,
    sehingga hasil kosong lama di database ikut terabaikan.)"""
    if flow == "X":
        rows, drill = await _query("Importer Country", exporter=oid, year=year), "Importer Country"
    else:
        rows, drill = await _query("Exporter Country", importer=oid, year=year), "Exporter Country"
    if not rows:
        raise LookupError(f"OEC: belum ada data BACI {flow} {year}")
    out, mem = [], _members(oid)
    for r in rows:
        po = str(r.get(drill + " ID") or "")
        val = _num(r.get(MEASURE))
        if po and val > 0 and po not in mem:
            out.append(dict(oid=po, code=code_of(po), name=str(r.get(drill) or po), value=val))
    out.sort(key=lambda x: -x["value"])
    return dict(total=sum(x["value"] for x in out), rows=out)


async def _hs2_rows(exporter=None, importer=None, year=None):
    """Sektor HS2 untuk satu negara atau satu PASANGAN. Baris OEC: {HS2 ID, HS2, Trade Value}."""
    out = []
    for r in await _query("HS2", exporter=exporter, importer=importer, year=year):
        try:
            code = int(r.get("HS2 ID"))
        except Exception:
            continue
        # OEC menyimpan HS2 ID sebagai <grup><bab 2 digit> (101, 315, 1685 ...): bab HS = dua digit terakhir
        ch = str(code % 100).zfill(2)
        out.append(dict(code=ch, name=str(r.get("HS2") or HS2.get(ch) or ch), value=_num(r.get(MEASURE))))
    out.sort(key=lambda x: -x["value"])
    return out


def _rep_oid(reporter_m49):
    cc = _CC_BY_M49.get(int(reporter_m49))
    if cc is None:
        iso3 = ISO3.get(int(reporter_m49))
        return ("xx" + iso3.lower()) if iso3 else None
    return _id(cc)


@cached(86400)
async def partners(reporter, flow, year=None):
    """Mitra dagang pelapor (kode M49 internal). Tahun terbaru yang tersedia di BACI dicari mundur."""
    oid = _rep_oid(reporter)
    if not oid:
        return dict(year=None, total=0, partners=[])
    years = [year] if year else [dt.date.today().year - 1, dt.date.today().year - 2, dt.date.today().year - 3]
    for y in years:
        try:
            f = await _flow_rows(oid, flow, y)
        except Exception:
            continue
        if not f["rows"]:
            continue                       # tahun belum tersedia di BACI: coba tahun sebelumnya
        out = []
        for r in f["rows"]:
            st = STATIC.get(r["code"])
            out.append(dict(code=r["code"], oid=r["oid"], name=st[0] if st else r["name"], iso=st[1] if st else "",
                            lat=st[2] if st else None, lon=st[3] if st else None, value=r["value"]))
        return dict(year=int(y), total=f["total"], partners=out)
    return dict(year=None, total=0, partners=[])


def _m49(cc):
    return COUNTRIES[cc]["m49"]


@cached(86400)
async def overview(cc, flow="X", top=18):
    rep = _m49(cc)
    ex, im = await asyncio.gather(partners(rep, "X"), partners(rep, "M"))
    main = ex if flow == "X" else im
    other = im if flow == "X" else ex
    other_map = {p["code"]: p["value"] for p in other["partners"]}
    listing = []
    for p in main["partners"][:top]:
        listing.append(dict(p, share=(p["value"] / main["total"] * 100) if main["total"] else 0, counter=other_map.get(p["code"], 0)))
    top5 = sum(p["value"] for p in main["partners"][:5])
    heat = []
    exp_map = {p["code"]: p["value"] for p in ex["partners"]}
    imp_map = {p["code"]: p["value"] for p in im["partners"]}
    turn = sorted({*exp_map, *imp_map}, key=lambda c: -(exp_map.get(c, 0) + imp_map.get(c, 0)))[:12]
    names = {p["code"]: p for p in ex["partners"] + im["partners"]}
    for c in turn:
        heat.append(dict(code=c, oid=names[c].get("oid"), name=names[c]["name"], exp=exp_map.get(c, 0), imp=imp_map.get(c, 0), net=exp_map.get(c, 0) - imp_map.get(c, 0)))
    return dict(
        reporter=cc, flow=flow, year=main["year"] or ex["year"] or im["year"], exports=ex["total"], imports=im["total"], balance=(ex["total"] or 0) - (im["total"] or 0),
        concentration=(top5 / main["total"] * 100) if main["total"] else 0, partners_count=len(main["partners"]), partners=listing, heat=heat,
        origin=dict(lat=_origin(cc)[0], lon=_origin(cc)[1]),
    )


def _origin(cc):
    st = STATIC.get(COUNTRIES[cc]["m49"]) or STATIC.get(276 if cc == "EU" else 0)
    return (st[2], st[3]) if st else (0, 0)


def _pct(a, b):
    return (a / b * 100) if a is not None and b else None


@cached(86400, persist=True, stale_ok=30 * 86400)
async def pair(cc, partner_code=0, oid=""):
    """Analisa satu pasangan dagang dari BACI (CEPII) via OEC - berlaku untuk SEMUA mitra, bukan hanya 10 negara utama.

    BACI merekonsiliasi laporan ekspor & impor menjadi SATU angka per arus (ekspor A ke B = impor B dari A), jadi
    "selisih mirror" selalu nol dan tidak ditampilkan. Yang dihitung: nilai & pangsa, peringkat mitra, perubahan
    tahunan dan tren 5 tahun, KETERGANTUNGAN dua arah (pangsa di sisi mitra vs pangsa di sisi pelapor) dan produk
    HS2 utama per arah. Semua dari tahun data yang sama; tidak ada nilai yang diperkirakan."""
    rep = _m49(cc)
    rep_oid = _id(cc)
    base_x, base_m = await asyncio.gather(partners(rep, "X"), partners(rep, "M"))
    year = base_x["year"] or base_m["year"]
    if not year:
        return dict(year=None, error="data BACI untuk pelapor ini belum tersedia")
    if not oid:
        hit = next((p for p in base_x["partners"] + base_m["partners"] if p["code"] == int(partner_code or 0)), None)
        oid = hit["oid"] if hit else (_id(_CC_BY_M49[int(partner_code)]) if int(partner_code or 0) in _CC_BY_M49 else "")
    if not oid or oid in _members(rep_oid):
        return dict(year=year, error="mitra tidak dikenal")
    years = list(range(year - 4, year + 1))
    jobs = [_flow_rows(rep_oid, f, y) for f in ("X", "M") for y in years]
    jobs += [_flow_rows(oid, "X", year), _flow_rows(oid, "M", year), _hs2_rows(exporter=rep_oid, importer=oid, year=year), _hs2_rows(exporter=oid, importer=rep_oid, year=year)]
    res = await asyncio.gather(*jobs, return_exceptions=True)
    ok = lambda r: None if isinstance(r, Exception) else r
    fx, fm = [ok(r) for r in res[:5]], [ok(r) for r in res[5:10]]
    par_x, par_m, hs_x, hs_m = [ok(r) for r in res[10:]]

    def val(f):
        if not f:
            return None
        return next((r["value"] for r in f["rows"] if r["oid"] == oid), 0.0)

    def rank(f):
        if not f:
            return None
        return next((i + 1 for i, r in enumerate(f["rows"]) if r["oid"] == oid), None)

    mem = _members(rep_oid)

    def rep_val(f):          # nilai pelapor (atau jumlah anggota kelompok) di daftar mitra milik partner
        if not f:
            return None
        return sum(r["value"] for r in f["rows"] if r["oid"] in mem)

    trend = [dict(year=y, exports=val(fx[i]), imports=val(fm[i])) for i, y in enumerate(years)]
    ex, im = trend[-1]["exports"], trend[-1]["imports"]
    pex, pim = trend[-2]["exports"], trend[-2]["imports"]
    yoy = lambda a, b: ((a / b - 1) * 100) if a is not None and b else None
    name = next((p["name"] for p in base_x["partners"] + base_m["partners"] if p["oid"] == oid), None) or oid
    # ketergantungan: pangsa di sisi mitra (BACI: impor mitra dari pelapor = ekspor pelapor ke mitra)
    par_imp_share = _pct(rep_val(par_m), par_m and par_m["total"])     # % impor mitra yang berasal dari pelapor
    par_exp_share = _pct(rep_val(par_x), par_x and par_x["total"])     # % ekspor mitra yang menuju pelapor
    ex_share = _pct(ex, fx[-1] and fx[-1]["total"])                    # % ekspor pelapor yang menuju mitra
    im_share = _pct(im, fm[-1] and fm[-1]["total"])                    # % impor pelapor yang berasal dari mitra
    top = lambda rows, tot: [dict(r, share=_pct(r["value"], tot)) for r in (rows or [])[:6]]
    return dict(
        year=year, partner=name or oid, oid=oid, source="BACI (CEPII) via OEC",
        exports=ex, imports=im, net=(ex - im) if ex is not None and im is not None else None,
        turnover=(ex or 0) + (im or 0) if ex is not None or im is not None else None,
        ex_share=ex_share, im_share=im_share, ex_rank=rank(fx[-1]), im_rank=rank(fm[-1]),
        n_dest=len(fx[-1]["rows"]) if fx[-1] else None, n_src=len(fm[-1]["rows"]) if fm[-1] else None,
        ex_yoy=yoy(ex, pex), im_yoy=yoy(im, pim),
        partner_import_share=par_imp_share, partner_export_share=par_exp_share,
        # asimetri (poin persen): positif = mitra lebih bergantung pada pelapor daripada sebaliknya
        asym_exports=(par_imp_share - ex_share) if par_imp_share is not None and ex_share is not None else None,
        asym_imports=(par_exp_share - im_share) if par_exp_share is not None and im_share is not None else None,
        trend=trend, top_exports=top(hs_x, ex), top_imports=top(hs_m, im),
    )


@cached(86400)
async def sectors(cc, flow="X"):
    rep = _m49(cc)
    year = (await partners(rep, flow))["year"] or dt.date.today().year - 1
    rows = await (_hs2_rows(exporter=_id(cc), year=year) if flow == "X" else _hs2_rows(importer=_id(cc), year=year))
    tot = sum(x["value"] for x in rows) or 1
    return dict(year=year, items=[dict(x, share=x["value"] / tot * 100) for x in rows[:15]])
