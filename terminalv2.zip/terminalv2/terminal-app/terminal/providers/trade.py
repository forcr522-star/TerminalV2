"""Perdagangan internasional (ekspor/impor, mitra, sektor) — sumber: OEC Tesseract (BACI/CEPII).

UN Comtrade `preview` kini menolak akses tanpa kunci (HTTP 403 pada semua permintaan), sehingga panel
SUPPLY CHAIN kehilangan data setiap kali terminal berjalan lama. Penggantinya OEC Tesseract yang memakai
dataset BACI (CEPII) — HS6, tahunan, tanpa kunci API, dan sudah diverifikasi menerima permintaan publik.

Kontrak publik modul ini sengaja tidak berubah: _call(), partners(), overview(), pair(), sectors() masih
mengembalikan bentuk data yang sama (kode M49, primaryValue, cmdCode) supaya UI dan tes lama tetap jalan.
"""
import asyncio
import datetime as dt
from ..http import get_json, cached
from ..universe import COUNTRIES

API = "https://api.oec.world/tesseract/data.jsonrecords"
CUBE = "trade_i_baci_a_92"          # BACI HS6, tahunan (1995-2024)
MEASURE = "Trade Value"

STATIC = {
    842: ("United States", "US", 39.8, -98.6), 156: ("China", "CN", 35.0, 103.0), 124: ("Canada", "CA", 56.1, -106.3), 484: ("Mexico", "MX", 23.6, -102.5),
    826: ("United Kingdom", "GB", 54.0, -2.5), 276: ("Germany", "DE", 51.2, 10.4), 392: ("Japan", "JP", 36.2, 138.3), 410: ("South Korea", "KR", 36.5, 127.9),
    36: ("Australia", "AU", -25.3, 133.8), 554: ("New Zealand", "NZ", -41.0, 174.0), 756: ("Switzerland", "CH", 46.8, 8.2), 360: ("Indonesia", "ID", -2.5, 118.0),
    528: ("Netherlands", "NL", 52.1, 5.3), 250: ("France", "FR", 46.6, 2.5), 380: ("Italy", "IT", 42.8, 12.5), 724: ("Spain", "ES", 40.4, -3.7), 56: ("Belgium", "BE", 50.6, 4.6),
    699: ("India", "IN", 21.0, 78.0), 76: ("Brazil", "BR", -14.2, -51.9), 702: ("Singapore", "SG", 1.35, 103.8), 704: ("Vietnam", "VN", 14.1, 108.3), 764: ("Thailand", "TH", 15.9, 100.9),
    458: ("Malaysia", "MY", 4.2, 102.0), 608: ("Philippines", "PH", 12.9, 121.8), 344: ("Hong Kong", "HK", 22.3, 114.2), 490: ("Taiwan", "TW", 23.7, 121.0), 643: ("Russia", "RU", 61.5, 105.3),
    792: ("Turkiye", "TR", 39.0, 35.2), 682: ("Saudi Arabia", "SA", 24.0, 45.0), 784: ("UAE", "AE", 24.3, 54.4), 710: ("South Africa", "ZA", -30.6, 22.9), 616: ("Poland", "PL", 52.1, 19.4),
    203: ("Czechia", "CZ", 49.8, 15.5), 372: ("Ireland", "IE", 53.4, -8.2), 752: ("Sweden", "SE", 62.0, 15.0), 578: ("Norway", "NO", 60.5, 8.5), 208: ("Denmark", "DK", 56.3, 9.5),
    40: ("Austria", "AT", 47.5, 14.6), 246: ("Finland", "FI", 61.9, 25.7), 620: ("Portugal", "PT", 39.4, -8.2), 300: ("Greece", "GR", 39.0, 22.0), 348: ("Hungary", "HU", 47.2, 19.5),
    152: ("Chile", "CL", -35.7, -71.5), 170: ("Colombia", "CO", 4.6, -74.1), 604: ("Peru", "PE", -9.2, -75.0), 32: ("Argentina", "AR", -38.4, -63.6), 818: ("Egypt", "EG", 26.8, 30.8),
    586: ("Pakistan", "PK", 30.4, 69.3), 50: ("Bangladesh", "BD", 23.7, 90.4), 634: ("Qatar", "QA", 25.3, 51.2), 376: ("Israel", "IL", 31.0, 34.9),
    566: ("Nigeria", "NG", 9.1, 8.7), 12: ("Algeria", "DZ", 28.0, 1.7), 504: ("Morocco", "MA", 31.8, -7.1), 804: ("Ukraine", "UA", 49.0, 31.4), 642: ("Romania", "RO", 45.9, 25.0),
    398: ("Kazakhstan", "KZ", 48.0, 66.9), 417: ("Kyrgyzstan", "KG", 41.2, 74.8), 116: ("Cambodia", "KH", 12.6, 104.9), 104: ("Myanmar", "MM", 21.9, 95.9), 496: ("Mongolia", "MN", 46.9, 103.8),
}
HS2 = {
    "01": "Live animals", "02": "Meat", "03": "Fish & seafood", "04": "Dairy & eggs", "07": "Vegetables", "08": "Fruit & nuts", "09": "Coffee, tea, spices", "10": "Cereals", "12": "Oil seeds",
    "15": "Fats & oils", "17": "Sugars", "18": "Cocoa", "21": "Misc. food", "22": "Beverages", "24": "Tobacco", "25": "Salt, stone, cement", "26": "Ores", "27": "Mineral fuels & oil",
    "28": "Inorganic chemicals", "29": "Organic chemicals", "30": "Pharmaceuticals", "31": "Fertilizers", "32": "Dyes & paints", "33": "Cosmetics", "38": "Misc. chemicals", "39": "Plastics",
    "40": "Rubber", "41": "Hides", "44": "Wood", "47": "Pulp", "48": "Paper", "52": "Cotton", "54": "Man-made filaments", "61": "Knit apparel", "62": "Woven apparel", "63": "Textile articles",
    "64": "Footwear", "68": "Stone articles", "69": "Ceramics", "70": "Glass", "71": "Precious metals & gems", "72": "Iron & steel", "73": "Iron/steel articles", "74": "Copper", "76": "Aluminium",
    "79": "Zinc", "81": "Other base metals", "82": "Tools", "83": "Misc. metal articles", "84": "Machinery", "85": "Electrical machinery", "86": "Railway", "87": "Vehicles", "88": "Aircraft",
    "89": "Ships", "90": "Optical & medical instruments", "91": "Clocks", "94": "Furniture", "95": "Toys & games", "96": "Misc. manufactured", "97": "Art", "99": "Unclassified",
}

# Kode negara OEC = <benua><ISO3>. Satu-satunya pemetaan yang perlu dirawat bila OEC menambah negara.
_CONT = {
    "US": "na", "CN": "as", "JP": "as", "KR": "as", "IN": "as", "ID": "as", "SG": "as", "VN": "as", "TH": "as", "MY": "as",
    "PH": "as", "HK": "as", "TW": "as", "PK": "as", "BD": "as", "KZ": "as", "KG": "as", "KH": "as", "MM": "as", "MN": "as",
    "RU": "as", "TR": "as", "SA": "sa", "AE": "as", "QA": "as", "IL": "as", "ZA": "af", "NG": "af", "EG": "af", "DZ": "af",
    "MA": "af", "BR": "sa", "AR": "sa", "CL": "sa", "CO": "sa", "PE": "sa", "MX": "na", "CA": "na",
    "GB": "eu", "DE": "eu", "FR": "eu", "IT": "eu", "ES": "eu", "NL": "eu", "BE": "eu", "CH": "eu", "PL": "eu", "CZ": "eu",
    "IE": "eu", "SE": "eu", "NO": "eu", "DK": "eu", "AT": "eu", "FI": "eu", "PT": "eu", "GR": "eu", "HU": "eu", "RO": "eu",
    "UA": "eu",
    "AU": "oc", "NZ": "oc",
}
_OEC = {cc: _CONT.get(cc, "eu") + COUNTRIES[cc]["iso3"].lower() for cc in COUNTRIES}
_OEC["EU"] = "eudeu"          # BACI melaporkan Euro Zone sebagai satu pelapor; Jerman = bagian terbesarnya
_M49 = {cc: COUNTRIES[cc]["m49"] for cc in COUNTRIES}
_CC_BY_M49 = {v: k for k, v in _M49.items()}
_OEC_BY_CC = _OEC
_CC_BY_OEC = {v: k for k, v in _OEC.items()}


def _id(cc):
    return _OEC.get(cc) or ("eu" + COUNTRIES[cc]["iso3"].lower())


def _num(v):
    try:
        return float(v or 0)
    except Exception:
        return 0.0


async def _query(drill, exporter=None, importer=None, year=None, limit=500):
    """Satu permintaan Tesseract (tanpa kunci API)."""
    params = {"cube": CUBE, "drilldowns": drill, "measures": MEASURE, "limit": limit}
    if year:
        params["Year"] = year
    if exporter:
        params["Exporter Country"] = exporter
    if importer:
        params["Importer Country"] = importer
    j = await get_json(API, params=params, retries=1)
    return (j or {}).get("data") or []


async def _partners_raw(cc, flow, year):
    """(total, [{code, name, value, oid}]) untuk SEMUA mitra (bukan hanya 10 negara yang punya panel).
    code = kode M49 bila mitra dikenal, selain itu negatif unik agar tetap bisa dipakai sebagai kunci heatmap."""
    if flow == "X":
        rows, drill = await _query("Importer Country", exporter=_id(cc), year=year), "Importer Country"
    else:
        rows, drill = await _query("Exporter Country", importer=_id(cc), year=year), "Exporter Country"
    total = sum(_num(r.get(MEASURE)) for r in rows)
    out = []
    for i, r in enumerate(rows):
        oid = str(r.get(drill + " ID") or "")
        val = _num(r.get(MEASURE))
        if not oid or val <= 0:
            continue
        cc2 = _CC_BY_OEC.get(oid)
        out.append(dict(code=_M49.get(cc2) if cc2 else -(i + 1), name=str(r.get(drill) or oid), value=val, oid=oid))
    out.sort(key=lambda x: -x["value"])
    return total, out


async def _one_flow(rep_cc, par_cc, flow, year):
    """Nilai ekspor (X) atau impor (M) satu pasangan pada satu tahun."""
    if flow == "X":
        rows, drill = await _query("Importer Country", exporter=_id(rep_cc), year=year), "Importer Country"
    else:
        rows, drill = await _query("Exporter Country", importer=_id(rep_cc), year=year), "Exporter Country"
    want = _id(par_cc)
    for r in rows:
        if str(r.get(drill + " ID") or "") == want:
            return _num(r.get(MEASURE))
    return None


async def _hs2(cc, flow, year):
    """Sektor HS2. Baris OEC: {HS2 ID, HS2, Trade Value}."""
    if flow == "X":
        rows = await _query("HS2", exporter=_id(cc), year=year)
    else:
        rows = await _query("HS2", importer=_id(cc), year=year)
    out = []
    for r in rows:
        cid = r.get("HS2 ID")
        if cid is None:
            continue
        try:
            code = int(cid)
        except Exception:
            continue
        # OEC menyimpan HS2 ID sebagai <grup><bab 2 digit> (101, 315, 527, 1572, 1685, 2197 ...).
        # Bab HS = dua digit terakhir; label OEC dipakai langsung supaya nama selalu tepat.
        ch = str(code % 100).zfill(2)
        out.append(dict(code=ch, name=str(r.get("HS2") or HS2.get(ch) or ch), value=_num(r.get(MEASURE))))
    return out


async def _call(reporter, partner, flow, year, cmd="TOTAL"):
    """Bentuk data lama Comtrade: reporter/partner = kode M49, flow X/M, cmd TOTAL/AG2."""
    rep_cc = _CC_BY_M49.get(int(reporter))
    if rep_cc is None:
        return []
    if cmd != "TOTAL":
        return [dict(cmdCode=r["code"], primaryValue=r["value"], name=r["name"]) for r in await _hs2(rep_cc, flow, year)]
    if partner is None:
        total, rows = await _partners_raw(rep_cc, flow, year)
        if not rows or total <= 0:
            return []          # tahun belum tersedia di BACI: biarkan partners() mencoba tahun sebelumnya
        return [dict(cmdCode="TOTAL", partnerCode=0, primaryValue=total)] + [
            dict(cmdCode="TOTAL", partnerCode=x["code"], primaryValue=x["value"], name=x["name"], oid=x["oid"]) for x in rows]
    par_cc = _CC_BY_M49.get(int(partner))
    if par_cc is None:
        return []
    one = await _one_flow(rep_cc, par_cc, flow, year)
    return [dict(cmdCode="TOTAL", partnerCode=partner, primaryValue=one)] if one is not None else []


@cached(86400)
async def _partner_ref():
    """Nama mitra tambahan. OEC sudah membawa label pada tiap baris, jadi tidak perlu permintaan kedua."""
    return {}


@cached(86400)
async def partners(reporter, flow, year=None):
    ref = await _partner_ref()
    years = [year] if year else [dt.date.today().year - 1, dt.date.today().year - 2, dt.date.today().year - 3]
    for y in years:
        try:
            rows = await _call(reporter, None, flow, y)
        except Exception:
            rows = []
        rows = [r for r in rows if r.get("cmdCode") == "TOTAL"]
        if rows:
            world = next((r for r in rows if int(r.get("partnerCode", -1)) == 0), None)
            total = (world or {}).get("primaryValue") or sum(r.get("primaryValue") or 0 for r in rows if int(r.get("partnerCode", -1)) != 0)
            out = []
            for r in rows:
                pc = int(r.get("partnerCode", -1))
                if pc == 0:
                    continue
                st = STATIC.get(pc)
                nm = st[0] if st else (r.get("name") or ref.get(pc, (str(pc), ""))[0])
                iso = st[1] if st else ref.get(pc, ("", ""))[1]
                out.append(dict(code=pc, name=nm, iso=iso, lat=st[2] if st else None, lon=st[3] if st else None, value=r.get("primaryValue") or 0))
            out.sort(key=lambda x: -x["value"])
            return dict(year=int(y), total=total, partners=out)
    return dict(year=None, total=0, partners=[])


@cached(86400)
async def overview(cc, flow="X", top=18):
    rep = COUNTRIES[cc]["m49"]
    if cc == "EU":
        rep = 276
    ex, im = await asyncio.gather(partners(rep, "X"), partners(rep, "M"))
    main = ex if flow == "X" else im
    other = im if flow == "X" else ex
    other_map = {p["code"]: p["value"] for p in other["partners"]}
    listing = []
    for p in main["partners"][:top]:
        listing.append(dict(p, share=(p["value"] / main["total"] * 100) if main["total"] else 0, counter=other_map.get(p["code"], 0)))
    top5 = sum(p["value"] for p in main["partners"][:5])
    heat = []
    exp_map = {p["code"]: p["value"] for p in ex["partners"]}
    imp_map = {p["code"]: p["value"] for p in im["partners"]}
    turn = sorted({*exp_map, *imp_map}, key=lambda c: -(exp_map.get(c, 0) + imp_map.get(c, 0)))[:12]
    names = {p["code"]: p for p in ex["partners"] + im["partners"]}
    for c in turn:
        heat.append(dict(code=c, name=names[c]["name"], exp=exp_map.get(c, 0), imp=imp_map.get(c, 0), net=exp_map.get(c, 0) - imp_map.get(c, 0)))
    return dict(
        reporter=cc, flow=flow, year=main["year"] or ex["year"] or im["year"], exports=ex["total"], imports=im["total"], balance=(ex["total"] or 0) - (im["total"] or 0),
        concentration=(top5 / main["total"] * 100) if main["total"] else 0, partners_count=len(main["partners"]), partners=listing, heat=heat,
        origin=dict(lat=_origin(cc)[0], lon=_origin(cc)[1]),
    )


def _origin(cc):
    st = STATIC.get(COUNTRIES[cc]["m49"]) or STATIC.get(276 if cc == "EU" else 0)
    return (st[2], st[3]) if st else (0, 0)


@cached(86400)
async def pair(cc, partner_code):
    rep = COUNTRIES[cc]["m49"] if cc != "EU" else 276
    year = (await partners(rep, "X"))["year"] or dt.date.today().year - 1
    res = await asyncio.gather(_call(rep, partner_code, "X", year), _call(rep, partner_code, "M", year), _call(partner_code, rep, "M", year), _call(partner_code, rep, "X", year), return_exceptions=True)

    def val(r):
        if isinstance(r, Exception):
            return None
        rows = [x for x in r if x.get("cmdCode") == "TOTAL"]
        return rows[0].get("primaryValue") if rows else None

    ex, im, mirror_im, mirror_ex = [val(r) for r in res]
    gap_ex = (ex - mirror_im) if ex is not None and mirror_im is not None else None
    gap_im = (im - mirror_ex) if im is not None and mirror_ex is not None else None
    return dict(year=year, exports=ex, imports=im, mirror_imports=mirror_im, mirror_exports=mirror_ex, gap_exports=gap_ex, gap_imports=gap_im,
                net=(ex - im) if ex is not None and im is not None else None, mirror_net=(mirror_im - mirror_ex) if mirror_im is not None and mirror_ex is not None else None)


@cached(86400)
async def sectors(cc, flow="X"):
    rep = COUNTRIES[cc]["m49"] if cc != "EU" else 276
    year = (await partners(rep, flow))["year"] or dt.date.today().year - 1
    rows = await _call(rep, 0, flow, year, "AG2")
    out = []
    for r in rows:
        code = str(r.get("cmdCode", ""))
        if not code.isdigit():
            continue
        short = code.zfill(2) if len(code) <= 2 else code
        # Label panjang OEC ikut pada baris AG2; bila tidak ada (sumber lain/tes), pakai tabel HS2.
        nm = r.get("name") or HS2.get(short) or f"HS {code}"
        out.append(dict(code=short, name=nm, value=r.get("primaryValue") or 0))
    out.sort(key=lambda x: -x["value"])
    tot = sum(x["value"] for x in out) or 1
    return dict(year=year, items=[dict(x, share=x["value"] / tot * 100) for x in out[:15]])
