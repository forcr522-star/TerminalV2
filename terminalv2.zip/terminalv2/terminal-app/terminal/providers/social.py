"""Walter Bloomberg & akun squawk lain - GRATIS, tanpa akun / API berbayar.

1) Telegram: halaman pratinjau publik channel (https://t.me/s/<channel>) - disediakan resmi oleh Telegram untuk
   channel publik, tanpa login. Bawaan: @Walter_Bloomberg = channel PIHAK KETIGA yang memposting ulang headline
   Walter Bloomberg (@DeItaone) dan beberapa sumber lain; jedanya terhadap X tidak diketahui.
2) Bluesky: API publik resmi (public.api.bsky.app, tanpa akun). Bawaan: walterbloomberg.bsky.social - akun resmi
   Walter Bloomberg di Bluesky (bio sama dengan akun X). Akun ini jarang aktif; bila aktif lagi, langsung mengalir.

Atur lewat .env: TG_CHANNELS=Walter_Bloomberg,... dan BSKY_ACCOUNTS=walterbloomberg.bsky.social,...
Jalur X API berbayar (providers/xfeed.py) tetap ada sebagai opsi tercepat, tidak wajib.
"""
import asyncio
import datetime as dt
import html as _html
import re
import time

from .. import config, health
from .. import cpu
from ..http import fetch

TG = "https://t.me/s/{ch}"
BSKY = "https://public.api.bsky.app/xrpc/app.bsky.feed.getAuthorFeed"
health.mark_optional("t.me")
health.mark_optional("public.api.bsky.app")

# label tampilan & penjelasan (ditampilkan apa adanya di menu SQUAWK)
KNOWN = {
    "walter_bloomberg": ("Walter Bloomberg", "channel Telegram pihak ketiga yang memposting ulang headline Walter Bloomberg"),
    "walterbloomberg.bsky.social": ("Walter Bloomberg", "akun resmi Walter Bloomberg di Bluesky"),
}
_state = {}            # sumber -> dict(ok, at, n, error, last_post)
_EMOJI = re.compile(r"^[\s\U0001F300-\U0001FAFF☀-➿⬀-⯿️]+")
_TAIL = re.compile(r"\s*(?:@walter_bloomberg\b.*|\|\s*Source\s*)$", re.I)


def _label(key):
    return KNOWN.get(key.lower(), (None, None))


def headline(text):
    """Teks posting -> (judul, ringkasan). Buang emoji di depan & ekor 'source', ambil baris/kalimat headline pertama."""
    t = _html.unescape(text or "").replace("\xa0", " ")
    t = _EMOJI.sub("", t).strip()
    lines = [ln.strip() for ln in re.split(r"\n+", t) if ln.strip()]
    if not lines:
        return "", ""
    first = _TAIL.sub("", lines[0]).strip(" -–|")
    rest = " ".join(_TAIL.sub("", ln) for ln in lines[1:]).strip()
    if len(first) > 220:                                  # satu paragraf panjang: potong di akhir kalimat pertama
        m = re.match(r"(.{40,220}?[.!?])\s", first + " ")
        first, rest = (m.group(1), (first[len(m.group(1)):] + " " + rest).strip()) if m else (first[:220], rest)
    return first, rest[:240]


def parse_telegram(html_text, channel):
    """HTML https://t.me/s/<channel> -> item berita (lama -> baru). Posting tanpa teks (foto saja) dilewati."""
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html_text, "lxml")
    name, why = _label(channel)
    out = []
    for msg in soup.select("div.tgme_widget_message[data-post]"):
        post = msg.get("data-post") or ""
        body = msg.select_one(".tgme_widget_message_text")
        tm = msg.select_one("a.tgme_widget_message_date time[datetime]") or msg.select_one("time[datetime]")
        if body is None or tm is None:
            continue
        for br in body.find_all("br"):
            br.replace_with("\n")
        title, summary = headline(body.get_text())
        if len(title) < 8:
            continue
        try:
            ts = int(dt.datetime.fromisoformat(tm["datetime"].replace("Z", "+00:00")).timestamp())
        except Exception:
            ts = int(time.time())
        out.append(dict(title=title, source=f"{name or '@' + channel} (TG)", link=f"https://t.me/{post}", ts=ts, summary=summary,
                        hints=["MARKETS"], feed="TG", fast=True, via=why or f"channel Telegram @{channel}"))
    return out


def parse_bsky(payload, actor):
    name, why = _label(actor)
    out = []
    for f in (payload or {}).get("feed") or []:
        p = f.get("post") or {}
        rec = p.get("record") or {}
        if f.get("reason"):                                # repost orang lain: lewati
            continue
        title, summary = headline(rec.get("text"))
        if len(title) < 8:
            continue
        try:
            ts = int(dt.datetime.fromisoformat(str(rec.get("createdAt")).replace("Z", "+00:00")).timestamp())
        except Exception:
            ts = int(time.time())
        rkey = str(p.get("uri", "")).rsplit("/", 1)[-1]
        out.append(dict(title=title, source=f"{name or actor} (Bluesky)", link=f"https://bsky.app/profile/{actor}/post/{rkey}", ts=ts, summary=summary,
                        hints=["MARKETS"], feed="BSKY", fast=True, via=why or f"akun Bluesky {actor}"))
    return out


async def _tg(ch):
    r = await fetch(TG.format(ch=ch), retries=0, quiet=True, headers={"Accept": "text/html"})
    return await cpu.parse(parse_telegram, r.text, ch)


async def _bsky(actor):
    r = await fetch(BSKY, params={"actor": actor, "limit": 20, "filter": "posts_no_replies"}, retries=0, quiet=True)
    return await cpu.parse(parse_bsky, r.json(), actor)


def sources():
    return [("TG", c, _tg) for c in config.TG_CHANNELS] + [("BSKY", a, _bsky) for a in config.BSKY_ACCOUNTS]


async def poll_once(kind=None):
    """Ambil semua sumber (atau satu jenis), masukkan ke feed berita. Mengembalikan jumlah item baru."""
    from . import news
    got = []
    for k, name, fn in sources():
        if kind and k != kind:
            continue
        key = f"{k}:{name}"
        try:
            items = await fn(name)
            got += items
            _state[key] = dict(ok=True, at=time.time(), n=len(items), error=None, last_post=max((i["ts"] for i in items), default=None),
                               via=items[0]["via"] if items else (_label(name)[1] or name))
        except Exception as exc:
            st = _state.get(key, {})
            _state[key] = dict(st, ok=False, at=time.time(), error=f"{type(exc).__name__}: {str(exc)[:120]}", via=_label(name)[1] or name)
    return news.ingest(got) if got else 0


async def run():
    """Telegram tiap TG_POLL_SEC (bawaan 30 dtk), Bluesky tiap 120 dtk."""
    from .. import http as H
    n = 0
    while True:
        try:
            added = await poll_once("TG")
            if n % max(1, 120 // max(1, config.TG_POLL_SEC)) == 0:
                added += await poll_once("BSKY")
            if added:
                H.bump()
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        n += 1
        await asyncio.sleep(config.TG_POLL_SEC)


def status():
    return {k: dict(v) for k, v in _state.items()}
