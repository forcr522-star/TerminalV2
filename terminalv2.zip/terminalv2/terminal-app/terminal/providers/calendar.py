import datetime as dt
from ..http import get_json, cached
from ..universe import CURRENCY_TO_CC, COUNTRY_ORDER

TV = "https://economic-calendar.tradingview.com/events"
TV_HEADERS = {"Origin": "https://www.tradingview.com", "Referer": "https://www.tradingview.com/", "Accept": "application/json"}
# Hanya minggu ini yang masih tersedia; ff_calendar_nextweek.json sudah 404 (dicek 22 Nov 2026).
FF = ["https://nfs.faireconomy.media/ff_calendar_thisweek.json"]
IMPACT = {"high": "HIGH", "medium": "MODERATE", "low": "LOW", "holiday": "HOLIDAY", "non-economic": "LOW"}
TV_IMPORTANCE = {1: "HIGH", 0: "MODERATE", -1: "LOW"}


def _num(s):
    if s in (None, "", "null"):
        return None
    return s


def _f(v):
    try:
        return float(v)
    except Exception:
        return None


@cached(600)
async def tv_calendar(days_back=3, days_fwd=8):
    now = dt.datetime.now(dt.timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    params = {"from": (now - dt.timedelta(days=days_back)).strftime("%Y-%m-%dT%H:%M:%S.000Z"), "to": (now + dt.timedelta(days=days_fwd)).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
              "countries": ",".join(COUNTRY_ORDER)}
    j = await get_json(TV, params=params, headers=TV_HEADERS, retries=1)
    out = []
    for r in j.get("result", []):
        try:
            when = dt.datetime.fromisoformat(str(r.get("date")).replace("Z", "+00:00")).astimezone(dt.timezone.utc)
        except Exception:
            continue
        cc = r.get("country")
        unit = f"{r.get('scale') or ''}{r.get('unit') or ''}"
        out.append(dict(date=when.strftime("%Y-%m-%d %H:%M"), country=cc, cc=cc, cur=r.get("currency"), event=r.get("title") or r.get("indicator"), impact=TV_IMPORTANCE.get(r.get("importance"), "LOW"),
                        actual=_f(r.get("actual")), forecast=_f(r.get("forecast")), previous=_f(r.get("previous")), unit=unit, period=r.get("period"), source=r.get("source")))
    if not out:
        raise ValueError("TradingView calendar kosong")
    return out


@cached(900)
async def ff_calendar():
    out = []
    for u in FF:
        try:
            rows = await get_json(u, retries=1)
        except Exception:
            continue
        for r in rows:
            cur = r.get("country")
            try:
                when = dt.datetime.fromisoformat(r.get("date")).astimezone(dt.timezone.utc)
            except Exception:
                continue
            out.append(dict(date=when.strftime("%Y-%m-%d %H:%M"), country=cur, cc=CURRENCY_TO_CC.get(cur), cur=cur, event=r.get("title"), impact=IMPACT.get((r.get("impact") or "low").lower(), "LOW"),
                            actual=_num(r.get("actual")), forecast=_num(r.get("forecast")), previous=_num(r.get("previous")), unit=""))
    return out


async def events():
    try:
        return await tv_calendar()
    except Exception:
        return await ff_calendar()


def cc_of(ev):
    if ev.get("cc"):
        return ev["cc"]
    return CURRENCY_TO_CC.get(ev.get("cur") or "")
