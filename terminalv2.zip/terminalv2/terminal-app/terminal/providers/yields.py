"""Yield obligasi pemerintah per negara dari sumber gratis tanpa key, dengan rantai cadangan.

Setiap adapter mengembalikan {tenor: [(tanggal_iso, nilai_persen)]}. Kolom dipilih dari LABEL TENOR di data
itu sendiri (bukan dari ID seri yang dihafal), sehingga perubahan ID tidak menghasilkan tenor yang salah label.
collect(cc) menjalankan rantai per negara sampai kurva inti (2Y & 10Y) terpenuhi; tenor pertama yang tersedia
menang. Adapter yang gagal dicatat di `notes` supaya UI bisa menjelaskan kenapa sebuah nilai kosong.
"""
import asyncio
import csv
import datetime as dt
import io
import json
import re
from ..http import get_json, get_text
from .. import health
from . import fred

TENORS = ["1M", "2M", "3M", "4M", "6M", "1Y", "2Y", "3Y", "5Y", "7Y", "10Y", "15Y", "20Y", "30Y"]
KEEP = 400


# ---------------------------------------------------------------------------------------------- util
def tenor_of(label):
    """'2 Yr' / '2YR' / 'SR_10Y' / '6 Mo' / '3 Months' / '10J' -> '2Y' / '10Y' / '6M' / '3M'. Tenor tak dikenal -> None."""
    s = str(label).strip().lower().replace("_", " ")
    m = re.search(r"(?<![\d.])(\d{1,2})\s*(years?|yrs?|yr|y|jahre?|j|months?|mos?|mo|m)(?![a-z])", s)
    if not m:
        return None
    n, u = int(m.group(1)), m.group(2)
    t = f"{n}{'M' if u.startswith('m') else 'Y'}"
    return t if t in TENORS else None


def _iso(d):
    d = str(d).strip()
    if len(d) == 10 and d[4] == "-" and d[7] == "-" and d[:4].isdigit():
        return d                       # jalur cepat: sudah ISO (mayoritas baris SNB/BoE) - strptime 7 format itu lambat
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%Y/%m/%d", "%d %b %Y", "%d-%b-%Y", "%Y-%m", "%b %Y"):
        try:
            return dt.datetime.strptime(d, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def _num(v):
    try:
        f = float(str(v).strip().replace(",", ""))
    except (TypeError, ValueError):
        return None
    return f if f == f else None


def _trim(out):
    return {t: sorted(set(rows))[-KEEP:] for t, rows in out.items() if rows}


# ---------------------------------------------------------------------------------------------- parser murni (diuji dengan fixture)
def parse_treasury_csv(text):
    out = {}
    for row in csv.DictReader(io.StringIO(text)):
        d = _iso(row.get("Date", ""))
        if not d:
            continue
        for col, val in row.items():
            if col == "Date":
                continue
            t, v = tenor_of(col), _num(val)
            if t and v is not None:
                out.setdefault(t, []).append((d, v))
    return _trim(out)


def parse_ecb_csv(text):
    rows = []
    for row in csv.DictReader(io.StringIO(text)):
        d, v = _iso(row.get("TIME_PERIOD", "")), _num(row.get("OBS_VALUE"))
        if d and v is not None:
            rows.append((d, v))
    return sorted(rows)


def parse_mof_csv(text):
    lines = text.splitlines()
    start = next((i for i, ln in enumerate(lines) if ln.strip().lower().startswith("date")), None)
    if start is None:
        raise ValueError("header MOF tidak ditemukan")
    rd = csv.reader(lines[start:])
    head = next(rd)
    cols = {i: tenor_of(h) for i, h in enumerate(head) if i > 0}
    out = {}
    for row in rd:
        if not row:
            continue
        d = _iso(row[0])
        if not d:
            continue
        for i, t in cols.items():
            if t and i < len(row):
                v = _num(row[i])
                if v is not None:
                    out.setdefault(t, []).append((d, v))
    return _trim(out)


def parse_boc(j):
    out = {}
    for ob in j.get("observations", []):
        d = _iso(ob.get("d", ""))
        if not d:
            continue
        for k, v in ob.items():
            if k == "d" or not isinstance(v, dict):
                continue
            label = k.upper()
            t = "30Y" if "LONG" in label else tenor_of(label.replace("BD.CDN.", "").split(".")[0])
            val = _num(v.get("v"))
            if t and val is not None:
                out.setdefault(t, []).append((d, val))
    return _trim(out)


def parse_rba_csv(text):
    """F2: baris judul (Title) memuat 'Australian Government 2 year bond' -> pilih kolom dari judul."""
    rows = list(csv.reader(io.StringIO(text)))
    title_i = next((i for i, r in enumerate(rows) if r and r[0].strip().lower() == "title"), None)
    if title_i is None:
        raise ValueError("baris Title RBA tidak ditemukan")
    titles = rows[title_i]
    cols = {}
    for i, t in enumerate(titles):
        tl = t.lower()
        if i == 0 or "government" not in tl or "bond" not in tl or "index" in tl:
            continue
        tn = tenor_of(t)
        if tn:
            cols[i] = tn
    if not cols:
        raise ValueError("kolom obligasi RBA tidak ditemukan")
    out = {}
    for r in rows[title_i + 1:]:
        d = _iso(r[0]) if r else None
        if not d:
            continue
        for i, t in cols.items():
            if i < len(r):
                v = _num(r[i])
                if v is not None:
                    out.setdefault(t, []).append((d, v))
    return _trim(out)


def parse_snb_csv(text):
    lines = [ln for ln in text.splitlines() if ln.strip()]
    start = next((i for i, ln in enumerate(lines) if ln.replace('"', '').lower().startswith("date;")), None)
    if start is None:
        raise ValueError("header SNB tidak ditemukan")
    out = {}
    for row in csv.reader(lines[start + 1:], delimiter=";"):
        if len(row) < 3:
            continue
        d, t, v = _iso(row[0]), tenor_of(row[1]), _num(row[2])
        if d and t and v is not None:
            out.setdefault(t, []).append((d, v))
    return _trim(out)


def parse_wgb(html):
    """Tabel kurva yield worldgovernmentbonds.com -> {tenor: nilai terbaru}."""
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "lxml")
    found = {}
    for tr in soup.find_all("tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
        if len(cells) < 2:
            continue
        t = tenor_of(cells[0])
        if not t or not re.fullmatch(r"\d{1,2}\s*(months?|years?)", cells[0].strip().lower()):
            continue
        for c in cells[1:]:
            m = re.fullmatch(r"(-?\d+(?:\.\d+)?)\s*%", c.strip())
            if m:
                found[t] = float(m.group(1))
                break
    if not found:
        text = re.sub(r"\s+", " ", soup.get_text(" "))
        for m in re.finditer(r"(\d{1,2}) (months?|years?) (-?\d+(?:\.\d+)?)\s*%", text, flags=re.I):
            t = tenor_of(f"{m.group(1)} {m.group(2)}")
            if t and t not in found:
                found[t] = float(m.group(3))
    return found


# ---------------------------------------------------------------------------------------------- adapter jaringan
async def ad_fred_us(cc):
    ids = [("1M", "DGS1MO"), ("3M", "DGS3MO"), ("6M", "DGS6MO"), ("1Y", "DGS1"), ("2Y", "DGS2"), ("3Y", "DGS3"), ("5Y", "DGS5"), ("7Y", "DGS7"), ("10Y", "DGS10"), ("20Y", "DGS20"), ("30Y", "DGS30")]
    start = str(dt.date.today().year - 2) + "-01-01"
    res = await fred.many([s for _, s in ids], start=start)
    out = {t: res.get(s) or [] for t, s in ids}
    out = {t: r[-KEEP:] for t, r in out.items() if r}
    if not out:
        raise ValueError("FRED tanpa data")
    return out


async def ad_treasury_us(cc):
    year = dt.date.today().year
    out = {}
    for y in (year - 1, year):
        url = f"https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/{y}/all"
        try:
            txt = await get_text(url, params={"type": "daily_treasury_yield_curve", "field_tdr_date_value": y, "page": "", "_format": "csv"}, retries=1)
        except Exception:
            if y == year:
                raise
            continue
        for t, rows in parse_treasury_csv(txt).items():
            out.setdefault(t, []).extend(rows)
    if not out:
        raise ValueError("Treasury tanpa data")
    return _trim(out)


async def ad_yahoo_us(cc):
    from . import yahoo
    mp = {"^IRX": "3M", "^FVX": "5Y", "^TNX": "10Y", "^TYX": "30Y"}
    data = await yahoo.closes(tuple(mp), "1y")
    out = {}
    for s, t in mp.items():
        ser = data.get(s)
        if ser is not None and len(ser):
            out[t] = [(str(i)[:10], float(v)) for i, v in ser.items()]
    if not out:
        raise ValueError("Yahoo tanpa data")
    return _trim(out)


async def ad_ecb_eu(cc):
    start = (dt.date.today() - dt.timedelta(days=500)).isoformat()
    tens = ["1Y", "2Y", "3Y", "5Y", "7Y", "10Y", "20Y", "30Y"]

    async def one(t):
        url = f"https://data-api.ecb.europa.eu/service/data/YC/B.U2.EUR.4F.G_N_A.SV_C_YM.SR_{t}"
        return t, parse_ecb_csv(await get_text(url, params={"format": "csvdata", "startPeriod": start}, retries=1))
    res = await asyncio.gather(*[one(t) for t in tens], return_exceptions=True)
    out = {t: r[-KEEP:] for x in res if not isinstance(x, Exception) for t, r in [x] if r}
    if not out:
        raise ValueError("ECB tanpa data")
    return out


# URL MOF berubah lagi: berkas Inggris kini memakai akhiran "e" (jgbcme). Kandidat lama (jgbcm_*) sudah 404.
# Dicoba berurutan; yang pertama valid dipakai.
MOF_URLS = [
    "https://www.mof.go.jp/english/policy/jgbs/reference/interest_rate/historical/jgbcme_all.csv",
    "https://www.mof.go.jp/english/policy/jgbs/reference/interest_rate/jgbcme.csv",
]


async def ad_mof_jp(cc):
    err = None
    for url in MOF_URLS:
        try:
            out = await asyncio.to_thread(parse_mof_csv, await get_text(url, retries=0, quiet=True))
            if out:
                return out
        except Exception as exc:
            err = exc
    health.host_fail("www.mof.go.jp", err or ValueError("MOF tanpa data"), MOF_URLS[0])
    raise err or ValueError("MOF tanpa data")


BOE_SERIES = {"IUDSNPY": "5Y", "IUDMNPY": "10Y", "IUDLNPY": "20Y"}


def parse_boe_csv(text):
    """IADB Bank of England (CSVF=TN): header 'DATE,IUDSNPY,...' lalu baris '02 Jan 2024,3.80,...'."""
    rd = csv.reader(io.StringIO(text))
    head = next(rd, None)
    if not head or head[0].strip().upper() != "DATE":
        raise ValueError("respons BoE bukan CSV IADB")
    cols = {i: BOE_SERIES[c.strip().upper()] for i, c in enumerate(head) if c.strip().upper() in BOE_SERIES}
    out = {}
    for row in rd:
        d = _iso(row[0]) if row else None
        if not d:
            continue
        for i, t in cols.items():
            if i < len(row):
                v = _num(row[i])
                if v is not None:
                    out.setdefault(t, []).append((d, v))
    return _trim(out)


async def ad_boe_gb(cc):
    start = (dt.date.today() - dt.timedelta(days=500)).strftime("%d/%b/%Y")
    txt = await get_text("https://www.bankofengland.co.uk/boeapps/database/_iadb-fromshowcolumns.asp", params={
        "csv.x": "yes", "Datefrom": start, "Dateto": "now", "SeriesCodes": ",".join(BOE_SERIES), "CSVF": "TN", "UsingCodes": "Y", "VPD": "Y", "VFD": "N"}, retries=1)
    out = await asyncio.to_thread(parse_boe_csv, txt)   # parse di thread: CSV ribuan baris tidak menahan event loop
    if not out:
        raise ValueError("BoE tanpa data")
    return out


async def ad_boc_ca(cc):
    names = ["BD.CDN.2YR.DQ.YLD", "BD.CDN.3YR.DQ.YLD", "BD.CDN.5YR.DQ.YLD", "BD.CDN.7YR.DQ.YLD", "BD.CDN.10YR.DQ.YLD", "BD.CDN.LONG.DQ.YLD"]
    j = await get_json(f"https://www.bankofcanada.ca/valet/observations/{','.join(names)}/json", params={"recent": KEEP}, retries=1)
    out = await asyncio.to_thread(parse_boc, j)   # parse di thread: CSV ribuan baris tidak menahan event loop
    if not out:
        raise ValueError("BoC tanpa data")
    return out


async def ad_rba_au(cc):
    txt = await get_text("https://www.rba.gov.au/statistics/tables/csv/f2-data.csv", retries=1)
    out = await asyncio.to_thread(parse_rba_csv, txt)   # parse di thread: CSV ribuan baris tidak menahan event loop
    if not out:
        raise ValueError("RBA tanpa data")
    return out


async def ad_snb_ch(cc):
    txt = await get_text("https://data.snb.ch/api/cube/rendoblid/data/csv/en", retries=1)
    out = await asyncio.to_thread(parse_snb_csv, txt)   # parse di thread: CSV ribuan baris tidak menahan event loop
    if not out:
        raise ValueError("SNB tanpa data")
    return out


# Seri 10Y OECD MEI di FRED hanya ada untuk anggota OECD. CN & ID TIDAK ada (permintaannya selalu gagal dan dulu membuat
# host FRED masuk masa jeda, sehingga seri FRED negara lain - mis. NZ - ikut kosong), jadi tidak dicantumkan.
# Kode negara di ID seri FRED adalah 2 huruf (IRLTLT01NZM156N); dulu dipakai kode 3 huruf (IRLTLT01NZLM156N) -> selalu 404.
OECD3 = {"US": "US", "EU": "DE", "JP": "JP", "GB": "GB", "CA": "CA", "AU": "AU", "NZ": "NZ", "CH": "CH"}
# Suku bunga pasar uang 3 bulan (antarbank / bank bill, OECD MEI di FRED, bulanan): ujung pendek kurva untuk negara yang
# tidak punya yield obligasi pendek harian dari sumber gratis.
SHORT3M = {"CN": "IR3TIB01CNM156N", "ID": "IR3TIB01IDM156N", "NZ": "IR3TIB01NZM156N"}


async def ad_fred_oecd(cc):
    """10Y bulanan (OECD MEI di FRED): cadangan berhistori untuk negara tanpa API bank sentral gratis."""
    iso = OECD3.get(cc)
    if not iso:
        raise ValueError("tidak ada kode")
    rows = await fred.series(f"IRLTLT01{iso}M156N", start=str(dt.date.today().year - 8) + "-01-01")
    return {"10Y": rows[-KEEP:]}


async def ad_fred_short(cc):
    """3M pasar uang bulanan (OECD MEI di FRED) -> tenor 3M (label sumber menyebut 'pasar uang', bukan obligasi)."""
    sid = SHORT3M.get(cc)
    if not sid:
        raise ValueError("tidak ada kode")
    rows = await fred.series(sid, start=str(dt.date.today().year - 8) + "-01-01")
    if not rows:
        raise ValueError("FRED kosong")
    return {"3M": rows[-KEEP:]}


WGB_SLUG = {"US": "united-states", "CN": "china", "EU": "germany", "JP": "japan", "GB": "united-kingdom", "CA": "canada", "AU": "australia", "NZ": "new-zealand", "CH": "switzerland", "ID": "indonesia"}


async def ad_wgb(cc):
    html = await get_text(f"https://www.worldgovernmentbonds.com/country/{WGB_SLUG[cc]}/", retries=1)
    cur = await asyncio.to_thread(parse_wgb, html)
    if not cur:
        raise ValueError("tabel yield WGB tidak ditemukan")
    today = dt.date.today().isoformat()
    return {t: [(today, v)] for t, v in cur.items()}


# worldgovernmentbonds.com kini memuat tabel yield lewat JavaScript; adapter ad_wgb selalu gagal sehingga dikeluarkan
# dari rantai (hemat 1 permintaan per negara per pembaruan). Fungsinya tetap ada bila situsnya kembali bisa dibaca.
CHAIN = {
    "US": [("FRED", ad_fred_us), ("US Treasury", ad_treasury_us), ("Yahoo", ad_yahoo_us)],
    "EU": [("ECB", ad_ecb_eu), ("FRED/OECD (DE)", ad_fred_oecd)],
    "JP": [("MOF Japan", ad_mof_jp), ("FRED/OECD", ad_fred_oecd)],
    "CA": [("Bank of Canada", ad_boc_ca), ("FRED/OECD", ad_fred_oecd)],
    "AU": [("RBA", ad_rba_au), ("FRED/OECD", ad_fred_oecd)],
    "CH": [("SNB", ad_snb_ch), ("FRED/OECD", ad_fred_oecd)],
    "GB": [("Bank of England", ad_boe_gb), ("FRED/OECD", ad_fred_oecd)],
    "NZ": [("FRED/OECD", ad_fred_oecd), ("FRED/OECD 3M pasar uang", ad_fred_short)],
    "CN": [("FRED/OECD 3M pasar uang", ad_fred_short)],
    "ID": [("FRED/OECD 3M pasar uang", ad_fred_short)],
}
# Tenor yang memang tidak dipublikasikan sebagai benchmark untuk negara tertentu (dipakai untuk pesan UI yang jujur)
NO_BENCHMARK = {"ID": {"2Y": "Indonesia tidak menerbitkan benchmark 2Y; tersedia 5Y dan 10Y"},
                "GB": {"2Y": "Bank of England (IADB) tidak menerbitkan seri harian 2Y; dipakai 5Y sebagai ujung pendek"}}
# Alasan yang jujur bila 10Y harian tidak ada dari sumber gratis yang bisa dijangkau
NO_10Y = {"CN": "yield obligasi pemerintah China belum tersedia dari sumber data terbuka; sebagai gantinya ditampilkan suku bunga pasar uang 3M (OECD)",
          "ID": "yield SUN Indonesia belum tersedia dari sumber data terbuka; sebagai gantinya ditampilkan suku bunga pasar uang 3M (OECD)"}


ADAPTER_HOST = {"FRED": "fred.stlouisfed.org", "FRED/OECD": "fred.stlouisfed.org", "US Treasury": "home.treasury.gov", "ECB": "data-api.ecb.europa.eu",
                "MOF Japan": "www.mof.go.jp", "Bank of Canada": "www.bankofcanada.ca", "RBA": "www.rba.gov.au", "SNB": "data.snb.ch",
                "Bank of England": "www.bankofengland.co.uk", "WorldGovernmentBonds": "www.worldgovernmentbonds.com"}


def _host_of(name):
    for k in sorted(ADAPTER_HOST, key=len, reverse=True):
        if name.startswith(k):
            return ADAPTER_HOST[k]
    return None


def _good(got):
    return "10Y" in got and "2Y" in got and len(got) >= 4


async def collect(cc):
    got, notes = {}, []
    for name, fn in CHAIN.get(cc, []):
        if _good(got):
            break
        try:
            res = await fn(cc)
        except Exception as exc:
            notes.append(dict(src=name, error=f"{type(exc).__name__}: {str(exc)[:90]}"))
            continue
        added = 0
        for t, rows in res.items():
            if not rows:
                continue
            if t not in got:
                got[t] = (name, rows)
                added += 1
            else:
                # Sumber bulanan (OECD) tertinggal; bila sumber lain punya titik lebih baru (>10 hari), tambahkan sebagai nilai terkini.
                last_src, last_rows = got[t]
                newer = [r for r in rows if r[0] > last_rows[-1][0]]
                if newer:
                    gap = (dt.date.fromisoformat(newer[-1][0]) - dt.date.fromisoformat(last_rows[-1][0])).days
                    if gap > 10:
                        got[t] = (f"{last_src}+{name}", last_rows + newer[-1:])
                        added += 1
        if not added:
            notes.append(dict(src=name, error="tanpa tenor baru"))
    if got:
        by = ", ".join(dict.fromkeys(s_ for s_, _ in got.values()))
        for n in notes:
            host = _host_of(n["src"])
            if host and "tanpa tenor baru" not in n["error"]:
                health.cover(host, by)
    order = {t: i for i, t in enumerate(TENORS)}
    curve = []
    for t in sorted(got, key=lambda x: order[x]):
        src, rows = got[t]
        curve.append(dict(tenor=t, y=rows[-1][1], prev=rows[-2][1] if len(rows) > 1 else None, date=rows[-1][0], src=src, points=len(rows)))
    hist = {t: rows[-300:] for t, (s, rows) in got.items() if len(rows) > 1}
    why = dict(NO_BENCHMARK.get(cc, {}), **({"10Y": NO_10Y[cc]} if cc in NO_10Y else {}))
    missing = {t: why.get(t, "tidak tersedia dari sumber gratis") for t in ("2Y", "10Y") if t not in got}
    return dict(curve=curve, h10=hist.get("10Y", []), h2=hist.get("2Y", []), hist=hist, src=", ".join(dict.fromkeys(s for s, _ in got.values())) or None, notes=notes, missing=missing)
