"""GDELT 2.0 Event Database: file ekspor tiap 15 menit (gratis, tanpa key) -> titik panas konflik 24 jam terakhir.

Pengganti GDELT GEO 2.0 API (`api.gdeltproject.org/api/v2/geo/geo`), yang kini membalas 404 terus-menerus sehingga
"dinonaktifkan sementara" di status sumber. File ekspor resmi berisi event berkode CAMEO dengan koordinat lokasi
kejadian (ActionGeo), jumlah penyebutan media dan URL sumber.

Data GDELT dikodekan mesin dan cukup berisik, jadi disaring:
  - hanya akar CAMEO 14 (protes), 15 (postur militer), 18 (serangan), 19 (pertempuran), 20 (kekerasan massal);
  - lokasi setingkat NEGARA dibuang (titik tengah negara bukan lokasi kejadian);
  - titik dijumlahkan per lokasi selama 24 jam; peta memakai jumlah penyebutan, bukan satu artikel.
File diambil bertahap: 8 file terbaru saat start, lalu hanya file baru (±100 KB per 15 menit).
"""
import asyncio
import datetime as dt
import io
import zipfile

from .. import cpu
from ..http import fetch, get_text, cached
from .. import health

LAST = "https://data.gdeltproject.org/gdeltv2/lastupdate.txt"
ROOTS = {"14": "PROTEST", "15": "MILITARY POSTURE", "18": "ASSAULT", "19": "FIGHT", "20": "MASS VIOLENCE"}
WINDOW = 24 * 3600
FIRST = 8            # file pertama kali diambil (2 jam)
PER_REFRESH = 8      # paling banyak file yang diunduh per penyegaran
STEP = dt.timedelta(minutes=15)
_files = {}          # "YYYYMMDDHHMMSS" -> [event, ...]
_lock = asyncio.Lock()
health.mark_optional("data.gdeltproject.org")


def parse_export(raw):
    """Isi zip ekspor GDELT 2.0 (61 kolom, dipisah tab) -> event konflik yang lokasinya spesifik."""
    out = []
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        text = z.read(z.namelist()[0]).decode("utf-8", "replace")
    for line in text.splitlines():
        c = line.split("\t")
        if len(c) < 61 or c[28] not in ROOTS or c[51] in ("", "1") or not c[56] or not c[57]:
            continue
        try:
            lat, lon = float(c[56]), float(c[57])
            mentions = int(c[31] or 1)
        except ValueError:
            continue
        out.append(dict(lat=lat, lon=lon, name=c[52], cc=c[53], root=c[28], mentions=mentions, url=c[60]))
    return out


def _ts(name):
    return dt.datetime.strptime(name, "%Y%m%d%H%M%S").replace(tzinfo=dt.timezone.utc)


async def _refresh():
    txt = await get_text(LAST, retries=1, quiet=True)
    url = next((ln.split()[2] for ln in txt.splitlines() if ln.strip().endswith(".export.CSV.zip")), None)
    if not url:
        return
    url = url.replace("http://", "https://")              # server yang sama melayani https
    latest = url.rsplit("/", 1)[1].split(".")[0]
    t_latest = _ts(latest)
    want = [(t_latest - i * STEP).strftime("%Y%m%d%H%M%S") for i in range(WINDOW // 900)]
    missing = [w for w in want if w not in _files][: (FIRST if not _files else PER_REFRESH)]
    for name in missing:
        try:
            r = await fetch(url.replace(latest, name), retries=1, quiet=True)
            _files[name] = await cpu.parse(parse_export, r.content)
        except Exception:
            _files[name] = []                               # file hilang/rusak: jangan diminta berulang
    cut = (t_latest - dt.timedelta(seconds=WINDOW)).strftime("%Y%m%d%H%M%S")
    for k in [k for k in _files if k < cut]:
        _files.pop(k, None)


@cached(600, stale_ok=6 * 3600)
async def hotspots(limit=250):
    """Titik panas 24 jam: [{lat, lon, name, count, mentions, kind, url}] urut jumlah penyebutan."""
    async with _lock:
        await _refresh()
    acc = {}
    for evs in _files.values():
        for e in evs:
            k = (round(e["lat"], 2), round(e["lon"], 2))
            a = acc.setdefault(k, dict(lat=e["lat"], lon=e["lon"], name=e["name"], count=0, mentions=0, roots={}, url=e["url"], top=0))
            a["count"] += 1
            a["mentions"] += e["mentions"]
            a["roots"][e["root"]] = a["roots"].get(e["root"], 0) + e["mentions"]
            if e["mentions"] > a["top"]:
                a["top"], a["url"] = e["mentions"], e["url"]
    out = []
    for a in sorted(acc.values(), key=lambda x: -x["mentions"])[:limit]:
        kind = ROOTS[max(a["roots"], key=a["roots"].get)]
        out.append(dict(lat=round(a["lat"], 3), lon=round(a["lon"], 3), name=a["name"], count=a["count"], mentions=a["mentions"], kind=kind, url=a["url"]))
    return out


def files_loaded():
    return len(_files)
