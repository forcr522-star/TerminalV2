"""Layer CYBER globe: serangan siber yang DILAPORKAN (tanpa key, tanpa angka rekaan).

Sumber:
  1. ransomware.live (API publik v2 `recentvictims`): korban ransomware yang diumumkan kelompok peretas, dengan negara,
     sektor dan waktu ditemukan. Tautan yang diberikan hanya halaman ransomware.live (bukan situs bocoran .onion).
  2. Berita siber dari feed berita terminal (serangan, peretasan, ransomware, DDoS, kebocoran data), lokasinya dari
     nama tempat di judul bila ada.
Tidak ada "garis serangan" dari negara A ke B: sumber terbuka tidak memberi asal serangan yang dapat dipercaya.
"""
import datetime as dt
import re
import time

from .. import cpu
from ..http import get_json, cached
from .. import health
from . import news as N

URL = "https://api.ransomware.live/v2/recentvictims"
health.mark_optional("api.ransomware.live")

# ISO2 -> (nama di world.geojson, lat, lon titik tengah)
ISO2 = {
    "US": ("United States of America", 39.8, -98.6), "CA": ("Canada", 56.1, -106.3), "MX": ("Mexico", 23.6, -102.5), "BR": ("Brazil", -14.2, -51.9),
    "AR": ("Argentina", -38.4, -63.6), "CL": ("Chile", -35.7, -71.5), "CO": ("Colombia", 4.6, -74.1), "PE": ("Peru", -9.2, -75.0), "VE": ("Venezuela", 6.4, -66.6),
    "EC": ("Ecuador", -1.8, -78.2), "BO": ("Bolivia", -16.3, -63.6), "PY": ("Paraguay", -23.4, -58.4), "UY": ("Uruguay", -32.5, -55.8), "PA": ("Panama", 8.5, -80.8),
    "CR": ("Costa Rica", 9.7, -83.8), "GT": ("Guatemala", 15.8, -90.2), "HN": ("Honduras", 15.2, -86.2), "SV": ("El Salvador", 13.8, -88.9), "NI": ("Nicaragua", 12.9, -85.2),
    "DO": ("Dominican Rep.", 18.7, -70.2), "PR": ("Puerto Rico", 18.2, -66.5), "JM": ("Jamaica", 18.1, -77.3), "CU": ("Cuba", 21.5, -77.8), "TT": ("Trinidad and Tobago", 10.7, -61.2),
    "GB": ("United Kingdom", 54.0, -2.5), "IE": ("Ireland", 53.4, -8.2), "FR": ("France", 46.6, 2.5), "DE": ("Germany", 51.2, 10.4), "IT": ("Italy", 42.8, 12.5),
    "ES": ("Spain", 40.4, -3.7), "PT": ("Portugal", 39.4, -8.2), "NL": ("Netherlands", 52.1, 5.3), "BE": ("Belgium", 50.6, 4.6), "LU": ("Luxembourg", 49.8, 6.1),
    "CH": ("Switzerland", 46.8, 8.2), "AT": ("Austria", 47.5, 14.6), "DK": ("Denmark", 56.3, 9.5), "SE": ("Sweden", 62.0, 15.0), "NO": ("Norway", 60.5, 8.5),
    "FI": ("Finland", 61.9, 25.7), "IS": ("Iceland", 64.9, -18.6), "PL": ("Poland", 52.1, 19.4), "CZ": ("Czechia", 49.8, 15.5), "SK": ("Slovakia", 48.7, 19.7),
    "HU": ("Hungary", 47.2, 19.5), "RO": ("Romania", 45.9, 25.0), "BG": ("Bulgaria", 42.7, 25.5), "GR": ("Greece", 39.0, 22.0), "HR": ("Croatia", 45.1, 15.2),
    "SI": ("Slovenia", 46.2, 14.9), "RS": ("Serbia", 44.0, 21.0), "BA": ("Bosnia and Herz.", 43.9, 17.7), "MK": ("Macedonia", 41.6, 21.7), "AL": ("Albania", 41.2, 20.2),
    "ME": ("Montenegro", 42.7, 19.4), "XK": ("Kosovo", 42.6, 20.9), "MD": ("Moldova", 47.4, 28.4), "UA": ("Ukraine", 49.0, 31.4), "BY": ("Belarus", 53.7, 27.9),
    "LT": ("Lithuania", 55.2, 23.9), "LV": ("Latvia", 56.9, 24.6), "EE": ("Estonia", 58.6, 25.0), "RU": ("Russia", 61.5, 105.3), "TR": ("Turkey", 39.0, 35.2),
    "CY": ("Cyprus", 35.1, 33.4), "MT": ("Malta", 35.9, 14.4), "GE": ("Georgia", 42.3, 43.4), "AM": ("Armenia", 40.1, 45.0), "AZ": ("Azerbaijan", 40.1, 47.6),
    "IL": ("Israel", 31.0, 34.9), "PS": ("Palestine", 31.9, 35.2), "LB": ("Lebanon", 33.9, 35.9), "JO": ("Jordan", 30.6, 36.2), "SY": ("Syria", 34.8, 38.9),
    "IQ": ("Iraq", 33.2, 43.7), "IR": ("Iran", 32.4, 53.7), "SA": ("Saudi Arabia", 24.0, 45.0), "AE": ("United Arab Emirates", 24.3, 54.4), "QA": ("Qatar", 25.3, 51.2),
    "KW": ("Kuwait", 29.3, 47.5), "BH": ("Bahrain", 26.0, 50.6), "OM": ("Oman", 21.5, 55.9), "YE": ("Yemen", 15.5, 47.6), "EG": ("Egypt", 26.8, 30.8),
    "LY": ("Libya", 26.3, 17.2), "TN": ("Tunisia", 33.9, 9.5), "DZ": ("Algeria", 28.0, 1.7), "MA": ("Morocco", 31.8, -7.1), "NG": ("Nigeria", 9.1, 8.7),
    "GH": ("Ghana", 7.9, -1.0), "CI": ("Côte d'Ivoire", 7.5, -5.5), "SN": ("Senegal", 14.5, -14.5), "BJ": ("Benin", 9.3, 2.3), "TG": ("Togo", 8.6, 0.8),
    "CM": ("Cameroon", 7.4, 12.4), "KE": ("Kenya", -0.02, 37.9), "UG": ("Uganda", 1.4, 32.3), "TZ": ("Tanzania", -6.4, 34.9), "RW": ("Rwanda", -1.9, 29.9),
    "ET": ("Ethiopia", 9.1, 40.5), "ZA": ("South Africa", -30.6, 22.9), "NA": ("Namibia", -22.9, 18.5), "BW": ("Botswana", -22.3, 24.7), "ZW": ("Zimbabwe", -19.0, 29.2),
    "ZM": ("Zambia", -13.1, 27.8), "MZ": ("Mozambique", -18.7, 35.5), "AO": ("Angola", -11.2, 17.9), "MU": ("Mauritius", -20.3, 57.6), "MG": ("Madagascar", -18.8, 46.9),
    "IN": ("India", 21.0, 78.0), "PK": ("Pakistan", 30.4, 69.3), "BD": ("Bangladesh", 23.7, 90.4), "LK": ("Sri Lanka", 7.9, 80.8), "NP": ("Nepal", 28.4, 84.1),
    "CN": ("China", 35.0, 103.0), "HK": ("Hong Kong", 22.3, 114.2), "MO": ("Macao", 22.2, 113.5), "TW": ("Taiwan", 23.7, 121.0), "JP": ("Japan", 36.2, 138.3),
    "KR": ("South Korea", 36.5, 127.9), "KP": ("North Korea", 40.3, 127.5), "MN": ("Mongolia", 46.9, 103.8), "KZ": ("Kazakhstan", 48.0, 66.9), "UZ": ("Uzbekistan", 41.4, 64.6),
    "ID": ("Indonesia", -2.5, 118.0), "MY": ("Malaysia", 4.2, 102.0), "SG": ("Singapore", 1.35, 103.8), "TH": ("Thailand", 15.9, 100.9), "VN": ("Vietnam", 14.1, 108.3),
    "PH": ("Philippines", 12.9, 121.8), "KH": ("Cambodia", 12.6, 104.9), "MM": ("Myanmar", 21.9, 95.9), "LA": ("Laos", 19.9, 102.5), "BN": ("Brunei", 4.5, 114.7),
    "AU": ("Australia", -25.3, 133.8), "NZ": ("New Zealand", -41.0, 174.0), "PG": ("Papua New Guinea", -6.3, 143.9), "FJ": ("Fiji", -17.7, 178.1),
}
# kata yang hanya bermakna siber ("breach"/"leaked data" saja juga dipakai untuk sanksi, data korban perang, dsb.)
CYBER_KW = ["cyberattack", "cyberattacks", "cyber-attack", "cyber attack", "cyber attacks", "cybersecurity", "cyber security", "cybercrime",
            "cybercriminals", "cyber incident", "cyber espionage", "cyber threat", "cyber warfare", "cyber unit", "cyber risk", "cyberdefense",
            "cyber defence", "hacker", "hackers", "hacked", "hacking", "hack", "ransomware", "ddos", "data breach", "security breach", "breached",
            "malware", "spyware", "phishing", "zero-day", "botnet", "wiper malware", "infostealer"]
# batas kata di kedua sisi: "Cyber Tire" / "Cybertruck" / "mined" tidak ikut
_KW_RE = re.compile(r"(?<![a-z])(" + "|".join(re.escape(k) for k in sorted(CYBER_KW, key=len, reverse=True)) + r")(?![a-z])", re.I)


def _ts(s):
    try:
        return dt.datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()
    except Exception:
        return None


def _sector(desc):
    d = str(desc or "").split("|")[0].strip()
    return d.split("·")[0].strip() if "·" in d else ""


@cached(900, persist=True, stale_ok=12 * 3600)
async def ransomware():
    """Korban ransomware terbaru (maks. 100) dari ransomware.live."""
    j = await get_json(URL, retries=1, quiet=True)
    out = [_victim(v) for v in (j if isinstance(j, list) else [])]
    out.sort(key=lambda x: -(x["ts"] or 0))
    return out


# ccTLD yang tidak sama dengan ISO2
_TLD = {"uk": "GB"}
# kode negara di feed serangan ransomware.live yang AMBIGU (dipakai untuk dua negara berbeda): hanya dipercaya lewat domain
_AMBIG = {"CH", "PO", "PR", "IS"}
_FIPS = {"SW": "SE", "UK": "GB", "GM": "DE", "JA": "JP", "AS": "AU", "KS": "KR", "RS": "RU", "SP": "ES", "TU": "TR", "EI": "IE", "EZ": "CZ"}


def country_of_attack(domain, code):
    """Negara serangan: dari ccTLD domain korban bila ada (paling pasti), selain itu kode sumber bila tidak ambigu."""
    d = str(domain or "").lower().strip(".")
    tld = d.rsplit(".", 1)[-1] if "." in d else ""
    if len(tld) == 2:
        cc = _TLD.get(tld, tld.upper())
        return cc if cc in ISO2 else None
    if tld in ("gov", "mil"):
        return "US"
    c = str(code or "").upper()
    if c in _AMBIG:
        return None
    c = _FIPS.get(c, c)
    return c if c in ISO2 else None


@cached(1800, persist=True, stale_ok=12 * 3600)
async def month_victims(year, month):
    """Semua korban yang diumumkan pada satu bulan (ransomware.live /v2/victims/YYYY/MM)."""
    j = await get_json(f"https://api.ransomware.live/v2/victims/{year}/{month:02d}", retries=1, quiet=True)
    return [_victim(v) for v in (j if isinstance(j, list) else [])]


def _victim(v):
    cc = str(v.get("country") or "").upper()
    geo = ISO2.get(cc)
    return dict(victim=str(v.get("victim") or "")[:90], group=str(v.get("group") or ""), cc=cc, country=geo[0] if geo else (cc or None),
                lat=geo[1] if geo else None, lon=geo[2] if geo else None, sector=_sector(v.get("description"))[:60],
                ts=_ts(v.get("discovered")) or _ts(v.get("attackdate")), attack_ts=_ts(v.get("attackdate")),
                link=v.get("url") if str(v.get("url") or "").startswith("https://www.ransomware.live/") else None)


@cached(1800, persist=True, stale_ok=12 * 3600)
async def press_attacks():
    """Serangan siber yang DIBERITAKAN pers (ransomware.live /v2/recentcyberattacks), negara dari domain korban."""
    j = await get_json("https://api.ransomware.live/v2/recentcyberattacks", retries=1, quiet=True)
    out = []
    for a in j if isinstance(j, list) else []:
        cc = country_of_attack(a.get("domain"), a.get("country"))
        geo = ISO2.get(cc) if cc else None
        url = str(a.get("url") or "")
        title = str(a.get("title") or "")
        if not title or title.count("\ufffd") >= 2:                  # judul rusak di sumber (karakter hilang) -> ringkasan netral
            title = f"Serangan siber terhadap {a.get('victim') or a.get('domain') or 'organisasi'} (judul asli rusak di sumber)"
        out.append(dict(title=title[:160], victim=str(a.get("victim") or a.get("domain") or "")[:80],
                        domain=a.get("domain"), cc=cc, country=geo[0] if geo else None, lat=geo[1] if geo else None, lon=geo[2] if geo else None,
                        ts=_ts(a.get("date")) or _ts(a.get("added")), link=url if url.startswith("https://") and ".onion" not in url else None))
    out.sort(key=lambda x: -(x["ts"] or 0))
    return out


def cyber_news(hours=72, limit=60):
    """Berita serangan/peretasan dari feed terminal; lokasi dari nama tempat di judul (bila ada)."""
    from . import geo
    out, seen = [], set()
    for it in N.all_items(hours * 3600):
        t = it["title"]
        if not _KW_RE.search(t) or it["id"] in seen:
            continue
        seen.add(it["id"])
        place, ll = geo.locate_one(t)          # hanya bila judul menyebut SATU tempat (tidak ambigu)
        out.append(dict(id=it["id"], title=t, source=it["source"], link=it["link"], ts=it["ts"], prio=it.get("prio"),
                        place=place.title() if place else None, lat=ll[0] if ll else None, lon=ll[1] if ll else None))
        if len(out) >= limit:
            break
    return out


WINDOW_DAYS = 45


def _dots(victims):
    """Posisi titik tiap korban di dalam negaranya (sumber hanya mencatat negara)."""
    from . import geo
    for v in victims:
        if v["country"] and v["lat"] is not None:
            p = geo.point_in_country(v["country"], v["victim"] + "|" + v["group"])
            v["dot"] = list(p) if p else [v["lat"], v["lon"]]
    return victims


async def layer():
    import asyncio
    today = dt.date.today()
    prev = (today.replace(day=1) - dt.timedelta(days=1))
    res = await asyncio.gather(ransomware(), month_victims(today.year, today.month), month_victims(prev.year, prev.month), press_attacks(), return_exceptions=True)
    err = next((type(r).__name__ for r in res if isinstance(r, Exception)), None)
    recent, cur, old, press = [[] if isinstance(r, Exception) else r for r in res]
    now = time.time()
    seen, vic = set(), []
    for v in recent + cur + old:
        k = (v["victim"].lower(), v["group"].lower())
        if k in seen or not v["ts"] or now - v["ts"] > WINDOW_DAYS * 86400:
            continue
        seen.add(k)
        vic.append(v)
    vic.sort(key=lambda x: -(x["ts"] or 0))
    vic = await cpu.parse(_dots, vic)
    news = cyber_news()
    countries = {}
    for v in vic:
        if v["country"] and v["lat"] is not None:
            c = countries.setdefault(v["country"], dict(name=v["country"], victims=0, d7=0, groups={}, press=0))
            c["victims"] += 1
            c["d7"] += 1 if now - v["ts"] < 7 * 86400 else 0
            c["groups"][v["group"]] = c["groups"].get(v["group"], 0) + 1
    for a in press:
        if a["country"]:
            countries.setdefault(a["country"], dict(name=a["country"], victims=0, d7=0, groups={}, press=0))["press"] += 1
    for c in countries.values():
        c["groups"] = sorted(c["groups"], key=c["groups"].get, reverse=True)[:3]
    groups, sectors = {}, {}
    for v in vic:
        groups[v["group"]] = groups.get(v["group"], 0) + 1
        if v["sector"]:
            sectors[v["sector"]] = sectors.get(v["sector"], 0) + 1
    return dict(victims=vic, press=press, news=news, countries=countries, groups=sorted(groups.items(), key=lambda kv: -kv[1])[:8],
                sectors=sorted(sectors.items(), key=lambda kv: -kv[1])[:8], window_days=WINDOW_DAYS,
                d1=sum(1 for v in vic if now - v["ts"] < 86400), d7=sum(1 for v in vic if now - v["ts"] < 7 * 86400),
                source="ransomware.live + pers + berita", error=err, ts=now)
