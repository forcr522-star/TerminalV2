"""Polymarket - pasar prediksi (taruhan uang sungguhan) sebagai sumber sentimen. Publik, tanpa API key.

Sumber: gamma-api.polymarket.com/events?tag_slug=<tema>&active=true&closed=false&order=volume24hr (pasar teramai dulu).
Per pasar diambil: peluang "Yes" (= harga, 0..1), perubahan harga 1 jam / 24 jam / 7 hari, volume 24 jam, likuiditas.

DOMINAN BELI / JUAL (data, bukan tebakan):
  harga Yes hanya bergerak karena order yang tereksekusi -> Yes NAIK 24 jam = pembeli Yes dominan (BELI),
  Yes TURUN = penjual Yes dominan (JUAL). Ambang |perubahan| >= 1 poin persen; di bawahnya NETRAL.
  Dominasi sebuah tema / keseluruhan = porsi VOLUME 24 jam di pasar yang dibeli vs dijual (pasar ramai berbobot lebih).

ARAH UNTUK BOT (driver fundamental "pm"), dari arti pertanyaan (aturan kata kunci yang transparan, lihat _risk/_fed):
  risk  : Yes = de-eskalasi / kesepakatan (ceasefire, peace, deal, end of ..., reopen) -> +1 (risk-on)
          Yes = eskalasi / krisis (invade, war, strike, clash, blockade, recession, ...) -> -1 (risk-off)
  fed   : Yes = pemangkasan suku bunga -> +1 (dovish); kenaikan / tanpa pemangkasan -> -1 (hawkish)
  crypto: Yes = harga kripto naik/di atas (reach, above, hit) -> +1; turun/di bawah (dip, below, fall) -> -1
  skor  = rata-rata (tanda x perubahan Yes 24 jam) berbobot volume, dinormalkan tanh(x / 2 poin persen) -> -1..+1.
  Pasar yang hampir pasti (Yes < 3% atau > 97%) atau sepi (< $5.000 / 24 jam) diabaikan.
"""
import asyncio
import json
import math
import re
import time

from ..http import fetch, cached

API = "https://gamma-api.polymarket.com/events"
SITE = "https://polymarket.com/event/"
# tema yang relevan untuk pasar keuangan (urutan = tampilan)
THEMES = [
    ("geopolitics", "Geopolitik"), ("middle-east", "Timur Tengah"), ("ukraine", "Rusia-Ukraina"), ("china", "China / Taiwan"),
    ("fed", "Fed & suku bunga"), ("economy", "Ekonomi"), ("tariffs", "Tarif & dagang"), ("oil", "Minyak & energi"), ("crypto", "Kripto"),
]
PER_THEME = 12             # event teramai per tema
MIN_VOL = 5_000.0          # USD volume 24 jam minimal agar pasar dihitung
MOVE = 0.01                # 1 poin persen: batas BELI / JUAL
EDGE = 0.03                # pasar dengan Yes < 3% / > 97% dianggap sudah pasti (abaikan)

_RISK_ON = re.compile(r"\b(cease-?fire|truce|peace|deal|agreement|accord|treaty|end of|ends?\b|lift(?:ed|s)?|reopen|returns? to normal|"
                      r"normali[sz]|release|resume|de-?escalat|withdraw|cut tariffs|lower tariffs|tariffs? (?:cut|reduc))", re.I)
_RISK_OFF = re.compile(r"\b(invade|invasion|war\b|strike|attack|military action|military clash|clash|nuclear|blockade|bomb|missile|"
                       r"recession|default|shutdown|collapse|crash|sanction|escalat|regime (?:fall|change)|coup|martial law|new tariffs?|"
                       r"tariffs? (?:on|increase|hike))", re.I)
_CUT = re.compile(r"\b(cut|cuts|decrease|lower|reduc)", re.I)
_HIKE = re.compile(r"\b(hike|hikes|increase|raise)", re.I)
_ZERO = re.compile(r"\b(0|no|zero)\b[^?]{0,20}\b(cut|cuts)\b", re.I)


_UNDO = re.compile(r"\b(collapse[sd]?|break[s]?|broken|violat\w*|fail[s]?|ends?|over|expire[sd]?)\b", re.I)


def _risk(q):
    """+1 = Yes berarti risk-on, -1 = risk-off, 0 = tidak jelas (tidak dipakai untuk arah).
    Kata de-eskalasi menang ("war end", "end of blockade"), kecuali de-eskalasinya sendiri yang gagal sesudahnya
    ("ceasefire collapses / ends")."""
    on = _RISK_ON.search(q)
    if on:
        tail = q[on.end():on.end() + 40]
        if on.group(0).lower().startswith(("cease", "truce", "peace", "deal", "agreement", "accord", "treaty")) and _UNDO.search(tail):
            return -1
        return 1
    return -1 if _RISK_OFF.search(q) else 0


def _fed(q, theme):
    """+1 = Yes berarti dovish (pemangkasan), -1 = hawkish, 0 = bukan pasar suku bunga."""
    if theme not in ("fed", "economy") or not re.search(r"\b(fed|fomc|rate|bps|interest)", q, re.I):
        return 0
    if _ZERO.search(q) or re.search(r"\bno change\b", q, re.I):
        return -1 if _ZERO.search(q) else 0
    if _CUT.search(q):
        return 1
    if _HIKE.search(q):
        return -1
    return 0


_UP = re.compile(r"\b(reach|above|hit|exceed|over|higher|ath|all[- ]time high)\b", re.I)
_DOWN = re.compile(r"\b(dip|below|fall|drop|under|lower|crash)\b", re.I)


def _crypto(q, theme):
    """+1 = Yes berarti harga kripto naik, -1 = turun, 0 = bukan pasar harga kripto."""
    if theme != "crypto" or not re.search(r"\b(bitcoin|btc|ethereum|eth|solana|xrp|crypto)\b", q, re.I):
        return 0
    up, down = _UP.search(q), _DOWN.search(q)
    return 1 if up and not down else -1 if down and not up else 0


def _num(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def parse_events(events, theme, now=None):
    """Event Gamma -> daftar pasar ringkas (satu baris per pertanyaan Yes/No yang aktif & ramai)."""
    now = now or time.time()
    out = []
    for e in events or []:
        for m in e.get("markets") or []:
            if m.get("closed") or m.get("active") is False:
                continue
            try:
                outs = json.loads(m.get("outcomes") or "[]")
                prices = [float(p) for p in json.loads(m.get("outcomePrices") or "[]")]
            except (ValueError, TypeError):
                continue
            if len(outs) != 2 or len(prices) != 2 or str(outs[0]).lower() != "yes":
                continue
            yes, vol = prices[0], _num(m.get("volume24hr")) or 0.0
            if vol < MIN_VOL or not EDGE <= yes <= 1 - EDGE:
                continue
            q = (m.get("question") or e.get("title") or "").strip()
            d24 = _num(m.get("oneDayPriceChange")) or 0.0
            side = "BELI" if d24 >= MOVE else "JUAL" if d24 <= -MOVE else "NETRAL"
            out.append(dict(theme=theme, event=e.get("title"), question=q, yes=round(yes, 4), d1h=_num(m.get("oneHourPriceChange")),
                            d24=round(d24, 4), d7=_num(m.get("oneWeekPriceChange")), vol24=round(vol), liq=_num(m.get("liquidityNum")),
                            end=(m.get("endDate") or "")[:10], url=SITE + (e.get("slug") or ""), side=side,
                            risk=_risk(q) if theme != "crypto" else 0, fed=_fed(q, theme), crypto=_crypto(q, theme)))
    return out


def summarize(markets):
    """Dominasi per tema & keseluruhan + skor arah risiko / Fed untuk bot."""
    def dom(rows):
        buy = sum(r["vol24"] for r in rows if r["side"] == "BELI")
        sell = sum(r["vol24"] for r in rows if r["side"] == "JUAL")
        tot = sum(r["vol24"] for r in rows)
        net = sum(r["d24"] * r["vol24"] for r in rows) / tot if tot else 0.0
        verdict = "BELI" if buy > 1.25 * sell and buy > 0 else "JUAL" if sell > 1.25 * buy and sell > 0 else "SEIMBANG"
        return dict(n=len(rows), buy_vol=round(buy), sell_vol=round(sell), vol=round(tot), buy_pct=round(buy / tot * 100, 1) if tot else None,
                    sell_pct=round(sell / tot * 100, 1) if tot else None, net_pp=round(net * 100, 2), verdict=verdict)

    def score(key):
        rows = [r for r in markets if r[key]]
        w = sum(r["vol24"] for r in rows)
        if not w:
            return None, 0
        x = sum(r[key] * r["d24"] * r["vol24"] for r in rows) / w
        return round(math.tanh(x / 0.02), 3), len(rows)
    themes = []
    for slug, label in THEMES:
        rows = [r for r in markets if r["theme"] == slug]
        if rows:
            themes.append(dict(theme=slug, label=label, **dom(rows)))
    risk, n_risk = score("risk")
    fed, n_fed = score("fed")
    cry, n_cry = score("crypto")
    return dict(overall=dom(markets), themes=themes, risk=risk, n_risk=n_risk, fed=fed, n_fed=n_fed, crypto=cry, n_crypto=n_cry)


async def _theme(slug):
    r = await fetch(API, params={"tag_slug": slug, "active": "true", "closed": "false", "order": "volume24hr",
                                 "ascending": "false", "limit": PER_THEME}, retries=1, timeout=30)
    events = await asyncio.to_thread(json.loads, r.content)     # respons bisa ±1 MB: parse di thread
    return await asyncio.to_thread(parse_events, events, slug)


@cached(600, persist=True, stale_ok=86400)
async def overview():
    """Pasar prediksi penting + dominasi beli/jual. Satu pasar bisa muncul di beberapa tema: dihitung sekali (tema pertama)."""
    res = await asyncio.gather(*[_theme(s) for s, _ in THEMES], return_exceptions=True)
    seen, markets, errors = set(), [], {}
    for (slug, _), r in zip(THEMES, res):
        if isinstance(r, Exception):
            errors[slug] = f"{type(r).__name__}: {str(r)[:100]}"
            continue
        for m in r:
            k = m["question"].lower()
            if k not in seen:
                seen.add(k)
                markets.append(m)
    if not markets and errors:
        raise RuntimeError("Polymarket tidak dapat dijangkau: " + "; ".join(f"{k}: {v}" for k, v in list(errors.items())[:3]))
    markets.sort(key=lambda m: -m["vol24"])
    return dict(markets=markets[:150], errors=errors, at=time.time(), **summarize(markets))


HINTS = {"geopolitics": ["GEOPOLITICS"], "middle-east": ["MIDDLE EAST", "GEOPOLITICS"], "ukraine": ["EUROPE", "GEOPOLITICS"],
         "china": ["ASIA", "GEOPOLITICS"], "fed": ["UNITED STATES"], "economy": ["MARKETS"], "tariffs": ["MARKETS"], "oil": ["COMMODITIES"],
         "crypto": ["CRYPTO"]}


def news_items(ov):
    """Pergerakan besar -> item feed berita (satu per pasar per hari)."""
    day = time.strftime("%Y-%m-%d", time.gmtime())
    out = []
    for m in movers(ov):
        out.append(dict(title=f"Polymarket: {m['question']} - peluang Yes {m['yes'] * 100:.0f}% ({m['d24'] * 100:+.1f} poin 24 jam, dominan {m['side']})",
                        source="Polymarket", link=m["url"], hints=HINTS.get(m["theme"], ["MARKETS"]), uid=f"{m['question']}:{day}"))
    return out


def movers(ov, min_move=0.05, min_vol=50_000, n=8):
    """Pergerakan besar 24 jam (untuk feed berita): |perubahan Yes| >= 5 poin & volume >= $50.000."""
    rows = [m for m in (ov or {}).get("markets") or [] if abs(m["d24"]) >= min_move and m["vol24"] >= min_vol]
    rows.sort(key=lambda m: -abs(m["d24"]) * m["vol24"])
    return rows[:n]
