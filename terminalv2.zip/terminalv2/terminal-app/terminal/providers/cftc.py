import asyncio
from ..http import get_json, cached
from ..universe import COT_TFF, COT_DISAGG, COT_ASSET_CLASSES

DS = {"tff": "gpe5-46if", "disagg": "72hh-3qpy"}
URL = "https://publicreporting.cftc.gov/resource/{}.json"
EXCL = ("change", "pct", "traders", "spread", "conc", "chg")

GROUPS = {
    "tff": [("lev", "Leveraged Fund", ("lev_money",)), ("asset", "Asset Manager", ("asset_mgr",)), ("dealer", "Dealer", ("dealer",)), ("other", "Other Reportable", ("other_rept",))],
    "disagg": [("mm", "Managed Money", ("m_money",)), ("prod", "Producer/Merchant", ("prod_merc",)), ("swap", "Swap Dealer", ("swap",)), ("other", "Other Reportable", ("other_rept",))],
}


def _f(v):
    try:
        return float(v)
    except Exception:
        return None


def pick(row, tokens, side):
    for k, v in row.items():
        kk = k.lower()
        if all(t in kk for t in tokens) and side in kk and not any(e in kk for e in EXCL):
            return _f(v)
    return None


def _norm(kind, row):
    out = dict(date=str(row.get("report_date_as_yyyy_mm_dd", ""))[:10], oi=_f(row.get("open_interest_all")), code=row.get("cftc_contract_market_code"), name=row.get("market_and_exchange_names"))
    for gid, _, tokens in GROUPS[kind]:
        lo, sh = pick(row, tokens, "long"), pick(row, tokens, "short")
        out[gid + "_long"], out[gid + "_short"] = lo, sh
        out[gid + "_net"] = (lo - sh) if lo is not None and sh is not None else None
    return out


def _choose(rows):
    best = {}
    for r in rows:
        c = r.get("cftc_contract_market_code")
        best[c] = max(best.get(c, 0), _f(r.get("open_interest_all")) or 0)
    if not best:
        return None
    return max(best, key=best.get)


@cached(3600)
async def instrument(kind, name, limit=104):
    table = COT_TFF if kind == "tff" else COT_DISAGG
    code, like, cls = table[name]
    url = URL.format(DS[kind])
    rows = []
    if code:
        rows = await get_json(url, params={"$where": f"cftc_contract_market_code='{code}'", "$order": "report_date_as_yyyy_mm_dd DESC", "$limit": limit})
    if not rows and like:
        rows = await get_json(url, params={"$where": f"upper(market_and_exchange_names) like '%{like}%'", "$order": "report_date_as_yyyy_mm_dd DESC", "$limit": limit * 3})
        pick_code = _choose(rows[:30])
        rows = [r for r in rows if r.get("cftc_contract_market_code") == pick_code][:limit]
    data = [_norm(kind, r) for r in rows]
    for i, d in enumerate(data):
        nxt = data[i + 1] if i + 1 < len(data) else None
        for gid, _, _ in GROUPS[kind]:
            cur, prev = d.get(gid + "_net"), (nxt or {}).get(gid + "_net")
            d[gid + "_chg"] = (cur - prev) if cur is not None and prev is not None else None
    return dict(kind=kind, name=name, cls=cls, groups=[dict(id=g, label=l) for g, l, _ in GROUPS[kind]], rows=data)


def kind_of(name):
    return "tff" if name in COT_TFF else "disagg"


async def asset_class_table(cls):
    names = COT_ASSET_CLASSES[cls]
    res = await asyncio.gather(*[instrument(kind_of(n), n, 30) for n in names], return_exceptions=True)
    out = []
    for n, r in zip(names, res):
        if isinstance(r, Exception) or not r["rows"]:
            continue
        out.append(r)
    return out


@cached(3600)
async def spec_net_commodities(weeks=6):
    names = ["Aluminum", "Copper", "Corn", "Crude Oil (WTI)", "Gold", "Natural Gas", "Silver", "Wheat", "Soybeans", "Coffee", "Cocoa", "Cotton", "Sugar", "Platinum", "Palladium"]
    res = await asyncio.gather(*[instrument("disagg", n, weeks + 2) for n in names], return_exceptions=True)
    out = []
    for n, r in zip(names, res):
        if isinstance(r, Exception) or not r["rows"]:
            continue
        nets = [x.get("mm_net") for x in r["rows"][:weeks]]
        out.append(dict(name=f"CFTC {n} speculative net positions", values=nets, dates=[x["date"] for x in r["rows"][:weeks]]))
    nas = await instrument("tff", "Nasdaq 100", weeks + 2)
    out.append(dict(name="CFTC Nasdaq 100 speculative net positions", values=[x.get("lev_net") for x in nas["rows"][:weeks]], dates=[x["date"] for x in nas["rows"][:weeks]]))
    return out
