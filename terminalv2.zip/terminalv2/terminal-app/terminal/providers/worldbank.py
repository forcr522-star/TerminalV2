"""World Bank Indicators API v2 (gratis, tanpa key). Dipakai sebagai cadangan IMF DataMapper."""
import datetime as dt
from ..http import get_json, cached

BASE = "https://api.worldbank.org/v2/country/{codes}/indicator/{ind}"


def parse(j):
    """[meta, rows] -> {iso3: [(year, value)]}. Melempar ValueError bila bentuknya error/kosong."""
    if not isinstance(j, list) or len(j) < 2 or not j[1]:
        msg = ""
        if isinstance(j, list) and j and isinstance(j[0], dict):
            msg = str((j[0].get("message") or [{}])[0].get("value", ""))[:100] if j[0].get("message") else ""
        raise ValueError(f"World Bank kosong {msg}".strip())
    out = {}
    for r in j[1]:
        v = r.get("value")
        if v is None:
            continue
        code = r.get("countryiso3code") or (r.get("country") or {}).get("id")
        try:
            out.setdefault(code, []).append((int(str(r.get("date"))[:4]), float(v)))
        except (TypeError, ValueError):
            continue
    for k in out:
        out[k].sort()
    if not out:
        raise ValueError("World Bank tanpa nilai")
    return out


@cached(12 * 3600, persist=True, stale_ok=90 * 86400)
async def indicator(ind, codes, first=1995):
    year = dt.date.today().year
    j = await get_json(BASE.format(codes=";".join(codes), ind=ind), params={"format": "json", "per_page": 20000, "date": f"{first}:{year}"}, retries=1)
    return parse(j)
