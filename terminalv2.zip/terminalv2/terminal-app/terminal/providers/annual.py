"""Data makro tahunan per negara dengan rantai cadangan: IMF DataMapper -> World Bank.

Semua modul (fiscal, macro, rates) memakai ini, jadi satu sumber yang gagal tidak lagi mematikan
Fiscal, Regime, Compare, dan Economic Overview sekaligus.
"""
import asyncio
import csv
import datetime as dt
import io
from ..http import get_json, get_text, cached, _status
from .. import cpu, health
from ..universe import COUNTRIES, COUNTRY_ORDER
from . import worldbank

IMF = "https://www.imf.org/external/datamapper/api/v1/{ind}/{codes}"
IMF_HEADERS = {"Accept": "application/json, text/plain, */*", "Referer": "https://www.imf.org/external/datamapper/", "Origin": "https://www.imf.org"}

IMF_KEYS = ["NGDP_RPCH", "PCPIPCH", "LUR", "BCA_NGDPD", "GGXWDG_NGDP", "GGXCNL_NGDP"]
IMF_LABEL = {"NGDP_RPCH": "Real GDP Growth", "PCPIPCH": "Inflation (CPI)", "LUR": "Unemployment Rate", "BCA_NGDPD": "Current Account (% GDP)",
             "GGXWDG_NGDP": "Government Debt (% GDP)", "GGXCNL_NGDP": "Government Balance (% GDP)",
             # IMF Fiscal Monitor (FM) - termasuk proyeksi; menggantikan GGXONLB_NGDP/GGXWDG yang sudah tidak ada di DataMapper
             "GGXONLB_G01_GDP_PT": "Primary Balance (% GDP)", "GGR_G01_GDP_PT": "Government Revenue (% GDP)",
             "G_X_G01_GDP_PT": "Government Expenditure (% GDP)", "GGXWDN_G01_GDP_PT": "Net Debt (% GDP)",
             "GGCB_G01_PGDP_PT": "Cyclically Adjusted Balance (% potential GDP)", "ie": "Interest Paid (% GDP)", "NGDPD": "GDP (USD bn)"}
WB_IND = {"NGDP_RPCH": "NY.GDP.MKTP.KD.ZG", "PCPIPCH": "FP.CPI.TOTL.ZG", "LUR": "SL.UEM.TOTL.ZS", "BCA_NGDPD": "BN.CAB.XOKA.GD.ZS",
          "GGXWDG_NGDP": "GC.DOD.TOTL.GD.ZS", "GGXCNL_NGDP": "GC.NLD.TOTL.GD.ZS",
          "GGR_G01_GDP_PT": "GC.REV.XGRT.GD.ZS", "G_X_G01_GDP_PT": "GC.XPN.TOTL.GD.ZS", "NGDPD": "NY.GDP.MKTP.CD"}
WB_SCALE = {"NGDPD": 1e-9}          # World Bank: USD -> IMF: miliar USD
STALE_YEARS = 3                     # seri cadangan yang berhenti > 3 tahun lalu dianggap basi
WB_CODE = {"EURO": "EMU"}
SRC = {}
ERR = {}


def _imf_parse(j, indicator):
    vals = (j.get("values") or {}).get(indicator, {})
    out = {}
    for c, series in vals.items():
        pts = sorted((int(y), v) for y, v in series.items() if v is not None)
        if pts:
            out[c] = pts
    return out


async def _imf_fetch(indicator, codes):
    # Percobaan 1: semua negara sekaligus. Percobaan 2: satu per satu (beberapa gateway menolak URL panjang).
    try:
        j = await get_json(IMF.format(ind=indicator, codes="/".join(codes)), headers=IMF_HEADERS, retries=1)
        out = await cpu.parse(_imf_parse, j, indicator)
        if out:
            return out
    except Exception as exc:
        st = _status(exc)
        # Ditolak (403/401/404) = bukan masalah panjang URL; 60 percobaan per negara hanya memperlambat dan mengotori status.
        if st in (401, 403, 404):
            raise RuntimeError(f"IMF DataMapper menolak permintaan (HTTP {st})")
    # Percobaan 2: tanpa daftar negara. DataMapper kini mengirim SEMUA negara (100-160 KB) walau diminta satu negara,
    # jadi dulu "satu per satu" = 10 unduhan penuh serentak (mudah timeout). Cukup satu ulangan dengan batas waktu lebih longgar.
    j = await get_json(IMF_ALL.format(ind=indicator), headers=IMF_HEADERS, retries=1, timeout=60)
    want = set(codes)
    out = {k: v for k, v in (await cpu.parse(_imf_parse, j, indicator)).items() if k in want}
    if not out:
        raise RuntimeError("IMF DataMapper tidak mengembalikan data")
    return out


IMF_ALL = "https://www.imf.org/external/datamapper/api/v1/{ind}"


@cached(12 * 3600, persist=True, stale_ok=120 * 86400)
async def _imf_good(ind, codes):
    """Hasil IMF yang BERHASIL disimpan terpisah (120 hari). Bila IMF sesekali gagal, data IMF terakhir tetap dipakai -
    dulu kegagalan sesaat membuat hasil gabungan diganti cadangan World Bank yang jarang (mis. utang Indonesia hanya 2008-2009)."""
    out = await _imf_fetch(ind, codes)
    if not out:
        raise RuntimeError("IMF DataMapper tidak mengembalikan data")
    return out


# Dataflow Total Credit BIS naik ke versi 2.0 (versi 1.0 sudah tidak ada -> HTTP 404). Kunci datanya sama.
BIS_TC = "https://stats.bis.org/api/v1/data/BIS,WS_TC,2.0/Q.{codes}.G.A..770.A"


def parse_bis_tc(text):
    """BIS Total Credit (utang pemerintah umum, % PDB) kuartalan -> {iso2: [(tahun, nilai)]} (kuartal terakhir tiap tahun).
    Prioritas valuasi N (nominal) lalu M (market); kolom dicocokkan longgar karena header BIS bisa memuat label ('FREQ:Frequency')."""
    rd = csv.DictReader(io.StringIO(text))
    cols = {}
    for c in rd.fieldnames or []:
        cols.setdefault(c.split(":")[0].strip().upper(), c)
    need = ("BORROWERS_CTY", "TC_BORROWERS", "UNIT_TYPE", "TIME_PERIOD", "OBS_VALUE")
    if not all(n in cols for n in need):
        raise ValueError("kolom BIS WS_TC tidak dikenali")
    best = {}  # (iso2, valuation) -> {year: (period, value)}
    for r in rd:
        g = lambda k: (r.get(cols[k]) or "").split(":")[0].strip()
        if g("TC_BORROWERS") != "G" or g("UNIT_TYPE") != "770":
            continue
        adj = g("TC_ADJUST") if "TC_ADJUST" in cols else "A"
        if adj not in ("A", ""):
            continue
        per, val = g("TIME_PERIOD"), g("OBS_VALUE")
        try:
            year, v = int(per[:4]), float(val)
        except ValueError:
            continue
        key = (g("BORROWERS_CTY"), g("VALUATION") if "VALUATION" in cols else "N")
        cur = best.setdefault(key, {})
        if year not in cur or per > cur[year][0]:
            cur[year] = (per, v)
    out = {}
    for iso2 in {k[0] for k in best}:
        pick = best.get((iso2, "N")) or best.get((iso2, "M")) or next(v for k, v in best.items() if k[0] == iso2)
        out[iso2] = sorted((y, v[1]) for y, v in pick.items())
    if not out:
        raise ValueError("BIS WS_TC tanpa data")
    return out


async def _bis_debt(imf_codes):
    inv = {COUNTRIES[c]["imf"]: COUNTRIES[c]["bis"] for c in COUNTRY_ORDER}
    codes = {inv[c]: c for c in imf_codes if c in inv}
    if not codes:
        raise ValueError("tidak ada kode BIS")
    txt = await get_text(BIS_TC.format(codes="+".join(codes)), params={"format": "csv", "startPeriod": "2000"}, headers={"Accept": "text/csv"}, retries=1)
    return {codes[k]: v for k, v in parse_bis_tc(txt).items() if k in codes}


@cached(12 * 3600, persist=True, stale_ok=90 * 86400)
async def indicator(ind, codes):
    """-> {kode_imf: [(tahun, nilai)]}. Mencoba IMF, melengkapi yang kosong dari World Bank."""
    codes = tuple(codes)
    out, errs = {}, []
    try:
        out = dict(await _imf_good(ind, codes))
        SRC[ind] = "IMF"
    except Exception as exc:
        errs.append(f"IMF: {str(exc)[:80]}")
    missing = [c for c in codes if c not in out]
    if missing and ind in WB_IND:
        try:
            wb = await worldbank.indicator(WB_IND[ind], tuple(WB_CODE.get(c, c) for c in missing))
            sc = WB_SCALE.get(ind, 1.0)
            for c in missing:
                pts = wb.get(WB_CODE.get(c, c))
                if pts:
                    out[c] = [(y, v * sc) for y, v in pts] if sc != 1.0 else pts
            if out and SRC.get(ind) != "IMF":
                SRC[ind] = "World Bank"
            elif any(c in out for c in missing):
                SRC[ind] = "IMF+World Bank"
        except Exception as exc:
            errs.append(f"WB: {str(exc)[:80]}")
    # Cadangan ketiga untuk utang/PDB: BIS (mencakup negara yang tidak melapor ke World Bank, mis. China), juga untuk seri
    # World Bank yang sudah basi (mis. utang pemerintah pusat Indonesia di World Bank berhenti di 2009).
    this_year = dt.date.today().year
    missing = [c for c in codes if c not in out or out[c][-1][0] < this_year - STALE_YEARS]
    if missing and ind == "GGXWDG_NGDP":
        try:
            bis = await _bis_debt(missing)
            for c, pts in bis.items():
                if pts and (c not in out or pts[-1][0] > out[c][-1][0]):
                    out[c] = pts
            if bis:
                SRC[ind] = (SRC.get(ind) + "+BIS") if SRC.get(ind) else "BIS"
        except Exception as exc:
            errs.append(f"BIS: {str(exc)[:80]}")
    if not out:
        ERR[ind] = "; ".join(errs) or "tidak ada data"
        raise RuntimeError(ERR[ind])
    ERR.pop(ind, None)
    if errs and any(e.startswith("IMF") for e in errs):
        health.cover("www.imf.org", SRC.get(ind) or "World Bank")
    return out


async def multi(indicators, codes):
    res = await asyncio.gather(*[indicator(i, tuple(codes)) for i in indicators], return_exceptions=True)
    return {i: (r if not isinstance(r, Exception) else {}) for i, r in zip(indicators, res)}


async def all_countries():
    # Sengaja tanpa cache sendiri: tiap indikator sudah di-cache (dan hanya sukses yang disimpan),
    # sehingga kegagalan sementara tidak membeku sebagai "data kosong" selama berjam-jam.
    return await multi(IMF_KEYS, [COUNTRIES[c]["imf"] for c in COUNTRY_ORDER])


def pick(data, key, cc):
    return list(data.get(key, {}).get(COUNTRIES[cc]["imf"], []))


async def series(key, cc):
    d = await all_countries()
    return pick(d, key, cc)


def latest(points, year=None):
    year = year or dt.date.today().year
    past = [(y, v) for y, v in points if y <= year]
    return past[-1] if past else (None, None)


def status():
    return dict(source={k: SRC.get(k) for k in IMF_KEYS}, errors=dict(ERR))
