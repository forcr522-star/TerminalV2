"""Tunnel Cloudflare (quick tunnel, tanpa akun) + pengawas yang memastikan link BENAR-BENAR bisa dibuka.

Masalah yang ditangani:
  * Error 1033 ("Cloudflare is currently unable to resolve it"): URL trycloudflare sudah dicetak, tetapi cloudflared
    belum/tidak lagi terhubung ke edge Cloudflare. Pengawas menunggu "Registered tunnel connection", lalu memeriksa
    link publik sendiri (GET <link>/healthz). Link baru diumumkan AKTIF setelah terbukti terbuka.
  * Tunnel putus diam-diam: link diperiksa berkala. Link quick tunnel melekat pada PROSES cloudflared - selama proses
    hidup, cloudflared menyambung ulang ke edge sendiri dan link TETAP sama. Tunnel baru (= link BERGANTI) hanya dibuat
    bila proses mati, atau tunnel benar-benar putus (edge 530/error 1033, atau cloudflared tanpa koneksi) terus-menerus
    selama TUNNEL_DOWN_MIN menit. Pemeriksaan yang gagal karena server sendiri sedang tertahan, server lokal tidak
    menjawab, 502/503/504 selagi cloudflared tersambung (server lambat), atau jaringan PC ini sendiri TIDAK dihitung.
  * Cloudflare membatasi permintaan quick tunnel (429) / protokol diblokir jaringan: jeda bertahap dan pergantian
    protokol http2 <-> quic.
"""
import asyncio
import collections
import io
import os
import platform
import re
import shutil
import stat
import tarfile
import time

import httpx

from . import config

URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
REGISTERED_RE = re.compile(r"Registered tunnel connection|Connection [0-9a-f-]+ registered", re.I)
UNREGISTERED_RE = re.compile(r"Unregistered tunnel connection|Connection terminated|Lost connection", re.I)
EDGE_RE = re.compile(r"location=([a-z0-9]+)", re.I)
PROBLEM_RE = re.compile(r"\b(ERR|WRN|error|failed)\b", re.I)
BASE = "https://github.com/cloudflare/cloudflared/releases/latest/download/"

# Kode HTTP dari edge Cloudflare yang berarti "tunnel tidak tersambung" (530 = error 1033).
EDGE_DOWN = {502, 503, 504, 530}


def _asset():
    sysname = platform.system().lower()
    mach = platform.machine().lower()
    arm = "arm64" if ("arm" in mach or "aarch" in mach) else "amd64"
    if sysname == "windows":
        return f"cloudflared-windows-{'amd64' if '64' in mach or mach == 'amd64' else '386'}.exe", "cloudflared.exe", False
    if sysname == "darwin":
        return f"cloudflared-darwin-{arm}.tgz", "cloudflared", True
    return f"cloudflared-linux-{arm}", "cloudflared", False


async def ensure_binary():
    if config.CLOUDFLARED_PATH and os.path.exists(config.CLOUDFLARED_PATH):
        return config.CLOUDFLARED_PATH
    asset, name, tgz = _asset()
    local = config.BIN_DIR / name            # bin/ bawaan paket didahulukan (versi yang sudah diuji bersama paket)
    if local.exists():
        return str(local)
    found = shutil.which("cloudflared")
    if found:
        return found
    config.BIN_DIR.mkdir(parents=True, exist_ok=True)
    print(f"[tunnel] mengunduh cloudflared ({asset}) ...", flush=True)
    async with httpx.AsyncClient(follow_redirects=True, timeout=httpx.Timeout(180.0, connect=20.0)) as c:
        r = await c.get(BASE + asset)
        r.raise_for_status()
        data = r.content
    if tgz:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as t:
            member = next(m for m in t.getmembers() if m.name.endswith("cloudflared"))
            local.write_bytes(t.extractfile(member).read())
    else:
        local.write_bytes(data)
    local.chmod(local.stat().st_mode | stat.S_IEXEC)
    return str(local)


class Tunnel:
    """Satu proses cloudflared. URL dibaca dari keluarannya; jumlah koneksi edge dilacak dari log."""

    def __init__(self, port, protocol="http2"):
        self.port = port
        self.protocol = protocol
        self.proc = None
        self.url = None
        self.connections = 0
        self.edge = None
        self.tail = collections.deque(maxlen=60)
        self.problems = collections.deque(maxlen=10)
        self._reader = None
        self._registered = None

    @property
    def alive(self):
        return bool(self.proc and self.proc.returncode is None)

    async def start(self, timeout=75):
        binary = await ensure_binary()
        self.url = None
        self._registered = asyncio.Event()
        self.proc = await asyncio.create_subprocess_exec(
            binary, "tunnel", "--url", f"http://127.0.0.1:{self.port}", "--no-autoupdate", "--protocol", self.protocol,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, stdin=asyncio.subprocess.DEVNULL,
        )
        fut = asyncio.get_running_loop().create_future()

        async def read():
            while True:
                line = await self.proc.stdout.readline()
                if not line:
                    break
                text = line.decode(errors="ignore").rstrip()
                self.tail.append(text)
                m = URL_RE.search(text)
                if m and not fut.done():
                    fut.set_result(m.group(0))
                if REGISTERED_RE.search(text):
                    self.connections += 1
                    e = EDGE_RE.search(text)
                    if e:
                        self.edge = e.group(1)
                    self._registered.set()
                elif UNREGISTERED_RE.search(text):
                    self.connections = max(0, self.connections - 1)
                if PROBLEM_RE.search(text) and "trycloudflare" not in text:
                    self.problems.append(text[-220:])
            if not fut.done():
                last = next((t for t in reversed(self.tail) if t.strip()), "")
                fut.set_exception(RuntimeError("cloudflared berhenti sebelum URL tersedia" + (f": {last[-160:]}" if last else "")))

        self._reader = asyncio.create_task(read())
        try:
            self.url = await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            raise RuntimeError(f"cloudflared tidak memberi URL dalam {timeout} dtk")
        return self.url

    async def wait_registered(self, timeout=45):
        """True bila cloudflared sudah tersambung ke edge Cloudflare (minimal satu koneksi)."""
        if self._registered is None:
            return False
        try:
            await asyncio.wait_for(self._registered.wait(), timeout)
            return True
        except asyncio.TimeoutError:
            return False

    async def wait_exit(self):
        if self.proc:
            await self.proc.wait()

    async def stop(self):
        if self.proc and self.proc.returncode is None:
            try:
                self.proc.terminate()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(self.proc.wait(), 5)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        if self._reader:
            self._reader.cancel()


async def probe(url, timeout=12.0, client=None):
    """Periksa link publik: GET <url>/healthz (tanpa kunci; rute ini terbuka).

    Mengembalikan (ok, kode, keterangan):
      ok=True   -> link bisa dibuka (server menjawab lewat Cloudflare)
      ok=False  -> edge Cloudflare menjawab tetapi tunnel tidak tersambung (mis. 530 = error 1033)
      ok=None   -> tidak bisa memeriksa dari PC ini (DNS/jaringan lokal); bukan bukti link mati
    """
    own = client is None
    c = client or httpx.AsyncClient(timeout=timeout, follow_redirects=False, headers={"User-Agent": "terminal-tunnel-check"})
    try:
        r = await c.get(url.rstrip("/") + "/healthz")
        if r.status_code == 200:
            try:
                if r.json().get("ok"):
                    return True, 200, "ok"
            except Exception:
                pass
            return False, 200, "jawaban bukan dari server terminal"
        body = r.text[:4000] if r.status_code != 200 else ""
        if "1033" in body:
            return False, r.status_code, "error 1033 (tunnel tidak tersambung ke Cloudflare)"
        if r.status_code in EDGE_DOWN:
            return False, r.status_code, f"edge Cloudflare HTTP {r.status_code}"
        return False, r.status_code, f"HTTP {r.status_code}"
    except Exception as exc:
        return None, None, f"{type(exc).__name__}: {str(exc)[:120]}"
    finally:
        if own:
            await c.aclose()


async def probe_local(port, timeout=5.0):
    try:
        async with httpx.AsyncClient(timeout=timeout, trust_env=False) as c:
            r = await c.get(f"http://127.0.0.1:{port}/healthz")
            return r.status_code == 200
    except Exception:
        return False


def _now():
    return time.time()


class Supervisor:
    """Membuat, memverifikasi, memantau, dan membuat ulang tunnel. Status dibaca panel terminal SERVER.

    status["state"]:
      starting   : cloudflared dijalankan, menunggu URL
      verifying  : URL ada, menunggu koneksi edge + link terbukti terbuka (JANGAN dibuka dulu)
      active     : link terbukti terbuka (healthz lewat Cloudflare = 200)
      registered : cloudflared tersambung, tetapi PC ini tidak bisa memeriksa link (DNS lokal) - kemungkinan besar bisa dibuka
      unstable   : pemeriksaan terakhir gagal; dibuat ulang hanya bila tunnel putus terus-menerus TUNNEL_DOWN_MIN menit
      restarting : tunnel dibuat ulang (link akan BERGANTI)
      error      : gagal membuat tunnel; dicoba lagi otomatis
      fixed      : PUBLIC_URL di .env (tunnel/domain sendiri; tidak diawasi)
    """

    def __init__(self, port, on_link=None, log=print, check_every=None, protocol=None,
                 verify_window=90.0, down_window=None, min_down_checks=3):
        self.port = port
        self.on_link = on_link or (lambda url, active: None)
        self.log = log
        self.check_every = float(check_every or config.TUNNEL_CHECK_EVERY)
        first = (protocol or config.TUNNEL_PROTOCOL or "http2").lower()
        self.protocols = [first] + [p for p in ("http2", "quic") if p != first]
        self.verify_window = verify_window
        self.down_window = float(config.TUNNEL_DOWN_MIN * 60 if down_window is None else down_window)
        self.min_down_checks = min_down_checks
        self.tunnel = None
        self.status = dict(state="starting", url=None, since=None, verified_at=None, last_check=None, last_result=None,
                           fails=0, restarts=0, protocol=first, connections=0, edge=None, error=None, problems=[])

    def _set(self, **kw):
        self.status.update(kw)
        t = self.tunnel
        if t is not None:
            self.status.update(connections=t.connections, edge=t.edge, problems=list(t.problems)[-3:])

    async def _check(self, client):
        ok, code, detail = await probe(self.status["url"], client=client)
        self._set(last_check=_now(), last_result=detail if ok is not True else f"OK (HTTP {code})")
        if ok:
            self._set(verified_at=_now())
        return ok, code, detail

    async def run(self):
        if config.PUBLIC_URL:
            url = config.PUBLIC_URL.rstrip("/")
            self._set(state="fixed", url=url, since=_now())
            self.on_link(url, True)
            return
        backoff, attempt = 5.0, 0
        client = httpx.AsyncClient(timeout=12.0, follow_redirects=False, headers={"User-Agent": "terminal-tunnel-check"})
        try:
            while True:
                proto = self.protocols[(attempt // 2) % len(self.protocols)]   # 2x gagal berturut-turut -> ganti protokol
                self.tunnel = Tunnel(self.port, protocol=proto)
                self._set(state="starting", protocol=proto, error=None, url=None, verified_at=None, fails=0)
                self.on_link(None, False)
                try:
                    url = await self.tunnel.start()
                except Exception as exc:
                    attempt += 1
                    self._set(state="error", error=str(exc)[:200])
                    self.log(f"[tunnel] gagal membuat tunnel ({proto}): {exc}; ulangi dalam {backoff:.0f} dtk")
                    await self.tunnel.stop()
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, 120.0)
                    continue
                self._set(state="verifying", url=url, since=_now())
                self.log(f"[tunnel] URL dibuat: {url} - memverifikasi (jangan dibuka dulu) ...")
                active = await self._verify(client)
                if active is None:
                    attempt += 1
                    self.log(f"[tunnel] {url} tidak pernah tersambung ke Cloudflare - membuat tunnel baru ...")
                    await self._restart(backoff)
                    backoff = min(backoff * 2, 120.0)
                    continue
                attempt, backoff = 0, 5.0
                self.on_link(url, True)
                if active:
                    self.log(f"[tunnel] LINK AKTIF & terverifikasi: {url}")
                else:
                    self.log(f"[tunnel] LINK tersambung ke Cloudflare (edge {self.tunnel.edge or '?'}), "
                             "tetapi PC ini tidak bisa memeriksanya sendiri (DNS lokal). Coba buka di browser.")
                reason = await self._watch(client, verified_once=bool(active))
                self.log(f"[tunnel] {reason} - membuat tunnel baru; link akan BERGANTI ...")
                await self._restart(3.0)
        finally:
            await client.aclose()
            if self.tunnel:
                await self.tunnel.stop()

    async def _verify(self, client):
        """True = terbukti terbuka, False = tersambung tetapi tak bisa diperiksa dari sini, None = gagal (buat ulang)."""
        t = self.tunnel
        registered = await t.wait_registered(45)
        self._set()
        deadline = _now() + self.verify_window
        while t.alive and _now() < deadline:
            ok, code, detail = await self._check(client)
            if ok:
                self._set(state="active")
                return True
            await asyncio.sleep(4)
        if not t.alive:
            return None
        if registered or t.connections > 0:
            self._set(state="registered")
            return False
        return None

    async def _watch(self, client, verified_once):
        """Pantau sampai tunnel harus dibuat ulang; mengembalikan alasannya. Lihat aturan di docstring modul: link hanya
        diganti bila proses cloudflared mati atau tunnel putus terus-menerus selama `down_window` detik."""
        from . import watchdog
        t = self.tunnel
        fails, down_n, down_since = 0, 0, None
        exit_task = asyncio.ensure_future(t.wait_exit())
        try:
            while True:
                done, _ = await asyncio.wait({exit_task}, timeout=self.check_every)
                if done or not t.alive:
                    return "proses cloudflared berhenti"
                t0 = _now()
                ok, code, detail = await self._check(client)
                if ok:
                    fails, down_n, down_since = 0, 0, None
                    self._set(state="active", fails=0)
                    continue
                fails += 1
                if watchdog.stalled_since(t0):
                    self._set(state="unstable", fails=fails, last_result=f"server sedang tertahan saat pemeriksaan ({detail}) - bukan masalah tunnel")
                    continue
                if not await probe_local(self.port):
                    self._set(last_result=f"server lokal tidak menjawab ({detail})")
                    continue          # masalahnya di server, bukan tunnel: jangan ganti link
                gone = code == 530 or "1033" in (detail or "") or t.connections == 0
                if not gone:
                    # cloudflared masih tersambung ke edge: 502/503/504 = server lambat menjawab, None = jaringan PC ini.
                    # Link tetap berlaku; cloudflared menyambung ulang sendiri bila perlu.
                    down_n, down_since = 0, None
                    self._set(state="unstable" if verified_once else ("registered" if t.connections > 0 else "unstable"), fails=fails)
                    continue
                down_n += 1
                down_since = down_since or t0
                self._set(state="unstable", fails=fails)
                lasted = _now() - down_since
                if down_n == 1:
                    self.log(f"[tunnel] tunnel tidak tersambung ({detail}); link dipertahankan, cloudflared menyambung ulang sendiri. "
                             f"Diganti hanya bila berlanjut {self.down_window / 60:.0f} menit.")
                if down_n >= self.min_down_checks and lasted >= self.down_window:
                    return f"tunnel putus terus-menerus {lasted / 60:.1f} menit ({detail})"
        finally:
            exit_task.cancel()

    async def _restart(self, delay):
        self._set(state="restarting", url=None)
        self.status["restarts"] += 1
        self.on_link(None, False)
        if self.tunnel:
            await self.tunnel.stop()
        await asyncio.sleep(delay)
