"""Pemantau update terminal -> notifikasi (hanya kejadian PENTING; log informasi tidak pernah dinotifikasi).

  calendar - kalender ekonomi (dampak tinggi/sedang, negara terminal): 15 menit sebelum rilis, lalu saat angka actual keluar
             (dibandingkan dengan perkiraan). Menjelang rilis, kalender diambil ulang tiap menit supaya angka cepat masuk.
  rates    - suku bunga kebijakan bank sentral berubah (naik / turun).
  curve    - yield 10 tahun bergerak >= 10 bp sejak notifikasi terakhir negara itu, atau kurva 2s10s berubah >= 15 bp /
             berbalik tanda (terbalik <-> normal).
  signal   - posisi / order sinyal SELESAI (TP, SL, batal) dari jurnal 10 METODE dan STRATEGI ONE (jurnal hanya DIBACA).

Keadaan terakhir (nilai acuan & kejadian yang sudah dikirim) disimpan di database, jadi restart tidak mengirim ulang dan
pengamatan pertama hanya menjadi acuan (tanpa notifikasi).
"""
import asyncio
import datetime as dt
import json
import re
import time
import traceback

from . import notify, store
from .universe import COUNTRIES

KV = "notify_watch_v1"
PRE_MIN = 15                    # notifikasi menjelang rilis kalender
REL_FRESH = 15 * 60             # rilis yang sudah ada angkanya saat pertama terlihat: hanya dikirim bila <= 15 menit lalu
Y10_BP, Y10_BIG_BP = 10.0, 25.0
CURVE_BP = 15.0
IMPACT_LEVEL = {"HIGH": "high", "MODERATE": "medium"}
# rilis rutin berdampak "sedang" yang tidak relevan untuk trading (bukan data makro) -> tidak dinotifikasi (anti spam)
MINOR = re.compile(r"\bUSDA\b|Export Sales|Auction|Baker Hughes|CFTC", re.I)
NAME_ID = {"US": "Amerika Serikat", "CN": "China", "EU": "Zona Euro", "JP": "Jepang", "GB": "Inggris", "CA": "Kanada", "AU": "Australia",
           "ID": "Indonesia", "CH": "Swiss", "NZ": "Selandia Baru", "DE": "Jerman", "FR": "Prancis", "IT": "Italia"}
SCALE_ID = {"K": "ribu", "M": "juta", "B": "miliar", "T": "triliun"}
CUR_ID = {"$": "dolar", "US$": "dolar", "C$": "dolar Kanada", "A$": "dolar Australia", "NZ$": "dolar Selandia Baru", "€": "euro", "£": "pound",
          "¥": "yen", "CHF": "franc Swiss", "Rp": "rupiah", "IDR": "rupiah", "CNY": "yuan", "%": "persen"}
IMPACT_TXT = {"HIGH": "TINGGI", "MODERATE": "SEDANG"}

_state = None
_fresh_at = 0.0


def _load():
    global _state
    if _state is None:
        s = store.kv_get(KV, None) or {}
        _state = dict(cal=s.get("cal") or {}, rates=s.get("rates") or {}, sig=s.get("sig") or {}, started=s.get("started") or time.time())
    return _state


def _save():
    st = _load()
    cut = time.time() - 3 * 86400
    st["cal"] = {k: v for k, v in st["cal"].items() if v > cut}
    store.kv_set(KV, st)


def reset():
    """Dipakai pengujian."""
    global _state, _fresh_at
    _state, _fresh_at = None, 0.0


def _name(cc, cur=None):
    if (cc or "") in NAME_ID:
        return NAME_ID[cc]
    c = COUNTRIES.get(cc or "")
    return c["name"].title() if c else (cc or cur or "")


def _unit_words(unit):
    """'BC$' -> 'miliar dolar Kanada', '%' -> 'persen', 'K' -> 'ribu'."""
    u = (unit or "").strip()
    if not u:
        return ""
    scale = ""
    if u[0] in SCALE_ID and (len(u) == 1 or not u[1].isalpha() or u[1:] in CUR_ID):
        scale, u = SCALE_ID[u[0]], u[1:]
    cur = CUR_ID.get(u, u)
    return " ".join(x for x in (scale, cur) if x)


def _val(v, unit=""):
    """Nilai kalender untuk teks: angka -> '3.1%'; teks (ForexFactory) apa adanya."""
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        t = f"{v:,.2f}".rstrip("0").rstrip(".")
        return f"{t}{unit or ''}"
    return str(v)


def _say_val(v, unit=""):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        w = _unit_words(unit)
        return notify.say_num(v, 2) + (" " + w if w else "")
    t = str(v).strip()
    m = re.match(r"^(-?[\d.,]+)\s*([KMBT]?)(%?)$", t)
    if m:                                                       # ForexFactory: '3.1%', '250K', '-1.2B'
        w = " ".join(x for x in (SCALE_ID.get(m.group(2), ""), "persen" if m.group(3) else "") if x)
        return notify.say_num(_num(m.group(1)), 2) + (" " + w if w else "")
    return t


def _num(v):
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace("%", "").replace("K", "").replace("M", "").replace("B", "").replace(",", "").strip())
    except Exception:
        return None


# ------------------------------------------------------------------------------------------------ kalender
def calendar_check(events, now=None):
    """Bandingkan daftar kalender dengan yang sudah dikirim. Mengembalikan jumlah notifikasi."""
    st = _load()
    now = now or time.time()
    sent = 0
    for e in events or []:
        imp = e.get("impact")
        if imp not in IMPACT_LEVEL or (imp != "HIGH" and MINOR.search(str(e.get("event") or ""))):
            continue
        try:
            t = dt.datetime.strptime(e["date"], "%Y-%m-%d %H:%M").replace(tzinfo=dt.timezone.utc).timestamp()
        except Exception:
            continue
        cc, unit = e.get("cc") or e.get("country"), e.get("unit") or ""
        name, ev_name = _name(cc, e.get("cur")), str(e.get("event") or "")[:90]
        base = f"{e['date']}|{cc}|{ev_name}"
        f, p, a = _val(e.get("forecast"), unit), _val(e.get("previous"), unit), _val(e.get("actual"), unit)
        lvl = IMPACT_LEVEL[imp]
        hhmm = e["date"][11:16]
        # 1) menjelang rilis
        if 0 < t - now <= PRE_MIN * 60 and ("pre|" + base) not in st["cal"]:
            st["cal"]["pre|" + base] = now
            mins = max(1, round((t - now) / 60))
            parts = [x for x in (f and f"perkiraan {f}", p and f"sebelumnya {p}") if x]
            say = f"{mins} menit lagi rilis {ev_name}, {name}." + (" " + ", ".join(
                x for x in (_say_val(e.get('forecast'), unit) and f"Perkiraan {_say_val(e.get('forecast'), unit)}",
                            _say_val(e.get('previous'), unit) and f"sebelumnya {_say_val(e.get('previous'), unit)}") if x) + "." if parts else "")
            sent += bool(notify.emit("calendar", f"{name}: {ev_name} — rilis {mins} menit lagi",
                                     f"Dampak {IMPACT_TXT[imp]} · {hhmm} UTC" + (" · " + " · ".join(parts) if parts else ""),
                                     url="/#dashboard", key="pre|" + base, level=lvl, ts=t, say=say))
        # 2) angka keluar
        if a is not None and 0 <= now - t <= 3 * 3600 and ("rel|" + base) not in st["cal"]:
            st["cal"]["rel|" + base] = now
            first_seen = now - st["started"] < 90
            if first_seen and now - t > REL_FRESH:
                continue                                   # rilis lama saat server baru menyala: hanya acuan
            an, fn = _num(e.get("actual")), _num(e.get("forecast"))
            verdict = None
            if an is not None and fn is not None:
                verdict = "sesuai perkiraan" if abs(an - fn) < 1e-9 else ("di atas perkiraan" if an > fn else "di bawah perkiraan")
            body = " · ".join(x for x in (f and f"perkiraan {f}", p and f"sebelumnya {p}", verdict) if x)
            say = f"Rilis {ev_name}, {name}: {_say_val(e.get('actual'), unit)}" + (f", {verdict}" if verdict else "") + "." + (
                f" Perkiraan {_say_val(e.get('forecast'), unit)}." if f else "") + (f" Sebelumnya {_say_val(e.get('previous'), unit)}." if p else "")
            sent += bool(notify.emit("calendar", f"{name}: {ev_name} {a}", body or f"Dampak {IMPACT_TXT[imp]}", url="/#dashboard",
                                     key="rel|" + base, level=lvl, ts=t, say=say))
    return sent


def _awaiting(events, now):
    """Ada rilis penting yang waktunya sudah lewat (<= 20 menit) tetapi angkanya belum masuk?"""
    for e in events or []:
        if e.get("impact") not in IMPACT_LEVEL or e.get("actual") not in (None, ""):
            continue
        try:
            t = dt.datetime.strptime(e["date"], "%Y-%m-%d %H:%M").replace(tzinfo=dt.timezone.utc).timestamp()
        except Exception:
            continue
        if 0 <= now - t <= 20 * 60:
            return True
    return False


async def calendar_once(now=None):
    global _fresh_at
    from .providers import calendar
    now = now or time.time()
    evs = await calendar.events()
    if _awaiting(evs, now) and now - _fresh_at >= 60:      # menjelang/sesudah rilis: ambil angka terbaru (bukan cache 10 menit)
        _fresh_at = now
        try:
            evs = await calendar.tv_calendar.__wrapped__()
        except Exception:
            pass
    n = calendar_check(evs, now)
    await asyncio.to_thread(_save)
    return n


# ------------------------------------------------------------------------------------------------ suku bunga & kurva
def _bp(x):
    return f"{x:+.0f} bp"


def rates_check(rows):
    """rows = rates.overview()['rows']: policy, y10, curve (bp, label) per negara."""
    st = _load()
    sent = 0
    for r in rows or []:
        cc = r.get("cc")
        if not cc:
            continue
        name, cb = _name(cc), r.get("cb") or _name(cc)
        old = st["rates"].get(cc)
        cur = dict(policy=r.get("policy"), y10=r.get("y10"), curve=r.get("curve"), label=r.get("curve_label") or "2s10s")
        if old is None:
            st["rates"][cc] = cur                             # pengamatan pertama: acuan
            continue
        # suku bunga kebijakan
        if cur["policy"] is not None and old.get("policy") is not None and abs(cur["policy"] - old["policy"]) >= 0.005:
            d = cur["policy"] - old["policy"]
            verb = "menaikkan" if d > 0 else "menurunkan"
            sent += bool(notify.emit("rates", f"{cb}: suku bunga {old['policy']:.2f}% → {cur['policy']:.2f}%", f"{name} · {_bp(d * 100)}",
                                     url="/#cb", key=f"pol|{cc}|{cur['policy']:.4f}", level="high",
                                     say=f"{cb} {verb} suku bunga dari {notify.say_num(old['policy'], 2)} persen ke {notify.say_num(cur['policy'], 2)} persen."))
            old["policy"] = cur["policy"]
        elif old.get("policy") is None:
            old["policy"] = cur["policy"]
        # yield 10 tahun
        if cur["y10"] is not None and old.get("y10") is not None:
            d = (cur["y10"] - old["y10"]) * 100
            if abs(d) >= Y10_BP:
                sent += bool(notify.emit("curve", f"Yield 10Y {name}: {old['y10']:.2f}% → {cur['y10']:.2f}%", f"{_bp(d)} sejak notifikasi terakhir",
                                         url="/#cb", key=f"y10|{cc}|{cur['y10']:.3f}", level="high" if abs(d) >= Y10_BIG_BP else "medium",
                                         say=f"Yield obligasi 10 tahun {name} {'naik' if d > 0 else 'turun'} dari {notify.say_num(old['y10'], 2)} persen "
                                             f"ke {notify.say_num(cur['y10'], 2)} persen, {notify.say_num(abs(d), 0)} basis poin."))
                old["y10"] = cur["y10"]
        elif old.get("y10") is None:
            old["y10"] = cur["y10"]
        # kurva (spread ujung pendek - 10Y, bp)
        if cur["curve"] is not None and old.get("curve") is not None and cur["label"] == old.get("label"):
            a, b = old["curve"], cur["curve"]
            flip = (a < 0 <= b) or (a >= 0 > b)
            if flip or abs(b - a) >= CURVE_BP:
                what = ("kembali normal" if b >= 0 else "terbalik (inverted)") if flip else ("makin curam" if b > a else "makin datar")
                sent += bool(notify.emit("curve", f"Kurva {cur['label']} {name}: {a:+.0f} bp → {b:+.0f} bp", f"Kurva {what}",
                                         url="/#cb", key=f"crv|{cc}|{b:.1f}", level="high" if flip else "medium",
                                         say=f"Kurva yield {name} {what}. Spread {cur['label']} dari {notify.say_num(a, 0)} ke {notify.say_num(b, 0)} basis poin."))
                old["curve"] = b
        else:
            old["curve"], old["label"] = cur["curve"], cur["label"]
        st["rates"][cc] = old
    return sent


async def rates_once():
    from .providers import rates
    ov = await rates.overview()
    n = rates_check(ov.get("rows"))
    await asyncio.to_thread(_save)
    return n


# ------------------------------------------------------------------------------------------------ hasil sinyal (jurnal hanya dibaca)
def signals_check(now=None):
    st = _load()
    now = now or time.time()
    sent = 0
    for table, strat in (("signal_log", "multi"), ("one_log", "one")):
        last = st["sig"].get(table)
        if last is None:                                       # pertama kali: mulai dari sekarang (tanpa riwayat lama)
            st["sig"][table] = now
            continue
        try:
            rows = store.query(f"SELECT id, sym, side, status, r, closed FROM {table} WHERE closed IS NOT NULL AND closed > ? ORDER BY closed", (last,))
        except Exception:
            continue
        for row in rows:
            rid, sym, side, status, r, closed = (row[k] for k in ("id", "sym", "side", "status", "r", "closed")) if isinstance(row, dict) else row
            st["sig"][table] = max(st["sig"][table], float(closed))
            sent += bool(notify.signal_closed(rid, sym, side, status, None if r is None else float(r), strat))
    return sent


# ------------------------------------------------------------------------------------------------ loop
async def run():
    """Satu loop ringan: sinyal tiap 30 dtk, kalender tiap 60 dtk, suku bunga & kurva tiap 5 menit."""
    await asyncio.sleep(20)
    k = 0
    while True:
        try:
            await asyncio.to_thread(lambda: (signals_check(), _save()))
        except Exception:
            traceback.print_exc()
        if k % 2 == 0:
            try:
                await calendar_once()
            except Exception:
                pass                                           # sumber kalender gagal: dicoba lagi putaran berikutnya
        if k % 10 == 1:
            try:
                await rates_once()
            except Exception:
                pass
        k += 1
        await asyncio.sleep(30)


def summary():
    st = _load()
    return dict(rates=len(st["rates"]), calendar_sent=len(st["cal"]), sig=st["sig"], json=len(json.dumps(st)))
