// =====================================================================================================================
// ALAT TERMINAL (berlaku di semua menu)
//   - Ikon garis SVG & pengelompokan menu untuk sidebar
//   - Command palette: Ctrl/Cmd+K atau "/" -> lompat ke menu, cari simbol/berita, jalankan alat
//   - Watchlist & price alert (per browser): harga dari server tiap 60 dtk, alert -> toast + notifikasi browser
//   - Kalkulator ukuran posisi berbasis risiko (FX, logam, energi, indeks, kripto)
// Semua pilihan pengguna disimpan di localStorage browser itu (tidak memengaruhi pengguna lain).
// =====================================================================================================================
(function(){
const h=T.h;
const S=(p)=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg>';
T.ICONS={
  dashboard:S('<rect x="3" y="3" width="7.5" height="9" rx="1.5"/><rect x="13.5" y="3" width="7.5" height="5.5" rx="1.5"/><rect x="13.5" y="11.5" width="7.5" height="9.5" rx="1.5"/><rect x="3" y="15" width="7.5" height="6" rx="1.5"/>'),
  signal:S('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.2"/><path d="M12 1.8v4M12 18.2v4M1.8 12h4M18.2 12h4"/>'),
  heatmap:S('<path d="M3 20h18"/><rect x="4" y="12" width="3" height="6" rx=".6"/><rect x="10.5" y="6" width="3" height="12" rx=".6"/><rect x="17" y="9" width="3" height="9" rx=".6"/><path d="M5.5 9V6M12 4V2.5M18.5 7V5"/>'),
  thinking:S('<circle cx="6" cy="7" r="2.2"/><circle cx="18" cy="7" r="2.2"/><circle cx="12" cy="17" r="2.2"/><circle cx="12" cy="10.5" r="1.6"/><path d="M7.8 8.2l2.8 1.6M16.2 8.2l-2.8 1.6M12 12.1v2.7"/>'),
  market:S('<path d="M6 3v4M6 15v6M12 2v3M12 13v8M18 6v5M18 17v4"/><rect x="4" y="7" width="4" height="8" rx=".8"/><rect x="10" y="5" width="4" height="8" rx=".8"/><rect x="16" y="11" width="4" height="6" rx=".8"/>'),
  futures:S('<path d="M3 17c3.5 0 4-9 8-9s4.5 6 10 6"/><path d="M3 21h18"/><circle cx="11" cy="8" r="1.3"/>'),
  etf:S('<path d="M12 3l9 4.5-9 4.5-9-4.5z"/><path d="M3 12l9 4.5 9-4.5"/><path d="M3 16.5L12 21l9-4.5"/>'),
  financials:S('<path d="M6 2.5h9l4 4V21.5H6z"/><path d="M15 2.5V7h4"/><path d="M9 17v-3M12 17v-5M15 17v-2"/>'),
  participant:S('<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.6 2.7-6 6-6s6 2.4 6 6"/><circle cx="17.5" cy="9" r="2.4"/><path d="M16 14.3c3 .2 5 2.2 5 5.2"/>'),
  macro:S('<circle cx="12" cy="12" r="9"/><path d="M3.5 9h17M3.5 15h17"/><path d="M12 3c2.6 2.6 3.8 5.6 3.8 9S14.6 18.4 12 21c-2.6-2.6-3.8-5.6-3.8-9S9.4 5.6 12 3z"/>'),
  centralbank:S('<path d="M3 9l9-5.5L21 9"/><path d="M4.5 9h15"/><path d="M6 9v8M10 9v8M14 9v8M18 9v8"/><path d="M3.5 17.5h17M2.5 21h19"/>'),
  fiscal:S('<path d="M6 2.5h12v19l-3-1.8-3 1.8-3-1.8-3 1.8z"/><path d="M9 8h6M9 12h6M9 16h3.5"/>'),
  supply:S('<path d="M2.5 15h19l-2.6 4.5H5z"/><rect x="6" y="9" width="5" height="6" rx=".6"/><rect x="11.5" y="6.5" width="5" height="8.5" rx=".6"/><path d="M14 3.5v3"/>'),
  intel:S('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 12l6.4-6.4"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/>'),
  geo:S('<path d="M12 21.5s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12z"/><path d="M12 6.5v4M12 13.2v.2"/>'),
  quant:S('<path d="M18 4.5H6l6.5 7.5L6 19.5h12"/>'),
  star:S('<path d="M12 3.2l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 17l-5.4 2.9 1.1-6.1-4.5-4.2 6.1-.8z"/>'),
  calc:S('<rect x="5" y="2.5" width="14" height="19" rx="2"/><rect x="8" y="5.5" width="8" height="4" rx=".6"/><path d="M8.5 13h.01M12 13h.01M15.5 13h.01M8.5 16.5h.01M12 16.5h.01M15.5 16.5h.01"/>'),
  bell:S('<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2H4.5z"/><path d="M10 20.5a2.2 2.2 0 0 0 4 0"/>'),
  search:S('<circle cx="11" cy="11" r="6.5"/><path d="M20.5 20.5l-4.8-4.8"/>'),
  x:S('<path d="M6 6l12 12M18 6L6 18"/>'),
};
T.GROUPS=[['OVERVIEW',['dashboard']],['TRADING',['signal','heatmap','thinking']],['MARKETS',['market','futures','etf','financials','participant']],
  ['MACRO',['macro','centralbank','fiscal','supply']],['INTELLIGENCE',['intel','geo','quant']]];
T.groupOf=id=>(T.GROUPS.find(g=>g[1].includes(id))||['TERMINAL'])[0];

// ------------------------------------------------------------------ penyimpanan per browser
const ls={get:(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}},set:(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
T.ls=ls;

// ------------------------------------------------------------------ toast
const toasts=h('div',{id:'toasts'});document.body.append(toasts);
T.toast=(title,body,kind='info',ms=6000)=>{
  const el=h('div',{class:'toast '+kind},h('b',null,title),body?h('span',null,body):null);
  toasts.append(el);requestAnimationFrame(()=>el.classList.add('in'));
  setTimeout(()=>{el.classList.remove('in');setTimeout(()=>el.remove(),300)},ms);
};

// ------------------------------------------------------------------ data harga (dipakai watchlist, alert, kalkulator)
let assets=[];const bySym=new Map();
async function loadAssets(force){
  try{
    const d=await T.api('market/assets',{cls:'ALL'},{force:!!force,bg:true});
    assets=d.rows||[];bySym.clear();assets.forEach(a=>bySym.set(a.sym.toUpperCase(),a));
    checkAlerts();renderWatch();
  }catch(e){}
}
T.assetOf=sym=>bySym.get(String(sym).toUpperCase());

// ------------------------------------------------------------------ modal umum
function modal(title,body,cls=''){
  const close=()=>{wrap.remove();document.removeEventListener('keydown',esc)};
  const esc=e=>{if(e.key==='Escape')close()};
  const wrap=h('div',{class:'tm-modal '+cls,onclick:e=>{if(e.target===wrap)close()}},
    h('div',{class:'tm-box'},h('div',{class:'tm-head'},h('b',null,title),h('button',{class:'tm-x',title:'Tutup (Esc)',html:T.ICONS.x,onclick:close})),body));
  document.body.append(wrap);document.addEventListener('keydown',esc);
  return {wrap,close};
}

// ------------------------------------------------------------------ COMMAND PALETTE
const ACTIONS=[
  {id:'act:watch',label:'Watchlist & price alert',hint:'Pantau harga & pasang alert',icon:'star',run:()=>openWatch()},
  {id:'act:calc',label:'Kalkulator ukuran posisi',hint:'Lot dari saldo, risiko %, entry & SL',icon:'calc',run:()=>openCalc()},
  {id:'act:status',label:'Status sumber data',hint:'Sumber yang bermasalah / cadangan aktif',icon:'bell',admin:true,run:()=>{const b=document.getElementById('hbtn');if(b&&b.style.display!=='none')b.click();else T.toast('Semua sumber normal','Tidak ada sumber bermasalah saat ini.','ok')}},
];
function openPalette(){
  if(document.querySelector('.tm-modal.pal'))return;
  const inp=h('input',{class:'pal-in',placeholder:'Ketik menu, simbol (EURUSD, Gold…), berita, atau perintah…',autocomplete:'off',spellcheck:'false'});
  const list=h('div',{class:'pal-list'});
  const foot=h('div',{class:'pal-foot'},h('span',null,h('kbd',null,'↑'),h('kbd',null,'↓'),' pilih'),h('span',null,h('kbd',null,'Enter'),' buka'),h('span',null,h('kbd',null,'Esc'),' tutup'));
  const m=modal('',h('div',null,h('div',{class:'pal-bar',html:T.ICONS.search},inp),list,foot),'pal');
  m.wrap.querySelector('.tm-head').remove();
  let items=[],sel=0,st=null,news=[];
  const mods=T.modules.map(([id,,name])=>({id:'mod:'+id,label:name,hint:T.groupOf(id),icon:id,run:()=>{location.hash='#'+id}}));
  function score(text,q){text=text.toLowerCase();if(!q)return 1;if(text.startsWith(q))return 3;if(text.includes(' '+q))return 2;return text.includes(q)?1:0}
  function render(){
    const q=inp.value.trim().toLowerCase();
    const acts=ACTIONS.filter(a=>!a.admin||T.role==='admin');
    const m1=[...mods,...acts].map(it=>[score(it.label,q),it]).filter(x=>x[0]>0).sort((a,b)=>b[0]-a[0]).map(x=>x[1]);
    const as=q?assets.map(a=>[Math.max(score(a.sym,q),score(a.name||'',q)),a]).filter(x=>x[0]>0).sort((a,b)=>b[0]-a[0]).slice(0,8)
      .map(([,a])=>({id:'sym:'+a.sym,label:a.sym,hint:(a.name||'')+' · '+a.cls,price:a,run:()=>T.openAsset(a.sym),star:a.sym})):[];
    const ns=news.slice(0,6).map(n=>({id:'news:'+n.id,label:n.title,hint:n.source+' · '+T.ago(n.ts),icon:'intel',run:()=>window.open(n.link,'_blank')}));
    items=[...m1.slice(0,q?8:30),...as,...ns];
    sel=Math.min(sel,Math.max(0,items.length-1));
    list.replaceChildren();
    const sec=(t,arr)=>{if(!arr.length)return;list.append(h('div',{class:'pal-sec'},t));arr.forEach(it=>list.append(row(it)))};
    sec(q?'MENU & PERINTAH':'SEMUA MENU',m1.slice(0,q?8:30));sec('SIMBOL',as);sec('BERITA',ns);
    if(!items.length)list.append(h('div',{class:'pal-empty'},'Tidak ada hasil untuk "'+inp.value+'"'));
  }
  function row(it){
    const i=items.indexOf(it);
    const p=it.price;
    return h('div',{class:'pal-it'+(i===sel?' on':''),onmouseenter:()=>{sel=i;mark()},onclick:()=>go(it)},
      h('span',{class:'pal-ic',html:T.ICONS[it.icon]||T.ICONS.market}),
      h('span',{class:'pal-tx'},h('b',null,it.label),h('small',null,it.hint||'')),
      p?h('span',{class:'pal-px'},T.fmt(p.price,p.price<10?4:2),' ',h('em',{class:T.cls(p.pct)},T.pct(p.pct))):null,
      it.star?h('button',{class:'pal-star'+(watch().includes(it.star)?' on':''),title:'Tambah/hapus dari watchlist',html:T.ICONS.star,onclick:e=>{e.stopPropagation();toggleWatch(it.star);render()}}):null);
  }
  function mark(){[...list.querySelectorAll('.pal-it')].forEach((el,i)=>el.classList.toggle('on',i===sel))}
  function go(it){m.close();it.run()}
  inp.addEventListener('input',()=>{sel=0;render();clearTimeout(st);const q=inp.value.trim();news=[];
    if(q.length>=3)st=setTimeout(async()=>{try{const d=await T.api('search',{q});if(inp.value.trim()===q){news=d.news||[];render()}}catch(e){}},260)});
  inp.addEventListener('keydown',e=>{
    if(e.key==='ArrowDown'){sel=Math.min(items.length-1,sel+1);mark();e.preventDefault();list.querySelectorAll('.pal-it')[sel]?.scrollIntoView({block:'nearest'})}
    else if(e.key==='ArrowUp'){sel=Math.max(0,sel-1);mark();e.preventDefault();list.querySelectorAll('.pal-it')[sel]?.scrollIntoView({block:'nearest'})}
    else if(e.key==='Enter'&&items[sel]){go(items[sel])}
  });
  if(!assets.length)loadAssets().then(render);
  render();setTimeout(()=>inp.focus(),0);
}
T.openPalette=openPalette;
document.addEventListener('keydown',e=>{
  const typing=/^(INPUT|TEXTAREA|SELECT)$/.test((e.target||{}).tagName||'')||(e.target&&e.target.isContentEditable);
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openPalette()}
  else if(e.key==='/'&&!typing){e.preventDefault();openPalette()}
});

// ------------------------------------------------------------------ WATCHLIST & PRICE ALERT
const LS_W='tm.watch.v1',LS_A='tm.alerts.v1';
const watch=()=>ls.get(LS_W,['EURUSD','Gold','US500','Bitcoin']);
const alerts=()=>ls.get(LS_A,[]);
function toggleWatch(sym){const w=watch();const i=w.indexOf(sym);if(i>=0)w.splice(i,1);else w.push(sym);ls.set(LS_W,w);renderWatch();updBadge()}
let drawer=null;
function updBadge(){
  const b=document.getElementById('tb-watch');if(!b)return;
  const act=alerts().filter(a=>!a.fired).length;
  b.querySelector('i').textContent=act?act:'';b.querySelector('i').style.display=act?'':'none';
}
function addAlert(sym,price,note){
  const a=T.assetOf(sym);if(!a||!isFinite(price))return false;
  const op=price>=a.price?'>=':'<=';
  const list=alerts();list.push({id:Date.now().toString(36),sym:a.sym,op,price:+price,note:note||'',created:Date.now(),from:a.price,fired:null});
  ls.set(LS_A,list);updBadge();
  if('Notification' in window&&Notification.permission==='default')Notification.requestPermission().catch(()=>{});
  T.toast('Alert dipasang',`${a.sym} ${op==='>='?'naik ke':'turun ke'} ${T.fmt(price,price<10?5:2)} (sekarang ${T.fmt(a.price,a.price<10?5:2)})`,'ok',4000);
  return true;
}
function checkAlerts(){
  const list=alerts();let changed=false;
  list.forEach(al=>{
    if(al.fired)return;const a=T.assetOf(al.sym);if(!a||a.price==null)return;
    if((al.op==='>='&&a.price>=al.price)||(al.op==='<='&&a.price<=al.price)){
      al.fired=Date.now();al.firedAt=a.price;changed=true;
      const msg=`${al.sym} ${al.op==='>='?'menembus ke atas':'menembus ke bawah'} ${T.fmt(al.price,al.price<10?5:2)} — sekarang ${T.fmt(a.price,a.price<10?5:2)}${al.note?' · '+al.note:''}`;
      T.toast('PRICE ALERT',msg,'alert',15000);
      try{if('Notification' in window&&Notification.permission==='granted')new Notification('Price alert: '+al.sym,{body:msg})}catch(e){}
    }
  });
  if(changed){ls.set(LS_A,list);updBadge();renderWatch()}
}
function openWatch(){
  if(drawer){drawer.close();return}
  const body=h('div',{class:'wl'});
  const m=modal('WATCHLIST & PRICE ALERT',body,'drawer');
  const close0=m.close;m.close=()=>{close0();drawer=null};drawer=m;
  m.wrap.querySelector('.tm-x').onclick=m.close;m.wrap.onclick=e=>{if(e.target===m.wrap)m.close()};
  renderWatch();loadAssets();
}
function renderWatch(){
  const body=document.querySelector('.tm-modal.drawer .wl');if(!body)return;
  const dl=h('datalist',{id:'wl-syms'},...assets.map(a=>h('option',{value:a.sym},a.name)));
  const inp=h('input',{class:'in',list:'wl-syms',placeholder:'Tambah simbol (mis. GBPUSD, Silver, US100)…'});
  const add=()=>{const a=T.assetOf(inp.value.trim());if(!a){T.toast('Simbol tidak dikenal',inp.value,'warn',3000);return}if(!watch().includes(a.sym))toggleWatch(a.sym);inp.value=''};
  inp.addEventListener('keydown',e=>{if(e.key==='Enter')add()});
  const rows=watch().map(sym=>{
    const a=T.assetOf(sym);const act=alerts().filter(x=>x.sym===sym&&!x.fired).length;
    return h('div',{class:'wl-row'},
      h('div',{class:'wl-sym',onclick:()=>{T.openAsset(sym);drawer&&drawer.close()}},h('b',null,sym),h('small',null,a?a.name:'memuat…')),
      h('div',{class:'wl-sp',html:a&&a.spark?T.spark(a.spark,64,22,a.pct>=0?'var(--up)':'var(--dn)'):''}),
      h('div',{class:'wl-px'},h('b',null,a?T.fmt(a.price,a.price<10?4:2):'—'),h('small',{class:a?T.cls(a.pct):''},a?T.pct(a.pct):'')),
      h('button',{class:'wl-btn'+(act?' on':''),title:'Pasang price alert',html:T.ICONS.bell,onclick:()=>alertForm(sym)}),
      h('button',{class:'wl-btn',title:'Hapus dari watchlist',html:T.ICONS.x,onclick:()=>toggleWatch(sym)}));
  });
  const act=alerts().filter(a=>!a.fired),fired=alerts().filter(a=>a.fired).slice(-8).reverse();
  const arow=(al,done)=>{const a=T.assetOf(al.sym);const dist=a&&!done?(al.price/a.price-1)*100:null;
    return h('div',{class:'al-row'+(done?' done':'')},h('span',{class:'al-op '+(al.op==='>='?'up':'dn')},al.op==='>='?'▲':'▼'),
      h('b',null,al.sym),h('span',null,T.fmt(al.price,al.price<10?5:2)),
      h('small',{class:'mut'},done?'terpicu '+T.ago(al.fired/1000)+' lalu':(dist!=null?(dist>0?'+':'')+dist.toFixed(2)+'% lagi':'')),
      al.note?h('small',{class:'mut'},al.note):null,
      h('button',{class:'wl-btn',title:'Hapus alert',html:T.ICONS.x,onclick:()=>{ls.set(LS_A,alerts().filter(x=>x.id!==al.id));updBadge();renderWatch()}}))};
  body.replaceChildren(dl,h('div',{class:'wl-add'},inp,h('button',{class:'btn on',onclick:add},'Tambah')),
    h('div',{class:'wl-sec'},'WATCHLIST',h('small',null,'harga diperbarui tiap 60 dtk')),...(rows.length?rows:[h('div',{class:'msg'},'Belum ada simbol')]),
    h('div',{class:'wl-sec'},'ALERT AKTIF ('+act.length+')',h('small',null,'aktif selama tab terminal terbuka')),...(act.length?act.map(a=>arow(a,false)):[h('div',{class:'msg'},'Klik ikon lonceng pada simbol untuk memasang alert')]),
    ...(fired.length?[h('div',{class:'wl-sec'},'TERPICU'),...fired.map(a=>arow(a,true))]:[]));
}
function alertForm(sym){
  const a=T.assetOf(sym);if(!a)return;
  const px=h('input',{class:'in',type:'number',step:'any',value:a.price});
  const note=h('input',{class:'in',placeholder:'Catatan (opsional), mis. "breakout resistance"'});
  const m=modal('PRICE ALERT · '+sym,h('div',{class:'frm'},
    h('div',{class:'mut'},`Harga sekarang ${T.fmt(a.price,a.price<10?5:2)}. Arah alert ditentukan otomatis: di atas harga sekarang = menembus ke atas, di bawah = menembus ke bawah.`),
    h('label',null,'Harga alert',px),h('label',null,'Catatan',note),
    h('button',{class:'btn on',onclick:()=>{if(addAlert(sym,parseFloat(px.value),note.value.trim())){m.close();renderWatch()}}},'Pasang alert')));
  setTimeout(()=>px.select(),0);
}
T.openWatch=openWatch;

// ------------------------------------------------------------------ KALKULATOR UKURAN POSISI
// lot = risiko USD / (jarak SL x ukuran kontrak x kurs mata uang kuotasi->USD). Ukuran kontrak bisa diubah agar sesuai broker.
const CONTRACT={FX:100000,Gold:100,Silver:5000,Platinum:50,Palladium:100,Copper:25000,'Crude Oil WTI':1000,'Brent Oil':1000,'Natural Gas':10000,Bitcoin:1,Ethereum:1};
const QUOTE_IDX={DAX30:'EUR',EU50:'EUR',CAC40:'EUR',FTSE100:'GBP',UK100:'GBP',JP225:'JPY',NIKKEI225:'JPY',HK50:'HKD',ASX200:'AUD',AUS200:'AUD',CH20:'CHF','IDX Composite':'IDR','IDX LQ45':'IDR',CSI1000:'CNY'};
function quoteOf(a){if(a.cls==='FX'&&/^[A-Z]{6}$/.test(a.sym))return a.sym.slice(3);if(a.cls==='INDEX')return QUOTE_IDX[a.sym]||'USD';return 'USD'}
// Rumus murni (diuji): B saldo USD, R risiko %, E entry, L stop loss, C ukuran kontrak per lot, fx kurs kuotasi->USD.
// Lot dibulatkan KE BAWAH ke 0.01 agar risiko nyata tidak pernah melebihi batas.
T.posSize=(B,R,E,L,C,fx)=>{
  const side=L<E?'BUY':'SELL',dist=Math.abs(E-L),riskUsd=B*R/100,perLot=dist*C*fx,lots=riskUsd/perLot;
  return {side,dist,riskUsd,perLot,lots,lotsR:Math.floor(lots*100+1e-9)/100};
};
function toUSD(ccy){
  if(ccy==='USD')return 1;
  const d=T.assetOf('USD'+ccy),r=T.assetOf(ccy+'USD');
  if(r&&r.price)return r.price;if(d&&d.price)return 1/d.price;return null;
}
function openCalc(sym){
  if(!assets.length){loadAssets().then(()=>openCalc(sym));return}
  const st=ls.get('tm.calc.v1',{bal:10000,risk:1,sym:sym||'EURUSD'});if(sym)st.sym=sym;
  const sel=h('select',{class:'in'});
  ['FX','COMMODITY','INDEX','CRYPTO'].forEach(c=>{const g=h('optgroup',{label:c});assets.filter(a=>a.cls===c).forEach(a=>g.append(h('option',{value:a.sym,selected:a.sym===st.sym},a.sym+' — '+a.name)));sel.append(g)});
  const num=(v,step='any')=>h('input',{class:'in',type:'number',step,value:v});
  const bal=num(st.bal),risk=num(st.risk,'0.1'),entry=num(''),sl=num(''),tp=num(''),contract=num(''),qccy=h('input',{class:'in',maxlength:3,style:{textTransform:'uppercase'}});
  const out=h('div',{class:'calc-out'});
  function setSym(){
    const a=T.assetOf(sel.value);if(!a)return;
    entry.value=+a.price.toPrecision(7);
    const atr=Math.abs((a.high||a.price)-(a.low||a.price))||a.price*0.005;
    sl.value=+(a.price-atr).toPrecision(7);tp.value='';
    contract.value=a.cls==='FX'?CONTRACT.FX:(CONTRACT[a.sym]||1);qccy.value=quoteOf(a);calc();
  }
  function calc(){
    const a=T.assetOf(sel.value);const B=+bal.value,R=+risk.value,E=+entry.value,L=+sl.value,P=+tp.value,C=+contract.value;
    ls.set('tm.calc.v1',{bal:B,risk:R,sym:sel.value});
    const fx=toUSD((qccy.value||'USD').toUpperCase());
    if(!a||!(B>0)||!(R>0)||!(E>0)||!(L>0)||E===L||!(C>0)){out.replaceChildren(h('div',{class:'mut'},'Isi saldo, risiko, entry, dan stop loss (berbeda dari entry).'));return}
    if(fx==null){out.replaceChildren(h('div',{class:'dn'},'Kurs '+qccy.value+'→USD tidak tersedia; isi mata uang kuotasi lain.'));return}
    const {side,dist,riskUsd,perLot,lotsR}=T.posSize(B,R,E,L,C,fx);
    const pip=a.cls==='FX'?(qccy.value.toUpperCase()==='JPY'?0.01:0.0001):null;
    const pipVal=pip?pip*C*fx:null;
    const rr=P>0&&((side==='BUY'&&P>E)||(side==='SELL'&&P<E))?Math.abs(P-E)/dist:null;
    const kv=(k,v,cls)=>h('div',{class:'kv'},h('span',null,k),h('b',{class:cls||''},v));
    out.replaceChildren(
      h('div',{class:'calc-hero'},h('small',null,'UKURAN POSISI'),h('div',null,lotsR>=0.01?lotsR.toFixed(2):'< 0.01',h('em',null,' lot')),h('span',{class:side==='BUY'?'up':'dn'},side+' · risiko $'+T.fmt(riskUsd,2))),
      kv('Jarak stop loss',T.fmt(dist,dist<1?5:2)+(pip?' ('+T.fmt(dist/pip,1)+' pip)':' poin')),
      kv('Nilai per 1 lot per '+(pip?'pip':'1.0 harga'),'$'+T.fmt(pip?pipVal:C*fx,2)),
      kv('Unit / kontrak',T.fmt(lotsR*C,0)),
      kv('Rugi bila kena SL','-$'+T.fmt(lotsR*perLot,2),'dn'),
      rr!=null?kv('Profit di TP ('+rr.toFixed(2)+'R)','+$'+T.fmt(lotsR*perLot*rr,2),'up'):kv('Take profit','—'),
      lotsR<0.01?h('div',{class:'warn'},'Risiko terlalu kecil untuk lot minimum 0.01 — perbesar risiko % atau perkecil jarak SL.'):null);
  }
  [bal,risk,entry,sl,tp,contract,qccy].forEach(x=>x.addEventListener('input',calc));sel.addEventListener('change',setSym);
  modal('KALKULATOR UKURAN POSISI',h('div',{class:'calc'},
    h('div',{class:'frm'},h('label',null,'Instrumen',sel),
      h('div',{class:'two'},h('label',null,'Saldo akun (USD)',bal),h('label',null,'Risiko per trade (%)',risk)),
      h('div',{class:'two'},h('label',null,'Entry',entry),h('label',null,'Stop loss',sl)),
      h('label',null,'Take profit (opsional)',tp),
      h('div',{class:'two'},h('label',null,'Ukuran kontrak / lot',contract),h('label',null,'Mata uang kuotasi',qccy)),
      h('div',{class:'mut',style:{fontSize:'11px'}},'Ukuran kontrak bawaan: FX 100.000, Gold 100 oz, Silver 5.000 oz, minyak 1.000 barel, indeks & kripto 1. Sesuaikan dengan spesifikasi broker Anda.')),
    out),'calcm');
  setSym();
}
T.openCalc=openCalc;T.toUSD=toUSD;T.quoteOf=quoteOf;

// tombol di bar atas
const tb=document.getElementById('tbtools');
if(tb)tb.append(
  h('button',{id:'tb-watch',class:'tbb',title:'Watchlist & price alert',onclick:openWatch},h('span',{html:T.ICONS.star}),h('i',{style:{display:'none'}})),
  h('button',{class:'tbb',title:'Kalkulator ukuran posisi',onclick:()=>openCalc()},h('span',{html:T.ICONS.calc})));

T.refreshWatch=()=>loadAssets(true);
// Harga diambil hanya bila dibutuhkan: ada alert aktif (perlu dicek tiap 60 dtk) atau laci watchlist sedang terbuka.
// Dulu ~35 KB diunduh tiap menit walau alat tidak dipakai - beban percuma lewat tunnel.
const needPrices=()=>alerts().some(a=>!a.fired)||!!drawer;
if(needPrices())loadAssets();
setInterval(()=>{if(needPrices()&&document.visibilityState!=='hidden')loadAssets(true)},60000);
setTimeout(updBadge,0);
})();
