(function(){
// Menu THINKING — peta agent sesuai contoh pengguna.
// Semua sinyal antar-agent DIROUTESKAN LEWAT AGENT 1 (NEWS): 2->6 = 2->1 lalu 1->6.
// Bola hanya muncul saat ada permintaan/pengiriman nyata (bus.pulse), tidak ada animasi permanen.
// Kabel menyala (glow + aliran) selama bola melintas.
const h=T.h;
const ICON={news:'📰',technical:'📊',fundamental:'💰',volume:'📦',quant:'∑',febrian:'👤'};
const NAME={news:'NEWS & DATA',technical:'TEKNIKAL',fundamental:'FUNDAMENTAL',volume:'VOLUME / LIQUIDITY',quant:'QUANTITATIVE',febrian:'FEBRIAN DEVELOPER'};
const CARD={server:'SERVER',news:'NEWS',technical:'TEKNIKAL',fundamental:'FUNDAMENTAL',volume:'VOLUME',quant:'QUANT',febrian:'FEBRIAN DEV'};
const AGENTNO={news:1,technical:2,fundamental:3,volume:4,quant:5,febrian:6};
const ORDER=['news','technical','fundamental','volume','quant','febrian'];
const ST={work:['BEKERJA','#3b82f6'],ok:['SIAP','#21c993'],idle:['MENUNGGU','#94a3b8'],error:['ERROR','#ff5b6b'],off:['OFF','#5b6170']};
const VB={w:1040,h:600};
// Aksen warna tiap kotak (dipakai kartu, badge, ikon, dan titik status).
const AC={server:'#60a5fa',news:'#38bdf8',technical:'#22d3ee',fundamental:'#fbbf24',volume:'#34d399',quant:'#a78bfa',febrian:'#f472b6'};
// Ikon vektor 20x20 (titik pusat 0,0) — selalu pas di dalam badge, tidak bergantung font emoji.
const ICONS={
  server:'<ellipse cx="0" cy="-5.6" rx="7.6" ry="3"/><path d="M-7.6,-5.6v5.6c0,1.66 3.4,3 7.6,3s7.6-1.34 7.6-3v-5.6"/><path d="M-7.6,0c0,1.66 3.4,3 7.6,3s7.6-1.34 7.6-3"/>',
  news:'<rect x="-7.8" y="-6.6" width="15.6" height="13.2" rx="2.2"/><path d="M-4.4,-3.2h8.8M-4.4,0.2h8.8M-4.4,3.6h5.4"/>',
  technical:'<path d="M-7.6,-6.4v12.8h15.2"/><path d="M-5.6,3.2l4-5.4 3,2.8 4.4-6"/>',
  fundamental:'<circle cx="0" cy="0" r="7.8"/><path d="M0,-4.4v8.8"/><path d="M2.6,-2.4c-.6-.9-1.5-1.4-2.6-1.4-1.4,0-2.4.8-2.4,1.9 0,1.2 1.1,1.6 2.5,1.9 1.5.3 2.6.8 2.6,2.1 0,1.2-1.1,2-2.7,2-1.2,0-2.2-.5-2.8-1.4"/>',
  volume:'<path d="M-7.6,-4.2 0,-8 7.6,-4.2v8.4L0,8 -7.6,4.2Z"/><path d="M-7.6,-4.2 0,-0.4 7.6,-4.2"/><path d="M0,-0.4v8.4"/>',
  quant:'<path d="M6.4,-6.6H-6.4L0,0l-6.4,6.6H6.4"/>',
  febrian:'<circle cx="0" cy="-3.4" r="3.8"/><path d="M-7.2,7.8c0-3.9 3.2-6.3 7.2-6.3s7.2,2.4 7.2,6.3"/>'
};

const GEO={
  server:{x:34,y:254,w:110,h:94},
  news:{x:430,y:24,w:150,h:90},
  technical:{x:196,y:474,w:140,h:84},
  fundamental:{x:366,y:474,w:140,h:84},
  volume:{x:536,y:474,w:140,h:84},
  quant:{x:706,y:474,w:140,h:84},
  febrian:{x:900,y:276,w:122,h:96},
};
const C=id=>({x:GEO[id].x+GEO[id].w/2,y:GEO[id].y+GEO[id].h/2});

// Kabel tetap. Warna: biru = server/news->febrian, kuning = news->analis 2..5, cyan redup = rel bawah.
const EDGES={
  'server-news':{d:'M89,254 V84 H430',cls:'ln-power'},
  'news-technical':{d:'M505,114 C505,300 266,300 266,474',cls:'ln-news'},
  'news-fundamental':{d:'M505,114 C505,322 436,322 436,474',cls:'ln-news'},
  'news-volume':{d:'M505,114 C505,322 606,322 606,474',cls:'ln-news'},
  'news-quant':{d:'M505,114 C505,300 776,300 776,474',cls:'ln-news'},
  'news-febrian':{d:'M580,66 H961 V276',cls:'ln-power'},
  'server-technical':{d:'M144,301 H170 V516 H196',cls:'ln-chain'},
  'technical-fundamental':{d:'M336,516 H366',cls:'ln-chain'},
  'fundamental-volume':{d:'M506,516 H536',cls:'ln-chain'},
  'volume-quant':{d:'M676,516 H706',cls:'ln-chain'},
  'quant-febrian':{d:'M846,516 H880 V324 H900',cls:'ln-chain'},
};
// Rute sinyal: semua lewat AGENT 1. Kunci = "src>dst".
const ROUTES={};
function edge(a,b){return EDGES[a+'-'+b]?[a+'-'+b,false]:EDGES[b+'-'+a]?[b+'-'+a,true]:null}
function addRoute(a,b){const e=edge(a,b);if(e)ROUTES[a+'>'+b]=e}
['server','technical','fundamental','volume','quant','febrian'].forEach(x=>{addRoute('news',x);addRoute(x,'news')});
addRoute('server','news');
// Rute dua langkah: agent mana pun -> news -> agent lain
function route(src,dst){
  if(!GEO[src]||!GEO[dst])return [];
  if(src==='news'||dst==='news'){const e=edge(src,dst);return e?[[src,dst,e]]:[]}
  const a=edge(src,'news'),b=edge('news',dst);
  return (a&&b)?[[src,'news',a],['news',dst,b]]:[];
}

function buildSvg(){
  const links=Object.entries(EDGES).map(([k,e])=>`<path id="ln-${k}" class="${e.cls}" d="${e.d}"/>`).join('');
  const box=(id,cls)=>{
    const b=GEO[id],cx=b.x+b.w/2,ac=AC[id];
    const badgeY=b.y+26;
    const label=CARD[id];
    const isServer=id==='server';
    return `<g class="tn ${cls}" data-id="${id}" style="--ac:${ac}">`+
      `<rect class="tn-card" x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" rx="14"/>`+
      `<rect class="tn-inner" x="${b.x+.6}" y="${b.y+.6}" width="${b.w-1.2}" height="${b.h-1.2}" rx="13.4"/>`+
      `<circle class="tn-dot" cx="${b.x+b.w-13}" cy="${b.y+13}" r="2.6"/>`+
      `<g class="tn-badge" transform="translate(${cx} ${badgeY})">`+
        `<circle class="tn-ring" r="17"/>`+
        `<g class="tn-ico">${ICONS[id]}</g>`+
      `</g>`+
      `<text x="${cx}" y="${badgeY+30}" class="tn-nm">${label}</text>`+
      `<text x="${cx}" y="${badgeY+44}" class="tn-st"${isServer?'':' data-st="'+id+'"'}>${isServer?'ONLINE':'—'}</text>`+
      `</g>`;
  };
  return `<svg class="think-svg" viewBox="0 0 ${VB.w} ${VB.h}" preserveAspectRatio="xMidYMid meet">
    <defs>
      <radialGradient id="tg-bg" cx="46%" cy="38%" r="96%"><stop offset="0" stop-color="#141920"/><stop offset=".48" stop-color="#0a0d12"/><stop offset="1" stop-color="#040507"/></radialGradient>
      <radialGradient id="tg-halo" cx="30%" cy="15%" r="52%"><stop offset="0" stop-color="#f0a92e" stop-opacity=".11"/><stop offset=".46" stop-color="#f0a92e" stop-opacity=".035"/><stop offset="1" stop-color="#f0a92e" stop-opacity="0"/></radialGradient>
      <radialGradient id="tg-halo2" cx="86%" cy="51%" r="43%"><stop offset="0" stop-color="#21c993" stop-opacity=".08"/><stop offset=".48" stop-color="#21c993" stop-opacity=".03"/><stop offset="1" stop-color="#21c993" stop-opacity="0"/></radialGradient>
      <radialGradient id="tg-halo3" cx="20%" cy="82%" r="44%"><stop offset="0" stop-color="#4cc9f0" stop-opacity=".07"/><stop offset=".5" stop-color="#4cc9f0" stop-opacity=".025"/><stop offset="1" stop-color="#4cc9f0" stop-opacity="0"/></radialGradient>
      <radialGradient id="tg-blob-cyan"><stop offset="0" stop-color="#f0a92e" stop-opacity=".13"/><stop offset=".42" stop-color="#c9821c" stop-opacity=".05"/><stop offset="1" stop-color="#c9821c" stop-opacity="0"/></radialGradient>
      <radialGradient id="tg-blob-violet"><stop offset="0" stop-color="#21c993" stop-opacity=".09"/><stop offset=".44" stop-color="#159f74" stop-opacity=".035"/><stop offset="1" stop-color="#159f74" stop-opacity="0"/></radialGradient>
      <radialGradient id="tg-blob-blue"><stop offset="0" stop-color="#4cc9f0" stop-opacity=".1"/><stop offset=".44" stop-color="#2a8fb3" stop-opacity=".04"/><stop offset="1" stop-color="#2a8fb3" stop-opacity="0"/></radialGradient>
      <pattern id="tg-grid" width="56" height="56" patternUnits="userSpaceOnUse">
        <path d="M56 0H0V56" fill="none" stroke="#3a4252" stroke-opacity=".3" stroke-width="1"/>
        <path d="M28 0V56M0 28H56" fill="none" stroke="#3a4252" stroke-opacity=".06" stroke-width="1"/>
      </pattern>
      <filter id="tg-soft" x="-45%" y="-60%" width="190%" height="220%"><feGaussianBlur stdDeviation="26"/></filter>
      <radialGradient id="tg-vignette" cx="50%" cy="50%" r="74%"><stop offset=".6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".46"/></radialGradient>
      <linearGradient id="tg-card" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#151b23"/><stop offset=".62" stop-color="#0e1218"/><stop offset="1" stop-color="#0a0d12"/></linearGradient>
      <linearGradient id="tg-cardLive" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#231c10"/><stop offset=".62" stop-color="#15120c"/><stop offset="1" stop-color="#0c0b09"/></linearGradient>
      <linearGradient id="tg-sheen" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".05"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
      <linearGradient id="tg-power" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#38bdf8" stop-opacity=".35"/><stop offset="1" stop-color="#38bdf8" stop-opacity=".78"/></linearGradient>
      <linearGradient id="tg-news" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f59e0b" stop-opacity=".6"/><stop offset="1" stop-color="#f59e0b" stop-opacity=".18"/></linearGradient>
      <filter id="tglow" x="-70%" y="-70%" width="240%" height="240%"><feGaussianBlur stdDeviation="2.6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>
    <rect x="-1200" y="-700" width="3400" height="2000" fill="url(#tg-bg)"/>
    <rect x="-1200" y="-700" width="3400" height="2000" fill="url(#tg-halo)"/>
    <rect x="-1200" y="-700" width="3400" height="2000" fill="url(#tg-halo2)"/>
    <rect x="-1200" y="-700" width="3400" height="2000" fill="url(#tg-halo3)"/>
    <rect x="-1200" y="-700" width="3400" height="2000" fill="url(#tg-grid)"/>
    <g pointer-events="none" filter="url(#tg-soft)">
      <ellipse cx="188" cy="112" rx="220" ry="126" fill="url(#tg-blob-cyan)"/>
      <ellipse cx="850" cy="158" rx="216" ry="184" fill="url(#tg-blob-violet)"/>
      <ellipse cx="156" cy="528" rx="248" ry="132" fill="url(#tg-blob-blue)"/>
      <ellipse cx="690" cy="470" rx="200" ry="126" fill="url(#tg-blob-violet)"/>
    </g>
    <rect x="-1200" y="-700" width="3400" height="2000" fill="url(#tg-vignette)"/>
    <g id="t-zoom"><g id="t-links">${links}</g><g id="t-packets"></g>
      <g id="t-nodes">${box('server','tn-server')}${box('news','tn-agent')}${box('technical','tn-agent')}${box('fundamental','tn-agent')}${box('volume','tn-agent')}${box('quant','tn-agent')}${box('febrian','tn-feb')}</g>
    </g>
  </svg>`;
}

function statusText(st,agent){
  const a=st.agents&&st.agents[agent];
  if(!a)return '—';
  const s=ST[a.status]||ST.off;
  return a.alive?s[0]:'OFF';
}

T.Views.thinking=function(root){
  const g=T.gen;
  const shell=h('div',{class:'think'});
  const head=h('div',{class:'think-head'});
  const map=h('div',{class:'think-map',title:'Gulir untuk zoom · seret untuk menggeser · klik 2x untuk reset'});
  map.innerHTML=buildSvg();
  const side=h('div',{class:'think-side'});
  shell.append(head,map,side);
  root.append(shell);
  const svg=map.querySelector('svg');
  const zoomG=svg.querySelector('#t-zoom');
  const pk=svg.querySelector('#t-packets');
  const seen=new Set();

  // --- viewBox adaptif: peta selalu mengisi bingkai penuh (tanpa gap kiri/kanan) ---
  // Rasio viewBox mengikuti rasio panel, sehingga tidak ada letterbox di layar lebar/memanjang.
  const view={x:0,y:0,w:VB.w,h:VB.h};
  function fit(){
    const r=map.getBoundingClientRect();
    if(!r.width||!r.height)return;
    // Skala tetap: peta selalu tampil sebesar yang sama walau rasio layar diubah-ubah.
    // Hanya mengecil bila panel benar-benar lebih kecil dari ukuran desain; tidak ikut membesar tanpa batas.
    const k=Math.max(0.42,Math.min(1.15,Math.min(r.width/VB.w,r.height/VB.h)));
    view.w=r.width/k;view.h=r.height/k;
    view.x=(VB.w-view.w)/2;view.y=(VB.h-view.h)/2;
    svg.setAttribute('viewBox',`${view.x.toFixed(2)} ${view.y.toFixed(2)} ${view.w.toFixed(2)} ${view.h.toFixed(2)}`);
    clamp();
  }
  let z=1,tx=0,ty=0;
  // Geser dibatasi: bila gambar lebih kecil dari jendela -> tepat di tengah; bila lebih besar ->
  // tidak boleh ada ruang kosong di tepi (gambar selalu menutupi jendela).
  function clamp(){
    const sw=z*VB.w,sh=z*VB.h;
    tx=sw<=view.w?view.x+(view.w-sw)/2:Math.max(view.x+view.w-sw,Math.min(view.x,tx));
    ty=sh<=view.h?view.y+(view.h-sh)/2:Math.max(view.y+view.h-sh,Math.min(view.y,ty));
    zoomG.setAttribute('transform',`translate(${tx.toFixed(2)} ${ty.toFixed(2)}) scale(${z.toFixed(3)})`);
    map.style.cursor=z>1.001?'grab':'default';
  }
  function toVB(clientX,clientY){
    const r=svg.getBoundingClientRect(),k=r.width/view.w;
    return {x:view.x+(clientX-r.left)/k,y:view.y+(clientY-r.top)/k,k};
  }
  function zoomAt(clientX,clientY,factor){
    const p=toVB(clientX,clientY);
    const nz=Math.max(1,Math.min(2.6,z*factor));
    if(nz===z)return;
    tx=p.x-(p.x-tx)*(nz/z);ty=p.y-(p.y-ty)*(nz/z);
    z=nz;clamp();
  }
  map.addEventListener('wheel',e=>{e.preventDefault();zoomAt(e.clientX,e.clientY,e.deltaY<0?1.16:1/1.16)},{passive:false});
  map.addEventListener('dblclick',()=>{z=1;tx=0;ty=0;clamp()});
  let drag=null;
  map.addEventListener('pointerdown',e=>{if(z<=1)return;drag={x:e.clientX,y:e.clientY,tx,ty};map.setPointerCapture(e.pointerId);map.style.cursor='grabbing'});
  map.addEventListener('pointermove',e=>{
    if(!drag)return;
    const k=toVB(e.clientX,e.clientY).k;
    tx=drag.tx+(e.clientX-drag.x)/k;ty=drag.ty+(e.clientY-drag.y)/k;clamp();
  });
  const endDrag=()=>{drag=null;map.style.cursor=z>1?'grab':'default'};
  map.addEventListener('pointerup',endDrag);map.addEventListener('pointercancel',endDrag);
  if(window.ResizeObserver){const ro=new ResizeObserver(()=>fit());ro.observe(map);T.timers.push(()=>ro.disconnect())}
  window.addEventListener('resize',fit);
  fit();

  // --- bola sinyal: muncul hanya saat bus mencatat pulse ---------------------------
  // Bola digerakkan JS di sepanjang kabel (getPointAtLength), bukan SMIL <animateMotion>: `begin` SMIL dihitung dari awal
  // dokumen SVG (bukan saat bola ditambahkan) dan <mpath> yang tidak dikenali membuat bola diam di titik (0,0) - itulah
  // bola biru/kuning "nyasar" di kiri peta. Bola tidak terlihat sebelum waktunya mulai dan dihapus begitu sampai.
  const flying=[];let raf=0;
  function packet(pathId,color,dur,begin,reverse){
    const path=svg.querySelector('#'+pathId);
    if(!path||!path.getTotalLength)return;
    const c=document.createElementNS('http://www.w3.org/2000/svg','circle');
    c.setAttribute('r',5.8);c.setAttribute('fill',color);c.setAttribute('filter','url(#tglow)');
    c.setAttribute('visibility','hidden');
    pk.appendChild(c);
    flying.push({c,path,len:path.getTotalLength(),t0:performance.now()+begin*1000,dur:dur*1000,reverse});
    if(!raf)raf=requestAnimationFrame(fly);
  }
  function fly(now){
    raf=0;
    for(let i=flying.length-1;i>=0;i--){
      const f=flying[i],u=(now-f.t0)/f.dur;
      if(u>=1||!f.c.isConnected){f.c.remove();flying.splice(i,1);continue}
      if(u<0)continue;
      const p=f.path.getPointAtLength(f.len*(f.reverse?1-u:u));
      f.c.setAttribute('cx',p.x.toFixed(1));f.c.setAttribute('cy',p.y.toFixed(1));f.c.setAttribute('visibility','visible');
    }
    if(flying.length)raf=requestAnimationFrame(fly);
  }
  T.timers.push(()=>{if(raf)cancelAnimationFrame(raf);raf=0;flying.length=0});
  function glow(pathId,begin,dur,color){
    const el=svg.querySelector('#'+pathId);
    if(!el)return;
    setTimeout(()=>{
      el.classList.add('flow-on');el.style.setProperty('--flow',color);
      setTimeout(()=>{el.classList.remove('flow-on');el.style.removeProperty('--flow')},dur*1000+250);
    },begin*1000);
  }
  function drawPulses(st){
    const now=Date.now()/1000;
    (st.pulses||[]).forEach(p=>{
      const k=p.at+'|'+p.src+'|'+p.dst+'|'+p.kind;
      if(seen.has(k))return;
      seen.add(k);
      if(now-p.at>8)return;
      const hops=route(p.src,p.dst);
      if(!hops.length)return;
      const color=p.kind==='request'?'#f59e0b':'#38bdf8';
      let delay=0;
      hops.forEach(([a,b,[pid,rev]])=>{
        const dur=hops.length>1?1.05:1.5;
        packet('ln-'+pid,color,dur,delay,rev);
        glow('ln-'+pid,delay,dur,color);
        delay+=dur+0.12;
      });
    });
    if(seen.size>600)seen.clear();
  }

  function nodeStatus(st){
    svg.querySelectorAll('[data-st]').forEach(el=>{
      const id=el.getAttribute('data-st');
      el.textContent=statusText(st,id);
      el.setAttribute('data-s',(st.agents[id]||{}).status||'off');
    });
    svg.querySelectorAll('.tn[data-id]').forEach(el=>{
      const id=el.getAttribute('data-id');
      if(id==='server'){el.setAttribute('data-s','ok');return}
      const a=st.agents&&st.agents[id];
      el.setAttribute('data-s',a&&a.alive?a.status:'off');
    });
  }

  function drawSide(st){
    const ag=st.agents||{};
    const active=(st.active||[]).length;
    const bt=st.backtest&&st.backtest.running?' · ⏸ BACKTEST berjalan, fitur lain dijeda':'';
    head.replaceChildren(
      h('div',{class:'think-title'},h('b',null,'PETA AGENT'),h('span',{class:'mut'},` · ${active}/6 agent aktif${bt}`)),
      h('div',{class:'think-legend'},h('span',null,h('i',{style:{background:'#38bdf8'}}),'server / febrian'),
        h('span',null,h('i',{style:{background:'#f59e0b'}}),'news → analis'),
        h('span',null,h('i',{style:{background:'#21c993'}}),'sinyal data'),
        h('span',{class:'mut'},' · scroll = zoom')));
    side.replaceChildren(
      h('div',{class:'think-panel'},h('div',{class:'ph'},'AKTIVITAS AGENT'),
        ...ORDER.map(id=>{const a=ag[id]||{};const s=ST[a.status]||ST.off;
          return h('div',{class:'think-agent','data-s':a.alive?(a.status||'off'):'off'},
            h('div',{class:'think-arow'},h('b',null,h('span',{class:'think-no'},AGENTNO[id]),' '+NAME[id]),
              h('span',{class:'think-badge',style:{background:s[1]+'22',color:s[1]}},s[0])),
            h('div',{class:'think-act'},a.activity||'—'),
            a.task?h('div',{class:'mut'},'tugas: '+a.task):null,
            a.progress!=null?h('div',{class:'think-bar'},h('i',{style:{width:Math.round(a.progress*100)+'%'}})):null);})),
      st.world&&st.world.lines?h('div',{class:'think-panel think-world'},h('div',{class:'ph'},'KONTEKS DUNIA · SUMBER AGENT'),
        ...st.world.lines.map(l=>h('div',{class:'think-wl'+(l.startsWith('SHOCK')?' shock':'')},l)),
        (st.world.woken||[]).length?h('div',{class:'think-wl mut'},'Analisa ulang dipicu kejadian: '+st.world.woken.map(w=>w.sym+' ('+T.ago(w.at)+')').join(', ')):null,
        h('div',{class:'think-wl mut'},'sumber: '+Object.entries(st.world.sources||{}).map(([k,v])=>k+' '+(v==='ok'||v==='cache'?'✓':'·')).join('  '))):null,
      h('div',{class:'think-panel think-log'},h('div',{class:'ph'},'LOG'),
        ...(st.logs||[]).slice(-60).reverse().map(l=>h('div',{class:'think-line '+l.level,
          title:new Date(l.at*1000).toLocaleString()},
          h('span',{class:'mut'},new Date(l.at*1000).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'})),
          h('b',null,(ICON[l.agent]||'')+' '),h('span',null,l.text)))));
  }

  async function tick(){
    if(g!==T.gen)return;
    let st;
    try{st=await T.rawFetch('thinking/state')}catch(e){return}
    if(g!==T.gen)return;
    nodeStatus(st);drawPulses(st);drawSide(st);
  }
  tick();T.every(1600,tick);
};
})();
