(function(){
const h=T.h;
const QUAD=[['STAGFLATION','left','top'],['REFLATION','right','top'],['DEFLATION','left','bottom'],['EXPANSION','right','bottom']];
function quadChart(el,all,sel,path){
  const pts=Object.entries(all||{}).map(([cc,v])=>({name:cc,value:[v.g,v.i],itemStyle:{color:v.color},label:{show:true,formatter:cc,color:v.color,fontSize:10,position:'right'}}));
  const m=Math.max(2,...pts.flatMap(p=>p.value.map(Math.abs)),...(path||[]).flatMap(p=>[Math.abs(p.g),Math.abs(p.i)]))*1.15;
  const c=T.chart(el,{
    grid:{left:30,right:20,top:20,bottom:28},
    xAxis:T.axis({type:'value',min:-m,max:m,name:'GROWTH',nameLocation:'middle',nameGap:18,nameTextStyle:{color:'#5b6170',fontSize:9},splitLine:{show:false}}),
    yAxis:T.axis({type:'value',min:-m,max:m,name:'INFLATION',nameTextStyle:{color:'#5b6170',fontSize:9},splitLine:{show:false}}),
    tooltip:{trigger:'item',backgroundColor:'#07090c',borderColor:'#243041',textStyle:{color:'#e6e1d3',fontSize:11},formatter:p=>p.data.label2||`${p.name}: G ${p.value[0].toFixed(2)} / I ${p.value[1].toFixed(2)}`},
    graphic:QUAD.map(([t,x,y])=>({type:'text',[x]:38,[y]:30,style:{text:t,fill:'#34404f',fontSize:10,fontWeight:700}})),
    series:[
      {type:'scatter',data:pts,symbolSize:10,markLine:{silent:true,symbol:'none',lineStyle:{color:'#243041'},data:[{xAxis:0},{yAxis:0}],label:{show:false}}},
      {type:'line',smooth:false,symbol:'circle',symbolSize:5,lineStyle:{color:'#f59e0b',width:1.5},itemStyle:{color:'#f59e0b'},data:(path||[]).map(p=>({value:[p.g,p.i],label2:`${p.label}: G ${p.g.toFixed(2)} / I ${p.i.toFixed(2)}`})),z:5}
    ]
  });
  return c;
}
function driversTable(list,mode){
  let rows=list.slice();
  if(mode==='z')rows.sort((a,b)=>Math.abs(b.z)-Math.abs(a.z));
  return T.table(mode==='z'?[{label:'Indicator',left:true,get:r=>r.label,cls:()=>'wrap'},{label:'Signal (Z)',k:'z',fmt:v=>T.sgn(v),cls:v=>T.cls(v)},{label:'Type',k:'type'}]
    :[{label:'Indicator',left:true,get:r=>r.label,cls:()=>'wrap'},{label:'Actual',k:'actual',fmt:v=>T.fmt(v,2)},{label:'Mean (μ)',k:'mean',fmt:v=>T.fmt(v,2)},{label:'Z-Score',k:'z',fmt:v=>T.sgn(v),cls:v=>T.cls(v)}],rows);
}
T.Views.macro=function(root){
  const S=T.mem('macro',{tab:'data',cc:'US',cmpA:'US',cmpB:'CN'});let tab=S.tab,cc=S.cc,cmpA=S.cmpA,cmpB=S.cmpB;
  const top=h('div',{class:'row',style:{marginBottom:'8px'}});
  const body=h('div');
  const tabs=T.tabs([{id:'data',label:'Economic Data'},{id:'overview',label:'Economic Overview'},{id:'regime',label:'Macro Regime'},{id:'compare',label:'Compare Data'}],tab,t=>{tab=S.tab=t;go()});
  tabs.style.marginBottom='0';
  const ctabs=T.tabs(T.countries.map(c=>({id:c[0],label:c[1]})),cc,c=>{cc=S.cc=c;go()},'sm');
  ctabs.style.marginBottom='0';
  top.append(tabs);
  root.append(top,ctabs,h('div',{style:{height:'8px'}}),body);
  function go(){
    T.dispose();
    ctabs.style.display=tab==='compare'?'none':'flex';
    ({data,overview,regime,compare}[tab])();
  }
  function data(){
    const p=T.panel('Economic Data · '+T.cname(cc),{np:1,style:{height:'calc(100vh - 232px)',minHeight:'360px'}});
    body.replaceChildren(p.el);
    T.load(p.body,T.api('macro/data',{cc}),d=>{
      p.body.append(T.table([
        {label:'Release',left:true,get:r=>r.date,cls:()=>'mut'},
        {label:'Event',left:true,get:r=>r.event,cls:()=>'wrap'},
        {label:'Impact',node:(_,r)=>T.badge(r.impact)},
        {label:'Actual',k:'actual',fmt:v=>typeof v==='number'?T.fmt(v,2):(v||'—')},
        {label:'Forecast',k:'forecast',fmt:v=>typeof v==='number'?T.fmt(v,2):(v||'—')},
        {label:'Prev',k:'previous',fmt:v=>typeof v==='number'?T.fmt(v,2):(v||'—')},
        {label:'Z',k:'z',fmt:v=>v==null?'—':T.sgn(v),cls:v=>T.cls(v)},
        {label:'History',html:(_,r)=>T.miniBars(r.history)},
        {label:'Src',k:'src',cls:()=>'mut'}
      ],d.rows));
      if(!d.rows.length)p.body.append(h('div',{class:'msg'},'Tidak ada data'));
    });
  }
  function cell(g,r,i){
    const v=r.values[i];
    if(v==null)return h('span',{class:'mut'},'—');
    const nums=r.values.filter(x=>x!=null),mx=Math.max(1e-9,...nums.map(Math.abs)),mn=Math.min(...nums),rg=(Math.max(...nums)-mn)||1;
    let bg,txt;
    if(g.kind==='level')bg=`rgba(59,130,246,${(0.08+0.42*(v-mn)/rg).toFixed(2)})`;else bg=T.heat(v,mx);
    const u=r.unit;
    txt=g.kind==='cot'?T.big(v):(u==='%'?T.fmt(v,2)+'%':(u==='bp'?T.sgn(v,1)+'bp':T.fmt(v,Math.abs(v)<100?2:0)+(u||'')));
    return h('div',{class:'cell',style:{background:bg},title:(r.dates&&r.dates[i])||''},txt);
  }
  function overview(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('macro/overview',{cc}),d=>{
      if(d.cards.length){
        const kp=h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fill,minmax(210px,1fr))',marginBottom:'8px'}});
        d.cards.forEach(c=>kp.append(h('div',{class:'kpi'},h('div',{class:'l'},c.label),h('div',{class:'v'},T.fmt(c.value,2)+(c.unit==='%'?'%':'')),h('div',{class:'s'},'Latest '+c.date+(c.previous!=null?' · prev '+T.fmt(c.previous,2):'')))));
        wrap.append(kp);
      }else wrap.append(h('div',{class:'msg err'},'Kartu indikator '+T.cname(cc)+' belum tersedia (IMF/World Bank/FRED tidak merespons).'));
      d.groups.forEach(g=>{
        const p=T.panel(g.title,{np:1});wrap.append(h('div',{style:{marginBottom:'8px'}},p.el));
        if(!g.rows.length){p.body.append(h('div',{class:'msg'},g.note||'Tidak ada data'));return}
        p.body.append(T.table([{label:'Indikator',left:true,get:r=>r.name,cls:()=>'wrap'}].concat(g.cols.map((cl,i)=>({label:cl,node:(_,r)=>cell(g,r,i)}))),g.rows));
      });
      if(d.errors&&d.errors.length)wrap.append(h('div',{class:'mut',style:{fontSize:'10px'}},'Tidak tersedia: '+d.errors.join(' · ')));
    });
  }
  function regime(){
    const wrap=h('div',{class:'grid resp',style:{gridTemplateColumns:'1.2fr 1fr',height:'calc(100vh - 232px)',minHeight:'420px'}});
    body.replaceChildren(wrap);
    const L=T.panel('Growth vs Inflation Regime Map',{np:1,bodyStyle:{padding:'4px'}}),R=T.panel('Current Regime');
    wrap.append(L.el,R.el);
    T.load(R.body,T.api('macro/regime',{cc}),r=>{
      const box=T.chartBox();box.style.height='100%';L.body.append(box);
      quadChart(box,r.all,cc,r.path);
      let mode='model';
      const dwrap=h('div');
      const sw=T.tabs([{id:'model',label:'Scoring Model'},{id:'z',label:'Z-Score Drivers'}],mode,m=>{mode=m;dwrap.replaceChildren(driversTable(r.drivers,mode))},'sm');
      R.body.append(h('div',{class:'mut',style:{fontSize:'10px'}},'CURRENT REGIME · '+r.asof+' · '+(r.mode==='monthly'?'FRED monthly':(r.source||'IMF')+' annual')),
        h('div',{class:'big',style:{color:r.color,margin:'4px 0'}},r.regime),
        h('div',{class:'row mut'},h('span',null,'GROWTH '),h('b',{class:T.cls(r.growth)},T.sgn(r.growth)),h('span',null,'  INFL '),h('b',{class:T.cls(r.inflation)},T.sgn(r.inflation))),
        h('div',{class:'txt',style:{margin:'8px 0'}},r.description),sw,dwrap);
      dwrap.append(driversTable(r.drivers,mode));
    });
  }
  function compare(){
    const wrap=h('div');body.replaceChildren(wrap);
    const sa=T.select(T.countries.map(c=>({v:c[0],l:c[1]})),cmpA,v=>{cmpA=S.cmpA=v;go()});
    const sb=T.select(T.countries.map(c=>({v:c[0],l:c[1]})),cmpB,v=>{cmpB=S.cmpB=v;go()});
    const head=h('div',{class:'row',style:{marginBottom:'8px'}},h('span',{class:'mut'},'COMPARE ECONOMIC DATA'),sa,h('span',{class:'mut'},'vs'),sb);
    const box=h('div');wrap.append(head,box);
    T.load(box,T.api('macro/compare',{a:cmpA,b:cmpB}),d=>{
      const card=(r,cc2)=>h('div',{class:'kpi',style:{borderColor:r.color+'66'}},h('div',{class:'row'},h('b',null,T.cname(cc2)),h('span',{class:'pill',style:{background:r.color+'33',color:r.color}},r.regime)),h('div',{class:'row',style:{marginTop:'8px',gap:'24px'}},h('div',null,h('div',{class:'l mut'},'GROWTH SCORE'),h('div',{class:'v '+T.cls(r.growth)},T.sgn(r.growth))),h('div',null,h('div',{class:'l mut'},'INFLATION SCORE'),h('div',{class:'v '+T.cls(r.inflation)},T.sgn(r.inflation)))));
      box.append(h('div',{class:'grid resp',style:{gridTemplateColumns:'1fr 1fr',marginBottom:'8px'}},card(d.a,cmpA),card(d.b,cmpB)));
      box.append(h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',marginBottom:'8px'}},
        h('div',{class:'kpi'},h('div',{class:'l'},'Cycle correlation (ρ)'),h('div',{class:'v'},d.correlation==null?'—':T.sgn(d.correlation))),
        h('div',{class:'kpi'},h('div',{class:'l'},'Growth differential'),h('div',{class:'v'},T.sgn(d.growth_diff)+' σ')),
        h('div',{class:'kpi'},h('div',{class:'l'},'Inflation differential'),h('div',{class:'v'},T.sgn(d.inflation_diff)+' σ')),
        h('div',{class:'kpi'},h('div',{class:'l'},'Cycle alignment'),h('div',{class:'v warn',style:{fontSize:'15px'}},d.alignment))));
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'1.2fr 1fr'}});
      const M=T.panel('Macroeconomic Alignment Matrix',{np:1}),C=T.panel('Real GDP Growth & Inflation',{np:1,bodyStyle:{height:'320px'}});
      M.body.append(T.table([{label:'Concept',left:true,get:r=>r.concept,cls:()=>'wrap'},{label:cmpA,k:'a',fmt:v=>T.fmt(v,2)},{label:'Δ',k:'delta',fmt:v=>T.sgn(v),cls:v=>T.cls(v)},{label:cmpB,k:'b',fmt:v=>T.fmt(v,2)},{label:cmpA+' hist',html:(_,r)=>T.spark(r.hist_a,60,16,'#f59e0b')},{label:cmpB+' hist',html:(_,r)=>T.spark(r.hist_b,60,16,'#ff5b6b')}],d.matrix));
      g.append(M.el,C.el);box.append(g);
      const cb=T.chartBox();C.body.append(cb);
      const years=[...new Set([...d.series.a_gdp,...d.series.b_gdp].map(x=>x[0]))].sort();
      const m=a=>years.map(y=>{const f=a.find(x=>x[0]===y);return f?f[1]:null});
      T.chart(cb,{grid:T.grid(),tooltip:T.tip(),legend:{top:0,textStyle:{color:'#8f93a0',fontSize:10}},xAxis:T.axis({type:'category',data:years}),yAxis:T.axis({type:'value'}),
        series:[{name:cmpA+' GDP',type:'line',data:m(d.series.a_gdp),color:'#f59e0b',showSymbol:false},{name:cmpB+' GDP',type:'line',data:m(d.series.b_gdp),color:'#ff5b6b',showSymbol:false},
          {name:cmpA+' CPI',type:'line',data:m(d.series.a_cpi),color:'#f59e0b',lineStyle:{type:'dashed'},showSymbol:false},{name:cmpB+' CPI',type:'line',data:m(d.series.b_cpi),color:'#ff5b6b',lineStyle:{type:'dashed'},showSymbol:false}]});
    });
  }
  go();
};
})();
