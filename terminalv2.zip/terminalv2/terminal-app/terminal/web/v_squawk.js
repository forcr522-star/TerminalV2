// =====================================================================================================================
// SQUAWK: arus headline TERCEPAT - Walter Bloomberg (@DeItaone, X), FinancialJuice, Bloomberg RSS + kabar kilat sumber lain.
//   - polling ringan /api/squawk?since=<terakhir> tiap 5 dtk (hanya baris baru, biasanya 0-2) saat tab terlihat
//   - bunyi & dibacakan (squawk box) kini diatur di PUSAT NOTIFIKASI DASHBOARD (jenis "Headline cepat"), bukan di sini
//   - filter sumber, kata kunci & "hanya FLASH"; headline baru menyala sebentar
// =====================================================================================================================
(function(){
const h=T.h;
const LS='tm.squawk.v1';
const opt=Object.assign({flashOnly:false,src:'ALL',q:''},T.ls?T.ls.get(LS,{}):{});
['sound','speak','global'].forEach(k=>delete opt[k]);       // pengaturan suara lama -> pindah ke pusat notifikasi
const save=()=>T.ls&&T.ls.set(LS,opt);
// kelompok sumber -> label & warna chip
const KIND=it=>['X','TG','BSKY'].includes(it.feed)||/\((X|TG|Bluesky)\)$/.test(it.source)?'X':it.feed==='FinancialJuice'?'FJ':/^Bloomberg/.test(it.feed||'')?'BBG':'OTHER';
const KLABEL={X:'X · SQUAWK',FJ:'FINANCIALJUICE',BBG:'BLOOMBERG',OTHER:'FLASH'};
const short=it=>{const k=KIND(it);return k==='X'?it.source.replace(/ \((X|TG|Bluesky)\)$/,''):k==='FJ'?'FinancialJuice':k==='BBG'?(it.feed||'Bloomberg').replace('Bloomberg ','BBG '):it.source};
const hhmmss=ts=>new Date(ts*1000).toLocaleTimeString('en-GB',{hour12:false});
const pass=it=>(opt.src==='ALL'||KIND(it)===opt.src)&&(!opt.flashOnly||it.flash||it.prio==='CRIT')&&(!opt.q||it.title.toLowerCase().includes(opt.q.toLowerCase()));

// ---- polling tab SQUAWK (notifikasi & suara headline cepat datang dari server lewat pusat notifikasi)
let last=0,timer=null,listeners=new Set();
async function poll(){
  if(document.visibilityState==='hidden')return;
  try{
    const d=await T.rawFetch('squawk',{since:last||undefined,n:last?50:80},{bg:true});
    const items=d.items||[];
    if(items.length){const mx=Math.max(...items.map(i=>i.seen||i.ts));const first=!last;last=Math.max(last,mx);listeners.forEach(fn=>fn(items,d,first))}
    else listeners.forEach(fn=>fn([],d,false));
  }catch(e){}
}
function start(){if(!timer){timer=setInterval(poll,5000)}}
function stopIfIdle(){if(!listeners.size&&timer){clearInterval(timer);timer=null}}

// ---- tampilan tab SQUAWK (dipanggil dari menu MARKET INTELLIGENCE)
T.squawkView=function(body){
  const list=h('div',{class:'sq-list'});
  const statusBox=h('div',{class:'sq-status'});
  const count=h('span',{class:'sq-count'},'—');
  let all=[];
  const row=(it,fresh)=>{const k=KIND(it);
    return h('a',{class:'sq-row k-'+k+(it.flash||it.prio==='CRIT'?' hot':'')+(fresh?' fresh':''),href:it.link,target:'_blank',rel:'noopener'},
      h('span',{class:'sq-t'},hhmmss(it.ts)),
      h('span',{class:'sq-src',title:it.source+(it.feed==='TG'?' · channel Telegram pihak ketiga (repost)':it.feed==='BSKY'?' · Bluesky resmi':it.feed==='X'?' · X API':'')},short(it),it.feed==='TG'?h('em',null,' TG'):it.feed==='BSKY'?h('em',null,' BSKY'):null),
      h('span',{class:'sq-h'},it.title),
      h('span',{class:'sq-age',title:'terbit '+T.ago(it.ts)+' lalu · terlihat terminal '+T.ago(it.seen||it.ts)+' lalu'},T.ago(it.ts)));
  };
  function render(freshIds){
    const v=all.filter(pass).slice(0,150);
    list.replaceChildren(...(v.length?v.map(it=>row(it,freshIds&&freshIds.has(it.id))):[h('div',{class:'msg'},all.length?'Tidak ada headline untuk filter ini':'Menunggu headline pertama…')]));
    count.textContent=v.length+' headline';
  }
  const chip=(id,label)=>h('button',{class:'chip'+(opt.src===id?' on':''),onclick:e=>{opt.src=id;save();[...e.target.parentNode.children].forEach(b=>b.classList.toggle('on',b===e.target));render()}},label);
  const fo=h('button',{class:'chip'+(opt.flashOnly?' on':''),title:'Sembunyikan headline biasa',onclick:e=>{opt.flashOnly=!opt.flashOnly;save();e.currentTarget.classList.toggle('on',opt.flashOnly);render()}},'Hanya FLASH / kritis');
  const q=h('input',{class:'in',placeholder:'Filter kata kunci (Fed, CPI, oil, gold…)',value:opt.q,oninput:e=>{opt.q=e.target.value.trim();save();render()}});
  const left=T.panel('Live Squawk',{np:1,actions:count});
  left.el.classList.add('sq-main');
  const ns=T.notifyState?T.notifyState():null;
  const nOn=ns&&ns.on&&ns.kinds.includes('squawk');
  const nlink=h('button',{class:'sq-nlink'+(nOn?' on':''),title:'Bunyi & bacakan headline baru diatur di pusat notifikasi (DASHBOARD)',onclick:()=>{location.hash='#dashboard';setTimeout(()=>T.openNotify&&T.openNotify(),400)}},
    h('span',{html:T.ICONS.bell}),nOn?'Notifikasi squawk: AKTIF':'Bunyi & bacakan: atur di Dashboard');
  left.body.append(h('div',{class:'sq-bar'},h('div',{class:'sq-chips'},chip('ALL','Semua'),chip('X','Walter Bloomberg'),chip('FJ','FinancialJuice'),chip('BBG','Bloomberg'),chip('OTHER','Flash lain')),fo,q,nlink),list);
  const admin=T.role==='admin';                       // status per sumber/feed hanya untuk admin
  const right=admin?T.panel('Sumber',{bodyStyle:{display:'flex',flexDirection:'column',gap:'12px'}}):null;
  if(right){right.el.classList.add('sq-side');right.body.append(statusBox)}
  const box=h('div',{class:'sq'+(right?'':' solo')},left.el,right?right.el:null);
  body.replaceChildren(box);
  function renderStatus(d){
    if(!d||!admin)return;
    const x=d.x||{},soc=d.social||{};
    const socRows=Object.entries(soc).map(([k,v])=>{const [kind,name]=k.split(':');
      const fresh=v.last_post&&(Date.now()/1000-v.last_post)<3*86400;
      return h('div',{class:'sq-srow',title:v.via||''},h('i',{class:v.ok?(fresh?'ok':''):'bad'}),h('span',null,(kind==='TG'?'Telegram @':'Bluesky ')+name),
        h('small',null,!v.ok?'dicoba lagi':v.last_post?'posting '+T.ago(v.last_post)+' lalu':'menunggu'))});
    const anyLive=Object.values(soc).some(v=>v.ok&&v.last_post&&(Date.now()/1000-v.last_post)<3*86400);
    const head=h('div',{class:'sq-x '+(anyLive||x.mode!=='off'&&x.ok!==false?'ok':'off')},h('b',null,'Walter Bloomberg · gratis'),
      h('span',null,anyLive?'Terhubung tanpa akun & tanpa API berbayar: Telegram (channel pihak ketiga yang memposting ulang headline Walter) + Bluesky resmi Walter (aktif bila akun itu memposting).'
        :'Menghubungkan ke Telegram & Bluesky (gratis, tanpa akun)…'),
      x.mode!=='off'?h('span',{class:'sq-xapi'},'X API: '+(x.ok===false?(x.last_error||'gagal'):'aktif · tiap '+x.poll_sec+' dtk')):null);
    const src=Object.entries(d.sources||{}).map(([name,s])=>h('div',{class:'sq-srow'},h('i',{class:s.ok?'ok':(s.error?'bad':'')}),h('span',null,name),h('small',null,s.ok?(s.n+' · tiap '+s.every+' dtk'):(s.error?'dicoba lagi':'menunggu'))));
    statusBox.replaceChildren(head,...socRows,h('div',{class:'sq-sh'},'SUMBER CEPAT LAIN (GRATIS)'),...src);
  }
  const L=(items,d,first)=>{
    if(!box.isConnected){listeners.delete(L);stopIfIdle();return}
    renderStatus(d);
    if(!items.length)return;
    const known=new Set(all.map(i=>i.id));const fresh=items.filter(i=>!known.has(i.id));
    all=fresh.concat(all).sort((a,b)=>(b.seen||b.ts)-(a.seen||a.ts)||b.ts-a.ts).slice(0,400);
    render(first?null:new Set(fresh.map(i=>i.id)));
  };
  // muat awal: data tersimpan langsung tampil (tanpa menunggu), lalu ikut polling bersama
  listeners.add(L);
  T.api('squawk',{n:150}).then(d=>{all=(d.items||[]).slice();if(all.length)last=Math.max(last,...all.map(i=>i.seen||i.ts));render();renderStatus(d)}).catch(e=>list.replaceChildren(h('div',{class:'msg err'},e.message)));
  start();
  T.timers.push(setInterval(()=>{if(!box.isConnected){listeners.delete(L);stopIfIdle()}else list.querySelectorAll('.sq-age').forEach((el,i)=>{const it=all.filter(pass)[i];if(it)el.textContent=T.ago(it.ts)})},15000));
};
})();
