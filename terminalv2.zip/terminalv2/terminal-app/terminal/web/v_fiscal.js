(function(){
const h=T.h;
const RC={'AAA':'#21c993','AA+':'#21c993','AA':'#21c993','AA-':'#21c993','A+':'#f0a92e','A':'#f0a92e','BBB':'#f97316'};
T.Views.fiscal=function(root){
  const S=T.mem('fiscal',{cc:'GLOBAL',bmode:'balance'});let cc=S.cc,bmode=S.bmode;
  const mkTabs=ccs=>T.tabs([{id:'GLOBAL',label:'Global Overview'}].concat(T.countries.filter(c=>!ccs||ccs.includes(c[0])).map(c=>({id:c[0],label:c[1]}))),cc,c=>{cc=S.cc=c;go()},'sm');
  let tabs=mkTabs(null);
  const body=h('div');root.append(tabs,body);
  // Negara yang tidak punya data publik di IMF/World Bank/BIS dihilangkan dari tab (bukan ditampilkan kosong).
  T.api('fiscal/overview').then(d=>{
    if(!d||!d.available)return;
    if(cc!=='GLOBAL'&&!d.available.includes(cc)){cc=S.cc='GLOBAL';go()}
    const nt=mkTabs(d.available);tabs.replaceWith(nt);tabs=nt;
  }).catch(()=>{});
  function go(){T.dispose();cc==='GLOBAL'?global():country()}
  function bars(el,labels,vals,colors){T.chart(el,{grid:{left:34,right:8,top:12,bottom:24},tooltip:T.tip(),xAxis:T.axis({type:'category',data:labels,axisLabel:{color:'#8a8f9c',fontSize:9}}),yAxis:T.axis({type:'value'}),series:[{type:'bar',data:vals.map((v,i)=>({value:v,itemStyle:{color:colors(v,i)}}))}]})}
  function global(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('fiscal/overview'),d0=>{
      const keep=new Set(d0.available||d0.rows.map(r=>r.cc));
      const d=Object.assign({},d0,{rows:d0.rows.filter(r=>keep.has(r.cc))});
      const sm=d.summary||{avg_debt:null,avg_balance:null,high_debt:0};
      if(!d.rows.some(r=>r.debt_gdp!=null))wrap.append(h('div',{class:'msg err'},T.role==='admin'?'Data fiskal belum bisa diambil dari IMF maupun World Bank. '+Object.values(d.errors||{}).join(' · ')+' Ketuk ⚠ di atas untuk melihat sumber yang gagal.':'Data fiskal sementara belum tersedia. Server mencoba ulang otomatis.'));
      wrap.append(h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',marginBottom:'8px'}},
        h('div',{class:'kpi'},h('div',{class:'l'},'Average debt-to-GDP'),h('div',{class:'v warn'},sm.avg_debt==null?'—':T.fmt(sm.avg_debt)+'%'),h('div',{class:'s'},'10-market mean (IMF WEO)')),
        h('div',{class:'kpi'},h('div',{class:'l'},'Average budget balance'),h('div',{class:'v dn'},sm.avg_balance==null?'—':T.fmt(sm.avg_balance)+'%'),h('div',{class:'s'},'% of GDP')),
        h('div',{class:'kpi'},h('div',{class:'l'},'High debt sovereigns'),h('div',{class:'v'},sm.high_debt+' / '+d.rows.length),h('div',{class:'s'},'debt above 100% of GDP'))));
      const p=T.panel('Global Sovereign Fiscal Monitor',{np:1});
      p.body.append(T.table([{label:'Sovereign',left:true,get:r=>r.name},{label:'Rating*',node:(_,r)=>h('span',{style:{color:RC[r.rating]||'#9ca3af'}},r.rating)},{label:'Debt / GDP',k:'debt_gdp',fmt:v=>v==null?'—':T.fmt(v)+'%',cls:v=>v>100?'dn':''},{label:'Budget balance',k:'balance',fmt:v=>v==null?'—':T.fmt(v)+'%',cls:v=>T.cls(v)},{label:'Primary balance',k:'primary',fmt:v=>v==null?'—':T.fmt(v)+'%',cls:v=>T.cls(v)},{label:'Interest paid',k:'interest',node:(v,r)=>h('span',{class:v>3?'dn':''},v==null?'—':T.fmt(v)+'%'+(r.interest_kind==='net'?' (net)':''))},{label:'Revenue',k:'revenue',fmt:v=>v==null?'—':T.fmt(v,1)+'%'},{label:'Expenditure',k:'expenditure',fmt:v=>v==null?'—':T.fmt(v,1)+'%'},{label:'Net debt',k:'net_debt',fmt:v=>v==null?'—':T.fmt(v,1)+'%'},{label:'Debt (USD)',k:'debt_usd',fmt:v=>v==null?'—':'$'+T.big(v)},{label:'Year',k:'year'}],d.rows,{onRow:r=>{cc=S.cc=r.cc;tabs.set(cc);go()}}));
      wrap.append(p.el,h('div',{class:'mut',style:{margin:'4px 2px',fontSize:'10px'}},'*Rating statis (editable di universe.py). Data fiskal: '+(d.source||'tidak tersedia')+' (IMF WEO & Fiscal Monitor, termasuk proyeksi; cadangan World Bank/BIS).'));
      if((d0.hidden||[]).length)wrap.append(h('div',{class:'mut',style:{margin:'0 2px 4px',fontSize:'10px'}},'Tidak ditampilkan (belum ada data publik di IMF/World Bank/BIS): '+d0.hidden.join(', ')));
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'repeat(4,minmax(0,1fr))',marginTop:'8px'}});
      [['Debt-to-GDP comparison','debt_gdp',(v)=>v>100?'#ff5b6b':v>60?'#f0a92e':'#21c993'],['Budget balance comparison','balance',(v)=>v<0?'#ff5b6b':'#21c993'],['Primary balance','primary',(v)=>v<0?'#ff5b6b':'#3b82f6'],['Interest burden (% GDP)','interest',(v)=>v>3?'#ff5b6b':v>2?'#f0a92e':'#21c993']].forEach(([t,k,c])=>{const q=T.panel(t,{bodyStyle:{height:'200px',padding:'4px'}});const b=T.chartBox();q.body.append(b);g.append(q.el);bars(b,d.rows.map(r=>r.cc),d.rows.map(r=>r[k]),c)});
      wrap.append(g);
    });
  }
  function country(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('fiscal/country',{cc}),d=>{
      const ex=d.extras||{};
      const pc=(v,nd)=>v==null?'—':T.fmt(v,nd==null?1:nd)+'%';
      const kp=h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(170px,1fr))',marginBottom:'8px'}});
      const k=(l,v,s,c)=>kp.append(h('div',{class:'kpi'},h('div',{class:'l'},l),h('div',{class:'v '+(c||'')},v),h('div',{class:'s'},s||'')));
      // Kartu yang sama untuk SEMUA negara (IMF WEO + Fiscal Monitor). Kartu hanya dibuat bila nilainya ada (tanpa deretan "—").
      if(d.balance!=null)k('Budget balance',pc(d.balance,2),'Fiscal balance / GDP ('+d.balance_year+')',T.cls(d.balance));
      if(ex.debt)k('Total public debt','$'+T.big(ex.debt).replace('$',''),'Gross outstanding '+ex.debt_date);
      else if(d.debt_usd!=null)k('Total public debt','≈ $'+T.big(d.debt_usd),'Gross debt in USD ('+d.debt_year+', IMF)');
      if(d.debt_gdp!=null)k('Debt-to-GDP',pc(d.debt_gdp,2),'Peak '+(d.peak[1]!=null?T.fmt(d.peak[1],1)+'% ('+d.peak[0]+')':'—'),d.debt_gdp>100?'dn':d.debt_gdp>60?'warn':'');
      if(d.net_debt!=null)k('Net debt',pc(d.net_debt),'Gross debt minus financial assets');
      if(d.primary!=null)k('Primary balance',pc(d.primary,2),'Excl. interest',T.cls(d.primary));
      if(d.interest!=null)k(d.interest_kind==='net'?'Net interest':'Interest paid',pc(d.interest,2),'of GDP'+(d.interest_rev!=null?' · '+T.fmt(d.interest_rev,0)+'% of revenue':'')+' ('+d.interest_year+')'+(d.interest_kind==='gross'&&d.net_interest!=null?' · net '+T.fmt(d.net_interest,1)+'%':''),d.interest>3?'dn':d.interest>2?'warn':'');
      if(d.revenue!=null)k('Revenue',pc(d.revenue),'Government revenue / GDP');
      if(d.expenditure!=null)k('Expenditure',pc(d.expenditure),'Government spending / GDP');
      if(d.cab!=null)k('Structural balance',pc(d.cab,2),'Cyclically adjusted (% potential GDP)',T.cls(d.cab));
      if(d.debt_proj!=null)k('Debt projection',pc(d.debt_proj),'IMF forecast '+d.debt_proj_year,d.debt_proj>d.debt_gdp?'dn':'up');
      if(ex.tga!=null)k('Treasury General Account',T.big(ex.tga,'$'),'Cash reserves');
      k('Credit rating*',d.rating,'S&P long-term (static)');
      wrap.append(kp);
      if(!d.has_data)wrap.append(h('div',{class:'msg'},'Data fiskal negara ini belum tersedia dari sumber publik.'));
      if(d.commentary)wrap.append(h('div',{class:'panel',style:{padding:'8px 12px',marginBottom:'8px',color:'#f4c46a'}},h('span',{class:'badge b-MODERATE',style:{marginRight:'8px'}},'FISCAL COMMENTARY'),d.commentary));
      const auc=d.auctions||{upcoming:[],history:[],available:false};
      const ok=a=>a&&a.length>1;
      const projLine={silent:true,symbol:'none',data:[{xAxis:String(d.this_year)}],lineStyle:{color:'#5b6170',type:'dashed'},label:{formatter:'proj. →',color:'#8a8f9c'}};
      const yearsOf=(...arrs)=>[...new Set(arrs.flat().map(x=>x.y))].sort((a,b)=>a-b);
      const val=(arr,years)=>{const m=new Map(arr.map(x=>[x.y,x.v]));return years.map(y=>m.has(y)?m.get(y):null)};
      const legend={top:0,right:6,textStyle:{color:'#8a8f9c',fontSize:10},itemWidth:12,itemHeight:6};
      const panels=[];
      // 1) lintasan utang: bruto + neto, histori & proyeksi IMF
      if(ok(d.history_debt)){
        const ys=yearsOf(d.history_debt,d.history_net||[]);
        const A=T.panel('Sovereign debt-to-GDP trajectory (history & IMF projections)',{bodyStyle:{height:'300px',padding:'4px'}});
        const b=T.chartBox();A.body.append(b);
        panels.push([A.el,2,()=>T.chart(b,{grid:T.grid({top:26}),tooltip:T.tip({valueFormatter:v=>v==null?'—':T.fmt(v,1)+'%'}),legend,xAxis:T.axis({type:'category',data:ys}),yAxis:T.axis({type:'value',scale:true,axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),
          series:[{name:'Gross debt',type:'line',smooth:true,showSymbol:false,connectNulls:true,data:val(d.history_debt,ys),lineStyle:{color:'#ff5b6b',width:2},itemStyle:{color:'#ff5b6b'},areaStyle:{color:'rgba(255,91,107,.12)'},markLine:projLine}]
            .concat(ok(d.history_net)?[{name:'Net debt',type:'line',smooth:true,showSymbol:false,connectNulls:true,data:val(d.history_net,ys),lineStyle:{color:'#f0a92e',width:1.6,type:'dashed'},itemStyle:{color:'#f0a92e'}}]:[])})]);
      }
      if(auc.available)panels.push([auctionPanel(auc),1,null]);
      // 2) saldo anggaran: total / primer / struktural
      const modes=[['balance','Overall',d.history_balance],['primary','Primary',d.history_primary],['cab','Structural',d.history_cab||[]]].filter(m=>ok(m[2]));
      if(modes.length){
        const C=T.panel('Budget balance & impulse (% GDP)',{bodyStyle:{height:'260px',padding:'4px'}});
        if(!modes.some(m=>m[0]===bmode))bmode=S.bmode=modes[0][0];
        const b2=T.chartBox();C.body.append(b2);
        const drawB=()=>{const src=(modes.find(m=>m[0]===bmode)||modes[0])[2];const c=echarts.getInstanceByDom(b2);if(c)c.dispose();
          T.chart(b2,{grid:T.grid(),tooltip:T.tip({valueFormatter:v=>T.fmt(v,2)+'%'}),xAxis:T.axis({type:'category',data:src.map(x=>x.y)}),yAxis:T.axis({type:'value',axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),
            series:[{type:'bar',data:src.map(x=>({value:x.v,itemStyle:{color:x.v<0?(x.y>d.this_year?'rgba(255,91,107,.45)':'#ff5b6b'):(x.y>d.this_year?'rgba(33,201,147,.45)':'#21c993')}})),markLine:projLine}]})};
        if(modes.length>1){const sw=T.tabs(modes.map(m=>({id:m[0],label:m[1]})),bmode,m=>{bmode=S.bmode=m;drawB()},'sm');sw.style.margin=0;C.head.append(sw)}
        panels.push([C.el,1,drawB]);
      }
      // 3) pendapatan vs belanja
      if(ok(d.history_revenue)||ok(d.history_expenditure)){
        const ys=yearsOf(d.history_revenue||[],d.history_expenditure||[]);
        const R=T.panel('Revenue vs expenditure (% GDP)',{bodyStyle:{height:'260px',padding:'4px'}});
        const b=T.chartBox();R.body.append(b);
        panels.push([R.el,1,()=>T.chart(b,{grid:T.grid({top:26}),tooltip:T.tip({valueFormatter:v=>v==null?'—':T.fmt(v,1)+'%'}),legend,xAxis:T.axis({type:'category',data:ys}),yAxis:T.axis({type:'value',scale:true,axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),
          series:[{name:'Revenue',type:'line',smooth:true,showSymbol:false,connectNulls:true,data:val(d.history_revenue||[],ys),lineStyle:{color:'#21c993',width:2},itemStyle:{color:'#21c993'}},
            {name:'Expenditure',type:'line',smooth:true,showSymbol:false,connectNulls:true,data:val(d.history_expenditure||[],ys),lineStyle:{color:'#ff7a6b',width:2},itemStyle:{color:'#ff7a6b'},markLine:projLine}]})]);
      }
      // 4) beban bunga utang: bruto (dibayar, historis) + neto (saldo primer - total, termasuk proyeksi)
      if(ok(d.history_interest)||ok(d.history_net_interest)){
        const ys=yearsOf(d.history_interest||[],d.history_net_interest||[]);
        const I=T.panel('Interest on public debt (% GDP)',{bodyStyle:{height:'260px',padding:'4px'}});
        const b=T.chartBox();I.body.append(b);
        panels.push([I.el,1,()=>T.chart(b,{grid:T.grid({top:26}),tooltip:T.tip({valueFormatter:v=>v==null?'—':T.fmt(v,2)+'%'}),legend,xAxis:T.axis({type:'category',data:ys}),yAxis:T.axis({type:'value',axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),
          series:(ok(d.history_interest)?[{name:'Paid (gross)',type:'bar',data:val(d.history_interest,ys),itemStyle:{color:'#f0a92e'}}]:[])
            .concat(ok(d.history_net_interest)?[{name:'Net (proj.)',type:'line',smooth:true,showSymbol:false,connectNulls:true,data:val(d.history_net_interest,ys),lineStyle:{color:'#4cc9f0',width:1.6},itemStyle:{color:'#4cc9f0'},markLine:projLine}]:[])})]);
      }
      // susun: baris pertama 2:1, sisanya 3 kolom; grafik digambar sesudah panel masuk DOM
      const first=panels.length&&panels[0][1]===2?panels.shift():null;
      if(first){const g=h('div',{class:'grid resp',style:{gridTemplateColumns:panels.length?'2fr 1fr':'1fr',marginBottom:'8px'}},first[0]);
        const side=panels.length?panels.shift():null;if(side)g.append(side[0]);wrap.append(g);first[2]&&first[2]();side&&side[2]&&side[2]()}
      if(panels.length){const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'repeat('+Math.min(3,panels.length)+',minmax(0,1fr))',marginBottom:'8px'}},...panels.map(p=>p[0]));wrap.append(g);panels.forEach(p=>p[2]&&p[2]())}
      if(d.news.length){
        const N=T.panel('Legislative & sovereign risk headlines',{np:1,bodyStyle:{height:'300px'}});wrap.append(N.el);
        N.body.append(...d.news.map(n=>h('a',{class:'feed',href:n.link,target:'_blank',style:{padding:'6px 10px'}},h('div',{class:'m'},h('span',{class:'acc'},T.ago(n.ts)),h('span',null,n.source)),h('div',{class:'tt'},n.title))));
      }
    });
  }
  // Panel lelang: tab "Mendatang" (jika ada) dan "Riwayat" (hasil terakhir). Dibuat hanya bila ada salah satunya.
  function auctionPanel(auc){
    const P=T.panel('Debt auctions',{np:1,bodyStyle:{height:'300px'}});
    const rate=(v,r)=>h('span',null,v==null?'—':T.fmt(v,3)+(r.unit&&r.unit!=='%'?' '+r.unit:'%'));
    const amt=(v)=>v?T.big(Number(v),'$'):'—';
    const anyAmt=rows=>rows.some(r=>r.amount);
    const colsUp=rows=>[{label:'Date',left:true,get:r=>r.date+(r.time?' '+r.time:'')},{label:'Security',left:true,get:r=>r.name}]
      .concat(anyAmt(rows)?[{label:'Offering',k:'amount',fmt:amt}]:[]).concat(rows.some(r=>r.forecast!=null)?[{label:'Fcst',node:(_,r)=>rate(r.forecast,r)}]:[]).concat(rows.some(r=>r.previous!=null)?[{label:'Prev',node:(_,r)=>rate(r.previous,r)}]:[]);
    const colsHi=rows=>[{label:'Date',left:true,get:r=>r.date},{label:'Security',left:true,get:r=>r.name},{label:'Yield',node:(_,r)=>rate(r.rate,r)}]
      .concat(rows.some(r=>r.btc!=null)?[{label:'Bid/Cover',k:'btc',fmt:v=>v==null?'—':T.fmt(v,2)+'x'}]:[]).concat(anyAmt(rows)?[{label:'Offering',k:'amount',fmt:amt}]:[]);
    const tabsDef=[];
    if(auc.upcoming.length)tabsDef.push({id:'up',label:'Mendatang ('+auc.upcoming.length+')'});
    if(auc.history.length)tabsDef.push({id:'hi',label:'Riwayat ('+auc.history.length+')'});
    let cur=tabsDef[0].id;
    const box=h('div');
    const draw=()=>box.replaceChildren(cur==='up'?T.table(colsUp(auc.upcoming),auc.upcoming):T.table(colsHi(auc.history),auc.history),h('div',{class:'mut',style:{padding:'4px 10px',fontSize:'10px'}},'Sumber: '+(auc.sources.join(', ')||'—')));
    if(tabsDef.length>1){const t=T.tabs(tabsDef,cur,x=>{cur=x;draw()},'sm');t.style.margin=0;P.head.append(t)}
    P.body.append(box);draw();
    return P.el;
  }
  go();
};
})();
