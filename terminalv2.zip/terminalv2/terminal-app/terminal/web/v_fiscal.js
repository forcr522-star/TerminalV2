(function(){
const h=T.h;
const RC={'AAA':'#21c993','AA+':'#21c993','AA':'#21c993','AA-':'#21c993','A+':'#f0a92e','A':'#f0a92e','BBB':'#f97316'};
T.Views.fiscal=function(root){
  const S=T.mem('fiscal',{cc:'GLOBAL',bmode:'balance'});let cc=S.cc,bmode=S.bmode;
  const mkTabs=ccs=>T.tabs([{id:'GLOBAL',label:'Global Overview'}].concat(T.countries.filter(c=>!ccs||ccs.includes(c[0])).map(c=>({id:c[0],label:c[1]}))),cc,c=>{cc=S.cc=c;go()},'sm');
  let tabs=mkTabs(null);
  const body=h('div');root.append(tabs,body);
  // Negara yang tidak punya data publik di IMF/World Bank/BIS dihilangkan dari tab (bukan ditampilkan kosong).
  T.api('fiscal/overview').then(d=>{
    if(!d||!d.available)return;
    if(cc!=='GLOBAL'&&!d.available.includes(cc)){cc=S.cc='GLOBAL';go()}
    const nt=mkTabs(d.available);tabs.replaceWith(nt);tabs=nt;
  }).catch(()=>{});
  function go(){T.dispose();cc==='GLOBAL'?global():country()}
  function bars(el,labels,vals,colors){T.chart(el,{grid:{left:34,right:8,top:12,bottom:24},tooltip:T.tip(),xAxis:T.axis({type:'category',data:labels,axisLabel:{color:'#8a8f9c',fontSize:9}}),yAxis:T.axis({type:'value'}),series:[{type:'bar',data:vals.map((v,i)=>({value:v,itemStyle:{color:colors(v,i)}}))}]})}
  function global(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('fiscal/overview'),d0=>{
      const keep=new Set(d0.available||d0.rows.map(r=>r.cc));
      const d=Object.assign({},d0,{rows:d0.rows.filter(r=>keep.has(r.cc))});
      const sm=d.summary||{avg_debt:null,avg_balance:null,high_debt:0};
      if(!d.rows.some(r=>r.debt_gdp!=null))wrap.append(h('div',{class:'msg err'},'Data fiskal belum bisa diambil dari IMF maupun World Bank. '+Object.values(d.errors||{}).join(' · ')+' Ketuk ⚠ di atas untuk melihat sumber yang gagal.'));
      wrap.append(h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',marginBottom:'8px'}},
        h('div',{class:'kpi'},h('div',{class:'l'},'Average debt-to-GDP'),h('div',{class:'v warn'},sm.avg_debt==null?'—':T.fmt(sm.avg_debt)+'%'),h('div',{class:'s'},'10-market mean (IMF WEO)')),
        h('div',{class:'kpi'},h('div',{class:'l'},'Average budget balance'),h('div',{class:'v dn'},sm.avg_balance==null?'—':T.fmt(sm.avg_balance)+'%'),h('div',{class:'s'},'% of GDP')),
        h('div',{class:'kpi'},h('div',{class:'l'},'High debt sovereigns'),h('div',{class:'v'},sm.high_debt+' / '+d.rows.length),h('div',{class:'s'},'debt above 100% of GDP'))));
      const p=T.panel('Global Sovereign Fiscal Monitor',{np:1});
      p.body.append(T.table([{label:'Sovereign',left:true,get:r=>r.name},{label:'Rating*',node:(_,r)=>h('span',{style:{color:RC[r.rating]||'#9ca3af'}},r.rating)},{label:'Debt / GDP',k:'debt_gdp',fmt:v=>v==null?'—':T.fmt(v)+'%',cls:v=>v>100?'dn':''},{label:'Budget balance',k:'balance',fmt:v=>v==null?'—':T.fmt(v)+'%',cls:v=>T.cls(v)},{label:'Primary balance',k:'primary',fmt:v=>v==null?'—':T.fmt(v)+'%',cls:v=>T.cls(v)},{label:'Gross debt (LCU bn)',k:'gross_debt',fmt:v=>T.big(v*1e9)},{label:'Year',k:'year'}],d.rows,{onRow:r=>{cc=S.cc=r.cc;tabs.set(cc);go()}}));
      wrap.append(p.el,h('div',{class:'mut',style:{margin:'4px 2px',fontSize:'10px'}},'*Rating statis (editable di universe.py). Data fiskal: '+(d.source||'tidak tersedia')+(d.source&&d.source.indexOf('World Bank')>=0?' (World Bank tidak punya primary balance & gross debt LCU).':'.')));
      if((d0.hidden||[]).length)wrap.append(h('div',{class:'mut',style:{margin:'0 2px 4px',fontSize:'10px'}},'Tidak ditampilkan (belum ada data publik di IMF/World Bank/BIS): '+d0.hidden.join(', ')));
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'repeat(3,1fr)',marginTop:'8px'}});
      [['Debt-to-GDP comparison','debt_gdp',(v)=>v>100?'#ff5b6b':v>60?'#f0a92e':'#21c993'],['Budget balance comparison','balance',(v)=>v<0?'#ff5b6b':'#21c993'],['Primary balance','primary',(v)=>v<0?'#ff5b6b':'#3b82f6']].forEach(([t,k,c])=>{const q=T.panel(t,{bodyStyle:{height:'200px',padding:'4px'}});const b=T.chartBox();q.body.append(b);g.append(q.el);bars(b,d.rows.map(r=>r.cc),d.rows.map(r=>r[k]),c)});
      wrap.append(g);
    });
  }
  function country(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('fiscal/country',{cc}),d=>{
      const ex=d.extras||{};
      const kp=h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(170px,1fr))',marginBottom:'8px'}});
      const k=(l,v,s,c)=>kp.append(h('div',{class:'kpi'},h('div',{class:'l'},l),h('div',{class:'v '+(c||'')},v),h('div',{class:'s'},s||'')));
      // Kartu hanya dibuat bila nilainya ada (tanpa deretan "—").
      if(d.balance!=null)k('Budget deficit',T.fmt(d.balance)+'%','Fiscal balance / GDP',T.cls(d.balance));
      if(ex.debt)k('Total public debt','$'+T.big(ex.debt).replace('$',''),'Gross outstanding '+ex.debt_date);
      else if(d.gross_debt!=null)k('Total public debt',T.big(d.gross_debt*1e9),'Gross debt (LCU)');
      if(d.debt_gdp!=null)k('Debt-to-GDP',T.fmt(d.debt_gdp)+'%','Peak '+(d.peak[1]!=null?T.fmt(d.peak[1],1)+'% ('+d.peak[0]+')':'—'),d.debt_gdp>100?'dn':'');
      if(d.primary!=null)k('Primary balance',T.fmt(d.primary)+'%','Excl. interest',T.cls(d.primary));
      if(ex.tga!=null)k('Treasury General Account',T.big(ex.tga,'$'),'Cash reserves');
      k('Credit rating*',d.rating,'S&P long-term (static)');
      wrap.append(kp);
      if(!d.has_data)wrap.append(h('div',{class:'msg'},'Data fiskal negara ini belum tersedia dari sumber publik.'));
      if(d.commentary)wrap.append(h('div',{class:'panel',style:{padding:'8px 12px',marginBottom:'8px',color:'#f4c46a'}},h('span',{class:'badge b-MODERATE',style:{marginRight:'8px'}},'FISCAL COMMENTARY'),d.commentary));
      const auc=d.auctions||{upcoming:[],history:[],available:false};
      const hasDebt=d.history_debt.length>1,hasBal=d.history_balance.length>1||d.history_primary.length>1;
      if(hasDebt||auc.available){
        const g=h('div',{class:'grid resp',style:{gridTemplateColumns:(hasDebt&&auc.available)?'2fr 1fr':'1fr',marginBottom:'8px'}});
        if(hasDebt){
          const A=T.panel('Sovereign debt-to-GDP trajectory (history & IMF projections)',{bodyStyle:{height:'300px',padding:'4px'}});g.append(A.el);wrap.append(g);
          const b1=T.chartBox();A.body.append(b1);
          T.chart(b1,{grid:T.grid(),tooltip:T.tip(),xAxis:T.axis({type:'category',data:d.history_debt.map(x=>x.y)}),yAxis:T.axis({type:'value',scale:true,axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),
            series:[{type:'line',smooth:true,showSymbol:false,data:d.history_debt.map(x=>x.v),lineStyle:{color:'#ff5b6b',width:2},areaStyle:{color:'rgba(255,91,107,.12)'},markLine:{silent:true,symbol:'none',data:[{xAxis:String(d.this_year)}],lineStyle:{color:'#5b6170',type:'dashed'},label:{formatter:'proj.',color:'#8a8f9c'}}}]});
        }else wrap.append(g);
        if(auc.available)g.append(auctionPanel(auc));
      }
      if(hasBal||d.news.length){
        const g2=h('div',{class:'grid resp',style:{gridTemplateColumns:(hasBal&&d.news.length)?'1fr 1fr':'1fr'}});wrap.append(g2);
        if(hasBal){
          const C=T.panel('Budget balance & impulse',{bodyStyle:{height:'260px',padding:'4px'}});
          const modes=[['balance','Balance % GDP',d.history_balance],['primary','Primary % GDP',d.history_primary]].filter(m=>m[2].length>1);
          if(!modes.some(m=>m[0]===bmode))bmode=S.bmode=modes[0][0];
          if(modes.length>1){const sw=T.tabs(modes.map(m=>({id:m[0],label:m[1]})),bmode,m=>{bmode=S.bmode=m;drawB()},'sm');sw.style.margin=0;C.head.append(sw)}
          g2.append(C.el);
          const b2=T.chartBox();C.body.append(b2);
          const drawB=()=>{const src=(modes.find(m=>m[0]===bmode)||modes[0])[2];const c=echarts.getInstanceByDom(b2);if(c)c.dispose();T.chart(b2,{grid:T.grid(),tooltip:T.tip(),xAxis:T.axis({type:'category',data:src.map(x=>x.y)}),yAxis:T.axis({type:'value',axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),series:[{type:'bar',data:src.map(x=>({value:x.v,itemStyle:{color:x.v<0?'#ff5b6b':'#21c993'}}))}]})};
          drawB();
        }
        if(d.news.length){
          const N=T.panel('Legislative & sovereign risk headlines',{np:1,bodyStyle:{height:'300px'}});g2.append(N.el);
          N.body.append(...d.news.map(n=>h('a',{class:'feed',href:n.link,target:'_blank',style:{padding:'6px 10px'}},h('div',{class:'m'},h('span',{class:'acc'},T.ago(n.ts)),h('span',null,n.source)),h('div',{class:'tt'},n.title))));
        }
      }
    });
  }
  // Panel lelang: tab "Mendatang" (jika ada) dan "Riwayat" (hasil terakhir). Dibuat hanya bila ada salah satunya.
  function auctionPanel(auc){
    const P=T.panel('Debt auctions',{np:1,bodyStyle:{height:'300px'}});
    const rate=(v,r)=>h('span',null,v==null?'—':T.fmt(v,3)+(r.unit&&r.unit!=='%'?' '+r.unit:'%'));
    const amt=(v)=>v?T.big(Number(v),'$'):'—';
    const anyAmt=rows=>rows.some(r=>r.amount);
    const colsUp=rows=>[{label:'Date',left:true,get:r=>r.date+(r.time?' '+r.time:'')},{label:'Security',left:true,get:r=>r.name}]
      .concat(anyAmt(rows)?[{label:'Offering',k:'amount',fmt:amt}]:[]).concat(rows.some(r=>r.forecast!=null)?[{label:'Fcst',node:(_,r)=>rate(r.forecast,r)}]:[]).concat(rows.some(r=>r.previous!=null)?[{label:'Prev',node:(_,r)=>rate(r.previous,r)}]:[]);
    const colsHi=rows=>[{label:'Date',left:true,get:r=>r.date},{label:'Security',left:true,get:r=>r.name},{label:'Yield',node:(_,r)=>rate(r.rate,r)}]
      .concat(rows.some(r=>r.btc!=null)?[{label:'Bid/Cover',k:'btc',fmt:v=>v==null?'—':T.fmt(v,2)+'x'}]:[]).concat(anyAmt(rows)?[{label:'Offering',k:'amount',fmt:amt}]:[]);
    const tabsDef=[];
    if(auc.upcoming.length)tabsDef.push({id:'up',label:'Mendatang ('+auc.upcoming.length+')'});
    if(auc.history.length)tabsDef.push({id:'hi',label:'Riwayat ('+auc.history.length+')'});
    let cur=tabsDef[0].id;
    const box=h('div');
    const draw=()=>box.replaceChildren(cur==='up'?T.table(colsUp(auc.upcoming),auc.upcoming):T.table(colsHi(auc.history),auc.history),h('div',{class:'mut',style:{padding:'4px 10px',fontSize:'10px'}},'Sumber: '+(auc.sources.join(', ')||'—')));
    if(tabsDef.length>1){const t=T.tabs(tabsDef,cur,x=>{cur=x;draw()},'sm');t.style.margin=0;P.head.append(t)}
    P.body.append(box);draw();
    return P.el;
  }
  go();
};
})();
