// Service worker notifikasi terminal (Web Push).
// - website terbuka & terlihat  -> pesan diteruskan ke halaman (halaman membunyikan suara + kartu notifikasi)
// - website tidak terlihat / tab ditutup -> notifikasi Chrome langsung
// - klik notifikasi -> fokus ke tab terminal (atau buka baru) di menu terkait
const ICON='/vendor/notify-icon.png';
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('push',e=>{
  let d={};
  try{d=e.data?e.data.json():{}}catch(_){d={title:'Terminal',body:e.data?e.data.text():''}}
  e.waitUntil((async()=>{
    const wins=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    const vis=wins.filter(c=>c.visibilityState==='visible');
    if(vis.length&&d.kind!=='test'){vis.forEach(c=>c.postMessage({type:'notify',event:d}));return}
    await self.registration.showNotification(d.title||'Terminal',{body:d.body||'',tag:d.id||undefined,renotify:!!d.id,icon:ICON,badge:ICON,
      data:{url:d.url||'/',id:d.id},requireInteraction:d.level==='high',timestamp:Math.round((d.ts||Date.now()/1000)*1000)});
    wins.forEach(c=>c.postMessage({type:'notify',event:d,shown:true}));
  })());
});
self.addEventListener('notificationclick',e=>{
  e.notification.close();
  const url=(e.notification.data&&e.notification.data.url)||'/';
  e.waitUntil((async()=>{
    const wins=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    for(const c of wins){if('focus' in c){await c.focus();c.postMessage({type:'nav',url});return}}
    if(self.clients.openWindow)await self.clients.openWindow(url);
  })());
});
