// =====================================================================================================================
// CATALYST MAP (MARKET INTELLIGENCE): peta transmisi lintas aset layar penuh
//   Katalis (berita) -> Tesis (arah) -> Dampak (kelas aset) -> Instrumen (harga & % hari ini)
//   - tebal garis = kekuatan, warna = bias (hijau bullish, merah bearish), arus beranimasi
//   - sorot node -> jalurnya menyala; klik katalis -> panel detail (headline, instrumen); klik instrumen -> MARKET
//   - tombol layar penuh (Fullscreen API)
// =====================================================================================================================
(function(){
const h=T.h;
const BIAS_C={BULLISH:'#21c993',BEARISH:'#ff5b6b'};
const col=b=>BIAS_C[b]||'#7a8aa6';
const esc=T.esc;
const clip=(s,n)=>{s=String(s||'');return s.length>n?s.slice(0,n-1)+'…':s};

function layout(d,W,H){
  const cats=(d.catalysts||[]).slice().sort((a,b)=>b.strength-a.strength).slice(0,8);
  const smax=Math.max(1,...cats.map(c=>c.strength||0)),rel=v=>Math.max(0,Math.min(1,(v||0)/smax));   // kekuatan relatif 0..1
  const L=18,R=18,TOP=64,BOT=24;
  const cw=Math.max(180,Math.min(300,W*0.24)),iw=Math.max(150,Math.min(178,W*0.13));
  const xCat=L,xThe=L+cw+Math.max(60,W*0.07),tw=Math.max(130,Math.min(170,W*0.12)),xImp=xThe+tw+Math.max(90,W*0.13),xIns=W-R-iw;
  const n=Math.max(1,cats.length),step=(H-TOP-BOT)/n;
  const nodes={},links=[];
  cats.forEach((c,i)=>{
    const y=TOP+step*(i+0.5);
    nodes['c:'+c.id]={id:'c:'+c.id,kind:'cat',x:xCat,y,w:cw,c};
    nodes['t:'+c.id]={id:'t:'+c.id,kind:'the',x:xThe,y,w:tw,label:c.bias,sub:c.asset,bias:c.bias};
    links.push({s:'c:'+c.id,t:'t:'+c.id,bias:c.bias,w:rel(c.strength)});
  });
  // dampak per kelas aset: y = rata-rata y tesis yang terhubung, lalu dijarakkan agar tidak bertumpuk
  const imp={};
  cats.forEach(c=>{const k='i:'+c.asset;(imp[k]=imp[k]||{id:k,kind:'imp',label:c.asset,ys:[],str:0,bull:0,bear:0});imp[k].ys.push(nodes['t:'+c.id].y);imp[k].str+=rel(c.strength);
    if(c.bias==='BULLISH')imp[k].bull+=c.strength;else if(c.bias==='BEARISH')imp[k].bear+=c.strength;
    links.push({s:'t:'+c.id,t:k,bias:c.bias,w:rel(c.strength)})});
  const spread=(arr,gap)=>{arr.sort((a,b)=>a.y-b.y);for(let i=1;i<arr.length;i++)if(arr[i].y-arr[i-1].y<gap)arr[i].y=arr[i-1].y+gap;
    const over=arr.length?arr[arr.length-1].y-(H-BOT-gap/2):0;if(over>0)arr.forEach(a=>a.y-=over);const under=arr.length?(TOP+gap/2)-arr[0].y:0;if(under>0)arr.forEach(a=>a.y+=under)};
  const imps=Object.values(imp).map(o=>Object.assign(o,{x:xImp,y:o.ys.reduce((a,b)=>a+b,0)/o.ys.length,r:Math.max(12,Math.min(26,10+Math.sqrt(o.str)*11)),bias:o.bull>o.bear?'BULLISH':o.bear>o.bull?'BEARISH':''}));
  spread(imps,Math.min(84,(H-TOP-BOT)/Math.max(1,imps.length)));
  imps.forEach(o=>nodes[o.id]=o);
  // instrumen: y = rata-rata y dampak yang terhubung
  const ins={};
  cats.forEach(c=>(c.instruments||[]).slice(0,4).forEach(x=>{const k='s:'+x.sym;(ins[k]=ins[k]||{id:k,kind:'ins',sym:x.sym,ys:[],dirs:{}});
    ins[k].ys.push(nodes['i:'+c.asset].y);ins[k].dirs[x.dir]=(ins[k].dirs[x.dir]||0)+x.weight;
    if(!links.some(l=>l.s==='i:'+c.asset&&l.t===k))links.push({s:'i:'+c.asset,t:k,bias:x.dir,w:rel(c.strength)*Math.max(.35,Math.min(1,(x.weight>1?x.weight/100:x.weight)||1))})}));
  const insl=Object.values(ins).map(o=>Object.assign(o,{x:xIns,w:iw,y:o.ys.reduce((a,b)=>a+b,0)/o.ys.length,dir:Object.entries(o.dirs).sort((a,b)=>b[1]-a[1])[0][0]}));
  spread(insl,Math.max(26,Math.min(40,(H-TOP-BOT)/Math.max(1,insl.length))));
  insl.forEach(o=>nodes[o.id]=o);
  return {nodes,links,cats,rel,cols:[[xCat,'01','KATALIS'],[xThe,'02','TESIS'],[xImp-30,'03','DAMPAK'],[xIns,'04','INSTRUMEN']]};
}

function anchor(n,side){
  if(n.kind==='cat')return [side==='out'?n.x+n.w:n.x,n.y];
  if(n.kind==='the')return [side==='out'?n.x+n.w:n.x,n.y];
  if(n.kind==='imp')return [side==='out'?n.x+n.r:n.x-n.r,n.y];
  return [n.x,n.y];
}

function svg(G,W,H,prices){
  const P=[];
  P.push(`<svg class="cm-svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">`);
  P.push(`<defs><filter id="cm-glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <radialGradient id="cm-hub" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#2a3446"/><stop offset="1" stop-color="#121821"/></radialGradient></defs>`);
  // kolom
  G.cols.forEach(([x,num,lab])=>P.push(`<text class="cm-colh" x="${x}" y="30"><tspan class="n">${num}</tspan> ${lab}</text>`));
  // garis + arus
  P.push('<g class="cm-links">');
  G.links.forEach((l,i)=>{
    const a=G.nodes[l.s],b=G.nodes[l.t];if(!a||!b)return;
    const [x1,y1]=anchor(a,'out'),[x2,y2]=anchor(b,'in'),dx=Math.max(30,(x2-x1)*0.5);
    const d=`M${x1.toFixed(1)},${y1.toFixed(1)} C${(x1+dx).toFixed(1)},${y1.toFixed(1)} ${(x2-dx).toFixed(1)},${y2.toFixed(1)} ${x2.toFixed(1)},${y2.toFixed(1)}`;
    const w=1.2+4.8*l.w,c=col(l.bias),dur=(2.8-1.6*l.w).toFixed(2);   // tebal & laju arus = kekuatan relatif
    P.push(`<g class="cm-l" data-s="${esc(l.s)}" data-t="${esc(l.t)}"><path class="base" d="${d}" stroke="${c}" stroke-width="${w.toFixed(1)}"/><path class="flow" d="${d}" stroke="${c}" stroke-width="${Math.max(1.2,w*0.6).toFixed(1)}" style="animation-duration:${dur}s"/></g>`);
  });
  P.push('</g><g class="cm-nodes">');
  Object.values(G.nodes).forEach(n=>{
    if(n.kind==='cat'){const c=n.c,bc=col(c.bias);
      P.push(`<g class="cm-n cm-cat" data-id="${esc(n.id)}" transform="translate(${n.x},${(n.y-25).toFixed(1)})"><rect class="card" width="${n.w}" height="50" rx="9"/><rect width="3" height="34" x="0" y="8" rx="1.5" fill="${bc}"/>
        <text class="t1" x="13" y="21">${esc(clip(c.title,Math.floor((n.w-72)/7.2)))}</text>
        <text class="t2" x="13" y="38">${esc(c.impact||'')} · STR ${Math.round(c.strength)} · ${c.count} headline</text>
        <rect class="bar" x="${n.w-58}" y="15" width="46" height="4" rx="2"/><rect x="${n.w-58}" y="15" width="${Math.max(2,46*G.rel(c.strength)).toFixed(1)}" height="4" rx="2" fill="${bc}"/></g>`)}
    else if(n.kind==='the'){const c=col(n.bias);
      P.push(`<g class="cm-n cm-the" data-id="${esc(n.id)}" transform="translate(${n.x},${(n.y-15).toFixed(1)})"><rect class="pill" width="${n.w}" height="30" rx="15" style="stroke:${c}"/>
        <circle cx="15" cy="15" r="4" fill="${c}"/><text x="26" y="19"><tspan class="b" fill="${c}">${esc(n.label||'NETRAL')}</tspan> · ${esc(clip(n.sub,14))}</text></g>`)}
    else if(n.kind==='imp'){const c=col(n.bias);
      P.push(`<g class="cm-n cm-imp" data-id="${esc(n.id)}" transform="translate(${n.x},${n.y.toFixed(1)})"><circle class="halo" r="${(n.r+9).toFixed(1)}" style="stroke:${c}"/><circle class="hub" r="${n.r.toFixed(1)}" style="stroke:${c}" filter="url(#cm-glow)"/>
        <text class="lab" y="${(n.r+17).toFixed(1)}">${esc(clip(n.label,18))}</text></g>`)}
    else{const c=col(n.dir),p=prices[String(n.sym).toUpperCase()];
      const pct=p&&p.pct!=null?`<tspan class="pct" fill="${p.pct>=0?'#21c993':'#ff5b6b'}">${p.pct>0?'+':''}${p.pct.toFixed(2)}%</tspan>`:'';
      P.push(`<g class="cm-n cm-ins" data-id="${esc(n.id)}" data-sym="${esc(n.sym)}" transform="translate(${n.x},${(n.y-13).toFixed(1)})"><rect class="pill" width="${n.w}" height="26" rx="7" style="stroke:${c}"/>
        <text x="10" y="17"><tspan fill="${c}">${n.dir==='BULLISH'?'▲':n.dir==='BEARISH'?'▼':'•'}</tspan> <tspan class="sym">${esc(clip(n.sym,Math.floor((n.w-84)/7.4)))}</tspan></text><text class="r" x="${n.w-9}" y="17">${pct}</text></g>`)}
  });
  P.push('</g></svg>');
  return P.join('');
}

function lanes(G,prices){
  const arrow=d=>d==='BULLISH'?'▲':d==='BEARISH'?'▼':'•';
  return h('div',{class:'cm-lanes'},...G.cats.map(c=>{const bc=col(c.bias);
    return h('div',{class:'cm-lane','data-cid':c.id,style:'--bc:'+bc},
      h('div',{class:'cm-lt'},h('b',null,c.title),h('span',{class:'cm-lbar'},h('i',{style:{width:(100*G.rel(c.strength)).toFixed(0)+'%'}}))),
      h('div',{class:'cm-ls'},(c.impact||'')+' · STR '+Math.round(c.strength)+' · '+c.count+' headline'),
      h('div',{class:'cm-lflow'},h('span',{class:'cm-lth'},c.bias||'NETRAL'),h('i',{class:'cm-arr'}),h('span',{class:'cm-limp'},c.asset),h('i',{class:'cm-arr'}),
        ...(c.instruments||[]).slice(0,4).map(x=>{const p=prices[String(x.sym).toUpperCase()];
          return h('span',{class:'cm-lins'},h('em',{style:{color:col(x.dir)}},arrow(x.dir)),x.sym,p&&p.pct!=null?h('small',{class:T.cls(p.pct)},T.pct(p.pct)):null)})))}));
}

T.catalystMap=function(body){
  const st=T.mem('cmap',{sel:null});
  const wrap=h('div',{class:'cmap'});
  const stage=h('div',{class:'cm-stage'});
  const detail=h('div',{class:'cm-detail'});
  const fsBtn=h('button',{class:'cm-btn',title:'Layar penuh',html:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>'});
  const meta=h('span',{class:'cm-meta'},'memuat…');
  const head=h('div',{class:'cm-head'},h('b',null,'CROSS-ASSET CATALYST TRANSMISSION'),meta,
    h('span',{class:'cm-leg'},h('i',{style:{background:BIAS_C.BULLISH}}),'bullish',h('i',{style:{background:BIAS_C.BEARISH}}),'bearish',h('i',{class:'w'}),'tebal = kekuatan'),fsBtn);
  const main=h('div',{class:'cm-body'},stage,detail);
  wrap.append(head,main);
  body.replaceChildren(wrap);
  fsBtn.onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else (wrap.requestFullscreen||wrap.webkitRequestFullscreen||(()=>{})).call(wrap)};
  let data=null,prices={},G=null,mode='',first=true;
  // lebar >=1100: panel detail jadi kolom kanan · 760-1100: panel melayang (dibuka saat diklik) · <760: jalur vertikal
  const modeOf=()=>{const w=wrap.clientWidth;return w>=1100?'wide':w>=760?'mid':'narrow'};
  const fit=()=>{if(document.fullscreenElement)return;if(mode==='narrow'){wrap.style.height='';return}
    const top=wrap.getBoundingClientRect().top;wrap.style.height=Math.max(520,window.innerHeight-top-12)+'px'};
  function draw(){
    if(!data||!wrap.isConnected)return;
    mode=modeOf();wrap.dataset.mode=mode;fit();
    if(first){first=false;if(mode!=='wide')detail.classList.add('min')}
    if(detail.parentNode!==main)main.append(detail);                     // panel bisa sedang berada di dalam jalur (ponsel)
    if(mode==='narrow'){G=layout(data,900,600);stage.replaceChildren(lanes(G,prices));if(st.tapped&&st.sel)select(st.sel,true);else detail.classList.add('min');return}
    // tinggi minimum menurut jumlah node: kartu katalis ±60 px, pill instrumen ±30 px (sisanya bisa digulir, tidak terpotong)
    const top=(data.catalysts||[]).slice().sort((a,b)=>b.strength-a.strength).slice(0,8);
    const nIns=new Set(top.flatMap(c=>(c.instruments||[]).slice(0,4).map(x=>x.sym))).size;
    const W=Math.max(900,stage.clientWidth),H=Math.max(480,stage.clientHeight,88+Math.max(top.length*60,nIns*30));
    G=layout(data,W,H);
    stage.innerHTML=svg(G,W,H,prices);
    select(st.sel&&G.nodes['c:'+st.sel]?st.sel:(G.cats[0]&&G.cats[0].id),true);
  }
  // sorot jalur: node + semua leluhur & keturunannya
  function related(id){
    const up={},down={};G.links.forEach(l=>{(down[l.s]=down[l.s]||[]).push(l.t);(up[l.t]=up[l.t]||[]).push(l.s)});
    const keep=new Set([id]);const walk=(m,k)=>{(m[k]||[]).forEach(x=>{if(!keep.has(x)){keep.add(x);walk(m,x)}})};walk(down,id);walk(up,id);return keep;
  }
  function focus(id){
    const svgEl=stage.querySelector('svg');if(!svgEl)return;
    if(!id){svgEl.classList.remove('hl');stage.querySelectorAll('.on').forEach(e=>e.classList.remove('on'));return}
    const keep=related(id);svgEl.classList.add('hl');
    stage.querySelectorAll('.cm-n').forEach(e=>e.classList.toggle('on',keep.has(e.dataset.id)));
    stage.querySelectorAll('.cm-l').forEach(e=>e.classList.toggle('on',keep.has(e.dataset.s)&&keep.has(e.dataset.t)));
  }
  function select(cid,quiet){
    const c=G&&G.cats.find(x=>x.id===cid);if(!c){detail.replaceChildren();return}
    st.sel=cid;
    stage.querySelectorAll('.cm-cat').forEach(e=>e.classList.toggle('sel',e.dataset.id==='c:'+cid));
    stage.querySelectorAll('.cm-lane').forEach(e=>e.classList.toggle('sel',e.dataset.cid===cid));
    detail.replaceChildren(
      h('div',{class:'cm-dh'},h('span',{class:'badge b-'+c.bias},c.bias),T.badge(c.impact||'—'),h('span',{class:'mut'},c.region||''),h('button',{class:'cm-x',title:'Tutup',onclick:()=>detail.classList.add('min')},'—')),
      h('b',{class:'cm-dt'},c.title),
      h('div',{class:'cm-dtx'},c.text||''),
      h('div',{class:'cm-kv'},h('span',null,'Kekuatan'),h('b',null,Math.round(c.strength)),h('span',null,'Headline'),h('b',null,c.count),h('span',null,'Kritis'),h('b',null,c.crit||0)),
      h('div',{class:'cm-sh'},'INSTRUMEN TERDAMPAK'),
      h('div',{class:'cm-chips'},...(c.instruments||[]).map(x=>{const p=prices[String(x.sym).toUpperCase()];
        return h('button',{class:'chip cm-chip',onclick:()=>T.openAsset(x.sym)},h('span',{style:{color:col(x.dir)}},x.dir==='BULLISH'?'▲ ':x.dir==='BEARISH'?'▼ ':''),x.sym,p&&p.pct!=null?h('em',{class:T.cls(p.pct)},' '+T.pct(p.pct)):null)})),
      h('div',{class:'cm-sh'},'HEADLINE PEMICU'),
      ...(c.headlines||[]).slice(0,6).map(n=>h('a',{class:'feed cm-hl',href:n.link||'#',target:'_blank'},h('div',{class:'m'},h('span',{class:'acc'},T.ago(n.ts)),h('span',null,n.source)),h('div',{class:'tt'},n.title))));
    if(!quiet)detail.classList.remove('min');
    if(mode==='narrow'){const ln=stage.querySelector('.cm-lane.sel');if(ln)ln.append(detail)}
    if(!quiet)focus('c:'+cid);
  }
  stage.addEventListener('pointerover',e=>{const n=e.target.closest('.cm-n');focus(n?n.dataset.id:null)});
  stage.addEventListener('pointerleave',()=>focus(null));
  stage.addEventListener('click',e=>{
    const ln=e.target.closest('.cm-lane');if(ln&&!e.target.closest('.cm-detail')){const same=st.sel===ln.dataset.cid&&!detail.classList.contains('min');st.tapped=true;
      if(same)detail.classList.add('min');else select(ln.dataset.cid);return}
    const n=e.target.closest('.cm-n');if(!n)return;
    if(n.classList.contains('cm-cat'))select(n.dataset.id.slice(2));
    else if(n.classList.contains('cm-ins'))T.openAsset(n.dataset.sym);
    else focus(n.dataset.id)});
  const ro=new ResizeObserver(()=>{clearTimeout(ro._t);ro._t=setTimeout(draw,120)});ro.observe(stage);
  T.timers.push(setInterval(()=>{if(!wrap.isConnected)ro.disconnect()},5000));
  document.addEventListener('fullscreenchange',()=>{if(wrap.isConnected){wrap.style.height=document.fullscreenElement?'100%':'';setTimeout(draw,60)}});
  window.addEventListener('resize',()=>{if(wrap.isConnected)fit()});
  T.api('market/assets',{cls:'ALL'}).then(d=>{(d.rows||[]).forEach(a=>prices[a.sym.toUpperCase()]=a);draw()}).catch(()=>{});
  T.cachedThen('intel/map',null,(d)=>{data=d;meta.textContent=(d.catalysts||[]).length+' katalis · diperbarui '+new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
    if(!(d.catalysts||[]).length){stage.replaceChildren(h('div',{class:'msg'},'Belum ada data katalis'));return}draw()}).catch(e=>stage.replaceChildren(h('div',{class:'msg err'},e.message)));
  T.every(90000,()=>T.api('intel/map',null,{force:true,bg:true}).then(d=>{data=d;draw()}).catch(()=>{}));
};
})();
