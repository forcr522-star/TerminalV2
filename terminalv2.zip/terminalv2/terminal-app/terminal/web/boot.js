(function(){
const h=T.h;
const rail=document.getElementById('rail'),view=document.getElementById('view'),title=document.getElementById('title');
T.modules.forEach(([id,ico,name])=>rail.append(h('a',{href:'#'+id,title:name,'data-id':id,onclick:()=>rail.classList.remove('open')},ico)));
document.getElementById('burger').onclick=()=>rail.classList.toggle('open');
function nav(){
  const id=(location.hash||'#dashboard').slice(1).split('/')[0];
  const mod=T.modules.find(m=>m[0]===id)||T.modules[0];
  T.dispose();
  view.innerHTML='';view.scrollTop=0;
  [...rail.children].forEach(a=>a.classList.toggle('on',a.dataset.id===mod[0]));
  title.textContent=mod[2];
  const V=T.Views[mod[0]];
  if(!V){view.append(h('div',{class:'msg'},'Modul belum tersedia'));return}
  try{V(view)}catch(e){view.append(h('div',{class:'msg err'},'Error: '+e.message));console.error(e)}
}
window.addEventListener('hashchange',nav);
const zones=[['NEW YORK','America/New_York','ny'],['LONDON','Europe/London','ld'],['TOKYO','Asia/Tokyo','tk']];
const clocks=document.getElementById('clocks');
function openNow(tz){const hr=+new Intl.DateTimeFormat('en-GB',{timeZone:tz,hour:'2-digit',hour12:false}).format(new Date());const wd=new Intl.DateTimeFormat('en-US',{timeZone:tz,weekday:'short'}).format(new Date());return hr>=8&&hr<17&&wd!=='Sat'&&wd!=='Sun'}
let snap=null;
const snapTxt=()=>{
  if(!snap)return '—';
  const a=snap.updated?T.ago(snap.updated):'—';
  return snap.phase==='phase1'?'MEMUAT '+snap.ready+'/'+snap.planned:snap.ready+'/'+snap.planned+' · '+a;
};
function tick(){
  const parts=zones.map(([n,tz])=>`<span><i style="background:${openNow(tz)?'#22c55e':'#565d70'}"></i>${n}<b>${new Intl.DateTimeFormat('en-GB',{timeZone:tz,hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date())}</b></span>`);
  parts.push(`<span>LOCAL<b>${new Date().toLocaleTimeString('en-GB')}</b></span>`);
  parts.push(`<span>PING<b>${T.ping!=null?T.ping+'ms':'—'}</b></span>`);
  parts.push(`<span data-snap="1" title="Data tersimpan di server — klik untuk detail" style="cursor:pointer">DATA<b>${snapTxt()}</b></span>`);
  clocks.innerHTML=parts.join('');
}
setInterval(tick,1000);tick();
async function loadTicker(){
  try{
    const d=await T.api('ticker',null,{force:true});
    const items=d.items.map(i=>`<span>${T.esc(i.sym)} <b>${T.fmt(i.price,i.price<10?4:2)}</b> <span class="${T.cls(i.pct)}">${T.pct(i.pct)}</span></span>`).join('');
    document.getElementById('ticker').innerHTML=items+items;
    const ab=document.getElementById('alertbar');
    if(d.alert){ab.style.display='flex';ab.innerHTML=`<b>⚠ ${d.alert.prio==='CRIT'?'CRITICAL ALERT':'ALERT'}</b><span>${T.esc(d.alert.title)}</span>`}else ab.style.display='none';
  }catch(e){}
}
async function loadStrip(){
  try{
    const d=await T.api('dashboard');
    if(d&&d.strip){document.getElementById('stripbar').innerHTML='<span>POLICY RATES</span>'+d.strip.map(s=>`<span>${s.label} <b>${s.rate!=null?s.rate.toFixed(2)+'%':'—'}</b></span>`).join('')+'<span>INFLATION (YoY)</span>'+d.strip.filter(s=>s.infl!=null).map(s=>`<span>${s.cc} <b>${s.infl.toFixed(1)}%</b></span>`).join('')}
  }catch(e){}
}
let lastRev=null,bad=0;
const hbtn=document.getElementById('hbtn'),hmodal=document.getElementById('hmodal');
function showBad(){hbtn.style.display=(T.role==='admin'&&bad>0)?'':'none';hbtn.textContent='⚠ '+bad+' sumber bermasalah'}
async function pollRev(){
  try{const d=await T.rawFetch('rev');bad=d.bad||0;snap=d.snap||null;showBad();if(lastRev!==null&&d.rev!==lastRev)T.refreshActive();lastRev=d.rev}catch(e){}
}
hbtn.onclick=async()=>{
  try{
    const d=await T.rawFetch('health');
    const sec=(title,cls,items,render)=>items.length?[h('div',{class:'hsec '+cls},title+' ('+items.length+')'),...items.map(render)]:[];
    const by=l=>d.hosts.filter(x=>x.level===l);
    const err=x=>h('div',{class:'r'},h('b',{class:'dn'},'✗ '+x.host),h('span',{class:'mut'},x.error+(x.last_url?' — '+x.last_url:'')));
    const cov=x=>h('div',{class:'r'},h('b',{class:'warn'},'↪ '+x.host),h('span',{class:'mut'},'gagal, data diambil dari cadangan: '+x.covered_by));
    const opt=x=>h('div',{class:'r'},h('b',{class:'mut'},'· '+x.host),h('span',{class:'mut'},x.error));
    const okr=x=>h('div',{class:'r'},h('b',{class:'up'},'✓ '+x.host),h('span',{class:'mut'},'OK ('+x.ok+' permintaan'+(x.via?', via '+x.via:'')+')'));
    const dis=(d.disabled||[]).map(x=>h('div',{class:'r'},h('b',{class:'mut'},'⏸ '+x.url),h('span',{class:'mut'},x.reason+' — dicoba lagi otomatis nanti')));
    const rows=[...sec('PERLU PERHATIAN','dn',by('bad'),err),...sec('CADANGAN AKTIF (tidak memengaruhi data)','warn',by('covered'),cov),
      ...sec('FEED OPSIONAL TIDAK AKTIF (sumber lain menggantikan)','mut',by('optional'),opt),...(dis.length?[h('div',{class:'hsec mut'},'DINONAKTIFKAN SEMENTARA ('+dis.length+')'),...dis]:[]),
      ...sec('NORMAL','up',by('ok'),okr)];
    hmodal.replaceChildren(h('div',{class:'box'},h('div',{class:'row',style:{marginBottom:'8px'}},h('b',null,'STATUS SUMBER DATA'),h('span',{class:'sp',style:{flex:1}}),h('button',{class:'btn',onclick:()=>hmodal.style.display='none'},'Tutup')),h('div',{class:'mut',style:{marginBottom:'8px'}},'Hanya sumber di bagian "Perlu perhatian" yang dihitung di lencana. Jalankan `python -m terminal.selfcheck` di komputer Anda untuk diagnosis lengkap.'),...rows));
    hmodal.style.display='block';
  }catch(e){}
};
clocks.addEventListener('click',async e=>{
  if(!e.target.closest('[data-snap]'))return;
  try{
    const d=await T.rawFetch('snapshots',{detail:1});
    const gs=Object.entries(d.groups||{});
    const fails=(d.items||[]).filter(i=>i.fails||i.age==null).slice(0,40);
    const upd=d.updated?T.ago(d.updated)+' lalu':'—';
    hmodal.replaceChildren(h('div',{class:'box'},h('div',{class:'row',style:{marginBottom:'8px'}},h('b',null,'DATA TERSIMPAN DI SERVER'),h('span',{class:'sp',style:{flex:1}}),h('button',{class:'btn',onclick:()=>hmodal.style.display='none'},'Tutup')),
      h('div',{class:'mut',style:{marginBottom:'8px'}},`${d.ready}/${d.planned} menu siap · ${d.stored} snapshot (${(d.bytes/1048576).toFixed(1)} MB) · pembaruan terakhir ${upd}. Pengunjung baru langsung memakai data ini; server memperbaruinya otomatis di latar belakang.`),
      ...gs.map(([g,v])=>h('div',{class:'r'},h('b',{class:v.failing?'warn':'up'},(v.failing?'↻ ':'✓ ')+g),h('span',{class:'mut'},`${v.ready}/${v.total} siap`+(v.failing?` · ${v.failing} sedang dicoba ulang`:'')))),
      ...(fails.length?[h('div',{class:'hsec dn'},'BELUM TERSEDIA / DICOBA ULANG ('+fails.length+')'),...fails.map(i=>h('div',{class:'r'},h('b',{class:'mut'},i.key),h('span',{class:'mut'},i.error||'menunggu')))]:[])));
    hmodal.style.display='block';
  }catch(err){}
});
loadTicker();setInterval(loadTicker,60000);setInterval(pollRev,25000);setTimeout(pollRev,800);
setTimeout(loadStrip,1500);setInterval(loadStrip,600000);
const input=document.getElementById('search'),res=document.getElementById('results');
let st=null;
input.addEventListener('input',()=>{
  clearTimeout(st);
  const q=input.value.trim();
  if(!q){res.style.display='none';return}
  st=setTimeout(async()=>{
    try{
      const d=await T.api('search',{q});
      res.innerHTML='';
      d.assets.forEach(a=>res.append(h('div',{onclick:()=>{T.openAsset(a.sym);res.style.display='none';input.value=''}},`${a.sym} — ${a.name} `,h('span',{class:'mut'},a.cls))));
      d.news.forEach(n=>res.append(h('div',{onclick:()=>window.open(n.link,'_blank')},`📰 ${n.title}`)));
      if(!res.children.length)res.append(h('div',{class:'mut'},'Tidak ada hasil'));
      res.style.display='block';
    }catch(e){}
  },250);
});
document.addEventListener('click',e=>{if(!e.target.closest('#searchwrap'))res.style.display='none'});
T.openAsset=sym=>{T.pendingAsset=sym;location.hash='#market'};
// Peran sesi (admin/user) ditentukan server dari kunci akses. Bila gagal dibaca, anggap user (hak paling sedikit).
T.role='user';
T.rawFetch('me').then(d=>{T.role=d&&d.role==='admin'?'admin':'user'}).catch(()=>{}).finally(()=>{showBad();nav()});
})();
