(function(){
const h=T.h;
const rail=document.getElementById('rail'),view=document.getElementById('view'),title=document.getElementById('title'),eyebrow=document.getElementById('eyebrow');
// Sidebar: ikon garis + label, dikelompokkan. Desktop: melebar saat disorot (melayang di atas konten, tata letak tidak bergeser).
const LOGO='<svg viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="13" stroke="currentColor" stroke-opacity=".35" stroke-width="1.4"/><path d="M16 3a13 13 0 0 1 13 13" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M8.5 19.5l4.2-5 3.6 3 6.2-7.2" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><circle cx="22.5" cy="10.3" r="1.6" fill="currentColor"/></svg>';
const rin=h('div',{class:'rail-in'});
rin.append(h('a',{class:'brand',href:'#dashboard',title:'Terminal'},h('span',{class:'ico',html:LOGO}),h('span',{class:'lbl'},'TERMINAL',h('small',null,'MACRO · FLOW · SIGNAL'))));
const known=new Set(T.GROUPS.flatMap(g=>g[1]));
const groups=T.GROUPS.map(g=>[g[0],g[1].filter(id=>T.modules.some(m=>m[0]===id))]);
const rest=T.modules.map(m=>m[0]).filter(id=>!known.has(id));
if(rest.length)groups.push(['LAINNYA',rest]);
groups.forEach(([gname,ids])=>{
  if(!ids.length)return;
  const g=h('div',{class:'rg'},h('div',{class:'rg-t'},gname));
  ids.forEach(id=>{const m=T.modules.find(x=>x[0]===id);
    let pt=null;
    g.append(h('a',{href:'#'+id,title:m[2],'data-id':id,onclick:()=>rail.classList.remove('open'),
      onpointerenter:()=>{clearTimeout(pt);pt=setTimeout(()=>T.prefetch(id),70)},onpointerleave:()=>clearTimeout(pt),
      ontouchstart:()=>T.prefetch(id),onfocus:()=>T.prefetch(id)},h('span',{class:'ico',html:T.ICONS[id]||'<b>'+m[1]+'</b>'}),h('span',{class:'lbl'},m[2])))});
  rin.append(g);
});
rin.append(h('div',{class:'rail-foot'},
  h('button',{title:'Watchlist & price alert',onclick:()=>{rail.classList.remove('open');T.openWatch()}},h('span',{class:'ico',html:T.ICONS.star}),h('span',{class:'lbl'},'WATCHLIST')),
  h('button',{title:'Kalkulator ukuran posisi',onclick:()=>{rail.classList.remove('open');T.openCalc()}},h('span',{class:'ico',html:T.ICONS.calc}),h('span',{class:'lbl'},'POSITION SIZE'))));
rail.append(rin);
const scrim=h('div',{id:'scrim',onclick:()=>rail.classList.remove('open')});document.body.append(scrim);
document.getElementById('burger').onclick=()=>rail.classList.toggle('open');
// ---------------------------------------------------------------- pindah menu: motion
// 1) konten lama meluncur keluar (View Transitions API, dikomposisi GPU; browser lama: dilewati)
// 2) panel/kartu baru muncul berurutan (cascade) - hanya yang muncul < 1,2 dtk setelah pindah menu, pembaruan data berkala
//    tidak ikut beranimasi
// 3) indikator menu aktif di sidebar bergeser ke item baru; judul berganti dengan animasi geser
const RM=matchMedia('(prefers-reduced-motion: reduce)');
const ind=h('i',{class:'rail-ind'});rin.prepend(ind);
function moveInd(a){
  if(!a){ind.style.opacity='0';return}
  ind.style.opacity='1';ind.style.height=a.offsetHeight+'px';ind.style.transform=`translateY(${a.offsetTop}px)`;
}
let mo=null,moT=null,popN=0,popBase=0;
const POP='.panel,.kpi,.col,.board>*,.sg-row,.sgi-tile,.hf-main,.hf-side>*,.think-map,.think-side>*,.hf-chip,.feed';
function cascade(){
  if(mo)mo.disconnect();clearTimeout(moT);popN=0;
  if(RM.matches)return;
  const pop=el=>{if(popN>14||el.classList.contains('pop'))return;el.style.setProperty('--d',(popBase+popN++*38)+'ms');el.classList.add('pop');
    el.addEventListener('animationend',()=>{el.classList.remove('pop');el.style.removeProperty('--d')},{once:true})};
  mo=new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{if(n.nodeType!==1)return;if(n.matches(POP))pop(n);n.querySelectorAll&&n.querySelectorAll(POP).forEach(pop)})));
  mo.observe(view,{childList:true,subtree:true});
  moT=setTimeout(()=>{mo.disconnect();mo=null},1200);
}
function render(mod){
  T.dispose();
  view.innerHTML='';view.scrollTop=0;
  T.curMod=mod[0];
  const on=rail.querySelector(`a[data-id="${mod[0]}"]`);
  rail.querySelectorAll('a[data-id]').forEach(a=>a.classList.toggle('on',a===on));moveInd(on);
  title.textContent=mod[2];eyebrow.textContent=T.groupOf(mod[0]);
  const tw=document.getElementById('titlewrap');tw.classList.remove('swap');void tw.offsetWidth;tw.classList.add('swap');
  document.title=mod[2].charAt(0)+mod[2].slice(1).toLowerCase()+' · Terminal';
  cascade();
  const V=T.Views[mod[0]];
  if(!V){view.append(h('div',{class:'msg'},'Modul belum tersedia'));return}
  try{V(view)}catch(e){view.append(h('div',{class:'msg err'},'Error: '+e.message));console.error(e)}
}
let firstNav=true;
function nav(){
  const id=(location.hash||'#dashboard').slice(1).split('/')[0];
  const mod=T.modules.find(m=>m[0]===id)||T.modules[0];
  const same=T.curMod===mod[0];
  if(firstNav||same||RM.matches||!document.startViewTransition||document.visibilityState==='hidden'){firstNav=false;popBase=0;render(mod);return}
  popBase=110;                     // panel baru mulai muncul setelah konten lama hampir hilang (tidak bertumpuk)
  // tahan sebentar (maks. 90 ms) agar data tersimpan sempat tergambar -> transisi menuju isi, bukan ke halaman kosong
  try{document.startViewTransition(()=>{render(mod);return new Promise(r=>setTimeout(r,90))})}catch(e){render(mod)}
}
window.addEventListener('hashchange',nav);
const zones=[['NEW YORK','America/New_York','ny'],['LONDON','Europe/London','ld'],['TOKYO','Asia/Tokyo','tk']];
const clocks=document.getElementById('clocks');
function openNow(tz){const hr=+new Intl.DateTimeFormat('en-GB',{timeZone:tz,hour:'2-digit',hour12:false}).format(new Date());const wd=new Intl.DateTimeFormat('en-US',{timeZone:tz,weekday:'short'}).format(new Date());return hr>=8&&hr<17&&wd!=='Sat'&&wd!=='Sun'}
let snap=null;
const snapTxt=()=>{
  if(!snap)return '—';
  const a=snap.updated?T.ago(snap.updated):'—';
  return snap.phase==='phase1'?'MEMUAT '+snap.ready+'/'+snap.planned:snap.ready+'/'+snap.planned+' · '+a;
};
function tick(){
  const parts=zones.map(([n,tz,k])=>{const on=openNow(tz);return `<span class="ck${on?' live':''}" title="${n} — sesi ${on?'buka':'tutup'}"><i></i>${k.toUpperCase()}<b>${new Intl.DateTimeFormat('en-GB',{timeZone:tz,hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date())}</b></span>`});
  parts.push(`<span class="ck loc" title="Waktu lokal">LOC<b>${new Date().toLocaleTimeString('en-GB')}</b></span>`);
  const pc=T.ping==null?'':T.ping<250?'good':T.ping<800?'mid':'slow';
  parts.push(`<span class="ck ping ${pc}" title="Waktu respons server">PING<b>${T.ping!=null?T.ping+'ms':'—'}</b></span>`);
  parts.push(`<span class="ck data" data-snap="1" title="Data tersimpan di server — klik untuk detail">DATA<b>${snapTxt()}</b></span>`);
  clocks.innerHTML=parts.join('');
}
setInterval(tick,1000);tick();
async function loadTicker(){
  try{
    const d=await T.api('ticker',null,{force:true,bg:true});
    const items=d.items.map(i=>`<span class="tk" data-sym="${T.esc(i.sym)}"><em>${T.esc(i.sym)}</em><b>${T.fmt(i.price,i.price<10?4:2)}</b><span class="${T.cls(i.pct)}">${i.pct>0?'▲':i.pct<0?'▼':'•'} ${T.pct(i.pct)}</span></span>`).join('');
    document.getElementById('ticker').innerHTML=items+items;
    const ab=document.getElementById('alertbar');
    if(d.alert){ab.style.display='flex';ab.className=d.alert.prio==='CRIT'?'crit':'';ab.innerHTML=`<b><i></i>${d.alert.prio==='CRIT'?'CRITICAL':'ALERT'}</b><span>${T.esc(d.alert.title)}</span>`}else ab.style.display='none';
  }catch(e){}
}
async function loadStrip(){
  try{
    const d=await T.api('dashboard',undefined,{bg:true});
    if(d&&d.strip){document.getElementById('stripbar').innerHTML='<span class="sl">POLICY RATE</span>'+d.strip.map(s=>`<span>${s.label}<b>${s.rate!=null?s.rate.toFixed(2)+'%':'—'}</b></span>`).join('')+'<span class="sl">INFLASI YoY</span>'+d.strip.filter(s=>s.infl!=null).map(s=>`<span>${s.cc}<b>${s.infl.toFixed(1)}%</b></span>`).join('')}
  }catch(e){}
}
let lastRev=null,bad=0;
const hbtn=document.getElementById('hbtn'),hmodal=document.getElementById('hmodal');
function showBad(){hbtn.style.display=(T.role==='admin'&&bad>0)?'':'none';hbtn.innerHTML='<i></i>'+bad+' sumber bermasalah'}
async function pollRev(){
  try{const d=await T.rawFetch('rev',null,{bg:true});bad=d.bad||0;snap=d.snap||null;showBad();if(lastRev!==null&&d.rev!==lastRev)T.refreshActive();lastRev=d.rev}catch(e){}
}
hbtn.onclick=async()=>{
  try{
    const d=await T.rawFetch('health');
    const sec=(title,cls,items,render)=>items.length?[h('div',{class:'hsec '+cls},title+' ('+items.length+')'),...items.map(render)]:[];
    const by=l=>d.hosts.filter(x=>x.level===l);
    const err=x=>h('div',{class:'r'},h('b',{class:'dn'},'✗ '+x.host),h('span',{class:'mut'},x.error+(x.last_url?' — '+x.last_url:'')));
    const cov=x=>h('div',{class:'r'},h('b',{class:'warn'},'↪ '+x.host),h('span',{class:'mut'},'gagal, data diambil dari cadangan: '+x.covered_by));
    const opt=x=>h('div',{class:'r'},h('b',{class:'mut'},'· '+x.host),h('span',{class:'mut'},x.error));
    const okr=x=>h('div',{class:'r'},h('b',{class:'up'},'✓ '+x.host),h('span',{class:'mut'},'OK ('+x.ok+' permintaan'+(x.via?', via '+x.via:'')+')'));
    const dis=(d.disabled||[]).map(x=>h('div',{class:'r'},h('b',{class:'mut'},'⏸ '+x.url),h('span',{class:'mut'},x.reason+' — dicoba lagi otomatis nanti')));
    const rows=[...sec('PERLU PERHATIAN','dn',by('bad'),err),...sec('CADANGAN AKTIF (tidak memengaruhi data)','warn',by('covered'),cov),
      ...sec('GAGAL SEKALI (dicoba ulang otomatis)','mut',by('retry'),opt),
      ...sec('FEED OPSIONAL TIDAK AKTIF (sumber lain menggantikan)','mut',by('optional'),opt),...(dis.length?[h('div',{class:'hsec mut'},'DINONAKTIFKAN SEMENTARA ('+dis.length+')'),...dis]:[]),
      ...sec('NORMAL','up',by('ok'),okr)];
    hmodal.replaceChildren(h('div',{class:'box'},h('div',{class:'row',style:{marginBottom:'8px'}},h('b',null,'STATUS SUMBER DATA'),h('span',{class:'sp',style:{flex:1}}),h('button',{class:'btn',onclick:()=>hmodal.style.display='none'},'Tutup')),h('div',{class:'mut',style:{marginBottom:'8px'}},'Hanya sumber di bagian "Perlu perhatian" yang dihitung di lencana. Jalankan `python -m terminal.selfcheck` di komputer Anda untuk diagnosis lengkap.'),...rows));
    hmodal.style.display='block';
  }catch(e){}
};
clocks.addEventListener('click',async e=>{
  if(!e.target.closest('[data-snap]'))return;
  try{
    const d=await T.rawFetch('snapshots',{detail:1});
    const gs=Object.entries(d.groups||{});
    const fails=(d.items||[]).filter(i=>i.fails||i.age==null).slice(0,40);
    const upd=d.updated?T.ago(d.updated)+' lalu':'—';
    hmodal.replaceChildren(h('div',{class:'box'},h('div',{class:'row',style:{marginBottom:'8px'}},h('b',null,'DATA TERSIMPAN DI SERVER'),h('span',{class:'sp',style:{flex:1}}),h('button',{class:'btn',onclick:()=>hmodal.style.display='none'},'Tutup')),
      h('div',{class:'mut',style:{marginBottom:'8px'}},`${d.ready}/${d.planned} menu siap · ${d.stored} snapshot (${(d.bytes/1048576).toFixed(1)} MB) · pembaruan terakhir ${upd}. Pengunjung baru langsung memakai data ini; server memperbaruinya otomatis di latar belakang.`),
      ...gs.map(([g,v])=>h('div',{class:'r'},h('b',{class:v.failing?'warn':'up'},(v.failing?'↻ ':'✓ ')+g),h('span',{class:'mut'},`${v.ready}/${v.total} siap`+(v.failing?` · ${v.failing} sedang dicoba ulang`:'')))),
      ...(fails.length?[h('div',{class:'hsec dn'},'BELUM TERSEDIA / DICOBA ULANG ('+fails.length+')'),...fails.map(i=>h('div',{class:'r'},h('b',{class:'mut'},i.key),h('span',{class:'mut'},i.error||'menunggu')))]:[])));
    hmodal.style.display='block';
  }catch(err){}
});
loadTicker();setInterval(loadTicker,60000);setInterval(pollRev,25000);setTimeout(pollRev,800);
setTimeout(loadStrip,1500);setInterval(loadStrip,600000);
// Pencarian = command palette (Ctrl/Cmd+K atau "/"): menu, simbol, berita, alat.
const sbtn=document.getElementById('search');
sbtn.querySelector('.ic').innerHTML=T.ICONS.search;
if(/Mac|iPhone|iPad/.test(navigator.platform||''))sbtn.querySelector('kbd').textContent='⌘K';
sbtn.onclick=()=>T.openPalette();
document.getElementById('ticker').addEventListener('click',e=>{const t=e.target.closest('.tk');if(t)T.openAsset(t.dataset.sym)});
T.openAsset=sym=>{T.pendingAsset=sym;location.hash='#market'};
// Peran sesi (admin/user) ditentukan server dari kunci akses. Bila gagal dibaca, anggap user (hak paling sedikit).
// Peran disisipkan server ke halaman (window.__ROLE) -> menu langsung digambar tanpa menunggu /api/me lewat tunnel.
// /api/me tetap dicek di latar; bila berbeda (mis. halaman lama di cache), tampilan digambar ulang dengan peran yang benar.
T.role=window.__ROLE==='admin'?'admin':'user';
nav();showBad();
T.rawFetch('me',null,{bg:true}).then(d=>{const r=d&&d.role==='admin'?'admin':'user';if(r!==T.role){T.role=r;nav()}showBad()}).catch(()=>{});
})();
