(function(){
const h=T.h;
const CAT={tff:[['all','All Trader Types'],['lev','Leveraged Fund'],['asset','Asset Manager'],['dealer','Dealer']],disagg:[['all','All Trader Types'],['mm','Managed Money'],['prod','Producer/Merchant'],['swap','Swap Dealer']]};
const COLORS={lev:'#ff5b6b',asset:'#21c993',dealer:'#3b82f6',mm:'#ff5b6b',prod:'#21c993',swap:'#3b82f6',other:'#a78bfa'};
const NAMES={lev:'Leveraged Fund',asset:'Asset Manager',dealer:'Dealer',mm:'Managed Money',prod:'Producer/Merchant',swap:'Swap Dealer',other:'Other'};
let META=null;
// permintaan COT per instrumen disimpan; bila gagal, dibuang agar percobaan berikutnya mengambil ulang
const cot=name=>T.cache['cot:'+name]||(T.cache['cot:'+name]=T.api('cot/instrument',{name}).catch(e=>{delete T.cache['cot:'+name];throw e}));
const kindOf=n=>META.tff.includes(n)?'tff':'disagg';
function donut(long,short,size=34){
  const t=long+short;if(!t)return '';
  const p=long/t,r=size/2-3,c=2*Math.PI*r;
  return `<svg width="${size}" height="${size}"><circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="#e0475a" stroke-width="5"/><circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="#1aa57a" stroke-width="5" stroke-dasharray="${(c*p).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 ${size/2} ${size/2})"/></svg>`;
}
function cotView(box){
  let name='US Dollar Index',cat='all',metric='net';
  const top=h('div',{class:'grid resp',style:{gridTemplateColumns:'1fr 1fr',marginBottom:'8px'}});
  const A=T.panel('Commitment of Traders',{bodyStyle:{height:'340px',display:'flex',flexDirection:'column'}}),B=T.panel('Dataset Compare',{bodyStyle:{height:'340px',display:'flex',flexDirection:'column'}});
  top.append(A.el,B.el);
  const bottom=h('div',{class:'grid resp',style:{gridTemplateColumns:'1fr 1.3fr'}});
  const D=T.panel('History',{np:1,bodyStyle:{maxHeight:'380px'}}),C=T.panel('Asset Class Positioning',{np:1,bodyStyle:{maxHeight:'380px'}});
  bottom.append(D.el,C.el);
  box.append(top,bottom);
  const instSel=T.select(META.tff.concat(META.disagg),name,v=>{name=v;cat='all';rebuildCat();draw()});
  const catWrap=h('span');
  const rebuildCat=()=>{catWrap.replaceChildren(T.select(CAT[kindOf(name)].map(([v,l])=>({v,l})),cat,v=>{cat=v;draw()}))};
  rebuildCat();
  const mt=T.tabs([{id:'net',label:'Net Positioning'},{id:'ls',label:'L/S Breakdown'},{id:'oi',label:'Open Interest'},{id:'wk',label:'Weekly Changes'},{id:'bs',label:'Buy/Sell %'}],metric,m=>{metric=m;draw()},'sm');mt.style.margin=0;
  A.body.append(h('div',{class:'row',style:{marginBottom:'6px'}},instSel,catWrap),mt,h('div',{style:{flex:1,minHeight:'200px',position:'relative',marginTop:'6px'},id:'cotarea'}));
  async function draw(){
    const area=A.body.querySelector('#cotarea');
    area.replaceChildren(h('div',{class:'msg'},'Memuat…'));
    try{
      const d=await cot(name);
      area.replaceChildren();
      if(!d.rows.length){area.append(h('div',{class:'msg'},'Data COT tidak tersedia'));return}
      const rows=d.rows.slice().reverse();const dates=rows.map(r=>r.date);
      const ids=cat==='all'?d.groups.map(g=>g.id):[cat];
      D.body.replaceChildren(T.table([{label:'Date',left:true,k:'date'},{label:'OI',k:'oi',fmt:v=>T.fmt(v,0)}].concat(d.groups.filter(x=>cat==='all'||x.id===cat).flatMap(x=>[{label:x.label+' Long',k:x.id+'_long',fmt:v=>T.fmt(v,0)},{label:'Short',k:x.id+'_short',fmt:v=>T.fmt(v,0)},{label:'Net',k:x.id+'_net',fmt:v=>T.fmt(v,0),cls:v=>T.cls(v)}])),d.rows));
      const b=h('div',{style:{position:'absolute',inset:0}});
      if(metric==='bs'){
        const id=cat==='all'?d.groups[0].id:cat,last=d.rows[0];
        area.append(h('div',{class:'row',style:{justifyContent:'space-around',height:'100%'}},...d.groups.filter(g=>cat==='all'||g.id===cat).map(g=>{const lo=last[g.id+'_long']||0,sh=last[g.id+'_short']||0;return h('div',{style:{textAlign:'center'}},h('div',{html:donut(lo,sh,110)}),h('b',null,g.label),h('div',{class:'mut'},`Long ${(lo/(lo+sh||1)*100).toFixed(1)}% · Short ${(sh/(lo+sh||1)*100).toFixed(1)}%`),h('div',{class:T.cls(last[g.id+'_net'])},'Net '+T.big(last[g.id+'_net'])))}))) ;return;
      }
      area.append(b);
      const lines=[];
      ids.forEach(id=>{
        if(metric==='net')lines.push({name:NAMES[id],type:'line',showSymbol:false,data:rows.map(r=>r[id+'_net']),color:COLORS[id]});
        if(metric==='ls'){lines.push({name:NAMES[id]+' Long',type:'bar',stack:'ls',data:rows.map(r=>r[id+'_long']),itemStyle:{color:'#1aa57a'}});lines.push({name:NAMES[id]+' Short',type:'bar',stack:'ls2',data:rows.map(r=>-(r[id+'_short']||0)),itemStyle:{color:'#e0475a'}})}
        if(metric==='wk')lines.push({name:NAMES[id]+' Δ',type:'bar',data:rows.map(r=>r[id+'_chg']),itemStyle:{color:COLORS[id]}});
      });
      if(metric==='oi')lines.push({name:'Open Interest',type:'line',showSymbol:false,areaStyle:{color:'rgba(245,158,11,.15)'},data:rows.map(r=>r.oi),color:'#f59e0b'});
      T.chart(b,{grid:{left:56,right:12,top:26,bottom:26},tooltip:T.tip(),legend:{top:0,textStyle:{color:'#8f93a0',fontSize:10}},xAxis:T.axis({type:'category',data:dates}),yAxis:T.axis({type:'value',axisLabel:{formatter:v=>T.big(v),color:'#8a8f9c'}}),series:lines,dataZoom:[{type:'inside'}]});
    }catch(e){area.replaceChildren(h('div',{class:'msg err'},'Data tidak tersedia: '+e.message))}
  }
  const cmp={a:{cls:'Currencies',inst:'US Dollar Index',cat:'lev',m:'net'},b:{cls:'Commodities',inst:'Gold',cat:'mm',m:'net'}};
  const sel=(key,label)=>{
    const s=cmp[key];
    const instWrap=h('span'),catW=h('span');
    const fill=()=>{instWrap.replaceChildren(T.select(META.classes[s.cls],s.inst,v=>{s.inst=v;s.cat=CAT[kindOf(v)][1][0];fillCat();rerun()}))};
    const fillCat=()=>{catW.replaceChildren(T.select(CAT[kindOf(s.inst)].slice(1).map(([v,l])=>({v,l})),s.cat,v=>{s.cat=v;rerun()}))};
    fill();fillCat();
    return h('div',{class:'row',style:{marginBottom:'6px'}},h('b',{style:{color:label==='D1'?'#f59e0b':'#a78bfa',width:'22px'}},label),T.select(Object.keys(META.classes),s.cls,v=>{s.cls=v;s.inst=META.classes[v][0];s.cat=CAT[kindOf(s.inst)][1][0];fill();fillCat();rerun()}),instWrap,catW,T.select([{v:'net',l:'Net Position'},{v:'long',l:'Long'},{v:'short',l:'Short'}],s.m,v=>{s.m=v;rerun()}));
  };
  const cmpArea=h('div',{style:{flex:'1 1 auto',minHeight:'200px',marginTop:'6px',position:'relative'}});
  let diff=false,seq=0;
  const bCmp=h('button',{class:'btn on',onclick:()=>run(false)},'Compare datasets'),bNet=h('button',{class:'btn',onclick:()=>run(true)},'Calculate net (D1 − D2)');
  // Grafik perbandingan digambar langsung saat menu dibuka dan setiap kali pilihan D1/D2 berubah (tanpa harus menekan tombol).
  const rerun=()=>run(diff);
  const run=async(d)=>{
    diff=d;const my=++seq;bCmp.classList.toggle('on',!d);bNet.classList.toggle('on',d);
    cmpArea.replaceChildren(h('div',{class:'msg'},'Memuat…'));
    try{
      const [x,y]=await Promise.all([cot(cmp.a.inst),cot(cmp.b.inst)]);
      if(my!==seq||!cmpArea.isConnected)return;               // pilihan sudah berganti / menu ditinggalkan
      const get=(dat,s)=>new Map(dat.rows.map(r=>[r.date,r[s.cat+'_'+s.m]]));
      const ma=get(x,cmp.a),mb=get(y,cmp.b);
      const dates=[...ma.keys()].filter(k=>mb.has(k)).sort();
      if(!dates.length){cmpArea.replaceChildren(h('div',{class:'msg'},'Tidak ada tanggal laporan yang sama untuk D1 dan D2'));return}
      cmpArea.replaceChildren();const b=h('div',{style:{position:'absolute',inset:0}});cmpArea.append(b);
      const series=diff?[{name:'D1 − D2',type:'line',showSymbol:false,data:dates.map(k=>ma.get(k)-mb.get(k)),color:'#ff5b6b',areaStyle:{color:'rgba(255,91,107,.12)'}}]
        :[{name:cmp.a.inst,type:'line',showSymbol:false,data:dates.map(k=>ma.get(k)),color:'#f59e0b'},{name:cmp.b.inst,type:'line',yAxisIndex:1,showSymbol:false,data:dates.map(k=>mb.get(k)),color:'#a78bfa'}];
      T.chart(b,{grid:{left:56,right:56,top:24,bottom:24},tooltip:T.tip(),legend:{top:0,textStyle:{color:'#8f93a0',fontSize:10}},xAxis:T.axis({type:'category',data:dates}),yAxis:[T.axis({type:'value',axisLabel:{formatter:v=>T.big(v),color:'#8a8f9c'}}),T.axis({type:'value',axisLabel:{formatter:v=>T.big(v),color:'#8a8f9c'},splitLine:{show:false}})],series});
    }catch(e){if(my===seq)cmpArea.replaceChildren(h('div',{class:'msg err'},'Data tidak tersedia: '+e.message))}
  };
  B.body.append(sel('a','D1'),sel('b','D2'),h('div',{class:'row'},bCmp,bNet),cmpArea);
  run(false);
  let ccls='Currencies',ccat='lev';
  const cwrap=h('div');
  const loadC=()=>{
    const first=META.classes[ccls][0],kind=kindOf(first);
    if(!CAT[kind].some(c=>c[0]===ccat))ccat=CAT[kind][1][0];
    cwrap.replaceChildren(h('div',{class:'msg'},'Memuat…'));
    T.api('cot/class',{cls:ccls}).then(d=>{
      cwrap.replaceChildren(T.table([{label:'Instrument',left:true,get:r=>r.name},{label:'Net pos',get:r=>r.rows[0][ccat+'_net'],fmt:v=>T.big(v),cls:v=>T.cls(v)},{label:'OI',get:r=>r.rows[0].oi,fmt:v=>T.big(v)},
        {label:'Long',get:r=>r.rows[0][ccat+'_long'],fmt:v=>T.big(v)},{label:'Short',get:r=>r.rows[0][ccat+'_short'],fmt:v=>T.big(v)},{label:'Wkly Δ',get:r=>r.rows[0][ccat+'_chg'],fmt:v=>T.big(v),cls:v=>T.cls(v)},
        {label:'Trend',html:(_,r)=>T.spark(r.rows.slice(0,20).reverse().map(x=>x[ccat+'_net']))},{label:'Buy/Sell',html:(_,r)=>donut(r.rows[0][ccat+'_long']||0,r.rows[0][ccat+'_short']||0)}],d.items,{onRow:r=>{name=r.name;cat='all';instSel.value=name;rebuildCat();draw()}}));
      if(!d.items.length)cwrap.append(h('div',{class:'msg'},'Data tidak tersedia'));
    }).catch(e=>cwrap.replaceChildren(h('div',{class:'msg err'},e.message)));
  };
  C.head.append(T.select(Object.keys(META.classes),ccls,v=>{ccls=v;loadC()}),T.select(CAT.tff.slice(1).concat(CAT.disagg.slice(1)).map(([v,l])=>({v,l})),ccat,v=>{ccat=v;loadC()}));
  C.body.append(cwrap);
  draw();loadC();
}
// ---- Retail Sentiment (Myfxbook) -------------------------------------------------------------------------------------
// Perbaikan: (1) tinggi panel tetap sehingga grafik tidak lagi mengikuti tinggi tabel 100+ baris; (2) sumbu waktu sungguhan
// (bukan kategori) sehingga jarak titik sesuai waktu; (3) skala Y per metrik (0-100 untuk %, garis nol untuk net volume);
// (4) angka dibulatkan di tooltip/tabel; (5) histori <2 snapshot ditampilkan sebagai kartu, bukan grafik kosong;
// (6) render ulang tidak lagi menumpuk kontrol di panel kiri.
const RMETRICS={
  net:{label:'Net Volume',series:[{name:'Net vol (lots)',get:r=>r.net_vol,color:'#21c993'}],fmt:v=>T.fmt(v,2),zero:true,area:true},
  pct:{label:'Percentage Position',series:[{name:'% Long',get:r=>r.long_pct,color:'#3b82f6'},{name:'% Short',get:r=>r.short_pct,color:'#f59e0b'}],fmt:v=>T.fmt(v,1)+'%',min:0,max:100,ref:50},
  lots:{label:'Lot Volume',series:[{name:'Long vol',get:r=>r.long_vol,color:'#a78bfa'},{name:'Short vol',get:r=>r.short_vol,color:'#f59e0b'}],fmt:v=>T.fmt(v,2),scale:true},
  pos:{label:'Number of Positions',series:[{name:'Long pos',get:r=>r.long_pos,color:'#21c993'},{name:'Short pos',get:r=>r.short_pos,color:'#ff5b6b'}],fmt:v=>T.fmt(v,0),scale:true},
  tot:{label:'Total Position',series:[{name:'Total positions',get:r=>r.total_pos,color:'#e11d48',bar:true}],fmt:v=>T.fmt(v,0)},
  avg:{label:'Avg. Entry Price',series:[{name:'Avg long',get:r=>r.avg_long,color:'#34d399'},{name:'Avg short',get:r=>r.avg_short,color:'#e5e7eb'}],fmt:v=>T.fmt(v,v!=null&&Math.abs(v)<20?5:2),scale:true}
};
const RDAYS=[[1,'1 hari'],[3,'3 hari'],[7,'7 hari'],[14,'14 hari'],[30,'30 hari']];
const tstr=ms=>new Date(ms).toLocaleString('en-GB',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
function retailOption(rows,M){
  const ser=M.series.map(s=>{
    const data=rows.map(r=>[r.ts*1000,s.get(r)]).filter(p=>p[1]!=null);
    const few=data.length<=60;
    const o=s.bar?{type:'bar',name:s.name,data,itemStyle:{color:s.color},barMinWidth:4,barMaxWidth:22}
      :{type:'line',name:s.name,data,color:s.color,showSymbol:few,symbolSize:5,lineStyle:{width:1.8},connectNulls:true};
    if(M.area&&!s.bar){
      // Area mengisi dari garis nol; hijau di atas nol, merah di bawah nol (sebelumnya satu warna hijau memenuhi seluruh panel untuk nilai negatif).
      // Catatan: batas piece tepat 0 (gt:0 / min:0) memicu error 'coord' di ECharts 5.6.1, karena itu dipakai 1e-9.
      o.areaStyle={opacity:.14};o.lineStyle={width:1.8};
      o.markLine={silent:true,symbol:'none',data:[{yAxis:0}],lineStyle:{color:'#5b6170',type:'dashed'},label:{show:false}};
    }
    if(M.ref!=null&&!s.bar&&s===M.series[0])o.markLine={silent:true,symbol:'none',data:[{yAxis:M.ref}],lineStyle:{color:'#34404f',type:'dashed'},label:{show:false}};
    return o;
  });
  const y=T.axis({type:'value',axisLabel:{color:'#8a8f9c',fontSize:10,formatter:v=>M.fmt(v)}});
  if(M.min!=null)y.min=M.min;if(M.max!=null)y.max=M.max;
  if(M.scale){y.scale=true;y.boundaryGap=['12%','12%']}
  const opt={
    grid:{left:66,right:18,top:34,bottom:40},
    legend:{top:2,textStyle:{color:'#8f93a0',fontSize:10},icon:'roundRect',itemWidth:12,itemHeight:4},
    tooltip:T.tip({formatter:ps=>{
      const a=Array.isArray(ps)?ps:[ps];
      return '<div style="color:#8f93a0;margin-bottom:3px">'+T.esc(tstr(a[0].value[0]))+'</div>'+a.map(p=>'<div style="white-space:nowrap"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:'+(typeof p.color==='string'?p.color:'#94a3b8')+';margin-right:6px"></span>'+T.esc(p.seriesName)+'<b style="float:right;margin-left:16px">'+M.fmt(p.value[1])+'</b></div>').join('');
    }}),
    xAxis:T.axis({type:'time',axisLabel:{color:'#8a8f9c',fontSize:10,hideOverlap:true,formatter:v=>tstr(v)},splitNumber:5,splitLine:{show:false}}),
    yAxis:y,series:ser,dataZoom:[{type:'inside',filterMode:'none'}]
  };
  if(M.area){
    opt.visualMap={show:false,type:'piecewise',dimension:1,seriesIndex:0,pieces:[{min:1e-9,color:'#21c993'},{max:0,color:'#ff5b6b'}],outOfRange:{color:'#21c993'}};
  }
  return opt;
}
function retailView(box){
  const MEM=T.mem('retail',{sym:'XAUUSD',metric:'net',days:14,filter:''});
  const top=h('div',{class:'grid resp retailgrid',style:{gridTemplateColumns:'1.3fr 1fr'}});
  const A=T.panel('Retail Sentiment',{bodyStyle:{display:'flex',flexDirection:'column',overflow:'hidden'}}),B=T.panel('Instruments',{np:1});
  top.append(A.el,B.el);box.append(top);
  const ctl={draw:null,chart:null};
  const kill=()=>{const c=ctl.chart;if(c){try{c._ro&&c._ro.disconnect();c.dispose()}catch(e){}T.charts=T.charts.filter(x=>x!==c);ctl.chart=null}};
  T.every(60000,()=>{if(ctl.draw)ctl.draw(true)});
  T.load(B.body,T.api('retail/table'),d=>{
    kill();A.body.replaceChildren();B.head.querySelectorAll('.rfilter').forEach(x=>x.remove());
    if(!d.status.enabled||!d.rows.length){
      ctl.draw=null;
      const why=d.status.enabled?(d.status.error?'Myfxbook error: '+d.status.error:'Menunggu snapshot pertama Myfxbook (maks 20 menit)…'):'Isi MYFXBOOK_EMAIL dan MYFXBOOK_PASSWORD di .env (akun Myfxbook gratis) untuk mengaktifkan modul ini.';
      B.body.append(h('div',{class:'msg'},why));A.body.append(h('div',{class:'msg'},'Belum ada data retail'));return;
    }
    const rows=d.rows,syms=rows.map(r=>r.symbol);
    if(!syms.includes(MEM.sym))MEM.sym=syms.includes('XAUUSD')?'XAUUSD':syms[0];
    // ---- tabel instrumen (dengan filter)
    const tableHost=h('div');
    const inp=h('input',{class:'in rfilter',placeholder:'Cari simbol…',value:MEM.filter,style:{width:'110px',padding:'2px 6px',fontSize:'10px',textTransform:'none'},oninput:e=>{MEM.filter=e.target.value;drawTable()}});
    B.head.append(inp);
    const cols=[{label:'Instrument',left:true,k:'symbol'},{label:'Net lots',k:'net_vol',fmt:v=>T.fmt(v,1),cls:v=>T.cls(v)},{label:'Total pos',k:'total_pos',fmt:v=>T.fmt(v,0)},
      {label:'% Long',k:'long_pct',fmt:v=>v==null?'—':T.fmt(v,0)+'%',cls:()=>'up'},{label:'% Short',k:'short_pct',fmt:v=>v==null?'—':T.fmt(v,0)+'%',cls:()=>'dn'},
      {label:'Δ Vol',k:'dvol',fmt:v=>v==null?'—':T.sgn(v,1),cls:v=>T.cls(v)},{label:'Trend',html:(_,r)=>T.spark(r.trend,54,18)},{label:'L/S',html:(_,r)=>donut(r.long_pct,r.short_pct,26)}];
    function drawTable(){
      const q=MEM.filter.trim().toUpperCase(),list=q?rows.filter(r=>r.symbol.includes(q)):rows;
      tableHost.replaceChildren(list.length?T.table(cols,list,{onRow:r=>{MEM.sym=r.symbol;sel.value=MEM.sym;draw()},selected:r=>r.symbol===MEM.sym}):h('div',{class:'msg'},'Simbol tidak ditemukan'));
    }
    B.body.append(tableHost);drawTable();
    if(MEM.tscroll)B.body.scrollTop=MEM.tscroll;
    B.body.onscroll=()=>{MEM.tscroll=B.body.scrollTop};
    // ---- kontrol grafik
    const sel=T.select(syms,MEM.sym,v=>{MEM.sym=v;draw()});
    const dsel=T.select(RDAYS.map(([v,l])=>({v,l})),MEM.days,v=>{MEM.days=+v;draw()});
    const mt=T.tabs(Object.entries(RMETRICS).map(([id,m])=>({id,label:m.label})),MEM.metric,m=>{MEM.metric=m;draw()},'sm');mt.style.margin='0 0 6px';
    const sum=h('div',{class:'rsum'});
    const area=h('div',{style:{flex:'1 1 auto',position:'relative',minHeight:'220px'}});
    const note=h('div',{class:'mut',style:{fontSize:'10px',marginTop:'4px',minHeight:'13px'}});
    A.body.append(h('div',{class:'row',style:{marginBottom:'6px'}},sel,dsel),mt,sum,area,note);
    function kv(label,val,cls){return h('div',{class:'rk'},h('span',{class:'mut'},label),h('b',{class:cls||''},val))}
    async function draw(quiet){
      const g=T.gen,sym=MEM.sym,days=MEM.days,metric=MEM.metric,M=RMETRICS[metric];
      if(!quiet)area.replaceChildren(h('div',{class:'msg'},'Memuat…'));
      let x;
      try{x=await T.api('retail/history',{symbol:sym,days},{force:!!quiet})}catch(e){if(g===T.gen&&!quiet)area.replaceChildren(h('div',{class:'msg err'},e.message));return}
      if(g!==T.gen||sym!==MEM.sym||days!==MEM.days||metric!==MEM.metric||!area.isConnected)return;
      kill();area.replaceChildren();
      const hr=x.rows;
      if(!hr.length){sum.replaceChildren();note.textContent='';area.append(h('div',{class:'msg'},'Belum ada histori untuk '+sym+' pada rentang ini'));return}
      const L=hr[hr.length-1],ageMin=Math.max(0,Math.round((Date.now()/1000-L.ts)/60));
      sum.replaceChildren(
        kv('Long / Short',T.fmt(L.long_pct,1)+'% / '+T.fmt(L.short_pct,1)+'%'),kv('Net vol',T.sgn(L.net_vol,2)+' lots',T.cls(L.net_vol)),
        kv('Posisi',T.fmt(L.long_pos,0)+' L · '+T.fmt(L.short_pos,0)+' S'),kv('Update',tstr(L.ts*1000)+' ('+(ageMin<60?ageMin+' mnt':Math.round(ageMin/60)+' j')+' lalu)',ageMin>75?'warn':''));
      const stale=ageMin>3*(x.interval||1200)/60;
      note.textContent=hr.length+' snapshot tersimpan sejak '+tstr(hr[0].ts*1000)+' · interval ±'+Math.round((x.interval||1200)/60)+' mnt'+(stale?' · ⚠ data terakhir sudah lama (cek status Myfxbook)':'');
      if(hr.length<2){
        area.append(h('div',{class:'msg',style:{padding:'48px 16px'}},h('div',{style:{marginBottom:'6px',color:'var(--txt)'}},'Snapshot pertama '+sym+' tersimpan ('+tstr(L.ts*1000)+').'),'Grafik tren muncul setelah snapshot berikutnya (±'+Math.round((x.interval||1200)/60)+' menit). Histori terkumpul selama bot berjalan.'));
        return;
      }
      const b=h('div',{style:{position:'absolute',inset:'0'}});area.append(b);
      ctl.chart=T.chart(b,retailOption(hr,M));
    }
    ctl.draw=draw;draw();
  });
}
T.Views.participant=function(root){
  let tab='cot';
  const tabs=T.tabs([{id:'cot',label:'Commitment of Traders'},{id:'retail',label:'Retail Sentiment'}],tab,t=>{tab=t;go()});
  const body=h('div');root.append(tabs,body);
  async function go(){
    T.dispose();body.replaceChildren();
    if(tab==='retail')return retailView(body);
    if(!META){try{META=await T.api('cot/meta')}catch(e){body.append(h('div',{class:'msg err'},e.message));return}}
    cotView(body);
  }
  go();
};
})();
