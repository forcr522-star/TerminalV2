(function(){
const h=T.h;
function arc(a,b,n=24){
  const mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2,dx=b[1]-a[1],dy=b[0]-a[0],len=Math.hypot(dx,dy),k=Math.min(0.28*len,22);
  const cx=mx+(len?(-dx/len)*k:0)*(dy>=0?1:1),cy=my+(len?(dy/len)*k:0);
  const pts=[];for(let i=0;i<=n;i++){const t=i/n;pts.push([(1-t)*(1-t)*a[0]+2*(1-t)*t*cx+t*t*b[0],(1-t)*(1-t)*a[1]+2*(1-t)*t*cy+t*t*b[1]])}
  return pts;
}
T.Views.supply=function(root){
  let cc='US',flow='X',pairCode=null;
  const bar=h('div',{class:'row',style:{marginBottom:'8px'}});
  const body=h('div');root.append(bar,body);
  function go(){
    T.dispose();
    bar.replaceChildren(h('span',{class:'mut'},'REPORTER:'),T.select(T.countries.map(c=>({v:c[0],l:c[0]+' · '+c[1]})),cc,v=>{cc=v;pairCode=null;go()}),
      h('span',{class:'mut',style:{marginLeft:'8px'}},'FLOW MODE:'),T.tabs([{id:'X',label:'Exports'},{id:'M',label:'Imports'}],flow,f=>{flow=f;go()},'sm'));
    bar.lastChild.style.margin=0;
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('supply/overview',{cc,flow}),d=>{
      if(!d.partners.length){wrap.append(h('div',{class:'msg'},'Data UN Comtrade tidak tersedia untuk reporter/periode ini'));return}
      const name=T.cname(cc);
      wrap.append(h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))',marginBottom:'8px'}},
        ...[['Exports',T.big(d.exports,'$')],['Imports',T.big(d.imports,'$')],['Trade balance',T.big(d.balance,'$'),T.cls(d.balance)],['Top-5 concentration',T.fmt(d.concentration,1)+'%'],['Partners',d.partners_count],['Dataset year',d.year]].map(([l,v,c])=>h('div',{class:'kpi'},h('div',{class:'l'},l),h('div',{class:'v '+(c||''),style:{fontSize:'18px'}},v)))));
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'2fr 1fr',marginBottom:'8px'}});
      const M=T.panel(`${name} ${flow==='X'?'exports':'imports'} network routes`,{np:1,bodyStyle:{height:'380px'}}),R=T.panel(`Partner ranking (${flow==='X'?'exports':'imports'})`,{np:1,bodyStyle:{height:'380px'}});
      g.append(M.el,R.el);wrap.append(g);
      const mapEl=h('div',{class:'map',style:{height:'100%'}});M.body.append(mapEl);
      const map=T.map(mapEl,[25,20],2);
      const o=[d.origin.lat,d.origin.lon];
      const mx=d.partners[0].value||1;
      d.partners.forEach(p=>{if(p.lat==null)return;
        L.polyline(arc(o,[p.lat,p.lon]),{color:'#34d399',weight:1+4*p.value/mx,opacity:.55}).bindTooltip(`${p.name}: ${T.big(p.value,'$')}`).addTo(map);
        L.circleMarker([p.lat,p.lon],{radius:4,color:'#34d399',fillOpacity:.9,weight:0}).addTo(map)});
      L.circleMarker(o,{radius:6,color:'#60a5fa',fillOpacity:1}).addTo(map);
      R.body.append(...d.partners.map((p,i)=>h('div',{style:{padding:'6px 10px',borderBottom:'1px solid #161a24',cursor:'pointer'},onclick:()=>{pairCode=p.code;pair.go()}},
        h('div',{class:'row'},h('span',{class:'mut'},String(i+1).padStart(2,'0')),h('b',null,p.name),h('span',{style:{marginLeft:'auto'},class:'up'},T.big(p.value,'$'))),
        h('div',{class:'bar2',style:{marginTop:'3px'}},h('i',{style:{width:(p.value/mx*100)+'%',background:'#10b981'}})))));
      const P=T.panel('Bilateral pair intelligence · mirror & asymmetry',{bodyStyle:{minHeight:'150px'}});
      const pair={go(){
        const code=pairCode||d.partners[0].code;
        P.body.replaceChildren(h('div',{class:'row'},h('span',{class:'mut'},'PARTNER:'),T.select(d.partners.map(p=>({v:p.code,l:p.name})),code,v=>{pairCode=+v;pair.go()})),h('div',{class:'msg'},'Memuat…'));
        T.api('supply/pair',{cc,partner:code}).then(x=>{
          const nm=(d.partners.find(p=>p.code===+code)||{}).name||code;
          const cell=(l,v,c)=>h('div',{class:'kpi'},h('div',{class:'l'},l),h('div',{class:'v '+(c||''),style:{fontSize:'17px'}},v==null?'—':T.big(v,'$')));
          P.body.replaceChildren(h('div',{class:'row',style:{marginBottom:'8px'}},h('span',{class:'mut'},'PARTNER:'),T.select(d.partners.map(p=>({v:p.code,l:p.name})),code,v=>{pairCode=+v;pair.go()}),h('span',{class:'mut'},`${cc} ⇄ ${nm} · ${x.year}`)),
            h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))'}},cell(`${cc} → ${nm} exports`,x.exports),cell(`${cc} ← ${nm} imports`,x.imports),cell('Bilateral net',x.net,T.cls(x.net)),cell(`${nm} reports imports from ${cc}`,x.mirror_imports),cell(`${nm} reports exports to ${cc}`,x.mirror_exports),cell('Export gap (mirror)',x.gap_exports,T.cls(x.gap_exports)),cell('Import gap (mirror)',x.gap_imports,T.cls(x.gap_imports))));
        }).catch(e=>P.body.replaceChildren(h('div',{class:'msg err'},e.message)));
      }};
      wrap.append(P.el);pair.go();
      const g2=h('div',{class:'grid resp',style:{gridTemplateColumns:'1fr 1fr 1fr',marginTop:'8px'}});
      const B=T.panel('Partner bubble exposure',{bodyStyle:{height:'300px',padding:'4px'}}),H=T.panel('Partner exposure heatmap',{np:1,bodyStyle:{height:'300px'}}),S=T.panel('Trade by sector (HS2)',{bodyStyle:{height:'300px',padding:'4px'}});
      g2.append(B.el,H.el,S.el);wrap.append(g2);
      const bb=T.chartBox();B.body.append(bb);
      T.chart(bb,{tooltip:{backgroundColor:'#0b0d12',textStyle:{color:'#d7dbe6'},formatter:p=>`${p.data.name}<br>${T.big(p.data.v,'$')}`},series:[{type:'graph',layout:'force',force:{repulsion:90,gravity:.08},roam:false,label:{show:true,color:'#d1fae5',fontSize:10},itemStyle:{color:'rgba(16,185,129,.25)',borderColor:'#10b981'},
        data:d.partners.slice(0,12).map(p=>({name:p.name,v:p.value,symbolSize:20+60*Math.sqrt(p.value/mx)}))}]});
      const hm=Math.max(1,...d.heat.map(r=>Math.abs(r.net)));
      H.body.append(T.table([{label:'Partner',left:true,get:r=>r.name},{label:'Exp',k:'exp',fmt:v=>T.big(v,'$')},{label:'Imp',k:'imp',fmt:v=>T.big(v,'$')},{label:'Net',html:(_,r)=>`<div class="cell" style="background:${T.heat(r.net,hm)}">${T.big(r.net,'$')}</div>`}],d.heat));
      T.api('supply/sectors',{cc,flow}).then(s=>{const b=T.chartBox();S.body.append(b);
        T.chart(b,{grid:{left:110,right:20,top:6,bottom:16},tooltip:T.tip({trigger:'item'}),xAxis:T.axis({type:'value',axisLabel:{formatter:v=>T.big(v),color:'#7d8498'}}),yAxis:T.axis({type:'category',inverse:true,data:s.items.map(i=>i.name),axisLabel:{color:'#9aa3b8',fontSize:9}}),series:[{type:'bar',data:s.items.map(i=>i.value),itemStyle:{color:'#3b82f6'}}]})}).catch(e=>S.body.append(h('div',{class:'msg err'},e.message)));
    });
  }
  go();
};
})();
