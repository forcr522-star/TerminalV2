(function(){
const h=T.h;
const RANGES=['1D','5D','1M','3M','6M','1Y','5Y','ALL'];
T.Views.market=function(root){
  let tab='overview',cls='ALL',sym=T.pendingAsset||'US500',mode='candle',rng='1Y',overlay=null,filter='';T.pendingAsset=null;
  const tabs=T.tabs([{id:'overview',label:'Overview'},{id:'heatmap',label:'Heatmap'}],tab,t=>{tab=t;go()});
  const body=h('div');root.append(tabs,body);
  function go(){T.dispose();tab==='overview'?overview():heatmap()}
  function overview(){
    const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'minmax(300px,.8fr) 2fr',height:'calc(100vh - 170px)',minHeight:'420px'}});
    body.replaceChildren(g);
    const L=T.panel('Assets',{np:1}),R=T.panel('Price Chart',{np:1});
    g.append(L.el,R.el);
    const ctabs=T.tabs([{id:'ALL',label:'All'},{id:'INDEX',label:'Indices'},{id:'FX',label:'Currencies'},{id:'COMMODITY',label:'Commod.'},{id:'CRYPTO',label:'Crypto'},{id:'BOND',label:'Bonds'}],cls,c=>{cls=c;loadList()},'sm');
    ctabs.style.margin='6px';
    const fin=h('input',{class:'in',placeholder:'Filter ticker or asset name…',style:{margin:'0 6px 6px',width:'calc(100% - 12px)'},oninput:e=>{filter=e.target.value.toLowerCase();render()}});
    const listBox=h('div',{style:{overflow:'auto',flex:1}});
    L.body.style.display='flex';L.body.style.flexDirection='column';L.body.append(ctabs,fin,listBox);
    let rows=[];
    const render=()=>{
      const rs=rows.filter(r=>!filter||r.sym.toLowerCase().includes(filter)||r.name.toLowerCase().includes(filter));
      listBox.replaceChildren(T.table([{label:'Asset',left:true,html:(_,r)=>`<b>${T.esc(r.sym)}</b><div class="mut" style="font-size:9px">${T.esc(r.name)}</div>`},{label:'Price',k:'price',fmt:v=>T.fmt(v,v!=null&&v<10?4:2)},{label:'Day',node:(_,r)=>h('span',{class:T.cls(r.pct)},T.pct(r.pct))},
        {label:'Range',html:(_,r)=>r.range_pos==null?'':`<div class="bar2" style="min-width:50px"><i style="width:${r.range_pos*100}%;background:${r.pct>=0?'#16a34a':'#dc2626'}"></i></div>`}],rs.filter(r=>r.price!=null),{onRow:r=>{sym=r.sym;drawChart()},selected:r=>r.sym===sym}));
    };
    const loadList=()=>T.load(listBox,T.api('market/assets',{cls}),d=>{rows=d.rows;render()});
    const head=h('div',{class:'row',style:{padding:'8px'}});
    const modes=T.tabs([{id:'area',label:'Area'},{id:'candle',label:'Candle'},{id:'line',label:'Line'},{id:'hist',label:'Historical'},{id:'overlay',label:'Overlay'}],mode,m=>{mode=m;drawChart()},'sm');
    const rtabs=T.tabs(RANGES,rng,r=>{rng=r;drawChart()},'sm');
    modes.style.margin=0;rtabs.style.margin=0;rtabs.style.marginLeft='auto';
    const title=h('div',{style:{fontWeight:700,fontSize:'15px'}});
    const hint=h('input',{class:'in',placeholder:'overlay ticker (mis. BTC-USD)',style:{width:'150px',display:'none'},onchange:e=>{overlay=e.target.value.trim();drawChart()}});
    head.append(title,modes,hint,rtabs);
    const area=h('div',{style:{flex:1,minHeight:'300px',position:'relative'}});
    R.body.style.display='flex';R.body.style.flexDirection='column';R.body.append(head,area);
    async function drawChart(){
      T.charts.forEach(c=>{try{c.dispose()}catch(e){}});T.charts=[];
      hint.style.display=mode==='overlay'?'block':'none';
      title.textContent=sym;
      area.replaceChildren(h('div',{class:'msg'},'Memuat chart…'));
      try{
        const d=await T.api('market/history',{symbol:sym,range:rng});
        const r=d.rows;title.innerHTML=`${T.esc(d.name)} <span class="mut" style="font-size:11px">${T.esc(sym)}</span> <span class="${T.cls(r.length>1?r[r.length-1].c-r[r.length-2].c:0)}">${T.fmt(r.length?r[r.length-1].c:null,r.length&&r[r.length-1].c<10?4:2)}</span>`;
        area.replaceChildren();
        if(!r.length){area.append(h('div',{class:'msg'},'Tidak ada data'));return}
        if(mode==='hist'){
          const hist=r.slice().reverse().map((x,i,a)=>({...x,chg:a[i+1]?(x.c/a[i+1].c-1)*100:null}));
          area.append(h('div',{style:{position:'absolute',inset:0,overflow:'auto'}},T.table([{label:'Date',left:true,k:'d'},{label:'Close',k:'c',fmt:v=>T.fmt(v,4)},{label:'Open',k:'o',fmt:v=>T.fmt(v,4)},{label:'High',k:'h',fmt:v=>T.fmt(v,4)},{label:'Low',k:'l',fmt:v=>T.fmt(v,4)},{label:'Volume',k:'v',fmt:v=>T.big(v)},{label:'1D Chg',k:'chg',fmt:v=>T.pct(v),cls:v=>T.cls(v)}],hist)));
          return;
        }
        const box=h('div',{style:{position:'absolute',inset:0}});area.append(box);
        const x=r.map(p=>rng==='1D'||rng==='5D'?new Date(p.t).toLocaleString('en-GB',{day:'2-digit',hour:'2-digit',minute:'2-digit'}):p.d);
        const vol={type:'bar',data:r.map(p=>p.v),xAxisIndex:1,yAxisIndex:1,itemStyle:{color:'#2a3550'}};
        const common={tooltip:T.tip(),dataZoom:[{type:'inside',xAxisIndex:[0,1]}],axisPointer:{link:[{xAxisIndex:'all'}]}};
        const gr=[{left:56,right:16,top:14,height:'66%'},{left:56,right:16,top:'80%',height:'12%'}];
        const xa=[T.axis({type:'category',data:x,boundaryGap:mode==='candle',axisLabel:{show:false}}),T.axis({type:'category',data:x,gridIndex:1,axisLabel:{color:'#7d8498',fontSize:9}})];
        const ya=[T.axis({type:'value',scale:true,position:'right'}),T.axis({type:'value',gridIndex:1,splitLine:{show:false},axisLabel:{show:false}})];
        if(mode==='candle'){
          T.chart(box,{...common,grid:gr,xAxis:xa,yAxis:ya,series:[{type:'candlestick',data:r.map(p=>[p.o,p.c,p.l,p.h]),itemStyle:{color:'#22c55e',color0:'#ef4444',borderColor:'#22c55e',borderColor0:'#ef4444'}},vol]});
        }else if(mode==='overlay'){
          let ov=null;
          if(overlay){try{ov=(await T.api('market/history',{symbol:overlay,range:rng})).rows}catch(e){}}
          const norm=a=>a.map(p=>(p.c/a[0].c-1)*100);
          const series=[{name:sym,type:'line',showSymbol:false,data:norm(r),color:'#3b82f6'}];
          if(ov&&ov.length)series.push({name:overlay,type:'line',showSymbol:false,data:norm(ov),color:'#f59e0b'});
          T.chart(box,{tooltip:T.tip(),legend:{top:0,textStyle:{color:'#8b93a7'}},grid:{left:56,right:16,top:26,bottom:26},xAxis:T.axis({type:'category',data:x}),yAxis:T.axis({type:'value',axisLabel:{formatter:'{value}%',color:'#7d8498'}}),series,dataZoom:[{type:'inside'}]});
        }else{
          const up=r[r.length-1].c>=r[0].c,col=up?'#22c55e':'#ef4444';
          T.chart(box,{...common,grid:gr,xAxis:xa,yAxis:ya,series:[{type:'line',data:r.map(p=>p.c),showSymbol:false,lineStyle:{color:col,width:1.5},areaStyle:mode==='area'?{color:up?'rgba(34,197,94,.16)':'rgba(239,68,68,.16)'}:null},vol]});
        }
      }catch(e){area.replaceChildren(h('div',{class:'msg err'},'Data tidak tersedia: '+e.message))}
    }
    loadList();drawChart();
  }
  function heatmap(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('market/heatmap'),d=>{
      const grid=h('div',{class:'grid resp',style:{gridTemplateColumns:'repeat(2,1fr)'}});
      wrap.append(grid);
      Object.entries(d.groups).forEach(([name,items])=>{
        const p=T.panel(name,{np:1,bodyStyle:{height:'340px',padding:'2px'}});grid.append(p.el);
        if(!items.length){p.body.append(h('div',{class:'msg'},'Tidak ada data'));return}
        const box=T.chartBox();p.body.append(box);
        const col=v=>v==null?'#1f2430':v>=0?`rgba(34,197,94,${Math.min(.85,.18+Math.abs(v)/3)})`:`rgba(239,68,68,${Math.min(.85,.18+Math.abs(v)/3)})`;
        T.chart(box,{tooltip:{backgroundColor:'#0b0d12',borderColor:'#2a3042',textStyle:{color:'#d7dbe6'},formatter:p=>`${p.name}<br>${T.fmt(p.data.price,4)} ${p.data.pct!=null?T.pct(p.data.pct):''}`},
          series:[{type:'treemap',roam:false,nodeClick:false,breadcrumb:{show:false},width:'100%',height:'100%',itemStyle:{borderColor:'#0b0d12',borderWidth:2,gapWidth:1},
            label:{show:true,color:'#fff',fontSize:11,formatter:p=>`${p.name}\n${p.data.pct!=null?T.pct(p.data.pct):T.fmt(p.data.price,2)}`},
            data:items.map(i=>({name:i.sym,value:1+Math.abs(i.pct||0)*4,price:i.price,pct:i.pct,itemStyle:{color:col(i.pct)}}))}]});
      });
    });
  }
  go();
};
})();
