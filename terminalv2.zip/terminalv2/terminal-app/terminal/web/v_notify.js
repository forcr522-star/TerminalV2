// =====================================================================================================================
// PUSAT NOTIFIKASI (satu-satunya pengaturan notifikasi; tombol di DASHBOARD, per browser / per pengguna)
//   Mencakup SEMUA update penting terminal (bukan log): berita penting, headline cepat (squawk), kalender ekonomi
//   (menjelang & saat rilis), suku bunga bank sentral, yield & kurva, sinyal (baru / terisi / selesai), likuiditas
//   heatmap, price alert watchlist.
//   Tiap notifikasi: kartu berwarna menurut tingkat (TINGGI merah, SEDANG kuning, RENDAH biru, POSITIF hijau)
//   -> nada notifikasi -> isi notifikasi DIBACAKAN (bahasa Indonesia; headline berbahasa Inggris dengan suara Inggris).
//   Antrean berurutan: bacaan tidak saling menimpa; bila menumpuk, yang paling rendah diringkas ("ada N notifikasi lain").
//   Website di latar / ditutup: notifikasi Chrome (Web Push lewat service worker /sw.js).
//   PER PENGGUNA: pengaturan milik browser ini + peran yang login (admin & user di browser yang sama pun terpisah).
//   Browser/pengguna yang tidak mengaktifkan tidak dikirimi apa pun; mengubah pengaturan tidak memengaruhi pengguna lain.
// =====================================================================================================================
(function(){
const h=T.h;
const ROLE=window.__ROLE==='admin'?'admin':'user';
const LS='tm.notify.v2.'+ROLE;                // pengaturan per peran di browser ini
const CATS=[
  {id:'news',icon:'intel',label:'Berita penting',desc:'Berita kritis & high impact: perang/serangan/krisis, bank sentral, inflasi, tarif (sumber tier-1).'},
  {id:'squawk',icon:'intel',label:'Headline cepat (Squawk)',desc:'Setiap headline baru Walter Bloomberg, FinancialJuice, Bloomberg & kabar kilat — dibacakan seperti squawk box.'},
  {id:'calendar',icon:'macro',label:'Kalender ekonomi',desc:'15 menit sebelum rilis berdampak tinggi/sedang, lalu angka actual vs perkiraan saat rilis.'},
  {id:'rates',icon:'centralbank',label:'Suku bunga bank sentral',desc:'Bank sentral menaikkan atau menurunkan suku bunga (dari berapa ke berapa).'},
  {id:'curve',icon:'centralbank',label:'Yield & kurva obligasi',desc:'Yield 10 tahun bergerak ≥ 10 bp, kurva 2s10s berubah ≥ 15 bp atau berbalik (inverted ↔ normal).'},
  {id:'signal',icon:'signal',label:'Sinyal',desc:'Order limit baru, order terisi, posisi selesai (TP / SL / batal) — 10 METODE & STRATEGI ONE.'},
  {id:'liq',icon:'heatmap',label:'Likuiditas heatmap',desc:'Harga menyapu Key Liquidation Level besar di HEATMAP.'},
  {id:'alert',icon:'star',label:'Price alert (watchlist)',desc:'Alert harga yang Anda pasang di Watchlist tersentuh.',local:true}];
const SERVER=CATS.filter(c=>!c.local).map(c=>c.id);
const CLAB=Object.fromEntries(CATS.map(c=>[c.id,c.label.toUpperCase()]));CLAB.test='UJI';
const LV={high:'TINGGI',medium:'SEDANG',low:'RENDAH',good:'POSITIF'};
const RANK={high:3,good:2,medium:2,low:1};
const MIN_OPTS=[['low','Semua'],['medium','Sedang & tinggi'],['high','Tinggi saja']];
function migrate(){                         // pengaturan versi lama (belum dipisah per peran) -> dipakai SEKALI oleh peran yang pertama membuka
  if(!T.ls||T.ls.get(LS,null))return {};
  const v2=T.ls.get('tm.notify.v2',null),v1=T.ls.get('tm.notify.v1',null);
  try{localStorage.removeItem('tm.notify.v2');localStorage.removeItem('tm.notify.v1')}catch(e){}
  if(v2)return v2;
  return v1?{on:!!v1.on,sound:v1.sound!==false,endpoint:v1.endpoint||null,push:!!v1.push}:{};
}
const st=Object.assign({on:false,kinds:CATS.map(c=>c.id),sound:true,speak:true,rate:1.05,min:'low',bg:true,endpoint:null,push:false},
  migrate(),(T.ls&&T.ls.get(LS,null))||{});
const save=()=>T.ls&&T.ls.set(LS,st);
const seen=new Set();
let since=0,timer=null,reg=null;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

// ---------------------------------------------------------------- suara: nada per tingkat (WebAudio, tanpa berkas)
let actx=null,unlocked=false;
function unlock(){
  try{actx=actx||new (window.AudioContext||window.webkitAudioContext)();if(actx.state==='suspended')actx.resume()}catch(e){}
  if(!unlocked&&'speechSynthesis' in window){try{const u=new SpeechSynthesisUtterance(' ');u.volume=0;speechSynthesis.speak(u)}catch(e){}}
  unlocked=true;hideHint();pump();
}
['pointerdown','keydown','touchstart'].forEach(ev=>document.addEventListener(ev,unlock,{passive:true}));
const TONES={high:[[988,0,'square'],[740,.16,'square'],[988,.32,'square']],medium:[[784,0,'triangle'],[1047,.15,'triangle']],
  low:[[880,0,'sine']],good:[[660,0,'triangle'],[880,.12,'triangle'],[1319,.24,'triangle']]};
function chime(level){                       // -> durasi (ms)
  if(!st.sound)return 0;
  const seq=TONES[level]||TONES.medium;
  try{if(!actx)actx=new (window.AudioContext||window.webkitAudioContext)();if(actx.state==='suspended'){actx.resume();if(actx.state==='suspended'){needGesture();return 0}}
    const t=actx.currentTime+0.02;
    seq.forEach(([f,dt,type])=>{const o=actx.createOscillator(),g=actx.createGain();o.type=type;o.frequency.value=f;
      const pk=type==='square'?0.09:0.2;
      g.gain.setValueAtTime(0.0001,t+dt);g.gain.exponentialRampToValueAtTime(pk,t+dt+0.012);g.gain.exponentialRampToValueAtTime(0.0001,t+dt+0.24);
      o.connect(g).connect(actx.destination);o.start(t+dt);o.stop(t+dt+0.26)});
    return Math.round((seq[seq.length-1][1]+0.3)*1000);
  }catch(e){return 0}
}
// ---------------------------------------------------------------- suara: dibacakan (Web Speech bawaan browser)
let voices=[];
const loadV=()=>{try{voices=speechSynthesis.getVoices()||[]}catch(e){}};
if('speechSynthesis' in window){loadV();try{speechSynthesis.addEventListener('voiceschanged',loadV)}catch(e){}}
function voiceFor(lang){
  const want=lang==='en'?'en':'id';
  const vs=voices.filter(v=>(v.lang||'').toLowerCase().replace('_','-').startsWith(want));
  return vs.find(v=>/google|natural|online|microsoft/i.test(v.name))||vs[0]||null;
}
T.notifyVoiceInfo=()=>{loadV();return {id:!!voiceFor('id'),en:!!voiceFor('en'),supported:'speechSynthesis' in window}};
function speak(text,lang){
  return new Promise(res=>{
    if(!st.speak||!text||!('speechSynthesis' in window))return res();
    let done=false,to=null;const fin=()=>{if(done)return;done=true;clearTimeout(to);res()};
    try{
      const u=new SpeechSynthesisUtterance(text);const v=voiceFor(lang);
      if(v)u.voice=v;u.lang=v?v.lang:(lang==='en'?'en-US':'id-ID');u.rate=st.rate||1.05;
      u.onend=fin;u.onerror=e=>{if(e&&e.error==='not-allowed')needGesture();fin()};
      to=setTimeout(fin,Math.min(40000,3000+text.length*95));
      speechSynthesis.speak(u);
    }catch(e){fin()}
  });
}
// ---------------------------------------------------------------- petunjuk "klik sekali" (browser menahan suara sebelum ada interaksi)
let hint=null;
function needGesture(){
  if(hint||!(st.sound||st.speak))return;
  hint=h('div',{class:'ntf-hint',onclick:unlock},h('span',{html:T.ICONS.bell}),h('span',null,'Klik di mana saja untuk menyalakan suara notifikasi (browser menahan suara sebelum ada klik).'));
  document.body.append(hint);
}
function hideHint(){if(hint){hint.remove();hint=null}}

// ---------------------------------------------------------------- kartu notifikasi berwarna
const stack=h('div',{class:'ntf-stack','aria-live':'polite'});document.body.append(stack);
const hhmm=ts=>new Date((ts||Date.now()/1000)*1000).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
function card(ev){
  const lv=LV[ev.level]?ev.level:'medium';
  const close=()=>{el.classList.remove('in');setTimeout(()=>el.remove(),260)};
  const el=h('div',{class:'ntf '+lv,onclick:e=>{if(e.target.closest('.ntf-x'))return;if(ev.url){const u=new URL(ev.url,location.href);if(u.hash)location.hash=u.hash}close()}},
    h('div',{class:'ntf-h'},h('span',{class:'ntf-lv'},LV[lv]),h('span',{class:'ntf-k'},CLAB[ev.kind]||'NOTIFIKASI'),h('span',{class:'ntf-t'},hhmm(ev.ts)),
      h('button',{class:'ntf-x',title:'Tutup',html:T.ICONS.x,onclick:close})),
    h('b',null,ev.title),ev.body?h('span',null,ev.body):null);
  stack.prepend(el);requestAnimationFrame(()=>el.classList.add('in'));
  [...stack.children].slice(5).forEach(x=>x.remove());
  setTimeout(close,lv==='high'?30000:lv==='low'?12000:18000);
  return el;
}

// ---------------------------------------------------------------- antrean: kartu -> nada -> dibacakan (berurutan)
const Q=[];let busy=false,dropped=0;
const MAXQ=6;
function enqueue(ev){
  Q.push(ev);
  while(Q.length>MAXQ){                     // terlalu banyak menumpuk: buang yang tingkatnya paling rendah (kartu tetap tampil)
    let k=0;Q.forEach((x,i)=>{if((RANK[x.level]||2)<(RANK[Q[k].level]||2))k=i});Q.splice(k,1);dropped++;
  }
  pump();
}
async function pump(){
  if(busy)return;busy=true;
  try{
    while(Q.length){
      const ev=Q.shift();
      if(ev._el)ev._el.classList.add('now');
      const ms=chime(ev.level);if(ms)await sleep(ms+120);
      await speak(ev.say||ev.title,ev.lang);
      if(ev._el)ev._el.classList.remove('now');
      await sleep(260);
      if(!Q.length&&dropped){const n=dropped;dropped=0;await speak(`Ada ${n} notifikasi lain. Lihat kartu notifikasi di layar.`,'id')}
    }
  }finally{busy=false}
}
function pass(ev){
  if(ev.kind==='test')return true;
  if(!st.on)return false;                    // pengguna ini (peran + browser) tidak mengaktifkan: tidak ada kartu / suara
  if(!st.kinds.includes(ev.kind))return false;
  return (RANK[ev.level]||2)>=(RANK[st.min]||1);
}
function handle(ev,{fromPush}={}){
  if(!ev||!ev.id||seen.has(ev.id))return;seen.add(ev.id);
  if(!pass(ev))return;
  const vis=document.visibilityState==='visible';
  if(vis||st.bg){ev._el=card(ev);enqueue(ev)}
  if(!vis&&!st.push&&reg&&'Notification' in window&&Notification.permission==='granted'&&!fromPush){
    // tanpa push (mis. server tanpa pywebpush): tab di latar tetap memunculkan notifikasi Chrome selama website terbuka
    reg.showNotification(ev.title,{body:ev.body||'',tag:ev.id,icon:'/vendor/notify-icon.png',data:{url:ev.url||'/'}}).catch(()=>{});
  }
}
// notifikasi lokal (dibuat di browser, mis. price alert watchlist). Mengembalikan true bila ditangani pusat notifikasi.
T.notifyLocal=ev=>{
  if(!st.on||!st.kinds.includes(ev.kind))return false;
  handle(Object.assign({id:'local-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),ts:Date.now()/1000,lang:'id',level:'medium'},ev));
  return true;
};

// ---------------------------------------------------------------- polling cadangan (halaman terbuka): hanya kejadian baru
async function poll(){
  if(!st.on)return;
  const ks=st.kinds.filter(k=>SERVER.includes(k));if(!ks.length)return;
  try{
    const d=await T.rawFetch('notify/events',{since:since||0,kinds:ks.join(',')},{bg:true});
    if(!since){since=d.now;return}
    since=Math.max(since,d.now-1);
    (d.events||[]).forEach(e=>{since=Math.max(since,e.at);handle(e)});
  }catch(e){}
}
function startPoll(){if(!timer){poll();timer=setInterval(poll,8000)}}
function stopPoll(){clearInterval(timer);timer=null;since=0}
if('serviceWorker' in navigator)navigator.serviceWorker.addEventListener('message',e=>{
  const m=e.data||{};
  if(m.type==='notify')handle(m.event,{fromPush:true});
  else if(m.type==='nav'&&m.url){const u=new URL(m.url,location.href);if(u.hash)location.hash=u.hash}
});

// ---------------------------------------------------------------- aktif / nonaktif
const b64=s=>{s=s.replace(/-/g,'+').replace(/_/g,'/');s+='='.repeat((4-s.length%4)%4);return Uint8Array.from(atob(s),c=>c.charCodeAt(0))};
async function post(path,body){const r=await fetch('/api/'+path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return r.json()}
async function swReg(){
  if(!('serviceWorker' in navigator)||!window.isSecureContext)return null;
  reg=await navigator.serviceWorker.register('/sw.js',{scope:'/'});
  await navigator.serviceWorker.ready;return reg;
}
const pushKinds=()=>st.kinds.filter(k=>SERVER.includes(k));
async function enable(){
  if(!('Notification' in window))throw new Error('Browser ini tidak mendukung notifikasi.');
  unlock();
  const perm=Notification.permission==='granted'?'granted':await Notification.requestPermission();
  if(perm!=='granted')throw new Error(perm==='denied'?'Izin notifikasi diblokir. Buka ikon gembok di samping alamat website → Notifikasi → Izinkan, lalu coba lagi.':'Izin notifikasi belum diberikan.');
  let note=null;st.push=false;
  try{
    await swReg();
    const key=await T.rawFetch('notify/key');
    if(reg&&key.push&&'PushManager' in window){
      let sub=await reg.pushManager.getSubscription();
      const want=b64(key.public);
      if(sub){const cur=sub.options&&sub.options.applicationServerKey?new Uint8Array(sub.options.applicationServerKey):null;
        if(!cur||cur.length!==want.length||cur.some((v,i)=>v!==want[i])){await sub.unsubscribe();sub=null}}
      if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:want});
      const r=await post('notify/subscribe',{subscription:sub.toJSON(),kinds:pushKinds(),min:st.min});
      if(r.ok){st.push=true;st.endpoint=sub.endpoint}else note=r.error;
    }else note=!window.isSecureContext?'Website dibuka lewat http (bukan https/localhost): notifikasi saat website DITUTUP tidak tersedia; selama website terbuka tetap berbunyi, dibacakan & muncul.'
      :!key.push?'Server belum memasang pywebpush: notifikasi saat website DITUTUP belum aktif; selama website terbuka tetap berbunyi, dibacakan & muncul.':null;
  }catch(e){note='Push latar tidak aktif ('+e.message+'); selama website terbuka notifikasi tetap berbunyi, dibacakan & muncul.'}
  st.on=true;save();startPoll();render();
  return note;
}
async function disable(){
  try{if(reg||('serviceWorker' in navigator&&(reg=await navigator.serviceWorker.getRegistration('/')))){const sub=await reg.pushManager.getSubscription();
    if(sub){await post('notify/unsubscribe',{endpoint:sub.endpoint});await sub.unsubscribe()}}}catch(e){}
  st.on=false;st.push=false;st.endpoint=null;save();stopPoll();Q.length=0;try{speechSynthesis.cancel()}catch(e){}render();
}
async function saveKinds(){
  save();
  if(st.on&&st.push&&reg){try{const sub=await reg.pushManager.getSubscription();if(sub)await post('notify/subscribe',{subscription:sub.toJSON(),kinds:pushKinds(),min:st.min})}catch(e){}}
  since=0;render();
}
const SAMPLES=[
  {level:'high',kind:'calendar',title:'Contoh TINGGI · merah',body:'Misal: rilis data berdampak tinggi, suku bunga berubah, posisi kena SL.',say:'Contoh notifikasi tingkat tinggi, warna merah.'},
  {level:'medium',kind:'curve',title:'Contoh SEDANG · kuning',body:'Misal: yield 10 tahun bergerak besar, berita high impact.',say:'Contoh notifikasi tingkat sedang, warna kuning.'},
  {level:'low',kind:'squawk',title:'Contoh RENDAH · biru',body:'Misal: headline cepat biasa.',say:'Contoh notifikasi tingkat rendah, warna biru.'},
  {level:'good',kind:'signal',title:'Contoh POSITIF · hijau',body:'Misal: posisi sinyal mencapai TP.',say:'Contoh notifikasi positif, warna hijau.'}];
async function test(){
  unlock();
  SAMPLES.forEach((s,i)=>handle(Object.assign({id:'test-'+Date.now()+'-'+i,ts:Date.now()/1000,lang:'id'},s,{kind:'test'})));
  if(st.push&&st.endpoint){const r=await post('notify/test',{endpoint:st.endpoint});
    return r.ok?'Contoh 4 tingkat diputar. Uji Chrome juga dikirim (pindah ke tab lain / minimalkan browser untuk melihatnya).':(r.error||'gagal mengirim uji Chrome')}
  return 'Contoh 4 tingkat diputar: nada lalu dibacakan.';
}

// ---------------------------------------------------------------- tampilan: bar dashboard + modal pengaturan
const bars=new Set();
function render(){bars.forEach(b=>{if(!b.isConnected){bars.delete(b);return}b.replaceChildren(...barKids())})}
function barKids(){
  const on=st.on&&(!('Notification' in window)||Notification.permission==='granted');
  const mode=[st.sound?'BUNYI':null,st.speak?'DIBACAKAN':null,st.push?'CHROME':null].filter(Boolean).join(' + ')||'TANPA SUARA';
  return [h('span',{class:'nb-ic'+(on?' on':''),html:T.ICONS.bell}),
    h('b',null,'NOTIFIKASI'),h('span',{class:'nb-st '+(on?'on':'off')},on?'AKTIF · '+mode:'NONAKTIF'),
    h('span',{class:'nb-who',title:'Pengaturan ini hanya untuk Anda: akun '+ROLE.toUpperCase()+' di browser/perangkat ini. Pengguna lain tidak terpengaruh.'},ROLE.toUpperCase()+' · browser ini'),
    on?h('span',{class:'nb-k'},...CATS.filter(k=>st.kinds.includes(k.id)).map(k=>h('i',null,k.label)),st.min!=='low'?h('i',{class:'lvl'},'min. '+(MIN_OPTS.find(m=>m[0]===st.min)||[0,''])[1].toLowerCase()):null)
      :h('span',{class:'nb-k mut'},'Semua update terminal — berita, squawk, kalender, suku bunga, yield/kurva, sinyal, likuiditas, price alert — berbunyi & dibacakan, berwarna menurut tingkat'),
    h('button',{class:'btn'+(on?'':' on'),onclick:open},on?'Atur':'Aktifkan notifikasi')];
}
T.notifyBar=()=>{const b=h('div',{class:'notify-bar'});bars.add(b);b.replaceChildren(...barKids());return b};
function open(){
  const msg=h('div',{class:'nm-msg'});
  const say=(t,kind)=>{msg.className='nm-msg '+(kind||'');msg.textContent=t||''};
  const cards=CATS.map(k=>{const c=h('input',{type:'checkbox',checked:st.kinds.includes(k.id)});
    c.onchange=()=>{st.kinds=c.checked?[...new Set(st.kinds.concat(k.id))]:st.kinds.filter(x=>x!==k.id);lab.classList.toggle('on',c.checked);saveKinds()};
    const lab=h('label',{class:'nm-card'+(st.kinds.includes(k.id)?' on':''),'data-kind':k.id},c,h('span',{class:'nm-ic',html:T.ICONS[k.icon]||T.ICONS.bell}),h('span',{class:'nm-tx'},h('b',null,k.label),h('small',null,k.desc)));return lab});
  const allBtn=h('button',{class:'btn sm',onclick:()=>{st.kinds=CATS.map(c=>c.id);cards.forEach(l=>{l.classList.add('on');l.querySelector('input').checked=true});saveKinds()}},'Pilih semua');
  const lvlSeg=h('div',{class:'nm-seg'},...MIN_OPTS.map(([id,lab])=>h('button',{class:st.min===id?'on':'','data-min':id,onclick:e=>{st.min=id;saveKinds();
    [...lvlSeg.children].forEach(b=>b.classList.toggle('on',b.dataset.min===id))}},lab)));
  const tog=(key,label,hint)=>{const c=h('input',{type:'checkbox',checked:!!st[key]});c.onchange=()=>{st[key]=c.checked;save();render();if(key==='speak'&&!c.checked)try{speechSynthesis.cancel()}catch(e){}};
    return h('label',{class:'nm-snd'},c,h('span',null,label,hint?h('small',null,' — '+hint):null))};
  const rate=h('input',{type:'range',min:'0.8',max:'1.4',step:'0.05',value:String(st.rate||1.05),oninput:e=>{st.rate=+e.target.value;rv.textContent=st.rate.toFixed(2)+'x';save()}});
  const rv=h('span',{class:'mut'},(st.rate||1.05).toFixed(2)+'x');
  const vi=T.notifyVoiceInfo();
  const vnote=!vi.supported?'Browser ini tidak bisa membacakan teks.':(!vi.id?'Suara bahasa Indonesia tidak terpasang di perangkat ini — dibacakan dengan suara bawaan browser (Chrome/Edge biasanya punya suara Indonesia).':'Suara Indonesia & Inggris tersedia.');
  const go=h('button',{class:'btn on'},st.on?'Simpan':'Aktifkan & minta izin');
  go.onclick=async()=>{if(!st.kinds.length){say('Pilih minimal satu jenis notifikasi.','bad');return}
    go.disabled=true;say('Meminta izin browser…');
    try{const note=await enable();say(note||(st.push?'Aktif. Saat website ditutup notifikasi muncul lewat Chrome (selama Chrome berjalan).':'Aktif.'),note?'warn':'ok');
      off.style.display='';tst.style.display='';go.textContent='Simpan'}catch(e){say(e.message,'bad')}go.disabled=false};
  const tst=h('button',{class:'btn',style:{display:st.on?'':'none'},onclick:async()=>{const r=await test();if(r)say(r,'ok')}},'Uji (4 tingkat)');
  const off=h('button',{class:'btn',style:{display:st.on?'':'none'},onclick:async()=>{await disable();say('Notifikasi dimatikan untuk browser ini.','');off.style.display='none';tst.style.display='none';go.textContent='Aktifkan & minta izin'}},'Matikan');
  const legend=h('div',{class:'nm-legend'},...Object.entries(LV).map(([k,v])=>h('span',{class:'ntf-lv '+k},v)),h('small',null,'warna kartu & nada mengikuti tingkat'));
  const box=h('div',{class:'nm'},
    h('div',{class:'nm-intro'},'Satu pengaturan untuk ',h('b',null,'semua update terminal'),' (log informasi tidak ikut). Tiap notifikasi: ',h('b',null,'kartu berwarna → nada → isinya dibacakan'),'. Saat website ditutup: notifikasi Chrome. Pengaturan ini ',h('b',null,'hanya untuk Anda'),' (akun '+ROLE.toUpperCase()+' di browser ini) — pengguna lain tidak ikut aktif dan tidak dikirimi.'),
    legend,
    h('div',{class:'nm-row'},h('b',null,'JENIS'),allBtn),
    h('div',{class:'nm-grid'},...cards),
    h('div',{class:'nm-row'},h('b',null,'TINGKAT MINIMAL'),lvlSeg),
    tog('sound','Bunyi nada notifikasi','nada berbeda tiap tingkat'),
    tog('speak','Bacakan isi notifikasi','misal "Yield 10 tahun AS naik dari 4,12 ke 4,25 persen"'),
    h('div',{class:'nm-rate'},h('span',null,'Kecepatan bacaan'),rate,rv),
    h('div',{class:'mut',style:{fontSize:'11px'}},vnote),
    tog('bg','Tetap dibacakan saat tab terminal di belakang','seperti squawk box'),
    msg,h('div',{class:'nm-act'},go,tst,off));
  const m=T.modal?T.modal('NOTIFIKASI',box,'notifym'):null;
  if(!m){const w=h('div',{class:'tm-modal notifym'},h('div',{class:'tm-box'},box));document.body.append(w)}
}
T.openNotify=open;
T.notifyOff=async()=>{if(st.on)await disable()};       // dipakai LOGOUT: perangkat ini berhenti menerima notifikasi terminal
T.notifyState=()=>({on:st.on,kinds:st.kinds.slice(),sound:st.sound,speak:st.speak,min:st.min});
// Sinkronkan langganan push browser ini dengan pengguna yang SEDANG login: satu browser hanya punya satu langganan push,
// jadi bila admin & user bergantian di browser yang sama, langganan mengikuti pengaturan peran yang login sekarang
// (pengaturan nonaktif -> langganan dicabut, sehingga notifikasi peran lain tidak ikut terkirim ke sesi ini).
async function resync(){
  try{
    if(!('serviceWorker' in navigator)||!window.isSecureContext)return;
    const r0=await navigator.serviceWorker.getRegistration('/');if(r0)reg=r0;
    const sub=reg?await reg.pushManager.getSubscription():null;
    if(!st.on){if(sub){await post('notify/unsubscribe',{endpoint:sub.endpoint});await sub.unsubscribe()}return}
    if(Notification.permission!=='granted')return;
    if(!reg)await swReg();
    if(sub){const r=await post('notify/subscribe',{subscription:sub.toJSON(),kinds:pushKinds(),min:st.min});if(r.ok){st.push=true;st.endpoint=sub.endpoint;save();render()}}
  }catch(e){}
}
T.notifyResync=resync;
// lanjutkan setelah muat ulang: daftarkan ulang service worker & polling bila sebelumnya aktif
if(!st.on)setTimeout(resync,1500);
if(st.on&&'Notification' in window&&Notification.permission==='granted'){
  swReg().then(resync).catch(()=>{});setTimeout(startPoll,2000);
  if((st.sound||st.speak)&&navigator.userActivation&&!navigator.userActivation.hasBeenActive)setTimeout(()=>{if(!unlocked)needGesture()},2500);
}else if(st.on&&'Notification' in window&&Notification.permission==='denied'){st.on=false;st.push=false;save()}
save();
})();
