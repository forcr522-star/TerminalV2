// =====================================================================================================================
// NOTIFIKASI (per browser / per pengguna)
//   Tombol di DASHBOARD -> pilih jenis (likuiditas heatmap, berita high impact, sinyal) -> browser meminta izin.
//   - website terbuka & terlihat: bunyi + kartu notifikasi di halaman
//   - website di latar / ditutup: notifikasi Chrome (Web Push lewat service worker /sw.js)
//   Pengaturan disimpan di browser ini saja; pengguna/perangkat lain tidak ikut aktif.
// =====================================================================================================================
(function(){
const h=T.h;
const LS='tm.notify.v1';
const KINDS=[
  {id:'liq',icon:'heatmap',label:'Likuiditas besar terambil',desc:'Harga menyapu Key Liquidation Level besar di HEATMAP (pair yang dipantau, TF H1).'},
  {id:'news',icon:'intel',label:'Berita high impact',desc:'Semua berita berdampak tinggi: perang/serangan/krisis, bank sentral, inflasi, tarif — termasuk SQUAWK (Walter Bloomberg, FinancialJuice, Bloomberg).'},
  {id:'signal',icon:'signal',label:'Sinyal SIGNAL',desc:'Bot memasang order LIMIT baru, dan saat harga menyentuh entry (order terisi).'}];
const st=Object.assign({on:false,kinds:['news','liq','signal'],sound:true,endpoint:null,push:false},(T.ls&&T.ls.get(LS,{}))||{});
const save=()=>T.ls&&T.ls.set(LS,st);
const seen=new Set();
let since=0,timer=null,reg=null;

// ---- suara per jenis (WebAudio, tanpa berkas)
let actx=null;
const unlock=()=>{try{actx=actx||new (window.AudioContext||window.webkitAudioContext)();if(actx.state==='suspended')actx.resume()}catch(e){}};
['pointerdown','keydown'].forEach(ev=>document.addEventListener(ev,unlock,{once:false,passive:true}));
const TONES={news:[[988,0],[1319,.14]],liq:[[440,0],[660,.1],[880,.2]],signal:[[784,0],[784,.16],[1175,.32]],test:[[880,0],[1175,.12]]};
function chime(kind){
  if(!st.sound)return;
  try{unlock();const t=actx.currentTime;(TONES[kind]||TONES.news).forEach(([f,dt])=>{const o=actx.createOscillator(),g=actx.createGain();o.type='triangle';o.frequency.value=f;
    g.gain.setValueAtTime(0.0001,t+dt);g.gain.exponentialRampToValueAtTime(0.22,t+dt+0.012);g.gain.exponentialRampToValueAtTime(0.0001,t+dt+0.26);
    o.connect(g).connect(actx.destination);o.start(t+dt);o.stop(t+dt+0.28)})}catch(e){}
}
const KLAB={liq:'LIKUIDITAS',news:'HIGH IMPACT',signal:'SINYAL',test:'UJI'};
function handle(ev,{fromPush}={}){
  if(!ev||!ev.id||seen.has(ev.id))return;seen.add(ev.id);
  if(ev.kind!=='test'&&!st.kinds.includes(ev.kind))return;
  if(document.visibilityState==='visible'){
    chime(ev.kind);
    if(T.toast)T.toast('🔔 '+(KLAB[ev.kind]||'NOTIFIKASI')+' · '+ev.title,ev.body||'',ev.level==='high'?'alert':'info',12000);
  }else if(!st.push&&reg&&Notification.permission==='granted'&&!fromPush){
    // tanpa push (mis. server tanpa pywebpush): tab di latar tetap memunculkan notifikasi Chrome selama website terbuka
    reg.showNotification(ev.title,{body:ev.body||'',tag:ev.id,icon:'/vendor/notify-icon.png',data:{url:ev.url||'/'}}).catch(()=>{});
  }
}

// ---- polling cadangan (halaman terbuka): murah, hanya kejadian baru
async function poll(){
  if(!st.on)return;
  try{
    const d=await T.rawFetch('notify/events',{since:since||0,kinds:st.kinds.join(',')},{bg:true});
    if(!since){since=d.now;return}
    since=Math.max(since,d.now-1);
    (d.events||[]).forEach(e=>{since=Math.max(since,e.at);handle(e)});
  }catch(e){}
}
function startPoll(){if(!timer){poll();timer=setInterval(poll,10000)}}
function stopPoll(){clearInterval(timer);timer=null;since=0}
if('serviceWorker' in navigator)navigator.serviceWorker.addEventListener('message',e=>{
  const m=e.data||{};
  if(m.type==='notify')handle(m.event,{fromPush:true});
  else if(m.type==='nav'&&m.url){const u=new URL(m.url,location.href);if(u.hash)location.hash=u.hash}
});

// ---- aktif / nonaktif
const b64=s=>{s=s.replace(/-/g,'+').replace(/_/g,'/');s+='='.repeat((4-s.length%4)%4);return Uint8Array.from(atob(s),c=>c.charCodeAt(0))};
async function post(path,body){const r=await fetch('/api/'+path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return r.json()}
async function swReg(){
  if(!('serviceWorker' in navigator)||!window.isSecureContext)return null;
  reg=await navigator.serviceWorker.register('/sw.js',{scope:'/'});
  await navigator.serviceWorker.ready;return reg;
}
async function enable(){
  if(!('Notification' in window))throw new Error('Browser ini tidak mendukung notifikasi.');
  unlock();
  const perm=Notification.permission==='granted'?'granted':await Notification.requestPermission();
  if(perm!=='granted')throw new Error(perm==='denied'?'Izin notifikasi diblokir. Buka ikon gembok di samping alamat website → Notifikasi → Izinkan, lalu coba lagi.':'Izin notifikasi belum diberikan.');
  let note=null;st.push=false;
  try{
    await swReg();
    const key=await T.rawFetch('notify/key');
    if(reg&&key.push&&'PushManager' in window){
      let sub=await reg.pushManager.getSubscription();
      const want=b64(key.public);
      if(sub){const cur=sub.options&&sub.options.applicationServerKey?new Uint8Array(sub.options.applicationServerKey):null;
        if(!cur||cur.length!==want.length||cur.some((v,i)=>v!==want[i])){await sub.unsubscribe();sub=null}}
      if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:want});
      const r=await post('notify/subscribe',{subscription:sub.toJSON(),kinds:st.kinds});
      if(r.ok){st.push=true;st.endpoint=sub.endpoint}else note=r.error;
    }else note=!window.isSecureContext?'Website dibuka lewat http (bukan https/localhost): notifikasi saat website DITUTUP tidak tersedia; selama website terbuka tetap berbunyi & muncul.'
      :!key.push?'Server belum memasang pywebpush: notifikasi saat website DITUTUP belum aktif; selama website terbuka tetap berbunyi & muncul.':null;
  }catch(e){note='Push latar tidak aktif ('+e.message+'); selama website terbuka notifikasi tetap berbunyi & muncul.'}
  st.on=true;save();startPoll();render();
  return note;
}
async function disable(){
  try{if(reg||('serviceWorker' in navigator&&(reg=await navigator.serviceWorker.getRegistration('/')))){const sub=await reg.pushManager.getSubscription();
    if(sub){await post('notify/unsubscribe',{endpoint:sub.endpoint});await sub.unsubscribe()}}}catch(e){}
  st.on=false;st.push=false;st.endpoint=null;save();stopPoll();render();
}
async function saveKinds(){
  save();
  if(st.on&&st.push&&reg){try{const sub=await reg.pushManager.getSubscription();if(sub)await post('notify/subscribe',{subscription:sub.toJSON(),kinds:st.kinds})}catch(e){}}
  since=0;render();
}
async function test(){
  unlock();
  handle({id:'local-'+Date.now(),kind:'test',title:'Bunyi & kartu notifikasi aktif',body:'Begini notifikasi tampil saat website terbuka.',level:'normal'});
  if(st.push&&st.endpoint){const r=await post('notify/test',{endpoint:st.endpoint});
    return r.ok?'Notifikasi uji dikirim lewat Chrome (pindah ke tab lain / minimalkan browser untuk melihatnya muncul).':(r.error||'gagal mengirim uji')}
  if(reg&&Notification.permission==='granted'){await reg.showNotification('Notifikasi Chrome aktif ✓',{body:'Muncul selama website terbuka.',icon:'/vendor/notify-icon.png'});return null}
  return null;
}

// ---- tampilan: bar dashboard + modal pengaturan
const bars=new Set();
function render(){bars.forEach(b=>{if(!b.isConnected){bars.delete(b);return}b.replaceChildren(...barKids())})}
function barKids(){
  const on=st.on&&(!('Notification' in window)||Notification.permission==='granted');
  return [h('span',{class:'nb-ic'+(on?' on':''),html:T.ICONS.bell}),
    h('b',null,'NOTIFIKASI'),h('span',{class:'nb-st '+(on?'on':'off')},on?(st.push?'AKTIF · CHROME + SUARA':'AKTIF · SAAT WEBSITE TERBUKA'):'NONAKTIF'),
    on?h('span',{class:'nb-k'},...KINDS.filter(k=>st.kinds.includes(k.id)).map(k=>h('i',null,k.label))):h('span',{class:'nb-k mut'},'Dapatkan peringatan likuiditas, berita high impact & sinyal — juga saat website tidak dibuka'),
    h('button',{class:'btn'+(on?'':' on'),onclick:open},on?'Atur':'Aktifkan notifikasi')];
}
T.notifyBar=()=>{const b=h('div',{class:'notify-bar'});bars.add(b);b.replaceChildren(...barKids());return b};
function open(){
  const msg=h('div',{class:'nm-msg'});
  const say=(t,kind)=>{msg.className='nm-msg '+(kind||'');msg.textContent=t||''};
  const cards=KINDS.map(k=>{const c=h('input',{type:'checkbox',checked:st.kinds.includes(k.id)});
    c.onchange=()=>{st.kinds=c.checked?[...new Set(st.kinds.concat(k.id))]:st.kinds.filter(x=>x!==k.id);lab.classList.toggle('on',c.checked);saveKinds()};
    const lab=h('label',{class:'nm-card'+(st.kinds.includes(k.id)?' on':'')},c,h('span',{class:'nm-ic',html:T.ICONS[k.icon]}),h('span',{class:'nm-tx'},h('b',null,k.label),h('small',null,k.desc)));return lab});
  const snd=h('input',{type:'checkbox',checked:st.sound});snd.onchange=()=>{st.sound=snd.checked;save()};
  const go=h('button',{class:'btn on'},st.on?'Simpan':'Aktifkan & minta izin');
  go.onclick=async()=>{if(!st.kinds.length){say('Pilih minimal satu jenis notifikasi.','bad');return}
    go.disabled=true;say('Meminta izin browser…');
    try{const note=await enable();say(note||(st.push?'Aktif. Notifikasi muncul lewat Chrome walau website ditutup (selama Chrome berjalan).':'Aktif.'),note?'warn':'ok');
      off.style.display='';tst.style.display='';go.textContent='Simpan'}catch(e){say(e.message,'bad')}go.disabled=false};
  const tst=h('button',{class:'btn',style:{display:st.on?'':'none'},onclick:async()=>{const r=await test();if(r)say(r,'ok')}},'Kirim notifikasi uji');
  const off=h('button',{class:'btn',style:{display:st.on?'':'none'},onclick:async()=>{await disable();say('Notifikasi dimatikan untuk browser ini.','');off.style.display='none';tst.style.display='none';go.textContent='Aktifkan & minta izin'}},'Matikan');
  const box=h('div',{class:'nm'},
    h('div',{class:'nm-intro'},'Pilih satu atau semua. Saat website terbuka: ',h('b',null,'bunyi + kartu notifikasi'),'. Saat website di latar atau ditutup: ',h('b',null,'notifikasi Chrome'),'. Pengaturan ini hanya untuk browser ini — pengguna lain tidak ikut aktif.'),
    ...cards,
    h('label',{class:'nm-snd'},snd,h('span',null,'Bunyi saat website terbuka (nada berbeda tiap jenis)')),
    msg,h('div',{class:'nm-act'},go,tst,off));
  const m=T.modal?T.modal('NOTIFIKASI',box,'notifym'):null;
  if(!m){const w=h('div',{class:'tm-modal notifym'},h('div',{class:'tm-box'},box));document.body.append(w)}
}
T.openNotify=open;
// lanjutkan setelah muat ulang: daftarkan ulang service worker & polling bila sebelumnya aktif
if(st.on&&'Notification' in window&&Notification.permission==='granted'){swReg().catch(()=>{});setTimeout(startPoll,2000)}
else if(st.on&&'Notification' in window&&Notification.permission==='denied'){st.on=false;st.push=false;save()}
})();
