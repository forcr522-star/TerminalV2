(function(){
const h=T.h;
T.Views.futures=function(root){
  let group='COMMODITIES',sel=null;
  const tabs=T.tabs(['COMMODITIES','INDICES','CURRENCIES','RATES'],group,g=>{group=g;sel=null;go()});
  const body=h('div');root.append(tabs,body);
  function go(){
    T.dispose();
    const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'1.5fr 1fr',height:'calc(100vh - 192px)',minHeight:'440px'}});
    body.replaceChildren(g);
    const L=T.panel('Term Structure',{np:1,bodyStyle:{padding:'6px'}}),R=T.panel('Contracts',{np:1});
    const listP=T.panel(group,{np:1,bodyStyle:{maxHeight:'260px'}});
    const left=h('div',{style:{display:'grid',gridTemplateRows:'1.4fr 1fr',gap:'8px',minHeight:0}},L.el,listP.el);
    g.append(left,R.el);
    T.load(listP.body,T.api('futures/list',{group}),d=>{
      listP.body.append(T.table([{label:'Instrument',left:true,get:r=>r.name},{label:'Price',k:'price',fmt:v=>T.fmt(v)},{label:'Chg',k:'chg',fmt:v=>T.sgn(v),cls:v=>T.cls(v)},{label:'%Chg',k:'pct',fmt:v=>T.pct(v),cls:v=>T.cls(v)},{label:'Vol',k:'volume',fmt:v=>T.big(v)}],d.rows,{onRow:r=>{sel=r;curve()},selected:r=>sel&&r.root===sel.root}));
      if(!sel&&d.rows.length){sel=d.rows[0];curve()}
    });
    function curve(){
      T.charts.forEach(c=>{try{c.dispose()}catch(e){}});T.charts=[];
      L.head.firstChild.textContent='Term Structure: '+sel.name;
      L.body.replaceChildren(h('div',{class:'msg'},'Memuat kurva…'));R.body.replaceChildren();
      T.api('futures/curve',{root:sel.root,exch:sel.exch}).then(d=>{
        L.body.replaceChildren();
        if(!d.rows.length){L.body.append(h('div',{class:'msg'},'Kontrak tidak tersedia'));return}
        const b=T.chartBox();L.body.append(b);
        T.chart(b,{grid:T.grid({left:56}),tooltip:T.tip(),xAxis:T.axis({type:'category',data:d.rows.map(r=>r.label)}),yAxis:T.axis({type:'value',scale:true}),series:[{type:'line',symbol:'circle',symbolSize:5,data:d.rows.map(r=>r.price),color:'#10b981',lineStyle:{width:2}}]});
        R.body.append(T.table([{label:'Month',left:true,k:'label'},{label:'Last',k:'price',fmt:v=>T.fmt(v)},{label:'Chg',k:'chg',fmt:v=>T.sgn(v),cls:v=>T.cls(v)},{label:'Vol',k:'volume',fmt:v=>T.big(v)}],d.rows));
      }).catch(e=>L.body.replaceChildren(h('div',{class:'msg err'},e.message)));
    }
  }
  go();
};
})();
