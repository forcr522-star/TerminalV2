(function(){
const h=T.h;
const MARKETS=[['FX','FX'],['INDEX','INDEX'],['COMMODITY','COMMODITIES'],['CRYPTO','CRYPTO']];
let CATALOG=null;
T.Views.quant=function(root){
  let tab='technical',mkt='FX',asset='AUDCAD',keyLevels=true,rolA='EURUSD',rolB='GBPUSD';
  const tabs=T.tabs([{id:'technical',label:'Technical'},{id:'statistical',label:'Statistical'},{id:'volatility',label:'Volatility'},{id:'correlation',label:'Correlation'},{id:'seasonality',label:'Seasonality'}],tab,t=>{tab=t;go()});
  const ctl=h('div',{class:'row',style:{marginBottom:'8px'}});
  const body=h('div');root.append(tabs,ctl,body);
  async function go(){
    T.dispose();
    if(!CATALOG){try{CATALOG=await T.api('quant/assets')}catch(e){body.replaceChildren(h('div',{class:'msg err'},e.message));return}}
    ctl.replaceChildren();
    if(tab!=='correlation'){
      ctl.append(h('span',{class:'mut'},'MARKET:'),T.select(MARKETS.map(([v,l])=>({v,l})),mkt,v=>{mkt=v;asset=CATALOG[v][0].sym;go()}),h('span',{class:'mut'},'ASSET:'),T.select(CATALOG[mkt].map(a=>({v:a.sym,l:a.sym+' · '+a.name})),asset,v=>{asset=v;go()}));
    }
    ({technical,statistical,volatility,correlation,seasonality}[tab])();
  }
  const load=(fn)=>{const wrap=h('div');body.replaceChildren(wrap);T.load(wrap,T.api('quant/asset',{symbol:asset}),d=>fn(wrap,d))};
  function card(l,v,s,c){return h('div',{class:'kpi'},h('div',{class:'l'},l),h('div',{class:'v '+(c||''),style:{fontSize:'20px'}},v),h('div',{class:'s'},s||''))}
  function technical(){
    load((wrap,d)=>{
      const t=d.technical;
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'3fr 1fr',height:'calc(100vh - 242px)',minHeight:'440px'}});
      const P=T.panel('Price Action · '+d.display,{np:1,bodyStyle:{padding:'4px'}}),S=T.panel('Regime');g.append(P.el,S.el);wrap.append(g);
      const sw=h('button',{class:'btn on',onclick:()=>{keyLevels=!keyLevels;sw.classList.toggle('on',keyLevels);draw()}},'Key levels');P.head.append(sw);
      const box=T.chartBox();P.body.append(box);
      function draw(){
        const c=echarts.getInstanceByDom(box);if(c)c.dispose();
        const ml=keyLevels?{silent:true,symbol:'none',label:{formatter:p=>'Lv '+T.fmt(p.value,4),color:'#9aa3b8',fontSize:9},lineStyle:{color:'#475569',type:'dashed'},data:t.levels.map(v=>({yAxis:v}))}:undefined;
        T.chart(box,{tooltip:T.tip(),legend:{top:0,textStyle:{color:'#8f93a0',fontSize:10}},axisPointer:{link:[{xAxisIndex:'all'}]},
          grid:[{left:56,right:50,top:26,height:'62%'},{left:56,right:50,top:'78%',height:'14%'}],
          xAxis:[T.axis({type:'category',data:t.dates,axisLabel:{show:false}}),T.axis({type:'category',data:t.dates,gridIndex:1})],
          yAxis:[T.axis({type:'value',scale:true,position:'right'}),T.axis({type:'value',gridIndex:1,min:0,max:100,splitLine:{show:false}})],dataZoom:[{type:'inside',xAxisIndex:[0,1]}],
          series:[{name:'Price',type:'line',showSymbol:false,data:t.close,color:'#3b82f6',lineStyle:{width:1.6},markLine:ml},
            {name:'SMA(20)',type:'line',showSymbol:false,data:t.sma20,color:'#94a3b8',lineStyle:{type:'dashed',width:1}},{name:'EMA(20)',type:'line',showSymbol:false,data:t.ema20,color:'#f59e0b',lineStyle:{width:1}},
            {name:'ATR upper',type:'line',showSymbol:false,data:t.upper,color:'#6e1f29',lineStyle:{width:.8}},{name:'ATR lower',type:'line',showSymbol:false,data:t.lower,color:'#0f4a37',lineStyle:{width:.8}},
            {name:'RSI(14)',type:'line',showSymbol:false,data:t.rsi,xAxisIndex:1,yAxisIndex:1,color:'#21c993',lineStyle:{width:1},markLine:{silent:true,symbol:'none',data:[{yAxis:70},{yAxis:30}],lineStyle:{color:'#475569'},label:{show:false}}}]});
      }
      draw();
      const rc=t.regime==='BULLISH'?'#21c993':t.regime==='BEARISH'?'#ff5b6b':'#f0a92e';
      S.body.append(h('div',{class:'mut',style:{fontSize:'9px'}},'MARKET REGIME'),h('div',{class:'big',style:{color:rc,fontSize:'22px'}},t.regime),h('div',{class:'mut'},`Since ${t.since} (${t.run} consecutive days)`),h('div',{class:'mut'},'RSI: '+T.fmt(t.rsi_last,1)),
        h('div',{style:{height:'8px'}}),card('Volatility (ATR)',T.fmt(t.atr,4),'Daily range'),h('div',{style:{height:'6px'}}),card('Momentum (MACD hist)',T.sgn(t.macd,5),'',T.cls(t.macd)),
        h('div',{class:'mut',style:{margin:'10px 0 4px',fontSize:'9px'}},'LEVELS'),T.table([{label:'',left:true,get:r=>r.l},{label:'',k:'v',fmt:v=>v==null?'—':T.fmt(v,4)}],[{l:'SMA (20)',v:t.sma.s20},{l:'SMA (50)',v:t.sma.s50},{l:'SMA (200)',v:t.sma.s200},{l:'Last',v:t.last}]));
    });
  }
  function statistical(){
    load((wrap,d)=>{
      const s=d.statistical;
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'3fr 1fr',marginBottom:'8px'}});
      const A=T.panel('Return Distribution (daily log, 1Y)',{bodyStyle:{height:'340px',padding:'4px'}}),B=T.panel('Distribution Stats');g.append(A.el,B.el);wrap.append(g);
      const b=T.chartBox();A.body.append(b);
      const labels=s.hist.counts.map((_,i)=>((s.hist.edges[i]+s.hist.edges[i+1])/2*100).toFixed(2)+'%');
      T.chart(b,{grid:T.grid(),tooltip:T.tip(),xAxis:T.axis({type:'category',data:labels,axisLabel:{color:'#8a8f9c',fontSize:9}}),yAxis:T.axis({type:'value'}),series:[{type:'bar',data:s.hist.counts,itemStyle:{color:'#10b981'}}]});
      B.body.append(card('Sharpe',T.fmt(s.sharpe),'Annualized',T.cls(s.sharpe)),h('div',{style:{height:'6px'}}),card('Sortino',T.fmt(s.sortino),'Downside-adjusted',T.cls(s.sortino)),h('div',{style:{height:'6px'}}),
        h('div',{class:'kpi'},h('div',{class:'row'},h('span',{class:'mut'},'Skewness'),h('b',{style:{marginLeft:'auto'}},T.sgn(s.skew,3))),h('div',{class:'row'},h('span',{class:'mut'},'Kurtosis'),h('b',{style:{marginLeft:'auto'}},T.fmt(s.kurt,2))),h('div',{class:'row'},h('span',{class:'mut'},'VaR (95%)'),h('b',{class:'dn',style:{marginLeft:'auto'}},T.pct(s.var95*100)))));
      wrap.append(h('div',{class:'panel',style:{padding:'12px'}},h('div',{class:'mut',style:{fontSize:'9px'}},'HURST EXPONENT (MARKET MEMORY)'),h('div',{class:'row'},h('b',{class:'acc',style:{fontSize:'30px'}},s.hurst==null?'—':T.fmt(s.hurst)),h('div',{class:'bar2',style:{flex:1,minWidth:'120px',height:'10px'}},h('i',{style:{width:Math.max(0,Math.min(100,(s.hurst||0)*100))+'%',background:'#10b981'}})),h('span',{class:'mut'},s.hurst_label||'')),
        h('div',{class:'row mut',style:{marginTop:'6px'}},h('span',null,'ANN. RETURN '),h('b',{class:T.cls(s.ann_return)},T.pct(s.ann_return)),h('span',null,'  ANN. VOLATILITY '),h('b',{class:'dn'},T.fmt(s.ann_vol)+'%'))));
    });
  }
  function volatility(){
    load((wrap,d)=>{
      const v=d.volatility;
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'3fr 1fr'}});
      const A=T.panel('Historical Volatility (annualized %)',{bodyStyle:{height:'380px',padding:'4px'}}),B=T.panel('Vol Term Structure');g.append(A.el,B.el);wrap.append(g);
      const b=T.chartBox();A.body.append(b);
      T.chart(b,{grid:T.grid(),tooltip:T.tip(),legend:{top:0,textStyle:{color:'#8f93a0'}},xAxis:T.axis({type:'category',data:v.dates}),yAxis:T.axis({type:'value',scale:true}),series:[{name:'Realized vol (30D)',type:'line',showSymbol:false,data:v.rv30,color:'#ff5b6b',areaStyle:{color:'rgba(255,91,107,.1)'}},{name:'Realized vol (90D)',type:'line',showSymbol:false,data:v.rv90,color:'#a78bfa',lineStyle:{type:'dashed'}}]});
      const all=v.term.flat().filter(x=>x!=null),mx=Math.max(...all,1);
      B.body.append(card('Current volatility (30D)',v.current==null?'—':T.fmt(v.current)+'%','Annualized'),h('div',{class:'mut',style:{margin:'10px 0 4px',fontSize:'9px'}},'TERM STRUCTURE (DAYS)'),
        T.table([{label:'',left:true,get:r=>r.l}].concat(v.windows.map((w,i)=>({label:w+'d',get:r=>r.v[i],html:x=>x==null?'—':`<div class="cell" style="background:rgba(59,130,246,${(.12+.5*x/mx).toFixed(2)})">${T.fmt(x,1)}</div>`}))),v.term.map((row,i)=>({l:v.offsets[i],v:row}))));
    });
  }
  function correlation(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('quant/correlation'),d=>{
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'3fr 1fr',marginBottom:'8px'}});
      const A=T.panel('Asset Correlation Matrix (1Y daily returns)',{bodyStyle:{height:'520px',padding:'4px'}}),B=T.panel('Diversification');g.append(A.el,B.el);wrap.append(g);
      const b=T.chartBox();A.body.append(b);
      const data=[];d.matrix.forEach((row,i)=>row.forEach((v,j)=>data.push([j,i,v])));
      T.chart(b,{tooltip:{backgroundColor:'#07090c',textStyle:{color:'#e6e1d3'},formatter:p=>`${d.names[p.data[1]]} / ${d.names[p.data[0]]}: ${p.data[2]}`},grid:{left:60,right:10,top:10,bottom:60},xAxis:{type:'category',data:d.names,axisLabel:{rotate:60,fontSize:8,color:'#8a8f9c'},splitArea:{show:false}},yAxis:{type:'category',data:d.names,inverse:true,axisLabel:{fontSize:8,color:'#8a8f9c'}},
        visualMap:{min:-1,max:1,show:false,inRange:{color:['#6e1f29','#111827','#0f4a37']}},series:[{type:'heatmap',data,label:{show:d.names.length<=14,fontSize:8,color:'#cbd5e1'},itemStyle:{borderColor:'#07090c',borderWidth:1}}]});
      B.body.append(card('Portfolio diversification score',T.fmt(d.score,1)+'/100','Components correlated'),h('div',{style:{height:'6px'}}),card('Highest correlation',d.highest?T.sgn(d.highest.v):'—',d.highest?d.highest.pair:'','up'),h('div',{style:{height:'6px'}}),card('Lowest correlation',d.lowest?T.sgn(d.lowest.v):'—',d.lowest?d.lowest.pair:'','dn'));
      const R=T.panel('Historical rolling correlation (60D)',{bodyStyle:{height:'300px',padding:'4px'}});
      const names=d.names;
      R.head.append(T.select(names,rolA,v=>{rolA=v;roll()}),T.select(names,rolB,v=>{rolB=v;roll()}));wrap.append(R.el);
      const area=h('div',{style:{height:'100%'}});R.body.append(area);
      function roll(){
        const c=area.firstChild&&echarts.getInstanceByDom(area.firstChild);if(c)c.dispose();
        area.replaceChildren(h('div',{class:'msg'},'Memuat…'));
        T.api('quant/rolling',{a:rolA,b:rolB}).then(x=>{area.replaceChildren();const bb=T.chartBox();area.append(bb);
          T.chart(bb,{grid:T.grid(),tooltip:T.tip(),xAxis:T.axis({type:'category',data:x.dates}),yAxis:T.axis({type:'value',min:-1,max:1}),series:[{type:'line',showSymbol:false,data:x.values,color:'#22d3ee',markLine:{silent:true,symbol:'none',data:[{yAxis:0}],lineStyle:{color:'#475569'},label:{show:false}}}]})}).catch(e=>area.replaceChildren(h('div',{class:'msg err'},e.message)));
      }
      roll();
    });
  }
  function seasonality(){
    load((wrap,d)=>{
      const s=d.seasonality;
      const M=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],D=['MON','TUE','WED','THU','FRI'];
      const top=h('div',{class:'grid resp',style:{gridTemplateColumns:'2fr 1fr',marginBottom:'8px'}});
      const A=T.panel('Monthly Seasonality Heatmap',{np:1}),B=T.panel('Day of Week Bias',{np:1,bodyStyle:{height:'230px',padding:'4px'}});top.append(A.el,B.el);wrap.append(top);
      const mx=Math.max(.01,...s.months.filter(v=>v!=null).map(Math.abs));
      A.body.append(h('div',{class:'grid',style:{gridTemplateColumns:'repeat(6,1fr)',gap:'6px',padding:'10px'}},...M.map((m,i)=>h('div',{class:'cell',style:{background:T.heat(s.months[i],mx),padding:'12px 4px'}},h('div',{class:'mut',style:{fontSize:'10px'}},m),h('b',{class:T.cls(s.months[i])},T.pct(s.months[i]))))));
      const b=T.chartBox();B.body.append(b);
      T.chart(b,{grid:{left:44,right:16,top:10,bottom:24},tooltip:T.tip({trigger:'axis'}),xAxis:T.axis({type:'category',data:D}),yAxis:T.axis({type:'value',axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),series:[{type:'bar',data:s.dow.map(v=>({value:v,itemStyle:{color:v>=0?'#21c993':'#ff5b6b'}}))}]});
      const bot=h('div',{class:'grid resp',style:{gridTemplateColumns:'2fr 1fr'}});
      const C=T.panel('Seasonal Model (cumulative average daily return by day of year)',{bodyStyle:{height:'300px',padding:'4px'}}),E=T.panel('Seasonal Edge');bot.append(C.el,E.el);wrap.append(bot);
      const c=T.chartBox();C.body.append(c);
      T.chart(c,{grid:T.grid(),tooltip:T.tip(),xAxis:T.axis({type:'category',data:s.model.map((_,i)=>i+1),axisLabel:{show:false}}),yAxis:T.axis({type:'value',axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),series:[{type:'line',showSymbol:false,data:s.model,color:'#f59e0b',areaStyle:{color:'rgba(245,158,11,.12)'}}]});
      E.body.append(s.best?h('div',{class:'kpi',style:{borderColor:'#0f4a37'}},h('div',{class:'l'},'Best month'),h('div',{class:'v up'},s.best.m+' '+T.pct(s.best.v))):null,h('div',{style:{height:'6px'}}),s.worst?h('div',{class:'kpi',style:{borderColor:'#6e1f29'}},h('div',{class:'l'},'Worst month'),h('div',{class:'v dn'},s.worst.m+' '+T.pct(s.worst.v))):null);
    });
  }
  go();
};
})();
