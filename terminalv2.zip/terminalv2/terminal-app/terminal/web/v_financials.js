(function(){
const h=T.h;
T.Views.financials=function(root){
  const S=T.mem('fin',{ticker:'AAPL',stab:'income'});
  let ticker=T.pendingTicker||S.ticker,stab=S.stab,keyOnly=false,raw=false,view='fin';T.pendingTicker=null;
  // <form>: tombol Go/Enter di semua keyboard (termasuk Android yang tidak mengirim key==='Enter') memicu submit.
  const bar=h('form',{class:'row',style:{marginBottom:'8px'},autocomplete:'off'});
  const inp=h('input',{class:'in',value:ticker,enterkeyhint:'go',autocapitalize:'characters',autocomplete:'off',autocorrect:'off',spellcheck:'false',style:{width:'150px'}});
  let lastGo=0;
  const go=sym=>{
    const now=Date.now();if(now-lastGo<300)return;lastGo=now;
    ticker=(sym||inp.value).trim().toUpperCase();if(!ticker)return;
    inp.value=ticker;S.ticker=ticker;inp.blur();load();
  };
  bar.addEventListener('submit',e=>{e.preventDefault();go()});
  const btn=h('button',{class:'btn',type:'submit'},'Load');
  // Di layar sentuh, ketukan pertama menutup keyboard dan menggeser tata letak sehingga 'click' bisa hilang.
  // touchend tetap terkirim ke tombol tempat sentuhan dimulai.
  btn.addEventListener('touchend',e=>{e.preventDefault();go()},{passive:false});
  bar.append(h('span',{class:'mut'},'TICKER:'),inp,btn,
    ...['AAPL','MSFT','NVDA','BBCA.JK','BBRI.JK','TLKM.JK','ASII.JK'].map(t=>{const c=h('span',{class:'chip',onclick:()=>go(t)},t);c.addEventListener('touchend',e=>{e.preventDefault();go(t)},{passive:false});return c}));
  const body=h('div');root.append(bar,body);
  const KEY=['Total Revenue','Gross Profit','Operating Income','EBITDA','Net Income','Diluted EPS','Total Assets','Total Debt','Stockholders Equity','Operating Cash Flow','Free Cash Flow','Cash And Cash Equivalents','Common Stock Equity','Capital Expenditure'];
  function load(){
    T.dispose();
    T.load(body,T.api('financials',{ticker}),d=>{
      const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'minmax(260px,.8fr) 2fr',marginBottom:'8px'}});
      const L=T.panel('Profile',{bodyStyle:{maxHeight:'420px'}}),R=T.panel('',{np:1,bodyStyle:{height:'420px',padding:'4px'}});
      g.append(L.el,R.el);body.append(g);
      const m=d.metrics,a=d.analyst;
      L.body.append(h('div',{style:{fontSize:'15px',fontWeight:700}},d.profile.name),h('div',{class:'row',style:{margin:'4px 0'}},d.profile.sector?T.badge(d.profile.sector.toUpperCase(),'TAG'):null,d.profile.industry?T.badge(d.profile.industry.toUpperCase(),'TAG'):null),
        h('div',{class:'txt mut',style:{maxHeight:'110px',overflow:'auto',fontSize:'10px'}},d.profile.summary),
        h('div',{class:'grid',style:{gridTemplateColumns:'1fr 1fr',margin:'10px 0'}},...[['Market cap',T.big(m.market_cap)],['Enterprise value',T.big(m.ev)],['P/E (TTM)',T.fmt(m.pe,1)],['P/B',T.fmt(m.pb,1)],['Insiders hold',m.insiders==null?'—':T.fmt(m.insiders*100,1)+'%'],['Institutions hold',m.institutions==null?'—':T.fmt(m.institutions*100,1)+'%']].map(([l,v])=>h('div',null,h('div',{class:'mut',style:{fontSize:'9px'}},l.toUpperCase()),h('b',null,v)))),
        h('div',{class:'mut',style:{fontSize:'9px'}},'ANALYST ESTIMATES'),h('div',{class:'row'},h('b',{class:'up',style:{fontSize:'18px'}},a.target==null?'—':T.fmt(a.target)),h('span',{class:'mut'},'target mean'),h('span',{class:'badge b-BULL'},a.rec||'—')),
        h('div',{class:'mut',style:{fontSize:'10px'}},`Low ${T.fmt(a.low)} · High ${T.fmt(a.high)} · ${a.count||'—'} analysts`),
        h('div',{class:'mut',style:{fontSize:'9px',margin:'10px 0 4px'}},'LATEST INSIDER TRADES'),
        d.insiders.length?T.table([{label:'Insider',left:true,get:r=>r.name,cls:()=>'wrap'},{label:'Shares',k:'shares',fmt:v=>T.big(v)},{label:'Date',k:'date'}],d.insiders):h('div',{class:'mut'},'Tidak ada data'));
      const vt=T.tabs([{id:'fin',label:'Financials'},{id:'price',label:'Price'}],view,v=>{view=v;drawChart()},'sm');vt.style.margin='0';R.head.replaceChildren(vt);
      const area=h('div',{style:{width:'100%',height:'100%'}});R.body.append(area);
      function drawChart(){
        T.charts.forEach(c=>{try{c.dispose()}catch(e){}});T.charts=[];
        const b=T.chartBox();area.replaceChildren(b);
        if(view==='price')T.chart(b,{grid:T.grid(),tooltip:T.tip(),xAxis:T.axis({type:'category',data:d.price.map(p=>new Date(p.t).toISOString().slice(0,10))}),yAxis:T.axis({type:'value',scale:true}),series:[{type:'line',showSymbol:false,data:d.price.map(p=>p.c),lineStyle:{color:'#ef4444',width:1.5},areaStyle:{color:'rgba(239,68,68,.1)'}}]});
        else T.chart(b,{grid:{left:56,right:10,top:26,bottom:24},tooltip:T.tip(),legend:{top:0,textStyle:{color:'#8b93a7'}},xAxis:T.axis({type:'category',data:d.chart.cols}),yAxis:T.axis({type:'value',axisLabel:{formatter:v=>T.big(v),color:'#7d8498'}}),
          series:[{name:'Revenue',type:'bar',data:d.chart.revenue,itemStyle:{color:'#10b981'}},{name:'Net Income',type:'bar',data:d.chart.net,itemStyle:{color:'#3b82f6'}}]});
      }
      drawChart();
      const S=T.panel('',{np:1,bodyStyle:{maxHeight:'520px'}});body.append(S.el);
      const st=T.tabs([{id:'income',label:'Income Statement'},{id:'balance',label:'Balance Sheet'},{id:'cashflow',label:'Cash Flow'}],stab,s=>{stab=S.stab=s;drawT()},'sm');st.style.margin='0';
      const k=h('button',{class:'btn'+(keyOnly?' on':''),onclick:()=>{keyOnly=!keyOnly;k.classList.toggle('on',keyOnly);drawT()}},'Key metrics'),
        r=h('button',{class:'btn'+(raw?' on':''),onclick:()=>{raw=!raw;r.classList.toggle('on',raw);drawT()}},'Raw values');
      S.head.replaceChildren(st,h('span',{class:'sp'}),k,r);
      function drawT(){
        const s=d[stab];let rows=s.rows;
        if(keyOnly)rows=rows.filter(x=>KEY.includes(x.metric));
        const cols=[{label:'Metric',left:true,get:x=>x.metric,cls:()=>'wrap'}].concat(s.cols.map((c,i)=>({label:c,get:x=>x.values[i],fmt:v=>v==null?'—':(raw?T.fmt(v,Math.abs(v)<100?3:0):T.big(v))}))).concat([{label:rows[0]&&rows[0].basis==='yoy'?'YoY%':'QoQ%',k:'change',fmt:v=>v==null?'—':T.pct(v,1),cls:v=>T.cls(v)}]);
        S.body.replaceChildren(rows.length?T.table(cols,rows):h('div',{class:'msg'},'Data laporan tidak tersedia'));
      }
      drawT();
    });
  }
  load();
};
})();
