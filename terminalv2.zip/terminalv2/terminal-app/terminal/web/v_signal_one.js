(function(){
// Menu SIGNAL saat STRATEGI ONE aktif ("ZONA + STRUKTUR + HARMONIC", dokumen aturan v2.0).
// Board (admin & user): list pair, chart live, order E1/E2. Admin: + gambar zona/likuiditas/struktur di chart, panel setup,
// daftar cek keputusan (Bagian 21) dan status filter terminal. INSIDE/ANALISIS (admin): 6 kartu tahapan analisa.
const h=T.h;
const f=(v,nd)=>v==null||isNaN(v)?'—':Number(v).toFixed(nd);
const sgnR=v=>v==null||isNaN(v)?'—':(v>0?'+':'')+Number(v).toFixed(2)+'R';
const p2=n=>String(n).padStart(2,'0');
const tfmt=(ts,min)=>{if(!ts)return '—';const d=new Date(ts*1000);return min>=1440?`${d.getFullYear()}-${p2(d.getMonth()+1)}-${p2(d.getDate())}`:`${p2(d.getMonth()+1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}`};
const TYPE_TXT={A:'A · Koreksi ABC di zona',B:'B · BOS lalu retest',C:'C · Harmonic XABCD',D:'D · Liquidity sweep',E:'E · Rencana dua arah'};
const ST_TXT={PENDING:'Menunggu E1/E2',OPEN:'Berjalan',TP2:'TP2 tercapai',TP1:'TP1 lalu breakeven',SL:'Kena SL',CANCEL:'Dibatalkan',EXPIRED:'Kedaluwarsa',MISSED:'TP1 lebih dulu'};
const kill=c=>{if(c){try{c._ro&&c._ro.disconnect();c.dispose()}catch(e){}}};
async function postControl(body){
  const r=await fetch('/api/signal/control',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  if(r.status===401){location.reload();throw new Error('Sesi berakhir')}
  let j={};try{j=await r.json()}catch(e){}
  if(!r.ok||j.error)throw new Error(j.error||('HTTP '+r.status));
  return j.state;
}
T.rerenderSignal=s=>{T.state.sigStrategy=s;window.dispatchEvent(new HashChangeEvent('hashchange'))};
// Tombol pilihan strategi (dipakai juga tampilan 10 metode)
T.strategySwitch=(cur,onErr)=>h('div',{class:'sg-strat',title:'Pilih strategi analisa bot. Keduanya menganalisa semua pair terpilih; filter berita, volume, quant & risiko tetap jalan.'},
  h('span',{class:'lab'},'STRATEGI'),
  ...[['multi','10 METODE'],['one','STRATEGI ONE']].map(([id,lab])=>h('button',{class:id===cur?'on':'','data-strategy':id,onclick:async()=>{
    if(id===cur)return;
    try{await postControl({strategy:id});T.rerenderSignal(id)}catch(e){onErr&&onErr(e.message)}}},lab)));

// ------------------------------------------------------------------ gambar analisa ONE di atas chart (echarts markArea/markLine)
function overlays(one,times,step,nCat,nd){
  const areas=[],lines=[],pts=[];
  if(!one)return {areas,lines,pts};
  const n=times.length;
  const idx=ts=>{if(ts==null)return null;if(ts<times[0])return 0;if(ts>times[n-1])return Math.min(nCat-1,n-1+Math.max(1,Math.round((ts-times[n-1])/step)));for(let i=0;i<n;i++)if(times[i]>=ts)return i;return n-1};
  const right=nCat-1;
  (one.zones||[]).forEach(z=>{
    if(z.base_first_ts==null)return;
    const x0=idx(z.base_first_ts),x1=z.ended_ts?idx(z.ended_ts):right;
    if(x1<=0)return;
    const dem=z.dir==='DEMAND',dead=z.state==='BROKEN'||z.state==='EXPIRED';
    const a=dead?0.05:z.state==='WEAK'||z.state==='MITIGATED'?0.08:0.13;
    const col=dem?'33,201,147':'255,91,107';
    const bs={color:`rgba(${col},${a})`,borderColor:`rgba(${col},${dead?0.25:0.6})`,borderWidth:1,borderType:z.is_flip?'dashed':'solid'};
    areas.push([{coord:[Math.max(0,x0),z.wick_top],itemStyle:bs,label:{show:!dead,position:'insideTopLeft',formatter:(dem?'DEMAND':'SUPPLY')+(z.is_flip?' FLIP':'')+' · '+z.state+(z.validated?' ✓':''),color:`rgba(${col},.95)`,fontSize:9}},{coord:[x1,z.wick_bottom]}]);
    areas.push([{coord:[Math.max(0,x0),z.body_top],itemStyle:{color:`rgba(${col},${a+0.07})`}},{coord:[x1,z.body_bottom]}]);
  });
  (one.liquidity||[]).forEach(l=>{
    const x0=idx(l.first_ts||l.born_ts),x1=l.ended_ts?idx(l.ended_ts):right;
    const lab=(l.kind==='RANGE'?'RANGE ':'')+(l.dir==='HIGHS'?'EQH':'EQL')+(l.state==='SWEPT'?' · SWEPT':l.state==='BROKEN'?' · BROKEN':'');
    lines.push([{coord:[x0,l.price],lineStyle:{color:l.state==='ACTIVE'?'#f0a92e':'#7c6a45',type:'dotted',width:1.2},label:{show:true,position:'insideEndTop',formatter:lab,color:'#f0a92e',fontSize:9}},{coord:[x1,l.price]}]);
  });
  const st=one.structure||{};
  (st.bos||[]).forEach(b=>{
    const x0=idx(b.swing_ts),x1=idx(b.ts);if(x1==null||x1<=0)return;
    lines.push([{coord:[x0,b.level],lineStyle:{color:b.dir==='BULL'?'#5eead4':'#fda4af',type:'dashed',width:1},label:{show:true,position:'middle',formatter:b.choch?'CHoCH':'BOS',color:b.dir==='BULL'?'#5eead4':'#fda4af',fontSize:9}},{coord:[x1,b.level]}]);
  });
  (st.pivots||[]).forEach(p=>{const x=idx(p.ts);if(x!=null&&p.ts>=times[0])pts.push([x,p.price,p.type])});
  if(one.range&&one.range.first_ts){
    areas.push([{coord:[idx(one.range.first_ts),one.range.top],itemStyle:{color:'rgba(240,169,46,.04)',borderColor:'rgba(240,169,46,.35)',borderWidth:1,borderType:'dotted'}},{coord:[idx(one.range.last_ts),one.range.bottom]}]);
  }
  return {areas,lines,pts};
}
function setupLines(o,times,step,nCat,nd,lines,areas){
  if(!o)return;
  const n=times.length;
  const idx=ts=>{if(ts==null)return n-1;if(ts>times[n-1])return Math.min(nCat-1,n-1+Math.max(1,Math.round((ts-times[n-1])/step)));for(let i=0;i<n;i++)if(times[i]>=ts)return i;return n-1};
  const x0=Math.min(nCat-2,idx(o.issued||o.created_ts)),x1=nCat-1;
  const L=(y,color,type,text)=>{if(y==null)return;lines.push([{coord:[x0,y],lineStyle:{color,type,width:1.4},label:{show:true,position:'end',formatter:text,color,fontSize:10,backgroundColor:'#07090ccc',padding:[1,4]}},{coord:[x1,y]}])};
  areas.push([{coord:[x0,o.E1],itemStyle:{color:'rgba(255,91,107,.16)'}},{coord:[x1,o.SL]}]);
  areas.push([{coord:[x0,o.E1],itemStyle:{color:'rgba(33,201,147,.10)'}},{coord:[x1,o.TP2]}]);
  const k=(o.side==='LONG'||o.side==='BUY')?'BUY':'SELL';
  L(o.E1,'#60a5fa','solid',`${k} E1 ${f(o.E1,nd)}`);L(o.E2,'#60a5fa','dashed',`E2 ${f(o.E2,nd)}`);
  L(o.SL,'#ff5b6b','solid',`SL ${f(o.SL,nd)}`);L(o.TP1,'#21c993','solid',`TP1 ${f(o.TP1,nd)}`);L(o.TP2,'#21c993','dashed',`TP2 ${f(o.TP2,nd)}${o.rr_final?' ('+f(o.rr_final,2)+'R)':''}`);
  if(o.tp1_done&&o.sl_now!=null&&o.sl_now!==o.SL)L(o.sl_now,'#f59e0b','dashed',`SL → ${f(o.sl_now,nd)} (BE)`);
}
function chartOption(ch,one,admin){
  const n=ch.candles.length,pad=36,nd=ch.digits,step=ch.minutes*60;
  const times=ch.candles.map(c=>c[0]);
  const cats=ch.candles.map(c=>tfmt(c[0],ch.minutes));for(let i=0;i<pad;i++)cats.push('');
  const k=ch.candles.map(c=>[c[1],c[4],c[3],c[2]]);
  const ov=admin?overlays(one,times,step,n+pad,nd):{areas:[],lines:[],pts:[]};
  const o=ch.order||(admin&&one&&one.setup?Object.assign({},one.setup,{issued:one.setup.created_ts}):null);
  setupLines(o,times,step,n+pad,nd,ov.lines,ov.areas);
  const piv=new Array(n+pad).fill(null);ov.pts.forEach(([x,y])=>{if(x>=0&&x<n+pad)piv[x]=y});
  const priceLine={yAxis:ch.price,lineStyle:{color:'#94a3b8',type:'dotted',width:1},label:{show:true,position:'insideEndTop',formatter:f(ch.price,nd),color:'#e2e8f0',fontSize:10,backgroundColor:'#334155',padding:[1,4]}};
  const sv=Math.max(0,n-120),ev=n+pad-1;
  const win=(a,b)=>{let lo=Infinity,hi=-Infinity;for(let i=Math.max(0,Math.floor(a));i<=Math.min(n-1,Math.ceil(b));i++){lo=Math.min(lo,ch.candles[i][3]);hi=Math.max(hi,ch.candles[i][2])}
    if(o)[o.E1,o.E2,o.SL,o.TP1,o.TP2].forEach(v=>{if(v!=null){lo=Math.min(lo,v);hi=Math.max(hi,v)}});
    if(!isFinite(lo))return {};const pd=(hi-lo)*0.06||Math.abs(lo)*0.001;return {min:lo-pd,max:hi+pd}};
  const opt={animation:false,grid:{left:8,right:92,top:28,bottom:26},
    tooltip:{trigger:'axis',axisPointer:{type:'cross',lineStyle:{color:'#34404f'}},backgroundColor:'#07090c',borderColor:'#243041',textStyle:{color:'#e6e1d3',fontSize:11},
      formatter:ps=>{const c=ch.candles[ps[0].dataIndex];if(!c)return '';return `${tfmt(c[0],ch.minutes)}<br>O ${f(c[1],nd)} &nbsp; H ${f(c[2],nd)}<br>L ${f(c[3],nd)} &nbsp; C ${f(c[4],nd)}`}},
    xAxis:{type:'category',data:cats,boundaryGap:true,axisLine:{lineStyle:{color:'#243041'}},axisTick:{show:false},axisLabel:{color:'#8a8f9c',fontSize:9},splitLine:{show:false}},
    yAxis:Object.assign({type:'value',position:'right',scale:true,axisLabel:{formatter:v=>Number(v).toFixed(nd),color:'#8a8f9c',fontSize:10},axisLine:{show:false},splitLine:{lineStyle:{color:'#141a23'}}},win(sv,ev)),
    dataZoom:[{type:'inside',startValue:sv,endValue:ev,filterMode:'none'}],
    series:[{type:'candlestick',data:k,itemStyle:{color:'#21c993',color0:'#ff5b6b',borderColor:'#21c993',borderColor0:'#ff5b6b'},
        markArea:{silent:true,animation:false,data:ov.areas},markLine:{silent:true,symbol:'none',animation:false,data:[priceLine].concat(ov.lines)}},
      {type:'line',data:piv,connectNulls:true,symbol:'circle',symbolSize:4,lineStyle:{color:'#8b93a7',width:1,type:'dashed',opacity:.7},itemStyle:{color:'#c9cfdb'},silent:true,z:3}]};
  return {opt,win};
}

// ====================================================================================== BOARD
function board(root,admin){
  const g=T.gen;
  const S=T.mem('signal',{sym:null,tab:'open'});
  let data=null,ctl=null,det=null,ec=null,curKey='',zoomed=false,msg='';
  const top=h('div',{class:'sg-top'});
  const listPb=h('div',{class:'pb'});
  const listPanel=h('div',{class:'panel sg-list'},h('div',{class:'ph'},'LIST PAIR · STRATEGI ONE'),listPb);
  const chead=h('div',{class:'sg-chead'});
  const cmsg=h('div',{class:'msg',style:{display:'none'}});
  const ctag=h('div',{class:'sg-ctag'});
  const cdiv=h('div',{class:'sg-cc',style:{display:'none'}});
  const cbox=h('div',{class:'sg-cbox'},cdiv,ctag,cmsg);
  const chartPanel=h('div',{class:'panel sg-chart'},h('div',{class:'ph'},'CHART · ZONA + STRUKTUR + HARMONIC'),h('div',{class:'pb'},chead,cbox));
  const sidePb=h('div',{class:'pb'});
  const side=h('div',{class:'panel one-side'},h('div',{class:'ph'},'SETUP · CEK KEPUTUSAN · FILTER'),sidePb);
  const tabs=h('div',{class:'sg-tabs'});
  const ordPb=h('div',{class:'pb np'});
  const ordPanel=h('div',{class:'panel sg-orders'},ordPb);
  root.append(h('div',{class:'sg one'+(admin?'':' user')},top,listPanel,chartPanel,admin?side:null,tabs,ordPanel));

  async function toggle(body){try{msg='';await postControl(body);ctl=await T.rawFetch('signal/control');drawTop();await refresh()}catch(e){msg=e.message;drawTop()}}
  function drawTop(){
    if(!admin||!ctl)return;
    top.replaceChildren(
      T.strategySwitch('one',m=>{msg=m;drawTop()}),
      h('button',{class:'sg-btn '+(ctl.on?'on':'off'),title:'ON: bot menganalisa semua pair terpilih dengan strategi ONE. OFF: tidak ada analisa & setup baru (order berjalan tetap dipantau).',onclick:()=>toggle({on:!ctl.on})},'SINYAL: '+(ctl.on?'ON':'OFF')),
      h('button',{class:'sg-btn go',onclick:()=>{location.hash='#signal/inside'}},'INSIDE/ANALISIS'),
      h('span',{class:'mut'},ctl.mode_label+' · '+ctl.pairs.length+' pair · 2 limit (E1/E2) · TP1 → SL ke rata-rata entry + 0,05 ATR (aturan strategi)'+(ctl.mode!=='scalp'?' · dokumen merancang strategi ini untuk M5 (SCALPING)':'')),
      ...(msg?[h('span',{class:'dn'},msg)]:[]));
  }
  function pick(sym){S.sym=sym;zoomed=false;curKey='';det=null;if(data){data.symbol=sym;drawList()}refresh()}
  function drawList(){
    if(!data)return;
    const ov={};if(ctl)ctl.overview.forEach(o=>ov[o.sym]=o);
    if(!data.pairs.length){listPb.replaceChildren(h('div',{class:'sg-empty'},'Belum ada pair yang dipilih untuk dianalisa.'));return}
    listPb.replaceChildren(...data.pairs.map(p=>{
      const o=ov[p.sym];
      const dom=admin&&o&&o.fresh?o.dom:'';
      const tag=p.open?h('span',{class:'sg-tag '+p.side},(p.type||'')+' '+p.side):p.limit?h('span',{class:'sg-tag LMT'},(p.type||'')+' LMT'):null;
      return h('div',{class:'sg-row'+(p.sym===data.symbol?' sel':''),'data-sym':p.sym,onclick:()=>pick(p.sym),title:o&&o.reason?o.reason:p.name},
        admin?h('i',{class:'sg-dot '+dom}):h('span'),
        h('div',{style:{minWidth:0}},h('div',{class:'s'},p.sym,tag),h('div',{class:'n'},admin&&o&&o.fresh?('tren '+(o.trend||'—')+(o.one?' · setup '+o.one.type:'')):p.name)),
        h('div',{class:'p'},f(p.price,p.digits),h('small',{class:T.cls(p.pct)},T.pct(p.pct))));
    }));
  }
  function drawChart(){
    const ch=data&&data.chart;
    if(!ch){cdiv.style.display='none';cmsg.style.display='';ctag.replaceChildren();cmsg.textContent=data&&data.chart_error?'Chart tidak tersedia: '+data.chart_error:(data&&!data.pairs.length?'Belum ada pair yang dipilih.':'Memuat chart…');chead.replaceChildren();return}
    cmsg.style.display='none';cdiv.style.display='';
    const last=ch.candles[ch.candles.length-1],chg=ch.prev?(ch.price-ch.prev)/ch.prev*100:null;
    const one=det&&det.symbol===ch.symbol&&det.one?det.one:null;
    chead.replaceChildren(h('b',null,ch.symbol),h('span',{class:'mut'},ch.name+' · '+ch.tf),h('span',{class:'live'},'● LIVE'),h('span',{class:'px '+T.cls(chg)},f(ch.price,ch.digits)),
      h('span',{class:'mut'},'O '+f(last[1],ch.digits)+'  H '+f(last[2],ch.digits)+'  L '+f(last[3],ch.digits)+'  C '+f(last[4],ch.digits)),
      admin&&one?h('span',{class:'one-trend '+(one.structure.trend==='BULL'?'up':one.structure.trend==='BEAR'?'dn':'mut')},'TREN '+one.structure.trend):null);
    const o=ch.order;
    ctag.replaceChildren(...(o?[h('span',{class:'badge '+(o.side==='LONG'?'b-BULLISH':'b-BEARISH')},'SETUP '+o.type+' · '+o.kind),
      h('span',{class:'mut'},o.status==='PENDING'?'menunggu harga ke E1/E2':'posisi berjalan · '+sgnR(o.r)+(o.tp1_done?' · TP1 tercapai, SL di BE':''))]:[h('span',{class:'mut'},'Belum ada setup aktif untuk pair ini')]));
    const key=ch.symbol+'|'+ch.tf;
    const b=chartOption(ch,one,admin);
    if(!ec||key!==curKey){
      kill(ec);ec=null;
      zoomed=false;curKey=key;ec=T.chart(cdiv,b.opt);
      ec.on('datazoom',()=>{zoomed=true;try{const z=ec.getOption().dataZoom[0];const cur=data&&data.chart;if(!cur)return;ec.setOption({yAxis:chartOption(cur,one,admin).win(z.startValue,z.endValue)})}catch(e){}});
    }else{
      const up={series:b.opt.series,xAxis:b.opt.xAxis,yAxis:b.opt.yAxis};
      if(!zoomed)up.dataZoom=b.opt.dataZoom;else{try{const z=ec.getOption().dataZoom[0];up.yAxis=Object.assign({},b.opt.yAxis,b.win(z.startValue,z.endValue))}catch(e){}}
      ec.setOption(up,{replaceMerge:['series']});
    }
  }
  // ---------------------------------------------------------------- panel samping (admin)
  function drawSide(){
    if(!admin)return;
    if(!det){sidePb.replaceChildren(h('div',{class:'sg-empty'},'Memuat analisa…'));return}
    if(!det.ready){sidePb.replaceChildren(h('div',{class:'sg-empty'},det.error?'Analisa gagal: '+det.error:(det.on?'Menunggu analisa pertama '+det.symbol+'…':'SINYAL OFF: bot tidak menganalisa.')));return}
    if(det.result_strategy!=='one'){sidePb.replaceChildren(h('div',{class:'sg-empty'},'Menunggu analisa strategi ONE untuk '+det.symbol+'…'));return}
    sidePb.replaceChildren(...sideKids(det,true));
  }
  // ---------------------------------------------------------------- order
  const pxr=(v,r,nd,col)=>h('span',null,f(v,nd),r==null?'':h('span',{class:'sg-rr',style:col?{color:col}:null},(r>0?'+':'')+Number(r).toFixed(2)+'R'));
  const base=[{label:'Pair',left:true,get:o=>o,node:(v,o)=>h('span',null,h('b',null,o.sym),h('span',{class:'sg-tag '+o.side},o.side))},
    {label:'Setup',get:o=>o.type,node:(v,o)=>h('span',{class:'one-type',title:TYPE_TXT[o.type]||''},o.type+(o.reentry_no?' ↻':''))},
    {label:'Order',get:o=>o.kind,cls:(v,o)=>o.side==='LONG'?'up':'dn'},
    {label:'E1',get:o=>o,node:(v,o)=>f(o.E1,o.digits)},{label:'E2',get:o=>o,node:(v,o)=>f(o.E2,o.digits)},
    {label:'SL',get:o=>o,node:(v,o)=>h('span',{class:'dn'},f(o.SL,o.digits))},
    {label:'TP1',get:o=>o,node:(v,o)=>pxr(o.TP1,o.rr&&o.rr[0],o.digits,o.tp1_done?'#21c993':null)},{label:'TP2',get:o=>o,node:(v,o)=>pxr(o.TP2,o.rr&&o.rr[1],o.digits)},
    {label:'Lot E1/E2',get:o=>o,node:(v,o)=>o.lots&&o.lots.ok!==false?f(o.lots.lot1,2)+' / '+f(o.lots.lot2,2):'—'}];
  const COLS={
    open:base.concat([{label:'Harga',get:o=>o,node:(v,o)=>f(o.price,o.digits)},{label:'P/L',get:o=>o.r,fmt:v=>sgnR(v),cls:v=>T.cls(v)},{label:'Status',left:true,get:o=>o,node:(v,o)=>(o.tp1_done?'TP1 ✓ · SL di BE':'Berjalan')+(o.e2_filled?' · E2 terisi':'')}]),
    limit:base.concat([{label:'Harga',get:o=>o,node:(v,o)=>f(o.price,o.digits)},{label:'Jarak',get:o=>o.dist_r,fmt:v=>v==null?'—':Number(v).toFixed(2)+'R'},{label:'Berlaku s/d',get:o=>tfmt((o.issued||0)+(o.expiry_bars||0)*(o.tf_minutes||5)*60,o.tf_minutes)}]),
    closed:base.concat([{label:'Hasil',get:o=>o.r,fmt:v=>v==null?'—':sgnR(v),cls:v=>T.cls(v)},{label:'Status',left:true,get:o=>o,node:(v,o)=>h('span',{title:o.reason||''},o.status_txt||o.status)},{label:'Ditutup',get:o=>tfmt(o.closed,o.tf_minutes)}])};
  const EMPTY={open:'Tidak ada posisi ONE yang berjalan.',limit:'Tidak ada limit order ONE.',closed:'Belum ada order ONE yang selesai.'};
  function drawOrders(){
    if(!data)return;
    const O=data.orders,st=O.stats;
    const mk=(id,label,n)=>h('button',{class:S.tab===id?'on':'',onclick:()=>{S.tab=id;drawOrders()}},label+' ('+n+')');
    const sum=S.tab==='open'?'Floating: '+sgnR(st.float_r):S.tab==='closed'?(st.n?st.n+' trade · Positive '+Math.round((st.win||0)*100)+'% · Fill '+((st.fill_rate||0)*100).toFixed(0)+'% · Total '+sgnR(st.sum_r)+' · Rata-rata '+sgnR(st.avg_r):'—'):'2 limit per setup (50/50) · SL = 1R pada rata-rata entry';
    tabs.replaceChildren(mk('open','TERBUKA',O.open.length),mk('limit','LIMIT',O.limit.length),mk('closed','TERTUTUP',O.closed.length),h('span',{class:'sum'},sum));
    const rows=O[S.tab];
    if(!rows.length){ordPb.replaceChildren(h('div',{class:'sg-empty'},EMPTY[S.tab]));return}
    const sc=ordPb.scrollTop;
    ordPb.replaceChildren(T.table(COLS[S.tab],rows,{onRow:o=>pick(o.sym),selected:o=>o.sym===data.symbol}));
    ordPb.scrollTop=sc;
  }
  async function refresh(){
    try{
      const [d,c]=await Promise.all([T.rawFetch('signal/board',{symbol:S.sym||''}),admin?T.rawFetch('signal/control'):Promise.resolve(null)]);
      if(g!==T.gen)return;
      if((d.strategy||'multi')!=='one'){T.rerenderSignal('multi');return}
      T.state.sigStrategy='one';data=d;if(c)ctl=c;if(d.symbol)S.sym=d.symbol;
      if(admin&&d.symbol){try{det=await T.rawFetch('signal/detail',{symbol:d.symbol})}catch(e){det={ready:false,error:e.message,symbol:d.symbol}}}
      if(g!==T.gen)return;
      drawTop();drawList();drawChart();drawSide();drawOrders();
    }catch(e){if(g!==T.gen)return;cdiv.style.display='none';cmsg.style.display='';cmsg.textContent='Data tidak tersedia: '+e.message}
  }
  cmsg.style.display='';cmsg.textContent='Memuat…';
  refresh();T.every(10000,refresh);
}

// isi panel setup + checklist + filter (dipakai board & inside)
function sideKids(det,compact){
  const one=det.one,nd=det.digits||5,s=one.setup,F=one.filters||{};
  const kids=[];
  if(s){
    const lt=one.lots;
    kids.push(h('div',{class:'one-card '+(s.side==='BUY'?'buy':'sell')},
      h('div',{class:'one-card-h'},h('b',null,'SETUP '+s.type),h('span',{class:'badge '+(s.side==='BUY'?'b-BULLISH':'b-BEARISH')},s.side+(s.status==='PENDING'?' LIMIT':'')),h('span',{class:'mut'},ST_TXT[s.status]||s.status),h('span',{class:'one-score',title:'Skor Bagian 17'},'skor '+s.score)),
      h('div',{class:'mut',style:{fontSize:'11px',margin:'2px 0 6px'}},TYPE_TXT[s.type]+(s.reentry_no?' · re-entry':'')+(s.trigger&&s.trigger.kind?' · pemicu '+s.trigger.kind:'')),
      h('div',{class:'one-lv'},
        ...[['E1',s.E1,''],['E2',s.E2,''],['SL',s.SL,'dn'],['TP1',s.TP1,'up'],['TP2',s.TP2,'up']].map(([k,v,c])=>h('div',null,h('small',null,k),h('b',{class:c},f(v,nd)))),
        h('div',null,h('small',null,'RR'),h('b',null,f(s.rr_final,2)))),
      lt&&lt.ok!==false?h('div',{class:'mut',style:{fontSize:'11px',marginTop:'5px'}},`Lot (ekuitas ${T.fmt(one.contract.equity,0)} USD, risiko ${one.contract.risk_pct}%): E1 ${f(lt.lot1,2)} + E2 ${f(lt.lot2,2)}${lt.only_e1?' (hanya E1)':''}`):null,
      s.zone?h('div',{class:'mut',style:{fontSize:'11px'}},`Zona #${s.zone.id} ${s.zone.dir} ${f(s.zone.wick_bottom,nd)}–${f(s.zone.wick_top,nd)} · ${s.zone.state}${s.zone.is_flip?' · FLIP':''}${s.zone.validated?' · validated':''}`):null,
      h('div',{class:'mut',style:{fontSize:'11px'}},'Invalidasi '+f(s.invalidation,nd)+(s.backup?' · zona cadangan tersedia (re-entry 1x)':''))));
  }else{
    kids.push(h('div',{class:'one-card wait'},h('div',{class:'one-card-h'},h('b',null,'MENUNGGU'),h('span',{class:'mut'},'tren '+(one.structure.trend||'—'))),h('div',{class:'mut',style:{fontSize:'11px'}},det.reason||'belum ada setup')));
  }
  kids.push(h('div',{class:'one-sec'},'DAFTAR CEK KEPUTUSAN (BAGIAN 21)'));
  kids.push(h('div',{class:'one-check'},...(one.checklist||[]).map(c=>h('div',{class:c.ok?'ok':'no'},h('i',null,c.ok?'✓':'✗'),h('span',null,h('b',null,c.item),h('small',null,c.note))))));
  kids.push(h('div',{class:'one-sec'},'FILTER TERMINAL (TETAP JALAN)'));
  const q=F.quant||{},v=F.volume||{},r=F.risk||{},nw=F.news||{};
  const gated=Object.entries(q.types||{}).filter(([k,x])=>x.blocked).map(([k])=>k);
  const chip=(ok,lab,txt)=>h('div',{class:'one-chip '+(ok?'ok':'no')},h('b',null,lab),h('span',null,txt));
  kids.push(h('div',{class:'one-chips'},
    chip(nw.ok!==false,'BERITA',nw.block?nw.block:'tidak ada event penahan'+(nw.shock&&nw.shock.n?' · '+nw.shock.n+' kejadian mendadak':'')),
    chip(true,'VOLUME',v.has_volume?('RVOL pemicu ≥ '+v.min_rvol+(v.last&&v.last.rvol!=null?' · terakhir '+f(v.last.rvol,2):'')):'sumber tanpa data volume (dilewati)'),
    chip(!q.spike&&!gated.length,'QUANT',(q.atr_pct!=null?'ATR persentil '+f(q.atr_pct*100,0)+'%':'ATR —')+(gated.length?' · tipe dimatikan: '+gated.join(', '):' · tidak ada tipe negatif')),
    chip(r.day_r>-r.max_day_r&&r.day_n<r.max_day_n,'RISIKO',`hari ini ${r.day_n||0}/${r.max_day_n} setup · ${sgnR(r.day_r)} · akun ${sgnR(r.account_day_r)}`)));
  if(!compact&&(F.vetoed||[]).length)kids.push(h('div',{class:'warn',style:{fontSize:'11px'}},'Ditahan saat terbit: '+F.vetoed.map(x=>x.type+' '+x.side+' — '+x.reason).join(' · ')));
  const ts=one.stats&&one.stats.types||{};
  kids.push(h('div',{class:'one-sec'},'STATISTIK WALK-FORWARD PER TIPE (JENDELA DATA)'));
  kids.push(T.table([{label:'Tipe',left:true,get:r=>r.t},{label:'Trade',get:r=>r.n},{label:'Rata-rata',get:r=>r.avg,fmt:v=>sgnR(v),cls:v=>T.cls(v)},{label:'Win',get:r=>r.win,fmt:v=>v==null?'—':Math.round(v*100)+'%'},{label:'LCB',get:r=>r.lcb,fmt:v=>sgnR(v)}],
    'ABCDE'.split('').map(t=>Object.assign({t},ts[t]||{n:0}))));
  return kids;
}

// ====================================================================================== INSIDE / ANALISIS
function inside(root){
  const g=T.gen;
  const S=T.mem('signal_inside_one',{sym:null,tile:0});
  let ctl=null,det=null,ec=null,msg='';
  const top=h('div',{class:'sg-top',style:{gridArea:'top'}});
  const listPb=h('div',{class:'pb'});
  const listPanel=h('div',{class:'panel sgi-list'},h('div',{class:'ph'},'PAIR YANG DIANALISA · STRATEGI ONE'),listPb);
  const tiles=h('div',{class:'sgi-tiles one'});
  const resPb=h('div',{class:'pb'});
  const resPanel=h('div',{class:'panel sgi-res'},h('div',{class:'ph'},'HASIL ANALISA STRATEGI ONE'),resPb);
  root.append(h('div',{class:'sgi'},top,listPanel,tiles,resPanel));
  const TILES=[['STRUKTUR','swing · pivot · BOS/CHoCH'],['ZONA','demand / supply · fresh · flip'],['LIKUIDITAS','equal high/low · range · sweep'],['SETUP A–E','pemicu & aturan tiap tipe'],['TARGET & ORDER','E1/E2 · SL · TP1/TP2 · lot'],['FILTER & RISIKO','berita · volume · quant · harian']];
  function drawTop(){
    if(!ctl)return;
    top.replaceChildren(T.strategySwitch('one',m=>{msg=m;drawTop()}),
      h('button',{class:'sg-btn',onclick:()=>T.signalPicker(ctl,refresh)},'PILIH PAIR'),
      h('button',{class:'sg-btn',onclick:()=>T.signalMode(ctl,async()=>{S.tile=0;await refresh()})},'MODE TRADING'),
      h('button',{class:'sg-btn go',onclick:()=>{location.hash='#signal'}},'SINYAL'),
      h('span',{class:'mut'},ctl.mode_label+' · Sinyal '+(ctl.on?'ON':'OFF')+' · '+ctl.status.analyzed+'/'+ctl.status.total+' pair sudah dianalisa'+(ctl.status.errors?' · '+ctl.status.errors+' gagal':'')),
      ...(msg?[h('span',{class:'dn'},msg)]:[]));
  }
  function drawList(){
    if(!ctl)return;
    if(!ctl.overview.length){listPb.replaceChildren(h('div',{class:'sg-empty'},'Belum ada pair.'));return}
    listPb.replaceChildren(...ctl.overview.map(o=>h('div',{class:'sg-row'+(o.sym===S.sym?' sel':''),'data-sym':o.sym,title:o.error?('Gagal: '+o.error):(o.reason||o.name),onclick:()=>{S.sym=o.sym;drawList();load()}},
      h('i',{class:'sg-dot '+(o.ready&&o.fresh?o.dom:'')}),
      h('div',{style:{minWidth:0}},h('div',{class:'s'},o.sym),h('div',{class:'n'},o.ready&&o.fresh?('tren '+(o.trend||'—')+(o.one?' · '+o.one.type+' '+o.signal:'')):(o.error?'gagal':'menunggu…'))),
      h('div',{class:'p'},h('small',{class:o.signal==='BUY'?'up':o.signal==='SELL'?'dn':'mut'},o.ready&&o.fresh?(o.signal==='WAIT'?'WAIT':o.signal):'…')))));
  }
  function tileState(i){
    const one=det&&det.ready&&det.result_strategy==='one'?det.one:null;
    if(!one)return ['','menunggu analisa…'];
    const nd=det.digits;
    if(i===0){const st=one.structure,b=st.last_bos;return [st.trend==='BULL'?'BULLISH':st.trend==='BEAR'?'BEARISH':'WAITING',`tren ${st.trend}`+(b?` · ${b.choch?'CHoCH':'BOS'} ${b.dir} ${f(b.level,nd)}`:'')]}
    if(i===1){const z=one.zones.filter(z=>['FRESH','TESTED'].includes(z.state));const fl=z.filter(x=>x.is_flip).length;return [z.length?'BULLISH':'WAITING',`${z.length} zona FRESH/TESTED${fl?' · '+fl+' flip':''}`]}
    if(i===2){const a=one.liquidity.filter(l=>l.state==='ACTIVE');const sw=one.liquidity.filter(l=>l.state==='SWEPT');return [a.length?'BULLISH':'WAITING',`${a.length} level aktif · ${sw.length} tersapu`]}
    if(i===3){const s=one.setup;return [s?(s.side==='BUY'?'BULLISH':'BEARISH'):'WAITING',s?`setup ${s.type} ${s.side} · ${ST_TXT[s.status]||s.status}`:(det.reason||'tidak ada setup')]}
    if(i===4){const s=one.setup;return [s?(s.side==='BUY'?'BULLISH':'BEARISH'):'WAITING',s?`E1 ${f(s.E1,nd)} · SL ${f(s.SL,nd)} · TP2 ${f(s.TP2,nd)} (${f(s.rr_final,2)}R)`:'—']}
    const F=one.filters;const bad=(F.news&&F.news.ok===false)||(F.quant&&F.quant.spike);return [bad?'BEARISH':'BULLISH',bad?'ada filter yang menahan entry':'semua filter lolos saat ini'];
  }
  function drawTiles(){
    tiles.replaceChildren(...TILES.map(([t,sub],i)=>{const [st,note]=tileState(i);
      return h('div',{class:'sgi-tile '+st+(S.tile===i+1?' sel':''),'data-n':i+1,onclick:()=>{S.tile=S.tile===i+1?0:i+1;drawTiles();drawResult()}},
        h('div',{class:'h'},h('b',null,(i+1)+' · '+t),h('span',{class:'st mut'},sub)),h('div',{class:'nt'},note))}));
  }
  const tbl=(cols,rows,empty)=>rows&&rows.length?T.table(cols,rows):h('div',{class:'mut'},empty||'—');
  function detailFor(i){
    const one=det.one,nd=det.digits,tt=v=>tfmt(v,5);
    if(i===1){const st=one.structure;return [h('h4',null,'Struktur pasar (6.2–6.4)'),h('p',null,`Swing fractal ${one.params.fractal[0]} kiri / ${one.params.fractal[1]} kanan (dipakai setelah terkonfirmasi). Tren = arah BOS terakhir: ${st.trend}. BOS/CHoCH hanya dengan CLOSE.`),
      h('h4',null,'Pivot bergantian terakhir'),tbl([{label:'Waktu',get:p=>tt(p.ts)},{label:'Tipe',get:p=>p.type},{label:'Harga',get:p=>f(p.price,nd)}],st.pivots.slice().reverse()),
      h('h4',null,'BOS / CHoCH terakhir'),tbl([{label:'Waktu',get:b=>tt(b.ts)},{label:'Arah',get:b=>b.dir,cls:v=>v==='BULL'?'up':'dn'},{label:'Jenis',get:b=>b.choch?'CHoCH':'BOS'},{label:'Level ditembus',get:b=>f(b.level,nd)}],st.bos.slice().reverse())]}
    if(i===2){return [h('h4',null,'Zona demand / supply (6.5–6.7)'),h('p',null,'Base 2–12 candle kecil (tiap bar ≤ 0,8 ATR, total ≤ 1,2 ATR) lalu impuls ≥ 1,5 ATR dari tepi base. FRESH = belum disentuh, TESTED = 1 kunjungan, WEAK = ≥ 2 (hanya target). FLIP = zona lawan yang jebol.'),
      tbl([{label:'Lahir',get:z=>tt(z.born_ts)},{label:'Jenis',get:z=>z.dir+(z.is_flip?' FLIP':''),cls:(v,z)=>z.dir==='DEMAND'?'up':'dn'},{label:'Wick',get:z=>f(z.wick_bottom,nd)+' – '+f(z.wick_top,nd)},{label:'Body',get:z=>f(z.body_bottom,nd)+' – '+f(z.body_top,nd)},{label:'Status',get:z=>z.state},{label:'Kunjungan',get:z=>z.visits},{label:'Validated',get:z=>z.validated?'✓':'—'}],one.zones)]}
    if(i===3){return [h('h4',null,'Likuiditas (6.8–6.9)'),h('p',null,'Equal highs/lows (≥ 2 swing dalam 0,15 ATR) dan tepi range = target, BUKAN tempat entry. Sweep = wick menembus lalu close kembali dalam 3 bar (pemicu setup D bila diikuti BOS ≤ 20 bar).'),
      one.range?h('p',null,`Range aktif ${f(one.range.bottom,nd)} – ${f(one.range.top,nd)}`):null,
      tbl([{label:'Sejak',get:l=>tt(l.first_ts)},{label:'Jenis',get:l=>(l.kind==='RANGE'?'RANGE ':'')+(l.dir==='HIGHS'?'EQUAL HIGHS':'EQUAL LOWS')},{label:'Harga',get:l=>f(l.price,nd)},{label:'Status',get:l=>l.state},{label:'Sweep',get:l=>l.sweep?f(l.sweep.sweep,nd)+' @ '+tt(l.sweep.r_ts):'—'}],one.liquidity)]}
    if(i===4){const rows=Object.values(one.diag).sort((a,b)=>b.bar-a.bar);
      return [h('h4',null,'Evaluasi terakhir tiap tipe setup'),h('p',null,'A & C dievaluasi saat pivot berganti, B saat swing baru terbentuk sesudah break, D saat BOS terjadi ≤ 20 bar sesudah sweep, E saat TP2 tercapai di zona fresh/flip. Kode aturan mengacu ke dokumen (A1–A8, B3–B4, C1–C7, T3/T4, V1–V3, K1–K6).'),
        tbl([{label:'Waktu',get:d=>tt(d.ts)},{label:'Tipe',get:d=>d.type+' '+d.side},{label:'Aturan',get:d=>d.code},{label:'Hasil',left:true,get:d=>d.msg,cls:(v,d)=>d.ok?'up':'mut'}],rows),
        h('h4',null,'Setup terakhir'),tbl([{label:'Dibuat',get:s=>tt(s.created_ts)},{label:'Tipe',get:s=>s.type+' '+s.side},{label:'E1',get:s=>f(s.E1,nd)},{label:'SL',get:s=>f(s.SL,nd)},{label:'TP2',get:s=>f(s.TP2,nd)},{label:'RR',get:s=>f(s.rr_final,2)},{label:'Status',get:s=>ST_TXT[s.status]||s.status},{label:'Hasil',get:s=>['TP2','TP1','SL'].includes(s.status)?s.r:null,fmt:v=>v==null?'—':sgnR(v),cls:v=>T.cls(v)},{label:'Alasan',left:true,get:s=>s.reason||''}],one.setups),
        one.blocked&&one.blocked.length?h('h4',null,'Kandidat yang ditahan filter'):null,
        one.blocked&&one.blocked.length?tbl([{label:'Waktu',get:b=>tt(b.ts)},{label:'Tipe',get:b=>b.type+' '+b.side},{label:'Kode',get:b=>b.code},{label:'Alasan',left:true,get:b=>b.msg}],one.blocked.slice().reverse()):null]}
    if(i===5){const s=one.setup;if(!s)return [h('p',{class:'mut'},'Belum ada setup aktif. Tangga target dihitung saat setup terbentuk (Bagian 8).')];
      return [h('h4',null,'Order bertingkat (14.1–14.4)'),h('p',null,`Order #1 ${s.side} LIMIT di E1 ${f(s.E1,nd)}, order #2 di E2 ${f(s.E2,nd)} (E2 = E1 − 0,32 × jarak SL), SL ${f(s.SL,nd)} untuk keduanya, TP akhir = TP2 ${f(s.TP2,nd)}. TP1 ${f(s.TP1,nd)} dikelola bot: tutup 50% volume terbuka lalu SL ke rata-rata entry + 0,05 ATR; order #2 dihapus bila belum terisi.`),
        one.lots&&one.lots.ok!==false?h('p',null,`Lot (ekuitas ${T.fmt(one.contract.equity,0)} USD, risiko ${one.contract.risk_pct}% = ${T.fmt(one.lots.risk_money,2)} USD; 1 lot = ${T.fmt(one.contract.size,0)} ${one.contract.unit}): total ${f(one.lots.total,4)} → E1 ${f(one.lots.lot1,2)} + E2 ${f(one.lots.lot2,2)}`):h('p',{class:'mut'},'Lot belum bisa dihitung (kurs kuotasi belum tersedia)'),
        h('h4',null,'Tangga target (Bagian 8)'),tbl([{label:'Harga',get:x=>f(x.px,nd)},{label:'Sumber',get:x=>x.kind},{label:'RR',get:x=>f(x.rr,2)},{label:'Dipakai',get:x=>Math.abs(x.px-s.TP1)<1e-9?'TP1':Math.abs(x.px-s.TP2)<1e-9?'TP2':''}],s.ladder,s.type==='C'?'setup C: TP dari rumus harmonic (0,382 / 0,618 kaki AD), bukan tangga':'—'),
        h('h4',null,'Validasi'),...(s.checks||[]).map(c=>h('p',null,(c[1]?'✓ ':'✗ ')+c[0]+': '+c[2]))]}
    if(i===6){return [...sideKids(det,false).slice(-6)]}
    return [];
  }
  function drawResult(){
    if(!S.sym){resPb.replaceChildren(h('div',{class:'sg-empty'},'Pilih pair di list sebelah kiri.'));return}
    if(!det){resPb.replaceChildren(h('div',{class:'sg-empty'},'Memuat…'));return}
    if(!det.ready||det.result_strategy!=='one'){resPb.replaceChildren(h('div',{class:'sg-empty'},det.error?'Analisa gagal: '+det.error:(det.on?'Menunggu analisa strategi ONE untuk '+det.symbol+'…':'SINYAL OFF: bot tidak menganalisa pair ini.')));return}
    const kids=[h('div',{class:'ttl'},h('b',null,det.symbol+' · '+det.name),h('span',{class:'badge '+(det.signal==='BUY'?'b-BULLISH':det.signal==='SELL'?'b-BEARISH':'b-NEUTRAL')},det.signal),
      h('span',{class:'mut'},det.mode_label+' · bar terakhir '+det.asof+' · diperbarui '+T.ago(det.at)+' lalu'),det.fresh?null:h('span',{class:'warn'},'⚠ analisa lama — menunggu analisa ulang'))];
    const cbox=h('div',{class:'one-mini'});kids.push(cbox);
    if(S.tile)kids.push(...detailFor(S.tile));else kids.push(...sideKids(det,false));
    resPb.replaceChildren(...kids.filter(Boolean));
    const one=det.one;
    if(one&&one.candles&&one.candles.length){
      kill(ec);
      const ch={candles:one.candles,digits:det.digits,minutes:(one.candles.length>1?(one.candles[1][0]-one.candles[0][0])/60:5),price:det.price,order:null};
      ec=T.chart(cbox,chartOption(ch,one,true).opt);
    }
  }
  async function load(){
    if(!S.sym){det=null;drawTiles();drawResult();return}
    const sym=S.sym;
    try{const d=await T.rawFetch('signal/detail',{symbol:sym});if(g!==T.gen||sym!==S.sym)return;const same=det&&det.symbol===d.symbol&&det.at===d.at;det=d;drawTiles();if(!same)drawResult()}
    catch(e){if(g!==T.gen)return;det=null;resPb.replaceChildren(h('div',{class:'sg-empty err'},'Data tidak tersedia: '+e.message))}
  }
  async function refresh(){
    try{
      ctl=await T.rawFetch('signal/control');
      if(g!==T.gen)return;
      if(ctl.strategy!=='one'){T.rerenderSignal(ctl.strategy||'multi');return}
      T.state.sigStrategy='one';
      if(!ctl.pairs.includes(S.sym)){S.sym=ctl.pairs[0]||null}
      drawTop();drawList();await load();
    }catch(e){if(g!==T.gen)return;resPb.replaceChildren(h('div',{class:'sg-empty err'},'Data tidak tersedia: '+e.message))}
  }
  drawTiles();drawResult();refresh();T.every(10000,refresh);
}
T.SignalOne={board,inside};
})();
