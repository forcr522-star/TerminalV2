(function(){
const h=T.h;
const has=a=>Array.isArray(a)&&a.some(v=>v!=null);
function barChart(el,labels,vals,color){
  T.chart(el,{grid:{left:38,right:8,top:12,bottom:24},tooltip:T.tip({trigger:'axis'}),xAxis:T.axis({type:'category',data:labels,axisLabel:{color:'#7d8498',fontSize:9}}),yAxis:T.axis({type:'value'}),series:[{type:'bar',data:vals,itemStyle:{color},barMaxWidth:26}]});
}
function lineOpt(dates,series,extra={}){
  return Object.assign({grid:T.grid(),tooltip:T.tip(),legend:series.length>1?{top:0,textStyle:{color:'#8b93a7',fontSize:10}}:undefined,xAxis:T.axis({type:'category',data:dates,axisLabel:{color:'#7d8498',fontSize:9}}),yAxis:T.axis({type:'value',scale:true}),
    series:series.map(s=>Object.assign({type:'line',showSymbol:false,lineStyle:{width:1.6}},s))},extra);
}
const nodata=(msg)=>h('div',{class:'msg',style:{padding:'40px 14px'}},msg);
T.Views.centralbank=function(root){
  const S=T.mem('cb',{cc:'GLOBAL',ctab:'overview'});
  let cc=S.cc,ctab=S.ctab;
  const tabs=T.tabs([{id:'GLOBAL',label:'Global Overview'}].concat(T.countries.map(c=>({id:c[0],label:c[1]}))),cc,c=>{cc=S.cc=c;go()},'sm');
  const body=h('div');root.append(tabs,body);
  function go(){T.dispose();cc==='GLOBAL'?global():country()}
  function global(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('cb/overview'),d=>{
      const cards=[
        h('div',{class:'kpi'},h('div',{class:'l'},'Average policy rate'),h('div',{class:'v warn'},d.avg_policy==null?'—':T.fmt(d.avg_policy)+'%'),h('div',{class:'s'},(d.n_policy||0)+' dari '+d.rows.length+' bank sentral')),
        ...(d.n_curve?[h('div',{class:'kpi'},h('div',{class:'l'},'Inverted curves (2s10s)'),h('div',{class:'v'},d.inverted+' / '+d.n_curve),h('div',{class:'s'},'kurva dengan 2Y > 10Y'))]:[]),
        ...(d.avg_y10!=null?[h('div',{class:'kpi'},h('div',{class:'l'},'Average 10Y yield'),h('div',{class:'v'},T.fmt(d.avg_y10)+'%'),h('div',{class:'s'},(d.n_yield||0)+' dari '+d.rows.length+' negara'))]:[])];
      if(d.avg_cds!=null)cards.push(h('div',{class:'kpi'},h('div',{class:'l'},'Average sovereign CDS 5Y'),h('div',{class:'v'},T.fmt(d.avg_cds,0)+' bps'),h('div',{class:'s'},'best-effort')));
      wrap.append(h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',marginBottom:'8px'}},...cards));
      const yc=(k,dp)=>({label:k==='y10'?'10Y yield':'2Y yield',k,node:(v,r)=>h('span',{title:r.ynote||'',class:v==null?'mut':''},v==null?'—':T.fmt(v,dp)+'%')});
      // Kolom yang kosong untuk SEMUA negara disembunyikan (bukan deretan "—").
      const any=k=>d.rows.some(r=>r[k]!=null);
      const colDefs=[{label:'Country',left:true,get:r=>r.name},{label:'Central bank',left:true,k:'cb'},{label:'Policy rate',k:'policy',fmt:v=>v==null?'—':T.fmt(v)+'%',cls:()=>'warn',need:'policy'},
        Object.assign(yc('y10',3),{need:'y10'}),Object.assign(yc('y2',3),{need:'y2'}),
        {label:'10Y vs US',k:'spread_us',fmt:v=>v==null?'—':T.sgn(v,0)+' bps',cls:v=>T.cls(v),need:'spread_us'},{label:'2s10s',k:'curve',fmt:v=>v==null?'—':T.sgn(v,0)+' bps',cls:v=>v<0?'dn':'up',need:'curve'},
        {label:'Sumber yield',k:'ysrc',cls:()=>'mut',fmt:v=>v?String(v).split(',')[0]:'—',need:'ysrc'},{label:'CDS 5Y',k:'cds',fmt:v=>v==null?'—':T.fmt(v,0),need:'cds'}];
      const p=T.panel('Global Sovereign & Policy Rate Monitor',{np:1});
      p.body.append(T.table(colDefs.filter(c=>!c.need||any(c.need)),d.rows,{onRow:r=>{cc=S.cc=r.cc;tabs.set(cc);go()}}));
      wrap.append(p.el);
      const charts=[['Policy rate comparison','policy','#eab308'],['10Y sovereign yields','y10','#3b82f6'],['10Y spread vs US (bps)','spread_us','#ef4444']].filter(([t,k])=>has(d.rows.map(r=>r[k])));
      if(charts.length){
        const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'repeat('+charts.length+',1fr)',marginTop:'8px'}});
        charts.forEach(([t,k,c])=>{
          const q=T.panel(t,{bodyStyle:{height:'200px',padding:'4px'}});g.append(q.el);
          const b=T.chartBox();q.body.append(b);barChart(b,d.rows.map(r=>r.cc),d.rows.map(r=>r[k]),c);
        });
        wrap.append(g);
      }
    });
  }
  function country(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('cb/country',{cc}),d=>{
      // Prinsip: data yang memang tidak tersedia TIDAK ditampilkan (tanpa kartu "—", tanpa panel kosong, tanpa pesan error teknis).
      const kp=h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(170px,1fr))',marginBottom:'8px'}});
      const k=(l,v,s,c)=>kp.append(h('div',{class:'kpi'},h('div',{class:'l'},l),h('div',{class:'v '+(c||'')},v),h('div',{class:'s'},s||'')));
      if(d.policy!=null)k('Policy rate',T.fmt(d.policy)+'%',d.cb+(d.policy_chg_12m!=null?' · 12m '+T.sgn(d.policy_chg_12m)+' pt':''),'warn');
      if(d.inflation)k('Inflasi CPI (YoY)',T.fmt(d.inflation.value)+'%',d.inflation.src+' · '+d.inflation.asof);
      if(d.real_rate!=null)k('Suku bunga riil',T.sgn(d.real_rate)+'%','policy − inflasi',T.cls(d.real_rate));
      if(d.spread_2s10s!=null)k('2s10s spread',T.sgn(d.spread_2s10s,0)+' bps',d.spread_2s10s<0?'Inverted curve':'Normal curve');
      if(d.y10!=null)k('Govt 10Y yield',T.fmt(d.y10,3)+'%',d.y10_chg==null?'':T.sgn(d.y10_chg,3)+' d/d');
      if(d.y2!=null)k('Govt 2Y yield',T.fmt(d.y2,3)+'%','Short-term benchmark');
      if(d.cds!=null)k('Sovereign CDS 5Y',T.fmt(d.cds,0)+' bps','best-effort');
      if(d.balance.latest!=null)k('Balance sheet',T.big(d.balance.latest,d.balance.unit+' '),'Total central bank assets'+(d.balance.src?' · '+d.balance.src:''));
      if(kp.children.length)wrap.append(kp);
      if(d.ysrc)wrap.append(h('div',{class:'mut',style:{margin:'0 2px 8px',fontSize:'10px'}},'Sumber yield: '+d.ysrc));
      const join=()=>{const m=new Map(d.h2);return d.h10.filter(x=>m.has(x[0])).map(x=>[x[0],(x[1]-m.get(x[0]))*100])};
      const jn=join();
      const A={cv:d.curve.length>1,h10:d.h10.length>1,jn:jn.length>1,ph:d.policy_hist.length>1,bs:d.balance.series.length>1,dec:d.decisions.length>0};
      const bsOpt=(fmtX)=>({grid:T.grid(),tooltip:T.tip(),xAxis:T.axis({type:'category',data:d.balance.series.map(x=>fmtX(x[0]))}),yAxis:T.axis({type:'value',scale:true,axisLabel:{formatter:v=>T.big(v),color:'#7d8498'}}),series:[{type:'bar',data:d.balance.series.map(x=>x[1]),itemStyle:{color:'#3b82f6'}}]});
      const benchSeries=()=>[{name:'10Y',data:d.h10.map(x=>x[1]),color:'#22d3ee'}].concat(d.h2.length>1?[{name:'2Y',data:d.h2.map(x=>x[1]),color:'#22c55e'}]:[]);
      // Daftar grafik yang tersedia: tab hanya dibuat untuk grafik yang punya data.
      const CH={
        overview:{label:'Multi-asset overview',ok:()=>true},
        field:{label:'Field curve',ok:()=>A.cv,build:b=>T.chart(b,lineOpt(d.curve.map(c=>c.tenor),[{name:'Current',data:d.curve.map(c=>c.y),color:'#3b82f6',showSymbol:true}].concat(d.curve.some(c=>c.prev!=null)?[{name:'Prev close',data:d.curve.map(c=>c.prev),color:'#64748b',lineStyle:{type:'dashed'}}]:[])))},
        bench:{label:'Benchmark 10Y/2Y',ok:()=>A.h10,build:(b,sh)=>T.chart(b,lineOpt(d.h10.map(x=>sh?x[0].slice(5):x[0]),benchSeries()))},
        policy:{label:'Policy rate',ok:()=>A.ph,build:(b)=>T.chart(b,lineOpt(d.policy_hist.map(x=>x[0]),[{data:d.policy_hist.map(x=>x[1]),color:'#eab308',step:'end',areaStyle:{color:'rgba(234,179,8,.15)'}}]))},
        spread:{label:'2s10s spread',ok:()=>A.jn,build:b=>T.chart(b,lineOpt(jn.map(x=>x[0]),[{data:jn.map(x=>x[1]),color:'#eab308',markLine:{silent:true,symbol:'none',data:[{yAxis:0}],lineStyle:{color:'#ef4444'}}}]))},
        bs:{label:'Balance sheet',ok:()=>A.bs,build:b=>T.chart(b,bsOpt(x=>x))}
      };
      const avail=Object.keys(CH).filter(id=>CH[id].ok());
      if(!avail.includes(ctab))ctab=S.ctab='overview';
      const hasNews=d.wire.length>0;
      const main=h('div',{class:'grid resp',style:{gridTemplateColumns:hasNews?'2.2fr 1fr':'1fr',marginBottom:'8px'}});
      const C=T.panel('',{np:1,bodyStyle:{height:'400px',padding:'6px'}});
      const ct=avail.length>1?T.tabs(avail.map(id=>({id,label:CH[id].label})),ctab,t=>{ctab=S.ctab=t;draw()},'sm'):h('span',{class:'mut'},'Overview');ct.style.margin='0';
      C.head.replaceChildren(ct);
      main.append(C.el);
      if(hasNews){
        const W=T.panel('News wire',{np:1,bodyStyle:{height:'400px'}});
        W.body.append(...d.wire.map(n=>h('a',{class:'feed',href:n.link,target:'_blank',style:{padding:'6px 10px'}},h('div',{class:'m'},h('span',{class:'acc'},T.ago(n.ts)),h('span',null,n.source)),h('div',{class:'tt'},n.title))));
        main.append(W.el);
      }
      wrap.append(main);
      function draw(){
        T.charts.forEach(c=>{try{c.dispose()}catch(e){}});T.charts=[];
        C.body.replaceChildren();
        if(ctab==='overview'){
          const items=[];
          const sub=(title,build)=>items.push(()=>{const p=T.panel(title,{bodyStyle:{padding:'4px'}});const b=T.chartBox();p.body.append(b);return [p.el,()=>build(b)]});
          if(A.cv)sub('Yield curve',b=>T.chart(b,lineOpt(d.curve.map(c=>c.tenor),[{data:d.curve.map(c=>c.y),color:'#3b82f6',showSymbol:true}])));
          if(A.h10)sub('Benchmark yields',b=>CH.bench.build(b,true));
          if(A.ph)sub('Policy rate',b=>T.chart(b,lineOpt(d.policy_hist.map(x=>x[0]),[{data:d.policy_hist.map(x=>x[1]),color:'#eab308',step:'end',areaStyle:{color:'rgba(234,179,8,.15)'}}])));
          if(A.jn)sub('2s10s spread (bps)',b=>T.chart(b,lineOpt(jn.map(x=>x[0].slice(5)),[{data:jn.map(x=>x[1]),color:'#eab308'}])));
          if(A.bs)sub('Balance sheet',b=>T.chart(b,bsOpt(x=>x.slice(2,7))));
          if(A.dec)items.push(()=>{const dp=T.panel('Policy decisions',{np:1});dp.body.append(T.table([{label:'Date',left:true,k:'date'},{label:'Rate',k:'rate',fmt:v=>T.fmt(v)+'%'},{label:'Δ',k:'change',fmt:v=>v==null?'—':T.sgn(v),cls:v=>T.cls(-v)}],d.decisions.slice().reverse()));return [dp.el,null]});
          if(!items.length){C.body.append(nodata('Belum ada data untuk negara ini dari sumber gratis'));return}
          const cols=items.length>=5?3:(items.length>=2?2:1),rows=Math.ceil(items.length/cols);
          const g=h('div',{style:{display:'grid',gridTemplateColumns:'repeat('+cols+',1fr)',gridTemplateRows:'repeat('+rows+',minmax(0,1fr))',gap:'6px',height:'100%'}});C.body.append(g);
          const built=items.map(f=>f());built.forEach(([el])=>g.append(el));built.forEach(([,run])=>run&&run());
        }else{
          const b=T.chartBox();C.body.append(b);CH[ctab].build(b,false);
        }
      }
      draw();
      const cards=[];
      if(d.statement){const St=T.panel('Policy statement · '+d.statement.source,{bodyStyle:{maxHeight:'220px'}});St.body.append(h('div',{class:'txt'},d.statement.title));cards.push(St.el)}
      if(d.catalyst){const Ct=T.panel('Latest catalyst · '+d.catalyst.source,{bodyStyle:{maxHeight:'220px'}});Ct.body.append(h('div',{class:'txt'},d.catalyst.title));cards.push(Ct.el)}
      if(cards.length)wrap.append(h('div',{class:'grid resp',style:{gridTemplateColumns:'repeat('+cards.length+',1fr)'}},...cards));
    });
  }
  go();
};
})();
