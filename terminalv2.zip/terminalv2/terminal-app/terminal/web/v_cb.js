(function(){
const h=T.h;
const has=a=>Array.isArray(a)&&a.some(v=>v!=null);
function barChart(el,labels,vals,color){
  T.chart(el,{grid:{left:38,right:8,top:12,bottom:24},tooltip:T.tip({trigger:'axis'}),xAxis:T.axis({type:'category',data:labels,axisLabel:{color:'#8a8f9c',fontSize:9}}),yAxis:T.axis({type:'value'}),series:[{type:'bar',data:vals,itemStyle:{color},barMaxWidth:26}]});
}
function lineOpt(dates,series,extra={}){
  return Object.assign({grid:T.grid(),tooltip:T.tip(),legend:series.length>1?{top:0,textStyle:{color:'#8f93a0',fontSize:10}}:undefined,xAxis:T.axis({type:'category',data:dates,axisLabel:{color:'#8a8f9c',fontSize:9}}),yAxis:T.axis({type:'value',scale:true}),
    series:series.map(s=>Object.assign({type:'line',showSymbol:false,lineStyle:{width:1.6}},s))},extra);
}
T.Views.centralbank=function(root){
  const S=T.mem('cb',{cc:'GLOBAL',ctab:'overview'});
  let cc=S.cc,ctab=S.ctab;
  const tabs=T.tabs([{id:'GLOBAL',label:'Global Overview'}].concat(T.countries.map(c=>({id:c[0],label:c[1]}))),cc,c=>{cc=S.cc=c;go()},'sm');
  const body=h('div');root.append(tabs,body);
  function go(){T.dispose();cc==='GLOBAL'?global():country()}
  function global(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('cb/overview'),d=>{
      const cards=[
        h('div',{class:'kpi'},h('div',{class:'l'},'Average policy rate'),h('div',{class:'v warn'},d.avg_policy==null?'—':T.fmt(d.avg_policy)+'%'),h('div',{class:'s'},(d.n_policy||0)+' dari '+d.rows.length+' bank sentral')),
        ...(d.n_curve?[h('div',{class:'kpi'},h('div',{class:'l'},'Inverted curves (2s10s)'),h('div',{class:'v'},d.inverted+' / '+d.n_curve),h('div',{class:'s'},'kurva dengan 2Y > 10Y'))]:[]),
        ...(d.avg_y10!=null?[h('div',{class:'kpi'},h('div',{class:'l'},'Average 10Y yield'),h('div',{class:'v'},T.fmt(d.avg_y10)+'%'),h('div',{class:'s'},(d.n_yield||0)+' dari '+d.rows.length+' negara'))]:[])];
      if(d.avg_cds!=null)cards.push(h('div',{class:'kpi'},h('div',{class:'l'},'Average sovereign CDS 5Y'),h('div',{class:'v'},T.fmt(d.avg_cds,0)+' bps'),h('div',{class:'s'},'best-effort')));
      wrap.append(h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',marginBottom:'8px'}},...cards));
      const yc=(k,dp)=>({label:k==='y10'?'10Y yield':'2Y yield',k,node:(v,r)=>h('span',{title:r.ynote||'',class:v==null?'mut':''},v==null?'—':T.fmt(v,dp)+'%')});
      // Kolom yang kosong untuk SEMUA negara disembunyikan (bukan deretan "—").
      const any=k=>d.rows.some(r=>r[k]!=null);
      const colDefs=[{label:'Country',left:true,get:r=>r.name},{label:'Central bank',left:true,k:'cb'},{label:'Policy rate',k:'policy',fmt:v=>v==null?'—':T.fmt(v)+'%',cls:()=>'warn',need:'policy'},
        Object.assign(yc('y10',3),{need:'y10'}),Object.assign(yc('y2',3),{need:'y2'}),
        {label:'10Y vs US',k:'spread_us',fmt:v=>v==null?'—':T.sgn(v,0)+' bps',cls:v=>T.cls(v),need:'spread_us'},{label:'2s10s',k:'curve',fmt:v=>v==null?'—':T.sgn(v,0)+' bps',cls:v=>v<0?'dn':'up',need:'curve'},
        {label:'Sumber yield',k:'ysrc',cls:()=>'mut',fmt:v=>v?String(v).split(',')[0]:'—',need:'ysrc'},{label:'CDS 5Y',k:'cds',fmt:v=>v==null?'—':T.fmt(v,0),need:'cds'}];
      const p=T.panel('Global Sovereign & Policy Rate Monitor',{np:1});
      p.body.append(T.table(colDefs.filter(c=>!c.need||any(c.need)),d.rows,{onRow:r=>{cc=S.cc=r.cc;tabs.set(cc);go()}}));
      wrap.append(p.el);
      const charts=[['Policy rate comparison','policy','#f0a92e'],['10Y sovereign yields','y10','#4cc9f0'],['10Y spread vs US (bps)','spread_us',p=>p.value>=0?'#21c993':'#ff5b6b']].filter(([t,k])=>has(d.rows.map(r=>r[k])));
      if(charts.length){
        const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'repeat('+charts.length+',1fr)',marginTop:'8px'}});
        charts.forEach(([t,k,c])=>{
          const q=T.panel(t,{bodyStyle:{height:'200px',padding:'4px'}});g.append(q.el);
          const b=T.chartBox();q.body.append(b);barChart(b,d.rows.map(r=>r.cc),d.rows.map(r=>r[k]),c);
        });
        wrap.append(g);
      }
    });
  }
  function country(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('cb/country',{cc}),d=>{
      // Prinsip (sama untuk SEMUA negara): setiap negara mendapat kartu & tab yang sama. Bila sebuah data memang tidak
      // tersedia dari sumber gratis, tempatnya tetap ada dan menjelaskan alasannya (tanpa angka rekaan).
      const kp=h('div',{class:'grid',style:{gridTemplateColumns:'repeat(auto-fit,minmax(170px,1fr))',marginBottom:'8px'}});
      const k=(l,v,s,c)=>kp.append(h('div',{class:'kpi'+(v==null?' na':'')},h('div',{class:'l'},l),h('div',{class:'v '+(v==null?'mut':(c||''))},v==null?'n/a':v),h('div',{class:'s'},s||'')));
      const ym=d.ymissing||{};
      const shortLbl=d.short_tenor?(d.short_tenor+(d.short_tenor==='3M'||d.short_tenor==='1M'?' (pasar uang)':' yield')):'Yield pendek';
      k('Policy rate',d.policy!=null?T.fmt(d.policy)+'%':null,d.cb+(d.policy_chg_12m!=null?' · 12m '+T.sgn(d.policy_chg_12m)+' pt':''),'warn');
      k('Inflasi CPI (YoY)',d.inflation?T.fmt(d.inflation.value)+'%':null,d.inflation?d.inflation.src+' · '+d.inflation.asof:'belum tersedia');
      k('Suku bunga riil',d.real_rate!=null?T.sgn(d.real_rate)+'%':null,'policy − inflasi',T.cls(d.real_rate));
      k('Govt 10Y yield',d.y10!=null?T.fmt(d.y10,3)+'%':null,d.y10!=null?(d.y10_chg==null?'':T.sgn(d.y10_chg,3)+' d/d'):(ym['10Y']||'tidak tersedia'));
      k(d.short_tenor==='2Y'||!d.short_tenor?'Govt 2Y yield':shortLbl,d.y_short!=null?T.fmt(d.y_short,3)+'%':null,d.y_short!=null?(d.short_tenor!=='2Y'&&ym['2Y']?'2Y: '+ym['2Y']:'Short-term benchmark'):(ym['2Y']||'tidak tersedia'));
      k('Yield spread · '+(d.spread_label||'2s10s'),d.spread_2s10s!=null?T.sgn(d.spread_2s10s,0)+' bps':null,d.spread_2s10s!=null?(d.spread_2s10s<0?'Inverted curve':'Normal curve'):'butuh dua tenor dengan riwayat');
      k('Balance sheet',d.balance.latest!=null?T.big(d.balance.latest,d.balance.unit+' '):null,d.balance.latest!=null?'Total aset bank sentral'+(d.balance.src?' · '+d.balance.src+(d.balance.freq?' ('+d.balance.freq+')':''):''):(d.balance.reason||'tidak tersedia'));
      if(d.cds!=null)k('Sovereign CDS 5Y',T.fmt(d.cds,0)+' bps','best-effort');
      wrap.append(kp);
      if(d.ysrc)wrap.append(h('div',{class:'mut',style:{margin:'0 2px 8px',fontSize:'10.5px'}},'Sumber yield: '+d.ysrc));
      const hist=d.hist||{};
      const order=['1M','2M','3M','4M','6M','1Y','2Y','3Y','5Y','7Y','10Y','15Y','20Y','30Y'];
      const tenors=Object.keys(hist).sort((a,b)=>order.indexOf(a)-order.indexOf(b));
      // seri benchmark: 10Y + ujung pendek (2Y bila ada) + 30Y bila ada - sama untuk semua negara
      const benchT=[...new Set(['10Y',tenors.includes('2Y')?'2Y':tenors.find(t=>t!=='10Y'),'30Y'])].filter(t=>t&&hist[t]);
      const BC={'10Y':'#4cc9f0','2Y':'#21c993','30Y':'#b197fc'};
      const benchDates=[...new Set(benchT.flatMap(t=>hist[t].map(x=>x[0])))].sort();
      const benchSeries=()=>benchT.map(t=>{const m=new Map(hist[t]);return {name:t,data:benchDates.map(x=>m.has(x)?m.get(x):null),connectNulls:true,color:BC[t]||'#f0a92e'}});
      const sp=d.spread_hist||[];
      const bsOpt=(fmtX)=>({grid:T.grid({left:62}),tooltip:T.tip(),xAxis:T.axis({type:'category',data:d.balance.series.map(x=>fmtX(x[0]))}),yAxis:T.axis({type:'value',scale:true,axisLabel:{formatter:v=>T.big(v),color:'#8a8f9c'}}),series:[{type:'bar',data:d.balance.series.map(x=>x[1]),itemStyle:{color:'#f0a92e',opacity:.85}}]});
      const A={cv:d.curve.length>1,bench:benchT.length>0&&benchDates.length>1,ph:d.policy_hist.length>1,sp:sp.length>1,bs:d.balance.series.length>1,dec:d.decisions.length>0};
      const why={
        cv:d.curve.length===1?`Hanya ${d.curve[0].tenor} yang tersedia (${T.fmt(d.curve[0].y,2)}% · ${d.curve[0].src}). ${ym['10Y']?'10Y: '+ym['10Y']+'.':''}`:('Kurva yield tidak tersedia. '+(ym['10Y']||'')),
        bench:'Riwayat yield tidak tersedia. '+(ym['10Y']||''),
        ph:'Riwayat policy rate belum tersedia (BIS).',
        sp:tenors.length===1?`Spread butuh dua tenor; hanya ${tenors[0]} yang punya riwayat. ${ym['10Y']?'10Y: '+ym['10Y']+'.':''}`:'Spread kurva butuh dua tenor dengan riwayat.',
        bs:d.balance.reason||'Data neraca belum tersedia.'};
      const unitTxt=d.balance.unit?(d.balance.unit+(d.balance.freq?' · '+d.balance.freq:'')+(d.balance.src?' · '+d.balance.src:'')):'';
      const spLbl=(d.spread_label||'2s10s')+' spread (bps)';
      // Daftar tab SAMA untuk semua negara (urutannya juga sama).
      const CH={
        overview:{label:'Multi-asset overview'},
        field:{label:'Yield curve',ok:A.cv,why:why.cv,build:b=>T.chart(b,lineOpt(d.curve.map(c=>c.tenor),[{name:'Current',data:d.curve.map(c=>c.y),color:'#f0a92e',showSymbol:true}].concat(d.curve.some(c=>c.prev!=null)?[{name:'Prev close',data:d.curve.map(c=>c.prev),color:'#5d6371',lineStyle:{type:'dashed'}}]:[])))},
        bench:{label:'Benchmark yields',ok:A.bench,why:why.bench,build:(b,sh)=>T.chart(b,lineOpt(benchDates.map(x=>sh?x.slice(2):x),benchSeries()))},
        policy:{label:'Policy rate',ok:A.ph,why:why.ph,build:b=>T.chart(b,lineOpt(d.policy_hist.map(x=>x[0]),[{data:d.policy_hist.map(x=>x[1]),color:'#f0a92e',step:'end',areaStyle:{color:'rgba(240,169,46,.15)'}}]))},
        spread:{label:spLbl.replace(' (bps)',''),ok:A.sp,why:why.sp,build:(b,sh)=>T.chart(b,lineOpt(sp.map(x=>sh?x[0].slice(2):x[0]),[{name:spLbl,data:sp.map(x=>x[1]),color:'#f0a92e',areaStyle:{color:'rgba(240,169,46,.08)'},markLine:{silent:true,symbol:'none',data:[{yAxis:0}],lineStyle:{color:'#ff5b6b',type:'dashed'}}}]))},
        bs:{label:'Balance sheet',ok:A.bs,why:why.bs,build:(b,sh)=>T.chart(b,bsOpt(x=>sh?x.slice(2,7):x.slice(0,7)))}
      };
      const ids=Object.keys(CH);
      if(!ids.includes(ctab))ctab=S.ctab='overview';
      const hasNews=d.wire.length>0;
      const main=h('div',{class:'grid resp',style:{gridTemplateColumns:hasNews?'2.2fr 1fr':'1fr',marginBottom:'8px'}});
      const C=T.panel('',{np:1,bodyStyle:{height:'420px',padding:'6px'}});
      const ct=T.tabs(ids.map(id=>({id,label:CH[id].label+(id!=='overview'&&!CH[id].ok?' ·':'')})),ctab,t=>{ctab=S.ctab=t;draw()},'sm');ct.style.margin='0';
      C.head.replaceChildren(ct);
      main.append(C.el);
      if(hasNews){
        const W=T.panel('News wire',{np:1,bodyStyle:{height:'420px'}});
        W.body.append(...d.wire.map(n=>h('a',{class:'feed',href:n.link,target:'_blank',style:{padding:'6px 10px'}},h('div',{class:'m'},h('span',{class:'acc'},T.ago(n.ts)),h('span',null,n.source)),h('div',{class:'tt'},n.title))));
        main.append(W.el);
      }
      wrap.append(main);
      const naBox=(txt)=>h('div',{class:'na-box'},h('b',null,'Tidak tersedia untuk '+d.name),h('span',null,txt));
      function draw(){
        T.charts.forEach(c=>{try{c.dispose()}catch(e){}});T.charts=[];
        C.body.replaceChildren();
        if(ctab==='overview'){
          const items=[];
          const sub=(title,id,sh)=>items.push(()=>{const p=T.panel(title,{bodyStyle:{padding:'4px'}});
            if(!CH[id].ok){p.body.append(naBox(CH[id].why));return [p.el,null]}
            const b=T.chartBox();p.body.append(b);return [p.el,()=>CH[id].build(b,sh)]});
          sub('Yield curve','field');sub('Benchmark yields'+(benchT.length?' · '+benchT.join(' / '):''),'bench',true);sub('Policy rate','policy');sub(spLbl,'spread',true);
          sub('Balance sheet'+(unitTxt?' · '+unitTxt:''),'bs',true);
          items.push(()=>{const dp=T.panel('Policy decisions',{np:1});
            dp.body.append(A.dec?T.table([{label:'Date',left:true,k:'date'},{label:'Rate',k:'rate',fmt:v=>T.fmt(v)+'%'},{label:'Δ',k:'change',fmt:v=>v==null?'—':T.sgn(v),cls:v=>T.cls(-v)}],d.decisions.slice().reverse()):naBox('Riwayat keputusan belum tersedia.'));return [dp.el,null]});
          const g=h('div',{style:{display:'grid',gridTemplateColumns:'repeat(3,minmax(0,1fr))',gridTemplateRows:'repeat(2,minmax(0,1fr))',gap:'6px',height:'100%'},class:'cb-ov'});C.body.append(g);
          const built=items.map(f=>f());built.forEach(([el])=>g.append(el));built.forEach(([,run])=>run&&run());
        }else if(!CH[ctab].ok){
          C.body.append(naBox(CH[ctab].why));
        }else{
          const b=T.chartBox();C.body.append(b);CH[ctab].build(b,false);
        }
      }
      draw();
      const cards=[];
      if(d.statement){const St=T.panel('Policy statement · '+d.statement.source,{bodyStyle:{maxHeight:'220px'}});St.body.append(h('div',{class:'txt'},d.statement.title));cards.push(St.el)}
      if(d.catalyst){const Ct=T.panel('Latest catalyst · '+d.catalyst.source,{bodyStyle:{maxHeight:'220px'}});Ct.body.append(h('div',{class:'txt'},d.catalyst.title));cards.push(Ct.el)}
      if(cards.length)wrap.append(h('div',{class:'grid resp',style:{gridTemplateColumns:'repeat('+cards.length+',1fr)'}},...cards));
    });
  }
  go();
};
})();
