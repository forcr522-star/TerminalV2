(function(){
const h=T.h;
const SEVC={CRITICAL:'#ff5b6b',HIGH:'#f97316',ACTIVE:'#3b82f6'};
const LVC={CRITICAL:'#ff5b6b',HIGH:'#f97316',ELEVATED:'#f0a92e',NORMAL:'#21c993'};
const RISKC={CRITICAL:['#ff5b6b',.62],HIGH:['#f97316',.55],ELEVATED:['#f0a92e',.45],LOW:['#21c993',.28]};
T.Views.geo=function(root){
  const S=T.mem('geo',{tab:'map'});let tab=S.tab;
  const tabs=T.tabs([{id:'map',label:'Geo Map'},{id:'maritime',label:'Maritime'}],tab,t=>{tab=S.tab=t;go()});
  const body=h('div');root.append(tabs,body);
  function go(){T.dispose();tab==='map'?geo():maritime()}
  function geo(){
    const g=h('div',{class:'grid resp geogrid',style:{gridTemplateColumns:'2.2fr 1fr',height:'calc(100vh - 192px)',minHeight:'440px',gridTemplateRows:'minmax(0,1fr)'}});
    body.replaceChildren(g);
    const M=T.panel('Geopolitical Risk Globe',{np:1}),R=T.panel('Geopolitical Events Feed',{np:1});
    g.append(M.el,R.el);
    // Globe 3D mengisi wadahnya secara mutlak: ukurannya tidak bergantung pada panjang feed di sebelahnya.
    const box=h('div',{class:'mapbox'});M.body.append(box);M.body.style.overflow='hidden';
    const tipHtml=(kind,o)=>{
      const risk=(cur&&cur.risk)||{};
      if(kind==='country'){const r=risk[o];if(!r)return `<b>${T.esc(o)}</b><br><span class="mut">tidak ada sinyal risiko</span>`;
        return `<b>${T.esc(o)}</b><br>Risk: <b style="color:${(RISKC[r.level]||RISKC.LOW)[0]}">${r.level}</b> · skor ${r.score} · ${r.events} event${r.critical?' ('+r.critical+' critical)':''}${r.top?'<br>'+T.esc(r.top.title).slice(0,110):''}`}
      if(kind==='event')return `<b style="color:${SEVC[o.sev]||'#fff'}">${o.sev}</b> · ${T.esc(o.place||'')}<br>${T.esc(o.title)}<br><span class="mut">${T.esc(o.source||'')} · ${T.ago(o.ts)}</span>`;
      if(kind==='choke')return `<b>${T.esc(o.name)}</b><br>${o.level} · ${o.mentions} mentions${o.vessels?' · '+o.vessels+' vessels':''}${o.pw?'<br>'+T.fmt(o.pw.transits,0)+' transits/day ('+(o.pw.chg_pct==null?'—':T.sgn(o.pw.chg_pct,0)+'% 7d vs 30d')+')':''}`;
      if(kind==='port')return `${T.esc(o.name)}<br>${T.fmt(o.latest,0)} transits/day (${o.chg_pct==null?'—':T.sgn(o.chg_pct,0)+'% 7d vs 30d'})`;
      return '';
    };
    let cur=null;
    const gl=T.globe(box,{colors:{risk:RISKC,sev:SEVC,lvl:LVC},tip:tipHtml});T._globe=gl;
    T.load(R.body,T.api('geo/overview'),d=>{
      cur=d;box.querySelectorAll('.lgd').forEach(e=>e.remove());
      const risk=d.risk||{};
      gl.setData(d);
      const lg=h('div',{class:'lgd',style:{left:'8px',top:'8px'}});
      lg.innerHTML='<div class="mut" style="letter-spacing:.06em;margin-bottom:4px">COUNTRY RISK</div>'+['CRITICAL','HIGH','ELEVATED','LOW'].map(k=>`<div><i style="background:${RISKC[k][0]};opacity:${Math.min(1,RISKC[k][1]+.3)}"></i>${k}</div>`).join('')+'<div class="mut" style="margin-top:3px"><i style="background:#18202c;border:1px solid #2f3b4f"></i>no signal</div>';
      box.append(lg);
      const ov=h('div',{class:'lgd lcp',style:{left:'8px',bottom:'8px',width:'250px'}});
      ov.innerHTML='<div class="mut" style="letter-spacing:.06em;margin-bottom:4px">CHOKE POINT ALERT</div>'+d.chokepoints.slice(0,4).map(c=>`<div style="display:flex;justify-content:space-between;gap:8px"><span style="color:${LVC[c.level]}">${T.esc(c.name)}</span><span class="mut">${c.level}</span></div>`).join('')+`<div class="mut" style="margin-top:6px">THREAT: <span style="color:#ff5b6b">CRIT ${d.threat.CRITICAL}</span> · <span style="color:#f97316">HIGH ${d.threat.HIGH}</span> · <span style="color:#3b82f6">ACTIVE ${d.threat.ACTIVE}</span></div>`;
      box.append(ov);
      if(d.gpr){const gp=h('div',{class:'lgd lgpr',style:{right:'8px',bottom:'8px',width:'230px'}});
        gp.innerHTML=`<div class="mut" style="letter-spacing:.06em">GPR INDEX</div><div style="font-size:22px;font-weight:700">${T.fmt(d.gpr.latest,0)} <span class="${d.gpr.latest>=150?'dn':'warn'}" style="font-size:11px">${d.gpr.level}</span></div>${T.spark(d.gpr.series.slice(-120).map(x=>x.v),210,36,'#3b82f6')}`;box.append(gp)}
      const top=Object.entries(risk).sort((a,b)=>b[1].score-a[1].score).slice(0,8);
      if(top.length)R.body.append(h('div',{style:{padding:'8px 10px',borderBottom:'1px solid #121820'}},h('div',{class:'mut',style:{fontSize:'9px',letterSpacing:'.06em',marginBottom:'4px'}},'TOP COUNTRY RISK'),
        ...top.map(([n,r])=>h('span',{class:'chip',style:{borderColor:(RISKC[r.level]||RISKC.LOW)[0],color:(RISKC[r.level]||RISKC.LOW)[0]}},n+' · '+r.level))));
      const list=d.events.length?d.events.map(e=>h('a',{class:'feed',href:e.link,target:'_blank',style:{padding:'7px 10px',borderLeft:'3px solid '+SEVC[e.sev]},onmouseenter:()=>gl.focus(e.lon,e.lat,Math.max(gl.k,2.4))},
        h('div',{class:'m'},T.badge(e.sev),T.badge(e.cat,'TAG'),h('span',null,e.place),h('span',null,e.source),h('span',{class:'acc'},T.ago(e.ts))),h('div',{class:'tt'},e.title))):[h('div',{class:'msg'},'Belum ada event ter-geolokasi; menunggu feed berita.')];
      R.body.append(...list);
    });
  }
  function maritime(){
    const g=h('div',{class:'grid resp geogrid',style:{gridTemplateColumns:'3fr 1fr',height:'calc(100vh - 192px)',minHeight:'440px',gridTemplateRows:'minmax(0,1fr)'}});
    body.replaceChildren(g);
    const M=T.panel('Global Maritime (AIS)',{np:1}),R=T.panel('Choke Points');g.append(M.el,R.el);
    const mapEl=h('div',{class:'map'});M.body.append(h('div',{class:'mapbox'},mapEl));M.body.style.overflow='hidden';
    let map=null;
    const run=async(force)=>{
      try{
        const d=await T.api('maritime',{limit:3500},{force:force===true});
        if(!map)map=T.shipMap(mapEl,d.vessels,{center:[20,40],zoom:2});else map.drawVessels(d.vessels);
        const st=d.status;
        R.body.querySelector('#aisst').innerHTML=`AIS: ${st.connected?'<span class="up">connected</span>':'<span class="dn">offline</span>'} · ${st.vessels} vessels · coverage ${T.esc(st.coverage||'')}${st.error?'<br><span class="dn">'+T.esc(st.error)+'</span>':''}${st.sources&&!st.sources.aisstream_configured?'<br><span class="mut">Cakupan global: isi AISSTREAM_API_KEY (gratis) di .env</span>':''}`;
      }catch(e){R.body.querySelector('#aisst').textContent=e.message}
    };
    R.body.append(h('div',{id:'aisst',class:'mut',style:{marginBottom:'8px'}},'Memuat…'));
    T.load(h('div'),Promise.resolve(),()=>{});
    T.api('geo/overview').then(d=>R.body.append(T.table([{label:'Point',left:true,get:r=>r.name,cls:()=>'wrap'},{label:'Level',node:(_,r)=>T.badge(r.level)},{label:'Transit/d',get:r=>r.pw&&r.pw.transits,fmt:v=>v==null?'—':T.fmt(v,0)},{label:'7d vs 30d',get:r=>r.pw&&r.pw.chg_pct,fmt:v=>v==null?'—':T.sgn(v,0)+'%',cls:v=>T.cls(v)},{label:'Ships',k:'vessels'}],d.chokepoints))).catch(()=>{});
    run();T.every(30000,()=>run(true));
  }
  go();
};
})();
