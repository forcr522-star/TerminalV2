(function(){
const h=T.h;
const SEVC={CRITICAL:'#ff5b6b',HIGH:'#f97316',ACTIVE:'#3b82f6'};
const LVC={CRITICAL:'#ff5b6b',HIGH:'#f97316',ELEVATED:'#f0a92e',NORMAL:'#21c993'};
const RISKC={CRITICAL:['#ff5b6b',.62],HIGH:['#f97316',.55],ELEVATED:['#f0a92e',.45],LOW:['#21c993',.28]};
T.Views.geo=function(root){
  // Satu pemilih saja: layer di atas globe (Risk · Maritime · Airplane · Cyber). Tab lama "Geo Map / Maritime" dihapus
  // karena layer Maritime globe sudah memuat kapal AIS langsung, choke point dan insiden maritim.
  const body=h('div');root.append(body);
  function go(){T.dispose();geo()}
  // ================================================================ GLOBE 4 LAYER: RISK · MARITIME · AIRPLANE · CYBER
  const SHIPC={tanker:'#f0a92e',cargo:'#4cc9f0',passenger:'#21c993',fishing:'#b197fc',tug:'#9aa3b8',service:'#9aa3b8',other:'#6b7685'};
  const ROLEC={BOMBER:'#ff5b6b',ISR:'#b197fc',TANKER:'#4cc9f0',FIGHTER:'#ff9f6b',TRANSPORT:'#e8d5a3',HELICOPTER:'#21c993',TRAINER:'#8a93a6',OTHER:'#c8ccd6'};
  const ROLE_ORDER=['BOMBER','ISR','TANKER','FIGHTER','TRANSPORT','HELICOPTER','TRAINER','OTHER'];
  const CYC='#d65cff';
  const SVG=p=>`<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
  const LAYERS=[
    {id:'risk',label:'Risk',ep:'geo/overview',every:120e3,ic:SVG('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>')},
    {id:'sea',label:'Maritime',ep:'geo/sea',params:{limit:4000},every:30e3,ic:SVG('<path d="M3 16l2 4h14l2-4z"/><path d="M6 16V9h12v7"/><path d="M12 3v6M9 6h6"/>')},
    {id:'air',label:'Airplane',ep:'geo/air',every:60e3,ic:SVG('<path d="M12 2.5l1.6 6 6.9 4v1.8l-6.9-2.1-.4 5 2.3 1.7v1.5L12 19.3l-3.5 1.1v-1.5l2.3-1.7-.4-5-6.9 2.1V12.5l6.9-4z"/>')},
    {id:'cyber',label:'Cyber',ep:'geo/cyber',every:120e3,ic:SVG('<path d="M12 3l7 3v5c0 5-3 8.3-7 10-4-1.7-7-5-7-10V6z"/><path d="M9 12l2 2 4-4"/>')},
  ];
  const ago=ts=>ts?T.ago(ts):'—';
  const ft=v=>v==null?'—':v===0?'darat':T.fmt(v,0)+' ft';
  function geo(){
    const G=T.mem('geo.layer',{id:'risk'});
    const g=h('div',{class:'grid resp geogrid',style:{gridTemplateColumns:'2.2fr 1fr',height:'calc(100vh - 164px)',minHeight:'440px',gridTemplateRows:'minmax(0,1fr)'}});
    body.replaceChildren(g);
    const M=T.panel('Geopolitical Globe',{np:1}),R=T.panel('Geopolitical Events Feed',{np:1});
    g.append(M.el,R.el);
    // Globe 3D mengisi wadahnya secara mutlak: ukurannya tidak bergantung pada panjang feed di sebelahnya.
    const box=h('div',{class:'mapbox'});M.body.append(box);M.body.style.overflow='hidden';
    const cache={},stamp={};
    const tipHtml=(kind,o)=>{
      const d=cache.risk||{},risk=d.risk||{};
      if(kind==='country'){
        if(G.id==='cyber'){const c=((cache.cyber||{}).countries||{})[o];return c?`<b>${T.esc(o)}</b><br><span style="color:${CYC}">${c.victims} korban ransomware</span> (${c.d7} dalam 7 hari)<br><span class="mut">kelompok: ${T.esc(c.groups.join(', '))}</span>`:`<b>${T.esc(o)}</b><br><span class="mut">tidak ada korban di daftar terbaru</span>`}
        const r=risk[o];if(!r)return `<b>${T.esc(o)}</b><br><span class="mut">tidak ada sinyal risiko</span>`;
        return `<b>${T.esc(o)}</b><br>Risk: <b style="color:${(RISKC[r.level]||RISKC.LOW)[0]}">${r.level}</b> · skor ${r.score} · ${r.events} event${r.critical?' ('+r.critical+' critical)':''}${r.top?'<br>'+T.esc(r.top.title).slice(0,110):''}`}
      if(kind==='event')return `<b style="color:${SEVC[o.sev]||'#fff'}">${o.sev}</b> · ${T.esc(o.place||'')}<br>${T.esc(o.title)}<br><span class="mut">${T.esc(o.source||'')} · ${ago(o.ts)}</span>`;
      if(kind==='hot')return `<b>${T.esc(o.name)}</b><br>GDELT · ${T.esc(o.kind)} · ${o.count} event · ${o.mentions} penyebutan (24 jam)`;
      if(kind==='choke')return `<b>${T.esc(o.name)}</b><br>${o.level} · ${o.mentions} mentions${o.vessels?' · '+o.vessels+' vessels':''}${o.pw?'<br>'+T.fmt(o.pw.transits,0)+' transits/day ('+(o.pw.chg_pct==null?'—':T.sgn(o.pw.chg_pct,0)+'% 7d vs 30d')+')':''}`;
      if(kind==='port')return `${T.esc(o.name)}<br>${T.fmt(o.latest,0)} transits/day (${o.chg_pct==null?'—':T.sgn(o.chg_pct,0)+'% 7d vs 30d'})`;
      if(kind==='ship')return `<b>${T.esc(o[5]||'(tanpa nama)')}</b> · <span style="color:${SHIPC[o[4]]||'#fff'}">${T.esc(o[4])}</span><br>${T.fmt(o[3],1)} kn · arah ${o[2]}° · MMSI ${o[6]}`;
      if(kind==='inc')return `<b style="color:${SEVC[o.sev]||'#fff'}">${o.sev}</b> · ${T.esc(o.place||'')}<br>${T.esc(o.title)}<br><span class="mut">${T.esc(o.source||'')} · ${ago(o.ts)}</span>`;
      if(kind==='air')return `<b>${T.esc(o.cs||o.reg||o.hex)}</b> · ${T.esc(o.type||'?')} · <span style="color:${ROLEC[o.role]}">${o.role}</span>${o.emergency?' · <b class="dn">SQUAWK '+o.sqk+'</b>':''}<br>${ft(o.alt)} · ${o.gs==null?'—':T.fmt(o.gs,0)+' kt'} · arah ${o.trk==null?'—':T.fmt(o.trk,0)+'°'}<br><span class="mut">reg ${T.esc(o.reg||'—')} · posisi ${T.fmt(o.seen,0)} dtk sebelum pengambilan</span>`;
      if(kind==='cyc'){const vs=o.items.slice(0,4).map(v=>`${T.esc(v.victim)} <span class="mut">· ${T.esc(v.group)} · ${ago(v.ts)}</span>`).join('<br>');return `<b>${T.esc(o.name)}</b> · <span style="color:${CYC}">${o.items.length} korban ransomware</span><br>${vs}`}
      if(kind==='cnews')return `<b style="color:${CYC}">BERITA SIBER</b> · ${T.esc(o.place||'')}<br>${T.esc(o.title)}<br><span class="mut">${T.esc(o.source||'')} · ${ago(o.ts)} · lokasi dari judul</span>`;
      return '';
    };
    const gl=T.globe(box,{tip:tipHtml});T._globe=gl;
    // ---- pemilih layer (di atas globe)
    const bar=h('div',{class:'gl-layers',role:'tablist'});
    const live=h('span',{class:'gl-live'});
    LAYERS.forEach(L=>bar.append(h('button',{class:'gl-lb','data-id':L.id,role:'tab',title:L.label,html:L.ic+'<span>'+L.label+'</span><em></em>',onclick:()=>{if(G.id!==L.id){G.id=L.id;show()}}})));
    box.append(bar,live);
    const setCount=(id,n)=>{const b=bar.querySelector(`[data-id="${id}"] em`);if(b)b.textContent=n==null?'':T.fmt(n,0)};
    // ---- scene per layer
    function sceneOf(id,d){
      if(id==='risk'){const risk=d.risk||{},countries={},labels=[];
        Object.entries(risk).sort((a,b)=>b[1].score-a[1].score).forEach(([n,r])=>{const c=RISKC[r.level];if(c)countries[n]=c;labels.push({name:n,level:r.level==='CRITICAL'?0:r.level==='HIGH'?1:2})});
        const pts=[];
        (d.hotspots||[]).forEach(p=>pts.push({lon:p.lon,lat:p.lat,shape:'glow',color:'rgba(245,158,11,.45)',r:5+Math.sqrt(p.count||1)*2.2,kind:'hot',obj:p,prio:-2}));
        (d.portwatch||[]).forEach(p=>{if(p.lat!=null)pts.push({lon:p.lon,lat:p.lat,color:'rgba(34,211,238,.75)',r:2.2,kind:'port',obj:p})});
        (d.chokepoints||[]).forEach(c=>pts.push({lon:c.lon,lat:c.lat,shape:'diamond',color:LVC[c.level]||'#f0a92e',kind:'choke',obj:c,prio:2}));
        (d.events||[]).forEach(e=>{if(e.lat!=null)pts.push({lon:e.lon,lat:e.lat,color:SEVC[e.sev]||'#3b82f6',r:e.sev==='CRITICAL'?4.5:3.4,pulse:e.sev==='CRITICAL',stroke:1,kind:'event',obj:e,prio:1})});
        return {countries,labels,points:pts,pulse:pts.some(p=>p.pulse)}}
      if(id==='sea'){const pts=[];
        (d.vessels||[]).forEach(v=>pts.push({lat:v[0],lon:v[1],heading:v[2],shape:'ship',color:SHIPC[v[4]]||SHIPC.other,kind:'ship',obj:v,prio:-1}));
        (d.ports||[]).forEach(p=>pts.push({lon:p.lon,lat:p.lat,color:'rgba(34,211,238,.8)',r:2.4,kind:'port',obj:p}));
        (d.chokepoints||[]).forEach(c=>pts.push({lon:c.lon,lat:c.lat,shape:'diamond',color:LVC[c.level]||'#f0a92e',kind:'choke',obj:c,prio:3}));
        (d.incidents||[]).forEach(e=>{if(e.lat!=null)pts.push({lon:e.lon,lat:e.lat,color:SEVC[e.sev]||'#3b82f6',r:4,pulse:e.sev==='CRITICAL',stroke:1,kind:'inc',obj:e,prio:2})});
        return {points:pts,pulse:pts.some(p=>p.pulse)}}
      if(id==='air'){const pts=(d.aircraft||[]).map(a=>({lon:a.lon,lat:a.lat,heading:a.trk,shape:'plane',color:a.emergency?'#ff3b4e':ROLEC[a.role]||ROLEC.OTHER,r:a.role==='BOMBER'||a.role==='ISR'||a.role==='TANKER'?1.15:.95,kind:'air',obj:a,prio:a.emergency?3:0}));
        (d.emergencies||[]).forEach(a=>pts.push({lon:a.lon,lat:a.lat,color:'#ff3b4e',r:5,pulse:true,stroke:1,kind:'air',obj:a,prio:3}));
        return {points:pts,pulse:pts.some(p=>p.pulse)}}
      // cyber: negara berwarna menurut jumlah korban + satu titik per negara + berita yang lokasinya jelas
      const countries={},labels=[],pts=[],byC={};
      (d.victims||[]).forEach(v=>{if(v.country&&v.lat!=null)(byC[v.country]=byC[v.country]||{name:v.country,lat:v.lat,lon:v.lon,items:[]}).items.push(v)});
      Object.values(byC).sort((a,b)=>b.items.length-a.items.length).forEach((c,i)=>{const n=c.items.length;countries[c.name]=[CYC,n>=15?.6:n>=5?.45:.28];labels.push({name:c.name,level:i<3?0:i<8?1:2,text:c.name+' · '+n});
        pts.push({lon:c.lon,lat:c.lat,color:CYC,r:3+Math.min(6,Math.sqrt(n)*1.4),pulse:c.items.some(v=>v.ts&&Date.now()/1000-v.ts<86400),stroke:1,kind:'cyc',obj:c,prio:1})});
      (d.news||[]).forEach(n=>{if(n.lat!=null)pts.push({lon:n.lon,lat:n.lat,color:'#ffb86b',r:3.2,stroke:1,kind:'cnews',obj:n,prio:2})});
      return {countries,labels,points:pts,pulse:pts.some(p=>p.pulse)};
    }
    // ---- legenda & ringkasan di atas globe
    const ovl=(cls,style,html)=>{const e=h('div',{class:'lgd '+cls,style});e.innerHTML=html;box.append(e);return e};
    const sw=(c,t,shape)=>`<div><i style="background:${c};${shape==='round'?'border-radius:50%':''}"></i>${t}</div>`;
    function overlays(id,d){
      box.querySelectorAll('.lgd').forEach(e=>e.remove());
      if(id==='risk'){
        ovl('',{left:'8px',top:'52px'},'<div class="mut lgh">COUNTRY RISK</div>'+['CRITICAL','HIGH','ELEVATED','LOW'].map(k=>sw(RISKC[k][0],k)).join('')+'<div class="mut" style="margin-top:3px"><i style="background:#18202c;border:1px solid #2f3b4f"></i>no signal</div><div class="mut" style="margin-top:3px"><i style="background:rgba(245,158,11,.6);border-radius:50%"></i>GDELT 24 jam</div>');
        ovl('lcp',{left:'8px',bottom:'8px',width:'250px'},'<div class="mut lgh">CHOKE POINT ALERT</div>'+(d.chokepoints||[]).slice(0,4).map(c=>`<div class="lrow"><span style="color:${LVC[c.level]}">${T.esc(c.name)}</span><span class="mut">${c.level}</span></div>`).join('')+(d.threat?`<div class="mut" style="margin-top:6px">THREAT: <span style="color:#ff5b6b">CRIT ${d.threat.CRITICAL}</span> · <span style="color:#f97316">HIGH ${d.threat.HIGH}</span> · <span style="color:#3b82f6">ACTIVE ${d.threat.ACTIVE}</span></div>`:''));
        if(d.gpr)ovl('lgpr',{right:'8px',bottom:'8px',width:'230px'},`<div class="mut lgh">GPR INDEX</div><div style="font-size:22px;font-weight:700">${T.fmt(d.gpr.latest,0)} <span class="${d.gpr.latest>=150?'dn':'warn'}" style="font-size:11px">${d.gpr.level}</span></div>${T.spark(d.gpr.series.slice(-120).map(x=>x.v),210,36,'#3b82f6')}`);
      }else if(id==='sea'){const st=d.status||{};
        ovl('',{left:'8px',top:'52px'},'<div class="mut lgh">KAPAL (AIS LIVE)</div>'+Object.entries(SHIPC).filter(([k])=>k!=='service').map(([k,c])=>sw(c,k+(st.kinds&&st.kinds[k]?' · '+st.kinds[k]:''),'round')).join('')+'<div style="margin-top:3px"><i style="background:#f0a92e;transform:rotate(45deg);width:8px;height:8px"></i>choke point</div>'+sw(SEVC.CRITICAL,'insiden (berita)','round'));
        ovl('lcp',{left:'8px',bottom:'8px',width:'260px'},`<div class="mut lgh">COVERAGE</div><div>${T.fmt(st.vessels,0)} kapal · ${T.esc(st.coverage||'')}</div>${st.sources&&!st.sources.aisstream_configured?'<div class="mut" style="margin-top:4px">Cakupan global: isi AISSTREAM_API_KEY (gratis, aisstream.io) di .env</div>':''}`);
      }else if(id==='air'){
        ovl('',{left:'8px',top:'52px'},'<div class="mut lgh">PESAWAT MILITER</div>'+ROLE_ORDER.map(r=>sw(ROLEC[r],r.toLowerCase()+((d.roles||{})[r]?' · '+d.roles[r]:''),'round')).join('')+sw('#ff3b4e','squawk darurat','round'));
        ovl('lcp',{left:'8px',bottom:'8px',width:'260px'},'<div class="mut lgh">KAWASAN PANTAUAN</div>'+((d.regions||[]).slice(0,5).map(r=>`<div class="lrow"><span>${T.esc(r.name)}</span><b>${r.count}</b></div>`).join('')||'<div class="mut">tidak ada pesawat militer di kawasan pantauan</div>'));
      }else{
        ovl('',{left:'8px',top:'52px'},`<div class="mut lgh">CYBER (DILAPORKAN)</div>${sw(CYC,'korban ransomware / negara')}${sw('#ffb86b','berita serangan siber','round')}<div class="mut" style="margin-top:3px">berdenyut = korban baru 24 jam</div>`);
        ovl('lcp',{left:'8px',bottom:'8px',width:'250px'},'<div class="mut lgh">KELOMPOK PALING AKTIF</div>'+((d.groups||[]).slice(0,5).map(([g,n])=>`<div class="lrow"><span>${T.esc(g)}</span><b>${n}</b></div>`).join('')||'<div class="mut">—</div>'));
      }
    }
    // ---- panel kanan per layer
    const row=(o,lon,lat,...kids)=>h('div',{class:'feed',style:o,onmouseenter:()=>lon!=null&&gl.focus(lon,lat,Math.max(gl.k,2.4))},...kids);
    function feed(id,d){
      const ph=R.head.firstChild;
      if(id==='risk'){ph.textContent='Geopolitical Events Feed';
        const top=Object.entries(d.risk||{}).sort((a,b)=>b[1].score-a[1].score).slice(0,8);
        const out=[];
        if(top.length)out.push(h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'TOP COUNTRY RISK'),...top.map(([n,r])=>h('span',{class:'chip',style:{borderColor:(RISKC[r.level]||RISKC.LOW)[0],color:(RISKC[r.level]||RISKC.LOW)[0]}},n+' · '+r.level))));
        out.push(...((d.events||[]).length?d.events.map(e=>h('a',{class:'feed',href:e.link,target:'_blank',rel:'noopener',style:{padding:'7px 10px',borderLeft:'3px solid '+SEVC[e.sev]},onmouseenter:()=>gl.focus(e.lon,e.lat,Math.max(gl.k,2.4))},
          h('div',{class:'m'},T.badge(e.sev),T.badge(e.cat,'TAG'),h('span',null,e.place),h('span',null,e.source),h('span',{class:'acc'},ago(e.ts))),h('div',{class:'tt'},e.title))):[h('div',{class:'msg'},'Belum ada event ter-geolokasi; menunggu feed berita.')]));
        R.body.replaceChildren(...out);return}
      if(id==='sea'){ph.textContent='Maritime · AIS & Choke Points';const st=d.status||{};
        R.body.replaceChildren(
          h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'AIS'),h('div',{html:`${st.connected?'<span class="up">● live</span>':'<span class="dn">● offline</span>'} · ${T.fmt(st.vessels,0)} kapal · ${T.esc(st.coverage||'')}${st.error?' · <span class="dn">'+T.esc(st.error)+'</span>':''}`})),
          h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'CHOKE POINTS'),T.table([{label:'Point',left:true,get:r=>r.name,cls:()=>'wrap'},{label:'Level',node:(_,r)=>T.badge(r.level)},{label:'Transit/d',get:r=>r.pw&&r.pw.transits,fmt:v=>v==null?'—':T.fmt(v,0)},{label:'7d vs 30d',get:r=>r.pw&&r.pw.chg_pct,fmt:v=>v==null?'—':T.sgn(v,0)+'%',cls:v=>T.cls(v)}],d.chokepoints||[])),
          h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'INSIDEN MARITIM (BERITA 48 JAM)'),
          ...((d.incidents||[]).length?d.incidents.map(e=>h('a',{class:'feed',href:e.link,target:'_blank',rel:'noopener',style:{padding:'7px 10px',borderLeft:'3px solid '+(SEVC[e.sev]||'#3b82f6')},onmouseenter:()=>e.lat!=null&&gl.focus(e.lon,e.lat,Math.max(gl.k,2.4))},
            h('div',{class:'m'},T.badge(e.sev),h('span',null,e.place||'lokasi tidak disebut'),h('span',null,e.source),h('span',{class:'acc'},ago(e.ts))),h('div',{class:'tt'},e.title))):[h('div',{class:'msg'},'Belum ada insiden maritim di feed berita.')]));
        return}
      if(id==='air'){ph.textContent='Military Air Traffic · ADS-B';
        const list=(d.aircraft||[]).slice().sort((a,b)=>(b.emergency-a.emergency)||ROLE_ORDER.indexOf(a.role)-ROLE_ORDER.indexOf(b.role)||String(a.cs||'').localeCompare(String(b.cs||'')));
        R.body.replaceChildren(
          h('div',{class:'gf-sum'},h('div',{class:'gf-h'},`${T.fmt(d.total||0,0)} PESAWAT MILITER TERLACAK · ${T.esc(d.source||'')}`),
            ...ROLE_ORDER.filter(r=>(d.roles||{})[r]).map(r=>h('span',{class:'chip',style:{borderColor:ROLEC[r],color:ROLEC[r]}},r+' · '+d.roles[r])),
            h('div',{class:'mut',style:{fontSize:'10.5px',marginTop:'6px'}},`data diambil ${ago(d.ts)} · diperbarui tiap ${Math.round((d.poll_sec||180)/60)} menit (batas gratis adsb.lol 500 permintaan/hari) · hanya pesawat yang memancarkan ADS-B`)),
          ...list.slice(0,150).map(a=>row({padding:'6px 10px',borderLeft:'3px solid '+(a.emergency?'#ff3b4e':ROLEC[a.role])},a.lon,a.lat,
            h('div',{class:'m'},h('b',{style:{color:'#ece7da'}},a.cs||a.reg||a.hex),h('span',null,a.type||'?'),h('span',{style:{color:ROLEC[a.role]}},a.role),a.emergency?T.badge('SQUAWK '+a.sqk,'CRITICAL'):null,h('span',{class:'acc'},ft(a.alt))),
            h('div',{class:'mut',style:{fontSize:'11px'}},`${a.gs==null?'—':T.fmt(a.gs,0)+' kt'} · arah ${a.trk==null?'—':T.fmt(a.trk,0)+'°'} · ${T.fmt(a.lat,2)}, ${T.fmt(a.lon,2)}`))));
        return}
      ph.textContent='Cyber Attacks · Reported';
      R.body.replaceChildren(
        h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'KORBAN RANSOMWARE DIUMUMKAN'),
          h('div',{class:'gf-kpis'},h('div',null,h('b',null,T.fmt(d.d1||0,0)),h('span',null,'24 jam')),h('div',null,h('b',null,T.fmt(d.d7||0,0)),h('span',null,'7 hari')),h('div',null,h('b',null,T.fmt((d.victims||[]).length,0)),h('span',null,'daftar terbaru'))),
          d.error?h('div',{class:'dn',style:{fontSize:'11px'}},'ransomware.live: '+d.error):null),
        h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'BERITA SERANGAN SIBER'),
        ...((d.news||[]).slice(0,25).map(n=>h('a',{class:'feed',href:n.link,target:'_blank',rel:'noopener',style:{padding:'7px 10px',borderLeft:'3px solid #ffb86b'},onmouseenter:()=>n.lat!=null&&gl.focus(n.lon,n.lat,Math.max(gl.k,2.4))},
          h('div',{class:'m'},n.place?h('span',null,n.place):null,h('span',null,n.source),h('span',{class:'acc'},ago(n.ts))),h('div',{class:'tt'},n.title)))),
        h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'KORBAN TERBARU (RANSOMWARE.LIVE)'),
        ...(d.victims||[]).slice(0,60).map(v=>h(v.link?'a':'div',{class:'feed',href:v.link||null,target:v.link?'_blank':null,rel:'noopener',style:{padding:'6px 10px',borderLeft:'3px solid '+CYC},onmouseenter:()=>v.lat!=null&&gl.focus(v.lon,v.lat,Math.max(gl.k,2))},
          h('div',{class:'m'},h('span',{style:{color:CYC}},v.group),h('span',null,v.country||'negara tidak disebut'),v.sector?h('span',null,v.sector):null,h('span',{class:'acc'},ago(v.ts))),h('div',{class:'tt'},v.victim))));
    }
    // ---- muat & tampilkan
    function apply(id,d){
      cache[id]=d;stamp[id]=Date.now();
      if(id==='sea')setCount('sea',(d.vessels||[]).length);
      if(id==='air')setCount('air',d.total);
      if(id==='cyber')setCount('cyber',d.d1);
      if(id==='risk')setCount('risk',(d.events||[]).length);
      if(G.id!==id)return;
      gl.setScene(sceneOf(id,d));overlays(id,d);feed(id,d);tickLive();
    }
    function load(id,force){const L=LAYERS.find(x=>x.id===id);
      return T.api(L.ep,L.params,{force:!!force,bg:!!force}).then(d=>apply(id,d)).catch(e=>{if(G.id===id&&!cache[id])R.body.replaceChildren(h('div',{class:'msg err'},e.message))})}
    function tickLive(){const t=stamp[G.id];live.innerHTML=t?`<i></i>LIVE · ${T.ago(t/1000)}`:'<i></i>memuat…'}
    function show(){
      [...bar.children].forEach(b=>b.classList.toggle('on',b.dataset.id===G.id));
      if(cache[G.id])apply(G.id,cache[G.id]);else{R.body.replaceChildren(h('div',{class:'msg'},'Memuat…'));gl.setScene(null);box.querySelectorAll('.lgd').forEach(e=>e.remove());tickLive()}
      load(G.id,!!cache[G.id]);
    }
    show();
    if(G.id!=='risk')load('risk');            // tooltip negara & hitungan RISK tetap tersedia
    LAYERS.forEach(L=>T.every(L.every,()=>{if(G.id===L.id&&!document.hidden)load(L.id,true)}));
    T.every(5000,tickLive);
  }
  go();
};
})();
