(function(){
const h=T.h;
const SEVC={CRITICAL:'#ef4444',HIGH:'#f97316',ACTIVE:'#3b82f6'};
const LVC={CRITICAL:'#ef4444',HIGH:'#f97316',ELEVATED:'#eab308',NORMAL:'#22c55e'};
const RISKC={CRITICAL:['#ef4444',.62],HIGH:['#f97316',.55],ELEVATED:['#eab308',.45],LOW:['#22c55e',.28]};
T.Views.geo=function(root){
  const S=T.mem('geo',{tab:'map'});let tab=S.tab;
  const tabs=T.tabs([{id:'map',label:'Geo Map'},{id:'maritime',label:'Maritime'}],tab,t=>{tab=S.tab=t;go()});
  const body=h('div');root.append(tabs,body);
  function go(){T.dispose();tab==='map'?geo():maritime()}
  function geo(){
    const g=h('div',{class:'grid resp geogrid',style:{gridTemplateColumns:'2.2fr 1fr',height:'calc(100vh - 170px)',minHeight:'440px',gridTemplateRows:'minmax(0,1fr)'}});
    body.replaceChildren(g);
    const M=T.panel('Geopolitical Risk Map',{np:1}),R=T.panel('Geopolitical Events Feed',{np:1});
    g.append(M.el,R.el);
    // Peta mengisi wadahnya secara mutlak (position:absolute): ukurannya tidak lagi bergantung pada panjang feed di sebelahnya.
    const mapEl=h('div',{class:'map'});const box=h('div',{class:'mapbox'},mapEl);M.body.append(box);M.body.style.overflow='hidden';
    const map=T.map(mapEl,[25,30],2);
    const layer=L.layerGroup().addTo(map);let riskLayer=null;
    T.load(R.body,T.api('geo/overview'),d=>{
      layer.clearLayers();box.querySelectorAll('.lgd').forEach(e=>e.remove());
      const risk=d.risk||{};
      T.loadWorld().then(world=>{
        if(riskLayer){try{map.removeLayer(riskLayer)}catch(e){}}
        riskLayer=L.geoJSON(world,{
          filter:f=>risk[f.properties.n],
          style:f=>{const r=risk[f.properties.n],c=RISKC[r.level]||RISKC.LOW;return{fillColor:c[0],fillOpacity:c[1],color:c[0],weight:.8,opacity:.8}},
          onEachFeature:(f,l)=>{const r=risk[f.properties.n];l.bindTooltip(`<b>${T.esc(f.properties.n)}</b><br>Risk: <b style="color:${(RISKC[r.level]||RISKC.LOW)[0]}">${r.level}</b> · skor ${r.score} · ${r.events} event${r.critical?' ('+r.critical+' critical)':''}${r.top?'<br>'+T.esc(r.top.title).slice(0,110):''}`,{sticky:true})}
        }).addTo(map);
        riskLayer.bringToBack();if(map._base)map._base.bringToBack();
      });
      d.hotspots.forEach(p=>L.circleMarker([p.lat,p.lon],{radius:Math.min(14,3+Math.sqrt(p.count||1)),color:'#f59e0b',weight:0,fillOpacity:.25,interactive:false}).addTo(layer));
      (d.portwatch||[]).forEach(p=>{if(p.lat!=null)L.circleMarker([p.lat,p.lon],{radius:3,color:'#22d3ee',weight:0,fillOpacity:.5}).bindTooltip(`${T.esc(p.name)}<br>${T.fmt(p.latest,0)} transits/day (${p.chg_pct==null?'—':T.sgn(p.chg_pct,0)+'% 7d vs 30d'})`).addTo(layer)});
      d.chokepoints.forEach(c=>L.marker([c.lat,c.lon],{icon:L.divIcon({className:'',html:`<div style="width:12px;height:12px;background:${LVC[c.level]};transform:rotate(45deg);border:1px solid #000"></div>`,iconSize:[12,12]})}).bindTooltip(`<b>${T.esc(c.name)}</b><br>${c.level} · ${c.mentions} mentions${c.vessels?' · '+c.vessels+' vessels':''}${c.pw?'<br>'+T.fmt(c.pw.transits,0)+' transits/day ('+(c.pw.chg_pct==null?'—':T.sgn(c.pw.chg_pct,0)+'% 7d vs 30d')+')':''}`).addTo(layer));
      d.events.forEach(e=>L.circleMarker([e.lat,e.lon],{radius:e.sev==='CRITICAL'?7:5,color:SEVC[e.sev],fillColor:SEVC[e.sev],fillOpacity:.7,weight:1}).bindTooltip(T.esc(e.title)).addTo(layer));
      const lg=h('div',{class:'lgd',style:{left:'8px',top:'8px'}});
      lg.innerHTML='<div class="mut" style="letter-spacing:.06em;margin-bottom:4px">COUNTRY RISK</div>'+['CRITICAL','HIGH','ELEVATED','LOW'].map(k=>`<div><i style="background:${RISKC[k][0]};opacity:${Math.min(1,RISKC[k][1]+.3)}"></i>${k}</div>`).join('')+'<div class="mut" style="margin-top:3px"><i style="background:#151a25;border:1px solid #2c3448"></i>no signal</div>';
      box.append(lg);
      const ov=h('div',{class:'lgd lcp',style:{left:'8px',bottom:'8px',width:'250px'}});
      ov.innerHTML='<div class="mut" style="letter-spacing:.06em;margin-bottom:4px">CHOKE POINT ALERT</div>'+d.chokepoints.slice(0,4).map(c=>`<div style="display:flex;justify-content:space-between;gap:8px"><span style="color:${LVC[c.level]}">${T.esc(c.name)}</span><span class="mut">${c.level}</span></div>`).join('')+`<div class="mut" style="margin-top:6px">THREAT: <span style="color:#ef4444">CRIT ${d.threat.CRITICAL}</span> · <span style="color:#f97316">HIGH ${d.threat.HIGH}</span> · <span style="color:#3b82f6">ACTIVE ${d.threat.ACTIVE}</span></div>`;
      box.append(ov);
      if(d.gpr){const gp=h('div',{class:'lgd lgpr',style:{right:'8px',bottom:'8px',width:'230px'}});
        gp.innerHTML=`<div class="mut" style="letter-spacing:.06em">GPR INDEX</div><div style="font-size:22px;font-weight:700">${T.fmt(d.gpr.latest,0)} <span class="${d.gpr.latest>=150?'dn':'warn'}" style="font-size:11px">${d.gpr.level}</span></div>${T.spark(d.gpr.series.slice(-120).map(x=>x.v),210,36,'#3b82f6')}`;box.append(gp)}
      const top=Object.entries(risk).sort((a,b)=>b[1].score-a[1].score).slice(0,8);
      if(top.length)R.body.append(h('div',{style:{padding:'8px 10px',borderBottom:'1px solid #161a24'}},h('div',{class:'mut',style:{fontSize:'9px',letterSpacing:'.06em',marginBottom:'4px'}},'TOP COUNTRY RISK'),
        ...top.map(([n,r])=>h('span',{class:'chip',style:{borderColor:(RISKC[r.level]||RISKC.LOW)[0],color:(RISKC[r.level]||RISKC.LOW)[0]}},n+' · '+r.level))));
      const list=d.events.length?d.events.map(e=>h('a',{class:'feed',href:e.link,target:'_blank',style:{padding:'7px 10px',borderLeft:'3px solid '+SEVC[e.sev]},onmouseenter:()=>map.setView([e.lat,e.lon],Math.max(map.getZoom(),4))},
        h('div',{class:'m'},T.badge(e.sev),T.badge(e.cat,'TAG'),h('span',null,e.place),h('span',null,e.source),h('span',{class:'acc'},T.ago(e.ts))),h('div',{class:'tt'},e.title))):[h('div',{class:'msg'},'Belum ada event ter-geolokasi; menunggu feed berita.')];
      R.body.append(...list);
      setTimeout(()=>map.invalidateSize(),50);
    });
  }
  function maritime(){
    const g=h('div',{class:'grid resp geogrid',style:{gridTemplateColumns:'3fr 1fr',height:'calc(100vh - 170px)',minHeight:'440px',gridTemplateRows:'minmax(0,1fr)'}});
    body.replaceChildren(g);
    const M=T.panel('Global Maritime (AIS)',{np:1}),R=T.panel('Choke Points');g.append(M.el,R.el);
    const mapEl=h('div',{class:'map'});M.body.append(h('div',{class:'mapbox'},mapEl));M.body.style.overflow='hidden';
    let map=null;
    const run=async(force)=>{
      try{
        const d=await T.api('maritime',{limit:3500},{force:force===true});
        if(!map)map=T.shipMap(mapEl,d.vessels,{center:[20,40],zoom:2});else map.drawVessels(d.vessels);
        const st=d.status;
        R.body.querySelector('#aisst').innerHTML=`AIS: ${st.connected?'<span class="up">connected</span>':'<span class="dn">offline</span>'} · ${st.vessels} vessels · coverage ${T.esc(st.coverage||'')}${st.error?'<br><span class="dn">'+T.esc(st.error)+'</span>':''}${st.sources&&!st.sources.aisstream_configured?'<br><span class="mut">Cakupan global: isi AISSTREAM_API_KEY (gratis) di .env</span>':''}`;
      }catch(e){R.body.querySelector('#aisst').textContent=e.message}
    };
    R.body.append(h('div',{id:'aisst',class:'mut',style:{marginBottom:'8px'}},'Memuat…'));
    T.load(h('div'),Promise.resolve(),()=>{});
    T.api('geo/overview').then(d=>R.body.append(T.table([{label:'Point',left:true,get:r=>r.name,cls:()=>'wrap'},{label:'Level',node:(_,r)=>T.badge(r.level)},{label:'Transit/d',get:r=>r.pw&&r.pw.transits,fmt:v=>v==null?'—':T.fmt(v,0)},{label:'7d vs 30d',get:r=>r.pw&&r.pw.chg_pct,fmt:v=>v==null?'—':T.sgn(v,0)+'%',cls:v=>T.cls(v)},{label:'Ships',k:'vessels'}],d.chokepoints))).catch(()=>{});
    run();T.every(30000,()=>run(true));
  }
  go();
};
})();
