(function(){
const h=T.h;
const SEVC={CRITICAL:'#ff5b6b',HIGH:'#f97316',ACTIVE:'#3b82f6'};
const LVC={CRITICAL:'#ff5b6b',HIGH:'#f97316',ELEVATED:'#f0a92e',NORMAL:'#21c993'};
const RISKC={CRITICAL:['#ff5b6b',.62],HIGH:['#f97316',.55],ELEVATED:['#f0a92e',.45],LOW:['#21c993',.28]};
T.Views.geo=function(root){
  // Satu pemilih saja: layer di atas globe (Risk · Maritime · Airplane · Cyber). Tab lama "Geo Map / Maritime" dihapus
  // karena layer Maritime globe sudah memuat kapal AIS langsung, choke point dan insiden maritim.
  const body=h('div');root.append(body);
  function go(){T.dispose();geo()}
  // ================================================================ GLOBE 4 LAYER: RISK · MARITIME · AIRPLANE · CYBER
  const SHIPC={tanker:'#f0a92e',cargo:'#4cc9f0',passenger:'#21c993',fishing:'#b197fc',tug:'#9aa3b8',service:'#9aa3b8',other:'#6b7685'};
  const ROLEC={BOMBER:'#ff5b6b',ISR:'#b197fc',TANKER:'#4cc9f0',FIGHTER:'#ff9f6b',TRANSPORT:'#e8d5a3',HELICOPTER:'#21c993',TRAINER:'#8a93a6',OTHER:'#c8ccd6'};
  const ROLE_ORDER=['BOMBER','ISR','TANKER','FIGHTER','TRANSPORT','HELICOPTER','TRAINER','OTHER'];
  const CYC='#d65cff';
  const SVG=p=>`<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
  const LAYERS=[
    {id:'risk',label:'Risk',ep:'geo/overview',every:120e3,ic:SVG('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>')},
    {id:'sea',label:'Maritime',ep:'geo/sea',params:{limit:4000},every:30e3,ic:SVG('<path d="M3 16l2 4h14l2-4z"/><path d="M6 16V9h12v7"/><path d="M12 3v6M9 6h6"/>')},
    {id:'air',label:'Airplane',ep:'geo/air',every:60e3,ic:SVG('<path d="M12 2.5l1.6 6 6.9 4v1.8l-6.9-2.1-.4 5 2.3 1.7v1.5L12 19.3l-3.5 1.1v-1.5l2.3-1.7-.4-5-6.9 2.1V12.5l6.9-4z"/>')},
    {id:'cyber',label:'Cyber',ep:'geo/cyber',every:120e3,ic:SVG('<path d="M12 3l7 3v5c0 5-3 8.3-7 10-4-1.7-7-5-7-10V6z"/><path d="M9 12l2 2 4-4"/>')},
  ];
  const ago=ts=>ts?T.ago(ts):'—';
  const ft=v=>v==null?'—':v===0?'darat':T.fmt(v,0)+' ft';
  function geo(){
    const G=T.mem('geo.layer',{id:'risk'});
    const g=h('div',{class:'grid resp geogrid',style:{gridTemplateColumns:'2.2fr 1fr',height:'calc(100vh - 164px)',minHeight:'440px',gridTemplateRows:'minmax(0,1fr)'}});
    body.replaceChildren(g);
    const M=T.panel('Geopolitical Globe',{np:1}),R=T.panel('Geopolitical Events Feed',{np:1});
    g.append(M.el,R.el);
    // Globe 3D mengisi wadahnya secara mutlak: ukurannya tidak bergantung pada panjang feed di sebelahnya.
    const box=h('div',{class:'mapbox'});M.body.append(box);M.body.style.overflow='hidden';
    const cache={},stamp={},stat={};
    const UP='#21c993',DN='#ff5b6b',FLAT='#4cc9f0';
    const chgCol=v=>v==null?'rgba(76,201,240,.5)':v>=10?UP:v<=-10?DN:'rgba(76,201,240,.85)';
    const tipHtml=(kind,o)=>{
      const d=cache.risk||{},risk=d.risk||{};
      if(kind==='country'){
        if(G.id==='cyber'){const c=((cache.cyber||{}).countries||{})[o];return c?`<b>${T.esc(o)}</b><br><span style="color:${CYC}">${c.victims} korban ransomware</span> (${c.d7} dalam 7 hari)${c.press?' · <span style="color:#ffb86b">'+c.press+' diberitakan</span>':''}<br><span class="mut">kelompok: ${T.esc(c.groups.join(', ')||'—')}</span>`:`<b>${T.esc(o)}</b><br><span class="mut">tidak ada korban di daftar ${(cache.cyber||{}).window_days||45} hari</span>`}
        if(G.id==='sea'){const c=((stat.sea||{}).countries||{})[o];return c?`<b>${T.esc(o)}</b><br>${T.fmt(c.d7,1)} kunjungan kapal/hari (7 hari)${c.chg==null?'':' · <span class="'+T.cls(c.chg)+'">'+T.sgn(c.chg,1)+'% vs 28 hari</span>'}<br><span class="mut">IMF PortWatch · data s/d ${T.esc((stat.sea||{}).activity_date||'')}</span>`:`<b>${T.esc(o)}</b><br><span class="mut">tidak ada pelabuhan PortWatch</span>`}
        if(G.id==='air'){const c=((cache.air||{}).countries||{})[o];return c?`<b>${T.esc(o)}</b><br>${c.count} pesawat militer di wilayah udaranya sekarang<br><span class="mut">${Object.entries(c.roles).map(([r,n])=>r.toLowerCase()+' '+n).join(' · ')}</span>`:`<b>${T.esc(o)}</b><br><span class="mut">tidak ada pesawat militer ber-ADS-B terlacak</span>`}
        const r=risk[o];if(!r)return `<b>${T.esc(o)}</b><br><span class="mut">tidak ada sinyal risiko</span>`;
        return `<b>${T.esc(o)}</b><br>Risk: <b style="color:${(RISKC[r.level]||RISKC.LOW)[0]}">${r.level}</b> · skor ${r.score} · ${r.events} event${r.critical?' ('+r.critical+' critical)':''}${r.top?'<br>'+T.esc(r.top.title).slice(0,110):''}`}
      if(kind==='event')return `<b style="color:${SEVC[o.sev]||'#fff'}">${o.sev}</b> · ${T.esc(o.place||'')}<br>${T.esc(o.title)}<br><span class="mut">${T.esc(o.source||'')} · ${ago(o.ts)}</span>`;
      if(kind==='hot')return `<b>${T.esc(o.name)}</b><br>GDELT · ${T.esc(o.kind)} · ${o.count} event · ${o.mentions} penyebutan (24 jam)`;
      if(kind==='choke')return `<b>${T.esc(o.name)}</b><br>${o.level} · ${o.mentions} mentions${o.vessels?' · '+o.vessels+' vessels':''}${o.pw?'<br>'+T.fmt(o.pw.transits,0)+' transits/day ('+(o.pw.chg_pct==null?'—':T.sgn(o.pw.chg_pct,0)+'% 7d vs 30d')+')':''}`;
      if(kind==='port')return `${T.esc(o.name)}<br>${T.fmt(o.latest,0)} transits/day (${o.chg_pct==null?'—':T.sgn(o.chg_pct,0)+'% 7d vs 30d'})`;
      if(kind==='ship')return `<b>${T.esc(o[5]||'(tanpa nama)')}</b> · <span style="color:${SHIPC[o[4]]||'#fff'}">${T.esc(o[4])}</span><br>${T.fmt(o[3],1)} kn · arah ${o[2]}° · MMSI ${o[6]}`;
      if(kind==='inc')return `<b style="color:${SEVC[o.sev]||'#fff'}">${o.sev}</b> · ${T.esc(o.place||'')}<br>${T.esc(o.title)}<br><span class="mut">${T.esc(o.source||'')} · ${ago(o.ts)}</span>`;
      if(kind==='air')return `<b>${T.esc(o.cs||o.reg||o.hex)}</b> · ${T.esc(o.type||'?')} · <span style="color:${ROLEC[o.role]}">${o.role}</span>${o.emergency?' · <b class="dn">SQUAWK '+o.sqk+'</b>':''}<br>${ft(o.alt)} · ${o.gs==null?'—':T.fmt(o.gs,0)+' kt'} · arah ${o.trk==null?'—':T.fmt(o.trk,0)+'°'}<br><span class="mut">reg ${T.esc(o.reg||'—')} · posisi ${T.fmt(o.seen,0)} dtk sebelum pengambilan</span>`;
      if(kind==='cyc'){const vs=o.items.slice(0,4).map(v=>`${T.esc(v.victim)} <span class="mut">· ${T.esc(v.group)} · ${ago(v.ts)}</span>`).join('<br>');return `<b>${T.esc(o.name)}</b> · <span style="color:${CYC}">${o.items.length} korban ransomware</span><br>${vs}`}
      if(kind==='cnews')return `<b style="color:${CYC}">BERITA SIBER</b> · ${T.esc(o.place||'')}<br>${T.esc(o.title)}<br><span class="mut">${T.esc(o.source||'')} · ${ago(o.ts)} · lokasi dari judul</span>`;
      if(kind==='wport')return `<b>${T.esc(o[2])}</b> · ${T.esc(o[3])}<br>${o[4]==null?'—':T.fmt(o[4],1)+' kunjungan kapal/hari'} (7 hari)${o[5]==null?'':' · <span class="'+T.cls(o[5])+'">'+T.sgn(o[5],0)+'% vs 28 hari</span>'}<br><span class="mut">${T.esc(o[6]||'')} · ${T.fmt(o[7],0)} kapal/tahun · IMF PortWatch</span>`;
      if(kind==='pwcp')return `<b>${T.esc(o.name)}</b><br>${T.fmt(o.latest,0)} transit/hari · rata-rata 7h ${T.fmt(o.avg7,0)} vs 30h ${T.fmt(o.avg30,0)} (<span class="${T.cls(o.chg_pct)}">${T.sgn(o.chg_pct,0)}%</span>)<br><span class="mut">tanker ${o.tanker} · kargo ${o.cargo} · ${T.esc(o.date||'')}</span>`;
      if(kind==='apt')return `<b>${T.esc(o[2])}</b> · ${T.esc(o[3])}<br><span class="mut">${T.esc(o[4])}</span>`;
      if(kind==='anews')return `<b style="color:${SEVC[o.sev]||'#fff'}">${o.sev}</b> · ${T.esc(o.place||'')}<br>${T.esc(o.title)}<br><span class="mut">${T.esc(o.source||'')} · ${ago(o.ts)} · lokasi dari judul</span>`;
      if(kind==='vic')return `<b>${T.esc(o.victim)}</b><br><span style="color:${CYC}">${T.esc(o.group)}</span> · ${T.esc(o.country||'')}${o.sector?' · '+T.esc(o.sector):''}<br><span class="mut">diumumkan ${ago(o.ts)} · titik = negara (posisi di dalam negara acak)</span>`;
      if(kind==='press'){return `<b style="color:#ffb86b">${o.items.length} serangan diberitakan</b> · ${T.esc(o.country)}<br>`+o.items.slice(0,4).map(a=>`${T.esc(a.title).slice(0,90)} <span class="mut">· ${ago(a.ts)}</span>`).join('<br>')}
      return '';
    };
    const gl=T.globe(box,{tip:tipHtml});T._globe=gl;
    // ---- pemilih layer (di atas globe)
    const bar=h('div',{class:'gl-layers',role:'tablist'});
    const live=h('span',{class:'gl-live'});
    LAYERS.forEach(L=>bar.append(h('button',{class:'gl-lb','data-id':L.id,role:'tab',title:L.label,html:L.ic+'<span>'+L.label+'</span><em></em>',onclick:()=>{if(G.id!==L.id){G.id=L.id;show()}}})));
    box.append(bar,live);
    const setCount=(id,n)=>{const b=bar.querySelector(`[data-id="${id}"] em`);if(b)b.textContent=n==null?'':T.fmt(n,0)};
    // ---- scene per layer
    function sceneOf(id,d){
      if(id==='risk'){const risk=d.risk||{},countries={},labels=[];
        Object.entries(risk).sort((a,b)=>b[1].score-a[1].score).forEach(([n,r])=>{const c=RISKC[r.level];if(c)countries[n]=c;labels.push({name:n,level:r.level==='CRITICAL'?0:r.level==='HIGH'?1:2})});
        const pts=[];
        (d.hotspots||[]).forEach(p=>pts.push({lon:p.lon,lat:p.lat,shape:'glow',color:'rgba(245,158,11,.45)',r:5+Math.sqrt(p.count||1)*2.2,kind:'hot',obj:p,prio:-2}));
        (d.portwatch||[]).forEach(p=>{if(p.lat!=null)pts.push({lon:p.lon,lat:p.lat,color:'rgba(34,211,238,.75)',r:2.2,kind:'port',obj:p})});
        (d.chokepoints||[]).forEach(c=>pts.push({lon:c.lon,lat:c.lat,shape:'diamond',color:LVC[c.level]||'#f0a92e',kind:'choke',obj:c,prio:2}));
        (d.events||[]).forEach(e=>{if(e.lat!=null)pts.push({lon:e.lon,lat:e.lat,color:SEVC[e.sev]||'#3b82f6',r:e.sev==='CRITICAL'?4.5:3.4,pulse:e.sev==='CRITICAL',stroke:1,kind:'event',obj:e,prio:1})});
        return {countries,labels,points:pts,pulse:pts.some(p=>p.pulse)}}
      if(id==='sea'){const st=stat.sea||{},pts=[],countries={},labels=[],lines=[];
        // negara: perubahan kunjungan kapal 7 hari vs 28 hari (hijau naik, merah turun)
        Object.entries(st.countries||{}).forEach(([n,c])=>{if(c.chg==null)return;countries[n]=[Math.abs(c.chg)<5?FLAT:c.chg>0?UP:DN,Math.min(.55,.14+Math.abs(c.chg)/60)]});
        Object.entries(st.countries||{}).filter(([,c])=>c.chg!=null&&c.d7>=5).sort((a,b)=>Math.abs(b[1].chg)-Math.abs(a[1].chg)).slice(0,14)
          .forEach(([n,c],i)=>labels.push({name:n,level:i<4?0:i<9?1:2,text:n+' '+T.sgn(c.chg,0)+'%'}));
        if(st.routes)lines.push({geo:st.routes,color:'rgba(76,201,240,.30)',width:.8});
        (st.ports||[]).forEach(p=>pts.push({lat:p[0],lon:p[1],color:chgCol(p[5]),r:1.1+Math.min(3.2,Math.sqrt(p[4]||0)*.42),kind:'wport',obj:p,prio:-1}));
        (st.pw_chokepoints||[]).forEach(c=>pts.push({lon:c.lon,lat:c.lat,shape:'diamond',r:3.4,color:c.chg_pct==null?'#9aa3b8':c.chg_pct<=-10?DN:c.chg_pct>=10?UP:'#e8d5a3',kind:'pwcp',obj:c,prio:2}));
        (d.vessels||[]).forEach(v=>pts.push({lat:v[0],lon:v[1],heading:v[2],shape:'ship',color:SHIPC[v[4]]||SHIPC.other,kind:'ship',obj:v,prio:0}));
        (d.chokepoints||[]).forEach(c=>pts.push({lon:c.lon,lat:c.lat,shape:'diamond',r:5,color:LVC[c.level]||'#f0a92e',kind:'choke',obj:c,prio:3}));
        (d.incidents||[]).forEach(e=>{if(e.lat!=null)pts.push({lon:e.lon,lat:e.lat,color:SEVC[e.sev]||'#3b82f6',r:4,pulse:e.sev==='CRITICAL',stroke:1,kind:'inc',obj:e,prio:2})});
        return {countries,labels,lines,points:pts,pulse:pts.some(p=>p.pulse)}}
      if(id==='air'){const st=stat.air||{},countries={},labels=[],pts=[];
        // bandara dunia (titik kecil) -> peta penerbangan; negara diwarnai menurut jumlah pesawat militer di wilayah udaranya
        (st.airports||[]).forEach(a=>pts.push({lat:a[0],lon:a[1],color:'rgba(232,213,163,.42)',r:1.05,kind:'apt',obj:a,prio:-3}));
        Object.entries(d.countries||{}).sort((a,b)=>b[1].count-a[1].count).forEach(([n,c],i)=>{countries[n]=['#4cc9f0',Math.min(.6,.18+c.count*.035)];labels.push({name:n,level:i<4?0:i<9?1:2,text:n+' · '+c.count})});
        (d.news||[]).forEach(n=>{if(n.lat!=null)pts.push({lon:n.lon,lat:n.lat,color:n.sev==='CRITICAL'?SEVC.CRITICAL:'#ffb86b',r:3.6,pulse:n.sev==='CRITICAL',stroke:1,kind:'anews',obj:n,prio:2})});
        (d.aircraft||[]).forEach(a=>pts.push({lon:a.lon,lat:a.lat,heading:a.trk,shape:'plane',color:a.emergency?'#ff3b4e':ROLEC[a.role]||ROLEC.OTHER,r:a.role==='BOMBER'||a.role==='ISR'||a.role==='TANKER'?1.15:.95,kind:'air',obj:a,prio:a.emergency?3:1}));
        (d.emergencies||[]).forEach(a=>pts.push({lon:a.lon,lat:a.lat,heading:a.trk,shape:'plane',color:'#ff3b4e',r:1.2,pulse:false,kind:'air',obj:a,prio:3},{lon:a.lon,lat:a.lat,color:'#ff3b4e',r:5,pulse:true,stroke:1,prio:-9}));
        return {countries,labels,points:pts,pulse:pts.some(p=>p.pulse)}}
      // cyber: peta titik (1 titik = 1 korban ransomware 45 hari, di dalam negaranya), negara berwarna menurut jumlah,
      // serangan yang diberitakan pers per negara, dan berita siber yang lokasinya jelas
      const countries={},labels=[],pts=[],now=Date.now()/1000;
      Object.values(d.countries||{}).sort((a,b)=>b.victims-a.victims).forEach((c,i)=>{const n=c.victims;if(n)countries[c.name]=[CYC,n>=60?.6:n>=15?.45:n>=5?.32:.2];
        labels.push({name:c.name,level:i<4?0:i<10?1:2,text:c.name+' · '+n})});
      (d.victims||[]).forEach(v=>{if(!v.dot)return;const fresh=v.ts&&now-v.ts<86400;
        pts.push({lat:v.dot[0],lon:v.dot[1],color:fresh?'#ff8bff':'rgba(214,92,255,.8)',r:fresh?2.6:1.7,pulse:fresh,kind:'vic',obj:v,prio:fresh?1:0})});
      const byP={};(d.press||[]).forEach(a=>{if(a.lat!=null)(byP[a.country]=byP[a.country]||{country:a.country,lat:a.lat,lon:a.lon,items:[]}).items.push(a)});
      Object.values(byP).forEach(c=>pts.push({lon:c.lon,lat:c.lat,shape:'diamond',r:3+Math.min(3,Math.sqrt(c.items.length)),color:'#ffb86b',kind:'press',obj:c,prio:2}));
      (d.news||[]).forEach(n=>{if(n.lat!=null)pts.push({lon:n.lon,lat:n.lat,color:'#ffd166',r:3.2,stroke:1,kind:'cnews',obj:n,prio:2})});
      return {countries,labels,points:pts,pulse:pts.some(p=>p.pulse)};
    }
    // ---- legenda & ringkasan di atas globe
    // legenda utama (kiri atas) bisa dilipat di ponsel: hanya judul yang tampil, ketuk untuk membuka
    const ovl=(cls,style,html)=>{const e=h('div',{class:'lgd '+(cls||'lgd-col'),style});e.innerHTML=html;if(!cls)e.onclick=()=>e.classList.toggle('open');box.append(e);return e};
    const sw=(c,t,shape)=>`<div><i style="background:${c};${shape==='round'?'border-radius:50%':''}"></i>${t}</div>`;
    function overlays(id,d){
      box.querySelectorAll('.lgd').forEach(e=>e.remove());
      if(id==='risk'){
        ovl('',{left:'8px',top:'52px'},'<div class="mut lgh">COUNTRY RISK</div>'+['CRITICAL','HIGH','ELEVATED','LOW'].map(k=>sw(RISKC[k][0],k)).join('')+'<div class="mut" style="margin-top:3px"><i style="background:#18202c;border:1px solid #2f3b4f"></i>no signal</div><div class="mut" style="margin-top:3px"><i style="background:rgba(245,158,11,.6);border-radius:50%"></i>GDELT 24 jam</div>');
        ovl('lcp',{left:'8px',bottom:'8px',width:'250px'},'<div class="mut lgh">CHOKE POINT ALERT</div>'+(d.chokepoints||[]).slice(0,4).map(c=>`<div class="lrow"><span style="color:${LVC[c.level]}">${T.esc(c.name)}</span><span class="mut">${c.level}</span></div>`).join('')+(d.threat?`<div class="mut" style="margin-top:6px">THREAT: <span style="color:#ff5b6b">CRIT ${d.threat.CRITICAL}</span> · <span style="color:#f97316">HIGH ${d.threat.HIGH}</span> · <span style="color:#3b82f6">ACTIVE ${d.threat.ACTIVE}</span></div>`:''));
        if(d.gpr)ovl('lgpr',{right:'8px',bottom:'8px',width:'230px'},`<div class="mut lgh">GPR INDEX</div><div style="font-size:22px;font-weight:700">${T.fmt(d.gpr.latest,0)} <span class="${d.gpr.latest>=150?'dn':'warn'}" style="font-size:11px">${d.gpr.level}</span></div>${T.spark(d.gpr.series.slice(-120).map(x=>x.v),210,36,'#3b82f6')}`);
      }else if(id==='sea'){const st=d.status||{},ss=stat.sea||{};
        ovl('',{left:'8px',top:'52px'},'<div class="mut lgh">MARITIME</div>'+sw(UP,'kunjungan kapal naik ≥10%','round')+sw('rgba(76,201,240,.85)','pelabuhan (ukuran = kapal/hari)','round')+sw(DN,'turun ≥10%','round')
          +'<div class="mut" style="margin-top:4px">negara: 7 hari vs 28 hari</div><div style="margin-top:4px"><i style="background:rgba(76,201,240,.5);height:2px;width:14px;vertical-align:3px"></i>rute pelayaran</div>'
          +'<div><i style="background:#e8d5a3;transform:rotate(45deg);width:8px;height:8px"></i>choke point (transit)</div>'+Object.entries(SHIPC).filter(([k])=>['tanker','cargo','passenger'].includes(k)).map(([k,c])=>sw(c,'kapal '+k+(st.kinds&&st.kinds[k]?' · '+st.kinds[k]:''),'round')).join('')+sw(SEVC.CRITICAL,'insiden (berita)','round'));
        ovl('lcp',{left:'8px',bottom:'8px',width:'270px'},`<div class="mut lgh">CAKUPAN</div><div>${T.fmt((ss.ports||[]).length,0)} pelabuhan · ${T.fmt((ss.pw_chokepoints||[]).length,0)} choke point · data s/d ${T.esc(ss.activity_date||'…')}</div><div>${T.fmt(st.vessels,0)} kapal AIS live · ${T.esc(st.coverage||'')}</div>${st.sources&&!st.sources.aisstream_configured?'<div class="mut" style="margin-top:4px">Kapal live global: isi AISSTREAM_API_KEY (gratis, aisstream.io)</div>':''}`);
      }else if(id==='air'){const sa=stat.air||{};
        ovl('',{left:'8px',top:'52px'},'<div class="mut lgh">PESAWAT MILITER</div>'+ROLE_ORDER.map(r=>sw(ROLEC[r],r.toLowerCase()+((d.roles||{})[r]?' · '+d.roles[r]:''),'round')).join('')+sw('#ff3b4e','squawk darurat 7700','round')
          +sw('rgba(232,213,163,.6)','bandara ('+T.fmt((sa.airports||[]).length,0)+')','round')+sw('#ffb86b','berita penerbangan','round')+'<div class="mut" style="margin-top:4px">negara: jumlah pesawat militer di wilayah udaranya</div>');
        ovl('lcp',{left:'8px',bottom:'8px',width:'260px'},'<div class="mut lgh">KAWASAN PANTAUAN</div>'+((d.regions||[]).slice(0,5).map(r=>`<div class="lrow"><span>${T.esc(r.name)}</span><b>${r.count}</b></div>`).join('')||'<div class="mut">tidak ada pesawat militer di kawasan pantauan</div>'));
      }else{
        ovl('',{left:'8px',top:'52px'},`<div class="mut lgh">CYBER (DILAPORKAN)</div>${sw('rgba(214,92,255,.9)','1 titik = 1 korban ransomware','round')}${sw('#ff8bff','korban baru 24 jam (berdenyut)','round')}<div><i style="background:#ffb86b;transform:rotate(45deg);width:8px;height:8px"></i>serangan diberitakan pers</div>${sw('#ffd166','berita siber (lokasi dari judul)','round')}<div class="mut" style="margin-top:4px">${d.window_days||45} hari · posisi titik acak di dalam negara korban</div>`);
        ovl('lcp',{left:'8px',bottom:'8px',width:'250px'},'<div class="mut lgh">KELOMPOK PALING AKTIF</div>'+((d.groups||[]).slice(0,5).map(([g,n])=>`<div class="lrow"><span>${T.esc(g)}</span><b>${n}</b></div>`).join('')||'<div class="mut">—</div>'));
      }
    }
    // ---- panel kanan per layer
    const row=(o,lon,lat,...kids)=>h('div',{class:'feed',style:o,onmouseenter:()=>lon!=null&&gl.focus(lon,lat,Math.max(gl.k,2.4))},...kids);
    const put=(...kids)=>R.body.replaceChildren(...kids.flat().filter(k=>k!=null&&k!==false));   // anak kosong (null) tidak ikut ditulis
    function feed(id,d){
      const ph=R.head.firstChild;
      if(id==='risk'){ph.textContent='Geopolitical Events Feed';
        const top=Object.entries(d.risk||{}).sort((a,b)=>b[1].score-a[1].score).slice(0,8);
        const out=[];
        if(top.length)out.push(h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'TOP COUNTRY RISK'),...top.map(([n,r])=>h('span',{class:'chip',style:{borderColor:(RISKC[r.level]||RISKC.LOW)[0],color:(RISKC[r.level]||RISKC.LOW)[0]}},n+' · '+r.level))));
        out.push(...((d.events||[]).length?d.events.map(e=>h('a',{class:'feed',href:e.link,target:'_blank',rel:'noopener',style:{padding:'7px 10px',borderLeft:'3px solid '+SEVC[e.sev]},onmouseenter:()=>gl.focus(e.lon,e.lat,Math.max(gl.k,2.4))},
          h('div',{class:'m'},T.badge(e.sev),T.badge(e.cat,'TAG'),h('span',null,e.place),h('span',null,e.source),h('span',{class:'acc'},ago(e.ts))),h('div',{class:'tt'},e.title))):[h('div',{class:'msg'},'Belum ada event ter-geolokasi; menunggu feed berita.')]));
        put(...out);return}
      if(id==='sea'){ph.textContent='Maritime · Ports, Routes & AIS';const st=d.status||{},ss=stat.sea||{};
        const cs=Object.entries(ss.countries||{}).filter(([,c])=>c.chg!=null&&c.d7>=5);
        const mv=(arr,up)=>arr.slice().sort((a,b)=>up?b[1].chg-a[1].chg:a[1].chg-b[1].chg).slice(0,5).map(([n,c])=>h('div',{class:'lrow gf-mv'},h('span',null,n),h('b',{class:T.cls(c.chg)},T.sgn(c.chg,0)+'%'),h('span',{class:'mut'},T.fmt(c.d7,0)+'/hari')));
        const busy=(ss.ports||[]).filter(p=>p[4]!=null).sort((a,b)=>b[4]-a[4]).slice(0,8);
        put(
          h('div',{class:'gf-sum'},h('div',{class:'gf-h'},`AKTIVITAS PELABUHAN · 7 HARI vs 28 HARI · data s/d ${ss.activity_date||'…'}`),
            h('div',{class:'gf-2'},h('div',null,h('div',{class:'mut gf-sub'},'NAIK'),...mv(cs,true)),h('div',null,h('div',{class:'mut gf-sub'},'TURUN'),...mv(cs,false)))),
          h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'PELABUHAN TERSIBUK (KAPAL/HARI)'),...busy.map(p=>h('div',{class:'lrow gf-mv',style:{cursor:'pointer'},onmouseenter:()=>gl.focus(p[1],p[0],Math.max(gl.k,3))},h('span',null,p[2]+' · '+p[3]),h('b',null,T.fmt(p[4],0)),h('span',{class:T.cls(p[5])},p[5]==null?'—':T.sgn(p[5],0)+'%')))),
          h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'AIS'),h('div',{html:`${st.connected?'<span class="up">● live</span>':'<span class="dn">● offline</span>'} · ${T.fmt(st.vessels,0)} kapal · ${T.esc(st.coverage||'')}${st.error?' · <span class="dn">'+T.esc(st.error)+'</span>':''}`})),
          h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'CHOKE POINTS'),T.table([{label:'Point',left:true,get:r=>r.name,cls:()=>'wrap'},{label:'Level',node:(_,r)=>T.badge(r.level)},{label:'Transit/d',get:r=>r.pw&&r.pw.transits,fmt:v=>v==null?'—':T.fmt(v,0)},{label:'7d vs 30d',get:r=>r.pw&&r.pw.chg_pct,fmt:v=>v==null?'—':T.sgn(v,0)+'%',cls:v=>T.cls(v)}],d.chokepoints||[])),
          h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'INSIDEN MARITIM (BERITA 48 JAM)'),
          ...((d.incidents||[]).length?d.incidents.map(e=>h('a',{class:'feed',href:e.link,target:'_blank',rel:'noopener',style:{padding:'7px 10px',borderLeft:'3px solid '+(SEVC[e.sev]||'#3b82f6')},onmouseenter:()=>e.lat!=null&&gl.focus(e.lon,e.lat,Math.max(gl.k,2.4))},
            h('div',{class:'m'},T.badge(e.sev),h('span',null,e.place||'lokasi tidak disebut'),h('span',null,e.source),h('span',{class:'acc'},ago(e.ts))),h('div',{class:'tt'},e.title))):[h('div',{class:'msg'},'Belum ada insiden maritim di feed berita.')]));
        return}
      if(id==='air'){ph.textContent='Military Air Traffic · ADS-B';
        const list=(d.aircraft||[]).slice().sort((a,b)=>(b.emergency-a.emergency)||ROLE_ORDER.indexOf(a.role)-ROLE_ORDER.indexOf(b.role)||String(a.cs||'').localeCompare(String(b.cs||'')));
        put(
          h('div',{class:'gf-sum'},h('div',{class:'gf-h'},`${T.fmt(d.total||0,0)} PESAWAT MILITER TERLACAK · ${T.esc(d.source||'')}`),
            ...ROLE_ORDER.filter(r=>(d.roles||{})[r]).map(r=>h('span',{class:'chip',style:{borderColor:ROLEC[r],color:ROLEC[r]}},r+' · '+d.roles[r])),
            h('div',{class:'mut',style:{fontSize:'10.5px',marginTop:'6px'}},`data diambil ${ago(d.ts)} · diperbarui tiap ${Math.round((d.poll_sec||240)/60)} menit (batas gratis adsb.lol 500 permintaan/hari) · hanya pesawat yang memancarkan ADS-B`)),
          Object.keys(d.countries||{}).length?h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'WILAYAH UDARA DENGAN PESAWAT MILITER'),...Object.entries(d.countries).sort((a,b)=>b[1].count-a[1].count).slice(0,10).map(([n,c])=>h('span',{class:'chip'},n+' · '+c.count))):null,
          (d.emergencies||[]).length?h('div',{class:'gf-sum'},h('div',{class:'gf-h',style:{color:'#ff3b4e'}},'SQUAWK DARURAT'),...d.emergencies.map(a=>row({padding:'4px 0'},a.lon,a.lat,h('div',{class:'m'},h('b',null,a.cs||a.reg||a.hex),h('span',null,a.type||'?'),T.badge('SQUAWK '+a.sqk,'CRITICAL'),h('span',{class:'acc'},ft(a.alt)))))):null,
          (d.news||[]).length?h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'BERITA PENERBANGAN & WILAYAH UDARA (48 JAM)'):null,
          ...(d.news||[]).slice(0,20).map(n=>h('a',{class:'feed',href:n.link,target:'_blank',rel:'noopener',style:{padding:'7px 10px',borderLeft:'3px solid '+(n.sev==='CRITICAL'?SEVC.CRITICAL:'#ffb86b')},onmouseenter:()=>n.lat!=null&&gl.focus(n.lon,n.lat,Math.max(gl.k,2.4))},
            h('div',{class:'m'},T.badge(n.sev),n.place?h('span',null,n.place):null,h('span',null,n.source),h('span',{class:'acc'},ago(n.ts))),h('div',{class:'tt'},n.title))),
          h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'PESAWAT MILITER'),
          ...list.slice(0,150).map(a=>row({padding:'6px 10px',borderLeft:'3px solid '+(a.emergency?'#ff3b4e':ROLEC[a.role])},a.lon,a.lat,
            h('div',{class:'m'},h('b',{style:{color:'#ece7da'}},a.cs||a.reg||a.hex),h('span',null,a.type||'?'),h('span',{style:{color:ROLEC[a.role]}},a.role),a.emergency?T.badge('SQUAWK '+a.sqk,'CRITICAL'):null,h('span',{class:'acc'},ft(a.alt))),
            h('div',{class:'mut',style:{fontSize:'11px'}},`${a.gs==null?'—':T.fmt(a.gs,0)+' kt'} · arah ${a.trk==null?'—':T.fmt(a.trk,0)+'°'} · ${T.fmt(a.lat,2)}, ${T.fmt(a.lon,2)}`))));
        return}
      ph.textContent='Cyber Attacks · Reported';
      put(
        h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'KORBAN RANSOMWARE DIUMUMKAN'),
          h('div',{class:'gf-kpis'},h('div',null,h('b',null,T.fmt(d.d1||0,0)),h('span',null,'24 jam')),h('div',null,h('b',null,T.fmt(d.d7||0,0)),h('span',null,'7 hari')),h('div',null,h('b',null,T.fmt((d.victims||[]).length,0)),h('span',null,(d.window_days||45)+' hari')),h('div',null,h('b',null,T.fmt(Object.keys(d.countries||{}).length,0)),h('span',null,'negara'))),
          d.error?h('div',{class:'dn',style:{fontSize:'11px'}},'ransomware.live: '+d.error):null),
        h('div',{class:'gf-sum'},h('div',{class:'gf-h'},'NEGARA PALING TERDAMPAK'),...Object.values(d.countries||{}).sort((a,b)=>b.victims-a.victims).slice(0,10).map(c=>h('span',{class:'chip',style:{borderColor:CYC,color:CYC}},c.name+' · '+c.victims)),
          (d.sectors||[]).length?h('div',{class:'gf-h',style:{marginTop:'8px'}},'SEKTOR'):null,...(d.sectors||[]).slice(0,6).map(([n,c])=>h('span',{class:'chip'},n+' · '+c))),
        (d.press||[]).length?h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'SERANGAN DIBERITAKAN PERS'):null,
        ...(d.press||[]).slice(0,20).map(a=>h(a.link?'a':'div',{class:'feed',href:a.link||null,target:a.link?'_blank':null,rel:'noopener',style:{padding:'7px 10px',borderLeft:'3px solid #ffb86b'},onmouseenter:()=>a.lat!=null&&gl.focus(a.lon,a.lat,Math.max(gl.k,2.2))},
          h('div',{class:'m'},h('span',null,a.country||'negara tidak pasti'),h('span',null,a.domain||''),h('span',{class:'acc'},ago(a.ts))),h('div',{class:'tt'},a.title))),
        h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'BERITA SERANGAN SIBER'),
        ...((d.news||[]).slice(0,25).map(n=>h('a',{class:'feed',href:n.link,target:'_blank',rel:'noopener',style:{padding:'7px 10px',borderLeft:'3px solid #ffb86b'},onmouseenter:()=>n.lat!=null&&gl.focus(n.lon,n.lat,Math.max(gl.k,2.4))},
          h('div',{class:'m'},n.place?h('span',null,n.place):null,h('span',null,n.source),h('span',{class:'acc'},ago(n.ts))),h('div',{class:'tt'},n.title)))),
        h('div',{class:'gf-h',style:{padding:'8px 10px 2px'}},'KORBAN TERBARU (RANSOMWARE.LIVE)'),
        ...(d.victims||[]).slice(0,60).map(v=>h(v.link?'a':'div',{class:'feed',href:v.link||null,target:v.link?'_blank':null,rel:'noopener',style:{padding:'6px 10px',borderLeft:'3px solid '+CYC},onmouseenter:()=>v.dot&&gl.focus(v.dot[1],v.dot[0],Math.max(gl.k,2.4))},
          h('div',{class:'m'},h('span',{style:{color:CYC}},v.group),h('span',null,v.country||'negara tidak disebut'),v.sector?h('span',null,v.sector):null,h('span',{class:'acc'},ago(v.ts))),h('div',{class:'tt'},v.victim))));
    }
    // ---- muat & tampilkan
    function apply(id,d){
      cache[id]=d;stamp[id]=Date.now();
      if(id==='sea')setCount('sea',(d.vessels||[]).length);
      if(id==='air')setCount('air',d.total);
      if(id==='cyber')setCount('cyber',d.d1);
      if(id==='risk')setCount('risk',(d.events||[]).length);
      if(G.id!==id)return;
      gl.setScene(sceneOf(id,d));overlays(id,d);feed(id,d);tickLive();
    }
    const STATIC={sea:'geo/sea_static',air:'geo/air_static'};
    function loadStatic(id){if(!STATIC[id]||stat[id])return;stat[id]={};   // sekali per sesi: pelabuhan/rute/bandara jarang berubah
      T.api(STATIC[id]).then(d=>{stat[id]=d;if(G.id===id&&cache[id])apply(id,cache[id])}).catch(()=>{stat[id]=null})}
    function load(id,force){const L=LAYERS.find(x=>x.id===id);loadStatic(id);
      return T.api(L.ep,L.params,{force:!!force,bg:!!force}).then(d=>apply(id,d)).catch(e=>{if(G.id===id&&!cache[id])put(h('div',{class:'msg err'},e.message))})}
    function tickLive(){const t=stamp[G.id];live.innerHTML=t?`<i></i>LIVE · ${T.ago(t/1000)}`:'<i></i>memuat…'}
    function show(){
      [...bar.children].forEach(b=>b.classList.toggle('on',b.dataset.id===G.id));
      if(cache[G.id])apply(G.id,cache[G.id]);else{put(h('div',{class:'msg'},'Memuat…'));gl.setScene(null);box.querySelectorAll('.lgd').forEach(e=>e.remove());tickLive()}
      load(G.id,!!cache[G.id]);
    }
    show();
    if(G.id!=='risk')load('risk');            // tooltip negara & hitungan RISK tetap tersedia
    LAYERS.forEach(L=>T.every(L.every,()=>{if(G.id===L.id&&!document.hidden)load(L.id,true)}));
    T.every(5000,tickLive);
  }
  go();
};
})();
