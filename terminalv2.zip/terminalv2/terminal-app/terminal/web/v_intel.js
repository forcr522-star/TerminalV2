(function(){
const h=T.h;
const SEC_COL={'FAST NEWS':'#3b82f6','MARKETS':'#22c55e','GEOPOLITICS':'#ef4444','CRYPTO':'#f59e0b','COMMODITIES':'#eab308','FOREX':'#22d3ee','TECH':'#a78bfa','UNITED STATES':'#60a5fa','EUROPE':'#34d399','ASIA':'#fb923c','MIDDLE EAST':'#f87171','INDONESIA':'#f43f5e'};
function item(f){
  return h('a',{class:'feed'+(f.prio==='CRIT'||f.flash?' crit':''),href:f.link,target:'_blank'},
    h('div',{class:'m'},h('span',{class:'acc'},T.ago(f.ts)),f.t1?T.badge('T1'):null,f.flash?T.badge('FLASH'):null,f.prio?T.badge(f.prio):null,f.sent?T.badge(f.sent):null,...(f.tags||[]).map(t=>T.badge(t,'TAG')),h('span',null,f.source)),
    h('div',{class:'tt'},f.title));
}
T.Views.intel=function(root){
  const S=T.mem('intel',{tab:'feeds'});let tab=S.tab;
  const tabs=T.tabs([{id:'feeds',label:'Feeds'},{id:'catalyst',label:'Catalyst'},{id:'map',label:'Catalyst Map'},{id:'research',label:'Research'}],tab,t=>{tab=S.tab=t;go()});
  const body=h('div');root.append(tabs,body);
  function go(){T.dispose();({feeds,catalyst,map,research}[tab]||feeds)()}
  function feeds(){
    const bar=h('div',{class:'row',style:{marginBottom:'8px',color:'#7d8498'}});
    const board=h('div',{class:'board'});
    const q=h('input',{class:'in',placeholder:'Cari headline…',style:{marginLeft:'auto'},onchange:e=>run(e.target.value.trim())});
    body.replaceChildren(bar,board);bar.append(h('span',{id:'stats'}),q);
    async function run(query,force){
      try{
        const d=await T.api('intel/feed',query?{q:query}:null,{force:force===true});
        board.replaceChildren();
        if(d.search){board.style.display='block';board.append(h('div',{class:'panel',style:{padding:'4px 12px'}},...d.search.map(item)));return}
        board.style.display='';
        const s=d.board.stats;
        bar.firstChild.innerHTML=`<b class="acc">${s.session}</b> · ${s.articles} ARTICLES · FLOW ${s.flow}/M · ${s.spikes} SPIKES · ${s.priority} PRIORITY · ${s.delta} DELTA · feeds ${s.feeds_ok}/${s.feeds_total}`;
        Object.entries(d.board.sections).forEach(([name,sec])=>{
          const col=h('div',{class:'col'},h('div',{class:'ph'},h('span',{style:{color:SEC_COL[name]}},'● '+name),h('span',{class:'sp'}),sec.spike?h('span',{class:'warn'},'SPIKE '+sec.spike):null,h('span',null,sec.recent+' / '+sec.total)),h('div',{class:'pb'},...(sec.items.length?sec.items.map(item):[h('div',{class:'msg'},'Belum ada item')])));
          board.append(col);
        });
        if(!d.board.stats.articles)board.prepend(h('div',{class:'msg',style:{gridColumn:'1/-1'}},'Mengambil feed pertama… coba lagi beberapa detik.'));
      }catch(e){board.replaceChildren(h('div',{class:'msg err'},e.message))}
    }
    run();T.every(60000,()=>{if(!q.value)run(null,true)});
  }
  function catalyst(){
    const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'1fr 1.6fr',height:'calc(100vh - 170px)',minHeight:'400px'}});
    body.replaceChildren(g);
    const L=T.panel('Catalyst Feed',{np:1}),R=T.panel('Detail');g.append(L.el,R.el);
    T.load(L.body,T.api('intel/catalysts'),d=>{
      const show=c=>{
        R.body.replaceChildren(h('div',{class:'row'},T.badge(c.impact+' IMPACT',c.impact),T.badge(c.bias),h('span',{class:'mut'},c.region+' · '+c.asset)),
          h('h3',{style:{margin:'8px 0'}},c.title),
          h('div',{class:'txt'},c.analysis||c.text),
          h('div',{class:'mut',style:{margin:'12px 0 4px',fontSize:'9px',letterSpacing:'.06em'}},'MARKET IMPACT'),
          T.table([{label:'Instrument',left:true,k:'sym'},{label:'Bias',node:(_,r)=>T.badge(r.dir)},{label:'Strength',k:'weight'}],c.instruments),
          h('div',{class:'mut',style:{margin:'12px 0 4px',fontSize:'9px',letterSpacing:'.06em'}},`HEADLINES (${c.count} / 36h)`),
          ...c.headlines.map(x=>h('a',{class:'feed',href:x.link,target:'_blank'},h('div',{class:'m'},h('span',{class:'acc'},T.ago(x.ts)),h('span',null,x.source)),h('div',{class:'tt'},x.title))));
      };
      if(!d.catalysts.length){L.body.append(h('div',{class:'msg'},'Belum ada katalis; tunggu feed berita terkumpul.'));return}
      L.body.append(T.table([{label:'Title',left:true,get:r=>r.title,cls:()=>'wrap'},{label:'Region',k:'region'},{label:'Bias',node:(_,r)=>T.badge(r.bias)},{label:'Impact',node:(_,r)=>T.badge(r.impact)}],d.catalysts,{onRow:show}));
      show(d.catalysts[0]);
    });
  }
  function map(){
    const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'2fr 1fr',height:'calc(100vh - 170px)',minHeight:'420px'}});
    body.replaceChildren(g);
    const L=T.panel('Cross-Asset Catalyst Transmission Map',{np:1,bodyStyle:{padding:'6px'}}),R=T.panel('Catalyst & Asset Relationships',{np:1});g.append(L.el,R.el);
    T.load(L.body,T.api('intel/map'),d=>{
      if(!d.graph.nodes.length){L.body.append(h('div',{class:'msg'},'Belum ada data katalis'));return}
      const cols=['#f59e0b','#a78bfa','#22d3ee','#3b82f6'],cats=d.graph.categories;
      // Legenda statis (bukan kontrol): peta ini hanya untuk dibaca.
      L.body.append(h('div',{class:'row',style:{padding:'2px 4px 6px',fontSize:'10px'}},...cats.map((n,i)=>h('span',{class:'mut'},h('i',{style:{display:'inline-block',width:'9px',height:'9px',borderRadius:'50%',background:cols[i],marginRight:'5px'}}),n)),
        h('span',{class:'mut'},h('i',{style:{display:'inline-block',width:'14px',height:'2px',background:'#22c55e',marginRight:'4px',verticalAlign:'middle'}}),'bullish'),h('span',{class:'mut'},h('i',{style:{display:'inline-block',width:'14px',height:'2px',background:'#ef4444',marginRight:'4px',verticalAlign:'middle'}}),'bearish')));
      // Tata letak tetap 4 kolom (Catalyst → Thesis → Impact → Instrument) dengan jarak vertikal seragam:
      // tidak ada simulasi gaya, jadi posisi tidak bergeser dan label tidak bertumpuk.
      const W=Math.max(L.body.clientWidth-12,760),PAD=34,avail=Math.max(380,L.body.clientHeight-40),COLW=(W-80-150)/3;
      const byCat=[[],[],[],[]];d.graph.nodes.forEach(n=>byCat[n.category].push(n));
      const maxRows=Math.max(...byCat.map(a=>a.length)),ROW=Math.max(30,Math.min(50,(avail-PAD*2)/maxRows)),H=Math.max(avail,maxRows*ROW+PAD*2);
      const pos={};
      byCat.forEach((arr,ci)=>{const step=(H-PAD*2)/Math.max(1,arr.length);arr.forEach((n,i)=>{pos[n.id]=[40+ci*COLW,PAD+step*(i+0.5)]})});
      const box=h('div',{class:'chart nomap',style:{width:W+'px',height:H+'px'}});L.body.append(box);
      T.chart(box,{tooltip:{show:false},animation:false,
        series:[{type:'graph',layout:'none',roam:false,draggable:false,silent:true,left:0,right:0,top:0,bottom:0,
          label:{show:true,color:'#d7dbe6',fontSize:11,position:'right',distance:8,width:COLW-60,overflow:'break',lineHeight:13},
          data:[{name:'',id:'__a',x:0,y:0,symbolSize:0,label:{show:false}},{name:' ',id:'__b',x:W,y:H,symbolSize:0,label:{show:false}},...d.graph.nodes.map(n=>({name:n.name,id:n.id,x:pos[n.id][0],y:pos[n.id][1],symbolSize:Math.min(24,Math.max(12,n.symbolSize*0.6)),itemStyle:{color:cols[n.category]}}))],
          links:d.graph.links.map(l=>({source:l.source,target:l.target,lineStyle:{color:l.bias==='BULLISH'?'#22c55e':l.bias==='BEARISH'?'#ef4444':'#64748b',width:1+l.value/50,opacity:.55,curveness:.12}})),
          edgeSymbol:['none','arrow'],edgeSymbolSize:5}]});
      R.body.append(T.table([{label:'Catalyst',left:true,get:r=>r.title,cls:()=>'wrap'},{label:'Bias',node:(_,r)=>T.badge(r.bias)},{label:'Str',k:'strength',fmt:v=>T.fmt(v,0)}],d.catalysts));
    });
  }
  function research(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('intel/research'),d=>{
      wrap.append(h('div',{class:'panel',style:{padding:'14px 16px',marginBottom:'8px'}},h('div',{style:{fontSize:'17px',fontWeight:700}},'Cross-asset research to evaluate shifts in market expectations.'),h('div',{class:'mut',style:{marginTop:'6px'}},d.llm?'Ringkasan ditulis AI lokal (Ollama, '+((d.llm_status&&d.llm_status.model)||'')+') dari headline terkini; yang belum selesai ditulis memakai ringkasan otomatis.':'Ringkasan dibuat otomatis (rule-based). Jalankan install.bat untuk memasang AI lokal (Ollama) agar narasi ditulis model.')));
      if(!d.publications.length)wrap.append(h('div',{class:'msg'},'Belum ada publikasi'));
      d.publications.forEach((p,i)=>wrap.append(h('div',{class:'panel',style:{padding:'12px 14px',marginBottom:'6px'}},h('div',{class:'row'},h('b',{class:'acc'},String(i+1).padStart(2,'0')),T.badge(p.asset.toUpperCase(),'TAG'),T.badge(p.impact),h('span',{class:'mut',style:{marginLeft:'auto'}},new Date(p.ts*1000).toLocaleString('en-GB'))),h('div',{style:{fontWeight:700,fontSize:'14px',margin:'6px 0'}},p.title,p.ai?h('span',{class:'badge b-TAG',style:{marginLeft:'8px'}},'AI'):null),h('div',{class:'txt'},p.body),h('div',{class:'row',style:{marginTop:'6px'}},...p.instruments.map(x=>h('span',{class:'chip'},x))))));
    });
  }
  go();
};
})();
