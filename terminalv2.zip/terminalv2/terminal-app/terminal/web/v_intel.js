(function(){
const h=T.h;
const SEC_COL={'FAST NEWS':'#3b82f6','MARKETS':'#21c993','GEOPOLITICS':'#ff5b6b','CRYPTO':'#f59e0b','COMMODITIES':'#f0a92e','FOREX':'#22d3ee','TECH':'#a78bfa','UNITED STATES':'#60a5fa','EUROPE':'#34d399','ASIA':'#fb923c','MIDDLE EAST':'#f87171','INDONESIA':'#f43f5e'};
function item(f){
  return h('a',{class:'feed'+(f.prio==='CRIT'||f.flash?' crit':''),href:f.link,target:'_blank'},
    h('div',{class:'m'},h('span',{class:'acc'},T.ago(f.ts)),f.fast?h('span',{class:'fastb',title:'Sumber cepat (squawk)'},'⚡'):null,f.t1?T.badge('T1'):null,f.flash?T.badge('FLASH'):null,f.prio?T.badge(f.prio):null,f.sent?T.badge(f.sent):null,...(f.tags||[]).map(t=>T.badge(t,'TAG')),h('span',null,f.source)),
    h('div',{class:'tt'},f.title));
}
T.Views.intel=function(root){
  const S=T.mem('intel',{tab:'squawk'});let tab=S.tab;
  const tabs=T.tabs([{id:'squawk',label:'⚡ Squawk'},{id:'feeds',label:'Feeds'},{id:'catalyst',label:'Catalyst'},{id:'map',label:'Catalyst Map'},{id:'research',label:'Research'}],tab,t=>{tab=S.tab=t;go()});
  const body=h('div');root.append(tabs,body);
  const squawk=()=>T.squawkView(body);
  function go(){T.dispose();({squawk,feeds,catalyst,map,research}[tab]||squawk)()}
  function feeds(){
    const bar=h('div',{class:'row',style:{marginBottom:'8px',color:'#8a8f9c'}});
    const board=h('div',{class:'board'});
    const q=h('input',{class:'in',placeholder:'Cari headline…',style:{marginLeft:'auto'},onchange:e=>run(e.target.value.trim())});
    body.replaceChildren(bar,board);bar.append(h('span',{id:'stats'}),q);
    async function run(query,force){
      try{
        const d=await T.api('intel/feed',query?{q:query}:null,{force:force===true});
        board.replaceChildren();
        if(d.search){board.style.display='block';board.append(h('div',{class:'panel',style:{padding:'4px 12px'}},...d.search.map(item)));return}
        board.style.display='';
        const s=d.board.stats;
        bar.firstChild.innerHTML=`<b class="acc">${s.session}</b> · ${s.articles} ARTICLES · FLOW ${s.flow}/M · ${s.spikes} SPIKES · ${s.priority} PRIORITY · ${s.delta} DELTA · feeds ${s.feeds_ok}/${s.feeds_total}`;
        Object.entries(d.board.sections).forEach(([name,sec])=>{
          const col=h('div',{class:'col'},h('div',{class:'ph'},h('span',{style:{color:SEC_COL[name]}},'● '+name),h('span',{class:'sp'}),sec.spike?h('span',{class:'warn'},'SPIKE '+sec.spike):null,h('span',null,sec.recent+' / '+sec.total)),h('div',{class:'pb'},...(sec.items.length?sec.items.map(item):[h('div',{class:'msg'},'Belum ada item')])));
          board.append(col);
        });
        if(!d.board.stats.articles)board.prepend(h('div',{class:'msg',style:{gridColumn:'1/-1'}},'Mengambil feed pertama… coba lagi beberapa detik.'));
      }catch(e){board.replaceChildren(h('div',{class:'msg err'},e.message))}
    }
    run();T.every(60000,()=>{if(!q.value)run(null,true)});
  }
  function catalyst(){
    const g=h('div',{class:'grid resp',style:{gridTemplateColumns:'1fr 1.6fr',height:'calc(100vh - 192px)',minHeight:'400px'}});
    body.replaceChildren(g);
    const L=T.panel('Catalyst Feed',{np:1}),R=T.panel('Detail');g.append(L.el,R.el);
    T.load(L.body,T.api('intel/catalysts'),d=>{
      const show=c=>{
        R.body.replaceChildren(h('div',{class:'row'},T.badge(c.impact+' IMPACT',c.impact),T.badge(c.bias),h('span',{class:'mut'},c.region+' · '+c.asset)),
          h('h3',{style:{margin:'8px 0'}},c.title),
          h('div',{class:'txt'},c.analysis||c.text),
          h('div',{class:'mut',style:{margin:'12px 0 4px',fontSize:'9px',letterSpacing:'.06em'}},'MARKET IMPACT'),
          T.table([{label:'Instrument',left:true,k:'sym'},{label:'Bias',node:(_,r)=>T.badge(r.dir)},{label:'Strength',k:'weight'}],c.instruments),
          h('div',{class:'mut',style:{margin:'12px 0 4px',fontSize:'9px',letterSpacing:'.06em'}},`HEADLINES (${c.count} / 36h)`),
          ...c.headlines.map(x=>h('a',{class:'feed',href:x.link,target:'_blank'},h('div',{class:'m'},h('span',{class:'acc'},T.ago(x.ts)),h('span',null,x.source)),h('div',{class:'tt'},x.title))));
      };
      if(!d.catalysts.length){L.body.append(h('div',{class:'msg'},'Belum ada katalis; tunggu feed berita terkumpul.'));return}
      L.body.append(T.table([{label:'Title',left:true,get:r=>r.title,cls:()=>'wrap'},{label:'Region',k:'region'},{label:'Bias',node:(_,r)=>T.badge(r.bias)},{label:'Impact',node:(_,r)=>T.badge(r.impact)}],d.catalysts,{onRow:show}));
      show(d.catalysts[0]);
    });
  }
  function map(){T.catalystMap(body)}
  function research(){
    const wrap=h('div');body.replaceChildren(wrap);
    T.load(wrap,T.api('intel/research'),d=>{
      wrap.append(h('div',{class:'panel',style:{padding:'14px 16px',marginBottom:'8px'}},h('div',{style:{fontSize:'17px',fontWeight:700}},'Cross-asset research to evaluate shifts in market expectations.'),h('div',{class:'mut',style:{marginTop:'6px'}},d.llm?'Ringkasan ditulis AI lokal (Ollama, '+((d.llm_status&&d.llm_status.model)||'')+') dari headline terkini; yang belum selesai ditulis memakai ringkasan otomatis.':'Ringkasan dibuat otomatis (rule-based). Jalankan install.bat untuk memasang AI lokal (Ollama) agar narasi ditulis model.')));
      if(!d.publications.length)wrap.append(h('div',{class:'msg'},'Belum ada publikasi'));
      d.publications.forEach((p,i)=>wrap.append(h('div',{class:'panel',style:{padding:'12px 14px',marginBottom:'6px'}},h('div',{class:'row'},h('b',{class:'acc'},String(i+1).padStart(2,'0')),T.badge(p.asset.toUpperCase(),'TAG'),T.badge(p.impact),h('span',{class:'mut',style:{marginLeft:'auto'}},new Date(p.ts*1000).toLocaleString('en-GB'))),h('div',{style:{fontWeight:700,fontSize:'14px',margin:'6px 0'}},p.title,p.ai?h('span',{class:'badge b-TAG',style:{marginLeft:'8px'}},'AI'):null),h('div',{class:'txt'},p.body),h('div',{class:'row',style:{marginTop:'6px'}},...p.instruments.map(x=>h('span',{class:'chip'},x))))));
    });
  }
  go();
};
})();
