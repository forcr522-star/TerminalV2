// =====================================================================================================================
// MENU HEATMAP & FOOTPRINT (kripto, Binance Spot)
//   Chart canvas sendiri: heatmap LIQUIDATION (model gaya CoinGlass; makin terang = makin besar), candle, big trade (bubble),
//   key liquidation level, footprint (muncul saat chart di-zoom), volume delta. Kanan: Liquidation map, Key liquidation
//   levels, Market overview.
//   Indikator kiri-atas (ikon mata) disimpan per browser (localStorage) -> setiap user punya tampilan sendiri.
//   Admin: tombol PILIH PAIR (hanya pair terpilih yang dipantau server). User: pilih pair dari daftar admin.
// =====================================================================================================================
(function(){
const h=T.h;
const TFS=['M1','M5','M15','M30','H1','H4','D1'];
const NICE=[1,2,5,10,20,25,50,100,200,250,500,1000,2000,2500,5000,10000,20000,25000,50000,100000];
const IND=[
  {id:'heat',name:'Liquidation Heatmap',tip:'Model level likuidasi (gaya CoinGlass) dihitung dari candle Binance: makin terang = makin besar estimasi likuidasi di harga itu. Pita berakhir saat harga menyapunya.'},
  {id:'bubbles',name:'Big Trades',tip:'Riwayat BIG TRADE: satu order taker yang sangat besar (bukan jumlah order kecil). Ambang naik sesuai timeframe: M1 = 0,1% order terbesar 24 jam … D1 = 0,002% terbesar. Hijau = beli agresif, merah = jual agresif; makin besar bola = makin besar nilainya.'},
  {id:'levels',name:'Key Liquidation Levels',tip:'Kluster estimasi likuidasi terbesar yang masih aktif. Garis kuning dari saat level mulai terbentuk; harga sering tertarik ke area ini.'},
  {id:'footprint',name:'Footprint',tip:'Nilai jual × beli agresif per harga di tiap candle. Muncul otomatis saat chart di-zoom (timeframe apa pun).'},
  {id:'delta',name:'Volume Delta',tip:'Beli agresif − jual agresif per candle (data taker Binance).'},
  {id:'liqmap',name:'Liquidation Map',tip:'Level likuidasi aktif saat ini per baris harga + kurva kumulatif (merah = likuidasi short di atas harga, hijau = likuidasi long di bawah harga).'}
];
const DEF_IND={heat:true,bubbles:true,levels:true,footprint:true,delta:true,liqmap:true,_open:!(window.innerWidth<700),sens:25,line:false};
// Meter sensitivitas heatmap (0..100): kanan = lebih kuning (likuiditas lebih kecil sudah dianggap besar), kiri = lebih redup.
// Titik jangkar [sensitivitas, persentil nilai yang dianggap 'penuh', pangkat warna]; nilai di antaranya diinterpolasi.
const SENS=[[0,0.9995,1.8],[35,0.995,1.0],[70,0.97,0.7],[100,0.85,0.45]];
const sensAt=s=>{s=Math.max(0,Math.min(100,+s||0));for(let i=1;i<SENS.length;i++){const[a,qa,ga]=SENS[i-1],[b,qb,gb]=SENS[i];if(s<=b){const f=(s-a)/(b-a);return {q:qa+(qb-qa)*f,g:ga+(gb-ga)*f}}}return {q:SENS[3][1],g:SENS[3][2]}};
const METER_BARS=10;
const LS_IND='hm.ind.v1',LS_VIEW='hm.view.v1';
const FP_BW=24;            // lebar candle (px) minimal untuk candle footprint (kotak per harga berwarna delta)
const FP_TEXT=56;          // lebar candle (px) minimal untuk angka jual × beli di tiap harga
const AX=74,TAX=20,DP=64;  // lebar sumbu harga, tinggi sumbu waktu, tinggi panel delta
const lsGet=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k)||'null');return Object.assign({},d,v&&typeof v==='object'?v:{})}catch(e){return Object.assign({},d)}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const cm=v=>{if(v==null||isNaN(v))return '—';const a=Math.abs(v),s=v<0?'-':'';return a>=1e9?s+(a/1e9).toFixed(2)+'B':a>=1e6?s+(a/1e6).toFixed(a>=1e8?0:a>=1e7?1:2)+'M':a>=1e3?s+(a/1e3).toFixed(a>=1e5?0:1)+'K':s+a.toFixed(0)};
const fp=(v,d)=>v==null||isNaN(v)?'—':Number(v).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const p2=n=>String(n).padStart(2,'0');
const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const tlab=(ts,sec,full)=>{const d=new Date(ts*1000);const hm=p2(d.getHours())+':'+p2(d.getMinutes());if(sec>=86400)return p2(d.getDate())+' '+MON[d.getMonth()]+(full?' '+d.getFullYear():'');return full||d.getHours()+d.getMinutes()===0?p2(d.getDate())+' '+MON[d.getMonth()]+' '+hm:hm};
const EYE=on=>on?'<svg viewBox="0 0 24 24" width="15" height="15"><path d="M1.5 12S5.5 4.5 12 4.5 22.5 12 22.5 12 18.5 19.5 12 19.5 1.5 12 1.5 12Z" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="12" cy="12" r="3.2" fill="currentColor"/></svg>'
  :'<svg viewBox="0 0 24 24" width="15" height="15"><path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10.5 7 10.5 7a17 17 0 0 1-3.2 4M6.6 6.7A17.5 17.5 0 0 0 1.5 12S5.5 19 12 19a9.6 9.6 0 0 0 4.4-1.1M9.9 9.9a3 3 0 0 0 4.2 4.2" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>';

// Palet heatmap gaya CoinGlass (viridis): ungu tua (kecil) -> biru -> teal -> hijau -> kuning (terbesar). Indeks 0 = tanpa data.
const PAL=(()=>{
  const S=[[0,[0,0,0,0]],[1/255,[68,1,84,255]],[.125,[71,44,122,255]],[.25,[59,81,139,255]],[.375,[44,113,142,255]],[.5,[33,144,141,255]],[.625,[39,173,129,255]],[.75,[92,200,99,255]],[.875,[170,220,50,255]],[1,[253,231,37,255]]];
  const p=new Uint8ClampedArray(256*4);
  for(let i=0;i<256;i++){const t=i/255;let j=0;while(j<S.length-2&&t>S[j+1][0])j++;const[a,ca]=S[j],[b,cb]=S[j+1];const f=(t-a)/(b-a||1);for(let c=0;c<4;c++)p[i*4+c]=Math.round(ca[c]+(cb[c]-ca[c])*f)}
  return p;
})();
const palCss=i=>`rgba(${PAL[i*4]},${PAL[i*4+1]},${PAL[i*4+2]},${(PAL[i*4+3]/255).toFixed(2)})`;
const niceNum=x=>{const e=Math.pow(10,Math.floor(Math.log10(x)));const f=x/e;return (f<=1?1:f<=2?2:f<=2.5?2.5:f<=5?5:10)*e};

async function postControl(body){
  const r=await fetch('/api/heatmap/control',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  if(r.status===401){location.reload();throw new Error('Sesi berakhir')}
  let j={};try{j=await r.json()}catch(e){}
  if(!r.ok||j.error)throw new Error(j.error||('HTTP '+r.status));
  return j.state;
}

T.Views.heatmap=function(root){
  document.querySelectorAll('.hf-modal').forEach(e=>e.remove());
  const g=T.gen,admin=T.role==='admin';
  const alive=()=>g===T.gen&&root.isConnected;
  const VW=lsGet(LS_VIEW,{sym:null,tf:'M5',mode:'liq'});
  if(!TFS.includes(VW.tf))VW.tf='M5';
  VW.mode='liq';                         // menu ini hanya LIQUIDATION (mode orderbook dihapus)
  const IN=lsGet(LS_IND,DEF_IND);
  const saveInd=()=>lsSet(LS_IND,IN);
  let pairs=[],D=null,FP=null,err='',lastFull=0,busy=false,raf=null,fpTimer=null,liveBusy=false;
  const S={bw:8,right:null,autoY:true,ymin:0,ymax:1,mx:null,my:null,drag:null,pinch:null};

  // ------------------------------------------------------------------ DOM
  const bar=h('div',{class:'hf-bar'});
  const cv=h('canvas',{class:'hf-cv'});
  const legend=h('div',{class:'hf-legend'});
  const tip=h('div',{class:'hf-tip'});
  const msg=h('div',{class:'hf-msg'});
  const tools=h('div',{class:'hf-tools'},
    h('button',{title:'Zoom in',onclick:()=>zoomAt(null,1.35)},'+'),h('button',{title:'Zoom out',onclick:()=>zoomAt(null,1/1.35)},'−'),
    h('button',{class:'auto',title:'Skala harga otomatis',onclick:()=>{S.autoY=!S.autoY;tools.querySelector('.auto').classList.toggle('on',S.autoY);req()}},'AUTO'),
    h('button',{title:'Reset tampilan (atau klik ganda chart)',onclick:()=>{resetView();req()}},'⟲'));
  if(IN.sens==null||isNaN(+IN.sens))IN.sens=DEF_IND.sens;
  const SK=()=>'sens';
  const meterBars=Array.from({length:METER_BARS},(_,i)=>h('i',{style:{height:Math.round(28+72*(i+1)/METER_BARS)+'%'}}));
  const meter=h('div',{class:'hf-meter',role:'slider',tabindex:0,'aria-label':'Sensitivitas heatmap','aria-valuemin':0,'aria-valuemax':100,
    title:'Sensitivitas heatmap (disimpan per browser). Geser ke KANAN = lebih kuning: likuiditas yang lebih kecil sudah dianggap besar. Geser ke KIRI = lebih redup: hanya likuiditas yang sangat besar yang kuning.'},...meterBars);
  const titleTxt=h('b',null,'—');
  const colBtn=h('button',{class:'hf-col',onclick:()=>{IN._open=!IN._open;saveInd();drawLegend()}});
  // Tombol CANDLE / LINE (disimpan per browser): line = garis harga penutupan, tanpa badan candle & footprint.
  const typeBtn=h('button',{class:'hf-ctype',title:'Tampilan harga: CANDLE atau LINE (klik untuk ganti; disimpan per browser)',
    onclick:()=>{IN.line=!IN.line;saveInd();drawType();drawLegend();req()}});
  function drawType(){
    const svg=IN.line?'<svg viewBox="0 0 16 12" width="16" height="12"><polyline points="1,10 5,6 8,8 11,3 15,5" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>'
      :'<svg viewBox="0 0 16 12" width="16" height="12"><line x1="4" y1="0" x2="4" y2="12" stroke="currentColor"/><rect x="2" y="3" width="4" height="6" fill="#0ecb81"/><line x1="11" y1="0" x2="11" y2="12" stroke="currentColor"/><rect x="9" y="2" width="4" height="7" fill="#f6465d"/></svg>';
    typeBtn.innerHTML=svg+'<span>'+(IN.line?'LINE':'CANDLE')+'</span>';typeBtn.classList.toggle('on',!!IN.line);
  }
  drawType();
  const titleRow=h('div',{class:'hf-title'},titleTxt,meter,typeBtn,colBtn);
  const legRows=h('div',{class:'hf-legrows'});
  legend.append(titleRow,legRows);
  function drawMeter(){
    const v=Math.max(0,Math.min(100,Math.round(+IN[SK()]))),on=Math.round(v/100*METER_BARS);
    meterBars.forEach((b,i)=>{b.style.background=i<on?palCss(Math.round(255*(0.25+0.75*(i+1)/METER_BARS))):''});
    meter.setAttribute('aria-valuenow',v);meter.setAttribute('aria-valuetext',v+'%');
    meter.dataset.thr=D&&D.ythr?cm(D.ythr):'';
    meter.title='Sensitivitas heatmap '+v+'%'+(D&&D.ythr?' · kuning ≥ '+cm(D.ythr)+' per baris':'')+
      ' (disimpan per browser). Geser ke KANAN = lebih kuning: likuiditas yang lebih kecil sudah dianggap besar. Geser ke KIRI = lebih redup.';
  }
  function setSens(v){
    v=Math.max(0,Math.min(100,Math.round(v)));if(v===+IN[SK()])return;
    IN[SK()]=v;saveInd();if(D){applySens();buildImage();buildBookImg();req()}drawMeter();
  }
  const meterAt=e=>{const r=meter.getBoundingClientRect();return (e.clientX-r.left)/r.width*100};
  meter.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();meter.setPointerCapture(e.pointerId);meter.focus();setSens(meterAt(e))});
  meter.addEventListener('pointermove',e=>{if(meter.hasPointerCapture(e.pointerId))setSens(meterAt(e))});
  meter.addEventListener('wheel',e=>{e.preventDefault();setSens(+IN[SK()]+(e.deltaY<0?5:-5))},{passive:false});
  meter.addEventListener('keydown',e=>{const k={ArrowRight:5,ArrowUp:5,ArrowLeft:-5,ArrowDown:-5,PageUp:20,PageDown:-20}[e.key];if(k){e.preventDefault();setSens(+IN[SK()]+k)}
    else if(e.key==='Home'){e.preventDefault();setSens(0)}else if(e.key==='End'){e.preventDefault();setSens(100)}});
  const wrap=h('div',{class:'hf-cw'},cv,legend,tools,tip,msg);
  const lcv=h('canvas',{class:'hf-lcv'});
  const lhTitle=h('span',null,'Liquidity map');
  const lhead=h('div',{class:'hf-lh'},lhTitle,h('button',{title:'Sembunyikan (aktifkan lagi lewat ikon mata Liquidity Map)',onclick:()=>{IN.liqmap=false;saveInd();layout()}},'×'));
  const liq=h('div',{class:'hf-liq'},lhead,lcv);
  const lvBody=h('div',{class:'pb'});
  const ovBody=h('div',{class:'pb'});
  const lvTitle=h('span',null,'Key liquidity levels');
  const lvPanel=h('div',{class:'panel hf-lv'},h('div',{class:'ph'},lvTitle,h('span',{class:'sp'}),h('span',{class:'hf-ph2'},'From price')),lvBody);
  const ovPanel=h('div',{class:'panel hf-ov'},h('div',{class:'ph'},'Market overview'),ovBody);
  const main=h('div',{class:'hf-main'},wrap,liq);
  const side=h('div',{class:'hf-side'},lvPanel,ovPanel);
  root.append(h('div',{class:'hf'},bar,main,side));

  // ------------------------------------------------------------------ toolbar: pair & timeframe
  const narrow=()=>window.innerWidth<700;
  function placeTools(){
    if(narrow()){tools.classList.add('inbar');if(tools.parentNode!==bar)drawBar()}
    else{tools.classList.remove('inbar');if(tools.parentNode!==wrap)wrap.insertBefore(tools,tip)}
  }
  function drawBar(){
    const st=D&&D.status;
    const live=st&&st.state==='live';
    bar.replaceChildren(...[
      h('div',{class:'hf-grp'},h('span',{class:'hf-lbl'},'PAIR'),pairs.length?h('div',{class:'hf-tfs hf-psel'},...pairs.map(p=>h('button',{class:p.sym===VW.sym?'on':'','data-sym':p.sym,
        title:p.name+' ('+p.sym+')'+(p.price!=null?' · '+fp(p.price,p.price<1?4:2):'')+(p.pct!=null?' · '+T.pct(p.pct)+' 24 jam':''),
        onclick:()=>{if(p.sym!==VW.sym){VW.sym=p.sym;lsSet(LS_VIEW,VW);full(true)}}},p.sym.replace(/USDT$/,'')))):h('span',{class:'mut'},'Belum ada pair yang dipantau')),
      h('div',{class:'hf-grp'},h('span',{class:'hf-lbl'},'TF'),h('div',{class:'hf-tfs hf-tfsel'},...TFS.map(tf=>h('button',{class:tf===VW.tf?'on':'','data-tf':tf,onclick:()=>{if(tf!==VW.tf){VW.tf=tf;lsSet(LS_VIEW,VW);full(true)}}},tf)))),
      h('div',{class:'hf-st'},(()=>{const p=pairs.find(x=>x.sym===VW.sym);return p&&p.price!=null?h('b',{class:'hf-px'},p.sym+' '+fp(p.price,p.price<1?4:2)+' ',h('span',{class:T.cls(p.pct)},p.pct!=null?T.pct(p.pct):'')):null})(),h('i',{class:live?'ok':st?'warn':''}),h('span',null,(live?'LIVE':st?(st.state==='error'?'GAGAL':'MENYAMBUNG…'):'—')+' · Binance Spot'))].filter(Boolean));
  }
  function drawLegend(){
    const title=D?D.symbol+' · '+D.tf:(VW.sym||'—')+' · '+VW.tf;
    const rows=IN._open?IND.map(it=>h('div',{class:'hf-ind'+(IN[it.id]?'':' off'),'data-ind':it.id,title:it.tip},
      h('button',{class:'eye',title:IN[it.id]?'Sembunyikan':'Tampilkan','aria-label':(IN[it.id]?'Sembunyikan ':'Tampilkan ')+it.name,html:EYE(IN[it.id]),onclick:e=>{e.stopPropagation();IN[it.id]=!IN[it.id];saveInd();drawLegend();if(it.id==='liqmap'||it.id==='delta')layout();else req();if(it.id==='footprint')scheduleFP()}}),
      h('span',null,it.name),it.id==='footprint'&&IN.footprint&&!IN.line&&S.bw<FP_BW?h('small',null,'zoom in'):null)):[];
    titleTxt.textContent=title;
    colBtn.textContent=IN._open?'▾':'▸';colBtn.title=IN._open?'Sembunyikan daftar indikator':'Tampilkan daftar indikator';
    legRows.replaceChildren(...[admin?h('button',{class:'hf-pick',onclick:openPicker},'PILIH PAIR'):null,...rows].filter(Boolean));
    drawMeter();
  }

  // ------------------------------------------------------------------ data
  function decodeHeat(hm){
    const n=hm.nrows,cols=[],u=hm.vmax/1000,L=Math.log1p(1000)/255;
    let bytes=null;
    if(hm.q){const bin=atob(hm.q);bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i)}
    for(let c=0;c<hm.ncols;c++){
      const a=new Float32Array(n);
      if(bytes)for(let j=0;j<n;j++){const q=bytes[c*n+j];if(q)a[j]=u*Math.expm1(q*L)}
      cols.push(a);
    }
    return cols;
  }
  // Skala warna LINEAR seperti CoinGlass: intensitas = (nilai / nilai "penuh")^pangkat, nilai "penuh" = persentil yang
  // ditentukan meter sensitivitas (bawaan p99,5). Sebagian besar sel ungu/biru, hanya kluster terbesar yang hijau-kuning.
  // Sel bernilai 0 di kolom yang punya data tetap ungu tua (latar heatmap); kolom tanpa data (belum direkam) tetap kosong.
  function heatRef(){
    const vals=[];
    D.cols.forEach(a=>{for(let j=0;j<a.length;j++)if(a[j]>0)vals.push(a[j])});
    vals.sort((a,b)=>a-b);
    D.vals=Float32Array.from(vals);
    applySens();
    return D.ythr||1;
  }
  function applySens(){
    const V=D.vals,{q:qh,g}=sensAt(IN[SK()]);D.gam=g;
    if(!V||!V.length){D.vhi=1;D.ythr=null;return}
    D.vhi=Math.max(1e-9,V[Math.min(V.length-1,Math.floor(V.length*qh))]);
    D.ythr=D.vhi*Math.pow(0.85,1/g);                                  // nilai yang mulai tampil kuning (intensitas 0,85)
  }
  const gam=()=>D&&D.gam||1;
  function shade(v,g){if(!(v>0))return 1;return 1+Math.round(Math.pow(Math.min(1,v/D.vhi),g)*254)}
  const hasData=a=>{for(let j=0;j<a.length;j++)if(a[j]>0)return true;return false};
  // Level likuidasi SAAT INI (long+short per baris) sebagai satu kolom gambar: diisikan ke ruang kosong di kanan candle terakhir
  // (seperti platform heatmap). Ini keadaan sekarang, bukan riwayat: tidak ada data masa lalu yang dikarang.
  function buildBookImg(){
    const B=D&&D.book;if(!B){if(D)D.bookImg=null;return}
    const n=D.heat.nrows;if(!D.bookImg||D.bookImg.height!==n){D.bookImg=document.createElement('canvas');D.bookImg.width=1;D.bookImg.height=Math.max(1,n)}
    const c=D.bookImg.getContext('2d'),id=c.createImageData(1,Math.max(1,n)),g=gam();
    for(let j=0;j<n;j++){const k=shade((B.bid[j]||0)+(B.ask[j]||0),g),o=(n-1-j)*4,i=k*4;id.data[o]=PAL[i];id.data[o+1]=PAL[i+1];id.data[o+2]=PAL[i+2];id.data[o+3]=PAL[i+3]}
    c.putImageData(id,0,0);
  }
  function buildImage(){
    const n=D.heat.nrows,m=D.cols.length;
    if(!D.img||D.img.width!==m||D.img.height!==n){D.img=document.createElement('canvas');D.img.width=Math.max(1,m);D.img.height=Math.max(1,n)}
    const ctx=D.img.getContext('2d');const id=ctx.createImageData(Math.max(1,m),Math.max(1,n));
    for(let c=0;c<m;c++)paintCol(id.data,c,m,n);
    ctx.putImageData(id,0,0);
  }
  function paintCol(px,c,m,n){
    const a=D.cols[c],g=gam();
    if(!hasData(a)){for(let j=0;j<n;j++)px[((n-1-j)*m+c)*4+3]=0;return}
    for(let j=0;j<n;j++){
      const k=shade(a[j],g),o=((n-1-j)*m+c)*4,i=k*4;
      px[o]=PAL[i];px[o+1]=PAL[i+1];px[o+2]=PAL[i+2];px[o+3]=PAL[i+3];
    }
  }
  function updateCols(from){
    // gambar ulang hanya kolom >= from (pembaruan live)
    const n=D.heat.nrows,m=D.cols.length;
    if(!D.img||D.img.width!==m){buildImage();return}
    const ctx=D.img.getContext('2d');
    const w=m-from;if(w<=0)return;
    const id=ctx.createImageData(w,n);
    const g=gam();
    for(let c=from;c<m;c++){
      const a=D.cols[c];if(!hasData(a))continue;
      for(let j=0;j<n;j++){const k=shade(a[j],g),o=((n-1-j)*w+(c-from))*4,i=k*4;id.data[o]=PAL[i];id.data[o+1]=PAL[i+1];id.data[o+2]=PAL[i+2];id.data[o+3]=PAL[i+3]}
    }
    ctx.clearRect(from,0,w,n);ctx.putImageData(id,from,0);
  }
  function indexMaps(){D.tidx=new Map();D.candles.forEach((c,i)=>D.tidx.set(c[0],i))}

  async function loadPairs(){
    try{
      const d=await T.rawFetch('heatmap/pairs');
      if(!alive())return;
      pairs=d.pairs||[];
      if(!pairs.find(p=>p.sym===VW.sym)){VW.sym=pairs.length?pairs[0].sym:null;lsSet(LS_VIEW,VW);if(D&&D.symbol!==VW.sym){D=null;full(true)}}
      drawBar();
    }catch(e){if(alive()){err=e.message;showMsg()}}
  }
  function showMsg(){
    let t='';
    if(!pairs.length)t=admin?'Belum ada pair yang dipantau. Klik PILIH PAIR untuk memilih pair heatmap.':'Admin belum memilih pair untuk heatmap.';
    else if(err)t='Data tidak tersedia: '+err;
    else if(!D)t='Memuat heatmap '+(VW.sym||'')+' '+VW.tf+'…';
    msg.textContent=t;msg.style.display=t?'flex':'none';
  }
  async function full(reset){
    if(!VW.sym){showMsg();drawLegend();return}
    if(busy&&!reset)return;
    busy=true;
    const want=VW.sym+'|'+VW.tf+'|'+VW.mode;
    if(reset){D=null;FP=null;err='';showMsg();drawLegend();drawSide();req()}
    try{
      const d=await T.rawFetch('heatmap/view',{symbol:VW.sym,tf:VW.tf,bars:300,mode:VW.mode});
      if(!alive()||want!==VW.sym+'|'+VW.tf+'|'+VW.mode)return;
      const keep=D&&D.symbol===d.symbol&&D.tf===d.tf&&D.mode===d.mode;
      const prevLast=keep?D.candles.length-1:0,prevT=keep?D.candles[prevLast][0]:null;
      d.cols=decodeHeat(d.heat);
      D=d;indexMaps();D.ref=heatRef();buildImage();buildBookImg();
      if(!keep||S.right==null)resetView();
      else{const ni=D.tidx.get(prevT);if(ni!=null)S.right+=ni-prevLast;else resetView()}
      err='';lastFull=Date.now();
      showMsg();drawBar();drawLegend();drawSide();scheduleFP();req();
    }catch(e){if(alive()&&want===VW.sym+'|'+VW.tf+'|'+VW.mode){err=e.message;showMsg()}}
    finally{busy=false}
  }
  async function live(){
    if(!D||liveBusy||busy||document.hidden)return;
    if(Date.now()-lastFull>120000){full(false);return}       // muat penuh berkala: baris harga & skala warna disegarkan
    liveBusy=true;
    const want=D.symbol+'|'+D.tf+'|'+D.mode,last=D.candles[D.candles.length-1][0];
    const fpm=wantFP()&&lastVisible()?fpM():0;
    try{
      const d=await T.rawFetch('heatmap/live',{symbol:D.symbol,tf:D.tf,since:last,row:D.row,k0:D.heat.k0,nrows:D.heat.nrows,bars:300,fp:fpm,mode:D.mode});
      if(!alive()||!D||want!==D.symbol+'|'+D.tf+'|'+D.mode)return;
      let from=D.candles.length;
      d.candles.forEach((c,i)=>{
        const at=D.tidx.get(c[0]);const col=Float32Array.from(d.heat[i]||[]);
        if(at!=null){D.candles[at]=c;D.cols[at]=col;from=Math.min(from,at)}
        else{D.candles.push(c);D.cols.push(col);D.tidx.set(c[0],D.candles.length-1);if(S.right>=D.candles.length-8)S.right+=1}
      });
      while(D.candles.length>1000){D.candles.shift();D.cols.shift();S.right-=1;from=Math.max(0,from-1);indexMaps()}
      D.heat.ncols=D.cols.length;
      const t0=d.candles.length?d.candles[0][0]:last;
      D.bubbles=D.bubbles.filter(b=>b[0]<t0).concat(d.bubbles||[]);
      ['book','levels','overview','status','since','now'].forEach(k=>{if(d[k]!==undefined)D[k]=d[k]});
      if(D.img&&D.img.width!==D.cols.length)buildImage();else updateCols(from);
      buildBookImg();
      if(d.fp&&FP&&FP.m===d.fp.m&&FP.key===D.symbol+'|'+D.tf){Object.entries(d.fp.cells).forEach(([t,rows])=>FP.cells.set(+t,rows))}
      const lp=D.candles[D.candles.length-1][4],p=pairs.find(x=>x.sym===D.symbol);if(p)p.price=lp;
      if(lp<(D.heat.k0+2)*D.row||lp>(D.heat.k0+D.heat.nrows-2)*D.row)lastFull=0;   // harga keluar jendela baris -> muat penuh berikutnya
      drawSide();drawBar();drawMeter();req();
    }catch(e){if(alive()&&/price step|row/i.test(e.message))full(false)}
    finally{liveBusy=false}
  }

  // ------------------------------------------------------------------ geometri & interaksi
  const ctx=cv.getContext('2d'),lctx=lcv.getContext('2d');
  let W=0,H=0,LW=0,dpr=1;
  // Tata letak: [area harga][sumbu harga][Liquidity map] di atas, lalu Volume Delta + sumbu waktu selebar penuh di bawah.
  const PR=()=>W-AX-(IN.liqmap?LW:0);           // tepi kanan area harga
  const PB=()=>H-TAX-(IN.delta?DP:0);           // tepi bawah area harga
  function geo(){const pb=PB();return {pl:0,pr:PR(),pt:0,pb,dt:pb,db:pb+(IN.delta?DP:0)}}
  const Lx=i=>PR()-(S.right-i)*S.bw;            // tepi kiri candle i
  const Xc=i=>Lx(i)+S.bw/2;
  const idxAt=x=>Math.floor(S.right-(PR()-x)/S.bw);
  function Y(p){const G=geo();return G.pt+(S.ymax-p)/(S.ymax-S.ymin)*(G.pb-G.pt)}
  function Pr(y){const G=geo();return S.ymax-(y-G.pt)/(G.pb-G.pt)*(S.ymax-S.ymin)}
  function visRange(){const n=D.candles.length;return [Math.max(0,Math.floor(S.right-PR()/S.bw)),Math.min(n-1,Math.ceil(S.right))]}
  function lastVisible(){return D&&S.right>=D.candles.length-1}
  // Tampilan awal: ±124 candle terakhir (model likuidasi penuh di semua candle).
  function resetView(){
    if(!D)return;const n=D.candles.length;
    const vis=Math.min(n,124);
    S.bw=Math.max(2,Math.min(40,PR()/(vis+6)||8));S.right=n+5;S.autoY=true;tools.querySelector('.auto').classList.add('on');
  }
  function fitY(){
    if(!D||!S.autoY)return;
    const [a,b]=visRange();let lo=Infinity,hi=-Infinity;
    for(let i=a;i<=b;i++){const c=D.candles[i];if(!c)continue;lo=Math.min(lo,c[3]);hi=Math.max(hi,c[2])}
    if(!isFinite(lo)){const c=D.candles[D.candles.length-1];lo=c[3];hi=c[2]}
    const pad=(hi-lo)*0.08||lo*0.002;S.ymin=lo-pad;S.ymax=hi+pad;
  }
  function zoomAt(x,f){
    if(!D)return;
    const G=geo();const xx=x==null?G.pr-S.bw*4:x;
    const at=S.right-(G.pr-xx)/S.bw;
    S.bw=Math.max(2,Math.min(240,S.bw*f));
    S.right=at+(G.pr-xx)/S.bw;clampRight();drawLegend();scheduleFP();req();
  }
  // Horizontal: kiri berhenti di candle pertama; kanan maks. 20% lebar layar setelah candle terakhir (diisi likuiditas saat ini).
  // Zoom-out maks. = seluruh data pas satu layar.
  function clampRight(){
    if(!D)return;const n=D.candles.length,pw=PR();if(pw<=0)return;
    S.bw=Math.max(S.bw,0.8*pw/n);
    const vis=pw/S.bw;
    S.right=Math.min(n+0.2*vis,Math.max(vis,S.right));
  }
  // Vertikal: rentang harga yang terlihat selalu di dalam baris yang punya data heatmap.
  function clampY(){
    if(!D||!D.heat)return;const lo=D.heat.k0*D.row,hi=(D.heat.k0+D.heat.nrows)*D.row,span=S.ymax-S.ymin;
    if(!(span>0)||span>=hi-lo){S.ymin=lo;S.ymax=hi;return}
    if(S.ymin<lo){S.ymin=lo;S.ymax=lo+span}
    if(S.ymax>hi){S.ymax=hi;S.ymin=hi-span}
  }
  cv.addEventListener('wheel',e=>{
    if(!D)return;e.preventDefault();
    const r=cv.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
    const f=Math.exp(-(e.deltaY||0)*0.0016);
    if(x>PR()&&x<PR()+AX&&y<geo().pb){S.autoY=false;tools.querySelector('.auto').classList.remove('on');const p=Pr(y);S.ymin=p-(p-S.ymin)/f;S.ymax=p+(S.ymax-p)/f;scheduleFP();req();return}
    if(e.shiftKey&&!e.ctrlKey){S.right+=(e.deltaY||e.deltaX)/S.bw;clampRight();scheduleFP();req();return}
    zoomAt(x,f);
  },{passive:false});
  const pts=new Map();
  cv.addEventListener('pointerdown',e=>{
    if(!D)return;cv.setPointerCapture(e.pointerId);pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const r=cv.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
    if(pts.size===2){const [a,b]=[...pts.values()];S.pinch={d:Math.abs(a.x-b.x)||1,bw:S.bw,cx:(a.x+b.x)/2-r.left};S.drag=null;return}
    S.drag={x:e.clientX,y:e.clientY,right:S.right,ymin:S.ymin,ymax:S.ymax,axis:x>PR()&&y<geo().pb,moved:false};
  });
  cv.addEventListener('pointermove',e=>{
    const r=cv.getBoundingClientRect();
    if(pts.has(e.pointerId))pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(S.pinch&&pts.size===2){const [a,b]=[...pts.values()];const d=Math.abs(a.x-b.x)||1;const f=(d/S.pinch.d)*S.pinch.bw/S.bw;zoomAt(S.pinch.cx,f);return}
    if(S.drag){
      const dx=e.clientX-S.drag.x,dy=e.clientY-S.drag.y;if(Math.abs(dx)+Math.abs(dy)>3)S.drag.moved=true;
      if(S.drag.axis){S.autoY=false;tools.querySelector('.auto').classList.remove('on');const f=Math.exp(dy*0.006);const mid=(S.drag.ymin+S.drag.ymax)/2,half=(S.drag.ymax-S.drag.ymin)/2*f;S.ymin=mid-half;S.ymax=mid+half}
      else{S.right=S.drag.right-dx/S.bw;clampRight();if(!S.autoY){const G=geo();const pp=(S.drag.ymax-S.drag.ymin)/(G.pb-G.pt);S.ymin=S.drag.ymin+dy*pp;S.ymax=S.drag.ymax+dy*pp}}
      S.mx=null;req();return;
    }
    S.mx=e.clientX-r.left;S.my=e.clientY-r.top;req();
  });
  const end=e=>{pts.delete(e.pointerId);if(pts.size<2)S.pinch=null;if(S.drag){S.drag=null;scheduleFP()}};
  cv.addEventListener('pointerup',end);cv.addEventListener('pointercancel',end);
  cv.addEventListener('pointerleave',()=>{S.mx=null;tip.style.display='none';req()});
  cv.addEventListener('dblclick',()=>{resetView();req();scheduleFP()});

  // ------------------------------------------------------------------ footprint
  function wantFP(){return D&&IN.footprint&&!IN.line&&S.bw>=FP_BW}
  function fpM(){const G=geo();const ppp=(G.pb-G.pt)/(S.ymax-S.ymin),need=S.bw>=FP_TEXT?15:5;for(const m of NICE)if(D.fpb*m*ppp>=need)return m;return NICE[NICE.length-1]}
  function scheduleFP(){clearTimeout(fpTimer);fpTimer=setTimeout(loadFP,220)}
  async function loadFP(){
    if(!alive()||!wantFP())return;
    const [a,b]=visRange();if(b<a)return;
    const m=fpM(),key=D.symbol+'|'+D.tf,t0=D.candles[a][0],t1=D.candles[b][0];
    if(FP&&FP.key===key&&FP.m===m&&FP.t0<=t0&&FP.t1>=t1&&Date.now()-FP.at<20000)return;
    try{
      const d=await T.rawFetch('heatmap/footprint',{symbol:D.symbol,tf:D.tf,t0,t1,m});
      if(!alive()||!D||key!==D.symbol+'|'+D.tf)return;
      FP={key,m:d.m,row:d.row,t0,t1,at:Date.now(),cells:new Map(Object.entries(d.cells).map(([t,r])=>[+t,r]))};req();
    }catch(e){}
  }

  // ------------------------------------------------------------------ gambar
  function req(){if(!raf)raf=requestAnimationFrame(draw)}
  function layout(){
    liq.style.display=IN.liqmap?'':'none';
    drawLegend();resize();
  }
  function resize(){
    placeTools();
    dpr=Math.min(2,window.devicePixelRatio||1);
    const r=wrap.getBoundingClientRect();W=Math.max(50,Math.floor(r.width));H=Math.max(120,Math.floor(r.height));
    cv.width=W*dpr;cv.height=H*dpr;cv.style.width=W+'px';cv.style.height=H+'px';
    if(IN.liqmap){const lr=liq.getBoundingClientRect(),lh=Math.max(40,PB());LW=Math.max(40,Math.floor(lr.width));liq.style.height=lh+'px';lcv.width=LW*dpr;lcv.height=lh*dpr;lcv.style.width=LW+'px';lcv.style.height=lh+'px'}
    else LW=0;
    if(!tools.classList.contains('inbar'))tools.style.right=(AX+(IN.liqmap?LW:0)+6)+'px';else tools.style.right='';
    if(D&&S.right!=null)clampRight();
    req();
  }
  const ro=new ResizeObserver(()=>{if(!alive()){ro.disconnect();return}resize()});
  ro.observe(wrap);ro.observe(liq);

  function draw(){
    raf=null;if(!alive())return;
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.fillStyle='#030407';ctx.fillRect(0,0,W,H);
    if(!D){drawLiq();return}
    clampRight();fitY();clampY();
    const G=geo(),n=D.candles.length,dg=D.digits,[a,b]=visRange();
    ctx.font='10px "JetBrains Mono",ui-monospace,monospace';
    // grid & label harga
    const step=niceNum((S.ymax-S.ymin)/Math.max(2,(G.pb-G.pt)/58));
    ctx.strokeStyle='#0f131c';ctx.lineWidth=1;ctx.beginPath();
    const ticks=[];for(let p=Math.ceil(S.ymin/step)*step;p<=S.ymax;p+=step){const y=Math.round(Y(p))+.5;ctx.moveTo(0,y);ctx.lineTo(G.pr,y);ticks.push([p,y])}
    ctx.stroke();
    ctx.save();ctx.beginPath();ctx.rect(0,0,G.pr,G.pb);ctx.clip();
    if(IN.heat)drawHeat(G,a,b);
    if(IN.levels)drawLevels(G);
    const showFP=wantFP()&&FP&&FP.key===D.symbol+'|'+D.tf;
    drawCandles(G,a,b,showFP);
    if(IN.bubbles)drawBubbles(G,a,b);
    drawTradeStart(G,a,b);
    // garis harga terakhir
    const lc=D.candles[n-1],ly=Math.round(Y(lc[4]))+.5,up=lc[4]>=lc[1];
    ctx.setLineDash([3,3]);ctx.strokeStyle=up?'#9aa4b8':'#4f86ff';ctx.beginPath();ctx.moveTo(0,ly);ctx.lineTo(G.pr,ly);ctx.stroke();ctx.setLineDash([]);
    ctx.restore();
    // sumbu harga
    ctx.fillStyle='#05070b';ctx.fillRect(G.pr,0,AX,G.pb);ctx.strokeStyle='#1b2130';ctx.beginPath();ctx.moveTo(G.pr+.5,0);ctx.lineTo(G.pr+.5,G.db);ctx.stroke();
    ctx.fillStyle='#7d8498';ctx.textAlign='left';ctx.textBaseline='middle';
    ticks.forEach(([p,y])=>{if(y>8&&y<G.pb-8)ctx.fillText(fp(p,step<1?Math.min(dg,Math.max(0,-Math.floor(Math.log10(step))+1)):0),G.pr+6,y)});
    tag(G.pr,ly,fp(lc[4],dg),up?'#3a4152':'#2554c7');
    // panel delta
    if(IN.delta)drawDelta(G,a,b);
    // sumbu waktu
    drawTime(G,a,b);
    // crosshair
    drawCross(G);
    drawLiq();
  }
  function tag(x,y,txt,bg){ctx.font='bold 10px "JetBrains Mono",ui-monospace,monospace';const w=AX-4;ctx.fillStyle=bg;ctx.fillRect(x+2,y-8,w,16);ctx.fillStyle='#fff';ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillText(txt,x+6,y);ctx.font='10px "JetBrains Mono",ui-monospace,monospace'}
  function drawHeat(G,a,b){
    if(!D.img||!D.cols.length)return;
    const r=D.row,k0=D.heat.k0,nr=D.heat.nrows;
    const jA=Math.max(0,Math.floor(S.ymin/r)-k0),jB=Math.min(nr-1,Math.floor(S.ymax/r)-k0);
    if(jB<jA)return;
    const sy=nr-1-jB,sh=jB-jA+1;
    const dy=Y((k0+jB+1)*r),dh=Y((k0+jA)*r)-dy;
    ctx.imageSmoothingEnabled=false;
    if(b>=a)ctx.drawImage(D.img,a,sy,b-a+1,sh,Lx(a),dy,(b-a+1)*S.bw,dh);
    const xb=Lx(D.candles.length);                          // tepi kanan candle terakhir
    if(D.bookImg&&xb<G.pr){
      ctx.drawImage(D.bookImg,0,sy,1,sh,Math.max(0,xb),dy,G.pr-Math.max(0,xb),dh);
      ctx.fillStyle='rgba(255,255,255,.07)';ctx.fillRect(Math.round(xb),0,1,G.pb);
    }
  }
  function drawLevels(G){
    const L=D.levels;if(!L)return;
    const all=[...(L.above||[]),...(L.below||[])];if(!all.length)return;
    const mx=Math.max(...all.map(x=>x.strength))||1,x1=G.pr;
    all.forEach(lv=>{
      const f=lv.strength/mx,y=Y(lv.price);if(y<-10||y>G.pb+10)return;
      const i=lv.since!=null&&D.tidx.has(lv.since)?D.tidx.get(lv.since):Math.max(0,D.candles.length-1);
      const x0=Math.max(0,Lx(i));
      const th=Math.max(1.5,1.5+f*3.5);
      ctx.fillStyle=`rgba(255,${Math.round(150+40*f)},40,${(0.55+0.4*f).toFixed(2)})`;
      ctx.fillRect(x0,Math.round(y-th/2),x1-x0,th);
    });
  }
  function drawLine(a,b){
    const n=D.candles.length,lo=Math.max(0,a-1),hi=Math.min(n-1,b+1);if(hi<lo)return;
    ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
    ctx.beginPath();for(let i=lo;i<=hi;i++){const x=Xc(i),y=Y(D.candles[i][4]);i===lo?ctx.moveTo(x,y):ctx.lineTo(x,y)}
    ctx.strokeStyle='rgba(0,0,0,.6)';ctx.lineWidth=4;ctx.stroke();
    ctx.strokeStyle='#e5e7eb';ctx.lineWidth=1.8;ctx.stroke();
    const l=D.candles[n-1];if(hi===n-1){ctx.fillStyle=l[4]>=l[1]?'#0ecb81':'#f6465d';ctx.beginPath();ctx.arc(Xc(n-1),Y(l[4]),3,0,Math.PI*2);ctx.fill()}
    ctx.restore();
  }
  function drawCandles(G,a,b,showFP){
    if(IN.line){drawLine(a,b);return}
    const bw=S.bw,body=Math.max(1,Math.min(bw*0.7,bw-1.5));
    for(let i=a;i<=b;i++){
      const c=D.candles[i];if(!c)continue;
      const up=c[4]>=c[1],col=up?'#0ecb81':'#f6465d';
      if(showFP){drawFPCandle(G,i,c,col);continue}
      const x=Math.round(Xc(i))+.5,yo=Y(c[1]),yc=Y(c[4]),bx=Math.round(x-body/2),by=Math.min(yo,yc),bwd=Math.max(1,Math.round(body)),bh=Math.max(1,Math.abs(yc-yo));
      ctx.strokeStyle='rgba(0,0,0,.55)';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x,Y(c[2]));ctx.lineTo(x,Y(c[3]));ctx.stroke();ctx.lineWidth=1;
      ctx.strokeStyle=col;ctx.beginPath();ctx.moveTo(x,Y(c[2]));ctx.lineTo(x,Y(c[3]));ctx.stroke();
      if(bwd>=3){ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(bx-1,by-1,bwd+2,bh+2)}
      ctx.fillStyle=col;ctx.fillRect(bx,by,bwd,bh);
    }
  }
  // Candle FOOTPRINT (gaya ATAS/Exocharts): tiap harga = kotak berwarna delta (hijau = beli agresif dominan, merah = jual),
  // garis badan candle open→close, sumbu tipis high→low, POC (harga volume terbesar) bertepi emas. Lebar >= FP_TEXT: angka
  // jual × beli per harga + Δ candle. Candle tanpa data trade tetap digambar sebagai candle biasa.
  function plainCandle(i,c,col){
    const body=Math.max(1,Math.min(S.bw*0.7,S.bw-1.5)),x=Math.round(Xc(i))+.5,yo=Y(c[1]),yc=Y(c[4]);
    ctx.strokeStyle=col;ctx.beginPath();ctx.moveTo(x,Y(c[2]));ctx.lineTo(x,Y(c[3]));ctx.stroke();
    ctx.fillStyle=col;ctx.fillRect(Math.round(x-body/2),Math.min(yo,yc),Math.max(1,Math.round(body)),Math.max(1,Math.abs(yc-yo)));
  }
  function drawFPCandle(G,i,c,col){
    const rows=FP.cells.get(c[0]);
    if(!rows||!rows.length){plainCandle(i,c,col);return}
    const x0=Lx(i)+1,w=S.bw-3,wx=x0+1.5,ax=x0+4,aw=w-4,R=FP.row,text=S.bw>=FP_TEXT;
    let mx=1,mt=1,poc=null,pv=-1,db=0,ds=0;
    rows.forEach(r=>{mx=Math.max(mx,r[1],r[2]);mt=Math.max(mt,r[1]+r[2]);if(r[1]+r[2]>pv){pv=r[1]+r[2];poc=r[0]}db+=r[1];ds+=r[2]});
    ctx.fillStyle='rgba(3,4,7,.55)';ctx.fillRect(ax,Y(c[2]),aw,Math.max(1,Y(c[3])-Y(c[2])));      // alas kolom (heatmap di belakang tetap samar)
    const half=aw/2;
    rows.forEach(([k,buy,sell])=>{
      const ya=Y((k+1)*R),yb=Y(k*R),hh=yb-ya;if(yb<0||ya>G.pb)return;
      const y=ya+0.5,hc=Math.max(1,hh-1);
      if(text){
        ctx.fillStyle=`rgba(246,70,93,${(0.12+0.68*sell/mx).toFixed(3)})`;ctx.fillRect(ax,y,half-0.5,hc);
        ctx.fillStyle=`rgba(14,203,129,${(0.12+0.68*buy/mx).toFixed(3)})`;ctx.fillRect(ax+half,y,half-0.5,hc);
      }else{
        const d=buy-sell,a=(0.18+0.72*(buy+sell)/mt).toFixed(3);
        ctx.fillStyle=d>=0?`rgba(14,203,129,${a})`:`rgba(246,70,93,${a})`;ctx.fillRect(ax,y,aw,hc);
      }
      if(k===poc){ctx.strokeStyle='#f5c542';ctx.lineWidth=1;ctx.strokeRect(ax+.5,y,aw-1,hc)}
      if(text&&hh>=9&&half>=20){
        const fs=Math.max(8,Math.min(11,Math.floor(hh-2)));ctx.font=fs+'px "JetBrains Mono",ui-monospace,monospace';ctx.textBaseline='middle';
        const strong=(x,z)=>x>=3*Math.max(z,1);
        ctx.fillStyle=strong(sell,buy)?'#ffd1d6':'#e5e7eb';ctx.textAlign='right';ctx.fillText(cm(sell),ax+half-3,ya+hh/2);
        ctx.fillStyle=strong(buy,sell)?'#c9ffe6':'#e5e7eb';ctx.textAlign='left';ctx.fillText(cm(buy),ax+half+3,ya+hh/2);
      }
    });
    // sumbu high-low & badan open-close
    ctx.strokeStyle=col;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(Math.round(wx)+.5,Y(c[2]));ctx.lineTo(Math.round(wx)+.5,Y(c[3]));ctx.stroke();
    const yo=Y(c[1]),yc=Y(c[4]);ctx.lineWidth=1.6;ctx.strokeRect(ax+.5,Math.min(yo,yc),aw-1,Math.max(1,Math.abs(yc-yo)));ctx.lineWidth=1;
    ctx.font='10px "JetBrains Mono",ui-monospace,monospace';
    if(text){const yl=Y(c[3])+12;if(yl<G.pb-2){const dd=db-ds;ctx.fillStyle=dd>=0?'#34d399':'#fb7185';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('Δ '+(dd>=0?'+':'')+cm(dd),ax+half,yl)}}
  }
  // BIG TRADE bubble gaya platform footprint: bola terisi gradasi (terang di tengah), TANPA garis tepi, luas ~ nilai trade.
  // Awal riwayat trade tersimpan: candle di kiri garis ini belum punya data big trade & footprint (bukan berarti tidak ada).
  function noTrades(c){return D.trades_from!=null&&c[0]+D.sec<=D.trades_from}
  function drawTradeStart(G,a,b){
    if(D.trades_from==null||!(IN.bubbles||wantFP())||!noTrades(D.candles[a]))return;
    let i=a;while(i<=b&&noTrades(D.candles[i]))i++;
    if(i>b)return;
    const x=Math.round(Lx(i))+.5;
    ctx.save();ctx.strokeStyle='rgba(148,163,184,.42)';ctx.setLineDash([2,4]);ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,G.pb);ctx.stroke();ctx.restore();
  }
  function drawBubbles(G,a,b){
    const bs=D.bubbles||[];if(!bs.length)return;
    const t0=D.candles[a][0],t1=D.candles[b][0];
    const vis=bs.filter(x=>x[0]>=t0&&x[0]<=t1);if(!vis.length)return;
    const um=Math.max(...vis.map(x=>x[2]))||1,rMax=Math.max(8,Math.min(34,S.bw*1.2)),rMin=Math.max(3,Math.min(6,S.bw*0.3));
    D._hit=[];
    vis.sort((p,q)=>q[2]-p[2]).forEach(([t,p,u,s,ts])=>{
      const i=D.tidx.get(t);if(i==null)return;const x=Xc(i),y=Y(p);if(y<-50||y>G.pb+50)return;
      const r=rMin+(rMax-rMin)*Math.sqrt(u/um);
      const gr=ctx.createRadialGradient(x-r*0.32,y-r*0.32,r*0.08,x,y,r);
      if(s>0){gr.addColorStop(0,'rgba(190,255,224,.96)');gr.addColorStop(.5,'rgba(16,200,128,.86)');gr.addColorStop(1,'rgba(4,120,80,.72)')}
      else{gr.addColorStop(0,'rgba(255,214,214,.96)');gr.addColorStop(.5,'rgba(240,68,90,.86)');gr.addColorStop(1,'rgba(150,24,40,.72)')}
      ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=gr;ctx.fill();
      if(r>=14){ctx.save();ctx.font='bold 10px "JetBrains Mono",ui-monospace,monospace';ctx.shadowColor='rgba(0,0,0,.7)';ctx.shadowBlur=3;ctx.fillStyle='#fff';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(cm(u),x,y);ctx.restore()}
      D._hit.push([x,y,r,t,p,u,s,ts]);
    });
  }
  function drawDelta(G,a,b){
    ctx.fillStyle='#05070b';ctx.fillRect(0,G.dt,W,G.db-G.dt);
    ctx.strokeStyle='#1b2130';ctx.beginPath();ctx.moveTo(0,G.dt+.5);ctx.lineTo(W,G.dt+.5);ctx.stroke();
    let mx=1;for(let i=a;i<=b;i++){const c=D.candles[i];if(c)mx=Math.max(mx,Math.abs(2*c[6]-c[5]))}
    const mid=G.dt+(G.db-G.dt)/2,hh=(G.db-G.dt)/2-6,body=Math.max(1,Math.min(S.bw*0.7,S.bw-1.5));
    for(let i=a;i<=b;i++){const c=D.candles[i];if(!c)continue;const d=2*c[6]-c[5];const y=hh*Math.abs(d)/mx;ctx.fillStyle=d>=0?'rgba(34,197,94,.8)':'rgba(239,68,68,.8)';ctx.fillRect(Math.round(Xc(i)-body/2),d>=0?mid-y:mid,Math.max(1,Math.round(body)),Math.max(1,y))}
    ctx.strokeStyle='#232a3a';ctx.beginPath();ctx.moveTo(0,Math.round(mid)+.5);ctx.lineTo(G.pr,Math.round(mid)+.5);ctx.stroke();
    const hi=S.mx!=null?idxAt(S.mx):D.candles.length-1,c=D.candles[Math.max(0,Math.min(D.candles.length-1,hi))];
    const d=c?2*c[6]-c[5]:0;
    ctx.fillStyle='#7d8498';ctx.textAlign='left';ctx.textBaseline='top';ctx.fillText('Volume Delta',6,G.dt+4);
    ctx.fillStyle=d>=0?'#4ade80':'#f87171';ctx.fillText((d>=0?'+':'')+cm(d),96,G.dt+4);
  }
  function drawTime(G,a,b){
    const y=G.db;ctx.fillStyle='#05070b';ctx.fillRect(0,y,W,TAX);ctx.strokeStyle='#1b2130';ctx.beginPath();ctx.moveTo(0,y+.5);ctx.lineTo(W,y+.5);ctx.stroke();
    const every=Math.max(1,Math.ceil(86/S.bw));ctx.fillStyle='#7d8498';ctx.textAlign='center';ctx.textBaseline='middle';
    const daily=every*D.sec>=86400;          // jarak label >= 1 hari (mis. H4 di-zoom-out): tampilkan tanggal, bukan jam
    for(let i=a;i<=b;i++){if(i%every)continue;const x=Xc(i);if(x<30||x>G.pr-30)continue;ctx.fillText(tlab(D.candles[i][0],daily?86400:D.sec),x,y+TAX/2)}
  }
  function drawCross(G){
    tip.style.display='none';
    if(S.mx==null||S.my==null||S.drag)return;
    const x=S.mx,y=S.my;if(x>G.pr||y>G.db)return;
    const iraw=idxAt(x),future=iraw>=D.candles.length;
    const i=Math.max(0,Math.min(D.candles.length-1,iraw));const c=D.candles[i];
    const xc=Math.round(Xc(i))+.5;
    ctx.strokeStyle='rgba(148,163,184,.45)';ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(xc,0);ctx.lineTo(xc,G.db);
    if(y<G.pb){ctx.moveTo(0,Math.round(y)+.5);ctx.lineTo(G.pr,Math.round(y)+.5)}
    ctx.stroke();ctx.setLineDash([]);
    const p=Pr(y);
    if(y<G.pb)tag(G.pr,y,fp(p,D.digits),'#334155');
    const tl=tlab(c[0],D.sec,true);ctx.fillStyle='#334155';const tw=ctx.measureText(tl).width+10;ctx.fillRect(xc-tw/2,G.db+1,tw,TAX-2);ctx.fillStyle='#fff';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(tl,xc,G.db+TAX/2);
    // tooltip
    const dg=D.digits,lines=[];
    lines.push(`<b>${tlab(c[0],D.sec,true)}</b> · O ${fp(c[1],dg)} H ${fp(c[2],dg)} L ${fp(c[3],dg)} C ${fp(c[4],dg)}`);
    const dl=2*c[6]-c[5];lines.push(`Volume ${cm(c[5])} · Delta <span class="${dl>=0?'up':'dn'}">${dl>=0?'+':''}${cm(dl)}</span> (beli ${c[5]?Math.round(c[6]/c[5]*100):0}%)`);
    if(y<G.pb){
      const k=Math.floor(p/D.row),j=k-D.heat.k0,col=D.cols[i];
      if(IN.bubbles&&noTrades(c))lines.push('<span class="mut">Di luar riwayat trade tersimpan — big trade & footprint belum tersedia untuk candle ini</span>');
      if(col&&j>=0&&j<col.length&&col[j]>0)lines.push(`Est. likuidasi aktif ${fp(k*D.row,dg)}–${fp((k+1)*D.row,dg)}: <b>${cm(col[j])}</b>`);
      if(D.book&&(future||i===D.candles.length-1)){const bj=k-D.book.k0;const bv=(D.book.bid[bj]||0),av=(D.book.ask[bj]||0);
        if(bv+av>0)lines.push(`Level likuidasi sekarang: ${bv?'long '+cm(bv):''}${bv&&av?' · ':''}${av?'short '+cm(av):''}`)}
      if(wantFP()&&FP){const rows=FP.cells.get(c[0]);if(rows){const kk=Math.floor(p/FP.row);const r=rows.find(x=>x[0]===kk);if(r)lines.push(`Footprint: jual <span class="dn">${cm(r[2])}</span> × beli <span class="up">${cm(r[1])}</span>`)}}
      const hb=(D._hit||[]).find(([bx,by,br])=>(bx-x)**2+(by-y)**2<=br*br);
      if(hb){const d=new Date(hb[7]);lines.push(`Big trade <b class="${hb[6]>0?'up':'dn'}">${hb[6]>0?'BELI':'JUAL'} $${cm(hb[5])}</b> @ ${fp(hb[4],dg)} · 1 order · ${p2(d.getHours())}:${p2(d.getMinutes())}:${p2(d.getSeconds())}`)}
    }
    tip.innerHTML=lines.join('<br>');tip.style.display='block';
    const tw2=tip.offsetWidth,th2=tip.offsetHeight;
    tip.style.left=Math.max(4,Math.min(G.pr-tw2-4,x+14))+'px';tip.style.top=Math.max(4,Math.min(G.pb-th2-4,y+14))+'px';
  }
  function drawLiq(){
    if(!IN.liqmap||!LW)return;
    lctx.setTransform(dpr,0,0,dpr,0,0);
    lctx.fillStyle='#0a0d13';lctx.fillRect(0,0,LW,PB());
    lhTitle.textContent='Liquidation map';
    if(!D||!D.book)return;
    const G=geo(),B=D.book,r=D.row,mid=B.mid;
    let mxv=1,cumA=0,cumB=0;
    const rows=[];
    for(let j=0;j<B.bid.length;j++){const k=B.k0+j,lo=k*r,hi=lo+r;if(hi<S.ymin||lo>S.ymax)continue;const v=(B.bid[j]||0)+(B.ask[j]||0);if(v>mxv)mxv=v;rows.push([k,lo,hi,B.bid[j]||0,B.ask[j]||0])}
    lctx.save();lctx.beginPath();lctx.rect(0,0,LW,G.pb);lctx.clip();
    const wmax=LW-8;
    // kurva kumulatif HANYA dalam rentang harga yang terlihat: ask dari harga ke atas (merah), bid dari harga ke bawah (hijau).
    // Diskalakan ke jumlah yang terlihat, sehingga tiap kotak panjang membuat garis melompat sejauh kotak itu (mengikuti volume).
    const asks=[],bids=[];
    for(let j=0;j<B.ask.length;j++){const k=B.k0+j;if((k+1)*r>mid&&k*r<S.ymax)asks.push([k,B.ask[j]||0])}
    for(let j=B.bid.length-1;j>=0;j--){const k=B.k0+j;if(k*r<mid&&(k+1)*r>S.ymin)bids.push([k,B.bid[j]||0])}
    let tA=0,tB=0;asks.forEach(x=>tA+=x[1]);bids.forEach(x=>tB+=x[1]);
    const mc=Math.max(tA,tB)||1;
    // area di bawah kurva diisi pekat (gradasi dari tepi kiri ke kurva) seperti CoinGlass, lalu kotak volume di atasnya, lalu garis kurva
    const path=(arr,dir)=>{const p=[];let cum=0;const y0=Y(mid);p.push([2,y0]);arr.forEach(([k,v])=>{cum+=v;p.push([2+cum/mc*wmax,dir>0?Y((k+1)*r):Y(k*r)])});return p};
    const pa=path(asks,1),pb=path(bids,-1);
    const area=(p,c1,c2)=>{if(p.length<2)return;const gr=lctx.createLinearGradient(2,0,2+wmax,0);gr.addColorStop(0,c1);gr.addColorStop(1,c2);
      lctx.beginPath();p.forEach(([x,y],i)=>i?lctx.lineTo(x,y):lctx.moveTo(x,y));lctx.lineTo(2,p[p.length-1][1]);lctx.closePath();lctx.fillStyle=gr;lctx.fill()};
    area(pa,'rgba(239,68,68,.62)','rgba(239,68,68,.30)');area(pb,'rgba(34,197,94,.55)','rgba(34,197,94,.26)');
    rows.forEach(([k,lo,hi,bv,av])=>{const ya=Y(hi),yb=Y(lo),hh=Math.max(1,yb-ya-(yb-ya>3?1:0));const v=bv+av;if(!v)return;const w=Math.max(1,v/mxv*wmax);
      lctx.fillStyle=`rgba(236,240,246,${(0.45+0.5*v/mxv).toFixed(2)})`;lctx.fillRect(2,ya,w,hh)});
    const line=(p,col)=>{if(p.length<2)return;lctx.beginPath();p.forEach(([x,y],i)=>i?lctx.lineTo(x,y):lctx.moveTo(x,y));lctx.strokeStyle=col;lctx.lineWidth=1.8;lctx.stroke();lctx.lineWidth=1};
    line(pa,'#ff4d5e');line(pb,'#2ee27a');
    lctx.setLineDash([4,3]);lctx.strokeStyle='#64748b';lctx.beginPath();const ym=Math.round(Y(mid))+.5;lctx.moveTo(0,ym);lctx.lineTo(LW,ym);lctx.stroke();lctx.setLineDash([]);
    if(S.my!=null&&S.mx!=null&&S.my<G.pb&&!S.drag){lctx.strokeStyle='rgba(148,163,184,.45)';lctx.setLineDash([4,4]);lctx.beginPath();lctx.moveTo(0,Math.round(S.my)+.5);lctx.lineTo(LW,Math.round(S.my)+.5);lctx.stroke();lctx.setLineDash([])}
    lctx.restore();
  }

  // ------------------------------------------------------------------ panel kanan
  function drawSide(){
    if(!D){lvBody.replaceChildren(h('div',{class:'sg-empty'},'—'));ovBody.replaceChildren(h('div',{class:'sg-empty'},'—'));return}
    const L=D.levels,O=D.overview,dg=D.digits;
    lvTitle.textContent='Key liquidation levels';
    if(!L){lvBody.replaceChildren(h('div',{class:'sg-empty'},'Menunggu data…'))}
    else{
      const all=[...L.above,...L.below];const mx=Math.max(1,...all.map(x=>x.usd));
      const row=(x,cls)=>h('div',{class:'hf-lr',title:'Estimasi likuidasi '+(x.side==='short'?'short':'long')+' '+cm(x.usd)+(x.since?' · terbentuk sejak '+tlab(x.since,D.sec,true):''),onclick:()=>{S.autoY=false;tools.querySelector('.auto').classList.remove('on');const half=(S.ymax-S.ymin)/2;S.ymin=x.price-half;S.ymax=x.price+half;req()}},
        h('span',{class:'p'},fp(x.price,dg)),h('span',{class:'bar'},h('i',{class:cls,style:{width:Math.max(3,x.usd/mx*100)+'%'}})),h('b',null,cm(x.usd)),h('small',{class:x.dist>=0?'up':'dn'},(x.dist>=0?'+':'')+x.dist.toFixed(2)+'%'));
      lvBody.replaceChildren(
        h('div',{class:'hf-sec'},h('i',{class:'dot dn'}),'Above · short liquidations'),
        ...(L.above.length?L.above.map(x=>row(x,'a')):[h('div',{class:'mut hf-none'},'Tidak ada level menonjol')]),
        h('div',{class:'hf-sec'},h('i',{class:'dot up'}),'Below · long liquidations'),
        ...(L.below.length?L.below.map(x=>row(x,'b')):[h('div',{class:'mut hf-none'},'Tidak ada level menonjol')]),
        h('div',{class:'hf-foot mut'},'Estimasi model: kluster level likuidasi aktif (belum tersapu) dalam ±'+O.liq_band_pct.toFixed(1)+'% dari harga. Klik level untuk menuju harganya.'));
    }
    if(!O){ovBody.replaceChildren(h('div',{class:'sg-empty'},'Menunggu data…'));return}
    return drawLiqOverview(O,dg);
  }

  function domBlock(O){
    const vcls=O.verdict==='BUYERS'?'up':O.verdict==='SELLERS'?'dn':'mut',sc=Math.max(-1,Math.min(1,O.score));
    const comp=(n,v)=>v==null?n+' —':n+' '+(v>0?'+':'')+v.toFixed(2);
    return h('div',{class:'hf-dom'},h('div',{class:'hf-kv'},h('span',null,'Dominasi'),h('b',{class:vcls},O.verdict+' ('+(O.score>0?'+':'')+O.score.toFixed(2)+')')),
      h('div',{class:'hf-scale'},h('i',{style:{left:((sc+1)/2*100)+'%'}})),
      h('div',{class:'mut hf-foot',title:'Skor = rata-rata imbalance (−1 penjual … +1 pembeli); |skor| > 0,10 = dominan. Taker = beli vs jual agresif '+O.flow_bars+' candle terakhir; big trade = beli vs jual big trade '+O.flow_bars+' candle terakhir (≥ $'+cm(O.floor)+' per order di TF ini).'},
        comp('taker',O.components.flow)+' · '+comp('big',O.components.big)));
  }
  // Market overview mode LIQUIDATION (tata letak seperti contoh: open liquidation levels, longs vs shorts, liquidated 24h, ...)
  function drawLiqOverview(O,dg){
    const tot=O.liq_total||1,lp=Math.round(O.liq_longs/tot*100),sp=100-lp;
    const kv=(k,v,cls)=>h('div',{class:'hf-kv'},h('span',null,k),h('b',{class:cls||''},v));
    const L=O.liq_largest,hrs=O.liq24_hours>=23.9?'24h':O.liq24_hours.toFixed(1)+'h';
    ovBody.replaceChildren(
      h('div',{class:'mut hf-cap',title:'Jumlah estimasi level likuidasi yang masih aktif (belum tersapu) dalam ±'+O.liq_band_pct.toFixed(1)+'% dari harga, menurut model.'},'Open liquidation levels (est., ±'+O.liq_band_pct.toFixed(1)+'%)'),
      h('div',{class:'hf-big'},cm(O.liq_total)),
      h('div',{class:'hf-split'},h('i',{class:'b',style:{width:lp+'%'}}),h('i',{class:'a',style:{width:sp+'%'}})),
      h('div',{class:'hf-two'},h('div',null,h('small',null,h('i',{class:'dot up'}),'Longs (below price)'),h('b',null,cm(O.liq_longs)+' '),h('small',{class:'mut'},lp+'%')),
        h('div',{style:{textAlign:'right'}},h('small',null,h('i',{class:'dot dn'}),'Shorts (above price)'),h('b',null,cm(O.liq_shorts)+' '),h('small',{class:'mut'},sp+'%'))),
      kv('Liquidated in '+hrs+' (est.)','$'+cm(O.liq24)),
      kv('of which longs / shorts','$'+cm(O.liq24_long)+' / $'+cm(O.liq24_short)),
      kv('Largest single level',L?cm(L.usd)+' @ '+fp(L.price,dg):'—',L?(L.side==='long'?'up':'dn'):''),
      kv('Price step / column period',fp(O.row,dg)+' / '+D.tf),
      kv('Taker buy / sell ('+O.flow_bars+')','$'+cm(O.taker_buy)+' / $'+cm(O.taker_sell)),
      kv('Big trades buy / sell','$'+cm(O.big_buy)+' / $'+cm(O.big_sell)),
      domBlock(O));
  }

  // ------------------------------------------------------------------ admin: PILIH PAIR
  async function openPicker(){
    let c;
    try{c=await T.rawFetch('heatmap/control')}catch(e){alert('Gagal memuat daftar pair: '+e.message);return}
    const sel=new Set(c.pairs),errEl=h('span',{class:'dn'});
    const modal=h('div',{class:'sg-modal hf-modal',onclick:e=>{if(e.target===modal)modal.remove()}});
    const st=(c.status&&c.status.pairs)||{};
    const chips=h('div',{class:'hf-chips'});
    const draw=()=>chips.replaceChildren(...c.catalog.map(p=>{const s=st[p.sym];return h('button',{class:'hf-chip'+(sel.has(p.sym)?' on':''),'data-sym':p.sym,onclick:()=>{sel.has(p.sym)?sel.delete(p.sym):sel.add(p.sym);draw()}},
      h('b',null,p.sym),h('span',null,p.name),h('small',{class:s&&s.state==='live'?'up':'mut'},s?('● '+s.state):(sel.has(p.sym)?'akan dipantau':'tidak dipantau')))}));
    draw();
    modal.append(h('div',{class:'box',style:{width:'min(620px,100%)'}},
      h('div',{class:'row',style:{marginBottom:'6px'}},h('b',null,'PILIH PAIR HEATMAP'),h('span',{style:{flex:1}}),h('button',{class:'btn',onclick:()=>modal.remove()},'Tutup')),
      h('div',{class:'mut',style:{fontSize:'11px',marginBottom:'8px'}},'Hanya pair yang dipilih yang dipantau server (WebSocket trade & candle Binance Spot) dan bisa dibuka user. Pair yang tidak dipilih tidak dipantau sama sekali.'),
      chips,
      h('div',{class:'ft'},h('button',{class:'btn',onclick:()=>{c.catalog.forEach(p=>sel.add(p.sym));draw()}},'Pilih semua'),h('button',{class:'btn',onclick:()=>{sel.clear();draw()}},'Kosongkan'),
        h('span',{style:{flex:1}}),errEl,h('button',{class:'sg-btn on',onclick:async()=>{try{errEl.textContent='';await postControl({pairs:[...sel]});modal.remove();await loadPairs();if(VW.sym&&(!D||D.symbol!==VW.sym))full(true)}catch(e){errEl.textContent=e.message}}},'SIMPAN'))));
    document.body.append(modal);
  }

  // ------------------------------------------------------------------ mulai
  document.addEventListener('visibilitychange',function vis(){if(!alive()){document.removeEventListener('visibilitychange',vis);return}if(!document.hidden)live()});
  layout();drawBar();drawSide();showMsg();
  loadPairs().then(()=>{if(alive())full(true)});
  T.every(1000,live);
  T.every(10000,loadPairs);
};
})();
