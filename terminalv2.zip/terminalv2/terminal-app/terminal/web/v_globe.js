// =====================================================================================================================
// GLOBE 3D (GEOPOLITICAL RISK): bola dunia interaktif di <canvas> (proyeksi ortografik d3-geo, dimuat lokal saat dibutuhkan)
//   - seret = putar (dengan inersia) · roda / cubit = zoom · klik dua kali = dekati titik · tombol + − ⟲ ▶
//   - negara diwarnai menurut level risiko; event, hotspot, choke point & pelabuhan PortWatch sebagai penanda
//   - hanya sisi yang menghadap layar yang digambar (penanda di balik bola disembunyikan)
//   - loop gambar berhenti otomatis saat menu ditinggalkan / tab tersembunyi
// =====================================================================================================================
(function(){
const h=T.h;
const D2R=Math.PI/180;

// d3-geo dimuat hanya ketika globe pertama kali dibuka (±54 KB, tanpa CDN)
T.loadD3Geo=()=>window.d3&&window.d3.geoOrthographic?Promise.resolve(window.d3):(T._d3p||(T._d3p=new Promise((ok,no)=>{
  const s=document.createElement('script');s.src='vendor/d3-geo.min.js'+(window.__V?'?v='+window.__V:'');
  s.onload=()=>ok(window.d3);s.onerror=()=>{T._d3p=null;no(new Error('gagal memuat d3-geo'))};document.head.append(s)})));

// Peta dunia untuk bola: berkas yang sama dengan peta datar, tetapi TANPA perbaikan garis tanggal (bola tidak butuh)
// - 3 tingkat detail (LOD) menurut zoom: ±16 rb / ±27 rb / ±45 rb titik -> putaran tetap mulus di laptop & ponsel
// - arah lingkar poligon diseragamkan untuk geometri bola d3 (luas > setengah bola = arah terbalik)
// - tiap negara punya "tudung" (pusat + jari-jari sudut) untuk membuang negara di balik bola sebelum diproyeksikan
const LOD=[0.45,0.22,0.1];
let WORLD=null;
function loadGlobeWorld(d3){
  return WORLD||(WORLD=fetch('vendor/world.geojson'+(window.__V?'?v='+window.__V:'')).then(r=>r.json()).then(raw=>{
    const thin=(r,t)=>{const o=[r[0]];for(let i=1;i<r.length-1;i++){const a=o[o.length-1],c=r[i];if(Math.abs(c[0]-a[0])+Math.abs(c[1]-a[1])>t)o.push(c)}o.push(r[r.length-1]);return o};
    const build=(polys,t)=>{const ps=polys.map(p=>p.map(r=>thin(r,t)).filter(r=>r.length>=4)).filter(p=>p.length);
      ps.forEach(p=>{if(d3.geoArea({type:'Polygon',coordinates:p})>2*Math.PI)p.forEach(r=>r.reverse())});
      return ps.length?{type:'MultiPolygon',coordinates:ps}:null};
    const feats=[];
    raw.features.forEach(f=>{const g=f.geometry;if(!g)return;
      const polys=g.type==='Polygon'?[g.coordinates]:g.coordinates;
      const lod=LOD.map(t=>build(polys,t));const hi=lod[2]||lod[1]||lod[0];if(!hi)return;
      for(let i=0;i<3;i++)if(!lod[i])lod[i]=hi;
      const c=d3.geoCentroid(hi);let rad=0;lod[0].coordinates.forEach(p=>p[0].forEach(q=>{const d=d3.geoDistance(c,q);if(d>rad)rad=d}));
      feats.push({n:f.properties.n,lod,geo:hi,b:d3.geoBounds(hi),c,rad:rad+0.02});
    });
    return feats;
  }).catch(e=>{WORLD=null;throw e}));
}

// siluet (menghadap ke utara, pusat 0,0): pesawat ±13 px, kapal ±8 px
const PLANE=new Path2D('M0,-7 L1.2,-3.5 L1.2,-1 L6.5,2.2 L6.5,3.4 L1.2,1.6 L1,4.6 L2.6,5.8 L2.6,6.6 L0,5.9 L-2.6,6.6 L-2.6,5.8 L-1,4.6 L-1.2,1.6 L-6.5,3.4 L-6.5,2.2 L-1.2,-1 L-1.2,-3.5 Z');
const SHIP=new Path2D('M0,-4.5 L2,-1 L2,3.6 L-2,3.6 L-2,-1 Z');
const inBounds=(b,lon,lat)=>{const [[w,s],[e,n]]=b;if(lat<s-.5||lat>n+.5)return false;return w<=e?(lon>=w-.5&&lon<=e+.5):(lon>=w-.5||lon<=e+.5)};
const norm=a=>((a+180)%360+360)%360-180;

// el: wadah (position:relative); opts: {colors:{risk:{LEVEL:[warna,alpha]},sev:{},lvl:{}}, tip:(kind,obj)=>html}
T.globe=function(el,opts){
  const host=h('div',{class:'globe'});
  const cv=h('canvas',{class:'gl-cv','aria-label':'Globe risiko geopolitik — seret untuk memutar, gulir untuk zoom'});
  const tip=h('div',{class:'gl-tip'});
  const btn=(lab,title,fn)=>h('button',{class:'gl-b',title,'aria-label':title,onclick:e=>{e.stopPropagation();fn()}},lab);
  const IC={pause:'<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>',
    play:'<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.4-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>',
    reset:'<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 12a8 8 0 1 0 2.4-5.7M4 4v4h4"/></svg>'};
  const playB=btn('','Putar otomatis',()=>{auto=!auto;setPlay();idleAt=0;kick()});
  const setPlay=()=>{playB.innerHTML=auto?IC.pause:IC.play;playB.title=auto?'Jeda putaran otomatis':'Putar otomatis';playB.classList.toggle('off',!auto)};
  const ctl=h('div',{class:'gl-ctl'},btn('+','Perbesar',()=>zoomTo(K*1.5)),btn('−','Perkecil',()=>zoomTo(K/1.5)),btn('','Atur ulang',()=>fly(20,15,1)),playB);
  const hint=h('div',{class:'gl-hint'},'seret = putar · gulir/cubit = zoom · klik 2× = dekati');
  host.append(cv,tip,ctl,hint);el.append(host);
  const ctx=cv.getContext('2d');
  const gen=T.gen;
  let d3=null,feats=[],scene=null,proj=null,path=null,grat=null;
  let Wd=0,Ht=0,dpr=1,R0=1,K=1;
  let rot=[-20,-15],vel=[0,0],auto=!matchMedia('(prefers-reduced-motion: reduce)').matches,idleAt=0;
  let drag=null,pinch=null,hover=null,anim=null,raf=0,last=0,dead=false;
  const pts=new Map();
  setPlay();ctl.children[2].innerHTML=IC.reset;

  // resolusi adaptif: bila perangkat tidak sanggup ±20 fps, kepadatan piksel kanvas diturunkan bertahap (min. 1)
  let dprCap=Math.min(2,window.devicePixelRatio||1),ema=0,frames=0;
  const bgC=document.createElement('canvas'),shC=document.createElement('canvas');let layerKey='';
  function size(){
    const r=host.getBoundingClientRect();Wd=Math.max(200,r.width);Ht=Math.max(200,r.height);dpr=dprCap;
    cv.width=Math.round(Wd*dpr);cv.height=Math.round(Ht*dpr);cv.style.width=Wd+'px';cv.style.height=Ht+'px';
    R0=Math.min(Wd,Ht)*0.44;if(proj)proj.translate([Wd/2,Ht/2]).scale(R0*K);draw();
  }
  const ro=new ResizeObserver(()=>size());ro.observe(host);
  // T.dispose() memanggil remove() & _ro.disconnect() untuk setiap entri T.maps
  const handle={remove:()=>{dead=true;cancelAnimationFrame(raf);ro.disconnect()},_ro:ro};
  T.maps.push(handle);

  const center=()=>[-rot[0],-rot[1]];
  const visible=(lon,lat)=>d3.geoDistance([lon,lat],center())<Math.PI/2-0.03;

  const stats={ms:0,n:0};
  function draw(){const t0=performance.now();draw0();stats.ms=performance.now()-t0;stats.n++}
  // lapisan statis (hanya digambar ulang saat ukuran/zoom berubah): atmosfer+lautan di bawah, bayangan tepi+garis tepi di atas
  function layers(s,cx,cy){
    const key=cv.width+'x'+cv.height+'@'+dpr+':'+s.toFixed(1);if(key===layerKey)return;layerKey=key;
    for(const c of [bgC,shC]){c.width=cv.width;c.height=cv.height}
    let x=bgC.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);
    let g=x.createRadialGradient(cx,cy,s*0.97,cx,cy,s*1.22);g.addColorStop(0,'rgba(76,201,240,.20)');g.addColorStop(.35,'rgba(76,201,240,.06)');g.addColorStop(1,'rgba(76,201,240,0)');
    x.fillStyle=g;x.beginPath();x.arc(cx,cy,s*1.22,0,2*Math.PI);x.fill();
    g=x.createRadialGradient(cx-s*.38,cy-s*.42,s*.05,cx,cy,s);g.addColorStop(0,'#1b2c42');g.addColorStop(.55,'#0d1724');g.addColorStop(1,'#070b11');   // cahaya dari kiri atas
    x.fillStyle=g;x.beginPath();x.arc(cx,cy,s,0,2*Math.PI);x.fill();
    x=shC.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);
    g=x.createRadialGradient(cx-s*.3,cy-s*.35,s*.15,cx,cy,s*1.01);g.addColorStop(0,'rgba(255,255,255,.05)');g.addColorStop(.62,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.55)');
    x.fillStyle=g;x.beginPath();x.arc(cx,cy,s,0,2*Math.PI);x.fill();x.lineWidth=1;x.strokeStyle='rgba(76,201,240,.35)';x.stroke();
  }
  function draw0(){
    if(!proj||dead)return;
    proj.rotate(rot).scale(R0*K);
    const t=performance.now(),s=R0*K,cx=Wd/2,cy=Ht/2;
    layers(s,cx,cy);
    ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,cv.width,cv.height);ctx.drawImage(bgC,0,0);   // atmosfer + lautan (bitmap tersimpan)
    ctx.setTransform(dpr,0,0,dpr,0,0);
    // graticule
    ctx.beginPath();path(grat);ctx.lineWidth=.6;ctx.strokeStyle='rgba(130,160,200,.09)';ctx.stroke();
    // daratan: hanya negara yang menghadap layar / masuk bidang pandang; detail menurut zoom; satu jalur per kelompok warna
    const moving=!!(drag||pinch||anim||Math.abs(vel[0])+Math.abs(vel[1])>.01);
    const sc=scene||{},cmap=sc.countries||{},li=Math.max(0,(K>=5?2:K>=2.8?1:0)-(moving?1:0)),cen=center(),view=Math.min(Math.PI/2,Math.asin(Math.min(1,Math.hypot(Wd,Ht)/2/s)))+0.05;
    const groups=new Map([['',[]]]);let drawn=0;
    feats.forEach(f=>{if(d3.geoDistance(f.c,cen)-f.rad>view)return;const c=cmap[f.n];const k=c?c[0]+'|'+c[1]:'';(groups.get(k)||groups.set(k,[]).get(k)).push(f);drawn++});
    stats.feats=drawn;stats.lod=li;
    groups.forEach((fs,k)=>{if(!fs.length)return;
      ctx.beginPath();fs.forEach(f=>path(f.lod[li]));ctx.fillStyle='#18202c';ctx.fill();
      if(k){const [col,al]=k.split('|');ctx.globalAlpha=+al;ctx.fillStyle=col;ctx.fill();ctx.globalAlpha=.9;ctx.lineWidth=.8;ctx.strokeStyle=col}else{ctx.lineWidth=.5;ctx.strokeStyle='#2f3b4f'}
      ctx.stroke();ctx.globalAlpha=1});
    if(hover&&hover.kind==='country'){ctx.beginPath();path(hover.f.lod[li]);ctx.lineWidth=1.6;ctx.strokeStyle='#f0e6cf';ctx.stroke();ctx.fillStyle='rgba(240,230,207,.08)';ctx.fill()}
    // garis (mis. rute pelayaran): dipotong otomatis di tepi bola oleh proyeksi
    (sc.lines||[]).forEach(l=>{ctx.beginPath();path(l.geo);ctx.lineWidth=(l.width||1)*Math.min(1.8,Math.sqrt(K));ctx.strokeStyle=l.color;if(l.dash)ctx.setLineDash(l.dash);ctx.stroke();ctx.setLineDash([])});
    // bayangan tepi bola -> kesan 3D
    ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(shC,0,0);ctx.setTransform(dpr,0,0,dpr,0,0);
    // penanda: titik kecil sewarna digambar satu jalur (ribuan kapal AIS tetap ringan)
    const pts=sc.points||[],batch=new Map(),zr=Math.min(1.6,Math.sqrt(K));
    for(let i=0;i<pts.length;i++){const p=pts[i];if(p.lat==null||!visible(p.lon,p.lat))continue;const q=proj([p.lon,p.lat]);p._q=q;
      switch(p.shape){
        case 'glow':{const r=(p.r||8)*zr,gg=ctx.createRadialGradient(q[0],q[1],0,q[0],q[1],r);gg.addColorStop(0,p.color);gg.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=gg;ctx.beginPath();ctx.arc(q[0],q[1],r,0,2*Math.PI);ctx.fill();break}
        case 'diamond':{ctx.save();ctx.translate(q[0],q[1]);ctx.rotate(Math.PI/4);const r=p.r||4.5;ctx.fillStyle=p.color;ctx.strokeStyle='#000';ctx.lineWidth=1;ctx.fillRect(-r,-r,2*r,2*r);ctx.strokeRect(-r,-r,2*r,2*r);ctx.restore();break}
        case 'ship':if(K<3){const k=p.color+'|1.6';(batch.get(k)||batch.set(k,[]).get(k)).push(q);break}   // jauh: titik (ribuan kapal tetap ringan)
        // fallthrough: diperbesar -> siluet kapal searah haluan
        case 'plane':{let ang=0;if(p.heading!=null){const h=p.heading*Math.PI/180,q2=proj([p.lon+Math.sin(h)*0.6/Math.max(.2,Math.cos(p.lat*Math.PI/180)),p.lat+Math.cos(h)*0.6]);if(q2)ang=Math.atan2(q2[0]-q[0],-(q2[1]-q[1]))}
          ctx.save();ctx.translate(q[0],q[1]);ctx.rotate(ang);const z=(p.r||1)*(K>2.5?1.25:1);ctx.scale(z,z);ctx.fillStyle=p.color;ctx.strokeStyle='rgba(0,0,0,.75)';ctx.lineWidth=1/z;
          ctx.fill(p.shape==='plane'?PLANE:SHIP);ctx.stroke(p.shape==='plane'?PLANE:SHIP);ctx.restore();break}
        default:{if(!p.pulse&&!p.stroke&&(p.r||2)<=2.6){const k=p.color+'|'+(p.r||2);(batch.get(k)||batch.set(k,[]).get(k)).push(q);break}
          if(p.pulse){const ph=((t/1700)+i*.17)%1;ctx.beginPath();ctx.arc(q[0],q[1],(p.r||4)+ph*14,0,2*Math.PI);ctx.strokeStyle=p.color;ctx.globalAlpha=(1-ph)*.8;ctx.lineWidth=1.4;ctx.stroke();ctx.globalAlpha=1}
          ctx.beginPath();ctx.arc(q[0],q[1],p.r||3.4,0,2*Math.PI);ctx.fillStyle=p.color;ctx.fill();ctx.lineWidth=1;ctx.strokeStyle='rgba(0,0,0,.7)';ctx.stroke()}
      }}
    batch.forEach((qs,k)=>{const [col,r]=k.split('|');const rr=+r;ctx.fillStyle=col;ctx.beginPath();qs.forEach(q=>{ctx.moveTo(q[0]+rr,q[1]);ctx.arc(q[0],q[1],rr,0,2*Math.PI)});ctx.fill()});
    // label negara (sesudah penanda, digeser ke bawah titik pusat, tanpa saling tumpuk): tingkat 0 selalu, 1 bila bola tidak kecil, 2 bila diperbesar
    const small=s<190,placed=[],fs=K>2.5?11:10,fmap=labelIndex();
    ctx.font='600 '+fs+'px '+T.FONT;ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineJoin='round';
    (sc.labels||[]).forEach(lb=>{const f=fmap.get(lb.name);if(!f)return;const lv=lb.level||0;
      if(!(lv===0&&!(small&&lb.small===false)||lv===1&&!small||K>=2.2))return;if(!visible(f.c[0],f.c[1]))return;
      const p=proj(f.c);if(!p)return;const txt=(lb.text||f.n).toUpperCase(),w=ctx.measureText(txt).width,x=p[0],y=p[1]+13;
      const box=[x-w/2-3,y-fs/2-2,x+w/2+3,y+fs/2+2];if(placed.some(b=>!(box[2]<b[0]||box[0]>b[2]||box[3]<b[1]||box[1]>b[3])))return;placed.push(box);
      ctx.lineWidth=3;ctx.strokeStyle='rgba(5,8,12,.85)';ctx.strokeText(txt,x,y);ctx.fillStyle='rgba(240,232,214,.92)';ctx.fillText(txt,x,y)});
    ctx.textBaseline='alphabetic';
    if(hover&&hover.kind!=='country'&&hover.p&&hover.p._q){const q=hover.p._q;ctx.beginPath();ctx.arc(q[0],q[1],9,0,2*Math.PI);ctx.strokeStyle='#f0e6cf';ctx.lineWidth=1.4;ctx.stroke()}
  }
  let _lbl=null;
  function labelIndex(){if(!_lbl){_lbl=new Map();feats.forEach(f=>_lbl.set(f.n,f))}return _lbl}

  // satu loop rAF: putar otomatis, inersia, animasi terbang, denyut event CRITICAL (±30 fps)
  function needsLoop(){const pulse=!!(scene&&scene.pulse);return !!(anim||drag||pinch||Math.abs(vel[0])+Math.abs(vel[1])>.01||(auto&&!idle())||pulse)}
  let over=false;   // kursor di atas bola -> putaran otomatis berhenti supaya mudah dibaca
  const idle=()=>over||(idleAt&&performance.now()<idleAt);   // jeda putar otomatis sesudah interaksi
  function kick(){if(!raf&&!dead)raf=requestAnimationFrame(tick)}
  function tick(now){
    raf=0;
    if(dead||T.gen!==gen||!host.isConnected){handle.remove();return}
    if(document.hidden){setTimeout(kick,500);return}
    const el=last?now-last:33;
    if(el<30&&!drag&&!pinch&&!anim){raf=requestAnimationFrame(tick);return}   // ±30 fps saat hanya berputar/berdenyut
    const dt=Math.min(64,el);last=now;
    if(el<200){ema=ema?ema*.9+el*.1:el;if(++frames>24&&ema>50&&dprCap>1){dprCap=Math.max(1,dprCap-.5);frames=0;ema=0;size()}}
    if(anim){const p=Math.min(1,(now-anim.t0)/anim.dur),e=p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2;
      rot=[anim.r0[0]+anim.dr[0]*e,anim.r0[1]+anim.dr[1]*e];K=anim.k0+(anim.k1-anim.k0)*e;if(p>=1)anim=null}
    else if(!drag&&!pinch&&(Math.abs(vel[0])+Math.abs(vel[1])>.01)){rot[0]+=vel[0];rot[1]=Math.max(-89,Math.min(89,rot[1]+vel[1]));vel=[vel[0]*.93,vel[1]*.93]}
    else if(auto&&!idle()&&!drag&&!pinch)rot[0]+=dt*0.004;   // ±4°/detik
    draw();
    if(needsLoop())raf=requestAnimationFrame(tick);
  }

  function zoomTo(k){K=Math.max(.8,Math.min(9,k));idleAt=performance.now()+6000;draw();kick()}
  function fly(lon,lat,k){if(!proj)return;const r1=[-lon,-lat];let d0=norm(r1[0]-rot[0]);
    anim={t0:performance.now(),dur:900,r0:rot.slice(),dr:[d0,r1[1]-rot[1]],k0:K,k1:k==null?K:Math.max(.8,Math.min(9,k))};vel=[0,0];idleAt=performance.now()+8000;kick()}

  // ---- interaksi ----
  const local=e=>{const r=cv.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top]};
  cv.addEventListener('pointerdown',e=>{
    if(!proj)return;cv.setPointerCapture(e.pointerId);pts.set(e.pointerId,local(e));anim=null;vel=[0,0];idleAt=performance.now()+6000;
    if(pts.size===2){const [a,b]=[...pts.values()];pinch={d:Math.hypot(a[0]-b[0],a[1]-b[1]),k:K};drag=null}
    else{drag={p:local(e),t:performance.now(),moved:0}}
    hideTip();kick();
  });
  cv.addEventListener('pointermove',e=>{
    if(!proj)return;const p=local(e);
    if(pts.has(e.pointerId))pts.set(e.pointerId,p);
    if(pinch&&pts.size===2){const [a,b]=[...pts.values()];const d=Math.hypot(a[0]-b[0],a[1]-b[1]);K=Math.max(.8,Math.min(9,pinch.k*d/Math.max(1,pinch.d)));kick();return}
    if(drag){const dx=p[0]-drag.p[0],dy=p[1]-drag.p[1],deg=57.2958/(R0*K);
      rot[0]+=dx*deg;rot[1]=Math.max(-89,Math.min(89,rot[1]-dy*deg));drag.moved+=Math.abs(dx)+Math.abs(dy);
      const now=performance.now(),dtm=Math.max(8,now-drag.t);vel=[dx*deg*16/dtm,-dy*deg*16/dtm];drag.p=p;drag.t=now;kick();return}
    if(e.pointerType==='mouse')queueHover(p);
  });
  const end=e=>{pts.delete(e.pointerId);
    if(pinch){if(pts.size<2)pinch=null;return}
    if(drag){const tap=drag.moved<6;drag=null;if(tap){vel=[0,0];queueHover(local(e),true)}else kick()}};
  cv.addEventListener('pointerup',end);cv.addEventListener('pointercancel',end);
  cv.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse')over=true});
  cv.addEventListener('pointerleave',e=>{if(e.pointerType!=='mouse')return;over=false;idleAt=Math.max(idleAt,performance.now()+1500);if(!drag){hover=null;hideTip();draw()}kick()});
  cv.addEventListener('wheel',e=>{if(!proj)return;e.preventDefault();zoomTo(K*Math.exp(-e.deltaY*0.0016))},{passive:false});
  cv.addEventListener('dblclick',e=>{if(!proj)return;const ll=proj.invert(local(e));if(ll&&visible(ll[0],ll[1]))fly(ll[0],ll[1],K*1.8)});

  let hq=null;
  function queueHover(p,sticky){hq=[p,sticky];requestAnimationFrame(()=>{if(!hq)return;const [pp,st]=hq;hq=null;doHover(pp,st)})}
  function doHover(p,sticky){
    const s=R0*K,dx=p[0]-Wd/2,dy=p[1]-Ht/2;
    if(dx*dx+dy*dy>s*s){hover=null;hideTip();draw();return}
    let best=null,bd=10;
    // penanda: yang terdekat dalam 10 px; prioritas lebih tinggi menang bila jaraknya hampir sama
    ((scene&&scene.points)||[]).forEach(pt=>{if(!pt.kind||pt.lat==null||!visible(pt.lon,pt.lat))return;const q=proj([pt.lon,pt.lat]);const d=Math.hypot(q[0]-p[0],q[1]-p[1])-(pt.prio||0);
      if(d<bd){bd=d;pt._q=q;best={kind:pt.kind,o:pt.obj,p:pt}}});
    if(!best){const ll=proj.invert(p);if(ll){const f=feats.find(f=>inBounds(f.b,ll[0],ll[1])&&d3.geoContains(f.geo,ll));if(f)best={kind:'country',f,o:f}}}
    hover=best;draw();
    if(!best){hideTip();return}
    const html=opts.tip(best.kind,best.kind==='country'?best.f.n:best.o);
    if(!html){hideTip();return}
    tip.innerHTML=html;tip.classList.add('on');
    const tw=tip.offsetWidth,th=tip.offsetHeight;let x=p[0]+14,y=p[1]+14;if(x+tw>Wd-6)x=p[0]-tw-14;if(y+th>Ht-6)y=p[1]-th-14;
    tip.style.transform=`translate(${Math.max(6,x)}px,${Math.max(6,y)}px)`;
    if(sticky){clearTimeout(tip._t);tip._t=setTimeout(hideTip,4000)}
  }
  function hideTip(){tip.classList.remove('on')}

  // ---- data ----
  const ready=T.loadD3Geo().then(_d3=>{d3=_d3;return loadGlobeWorld(d3)}).then(f=>{
    if(dead)return;feats=f;
    // data sudah rapat: tanpa resampling adaptif (lebih cepat)
    proj=d3.geoOrthographic().clipAngle(90).precision(0);path=d3.geoPath(proj,ctx);grat=d3.geoGraticule10();
    size();kick();
  }).catch(e=>{host.append(h('div',{class:'msg err gl-err'},'Globe tidak dapat dimuat: '+e.message))});

  return {
    // scene: {countries:{nama:[warna,alpha]}, lines:[{geo,color,width,dash}], points:[{lon,lat,shape,color,r,pulse,heading,kind,obj,prio}], labels:[{name,level,text}], pulse:bool}
    setScene(sc){scene=sc;ready.then(()=>{draw();kick()})},
    focus(lon,lat,k){ready.then(()=>{if(lon!=null&&lat!=null)fly(lon,lat,k==null?Math.max(K,2.2):k)})},
    get k(){return K},
    stats,
    el:host,
  };
};
})();
