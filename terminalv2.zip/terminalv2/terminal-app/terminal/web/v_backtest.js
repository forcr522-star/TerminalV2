(function(){
// Menu BACKTEST (hanya admin) — di dalam menu SIGNAL, dibuka lewat tombol BACKTEST.
// Selama berjalan server menjeda analisa & tracker (fitur lain) agar PC ringan; setelah selesai otomatis hidup lagi.
const h=T.h;
const nd=v=>(v==null||isNaN(v))?'—':Number(v).toFixed(2);
const pct=v=>(v==null)?'—':(Number(v)*100).toFixed(1)+'%';
const R=v=>(v==null)?'—':(Number(v)>0?'+':'')+Number(v).toFixed(2)+'R';
const today=()=>new Date().toISOString().slice(0,10);
const ago=(d)=>new Date(d*1000).toISOString().slice(0,10);

async function post(body){
  const r=await fetch('/api/signal/backtest',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  if(r.status===401){location.reload();throw new Error('Sesi berakhir')}
  let j={};try{j=await r.json()}catch(e){}
  if(!r.ok||j.error)throw new Error(j.error||('HTTP '+r.status));
  return j;
}

let modal=null,poll=null,S=null;

function card(label,value,cls){
  return h('div',{class:'bt-card'+(cls?' '+cls:'')},h('small',null,label),h('b',null,value));
}

function drawResults(out,body){
  const last=out.last||{};
  const m=last.metrics||{};
  body.append(h('div',{class:'bt-res'},h('div',{class:'bt-cards'},
    card('SINYAL',m.signals??'—'),
    card('FILL RATE',pct(m.fill_rate)),
    card('POSITIVE',pct(m.pos_rate),(m.pos_rate||0)>=0.5?'up':'dn'),
    card('RATA-RATA R',R(m.avg_r),(m.avg_r||0)>0?'up':'dn'),
    card('PER SINYAL',R(m.avg_r_signal)),
    card('PROFIT FACTOR',m.pf==null?'—':Number(m.pf).toFixed(2)),
    card('MAX DD',R(m.max_dd),'dn'),
    card('TP1/2/MAX',pct(m.tp1)+' / '+pct(m.tp2)+' / '+pct(m.tp3)))));
  if(last.by_pair&&Object.keys(last.by_pair).length){
    const rows=Object.entries(last.by_pair).map(([sym,x])=>h('tr',null,
      h('td',null,h('b',null,sym)),h('td',null,x.signals??0),h('td',null,pct(x.fill_rate)),h('td',null,pct(x.pos_rate)),
      h('td',{class:(x.avg_r||0)>0?'up':'dn'},R(x.avg_r)),h('td',null,x.pf==null?'—':Number(x.pf).toFixed(2))));
    body.append(h('div',{class:'bt-block'},h('div',{class:'bt-title'},'PER PAIR'),
      h('table',{class:'bt-tab'},h('thead',null,h('tr',null,['PAIR','SINYAL','FILL','POSITIVE','RATA-RATA','PF'].map(x=>h('th',null,x)))),h('tbody',null,...rows))));
  }
  const ls=(out.lessons||last.lessons||[]).slice(0,14);
  if(ls.length){
    body.append(h('div',{class:'bt-block'},h('div',{class:'bt-title'},'LOG BELAJAR (dipakai menu SIGNAL)'),
      ...ls.map(l=>h('div',{class:'bt-lesson '+(l.verdict==='AVOID'?'bad':l.verdict==='GOOD'?'good':'')},
        h('b',null,(l.source||'')+' '+(l.side||'')+' · '+(l.families||'—')+' · '+(l.regime||'?')),
        h('span',null,`${l.n} trade · rata-rata ${R(l.avg_r)} · LCB ${R(l.lcb)} · ${l.verdict}`)))));
  }
  const tr=(out.trades||[]).slice(0,80);
  if(tr.length){
    body.append(h('div',{class:'bt-block'},h('div',{class:'bt-title'},'CONTOH TRADE TERAKHIR'),
      h('table',{class:'bt-tab'},h('thead',null,h('tr',null,['WAKTU','PAIR','SISI','STATUS','R','PELAJARAN'].map(x=>h('th',null,x)))),
        h('tbody',null,...tr.map(t=>h('tr',null,h('td',null,(t.ts||'').slice(0,16)),h('td',null,t.sym),h('td',{class:t.side==='BUY'?'up':'dn'},t.side),
          h('td',null,t.status),h('td',{class:(t.r||0)>0?'up':'dn'},R(t.r)),h('td',{class:'bt-note'},t.lesson||'')))))));
  }
}

async function refresh(){
  if(!modal)return;
  const body=modal.querySelector('.bt-body');
  let out;
  try{out=await T.rawFetch('signal/backtest',{detail:1})}catch(e){body.replaceChildren(h('div',{class:'msg err'},e.message));return}
  const st=out.status||{};
  const head=modal.querySelector('.bt-live');
  if(st.running){
    const pctd=st.total?Math.round(st.done/st.total*100):0;
    head.replaceChildren(h('div',{class:'bt-run'},h('b',null,'BACKTEST BERJALAN'),h('span',null,` ${st.mode||''} · ${st.done}/${st.total} pair · ${st.current||''}`),
      h('div',{class:'bt-bar'},h('i',{style:{width:pctd+'%'}})),
      h('span',{class:'mut'},'Fitur terminal lain dijeda sementara. Anda bisa menutup jendela ini; backtest tetap berjalan.')));
  }else{
    head.replaceChildren(h('div',{class:'bt-run '+(st.error?'bad':'')},h('b',null,st.error?'BACKTEST GAGAL / DIHENTIKAN':'BACKTEST SELESAI'),
      h('span',{class:'mut'},st.finished?' · '+(new Date(st.finished*1000)).toLocaleString():' · belum dijalankan'),
      st.error?h('span',{class:'dn'},' '+st.error):'',
      // pair yang gagal diuji (data kosong / rentang terlalu pendek) ditampilkan, tidak lagi diam-diam jadi "0 sinyal"
      (out.last&&out.last.errors&&out.last.errors.length)?h('div',{class:'dn',style:{fontSize:'11px',marginTop:'4px'}},'Pair gagal diuji: '+out.last.errors.join(' · ')):''));
  }
  const res=body.querySelector('.bt-dyn');
  res.replaceChildren();
  if(out.last&&out.last.metrics)drawResults(out,res);
  const btn=modal.querySelector('.bt-start');
  btn.disabled=!!st.running;
  modal.querySelector('.bt-stop').disabled=!st.running;
}

async function open(){
  if(modal){clearInterval(poll);poll=null;modal.remove();modal=null;}
  modal=h('div',{class:'sg-modal'});
  let cat={classes:{},order:[]};
  try{cat=await T.rawFetch('signal/catalog')}catch(e){}
  const mode=h('select',{class:'bt-in'},h('option',{value:'swing'},'SWING (D1)'),h('option',{value:'intraday'},'INTRADAY (H1)'),h('option',{value:'scalp'},'SCALPING (M5)'));
  const start=h('input',{class:'bt-in',type:'date',value:(()=>{const d=new Date();d.setFullYear(d.getFullYear()-2);return d.toISOString().slice(0,10)})()});
  const end=h('input',{class:'bt-in',type:'date',value:today()});
  const be=h('input',{type:'checkbox',checked:true});
  const pairBox=h('div',{class:'bt-pairs'});
  const allSyms=[];
  (cat.order||[]).forEach(c=>(cat.classes[c]||[]).forEach(a=>allSyms.push(a)));
  const sel=new Set((cat.default||[]).slice(0,6));
  allSyms.forEach(a=>pairBox.append(h('label',{class:'bt-chip'},h('input',{type:'checkbox',checked:sel.has(a.sym),onchange:e=>{e.target.checked?sel.add(a.sym):sel.delete(a.sym)}}),a.sym)));
  const msg=h('span',{class:'mut'});
  const startBtn=h('button',{class:'btn bt-start',onclick:async()=>{
    msg.textContent='';
    try{
      if(!sel.size)throw new Error('pilih minimal satu pair');
      await post({action:'start',mode:mode.value,be:be.checked,start:start.value,end:end.value,pairs:[...sel]});
      refresh();
    }catch(e){msg.textContent=e.message;msg.className='dn'}
  }},'MULAI BACKTEST');
  const stopBtn=h('button',{class:'btn bt-stop',onclick:async()=>{try{await post({action:'stop'})}catch(e){} refresh()}},'HENTIKAN');
  const body=h('div',{class:'bt-body'},h('div',{class:'bt-block'},h('div',{class:'bt-title'},'PENGATURAN'),
    h('div',{class:'bt-form'},h('label',null,'GAYA',mode),h('label',null,'DARI',start),h('label',null,'SAMPAI',end),
      h('label',{class:'bt-check'},be,' BREAKEVEN ON'),startBtn,stopBtn,msg),
    h('div',{class:'mut bt-note'},'Backtest menguji SELURUH strategi menu SIGNAL (teknikal, volume/liquidity, fundamental sebagai overlay, dan quant) pada rentang data yang tersedia. Selama berjalan, analisa & fitur lain dijeda sementara.'),
    h('div',{class:'bt-title'},'PAIR (maks. 12)'),pairBox),
    h('div',{class:'bt-dyn'}));
  const closeBtn=h('button',{class:'btn',onclick:()=>{modal.remove();modal=null;clearInterval(poll);poll=null}},'Tutup');
  modal.append(h('div',{class:'box bt-box'},h('div',{class:'row',style:{marginBottom:'8px'}},h('b',null,'BACKTEST STRATEGI'),h('span',{style:{flex:1}}),closeBtn),
    h('div',{class:'bt-live'}),body));
  document.body.append(modal);
  refresh();
  poll=setInterval(refresh,2000);
}

T.Backtest={open};
})();