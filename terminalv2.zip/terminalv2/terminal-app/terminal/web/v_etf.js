(function(){
const h=T.h;
T.Views.etf=function(root){
  let sel='IXN';
  const wrap=h('div');root.append(wrap);
  T.load(wrap,T.api('etf/sectors'),d=>{
    const lead=d.leader,lag=d.laggard;
    wrap.append(h('div',{class:'row',style:{marginBottom:'8px',color:'#8a8f9c'}},
      h('span',null,'REGIME: '),h('b',{class:d.regime==='RISK-ON'?'up':'dn'},`${d.regime}${d.spread!=null?' ('+T.sgn(d.spread)+'%)':''}`),
      h('span',null,' · BREADTH: '),h('b',null,`${d.breadth.total?Math.round(d.breadth.adv/d.breadth.total*100):0}% ADV (${d.breadth.adv}/${d.breadth.total})`),
      lead?h('span',null,' · LEADER: ',h('b',{class:'up'},`${lead.sym} (${T.pct(lead.pct)})`)):null,lag?h('span',null,' · LAGGARD: ',h('b',{class:'dn'},`${lag.sym} (${T.pct(lag.pct)})`)):null));
    const top=h('div',{class:'grid resp',style:{gridTemplateColumns:'2fr 1fr',marginBottom:'8px'}});
    const A=T.panel('Sector Heatmap',{bodyStyle:{height:'340px',padding:'2px'}}),B=T.panel('Relative Return',{bodyStyle:{height:'340px',padding:'4px'}});
    top.append(A.el,B.el);wrap.append(top);
    const b1=T.chartBox(),b2=T.chartBox();A.body.append(b1);B.body.append(b2);
    const col=v=>v>=0?`rgba(33,201,147,${Math.min(.85,.2+Math.abs(v)/2)})`:`rgba(255,91,107,${Math.min(.85,.2+Math.abs(v)/2)})`;
    T.chart(b1,{series:[{type:'treemap',roam:false,nodeClick:false,breadcrumb:{show:false},width:'100%',height:'100%',itemStyle:{borderColor:'#07090c',borderWidth:2},label:{color:'#fff',fontSize:12,formatter:p=>`${p.name}\n${T.pct(p.data.pct)}\n${p.data.title}`},
      data:d.rows.map(r=>({name:r.sym,title:r.name,value:1+Math.abs(r.pct||0)*5,pct:r.pct,itemStyle:{color:col(r.pct||0)}}))}]});
    T.chart(b2,{grid:{left:50,right:10,top:10,bottom:24},tooltip:T.tip(),xAxis:T.axis({type:'category',data:d.rows.map(r=>r.sym)}),yAxis:T.axis({type:'value',axisLabel:{formatter:'{value}%',color:'#8a8f9c'}}),series:[{type:'bar',data:d.rows.map(r=>({value:+(r.rel||0).toFixed(2),itemStyle:{color:(r.rel||0)>=0?'#21c993':'#ff5b6b'}}))}]});
    const bot=h('div',{class:'grid resp',style:{gridTemplateColumns:'1fr 1.4fr'}});
    const S=T.panel('Sector Benchmarks',{np:1,bodyStyle:{maxHeight:'380px'}}),H=T.panel('',{np:1,bodyStyle:{maxHeight:'380px'}});
    bot.append(S.el,H.el);wrap.append(bot);
    S.body.append(T.table([{label:'Ticker',left:true,k:'sym'},{label:'Sector',left:true,k:'name'},{label:'Last',k:'price',fmt:v=>T.fmt(v)},{label:'1D',k:'pct',fmt:v=>T.pct(v),cls:v=>T.cls(v)},{label:'Trend',html:(_,r)=>T.spark(r.spark)}],d.rows,{onRow:r=>{sel=r.sym;holdings()},selected:r=>r.sym===sel}));
    const ht=h('div',{class:'row'},h('span',null,'ETF HOLDINGS · '),h('b',{id:'etfname'},sel));H.head.replaceChildren(ht);
    function holdings(){
      ht.lastChild.textContent=sel;
      T.load(H.body,T.api('etf/holdings',{etf:sel}),x=>{
        if(!x.rows.length){H.body.append(h('div',{class:'msg'},'Holdings tidak tersedia untuk ETF ini'));return}
        H.body.append(T.table([{label:'Ticker',left:true,k:'symbol'},{label:'Company',left:true,k:'name',cls:()=>'wrap'},{label:'Price',k:'price',fmt:v=>T.fmt(v)},{label:'1D',k:'pct',fmt:v=>T.pct(v),cls:v=>T.cls(v)},{label:'Weight',k:'weight',fmt:v=>v==null?'—':T.fmt(v)+'%'}],x.rows));
      });
    }
    holdings();
  });
};
})();
