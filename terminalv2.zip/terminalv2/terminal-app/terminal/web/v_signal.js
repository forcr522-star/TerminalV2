(function(){
const h=T.h;
// ⚡ = pair dipengaruhi kejadian mendadak (berita cepat); merah = entry baru sedang ditahan menunggu reaksi pasar
const shockTag=o=>o&&o.shock?h('span',{class:'sg-zap'+(o.shock.guard?' on':''),title:`${o.shock.n} kejadian mendadak · skor ${T.sgn(o.shock.score,2)}${o.shock.guard?' · penahan entry aktif':''}\n${o.shock.top}`},'⚡'):null;
const f=(v,nd)=>v==null||isNaN(v)?'—':Number(v).toFixed(nd);
const sgnR=v=>v==null||isNaN(v)?'—':(v>0?'+':'')+Number(v).toFixed(2)+'R';
const p2=n=>String(n).padStart(2,'0');
const tfmt=(ts,min)=>{if(!ts)return '—';const d=new Date(ts*1000);return min>=1440?`${d.getFullYear()}-${p2(d.getMonth()+1)}-${p2(d.getDate())}`:`${p2(d.getMonth()+1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}`};
const ST_TXT={BULLISH:'BULLISH',BEARISH:'BEARISH',WAITING:'WAITING'};
const closeModals=()=>document.querySelectorAll('.sg-modal').forEach(e=>e.remove());

// Ubah kontrol bot (hanya admin; server menolak selain admin dengan 403).
async function postControl(body){
  const r=await fetch('/api/signal/control',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  if(r.status===401){location.reload();throw new Error('Sesi berakhir')}
  let j={};try{j=await r.json()}catch(e){}
  if(!r.ok||j.error)throw new Error(j.error||('HTTP '+r.status));
  return j.state;
}

T.Views.signal=function(root){
  closeModals();
  const sub=(location.hash.split('/')[1]||'');
  const admin=T.role==='admin';
  if(sub==='inside'){
    if(admin)return inside(root);
    location.replace('#signal');return;
  }
  return board(root,admin);
};

// ====================================================================================== MENU SIGNAL (admin & user)
function board(root,admin){
  const g=T.gen;
  const S=T.mem('signal',{sym:null,tab:'open'});
  let data=null,ctl=null,ec=null,curKey='',zoomed=false,msg='';
  const top=h('div',{class:'sg-top'});
  const listPb=h('div',{class:'pb'});
  const listPanel=h('div',{class:'panel sg-list'},h('div',{class:'ph'},'LIST PAIR YANG DI ANALISA'),listPb);
  const chead=h('div',{class:'sg-chead'});
  const cmsg=h('div',{class:'msg',style:{display:'none'}});
  const ctag=h('div',{class:'sg-ctag'});
  const cdiv=h('div',{class:'sg-cc',style:{display:'none'}});
  const cbox=h('div',{class:'sg-cbox'},cdiv,ctag,cmsg);
  const chartPanel=h('div',{class:'panel sg-chart'},h('div',{class:'ph'},'CHART'),h('div',{class:'pb'},chead,cbox));
  const tabs=h('div',{class:'sg-tabs'});
  const ordPb=h('div',{class:'pb np'});
  const ordPanel=h('div',{class:'panel sg-orders'},ordPb);
  root.append(h('div',{class:'sg'+(admin?'':' user')},top,listPanel,chartPanel,tabs,ordPanel));

  async function toggle(body){
    try{msg='';ctl=await postControl(body).then(()=>T.rawFetch('signal/control'));drawTop();await refresh()}catch(e){msg=e.message;drawTop()}
  }
  function drawTop(){
    if(!admin||!ctl)return;
    top.replaceChildren(
      h('button',{class:'sg-btn '+(ctl.be?'on':'off'),title:'ON: setelah TP1 tercapai, SL dipindah ke harga entry. OFF: SL & TP tetap.',onclick:()=>toggle({be:!ctl.be})},'BREAKEVEN: '+(ctl.be?'ON':'OFF')),
      h('button',{class:'sg-btn '+(ctl.on?'on':'off'),title:'ON: bot menganalisa semua pair terpilih 24 jam. OFF: bot dilarang menganalisa (order berjalan tetap dipantau).',onclick:()=>toggle({on:!ctl.on})},'SINYAL: '+(ctl.on?'ON':'OFF')),
      h('button',{class:'sg-btn go',onclick:()=>{location.hash='#signal/inside'}},'INSIDE/ANALISIS'),
      h('button',{class:'sg-btn sel',onclick:()=>{if(window.T&&T.Backtest)T.Backtest.open()}},'BACKTEST'),
      h('span',{class:'mut'},ctl.mode_label+' · '+ctl.pairs.length+' pair'+(ctl.on?'':' · analisa dihentikan, order berjalan tetap dipantau')),
      ...(msg?[h('span',{class:'dn'},msg)]:[]));
  }
  function pick(sym){S.sym=sym;zoomed=false;curKey='';if(data){data.symbol=sym;drawList()}refresh()}
  function drawList(){
    if(!data)return;
    const ov={};if(ctl)ctl.overview.forEach(o=>ov[o.sym]=o);
    if(!data.pairs.length){listPb.replaceChildren(h('div',{class:'sg-empty'},'Belum ada pair yang dipilih untuk dianalisa.'));return}
    listPb.replaceChildren(...data.pairs.map(p=>{
      const o=ov[p.sym];
      const dom=admin&&o&&o.fresh?o.dom:'';
      const tag=p.open?h('span',{class:'sg-tag '+p.side},p.side):p.limit?h('span',{class:'sg-tag LMT'},'LMT'):null;
      return h('div',{class:'sg-row'+(p.sym===data.symbol?' sel':''),'data-sym':p.sym,onclick:()=>pick(p.sym),title:p.name},
        admin?h('i',{class:'sg-dot '+dom,title:dom==='BUY'?'dominan BUY':dom==='SELL'?'dominan SELL':dom==='NEUTRAL'?'seimbang / menunggu':'belum dianalisa'}):h('span'),
        h('div',{style:{minWidth:0}},h('div',{class:'s'},p.sym,tag,shockTag(o)),h('div',{class:'n'},p.name)),
        h('div',{class:'p'},f(p.price,p.digits),h('small',{class:T.cls(p.pct)},T.pct(p.pct))));
    }));
  }

  // ---------------------------------------------------------------- chart
  function idxOf(times,ts,step){
    const n=times.length;
    if(ts>times[n-1])return n-1+Math.max(1,Math.round((ts-times[n-1])/step));
    for(let i=0;i<n;i++)if(times[i]>=ts)return i;
    return n-1;
  }
  function build(ch){
    const n=ch.candles.length,pad=30,nd=ch.digits,step=ch.minutes*60,o=ch.order;
    const times=ch.candles.map(c=>c[0]);
    const cats=ch.candles.map(c=>tfmt(c[0],ch.minutes));for(let i=0;i<pad;i++)cats.push('');
    const k=ch.candles.map(c=>[c[1],c[4],c[3],c[2]]);
    const areas=[],lines=[];
    const lineTo=(x0,x1,y,color,type,text,w)=>lines.push([{coord:[x0,y],lineStyle:{color,type:type||'solid',width:w||1},label:{show:true,position:'end',formatter:text,color,fontSize:10,backgroundColor:'#07090ccc',padding:[1,4]}},{coord:[x1,y]}]);
    let x0=0,x1=0;
    if(o){
      x0=o.status==='OPEN'&&o.fill_ts?idxOf(times,o.fill_ts,step):idxOf(times,o.issued,step);
      const len=o.status==='OPEN'?(o.max_hold||48):(o.expiry_bars||12);
      x1=Math.min(n+pad-1,Math.max(x0+1,x0+len));x0=Math.min(x0,n+pad-2);
      areas.push([{coord:[x0,o.entry],itemStyle:{color:'rgba(255,91,107,.20)'}},{coord:[x1,o.sl]}]);
      areas.push([{coord:[x0,o.entry],itemStyle:{color:'rgba(33,201,147,.09)'}},{coord:[x1,o.tp[2]]}]);
      areas.push([{coord:[x0,o.entry],itemStyle:{color:'rgba(33,201,147,.14)'}},{coord:[x1,o.tp[0]]}]);
      lineTo(x0,x1,o.entry,'#60a5fa','solid',o.kind+' '+f(o.entry,nd),1.5);
      lineTo(x0,x1,o.sl,'#ff5b6b','solid','SL '+f(o.sl,nd)+' (−1R)',1.5);
      ['TP1','TP2','TP MAX'].forEach((nm,i)=>lineTo(x0,x1,o.tp[i],'#21c993',i===0?'solid':i===1?'dashed':'dotted',nm+' '+f(o.tp[i],nd)+' (+'+f(o.rr[i],2)+'R)',1.5));
      if(o.status==='OPEN'&&o.hits>=1&&o.sl_now!=null&&o.sl_now!==o.sl)lineTo(x0,x1,o.sl_now,'#f59e0b','dashed','SL → '+f(o.sl_now,nd)+' (BE)');
    }
    const priceLine={yAxis:ch.price,lineStyle:{color:'#94a3b8',type:'dotted',width:1},label:{show:true,position:'insideEndTop',formatter:f(ch.price,nd),color:'#e2e8f0',fontSize:10,backgroundColor:'#334155',padding:[1,4]}};
    const win=(a,b)=>{
      let lo=Infinity,hi=-Infinity;
      for(let i=Math.max(0,Math.floor(a));i<=Math.min(n-1,Math.ceil(b));i++){lo=Math.min(lo,ch.candles[i][3]);hi=Math.max(hi,ch.candles[i][2])}
      if(o)[o.entry,o.sl,o.tp[0],o.tp[1],o.tp[2]].forEach(v=>{lo=Math.min(lo,v);hi=Math.max(hi,v)});
      if(!isFinite(lo))return {};
      const pd=(hi-lo)*0.06||Math.abs(lo)*0.001;return {min:lo-pd,max:hi+pd};
    };
    const sv=Math.max(0,n-100),evv=n+pad-1;
    const yr=win(sv,evv);
    const opt={animation:false,grid:{left:8,right:84,top:30,bottom:26},
      tooltip:{trigger:'axis',axisPointer:{type:'cross',lineStyle:{color:'#34404f'}},backgroundColor:'#07090c',borderColor:'#243041',textStyle:{color:'#e6e1d3',fontSize:11},
        formatter:ps=>{const c=ch.candles[ps[0].dataIndex];if(!c)return '';return `${tfmt(c[0],ch.minutes)}<br>O ${f(c[1],nd)} &nbsp; H ${f(c[2],nd)}<br>L ${f(c[3],nd)} &nbsp; C ${f(c[4],nd)}`}},
      xAxis:{type:'category',data:cats,boundaryGap:true,axisLine:{lineStyle:{color:'#243041'}},axisTick:{show:false},axisLabel:{color:'#8a8f9c',fontSize:9},splitLine:{show:false}},
      yAxis:Object.assign({type:'value',position:'right',scale:true,axisLabel:{formatter:v=>Number(v).toFixed(nd),color:'#8a8f9c',fontSize:10},axisLine:{show:false},splitLine:{lineStyle:{color:'#141a23'}}},yr),
      dataZoom:[{type:'inside',startValue:sv,endValue:evv,filterMode:'none'}],
      series:[{type:'candlestick',data:k,itemStyle:{color:'#21c993',color0:'#ff5b6b',borderColor:'#21c993',borderColor0:'#ff5b6b'},
        markArea:{silent:true,animation:false,data:areas},markLine:{silent:true,symbol:'none',animation:false,data:[priceLine].concat(lines)}}]};
    return {opt,win,n,pad};
  }
  function drawChart(){
    const ch=data&&data.chart;
    if(!ch){
      cdiv.style.display='none';cmsg.style.display='';ctag.replaceChildren();
      cmsg.textContent=data&&data.chart_error?'Chart tidak tersedia: '+data.chart_error:(data&&!data.pairs.length?'Belum ada pair yang dipilih.':'Memuat chart…');
      chead.replaceChildren();return;
    }
    cmsg.style.display='none';cdiv.style.display='';
    const last=ch.candles[ch.candles.length-1],chg=ch.prev?(ch.price-ch.prev)/ch.prev*100:null;
    chead.replaceChildren(h('b',null,ch.symbol),h('span',{class:'mut'},ch.name+' · '+ch.tf),h('span',{class:'live'},'● LIVE'),h('span',{class:'px '+T.cls(chg)},f(ch.price,ch.digits)),
      h('span',{class:'mut'},'O '+f(last[1],ch.digits)+'  H '+f(last[2],ch.digits)+'  L '+f(last[3],ch.digits)+'  C '+f(last[4],ch.digits)));
    const o=ch.order;
    ctag.replaceChildren(...(o?[h('span',{class:'badge '+(o.side==='LONG'?'b-BULLISH':'b-BEARISH')},o.kind),
      h('span',{class:'mut'},o.status==='PENDING'?'menunggu harga menyentuh entry':'posisi berjalan · '+sgnR(o.r)+(o.hits?' · TP '+o.hits+'/3':''))]:[h('span',{class:'mut'},'Belum ada sinyal aktif untuk pair ini')]));
    const key=ch.symbol+'|'+ch.tf;
    const b=build(ch);
    if(!ec||key!==curKey){
      if(ec){try{ec.dispose()}catch(e){}ec=null}
      zoomed=false;curKey=key;
      ec=T.chart(cdiv,b.opt);
      ec.on('datazoom',()=>{
        zoomed=true;
        try{const z=ec.getOption().dataZoom[0];const cur=data&&data.chart;if(!cur)return;const w=build(cur).win(z.startValue,z.endValue);ec.setOption({yAxis:w})}catch(e){}
      });
    }else{
      const up={series:b.opt.series,xAxis:b.opt.xAxis,yAxis:b.opt.yAxis};
      if(!zoomed)up.dataZoom=b.opt.dataZoom;
      else{try{const z=ec.getOption().dataZoom[0];up.yAxis=Object.assign({},b.opt.yAxis,b.win(z.startValue,z.endValue))}catch(e){}}
      ec.setOption(up,{replaceMerge:['series']});
    }
  }

  // ---------------------------------------------------------------- order terbuka / limit / tertutup
  const pxr=(v,r,nd,sign,col)=>h('span',null,f(v,nd),h('span',{class:'sg-rr',style:col?{color:col}:null},r==null?'':sign+Number(r).toFixed(2)+'R'));
  const pairCell=(v,o)=>h('span',null,h('b',null,o.sym),h('span',{class:'sg-tag '+o.side},o.side));
  const tpCols=[0,1,2].map(i=>({label:['TP1','TP2','TP MAX'][i],get:o=>o,node:(v,o)=>pxr(o.tp[i],o.rr[i],o.digits,'+',o.hits>i&&o.status==='OPEN'?'#21c993':null)}));
  const base=[{label:'Pair',left:true,get:o=>o,node:pairCell},{label:'Gaya',get:o=>o.tf},{label:'Order',get:o=>o.kind,cls:(v,o)=>o.side==='LONG'?'up':'dn'},
    {label:'Entry',get:o=>o,node:(v,o)=>f(o.entry,o.digits)},{label:'SL (1R)',get:o=>o,node:(v,o)=>pxr(o.sl,1,o.digits,'−','#ff5b6b')}];
  const COLS={
    open:base.concat(tpCols,[{label:'Harga',get:o=>o,node:(v,o)=>f(o.price,o.digits)},{label:'RR (P/L)',get:o=>o.r,fmt:v=>sgnR(v),cls:v=>T.cls(v)},
      {label:'Status',left:true,get:o=>o,node:(v,o)=>(o.hits?'TP '+o.hits+'/3 tercapai':'Berjalan')+(o.be&&o.hits>=1?' · SL di entry':'')},{label:'Dibuka',get:o=>tfmt(o.fill_ts||o.created,o.tf_minutes)}]),
    limit:base.concat(tpCols,[{label:'Harga',get:o=>o,node:(v,o)=>f(o.price,o.digits)},{label:'Jarak ke entry',get:o=>o.dist_r,fmt:v=>v==null?'—':Number(v).toFixed(2)+'R'},
      {label:'Berlaku s/d',get:o=>tfmt(o.issued+(o.expiry_bars||0)*o.tf_minutes*60,o.tf_minutes)},{label:'Dibuat',get:o=>tfmt(o.created,o.tf_minutes)}]),
    closed:base.concat(tpCols,[{label:'Hasil (RR)',get:o=>o.r,fmt:v=>v==null?'—':sgnR(v),cls:v=>T.cls(v)},{label:'Status',left:true,get:o=>o.status_txt,cls:(v,o)=>o.r==null?'mut':''},{label:'Ditutup',get:o=>tfmt(o.closed,o.tf_minutes)}])
  };
  const EMPTY={open:'Tidak ada order terbuka.',limit:'Tidak ada limit order yang berjalan.',closed:'Belum ada order tertutup.'};
  function drawOrders(){
    if(!data)return;
    const O=data.orders,st=O.stats;
    const mk=(id,label,n)=>h('button',{class:S.tab===id?'on':'',onclick:()=>{S.tab=id;drawOrders()}},label+' ('+n+')');
    const sum=S.tab==='open'?'Floating: '+sgnR(st.float_r):S.tab==='closed'?(st.n?st.n+' trade · Positive '+Math.round((st.win||0)*100)+'% · Fill '+((st.fill_rate||0)*100).toFixed(0)+'% · Total '+sgnR(st.sum_r)+' · Rata-rata '+sgnR(st.avg_r):'—'):'SL = 1R · TP = kelipatan R';
    tabs.replaceChildren(mk('open','TERBUKA',O.open.length),mk('limit','LIMIT',O.limit.length),mk('closed','TERTUTUP',O.closed.length),h('span',{class:'sum'},sum));
    const rows=O[S.tab];
    if(!rows.length){ordPb.replaceChildren(h('div',{class:'sg-empty'},EMPTY[S.tab]));return}
    const sc=ordPb.scrollTop;
    ordPb.replaceChildren(T.table(COLS[S.tab],rows,{onRow:o=>pick(o.sym),selected:o=>o.sym===data.symbol}));
    ordPb.scrollTop=sc;
  }

  async function refresh(){
    try{
      const [d,c]=await Promise.all([T.rawFetch('signal/board',{symbol:S.sym||''}),admin?T.rawFetch('signal/control'):Promise.resolve(null)]);
      if(g!==T.gen)return;
      data=d;if(c)ctl=c;if(d.symbol)S.sym=d.symbol;
      drawTop();drawList();drawChart();drawOrders();
    }catch(e){
      if(g!==T.gen)return;
      cdiv.style.display='none';cmsg.style.display='';cmsg.textContent='Data tidak tersedia: '+e.message;
    }
  }
  cmsg.style.display='';cmsg.textContent='Memuat…';
  refresh();
  T.every(10000,refresh);
}

// ====================================================================================== INSIDE / ANALISIS (khusus admin)
function inside(root){
  const g=T.gen;
  const S=T.mem('signal_inside',{sym:null,tile:0});
  let ctl=null,det=null;
  const top=h('div',{class:'sg-top',style:{gridArea:'top'}});
  const listPb=h('div',{class:'pb'});
  const listPanel=h('div',{class:'panel sgi-list'},h('div',{class:'ph'},'LIST PAIR YANG SEDANG DI ANALISA'),listPb);
  const tiles=h('div',{class:'sgi-tiles'});
  const resPb=h('div',{class:'pb'});
  const resPanel=h('div',{class:'panel sgi-res'},h('div',{class:'ph'},'HASIL ANALISA'),resPb);
  root.append(h('div',{class:'sgi'},top,listPanel,tiles,resPanel));

  function drawTop(){
    if(!ctl)return;
    top.replaceChildren(
      h('button',{class:'sg-btn',onclick:openPicker},'PILIH PAIR'),
      h('button',{class:'sg-btn',onclick:openMode},'MODE TRADING'),
      h('button',{class:'sg-btn go',onclick:()=>{location.hash='#signal'}},'SINYAL'),
      h('span',{class:'mut'},ctl.mode_label+' · Breakeven '+(ctl.be?'ON':'OFF')+' · Sinyal '+(ctl.on?'ON':'OFF')+' · '+ctl.status.analyzed+'/'+ctl.status.total+' pair sudah dianalisa'+(ctl.status.errors?' · '+ctl.status.errors+' gagal':'')));
  }
  function drawList(){
    if(!ctl)return;
    if(!ctl.overview.length){listPb.replaceChildren(h('div',{class:'sg-empty'},'Belum ada pair. Klik PILIH PAIR.'));return}
    listPb.replaceChildren(...ctl.overview.map(o=>{
      const dom=o.ready&&o.fresh?o.dom:'';
      return h('div',{class:'sg-row'+(o.sym===S.sym?' sel':''),'data-sym':o.sym,title:o.error?('Gagal: '+o.error):o.name,onclick:()=>{S.sym=o.sym;S.tile=0;drawList();loadDetail()}},
        h('i',{class:'sg-dot '+dom,title:dom==='BUY'?'dominan BUY':dom==='SELL'?'dominan SELL':dom==='NEUTRAL'?'seimbang / menunggu':'belum dianalisa'}),
        h('div',{style:{minWidth:0}},h('div',{class:'s'},o.sym,shockTag(o)),h('div',{class:'n'},o.name)),
        h('div',{class:'p'},o.ready&&o.fresh?h('small',null,h('span',{class:'up'},o.bull+'▲'),' ',h('span',{class:'dn'},o.bear+'▼')):h('small',{class:'mut'},o.error?'gagal':'…')));
    }));
  }
  function drawTiles(){
    const list=det&&det.ready?det.tiles:null;
    tiles.replaceChildren(...Array.from({length:10},(_,i)=>{
      const t=list?list[i]:null;
      const st=t?t.state:'';
      return h('div',{class:'sgi-tile '+st+(S.tile===i+1?' sel':''),'data-n':i+1,onclick:()=>{S.tile=S.tile===i+1?0:i+1;drawTiles();drawResult()}},
        h('div',{class:'h'},h('b',null,'ANALISA '+(i+1)),t?h('span',{class:'st st-'+st},ST_TXT[st]):h('span',{class:'st mut'},'—')),
        h('div',{class:'m'},t?t.label:'menunggu analisa…'),h('div',{class:'nt'},t?t.note:''));
    }));
  }
  const sec=(s)=>[h('h4',null,s.title),...s.lines.map(l=>h('p',null,l))];
  function drawResult(){
    if(!S.sym){resPb.replaceChildren(h('div',{class:'sg-empty'},'Pilih pair di list sebelah kiri.'));return}
    if(!det){resPb.replaceChildren(h('div',{class:'sg-empty'},'Memuat…'));return}
    if(!det.ready){resPb.replaceChildren(h('div',{class:'sg-empty'},det.error?'Analisa gagal: '+det.error:(det.on?'Menunggu analisa pertama '+det.symbol+'…':'SINYAL sedang OFF: bot tidak menganalisa pair ini.')));return}
    const ex=det.explain;
    const badge=det.signal==='BUY'?'b-BULLISH':det.signal==='SELL'?'b-BEARISH':'b-NEUTRAL';
    const kids=[h('div',{class:'ttl'},h('b',null,det.symbol+' · '+det.name),h('span',{class:'badge '+badge},det.signal),h('span',{class:'mut'},det.mode_label+' · bar terakhir '+det.asof+' · diperbarui '+T.ago(det.at)+' lalu'),
      det.fresh?null:h('span',{class:'warn'},'⚠ analisa lama (gaya/breakeven baru diganti) — menunggu analisa ulang'))];
    // kejadian mendadak (berita cepat) yang memengaruhi pair ini: dampak yang diharapkan + reaksi harga + penahan entry
    const sh=det.shock;
    if(sh&&sh.events&&sh.events.length){
      const rc=sh.reaction;
      kids.push(h('div',{class:'sg-shock'+(sh.guard?' on':'')},
        h('div',{class:'sg-shock-h'},h('b',null,'⚡ KEJADIAN MENDADAK'),h('span',{class:'mut'},'skor '+T.sgn(sh.score,2)),
          det.woken?h('span',{class:'mut'},'analisa ulang dipicu '+T.ago(det.woken[0])+' lalu'):null),
        ...sh.events.map(e=>h('div',{class:'sg-shock-e'},h('span',{class:'badge b-'+(e.sev==='CRIT'?'CRITICAL':'HIGH')},e.type),
          h('span',{class:e.expected>0?'up':'dn'},e.expected>0?'▲ diharapkan naik':'▼ diharapkan turun'),
          h('span',null,e.title),h('span',{class:'mut'},(e.place?e.place+' · ':'')+e.sources+' sumber · '+T.ago(e.ts)))),
        sh.guard?h('div',{class:'warn',style:{marginTop:'4px'}},rc?`Reaksi pasar sejak berita: ${T.sgn(rc.move_atr,1)} ATR (puncak ${T.fmt(rc.peak_atr,1)} ATR, ${rc.bars} bar) — ${rc.peak_atr>=1?'entry baru DITAHAN sampai pasar tenang':'pasar tenang, entry boleh'}${rc.agrees?'':' · arah berlawanan dengan dugaan: dampak diabaikan'}`:'Belum ada bar tutup sesudah berita — entry baru DITAHAN sampai reaksi pasar terbaca'):null));
    }
    if(!ex){kids.push(h('p',{class:'mut'},'Penjelasan tidak tersedia untuk analisa ini.'));resPb.replaceChildren(...kids);return}
    if(S.tile){
      const t=det.tiles[S.tile-1],m=ex.methods[t.key];
      kids.push(h('div',{class:'ttl'},h('b',{class:'st-'+m.state},'ANALISA '+m.n+' · '+m.label+' → '+m.state)));
      m.sections.forEach(s=>kids.push(...sec(s)));
      kids.push(h('div',{class:'final'},h('h4',null,'KESIMPULAN AKHIR (SEMUA 10 ANALISA): '+ex.overall.state),...ex.overall.sections.flatMap(sec)));
    }else{
      kids.push(h('div',{class:'ttl'},h('b',null,'KESIMPULAN AKHIR: '+ex.overall.state),h('span',{class:'mut'},'Klik salah satu kartu ANALISA 1–10 untuk melihat alasannya satu per satu.')));
      ex.overall.sections.forEach(s=>kids.push(...sec(s)));
    }
    resPb.replaceChildren(...kids);resPb.scrollTop=0;
  }
  async function loadDetail(){
    if(!S.sym){det=null;drawTiles();drawResult();return}
    const sym=S.sym;
    try{
      const d=await T.rawFetch('signal/detail',{symbol:sym});
      if(g!==T.gen||sym!==S.sym)return;
      const same=det&&det.symbol===d.symbol&&det.at===d.at&&det.ready===d.ready&&det.on===d.on;
      det=d;drawTiles();if(!same)drawResult();
    }catch(e){
      if(g!==T.gen)return;
      det=null;resPb.replaceChildren(h('div',{class:'sg-empty err'},'Data tidak tersedia: '+e.message));
    }
  }
  async function refresh(){
    try{
      ctl=await T.rawFetch('signal/control');
      if(g!==T.gen)return;
      if(!ctl.pairs.includes(S.sym)){S.sym=ctl.pairs[0]||null;S.tile=0}
      drawTop();drawList();
      await loadDetail();
    }catch(e){
      if(g!==T.gen)return;
      resPb.replaceChildren(h('div',{class:'sg-empty err'},'Data tidak tersedia: '+e.message));
    }
  }

  // ---------------------------------------------------------------- popup tengah: PILIH PAIR
  async function openPicker(){
    let cat;
    try{cat=await T.rawFetch('signal/catalog')}catch(e){alert('Daftar pair gagal dimuat: '+e.message);return}
    const sel=new Set(ctl.pairs);
    let cls='SEMUA',q='';
    const modal=h('div',{class:'sg-modal',onclick:e=>{if(e.target===modal)modal.remove()}});
    const count=h('span',{class:'mut'});
    const chips=h('div',{class:'chips'});
    const err=h('span',{class:'dn'});
    const all=()=>cat.order.flatMap(c=>cat.classes[c]);
    const inTab=()=>cls==='SEMUA'?all():cat.classes[cls];
    const tabsEl=h('div',{class:'tabs sm'});
    function drawChips(){
      const qq=q.trim().toLowerCase();
      const items=inTab().filter(a=>!qq||a.sym.toLowerCase().includes(qq)||a.name.toLowerCase().includes(qq));
      chips.replaceChildren(...items.map(a=>h('span',{class:'chip'+(sel.has(a.sym)?' on':''),title:a.name,'data-sym':a.sym,onclick:e=>{sel.has(a.sym)?sel.delete(a.sym):sel.add(a.sym);e.target.classList.toggle('on',sel.has(a.sym));upd()}},a.sym)));
      if(!items.length)chips.append(h('span',{class:'mut'},'Tidak ada hasil'));
      upd();
    }
    function upd(){count.textContent=sel.size+' pair dipilih dari '+cat.total}
    function drawTabs(){
      tabsEl.replaceChildren(...['SEMUA'].concat(cat.order).map(c=>h('button',{class:c===cls?'on':'',onclick:()=>{cls=c;drawTabs();drawChips()}},c+' ('+(c==='SEMUA'?cat.total:cat.classes[c].length)+')')));
    }
    const input=h('input',{class:'in',placeholder:'Cari pair…',style:{width:'170px'},oninput:e=>{q=e.target.value;drawChips()}});
    const save=h('button',{class:'sg-btn on',onclick:async()=>{
      try{err.textContent='';await postControl({pairs:[...sel]});modal.remove();await refresh()}catch(e){err.textContent=e.message}
    }},'SIMPAN');
    modal.append(h('div',{class:'box'},
      h('div',{class:'row',style:{marginBottom:'6px'}},h('b',null,'PILIH PAIR YANG DIANALISA BOT'),h('span',{style:{flex:1}}),count),
      h('div',{class:'row'},tabsEl,input),
      chips,
      h('div',{class:'ft'},
        h('button',{class:'btn',onclick:()=>{inTab().forEach(a=>sel.add(a.sym));drawChips()}},'Pilih semua tab ini'),
        h('button',{class:'btn',onclick:()=>{inTab().forEach(a=>sel.delete(a.sym));drawChips()}},'Hapus tab ini'),
        h('button',{class:'btn',onclick:()=>{sel.clear();drawChips()}},'Kosongkan'),
        h('button',{class:'btn',onclick:()=>{sel.clear();cat.default.forEach(s=>sel.add(s));drawChips()}},'Default'),
        h('span',{style:{flex:1}}),err,h('button',{class:'btn',onclick:()=>modal.remove()},'Batal'),save)));
    document.body.append(modal);
    drawTabs();drawChips();
  }
  // ---------------------------------------------------------------- popup tengah: MODE TRADING
  function openMode(){
    const modal=h('div',{class:'sg-modal',onclick:e=>{if(e.target===modal)modal.remove()}});
    const err=h('div',{class:'dn',style:{minHeight:'14px'}});
    modal.append(h('div',{class:'box',style:{width:'min(520px,100%)'}},
      h('div',{class:'row',style:{marginBottom:'8px'}},h('b',null,'MODE TRADING'),h('span',{style:{flex:1}}),h('button',{class:'btn',onclick:()=>modal.remove()},'Tutup')),
      ...ctl.modes.map(m=>h('button',{class:'sg-mode'+(m.id===ctl.mode?' sel':''),'data-mode':m.id,onclick:async()=>{
        try{err.textContent='';await postControl({mode:m.id});modal.remove();S.tile=0;await refresh()}catch(e){err.textContent=e.message}
      }},h('b',null,m.label+(m.id===ctl.mode?'  ✓':'')),h('span',null,'Chart & analisa '+m.tf+' · bias '+m.htf),h('span',null,m.info))),
      err));
    document.body.append(modal);
  }

  drawTiles();drawResult();
  refresh();
  T.every(10000,refresh);
}
})();
