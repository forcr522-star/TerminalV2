(function(){
const h=T.h;
function quoteRows(rows){
  return T.table([
    {label:'',left:true,get:r=>r.sym,cls:()=>''},
    {label:'',k:'price',fmt:v=>T.fmt(v,v!=null&&v<10?4:2)},
    {label:'',k:'pct',fmt:v=>T.pct(v),cls:v=>T.cls(v)}
  ],rows.filter(r=>r.price!=null),{onRow:r=>T.openAsset(r.sym)});
}
T.Views.dashboard=function(root){
  // Hanya SATU baris: sebelumnya ada baris kedua (minmax(260px,34vh)) yang tidak berisi apa pun sehingga muncul celah kosong ±260px di bawah panel.
  const grid=h('div',{class:'grid resp dashtop',style:{gridTemplateColumns:'1.05fr 1.15fr 1.7fr 1.2fr',gridTemplateRows:'minmax(380px,52vh)'}});
  const DS=Object.assign({evHigh:false,regCC:'US'},T.ls?T.ls.get('tm.dash.v1',{}):{});    // pilihan tampilan dashboard per browser
  const dsave=()=>T.ls&&T.ls.set('tm.dash.v1',DS);
  const P={mo:T.panel('Market Overview',{np:1}),cot:T.panel('COT Positions',{np:1}),mar:T.panel('Global Monitor',{np:1}),live:T.panel('Live Feed',{np:1}),
    cm:T.panel('Commodities',{np:1}),bond:T.panel('Bond Yields & Spread',{np:1}),gpr:T.panel('GPR Index'),ev:T.panel('Upcoming Macro Events',{np:1}),reg:T.panel('Macro Regime'),cat:T.panel('Latest Catalysts',{np:1})};
  const left=h('div',{style:{display:'grid',gridTemplateRows:'1fr 1fr',gap:'8px',minHeight:0}},P.mo.el,P.cm.el);
  const cotbond=h('div',{style:{display:'grid',gridTemplateRows:'1fr 1fr',gap:'8px',minHeight:0}},P.cot.el,P.bond.el);
  const center=h('div',{style:{display:'grid',gridTemplateRows:'1.5fr 1fr',gap:'8px',minHeight:0}},P.mar.el,P.gpr.el);
  grid.append(left,cotbond,center,P.live.el);
  const bottom=h('div',{class:'grid resp dashbot',style:{gridTemplateColumns:'1.4fr 1fr 1.2fr',marginTop:'8px',height:'clamp(250px,34vh,340px)'}},P.ev.el,P.reg.el,P.cat.el);
  root.append(...(T.notifyBar?[T.notifyBar()]:[]),grid,bottom);
  // ---- GLOBE 4 LAYER (sama dengan menu GEOPOLITICAL RISK): Risk · Maritime · Airplane · Cyber; pilihan layer sendiri
  const gbox=h('div',{class:'mapbox dash-globe'});
  P.mar.body.append(gbox);P.mar.body.style.overflow='hidden';
  const LAB={risk:'Risk & berita geopolitik',sea:'Maritime',air:'Airplane (militer)',cyber:'Cyber'};
  const gtitle=P.mar.head.firstChild;
  P.mar.head.append(h('a',{class:'ph-link',href:'#geo',title:'Buka layar penuh di GEOPOLITICAL RISK'},'Layar penuh ↗'));
  T.geoGlobe(gbox,{mem:'dash.layer',compact:true,onLayer:id=>{gtitle.textContent='Global Monitor · '+(LAB[id]||id)}});
  // ---- UPCOMING MACRO EVENTS: tombol "HIGH saja" (kiri atas)
  const hiBtn=h('button',{class:'ph-tog'+(DS.evHigh?' on':''),title:'Tampilkan hanya rilis berdampak TINGGI',onclick:()=>{DS.evHigh=!DS.evHigh;dsave();hiBtn.classList.toggle('on',DS.evHigh);drawEvents()}},'HIGH saja');
  P.ev.head.insertBefore(hiBtn,P.ev.head.children[1]);
  let last=null;
  function drawEvents(){
    if(!last)return;
    const rows=DS.evHigh?(last.events_high||(last.events||[]).filter(r=>r.impact==='HIGH')):(last.events||[]);
    if(!rows.length){P.ev.body.replaceChildren(h('div',{class:'msg'},DS.evHigh?'Tidak ada rilis berdampak TINGGI dalam waktu dekat.':'Tidak ada rilis terjadwal.'));return}
    P.ev.body.replaceChildren(T.table([{label:'Indicator',left:true,get:r=>r.event,cls:()=>'wrap'},{label:'Country',k:'country'},{label:'Date & Time',k:'date'},{label:'Fcst',k:'forecast'},{label:'Impact',node:(_,r)=>T.badge(r.impact)}],rows));
  }
  // ---- MACRO REGIME: pilih negara (tombol berwarna = regime negara itu)
  const REGC=['US','CN','EU','JP','GB','CA','AU','ID','CH','NZ'];
  let regAll={},regData={};
  function drawRegime(){
    const r=regData[DS.regCC];
    const pick=h('div',{class:'reg-pick'},...REGC.map(cc=>{const a=regAll[cc];
      return h('button',{class:cc===DS.regCC?'on':'',style:a?{'--rc':a.color}:null,title:(T.cname?T.cname(cc):cc)+(a?' · '+a.regime:''),'data-cc':cc,
        onclick:()=>{if(DS.regCC===cc)return;DS.regCC=cc;dsave();loadRegime()}},cc)}));
    if(!r){P.reg.body.replaceChildren(pick,h('div',{class:'msg'},r===null?'Regime '+DS.regCC+' tidak tersedia':'Memuat regime '+DS.regCC+'…'));return}
    P.reg.body.replaceChildren(pick,h('div',{class:'row'},h('div',{class:'big',style:{color:r.color}},r.regime),h('div',{class:'mut'},(T.cname?T.cname(DS.regCC):DS.regCC)+' · Growth '+T.sgn(r.growth)+' · Infl '+T.sgn(r.inflation))),
      h('div',{class:'mut',style:{margin:'6px 0 4px',fontSize:'9px',letterSpacing:'.06em'}},'KEY DRIVERS'+(r.asof?' · '+r.asof:'')+(r.source?' · '+r.source:'')),
      T.table([{label:'',left:true,get:r=>r.label,cls:()=>'wrap'},{label:'',k:'actual',fmt:v=>T.fmt(v,2)},{label:'',k:'z',fmt:v=>T.sgn(v)+'σ',cls:v=>T.cls(v)}],(r.drivers||[]).slice(0,6)));
  }
  function loadRegime(){
    drawRegime();
    const cc=DS.regCC;
    T.api('macro/regime',{cc}).then(d=>{regData[cc]=d;if(d.all)regAll=d.all;if(DS.regCC===cc)drawRegime()}).catch(()=>{if(!regData[cc]){regData[cc]=null;if(DS.regCC===cc)drawRegime()}});
  }
  const fill=d=>{
    if(d.indices)P.mo.body.replaceChildren(quoteRows(d.indices));
    if(d.commodities)P.cm.body.replaceChildren(quoteRows(d.commodities));
    if(d.cot)P.cot.body.replaceChildren(T.table([{label:'Asset',left:true,k:'asset'},{label:'Long / Short',node:(_,r)=>{const b=h('div',{class:'bar2'},h('i',{style:{width:(r.long_pct||0)+'%',background:'#1aa57a'}}),h('i',{style:{width:(100-(r.long_pct||0))+'%',background:'#e0475a'}}));return b}},{label:'Net',k:'net',fmt:v=>T.big(v)},{label:'Δ Wk',k:'chg',fmt:v=>T.big(v),cls:v=>T.cls(v)}],d.cot));
    // Kosong = memang tidak tersedia dari sumber terbuka (bukan bug): tampil "n/a" + alasan di tooltip. Ujung pendek memakai
    // 2Y bila ada, selain itu tenor terpendek yang tersedia (label tenornya ditampilkan).
    const na=(r)=>h('span',{class:'na-cell',title:r.note||'tidak tersedia dari sumber terbuka'},'n/a');
    if(d.bonds)P.bond.body.replaceChildren(T.table([{label:'Curve',left:true,k:'name'},
      {label:'Short',get:r=>r,node:(_,r)=>r.y_short==null?na(r):h('span',null,r.short_tenor&&r.short_tenor!=='2Y'?h('small',{class:'tn'},r.short_tenor+' '):null,T.fmt(r.y_short,3))},
      {label:'10Y',get:r=>r,node:(_,r)=>r.y10==null?na(r):T.fmt(r.y10,3)},
      {label:'Sprd',get:r=>r,node:(_,r)=>r.spread==null?na(r):h('span',{class:r.spread<0?'dn':'up',title:r.spread_label||'2s10s'},T.sgn(r.spread,0)+'bp',r.spread_label&&r.spread_label!=='2s10s'?h('small',{class:'tn'},' '+r.spread_label):null)}],d.bonds));
    if(d.gpr){const g=d.gpr;P.gpr.body.replaceChildren(h('div',{class:'row',style:{alignItems:'flex-end'}},h('div',{class:'big'},T.fmt(g.latest,0)),h('div',null,h('div',{class:g.latest>=150?'dn':'warn'},g.level),h('div',{class:'mut'},T.sgn(g.change,1)+' ('+T.pct(g.change_pct,1)+')')),
      h('div',{class:'mut',style:{marginLeft:'auto',textAlign:'right'}},h('div',null,'30D AVG '+T.fmt(g.avg30,0)),h('div',null,'90D AVG '+T.fmt(g.avg90,0)),h('div',null,'180D HI '+T.fmt(g.hi180,0)+' · LO '+T.fmt(g.lo180,0)))),h('div',{html:T.spark(g.spark,420,60,'#3b82f6'),style:{marginTop:'6px'}}))}
    else P.gpr.body.replaceChildren(h('div',{class:'msg'},'GPR tidak tersedia'));
    if(d.feed)P.live.body.replaceChildren(...d.feed.map(f=>h('a',{class:'feed',href:f.link,target:'_blank',style:{padding:'6px 10px'}},h('div',{class:'m'},h('span',{class:'acc'},T.ago(f.ts)),f.fast?h('span',{class:'fastb',title:'Sumber cepat (squawk)'},'⚡'):null,h('span',null,f.source),f.flash?T.badge('FLASH'):null,f.prio==='CRIT'?T.badge('CRIT'):null),h('div',{class:'tt'},f.title))));
    if(d.events){last=d;drawEvents()}
    if(d.regime&&!regData.US){regData.US=Object.assign({},d.regime);if(!regAll.US)regAll.US={regime:d.regime.regime,color:d.regime.color}}
    drawRegime();
    if(d.catalysts)P.cat.body.replaceChildren(T.table([{label:'Title',left:true,get:r=>r.title,cls:()=>'wrap'},{label:'Region',k:'region'},{label:'Bias',node:(_,r)=>T.badge(r.bias)},{label:'Impact',node:(_,r)=>T.badge(r.impact)}],d.catalysts));
  };
  const onErr=e=>{[P.mo,P.cm,P.cot,P.bond,P.ev,P.reg,P.cat,P.live].forEach(p=>{if(!p.body.querySelector('table,.feed,.row'))p.body.replaceChildren(h('div',{class:'msg err'},e.message))})};
  const cached=!!T.cache.get('dashboard');
  if(!cached)[P.mo,P.cm,P.cot,P.bond,P.ev,P.reg,P.cat,P.live].forEach(p=>p.body.append(h('div',{class:'msg'},'Memuat…')));
  // Kunjungan ulang: data tersimpan langsung tampil, lalu diperbarui di latar belakang. Polling berikutnya hanya memperbarui isi.
  T.cachedThen('dashboard',null,d=>fill(d)).catch(onErr);
  loadRegime();                              // regime negara pilihan + warna regime semua negara (untuk tombol)
  T.every(60000,()=>T.api('dashboard',null,{force:true}).then(fill).catch(()=>{}));
};
})();
