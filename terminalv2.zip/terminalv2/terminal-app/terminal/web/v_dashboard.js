(function(){
const h=T.h;
const COL={cargo:'#22c55e',tanker:'#ef4444',passenger:'#3b82f6',fishing:'#f59e0b',tug:'#a78bfa',service:'#22d3ee',other:'#94a3b8'};
function quoteRows(rows){
  return T.table([
    {label:'',left:true,get:r=>r.sym,cls:()=>''},
    {label:'',k:'price',fmt:v=>T.fmt(v,v!=null&&v<10?4:2)},
    {label:'',k:'pct',fmt:v=>T.pct(v),cls:v=>T.cls(v)}
  ],rows.filter(r=>r.price!=null),{onRow:r=>T.openAsset(r.sym)});
}
T.shipMap=(el,vessels,opts={})=>{
  const m=T.map(el,opts.center||[20,40],opts.zoom||2);
  const layer=L.layerGroup().addTo(m);
  const draw=list=>{
    layer.clearLayers();
    list.forEach(v=>{
      const c=COL[v[4]]||COL.other;
      const ic=L.divIcon({className:'',html:`<div style="width:0;height:0;border-left:3px solid transparent;border-right:3px solid transparent;border-bottom:9px solid ${c};transform:rotate(${v[2]}deg);opacity:.85"></div>`,iconSize:[6,9],iconAnchor:[3,5]});
      L.marker([v[0],v[1]],{icon:ic}).bindTooltip(`${v[5]||v[6]} · ${v[4]} · ${v[3]}kn`).addTo(layer);
    });
  };
  draw(vessels||[]);
  m.drawVessels=draw;
  return m;
};
T.Views.dashboard=function(root){
  // Hanya SATU baris: sebelumnya ada baris kedua (minmax(260px,34vh)) yang tidak berisi apa pun sehingga muncul celah kosong ±260px di bawah panel.
  const grid=h('div',{class:'grid resp dashtop',style:{gridTemplateColumns:'1.05fr 1.15fr 1.7fr 1.2fr',gridTemplateRows:'minmax(380px,52vh)'}});
  const P={mo:T.panel('Market Overview',{np:1}),cot:T.panel('COT Positions',{np:1}),mar:T.panel('Global Maritime',{np:1}),live:T.panel('Live Feed',{np:1}),
    cm:T.panel('Commodities',{np:1}),bond:T.panel('Bond Yields & Spread',{np:1}),gpr:T.panel('GPR Index'),ev:T.panel('Upcoming Macro Events',{np:1}),reg:T.panel('Macro Regime'),cat:T.panel('Latest Catalysts',{np:1})};
  const left=h('div',{style:{display:'grid',gridTemplateRows:'1fr 1fr',gap:'8px',minHeight:0}},P.mo.el,P.cm.el);
  const cotbond=h('div',{style:{display:'grid',gridTemplateRows:'1fr 1fr',gap:'8px',minHeight:0}},P.cot.el,P.bond.el);
  const center=h('div',{style:{display:'grid',gridTemplateRows:'1.5fr 1fr',gap:'8px',minHeight:0}},P.mar.el,P.gpr.el);
  grid.append(left,cotbond,center,P.live.el);
  const bottom=h('div',{class:'grid resp dashbot',style:{gridTemplateColumns:'1.4fr 1fr 1.2fr',marginTop:'8px',height:'clamp(250px,34vh,340px)'}},P.ev.el,P.reg.el,P.cat.el);
  root.append(grid,bottom);
  const mapEl=h('div',{class:'map'});
  P.mar.body.append(h('div',{class:'mapbox'},mapEl));P.mar.body.style.overflow='hidden';
  let map=null;
  const fill=d=>{
    if(d.indices)P.mo.body.replaceChildren(quoteRows(d.indices));
    if(d.commodities)P.cm.body.replaceChildren(quoteRows(d.commodities));
    if(d.cot)P.cot.body.replaceChildren(T.table([{label:'Asset',left:true,k:'asset'},{label:'Long / Short',node:(_,r)=>{const b=h('div',{class:'bar2'},h('i',{style:{width:(r.long_pct||0)+'%',background:'#16a34a'}}),h('i',{style:{width:(100-(r.long_pct||0))+'%',background:'#dc2626'}}));return b}},{label:'Net',k:'net',fmt:v=>T.big(v)},{label:'Δ Wk',k:'chg',fmt:v=>T.big(v),cls:v=>T.cls(v)}],d.cot));
    if(d.bonds)P.bond.body.replaceChildren(T.table([{label:'Curve',left:true,k:'name'},{label:'2Y',k:'y2',fmt:v=>T.fmt(v,3)},{label:'10Y',k:'y10',fmt:v=>T.fmt(v,3)},{label:'Sprd',k:'spread',fmt:v=>v==null?'—':T.sgn(v,0)+'bp',cls:v=>v<0?'dn':'up'}],d.bonds));
    if(d.gpr){const g=d.gpr;P.gpr.body.replaceChildren(h('div',{class:'row',style:{alignItems:'flex-end'}},h('div',{class:'big'},T.fmt(g.latest,0)),h('div',null,h('div',{class:g.latest>=150?'dn':'warn'},g.level),h('div',{class:'mut'},T.sgn(g.change,1)+' ('+T.pct(g.change_pct,1)+')')),
      h('div',{class:'mut',style:{marginLeft:'auto',textAlign:'right'}},h('div',null,'30D AVG '+T.fmt(g.avg30,0)),h('div',null,'90D AVG '+T.fmt(g.avg90,0)),h('div',null,'180D HI '+T.fmt(g.hi180,0)+' · LO '+T.fmt(g.lo180,0)))),h('div',{html:T.spark(g.spark,420,60,'#3b82f6'),style:{marginTop:'6px'}}))}
    else P.gpr.body.replaceChildren(h('div',{class:'msg'},'GPR tidak tersedia'));
    if(d.feed)P.live.body.replaceChildren(...d.feed.map(f=>h('a',{class:'feed',href:f.link,target:'_blank',style:{padding:'6px 10px'}},h('div',{class:'m'},h('span',{class:'acc'},T.ago(f.ts)),h('span',null,f.source),f.flash?T.badge('FLASH'):null,f.prio==='CRIT'?T.badge('CRIT'):null),h('div',{class:'tt'},f.title))));
    if(d.events)P.ev.body.replaceChildren(T.table([{label:'Indicator',left:true,get:r=>r.event,cls:()=>'wrap'},{label:'Country',k:'country'},{label:'Date & Time',k:'date'},{label:'Fcst',k:'forecast'},{label:'Impact',node:(_,r)=>T.badge(r.impact)}],d.events));
    if(d.regime){const r=d.regime;P.reg.body.replaceChildren(h('div',{class:'row'},h('div',{class:'big',style:{color:r.color}},r.regime),h('div',{class:'mut'},'Growth '+T.sgn(r.growth)+' · Infl '+T.sgn(r.inflation))),
      h('div',{class:'mut',style:{margin:'8px 0 4px',fontSize:'9px',letterSpacing:'.06em'}},'KEY DRIVERS'),T.table([{label:'',left:true,get:r=>r.label,cls:()=>'wrap'},{label:'',k:'actual',fmt:v=>T.fmt(v,2)},{label:'',k:'z',fmt:v=>T.sgn(v)+'σ',cls:v=>T.cls(v)}],r.drivers))}
    else P.reg.body.replaceChildren(h('div',{class:'msg'},'Regime tidak tersedia'));
    if(d.catalysts)P.cat.body.replaceChildren(T.table([{label:'Title',left:true,get:r=>r.title,cls:()=>'wrap'},{label:'Region',k:'region'},{label:'Bias',node:(_,r)=>T.badge(r.bias)},{label:'Impact',node:(_,r)=>T.badge(r.impact)}],d.catalysts));
    if(d.maritime){
      const v=d.maritime.vessels||[];
      if(!map)map=T.shipMap(mapEl,v,{center:[20,40],zoom:2});else map.drawVessels(v);
      map.getContainer().querySelectorAll('.aisnote').forEach(x=>x.remove());
      if(!v.length){const st=d.maritime.status;map.getContainer().insertAdjacentHTML('beforeend',`<div class="aisnote" style="position:absolute;z-index:500;left:10px;bottom:10px;background:#000a;padding:6px 10px;border-radius:4px;color:#9aa">${T.esc(st.error||'Menunggu data AIS')}</div>`)}
    }
  };
  const onErr=e=>{[P.mo,P.cm,P.cot,P.bond,P.ev,P.reg,P.cat,P.live].forEach(p=>{if(!p.body.querySelector('table,.feed,.row'))p.body.replaceChildren(h('div',{class:'msg err'},e.message))})};
  const cached=!!T.cache.get('dashboard');
  if(!cached)[P.mo,P.cm,P.cot,P.bond,P.ev,P.reg,P.cat,P.live].forEach(p=>p.body.append(h('div',{class:'msg'},'Memuat…')));
  // Kunjungan ulang: data tersimpan langsung tampil, lalu diperbarui di latar belakang. Polling berikutnya hanya memperbarui isi.
  T.cachedThen('dashboard',null,d=>fill(d)).catch(onErr);
  T.every(60000,()=>T.api('dashboard',null,{force:true}).then(fill).catch(()=>{}));
};
})();
