(function(){
const T={Views:{},timers:[],charts:[],maps:[],route:null,gen:0,cache:{}};
window.T=T;
T.cache=new Map();T.reqs=new Map();T.inflight=new Map();T.watchers=[];T.state={};
T.TTL={dashboard:60e3,ticker:60e3,'intel/feed':60e3,maritime:30e3,'geo/overview':120e3,'market/assets':60e3,'market/heatmap':60e3,'signal/pair':60e3};
T.ttlOf=p=>T.TTL[p]||300e3;
T.rawFetch=async(path,params)=>{
  const q=params?'?'+new URLSearchParams(Object.entries(params).filter(([,v])=>v!==undefined&&v!==null&&v!=='')).toString():'';
  const t0=performance.now();
  const r=await fetch('/api/'+path+q,{credentials:'same-origin'});
  T.ping=Math.round(performance.now()-t0);
  if(r.status===401){location.reload();throw new Error('Sesi berakhir. Memuat ulang…')}
  const j=await r.json();
  if(j&&j.error)throw new Error(j.error);
  return j;
};
T.emit=(key,data)=>{T.watchers.filter(w=>w.key===key&&w.g===T.gen).forEach(w=>w.fn(data))};
// Data disimpan per permintaan. Kunjungan ulang ke menu langsung memakai data tersimpan (tanpa "Memuat…");
// bila sudah lewat TTL atau server menandai ada data baru, data diperbarui di latar belakang dan tampilan
// digambar ulang hanya jika isinya benar-benar berubah.
T.api=(path,params,opt={})=>{
  const q=params?'?'+new URLSearchParams(Object.entries(params).filter(([,v])=>v!==undefined&&v!==null&&v!=='')).toString():'';
  const key=path+q;
  T.reqs.set(key,[path,params]);
  const fresh=()=>{
    if(T.inflight.has(key))return T.inflight.get(key);
    const p=T.rawFetch(path,params).then(d=>{
      const js=JSON.stringify(d),old=T.cache.get(key);
      T.cache.set(key,{data:d,ts:Date.now(),js});T.inflight.delete(key);
      if(old&&old.js!==js)T.emit(key,d);
      return d;
    }).catch(e=>{T.inflight.delete(key);throw e});
    T.inflight.set(key,p);return p;
  };
  const hit=T.cache.get(key);
  let p;
  if(hit&&!opt.force){
    p=Promise.resolve(hit.data);p.cached=true;
    if(Date.now()-hit.ts>T.ttlOf(path))fresh().catch(()=>{});
  }else p=fresh();
  p.key=key;
  return p;
};
// Untuk tampilan yang menggambar sendiri: tampilkan data tersimpan dulu (bila ada), lalu ambil data terbaru.
T.cachedThen=async(path,params,fill)=>{
  const g=T.gen;
  const q=params?'?'+new URLSearchParams(Object.entries(params).filter(([,v])=>v!==undefined&&v!==null&&v!=='')).toString():'';
  const hit=T.cache.get(path+q);
  if(hit)fill(hit.data,true);
  const d=await T.api(path,params,{force:true});
  if(g===T.gen)fill(d,false);
  return d;
};
T.refreshActive=()=>{T.watchers.filter(w=>w.g===T.gen).forEach(w=>{const r=T.reqs.get(w.key);if(r)T.api(r[0],r[1],{force:true}).catch(()=>{})})};
T.mem=(ns,def)=>T.state[ns]||(T.state[ns]=Object.assign({},def));
T.h=function(tag,props,...kids){
  const e=document.createElement(tag);
  if(props)for(const k in props){
    const v=props[k];
    if(v==null||v===false)continue;
    if(k==='class')e.className=v;
    else if(k==='style'&&typeof v==='object')Object.assign(e.style,v);
    else if(k==='html')e.innerHTML=v;
    else if(k.startsWith('on'))e.addEventListener(k.slice(2),v);
    else e.setAttribute(k,v===true?'':v);
  }
  const add=k=>{if(k==null||k===false)return;if(Array.isArray(k))k.forEach(add);else e.append(k.nodeType?k:document.createTextNode(String(k)))};
  kids.forEach(add);
  return e;
};
const h=T.h;
T.esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
T.fmt=(v,d=2)=>v==null||isNaN(v)?'—':Number(v).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
T.pct=(v,d=2)=>v==null||isNaN(v)?'—':(v>0?'+':'')+Number(v).toFixed(d)+'%';
T.cls=v=>v>0?'up':v<0?'dn':'';
T.sgn=(v,d=2)=>v==null||isNaN(v)?'—':(v>0?'+':'')+Number(v).toFixed(d);
T.big=(v,cur='')=>{if(v==null||isNaN(v))return '—';const a=Math.abs(v);const s=a>=1e12?(a/1e12).toFixed(2)+'T':a>=1e9?(a/1e9).toFixed(2)+'B':a>=1e6?(a/1e6).toFixed(2)+'M':a>=1e3?(a/1e3).toFixed(1)+'K':a.toFixed(0);return (v<0?'-':'')+cur+s};
T.ago=ts=>{const s=Math.max(0,Date.now()/1000-ts);if(s<60)return Math.floor(s)+'s';if(s<3600)return Math.floor(s/60)+'m';if(s<86400)return Math.floor(s/3600)+'h';return Math.floor(s/86400)+'d'};
T.badge=(txt,cls)=>h('span',{class:'badge b-'+String(cls||txt).replace(/\s+/g,'-')},txt);
T.every=(ms,fn)=>{const g=T.gen;const id=setInterval(()=>{if(g===T.gen)fn()},ms);T.timers.push(id)};
T.spark=(vals,w=70,hh=18,color)=>{
  const v=(vals||[]).filter(x=>x!=null);if(v.length<2)return '';
  const mn=Math.min(...v),mx=Math.max(...v),rg=mx-mn||1;
  const pts=v.map((x,i)=>(i/(v.length-1)*w).toFixed(1)+','+(hh-2-((x-mn)/rg)*(hh-4)).toFixed(1)).join(' ');
  const c=color||(v[v.length-1]>=v[0]?'#22c55e':'#ef4444');
  return `<svg width="${w}" height="${hh}" viewBox="0 0 ${w} ${hh}"><polyline fill="none" stroke="${c}" stroke-width="1.2" points="${pts}"/></svg>`;
};
T.miniBars=(vals,w=70,hh=18)=>{
  const v=(vals||[]).filter(x=>x!=null);if(!v.length)return '';
  const mx=Math.max(...v.map(Math.abs))||1,bw=w/v.length;
  return `<svg width="${w}" height="${hh}">`+v.map((x,i)=>{const bh=Math.max(1,Math.abs(x)/mx*(hh-2));return `<rect x="${(i*bw+1).toFixed(1)}" y="${(hh-bh).toFixed(1)}" width="${Math.max(1,bw-2).toFixed(1)}" height="${bh.toFixed(1)}" fill="${i===v.length-1?'#60a5fa':'#3b4660'}"/>`}).join('')+'</svg>';
};
T.panel=(title,opts={})=>{
  const head=h('div',{class:'ph'},h('span',null,title),h('span',{class:'sp'}),opts.actions||null);
  const body=h('div',{class:'pb'+(opts.np?' np':''),style:opts.bodyStyle||null});
  const el=h('div',{class:'panel',style:opts.style||null},head,body);
  return {el,body,head};
};
T.tabs=(items,active,onSel,cls='')=>{
  const box=h('div',{class:'tabs '+cls});
  const set=id=>{[...box.children].forEach(b=>b.classList.toggle('on',b.dataset.id===String(id)))};
  items.forEach(it=>{const id=typeof it==='object'?it.id:it,label=typeof it==='object'?it.label:it;
    box.append(h('button',{'data-id':id,onclick:()=>{set(id);onSel(id)}},label))});
  set(active);box.set=set;
  return box;
};
T.select=(opts,val,onChange)=>{
  const s=h('select',{onchange:e=>onChange(e.target.value)});
  opts.forEach(o=>{const v=typeof o==='object'?o.v:o,l=typeof o==='object'?o.l:o;s.append(h('option',{value:v,selected:String(v)===String(val)},l))});
  return s;
};
T.table=(cols,rows,opt={})=>{
  const t=h('table',{class:'t'});
  t.append(h('thead',null,h('tr',null,cols.map(c=>h('th',{style:c.left?{textAlign:'left'}:null},c.label)))));
  const tb=h('tbody');
  rows.forEach((r,i)=>{
    const tr=h('tr',{class:opt.onRow?'cl':''});
    if(opt.onRow)tr.onclick=()=>{[...tb.children].forEach(x=>x.classList.remove('sel'));tr.classList.add('sel');opt.onRow(r,i)};
    if(opt.selected&&opt.selected(r))tr.classList.add('sel');
    cols.forEach(c=>{
      const raw=c.get?c.get(r):r[c.k];
      const td=h('td',{class:(c.cls?c.cls(raw,r):'')+(c.wrap?' wrap':'')});
      if(c.html)td.innerHTML=c.html(raw,r);
      else if(c.node){const n=c.node(raw,r);if(n!=null)td.append(n.nodeType?n:document.createTextNode(String(n)))}
      else td.textContent=c.fmt?c.fmt(raw,r):(raw==null?'—':raw);
      tr.append(td);
    });
    tb.append(tr);
  });
  t.append(tb);
  return t;
};
T.chart=(el,option,opts={})=>{
  const c=echarts.init(el,null,Object.assign({renderer:'canvas'},opts));
  c.setOption(Object.assign({backgroundColor:'transparent',animation:false,textStyle:{fontFamily:'inherit',color:'#8b93a7'}},option),true);
  T.charts.push(c);if(T._own)T._own.charts.push(c);
  const ro=new ResizeObserver(()=>{try{c.resize()}catch(e){}});
  ro.observe(el);c._ro=ro;
  return c;
};
T.axis=(o={})=>Object.assign({axisLine:{lineStyle:{color:'#2a3042'}},axisTick:{show:false},axisLabel:{color:'#7d8498',fontSize:10},splitLine:{lineStyle:{color:'#1a1f2b'}}},o);
T.grid=(o={})=>Object.assign({left:46,right:14,top:22,bottom:26,containLabel:false},o);
T.tip=(o={})=>Object.assign({trigger:'axis',backgroundColor:'#0b0d12',borderColor:'#2a3042',textStyle:{color:'#d7dbe6',fontSize:11},axisPointer:{lineStyle:{color:'#3b4660'}}},o);
T.chartBox=(height)=>h('div',{class:'chart',style:{height:height||'100%'}});
T.world=null;
// Poligon yang melintasi garis tanggal internasional (Rusia, Fiji) dibuat kontinu agar tidak menggambar pita horizontal.
T._fixWorld=d=>{
  const shift=(ring,dx)=>ring.map(c=>[c[0]+dx,c[1]]);
  d.features=d.features.filter(f=>f.properties.n!=='Antarctica').map(f=>{
    const g=f.geometry;if(!g)return f;
    const polys=g.type==='Polygon'?[g.coordinates]:g.coordinates;const out=[];
    polys.forEach(p=>{
      const xs=p[0].map(c=>c[0]);
      if(Math.max(...xs)-Math.min(...xs)>180){
        const fx=p.map(r=>r.map(c=>[c[0]<0?c[0]+360:c[0],c[1]]));
        out.push(fx,fx.map(r=>shift(r,-360)));
      }else out.push(p);
    });
    return {type:'Feature',properties:f.properties,geometry:{type:'MultiPolygon',coordinates:out}};
  });
  return d;
};
T.loadWorld=()=>T.world||(T.world=fetch('vendor/world.geojson').then(r=>r.json()).then(T._fixWorld).catch(()=>({type:'FeatureCollection',features:[]})));
T.map=(el,center,zoom)=>{
  const m=L.map(el,{zoomControl:false,attributionControl:false,worldCopyJump:true,preferCanvas:true,minZoom:2,maxZoom:8,zoomSnap:0.5}).setView(center||[20,10],zoom||2);
  T.loadWorld().then(d=>{
    try{m._base=L.geoJSON(d,{interactive:false,style:{fillColor:'#151a25',fillOpacity:1,color:'#2c3448',weight:.6}}).addTo(m);m._base.bringToBack()}catch(e){}
  });
  L.control.zoom({position:'topright'}).addTo(m);
  T.maps.push(m);if(T._own)T._own.maps.push(m);
  // Ukuran peta mengikuti wadahnya, apa pun yang terjadi pada elemen di sekitarnya.
  try{const ro=new ResizeObserver(()=>{try{m.invalidateSize()}catch(e){}});ro.observe(el);m._ro=ro}catch(e){}
  setTimeout(()=>m.invalidateSize(),150);
  return m;
};
T.clearOwned=box=>{
  const o=box&&box._own;if(!o)return;
  o.charts.forEach(c=>{try{c._ro&&c._ro.disconnect();c.dispose()}catch(e){}});
  o.maps.forEach(m=>{try{m._ro&&m._ro.disconnect();m.remove()}catch(e){}});
  T.charts=T.charts.filter(c=>!o.charts.includes(c));T.maps=T.maps.filter(m=>!o.maps.includes(m));
  box._own=null;
};
T.load=async(box,promise,render)=>{
  const g=T.gen,key=promise&&promise.key,vw=document.getElementById('view');
  const draw=async d=>{
    T.clearOwned(box);box.innerHTML='';
    const own={charts:[],maps:[]};box._own=own;T._own=own;
    try{await render(d)}finally{T._own=null}
  };
  if(!(promise&&promise.cached)){T.clearOwned(box);box.innerHTML='';box.append(h('div',{class:'msg'},'Memuat data…'))}
  try{
    const d=await promise;if(g!==T.gen)return;
    await draw(d);
    if(key)T.watchers.push({key,g,fn:async nd=>{
      if(g!==T.gen||!box.isConnected)return;
      const sc=vw?vw.scrollTop:0;
      try{await draw(nd)}catch(e){console.error(e)}
      if(vw)vw.scrollTop=sc;
    }});
  }catch(e){
    if(g!==T.gen)return;
    T.clearOwned(box);box.innerHTML='';box.append(h('div',{class:'msg err'},'Data tidak tersedia: '+e.message));
  }
};
T.dispose=()=>{
  T.gen++;
  T.watchers=[];
  T.timers.forEach(clearInterval);T.timers=[];
  T.charts.forEach(c=>{try{c._ro&&c._ro.disconnect();c.dispose()}catch(e){}});T.charts=[];
  T.maps.forEach(m=>{try{m._ro&&m._ro.disconnect();m.remove()}catch(e){}});T.maps=[];
};
T.countries=[['US','UNITED STATES'],['CN','CHINA'],['EU','EURO ZONE'],['JP','JAPAN'],['GB','UNITED KINGDOM'],['CA','CANADA'],['AU','AUSTRALIA'],['ID','INDONESIA'],['CH','SWITZERLAND'],['NZ','NEW ZEALAND']];
T.cname=cc=>(T.countries.find(c=>c[0]===cc)||[0,cc])[1];
T.heat=(v,max)=>{if(v==null)return 'transparent';const a=Math.min(1,Math.abs(v)/(max||1));return v>=0?`rgba(34,197,94,${(0.12+a*0.5).toFixed(2)})`:`rgba(239,68,68,${(0.12+a*0.5).toFixed(2)})`};
T.modules=[
  ['dashboard','▦','DASHBOARD'],['signal','◈','SIGNAL'],['heatmap','▩','HEATMAP & FOOTPRINT'],['macro','◔','MACRO'],['market','▤','MARKET'],['centralbank','⌂','CENTRAL BANK'],['fiscal','▥','FISCAL POLICY'],['intel','◉','MARKET INTELLIGENCE'],
  ['etf','◫','ETF'],['financials','$','FINANCIALS'],['participant','◐','MARKET PARTICIPANT'],['geo','◍','GEOPOLITICAL RISK'],['supply','⇄','SUPPLY CHAIN'],['quant','∿','QUANTITATIVE'],['futures','≋','FUTURES'],
  ['thinking','◌','THINKING']
];
})();
