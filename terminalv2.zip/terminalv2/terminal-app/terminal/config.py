import os
import pathlib
from dotenv import load_dotenv

ROOT = pathlib.Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


# --- Tidak ada kredensial wajib. Akses ke website dijaga KUNCI AKSES (dibuat otomatis, lihat terminal/auth.py) ----
# ACCESS_KEY kosong  -> dibuat acak sekali lalu disimpan di data/access_key.txt
# ACCESS_KEY=none    -> tanpa kunci (siapa pun yang tahu URL bisa masuk)
ACCESS_KEY = os.getenv("ACCESS_KEY", "").strip()
# --- Dua peran akses -----------------------------------------------------------------------------------------
# ADMIN_KEY : developer. Akses penuh: kontrol bot (Breakeven, Sinyal ON/OFF, pilih pair, mode trading) + halaman INSIDE/ANALISIS + status sumber data.
#             Kosong -> memakai ACCESS_KEY lama bila ada, jika tidak dibuat otomatis (data/access_key.txt).
# USER_KEY  : pengguna biasa. Hanya melihat menu SIGNAL versi baca-saja (chart, list pair, order terbuka/limit/tertutup) + menu lain.
#             Kosong -> dibuat otomatis (data/user_key.txt). "none" -> tidak ada kunci user (hanya admin yang bisa masuk).
ADMIN_KEY = os.getenv("ADMIN_KEY", "").strip()
USER_KEY = os.getenv("USER_KEY", "").strip()
# --- Opsional & gratis (mendaftar gratis): AISStream (kapal global) dan Myfxbook (sentimen retail) -----
MYFXBOOK_EMAIL = os.getenv("MYFXBOOK_EMAIL", "").strip()
MYFXBOOK_PASSWORD = os.getenv("MYFXBOOK_PASSWORD", "").strip()
AISSTREAM_API_KEY = os.getenv("AISSTREAM_API_KEY", "").strip()
# Berita tercepat dari X: Walter Bloomberg (@DeItaone) & akun squawk lain. Lihat providers/xfeed.py.
X_BEARER_TOKEN = os.getenv("X_BEARER_TOKEN", "").strip()                      # token X API v2 (developer.x.com)
X_ACCOUNTS = [a.strip().lstrip("@") for a in os.getenv("X_ACCOUNTS", "DeItaone").split(",") if a.strip()]
X_POLL_SEC = max(15, int(os.getenv("X_POLL_SEC", "60") or 60))                # sesuaikan dengan kuota paket X API Anda
X_RSS_URLS = [u.strip() for u in os.getenv("X_RSS_URLS", "").split(",") if u.strip()]   # alternatif: feed RSS akun X milik Anda
# GRATIS tanpa akun: channel Telegram publik (halaman t.me/s/) & akun Bluesky (API publik). Lihat providers/social.py.
TG_CHANNELS = [c.strip().lstrip("@") for c in os.getenv("TG_CHANNELS", "Walter_Bloomberg").split(",") if c.strip()]
BSKY_ACCOUNTS = [a.strip().lstrip("@") for a in os.getenv("BSKY_ACCOUNTS", "walterbloomberg.bsky.social").split(",") if a.strip()]
TG_POLL_SEC = max(20, int(os.getenv("TG_POLL_SEC", "30") or 30))
# --- AI lokal (Ollama): tanpa API key, berjalan di komputer sendiri ------------------------------------
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434").strip().rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gemma3:1b").strip()
OLLAMA_TIMEOUT = int(os.getenv("OLLAMA_TIMEOUT", "180"))
LLM_ENABLED = os.getenv("LLM_ENABLED", "1") != "0"
# Thread CPU untuk AI lokal. Bawaan = setengah core (min. 1) supaya server terminal tetap kebagian CPU saat AI menulis.
OLLAMA_THREADS = max(1, int(os.getenv("OLLAMA_THREADS", "0") or 0) or (os.cpu_count() or 2) // 2)

HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "8787"))
KEEPALIVE_SEC = max(30, int(os.getenv("KEEPALIVE_SEC", "120") or 120))    # koneksi idle dari cloudflared dibiarkan terbuka (cegah 502)
DEV_NO_AUTH = os.getenv("DEV_NO_AUTH", "0") == "1"
# Bot sinyal berjalan di latar belakang (analisa 24 jam + pelacak order). 0 = dimatikan (dipakai pengujian).
SIGNAL_RUNNER = os.getenv("SIGNAL_RUNNER", "1") != "0"
SESSION_DAYS = int(os.getenv("SESSION_DAYS", "30"))
TERMINAL_NAME = os.getenv("TERMINAL_NAME", "Terminal")
CLOUDFLARED_PATH = os.getenv("CLOUDFLARED_PATH", "").strip()
PUBLIC_URL = os.getenv("PUBLIC_URL", "").strip()
# --- Terminal SERVER: tunnel Cloudflare & panel ------------------------------------------------------------------
TUNNEL_CHECK_EVERY = max(10, int(os.getenv("TUNNEL_CHECK_EVERY", "30")))   # detik antar pemeriksaan link publik (GET <link>/healthz)
TUNNEL_PROTOCOL = os.getenv("TUNNEL_PROTOCOL", "http2").strip().lower()
# Link quick tunnel hanya diganti bila tunnel BENAR-BENAR putus (530/1033 atau cloudflared tanpa koneksi) terus-menerus selama ini (menit)
TUNNEL_DOWN_MIN = max(1.0, float(os.getenv("TUNNEL_DOWN_MIN", "5") or 5))   # http2 | quic (otomatis berganti bila gagal berulang)
SERVER_PANEL = os.getenv("SERVER_PANEL", "1") != "0"                       # 0 = tanpa panel tetap (log biasa seperti versi lama)
# 6 agent (NEWS, TEKNIKAL, FUNDAMENTAL, VOLUME, QUANT, FEBRIAN) berjalan DI DALAM proses server (satu terminal).
# 0 = tidak menjalankan agent di server (mis. bila tetap ingin menjalankannya sebagai proses terpisah secara manual).
AGENTS_INPROCESS = os.getenv("AGENTS_INPROCESS", "1") != "0"
DB_PATH = pathlib.Path(os.getenv("DB_PATH", str(ROOT / "data" / "terminal.db")))
DATA_DIR = DB_PATH.parent
# --- Preload & snapshot (data tersimpan di DB, dipakai semua pengunjung) ---------------------------------------
PRELOAD_TIMEOUT = int(os.getenv("PRELOAD_TIMEOUT", "300"))          # detik maks menunggu preload tahap 1 sebelum URL ditampilkan
PRELOAD_CONCURRENCY = int(os.getenv("PRELOAD_CONCURRENCY", "6"))     # pekerjaan paralel saat preload tahap 1
REFRESH_CONCURRENCY = int(os.getenv("REFRESH_CONCURRENCY", "3"))     # pekerjaan paralel saat pembaruan latar belakang
JOB_TIMEOUT = int(os.getenv("JOB_TIMEOUT", "150"))                   # detik maks satu pekerjaan preload/pembaruan
PRELOAD_FORCE = os.getenv("PRELOAD_FORCE", "0") == "1"               # 1 = selalu tunggu muat-ulang penuh walau snapshot lama ada
PRELOAD_DEEP = os.getenv("PRELOAD_DEEP", "1") != "0"                 # tahap 2: muat semua simbol/instrumen (ekor panjang) di latar belakang
BIN_DIR = ROOT / "bin"
WEB_DIR = ROOT / "terminal" / "web"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
