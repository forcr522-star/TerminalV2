"""Watchdog event loop: mendeteksi saat server "macet" (event loop tertahan) dan mencatat DI MANA macetnya.

Website, API, dan pemeriksaan tunnel Cloudflare semuanya dilayani satu event loop. Bila loop tertahan (kode sinkron
yang lama, menunggu kunci database, dsb.), semua permintaan ikut menunggu: PING di website naik dan Cloudflare bisa
menampilkan "Host Error" walau terminal masih berjalan. Thread kecil ini memeriksa denyut loop tiap 0,25 dtk; bila
denyut terlambat > AMBANG, tumpukan kode thread loop direkam lalu dicetak sekali saat loop pulih:

    [watchdog] server tertahan 4.2 dtk - terminal/store.py:58 query <- terminal/heatmap/view.py:612 trades_from ...

Ringkasan (jumlah, terlama, lokasi terakhir) tersedia lewat stats() untuk panel status.
"""
import asyncio
import collections
import os
import sys
import threading
import time
import traceback

THRESHOLD = float(os.getenv("WATCHDOG_SEC", "1.0") or 1.0)    # dtk; 0 = mati
_state = dict(beat=0.0, stalls=0, worst=0.0, worst_at=None, worst_where=None, last=None, last_where=None, running=False)
_recent = collections.deque(maxlen=50)      # (mulai, selesai) waktu dinding macet terakhir


def stalled_since(t0):
    """True bila event loop macet sejak t0 (waktu dinding) - timeout yang terjadi bukan kesalahan sumber datanya."""
    if not _state["running"]:
        return False
    if time.monotonic() - _state["beat"] > 1.0:     # loop baru saja macet; denyut belum sempat berjalan
        return True
    return any(end >= t0 for _, end in list(_recent))


def stats():
    return {k: v for k, v in _state.items() if k != "beat"}


def busy(within=3.0):
    """True bila event loop sedang atau baru saja (dalam `within` dtk) tertahan."""
    if not _state["running"]:
        return False
    if time.monotonic() - _state["beat"] > 0.75:
        return True
    t = time.time() - within
    return any(end >= t for _, end in list(_recent))


async def calm(max_wait=20.0, within=3.0):
    """Untuk pekerjaan LATAR (preload tahap 2, pembaruan otomatis): sesudah server tertahan, tunggu sampai tenang
    `within` dtk sebelum menambah beban baru (paling lama `max_wait` dtk). Tanpa watchdog: langsung kembali."""
    t0 = time.monotonic()
    while busy(within) and time.monotonic() - t0 < max_wait:
        await asyncio.sleep(0.5)


# Bingkai terdalam thread yang sedang MENUNGGU (antrean, kunci, soket, tidur) - tidak dihitung sebagai "sibuk".
_IDLE_FILES = ("threading.py", "queue.py", "selectors.py", "socket.py", "ssl.py", "windows_events.py", "base_events.py")
_IDLE_FUNCS = {"wait", "get", "_worker", "select", "poll", "_poll", "sleep", "accept", "recv", "recv_into", "readinto",
               "read", "acquire", "_wait_for_tstate_lock", "join", "perform", "getaddrinfo", "watch"}


def _busy_threads(skip):
    """[(nama-kelompok thread, lokasi)] untuk thread yang sedang menjalankan kode (bukan menunggu)."""
    names = {t.ident: t.name for t in threading.enumerate()}
    out = []
    for ident, frame in sys._current_frames().items():
        if ident in skip or frame is None:
            continue
        fn = frame.f_code.co_filename.replace(chr(92), "/").rsplit("/", 1)[-1]
        if fn in _IDLE_FILES or frame.f_code.co_name in _IDLE_FUNCS:
            continue
        nm = names.get(ident, "?")
        grp = nm.rstrip("0123456789").rstrip("_-") or nm
        out.append((grp, _where(frame, depth=1)))
    return out


def _top(counter, n=3):
    return ", ".join(f"{g} {w} ({c})" for (g, w), c in counter.most_common(n))


def _where(frame, depth=4):
    """Ringkas tumpukan: bingkai TERDALAM (bisa pustaka - di sanalah waktu habis) + bingkai kode terminal, terdalam dulu."""
    stack = traceback.extract_stack(frame)
    if not stack:
        return "?"
    inner = stack[-1]
    parts = [f"{'/'.join(inner.filename.replace(chr(92), '/').split('/')[-2:])}:{inner.lineno} {inner.name}"]
    for fs in reversed(stack[:-1]):
        fn = fs.filename.replace(chr(92), "/")
        if "/terminal/" in fn:
            parts.append(f"{fn.split('/terminal/')[-1]}:{fs.lineno} {fs.name}")
        if len(parts) > depth:
            break
    return " <- ".join(parts)


def start(log=print, threshold=None):
    """Panggil dari dalam event loop yang berjalan. Aman dipanggil berkali-kali (hanya satu watchdog)."""
    thr = THRESHOLD if threshold is None else threshold
    if thr <= 0 or _state["running"]:
        return
    loop = asyncio.get_running_loop()
    ident = threading.get_ident()
    _state.update(beat=time.monotonic(), running=True)

    async def beat():
        while True:
            _state["beat"] = time.monotonic()
            await asyncio.sleep(0.25)
    loop.create_task(beat())

    def watch():
        stall_from, where = None, None
        others = collections.Counter()      # thread lain yang sedang menjalankan kode selama macet (kandidat penyebab)
        skip = {ident, threading.get_ident()}
        while True:
            time.sleep(0.2)
            lag = time.monotonic() - _state["beat"]
            if lag > thr + 0.25:
                if stall_from is None:
                    stall_from = _state["beat"]
                    others.clear()
                    frame = sys._current_frames().get(ident)
                    where = _where(frame) if frame is not None else "?"
                elif lag > 3 * thr:
                    frame = sys._current_frames().get(ident)   # macet lama: perbarui lokasi (penyebab bisa berganti)
                    if frame is not None:
                        where = _where(frame)
                try:
                    others.update(_busy_threads(skip))
                except Exception:
                    pass
            elif stall_from is not None:
                dur = _state["beat"] - stall_from
                if dur > thr:
                    now = time.time()
                    _recent.append((now - dur, now))
                    _state["stalls"] += 1
                    busy_txt = _top(others)
                    _state.update(last=round(dur, 2), last_where=where, last_busy=busy_txt)
                    if dur > _state["worst"]:
                        _state.update(worst=round(dur, 2), worst_at=time.time(), worst_where=where, worst_busy=busy_txt)
                    try:
                        log(f"[watchdog] server tertahan {dur:.1f} dtk - {where}" + (f" | thread sibuk: {busy_txt}" if busy_txt else ""))
                    except Exception:
                        pass
                stall_from, where = None, None
    threading.Thread(target=watch, name="loop-watchdog", daemon=True).start()
