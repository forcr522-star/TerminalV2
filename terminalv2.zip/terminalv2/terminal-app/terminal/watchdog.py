"""Watchdog event loop: mendeteksi saat server "macet" (event loop tertahan) dan mencatat DI MANA macetnya.

Website, API, dan pemeriksaan tunnel Cloudflare semuanya dilayani satu event loop. Bila loop tertahan (kode sinkron
yang lama, menunggu kunci database, dsb.), semua permintaan ikut menunggu: PING di website naik dan Cloudflare bisa
menampilkan "Host Error" walau terminal masih berjalan. Thread kecil ini memeriksa denyut loop tiap 0,25 dtk; bila
denyut terlambat > AMBANG, tumpukan kode thread loop direkam lalu dicetak sekali saat loop pulih:

    [watchdog] server tertahan 4.2 dtk - terminal/store.py:58 query <- terminal/heatmap/view.py:612 trades_from ...

Ringkasan (jumlah, terlama, lokasi terakhir) tersedia lewat stats() untuk panel status.
"""
import asyncio
import collections
import os
import sys
import threading
import time
import traceback

THRESHOLD = float(os.getenv("WATCHDOG_SEC", "1.0") or 1.0)    # dtk; 0 = mati
_state = dict(beat=0.0, stalls=0, worst=0.0, worst_at=None, worst_where=None, last=None, last_where=None, running=False)
_recent = collections.deque(maxlen=50)      # (mulai, selesai) waktu dinding macet terakhir


def stalled_since(t0):
    """True bila event loop macet sejak t0 (waktu dinding) - timeout yang terjadi bukan kesalahan sumber datanya."""
    if not _state["running"]:
        return False
    if time.monotonic() - _state["beat"] > 1.0:     # loop baru saja macet; denyut belum sempat berjalan
        return True
    return any(end >= t0 for _, end in list(_recent))


def stats():
    return {k: v for k, v in _state.items() if k != "beat"}


def _where(frame, depth=5):
    """Ringkas tumpukan: hanya bingkai dari kode terminal (bukan pustaka), terdalam dulu."""
    out = []
    for fs in reversed(traceback.extract_stack(frame)):
        fn = fs.filename.replace("\\", "/")
        if "/terminal/" in fn or fn.endswith("main.py"):
            out.append(f"{fn.split('/terminal/')[-1] if '/terminal/' in fn else 'main.py'}:{fs.lineno} {fs.name}")
        if len(out) >= depth:
            break
    if not out:
        fs = traceback.extract_stack(frame)[-1]
        out.append(f"{fs.filename.replace(chr(92), '/').split('/')[-1]}:{fs.lineno} {fs.name}")
    return " <- ".join(out)


def start(log=print, threshold=None):
    """Panggil dari dalam event loop yang berjalan. Aman dipanggil berkali-kali (hanya satu watchdog)."""
    thr = THRESHOLD if threshold is None else threshold
    if thr <= 0 or _state["running"]:
        return
    loop = asyncio.get_running_loop()
    ident = threading.get_ident()
    _state.update(beat=time.monotonic(), running=True)

    async def beat():
        while True:
            _state["beat"] = time.monotonic()
            await asyncio.sleep(0.25)
    loop.create_task(beat())

    def watch():
        stall_from, where = None, None
        while True:
            time.sleep(0.2)
            lag = time.monotonic() - _state["beat"]
            if lag > thr + 0.25:
                if stall_from is None:
                    stall_from = _state["beat"]
                    frame = sys._current_frames().get(ident)
                    where = _where(frame) if frame is not None else "?"
                elif lag > 3 * thr:
                    frame = sys._current_frames().get(ident)   # macet lama: perbarui lokasi (penyebab bisa berganti)
                    if frame is not None:
                        where = _where(frame)
            elif stall_from is not None:
                dur = _state["beat"] - stall_from
                if dur > thr:
                    now = time.time()
                    _recent.append((now - dur, now))
                    _state["stalls"] += 1
                    _state.update(last=round(dur, 2), last_where=where)
                    if dur > _state["worst"]:
                        _state.update(worst=round(dur, 2), worst_at=time.time(), worst_where=where)
                    try:
                        log(f"[watchdog] server tertahan {dur:.1f} dtk - {where}")
                    except Exception:
                        pass
                stall_from, where = None, None
    threading.Thread(target=watch, name="loop-watchdog", daemon=True).start()
