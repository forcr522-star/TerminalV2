"""Lapisan HTTP: website statis + /api/... yang dilayani dari snapshot (lihat snapshots.py dan api.py)."""
import asyncio
import contextlib
import gzip
import hashlib
import json
import re
import mimetypes
import time
import traceback
from urllib.parse import urlencode
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse, Response, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.gzip import GZipMiddleware
from starlette.datastructures import Headers
from . import config, auth, store, llm, notify
from . import http as H
from . import snapshots as S
from . import api  # noqa: F401  (mendaftarkan semua endpoint)
from .api import state, ADMIN_ONLY
from .providers import myfxbook, news, ais, xfeed, social
from .signals import control as sigctl, runner as sigrun
from .heatmap import control as hmctl, engine as hmengine, settings as hmset, alerts as hmalerts


# Windows membaca tipe MIME dari registry; font web bisa tidak dikenali tanpa ini.
mimetypes.add_type("font/woff2", ".woff2")


def _public(p):
    """Tanpa kunci hanya: berkas font (lisensi OFL, untuk halaman login) dan service worker notifikasi /sw.js
    (browser mengambilnya ulang di latar tanpa cookie; isinya tidak memuat data)."""
    if p in ("/sw.js", "/vendor/notify-icon.png"):
        return True
    return p.startswith("/vendor/fonts/") and p.endswith(".woff2") and ".." not in p and "%" not in p


async def _loop(fn, every, first=0):
    await asyncio.sleep(first)
    while True:
        try:
            await fn()
        except Exception:
            traceback.print_exc()
        await asyncio.sleep(every)


async def _retail_job():
    await myfxbook.poll_once()


async def _prune_job():
    await asyncio.to_thread(store.prune)     # DELETE pada tabel besar: jangan di event loop


async def _news_job():
    n0 = len(news._items)
    await news.refresh()
    if len(news._items) != n0:
        H.bump()


async def _llm_job():
    from .analytics import catalyst
    await llm.probe(force=True)
    if not llm.enabled():
        return
    cats = await catalyst.build_async()
    if cats:
        await llm.narrate(cats)


async def _llm_boot():
    if not config.LLM_ENABLED:
        return
    with contextlib.suppress(Exception):
        await llm.ensure_server()
        await llm.ensure_model()


@contextlib.asynccontextmanager
async def lifespan(app):
    news.load_cached()
    sigctl.reload()                        # kontrol bot (pair, mode, breakeven, sinyal on/off) dari database
    hmctl.reload()                         # pair HEATMAP yang dipilih admin (hanya pair ini yang dipantau)
    state["snapshots_loaded"] = S.load()   # snapshot dari sesi sebelumnya: langsung bisa dilayani
    # berita: putaran tiap 15 dtk, tetapi tiap feed punya jedanya sendiri (sumber cepat 20-90 dtk, Google 5 mnt, bank sentral 15 mnt)
    tasks = [asyncio.create_task(_loop(_news_job, 15)), asyncio.create_task(_loop(_prune_job, 86400, 3600))]
    tasks.append(asyncio.create_task(notify.run()))     # pengirim notifikasi push (per browser yang mengaktifkan)
    tasks.append(asyncio.create_task(social.run()))     # Walter Bloomberg GRATIS: Telegram (t.me/s) + Bluesky (API publik)
    tasks.append(asyncio.create_task(xfeed.run()))      # opsional berbayar: X API (aktif hanya bila X_BEARER_TOKEN / X_RSS_URLS diisi)
    if myfxbook.enabled():
        tasks.append(asyncio.create_task(_loop(_retail_job, 20 * 60, 5)))
    tasks.append(asyncio.create_task(ais.run()))
    tasks.append(asyncio.create_task(_llm_boot()))
    tasks.append(asyncio.create_task(_loop(_llm_job, 600, 60)))
    tasks.append(asyncio.create_task(S.refresher()))
    tasks.append(asyncio.create_task(asyncio.to_thread(FastStatic.warm, config.WEB_DIR)))   # gzip aset web sekali, di thread
    if config.SIGNAL_RUNNER:
        sigrun.load()                      # hasil analisa terakhir tiap pair (untuk halaman INSIDE/ANALISIS)
        tasks.append(asyncio.create_task(sigrun.analysis_loop(first=20)))   # analisa 24 jam semua pair terpilih (hanya saat SINYAL = ON)
        tasks.append(asyncio.create_task(sigrun.tracker_loop(first=10)))    # pantau order terbit: entry, SL, TP
    if hmset.COLLECTOR:
        tasks.append(asyncio.create_task(hmengine.manager.run()))   # WebSocket Binance: trade & candle pair terpilih
        tasks.append(asyncio.create_task(hmalerts.run()))           # notifikasi: likuiditas besar terambil
    yield
    for t in tasks:
        t.cancel()
    await H.close()


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
# level 6: hampir sekecil level 9 (bawaan) tetapi 2-3x lebih cepat; berkas statis sudah dikompres sekali (FastStatic)
app.add_middleware(GZipMiddleware, minimum_size=1200, compresslevel=6)


def _enter(request: Request, role):
    """Kunci benar: pasang cookie sesi (berisi peran) lalu buang kunci dari alamat."""
    rest = [(k, v) for k, v in request.query_params.multi_items() if k != "key"]
    loc = request.url.path + ("?" + urlencode(rest) if rest else "")
    resp = RedirectResponse(loc, status_code=303)
    https = request.headers.get("x-forwarded-proto", request.url.scheme) == "https"
    resp.set_cookie(auth.COOKIE, auth.session_token(role), max_age=config.SESSION_DAYS * 86400, httponly=True, samesite="lax", secure=https, path="/")
    return resp


@app.middleware("http")
async def guard(request: Request, call_next):
    p = request.url.path
    is_api = p.startswith("/api/")
    role = auth.ADMIN
    if p != "/healthz" and not _public(p) and auth.enabled():
        qk = request.query_params.get("key")
        if qk is not None and not is_api:
            r = auth.role_for_key(qk)
            return _enter(request, r) if r else HTMLResponse(auth.login_page(error=True), status_code=401)
        role = auth.role_of(request.cookies, request.headers)
        if role is None:
            if is_api:
                return JSONResponse({"error": "unauthorized"}, status_code=401)
            return HTMLResponse(auth.login_page(), status_code=401)
    request.state.role = role
    resp = await call_next(request)
    if not is_api and "cache-control" not in resp.headers:
        if request.query_params.get("v") or p.startswith("/vendor/fonts/"):
            resp.headers["Cache-Control"] = "public, max-age=31536000, immutable"   # berversi / tidak pernah berubah
        else:
            resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/healthz")
async def healthz():
    return {"ok": True, "uptime": int(time.time() - state["started"])}


@app.get("/api/me")
async def api_me(request: Request):
    """Peran sesi ini ('admin' / 'user'): dipakai website untuk menampilkan menu developer atau menu user biasa."""
    return JSONResponse({"role": getattr(request.state, "role", auth.USER)}, headers={"Cache-Control": "no-store"})


@app.post("/api/signal/control")
async def signal_control_update(request: Request):
    """Ubah kontrol bot (admin saja): {on, be, mode, pairs}. Hanya kunci yang dikirim yang diubah."""
    if getattr(request.state, "role", None) != auth.ADMIN:
        return JSONResponse({"error": "hanya admin yang boleh mengubah kontrol"}, status_code=403)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "isi permintaan bukan JSON yang valid"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "isi permintaan harus objek JSON"}, status_code=400)
    unknown = [k for k in body if k not in ("on", "be", "mode", "pairs")]
    if unknown:
        return JSONResponse({"error": "kunci tidak dikenal: " + ", ".join(map(str, unknown))}, status_code=422)
    try:
        st = sigctl.update(**body)
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)
    sigrun.on_control_changed(st)
    return JSONResponse({"ok": True, "state": st}, headers={"Cache-Control": "no-store"})


async def _json_body(request):
    try:
        body = await request.json()
    except Exception:
        return None
    return body if isinstance(body, dict) else None


@app.post("/api/notify/subscribe")
async def notify_subscribe(request: Request):
    """Aktifkan notifikasi untuk BROWSER INI: {subscription: PushSubscription, kinds: ["liq","news","signal"]}."""
    body = await _json_body(request)
    if body is None:
        return JSONResponse({"error": "isi permintaan bukan objek JSON"}, status_code=400)
    try:
        sid = await asyncio.to_thread(notify.subscribe, body.get("subscription"), body.get("kinds") or [], getattr(request.state, "role", auth.USER))
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)
    return JSONResponse({"ok": True, "id": sid}, headers={"Cache-Control": "no-store"})


@app.post("/api/notify/unsubscribe")
async def notify_unsubscribe(request: Request):
    body = await _json_body(request) or {}
    ok = await asyncio.to_thread(notify.unsubscribe, body.get("endpoint") or "")
    return JSONResponse({"ok": ok}, headers={"Cache-Control": "no-store"})


@app.post("/api/notify/test")
async def notify_test(request: Request):
    """Kirim notifikasi uji HANYA ke browser yang meminta (bukan ke pengguna lain)."""
    body = await _json_body(request) or {}
    res = await notify.test(body.get("endpoint") or "")
    return JSONResponse(res, headers={"Cache-Control": "no-store"})


@app.post("/api/heatmap/control")
async def heatmap_control_update(request: Request):
    """Pilih pair HEATMAP yang dipantau (admin saja): {pairs: [...]} -> pair lain berhenti dipantau seketika."""
    if getattr(request.state, "role", None) != auth.ADMIN:
        return JSONResponse({"error": "hanya admin yang boleh memilih pair heatmap"}, status_code=403)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "isi permintaan bukan JSON yang valid"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "isi permintaan harus objek JSON"}, status_code=400)
    unknown = [k for k in body if k != "pairs"]
    if unknown:
        return JSONResponse({"error": "kunci tidak dikenal: " + ", ".join(map(str, unknown))}, status_code=422)
    try:
        st = hmctl.update(pairs=body.get("pairs"))
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)
    return JSONResponse({"ok": True, "state": st}, headers={"Cache-Control": "no-store"})


@app.post("/api/signal/backtest")
async def signal_backtest_start(request: Request):
    """Mulai/hentikan backtest (admin saja). Body: {action:"start", mode, be, start, end, pairs?} atau {action:"stop"}."""
    if getattr(request.state, "role", None) != auth.ADMIN:
        return JSONResponse({"error": "hanya admin yang boleh menjalankan backtest"}, status_code=403)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "isi permintaan bukan JSON yang valid"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "isi permintaan harus objek JSON"}, status_code=400)
    from .signals import backtest as bt
    try:
        act = body.get("action")
        if act == "stop":
            return JSONResponse({"ok": True, "status": bt.stop()}, headers={"Cache-Control": "no-store"})
        if act != "start":
            return JSONResponse({"error": "action harus 'start' atau 'stop'"}, status_code=422)
        pairs = body.get("pairs")
        if pairs is not None and not isinstance(pairs, list):
            return JSONResponse({"error": "pairs harus daftar simbol"}, status_code=422)
        st = bt.start(body.get("mode", "swing"), body.get("start"), body.get("end"), bool(body.get("be", True)), pairs)
        return JSONResponse({"ok": True, "status": st}, headers={"Cache-Control": "no-store"})
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)


@app.get("/api/{path:path}")
async def api_route(path: str, request: Request):
    if path not in S.ENDPOINTS:
        return JSONResponse({"error": "endpoint tidak dikenal"}, status_code=404)
    role = getattr(request.state, "role", auth.USER)
    if path in ADMIN_ONLY and role != auth.ADMIN:
        return JSONResponse({"error": "hanya untuk admin"}, status_code=403)
    try:
        body, how = await S.serve(path, dict(request.query_params))
    except S.ParamError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)
    if path == "rev" and role != auth.ADMIN:     # jumlah sumber bermasalah hanya untuk admin
        try:
            d = json.loads(body)
            d["bad"] = 0
            body = json.dumps(d, separators=(",", ":")).encode("utf-8")
        except Exception:
            pass
    return Response(body, media_type="application/json", headers={"X-Snapshot": how, "Cache-Control": "no-store"})


config.WEB_DIR.mkdir(parents=True, exist_ok=True)


# ------------------------------------------------------------------------------------------------ halaman & aset statis
# Lewat Cloudflare Tunnel setiap permintaan menempuh perjalanan pulang-pergi ke komputer ini (ratusan ms). Dulu SEMUA
# aset dikirim "no-cache" -> tiap buka/muat ulang website memeriksa ulang ~30 berkas satu per satu. Kini index.html
# menautkan aset dengan ?v=<versi isi berkas>; aset bertanda versi disimpan browser permanen (immutable) dan tidak
# diperiksa ulang. Versi berubah otomatis bila isi berkas berubah (pembaruan program).
_ASSET_RE = re.compile(r'(\s(?:src|href)=")(?!https?:|data:|//|#)([^"?]+\.(?:js|css))(")')


def _asset_version():
    h = hashlib.sha1()
    for f in sorted(config.WEB_DIR.rglob("*")):
        if f.is_file() and f.suffix in (".js", ".css", ".html", ".woff2", ".geojson"):
            st = f.stat()
            h.update(f"{f.relative_to(config.WEB_DIR)}:{st.st_size}:{int(st.st_mtime)}".encode())
    return h.hexdigest()[:10]


_index_cache = {}


def render_index(role):
    """index.html dengan tautan aset berversi + peran sesi disisipkan (menu tidak perlu menunggu /api/me)."""
    ver = _asset_version()
    key = (ver, role)
    if key not in _index_cache:
        html = (config.WEB_DIR / "index.html").read_text(encoding="utf-8")
        html = _ASSET_RE.sub(lambda m: f"{m.group(1)}{m.group(2)}?v={ver}{m.group(3)}", html)
        boot = f'<script>window.__ROLE={json.dumps(role)};window.__V={json.dumps(ver)};</script>\n'
        html = html.replace("<script ", boot + "<script ", 1)
        _index_cache.clear()
        _index_cache[key] = html
    return _index_cache[key]


@app.get("/")
async def index(request: Request):
    role = getattr(request.state, "role", auth.USER)
    return HTMLResponse(render_index(role if role in (auth.ADMIN, auth.USER) else auth.USER), headers={"Cache-Control": "no-cache"})


class FastStatic(StaticFiles):
    """Berkas statis dengan gzip yang dihitung SEKALI (di thread, bukan di event loop) lalu disimpan di memori.

    Tanpa ini GZipMiddleware mengompres ulang echarts (1 MB), world.geojson (0,7 MB) dsb. pada SETIAP kunjungan baru,
    di dalam event loop (±350 ms per kunjungan): selama itu permintaan lain - termasuk dari cloudflared - ikut antre.
    Kunci cache = (path, ukuran, mtime) sehingga berkas yang diperbarui otomatis dikompres ulang."""
    COMPRESSIBLE = (".js", ".css", ".html", ".json", ".geojson", ".svg", ".txt")
    _gz = {}

    @classmethod
    def _compress(cls, full_path, st):
        key = (full_path, st.st_size, st.st_mtime_ns)
        hit = cls._gz.get(key)
        if hit is None:
            with open(full_path, "rb") as f:
                hit = gzip.compress(f.read(), 6)
            for k in [k for k in cls._gz if k[0] == full_path]:
                cls._gz.pop(k, None)
            cls._gz[key] = hit
        return hit

    async def get_response(self, path, scope):
        resp = await super().get_response(path, scope)
        if not isinstance(resp, FileResponse) or resp.status_code != 200:
            return resp
        req = Headers(scope=scope)
        full = str(resp.path)
        st = getattr(resp, "stat_result", None)
        if (st is None or st.st_size < 1200 or not full.lower().endswith(self.COMPRESSIBLE)
                or "gzip" not in req.get("accept-encoding", "") or req.get("range")):
            return resp
        body = await asyncio.to_thread(self._compress, full, st)
        headers = {k: v for k, v in resp.headers.items() if k.lower() not in ("content-length", "content-encoding")}
        headers["content-encoding"] = "gzip"
        headers["vary"] = "Accept-Encoding"
        return Response(body, status_code=200, headers=headers)

    @classmethod
    def warm(cls, root):
        """Kompres semua aset web di latar (dipanggil sekali saat start) supaya kunjungan pertama pun langsung cepat."""
        n = 0
        for f in root.rglob("*"):
            if f.is_file() and f.suffix.lower() in cls.COMPRESSIBLE and f.stat().st_size >= 1200:
                try:
                    cls._compress(str(f.resolve()), f.stat())
                    n += 1
                except OSError:
                    pass
        return n


app.mount("/", FastStatic(directory=str(config.WEB_DIR)), name="web")
