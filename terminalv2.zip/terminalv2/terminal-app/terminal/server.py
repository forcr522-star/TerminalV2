"""Lapisan HTTP: website statis + /api/... yang dilayani dari snapshot (lihat snapshots.py dan api.py)."""
import asyncio
import contextlib
import json
import time
import traceback
from urllib.parse import urlencode
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse, Response, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.gzip import GZipMiddleware
from . import config, auth, store, llm
from . import http as H
from . import snapshots as S
from . import api  # noqa: F401  (mendaftarkan semua endpoint)
from .api import state, ADMIN_ONLY
from .providers import myfxbook, news, ais
from .signals import control as sigctl, runner as sigrun
from .heatmap import control as hmctl, engine as hmengine, settings as hmset


async def _loop(fn, every, first=0):
    await asyncio.sleep(first)
    while True:
        try:
            await fn()
        except Exception:
            traceback.print_exc()
        await asyncio.sleep(every)


async def _retail_job():
    await myfxbook.poll_once()


async def _prune_job():
    store.prune()


async def _news_job():
    n0 = len(news._items)
    await news.refresh()
    if len(news._items) != n0:
        H.bump()


async def _llm_job():
    from .analytics import catalyst
    await llm.probe(force=True)
    if not llm.enabled():
        return
    cats = catalyst.build()
    if cats:
        await llm.narrate(cats)


async def _llm_boot():
    if not config.LLM_ENABLED:
        return
    with contextlib.suppress(Exception):
        await llm.ensure_server()
        await llm.ensure_model()


@contextlib.asynccontextmanager
async def lifespan(app):
    news.load_cached()
    sigctl.reload()                        # kontrol bot (pair, mode, breakeven, sinyal on/off) dari database
    hmctl.reload()                         # pair HEATMAP yang dipilih admin (hanya pair ini yang dipantau)
    state["snapshots_loaded"] = S.load()   # snapshot dari sesi sebelumnya: langsung bisa dilayani
    tasks = [asyncio.create_task(_loop(_news_job, 90)), asyncio.create_task(_loop(_prune_job, 86400, 3600))]
    if myfxbook.enabled():
        tasks.append(asyncio.create_task(_loop(_retail_job, 20 * 60, 5)))
    tasks.append(asyncio.create_task(ais.run()))
    tasks.append(asyncio.create_task(_llm_boot()))
    tasks.append(asyncio.create_task(_loop(_llm_job, 600, 60)))
    tasks.append(asyncio.create_task(S.refresher()))
    if config.SIGNAL_RUNNER:
        sigrun.load()                      # hasil analisa terakhir tiap pair (untuk halaman INSIDE/ANALISIS)
        tasks.append(asyncio.create_task(sigrun.analysis_loop(first=20)))   # analisa 24 jam semua pair terpilih (hanya saat SINYAL = ON)
        tasks.append(asyncio.create_task(sigrun.tracker_loop(first=10)))    # pantau order terbit: entry, SL, TP
    if hmset.COLLECTOR:
        tasks.append(asyncio.create_task(hmengine.manager.run()))   # WebSocket Binance: orderbook, trade, candle pair terpilih
    yield
    for t in tasks:
        t.cancel()
    await H.close()


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(GZipMiddleware, minimum_size=1200)


def _enter(request: Request, role):
    """Kunci benar: pasang cookie sesi (berisi peran) lalu buang kunci dari alamat."""
    rest = [(k, v) for k, v in request.query_params.multi_items() if k != "key"]
    loc = request.url.path + ("?" + urlencode(rest) if rest else "")
    resp = RedirectResponse(loc, status_code=303)
    https = request.headers.get("x-forwarded-proto", request.url.scheme) == "https"
    resp.set_cookie(auth.COOKIE, auth.session_token(role), max_age=config.SESSION_DAYS * 86400, httponly=True, samesite="lax", secure=https, path="/")
    return resp


@app.middleware("http")
async def guard(request: Request, call_next):
    p = request.url.path
    is_api = p.startswith("/api/")
    role = auth.ADMIN
    if p != "/healthz" and auth.enabled():
        qk = request.query_params.get("key")
        if qk is not None and not is_api:
            r = auth.role_for_key(qk)
            return _enter(request, r) if r else HTMLResponse(auth.login_page(error=True), status_code=401)
        role = auth.role_of(request.cookies, request.headers)
        if role is None:
            if is_api:
                return JSONResponse({"error": "unauthorized"}, status_code=401)
            return HTMLResponse(auth.login_page(), status_code=401)
    request.state.role = role
    resp = await call_next(request)
    if not is_api:
        resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/healthz")
async def healthz():
    return {"ok": True, "uptime": int(time.time() - state["started"])}


@app.get("/api/me")
async def api_me(request: Request):
    """Peran sesi ini ('admin' / 'user'): dipakai website untuk menampilkan menu developer atau menu user biasa."""
    return JSONResponse({"role": getattr(request.state, "role", auth.USER)}, headers={"Cache-Control": "no-store"})


@app.post("/api/signal/control")
async def signal_control_update(request: Request):
    """Ubah kontrol bot (admin saja): {on, be, mode, pairs}. Hanya kunci yang dikirim yang diubah."""
    if getattr(request.state, "role", None) != auth.ADMIN:
        return JSONResponse({"error": "hanya admin yang boleh mengubah kontrol"}, status_code=403)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "isi permintaan bukan JSON yang valid"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "isi permintaan harus objek JSON"}, status_code=400)
    unknown = [k for k in body if k not in ("on", "be", "mode", "pairs")]
    if unknown:
        return JSONResponse({"error": "kunci tidak dikenal: " + ", ".join(map(str, unknown))}, status_code=422)
    try:
        st = sigctl.update(**body)
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)
    sigrun.on_control_changed(st)
    return JSONResponse({"ok": True, "state": st}, headers={"Cache-Control": "no-store"})


@app.post("/api/heatmap/control")
async def heatmap_control_update(request: Request):
    """Pilih pair HEATMAP yang dipantau (admin saja): {pairs: [...]} -> pair lain berhenti dipantau seketika."""
    if getattr(request.state, "role", None) != auth.ADMIN:
        return JSONResponse({"error": "hanya admin yang boleh memilih pair heatmap"}, status_code=403)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "isi permintaan bukan JSON yang valid"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "isi permintaan harus objek JSON"}, status_code=400)
    unknown = [k for k in body if k != "pairs"]
    if unknown:
        return JSONResponse({"error": "kunci tidak dikenal: " + ", ".join(map(str, unknown))}, status_code=422)
    try:
        st = hmctl.update(pairs=body.get("pairs"))
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)
    return JSONResponse({"ok": True, "state": st}, headers={"Cache-Control": "no-store"})


@app.post("/api/signal/backtest")
async def signal_backtest_start(request: Request):
    """Mulai/hentikan backtest (admin saja). Body: {action:"start", mode, be, start, end, pairs?} atau {action:"stop"}."""
    if getattr(request.state, "role", None) != auth.ADMIN:
        return JSONResponse({"error": "hanya admin yang boleh menjalankan backtest"}, status_code=403)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "isi permintaan bukan JSON yang valid"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "isi permintaan harus objek JSON"}, status_code=400)
    from .signals import backtest as bt
    try:
        act = body.get("action")
        if act == "stop":
            return JSONResponse({"ok": True, "status": bt.stop()}, headers={"Cache-Control": "no-store"})
        if act != "start":
            return JSONResponse({"error": "action harus 'start' atau 'stop'"}, status_code=422)
        pairs = body.get("pairs")
        if pairs is not None and not isinstance(pairs, list):
            return JSONResponse({"error": "pairs harus daftar simbol"}, status_code=422)
        st = bt.start(body.get("mode", "swing"), body.get("start"), body.get("end"), bool(body.get("be", True)), pairs)
        return JSONResponse({"ok": True, "status": st}, headers={"Cache-Control": "no-store"})
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)


@app.get("/api/{path:path}")
async def api_route(path: str, request: Request):
    if path not in S.ENDPOINTS:
        return JSONResponse({"error": "endpoint tidak dikenal"}, status_code=404)
    role = getattr(request.state, "role", auth.USER)
    if path in ADMIN_ONLY and role != auth.ADMIN:
        return JSONResponse({"error": "hanya untuk admin"}, status_code=403)
    try:
        body, how = await S.serve(path, dict(request.query_params))
    except S.ParamError as exc:
        return JSONResponse({"error": str(exc)}, status_code=422)
    if path == "rev" and role != auth.ADMIN:     # jumlah sumber bermasalah hanya untuk admin
        try:
            d = json.loads(body)
            d["bad"] = 0
            body = json.dumps(d, separators=(",", ":")).encode("utf-8")
        except Exception:
            pass
    return Response(body, media_type="application/json", headers={"X-Snapshot": how, "Cache-Control": "no-store"})


config.WEB_DIR.mkdir(parents=True, exist_ok=True)


@app.get("/")
async def index():
    return FileResponse(config.WEB_DIR / "index.html")


app.mount("/", StaticFiles(directory=str(config.WEB_DIR)), name="web")
