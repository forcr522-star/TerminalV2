"""Jalur komputasi berat (CPU) dengan SATU thread pekerja.

Python hanya menjalankan satu thread pada satu waktu (GIL). Bila banyak thread latar menghitung bersamaan (analisa sinyal,
backfill, model likuidasi, katalis berita), thread event loop - yang melayani website, API, tunnel - harus antre GIL
di belakang semuanya dan server "macet" (PING tinggi, Cloudflare "Host Error"). Semua pekerjaan berat lewat jalur ini
sehingga paling banyak SATU thread komputasi yang bersaing dengan event loop; pekerjaan I/O (database, berkas) tetap
memakai asyncio.to_thread biasa.
"""
import asyncio
import concurrent.futures
import functools

_pool = None


def _executor():
    global _pool
    if _pool is None:
        _pool = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="cpu")
    return _pool


async def run(fn, *args, **kwargs):
    """await cpu.run(fungsi, ...) - seperti asyncio.to_thread, tetapi antre di jalur komputasi tunggal."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_executor(), functools.partial(fn, *args, **kwargs))


# ------------------------------------------------------------------------------------------- jalur PARSE (RSS, CSV, JSON besar)
# Parser berita/CSV/JSON adalah kerja CPU murni (memegang GIL). Dulu lewat asyncio.to_thread -> executor bawaan yang
# sekarang 64 thread (diperbesar agar DNS tidak antre, lihat terminal/threads.py): saat preload, puluhan parser bisa
# berjalan BERSAMAAN dan thread event loop kalah berebut GIL ("[watchdog] server tertahan ... _poll"). Jalur ini
# membatasi parser menjadi PARSE_THREADS thread; executor bawaan tetap untuk I/O yang memblokir (DNS, berkas).
import os as _os

PARSE_THREADS = max(1, int(_os.getenv("PARSE_THREADS", "2") or 2))
_parse_pool = None


def _parse_executor():
    global _parse_pool
    if _parse_pool is None:
        _parse_pool = concurrent.futures.ThreadPoolExecutor(max_workers=PARSE_THREADS, thread_name_prefix="parse")
    return _parse_pool


async def parse(fn, *args, **kwargs):
    """await cpu.parse(fungsi, ...) - untuk mengurai respons sumber data (paling banyak PARSE_THREADS bersamaan)."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_parse_executor(), functools.partial(fn, *args, **kwargs))
