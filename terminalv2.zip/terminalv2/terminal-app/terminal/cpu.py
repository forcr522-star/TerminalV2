"""Jalur komputasi berat (CPU) dengan SATU thread pekerja.

Python hanya menjalankan satu thread pada satu waktu (GIL). Bila banyak thread latar menghitung bersamaan (analisa sinyal,
backfill, model likuidasi, katalis berita), thread event loop - yang melayani website, API, tunnel - harus antre GIL
di belakang semuanya dan server "macet" (PING tinggi, Cloudflare "Host Error"). Semua pekerjaan berat lewat jalur ini
sehingga paling banyak SATU thread komputasi yang bersaing dengan event loop; pekerjaan I/O (database, berkas) tetap
memakai asyncio.to_thread biasa.
"""
import asyncio
import concurrent.futures
import functools

_pool = None


def _executor():
    global _pool
    if _pool is None:
        _pool = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="cpu")
    return _pool


async def run(fn, *args, **kwargs):
    """await cpu.run(fungsi, ...) - seperti asyncio.to_thread, tetapi antre di jalur komputasi tunggal."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_executor(), functools.partial(fn, *args, **kwargs))
