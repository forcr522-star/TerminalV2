"""Model LIQUIDATION HEATMAP (gaya CoinGlass) dihitung sendiri dari candle Binance - tanpa API pihak ketiga.

Peta likuidasi CoinGlass & sejenisnya adalah MODEL, bukan data yang diamati: memperkirakan di harga mana posisi
berleverage akan terlikuidasi. Model di sini transparan dan seluruhnya dari data candle (OHLC, volume, volume taker beli):

  Untuk setiap candle i (urut waktu, hanya memakai data <= i -> tanpa kebocoran masa depan):
    1. SAPU   : level long dengan harga >= low candle dan level short dengan harga <= high candle dianggap
                terlikuidasi -> dihapus (dicatat sebagai "liquidated"). Hanya level dari candle SEBELUMNYA.
    2. LURUH  : posisi ditutup sukarela seiring waktu -> semua level x 0,5^(1/HALF_LIFE) (paruh = HALF_LIFE candle TF itu).
    3. BUKA   : posisi baru = volume quote x OPEN_RATIO di harga tipikal (H+L+C)/3.
                Porsi long = volume taker beli / volume; short = sisanya.
                Tiap posisi disebar ke tingkatan leverage (TIERS); harga likuidasi:
                    long  = P x (1 - 1/lev + MMR)      short = P x (1 + 1/lev - MMR)
  Kolom heatmap candle i = level yang masih aktif (belum tersapu) setelah candle i.

Karena memakai candle TF itu sendiri, peta tiap timeframe berbeda: M1 berisi level leverage tinggi dekat harga dengan nilai
kecil; H4/D1 menjumlah volume jauh lebih besar dan jangkauan lebih lebar. Nilai USDT adalah ESTIMASI model.
"""
import math
import os

import numpy as np


def _tiers():
    raw = os.getenv("HEATMAP_LIQ_TIERS", "").strip()     # contoh: "5:0.1,10:0.25,25:0.3,50:0.2,100:0.15"
    if raw:
        try:
            out = [(float(a), float(b)) for a, b in (x.split(":") for x in raw.split(","))]
            tot = sum(w for _, w in out)
            if out and tot > 0 and all(lv > 1 for lv, _ in out):
                return tuple((lv, w / tot) for lv, w in out)
        except ValueError:
            pass
    return ((5.0, 0.10), (10.0, 0.25), (25.0, 0.30), (50.0, 0.20), (100.0, 0.15))


TIERS = _tiers()
MMR = float(os.getenv("HEATMAP_LIQ_MMR", "0.004"))                   # maintenance margin rate (Binance tier awal ±0,4%)
OPEN_RATIO = float(os.getenv("HEATMAP_LIQ_OPEN_RATIO", "0.10"))      # porsi volume yang dianggap membuka posisi berleverage
HALF_LIFE = max(4.0, float(os.getenv("HEATMAP_LIQ_HALFLIFE", "96")))  # paruh umur posisi, dalam candle TF yang dipakai


def liq_prices(p):
    """Harga likuidasi (long, short) per tingkatan leverage untuk posisi di harga p."""
    return [(p * (1 - 1 / lv + MMR), p * (1 + 1 / lv - MMR), w) for lv, w in TIERS]


class State:
    """Level aktif per baris harga (ukuran r, baris k = harga [k*r, (k+1)*r)), mulai baris k0."""
    __slots__ = ("r", "k0", "long", "short")

    def __init__(self, r, k0, n):
        self.r, self.k0 = r, k0
        self.long = np.zeros(n, dtype=np.float64)     # likuidasi long (di BAWAH harga saat dibuka)
        self.short = np.zeros(n, dtype=np.float64)    # likuidasi short (di ATAS harga saat dibuka)

    def copy(self):
        s = State(self.r, self.k0, len(self.long))
        s.long[:], s.short[:] = self.long, self.short
        return s


def step(st, c, decay):
    """Proses satu candle [t, o, h, l, c, vol_quote, taker_buy_quote]. Mengembalikan (liq_long, liq_short) yang tersapu."""
    _, _, hi, lo, cl, qv, tbq = c[:7]
    n, r, k0 = len(st.long), st.r, st.k0
    # 1) sapu: level yang dilewati harga candle ini (hanya level dari candle sebelumnya)
    kl = int(math.floor(lo / r)) - k0
    kh = int(math.floor(hi / r)) - k0
    a = max(0, min(n, kl))
    liq_l = float(st.long[a:].sum())
    st.long[a:] = 0.0
    b = max(0, min(n, kh + 1))
    liq_s = float(st.short[:b].sum())
    st.short[:b] = 0.0
    # 2) luruh
    st.long *= decay
    st.short *= decay
    # 3) posisi baru di harga tipikal
    if qv and qv > 0:
        p = (hi + lo + cl) / 3.0
        new = qv * OPEN_RATIO
        buy = min(1.0, max(0.0, tbq / qv))
        for pl, ps, w in liq_prices(p):
            i = int(math.floor(pl / r)) - k0
            if 0 <= i < n:
                st.long[i] += new * buy * w
            j = int(math.floor(ps / r)) - k0
            if 0 <= j < n:
                st.short[j] += new * (1 - buy) * w
    return liq_l, liq_s


def run(candles, r, k0, n, keep_from=0):
    """Jalankan model atas semua candle. Mengembalikan (state akhir, {t: kolom float32 aktif} untuk candle index >= keep_from, hits)."""
    st = State(r, k0, n)
    decay = 0.5 ** (1.0 / HALF_LIFE)
    cols, hits = {}, []
    for i, c in enumerate(candles):
        hl = step(st, c, decay)
        hits.append((int(c[0]), hl[0], hl[1]))
        if i >= keep_from:
            cols[int(c[0])] = (st.long + st.short).astype(np.float32)
    return st, cols, hits
