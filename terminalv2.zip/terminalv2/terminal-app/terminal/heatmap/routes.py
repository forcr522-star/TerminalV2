"""Endpoint /api/heatmap/... (didaftarkan ke mesin snapshot sebagai store=False: selalu data langsung dari kolektor).

  heatmap/pairs      (admin & user) pair yang dipantau + harga / perubahan 24 jam
  heatmap/view       (admin & user) data penuh satu chart (candle, heatmap, bubble, liquidity map, key level, overview)
  heatmap/live       (admin & user) pembaruan kecil tiap ±1 dtk (candle berjalan, kolom heat terbaru, orderbook)
  heatmap/footprint  (admin & user) footprint candle yang terlihat saat chart di-zoom
  heatmap/control    (ADMIN SAJA)   katalog pair, pilihan admin, status kolektor
Pengubahan pilihan pair: POST /api/heatmap/control (admin saja, lihat server.py).
"""
from .. import snapshots as S
from . import view

ADMIN_ONLY = {"heatmap/control"}


@S.endpoint("heatmap/pairs", store=False, group="HEATMAP")
async def heatmap_pairs():
    return await view.pairs_payload()


@S.endpoint("heatmap/view", store=False, group="HEATMAP")
async def heatmap_view(symbol: str, tf: str = "M5", bars: int = 300):
    return await view.view_payload(symbol, tf, bars)


@S.endpoint("heatmap/live", store=False, group="HEATMAP")
async def heatmap_live(symbol: str, tf: str, since: int, row: float, k0: int, nrows: int, bars: int = 300, fp: int = 0):
    return await view.live_payload(symbol, tf, since, row, k0, nrows, bars, fp)


@S.endpoint("heatmap/footprint", store=False, group="HEATMAP")
async def heatmap_footprint(symbol: str, tf: str, t0: int, t1: int, m: int = 1):
    return await view.footprint_payload(symbol, tf, t0, t1, m)


@S.endpoint("heatmap/control", store=False, group="HEATMAP")
async def heatmap_control():
    return await view.control_payload()
