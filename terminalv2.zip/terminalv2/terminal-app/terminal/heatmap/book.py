"""Bucket harga untuk footprint & heatmap: ukuran bucket "bagus" (kelipatan tick) dan indeks bucket absolut.

(Orderbook lokal - snapshot + diff, sinkronisasi - dulu ada di sini untuk mode ORDERBOOK; mode itu sudah dihapus.)
"""
import math


def nice_step(x, tick):
    """Ukuran bucket 'bulat' (1/2/5 x 10^k) terdekat ke x, minimal satu tick."""
    if not x or x <= 0 or not math.isfinite(x):
        return tick
    e = math.floor(math.log10(x))
    best = None
    for k in (e - 1, e, e + 1):
        for m in (1, 2, 5):
            v = m * 10 ** k
            if best is None or abs(math.log(v / x)) < abs(math.log(best / x)):
                best = v
    best = max(best, tick)
    # bulatkan ke kelipatan tick (tick Binance = 10^-n) dan hilangkan noise float
    n = round(best / tick)
    return float(f"{max(1, n) * tick:.12g}")


def bidx(price, b):
    """Indeks bucket absolut: bucket k mencakup harga [k*b, (k+1)*b)."""
    return int(math.floor(price / b + 1e-9))
