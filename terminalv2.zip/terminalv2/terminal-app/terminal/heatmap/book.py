"""Orderbook lokal Binance Spot (snapshot REST + diff WebSocket), sesuai prosedur resmi Binance:

  1. Buka stream <symbol>@depth dan tampung event.
  2. Ambil snapshot GET /api/v3/depth (lastUpdateId = L).
  3. Buang event dengan u <= L. Event pertama yang dipakai wajib U <= L+1 <= u.
  4. Setelah itu setiap event wajib U == u_sebelumnya + 1. Bila tidak -> ada event hilang -> sinkron ulang.
  5. qty 0 = level dihapus.

Selain level mentah, buku menyimpan jumlah NOTIONAL (harga x qty, dalam USDT) per bucket harga secara inkremental,
sehingga pencuplikan heatmap tiap beberapa detik cukup membaca dict kecil, bukan mengulang ribuan level.

`cov_lo`/`cov_hi` = cakupan snapshot. Di luar rentang itu Binance tidak mengirim level lama yang tidak berubah, jadi
heatmap hanya dicuplik di dalam cakupan (tidak ada likuiditas "palsu kosong" di luar jangkauan snapshot).
"""
import math


class SyncError(Exception):
    """Urutan event depth putus: buku harus disinkron ulang dari snapshot."""


def nice_step(x, tick):
    """Ukuran bucket 'bulat' (1/2/5 x 10^k) terdekat ke x, minimal satu tick."""
    if not x or x <= 0 or not math.isfinite(x):
        return tick
    e = math.floor(math.log10(x))
    best = None
    for k in (e - 1, e, e + 1):
        for m in (1, 2, 5):
            v = m * 10 ** k
            if best is None or abs(math.log(v / x)) < abs(math.log(best / x)):
                best = v
    best = max(best, tick)
    # bulatkan ke kelipatan tick (tick Binance = 10^-n) dan hilangkan noise float
    n = round(best / tick)
    return float(f"{max(1, n) * tick:.12g}")


def bidx(price, b):
    """Indeks bucket absolut: bucket k mencakup harga [k*b, (k+1)*b)."""
    return int(math.floor(price / b + 1e-9))


class Book:
    __slots__ = ("b", "bids", "asks", "bb", "ab", "last_u", "cov_lo", "cov_hi", "w_lo0", "w_hi0", "synced_at", "updates")

    def __init__(self, b):
        self.b = b
        self.bids, self.asks = {}, {}          # harga -> qty
        self.bb, self.ab = {}, {}              # indeks bucket -> notional USDT (bid / ask)
        self.last_u = None
        self.cov_lo, self.cov_hi = 0.0, math.inf
        self.w_lo0 = self.w_hi0 = 0.0
        self.synced_at = 0.0
        self.updates = 0

    # ------------------------------------------------------------------------------------------ dasar
    def _set(self, side, agg, price, qty):
        old = side.get(price, 0.0)
        if qty <= 0:
            if price in side:
                del side[price]
        else:
            side[price] = qty
        d = (qty - old) * price
        if d:
            k = bidx(price, self.b)
            v = agg.get(k, 0.0) + d
            if v <= 1e-9:
                agg.pop(k, None)
            else:
                agg[k] = v

    def load_snapshot(self, snap, limit):
        """Isi buku dari respons /api/v3/depth. Cakupan: sisi yang terpotong limit hanya valid sampai level terakhirnya."""
        self.bids.clear(); self.asks.clear(); self.bb.clear(); self.ab.clear()
        bids = [(float(p), float(q)) for p, q in snap.get("bids", [])]
        asks = [(float(p), float(q)) for p, q in snap.get("asks", [])]
        for p, q in bids:
            self._set(self.bids, self.bb, p, q)
        for p, q in asks:
            self._set(self.asks, self.ab, p, q)
        self.cov_lo = min(p for p, _ in bids) if bids and len(bids) >= limit else 0.0
        self.cov_hi = max(p for p, _ in asks) if asks and len(asks) >= limit else math.inf
        self.last_u = int(snap["lastUpdateId"])
        m = self.mid()
        self.w_lo0 = (m - self.cov_lo) if m and self.cov_lo > 0 else 0.0
        self.w_hi0 = (self.cov_hi - m) if m and math.isfinite(self.cov_hi) else 0.0

    def apply(self, ev):
        """Terapkan satu event diff (dict dengan U, u, b, a). Mengembalikan False bila event lama (diabaikan)."""
        U, u = int(ev["U"]), int(ev["u"])
        if self.last_u is None:
            raise SyncError("buku belum punya snapshot")
        if u <= self.last_u:
            return False
        if U > self.last_u + 1:
            raise SyncError(f"event hilang: U={U} > last_u+1={self.last_u + 1}")
        for p, q in ev.get("b", ()):
            self._set(self.bids, self.bb, float(p), float(q))
        for p, q in ev.get("a", ()):
            self._set(self.asks, self.ab, float(p), float(q))
        self.last_u = u
        self.updates += 1
        return True

    # ------------------------------------------------------------------------------------------ baca
    def best(self):
        bb = max(self.bids) if self.bids else None
        ba = min(self.asks) if self.asks else None
        return bb, ba

    def mid(self):
        bb, ba = self.best()
        if bb is None or ba is None:
            return bb or ba
        return (bb + ba) / 2

    def window(self, mid, rng):
        """Rentang harga yang boleh dicuplik: ±rng dari mid, dipotong cakupan snapshot."""
        return max(self.cov_lo, mid * (1 - rng)), min(self.cov_hi, mid * (1 + rng))

    def buckets(self, lo, hi):
        """Notional per bucket (bid + ask) di dalam [lo, hi]. Mengembalikan dict indeks -> (bid, ask)."""
        klo, khi = bidx(lo, self.b), bidx(hi, self.b)
        out = {}
        for k, v in self.bb.items():
            if klo <= k <= khi:
                out[k] = [v, 0.0]
        for k, v in self.ab.items():
            if klo <= k <= khi:
                cur = out.get(k)
                if cur is None:
                    out[k] = [0.0, v]
                else:
                    cur[1] = v
        return out

    def prune(self, mid, keep):
        """Buang level di luar ±keep dari mid (menjaga memori tetap kecil pada sesi panjang)."""
        lo, hi = mid * (1 - keep), mid * (1 + keep)
        for side, agg in ((self.bids, self.bb), (self.asks, self.ab)):
            far = [p for p in side if p < lo or p > hi]
            for p in far:
                self._set(side, agg, p, 0.0)
        self.cov_lo = max(self.cov_lo, lo)
        self.cov_hi = min(self.cov_hi, hi)

    def near_edge(self, mid, frac=0.5):
        """True bila harga sudah menempuh > frac jarak ke tepi cakupan snapshot (sisi yang terpotong limit).
        Level di luar cakupan tidak diketahui, jadi snapshot baru diambil sebelum harga mendekati tepinya."""
        if self.cov_lo > 0 and self.w_lo0 > 0 and mid - self.cov_lo < (1 - frac) * self.w_lo0:
            return True
        if math.isfinite(self.cov_hi) and self.w_hi0 > 0 and self.cov_hi - mid < (1 - frac) * self.w_hi0:
            return True
        return False


def build_synced(snap, limit, b, events):
    """Bangun buku dari snapshot + event yang ditampung sejak stream dibuka (langkah 3-4 prosedur Binance).

    Mengembalikan Book yang sudah sinkron. SyncError bila snapshot terlalu baru/lama dibanding event yang ada.
    """
    book = Book(b)
    book.load_snapshot(snap, limit)
    L = book.last_u
    first = True
    for ev in events:
        U, u = int(ev["U"]), int(ev["u"])
        if u <= L:
            continue
        if first:
            if not (U <= L + 1 <= u):
                raise SyncError(f"event pertama tidak menyambung snapshot (U={U}, u={u}, L={L})")
            first = False
        book.apply(ev)
    return book
