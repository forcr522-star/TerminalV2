"""Menu HEATMAP & FOOTPRINT: heatmap likuidasi (model gaya CoinGlass), footprint, big trade, liquidation map (kripto, Binance Spot)."""
