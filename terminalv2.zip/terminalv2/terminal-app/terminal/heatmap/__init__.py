"""Menu HEATMAP & FOOTPRINT: heatmap orderbook, footprint, big order, liquidity map (kripto, Binance Spot)."""
