"""Penyimpanan heatmap, footprint, dan big order di SQLite (data/terminal.db, tabel hm_*).

Satu baris hm_col = satu kolom waktu (1 menit untuk lvl 1, 1 jam untuk lvl 2) untuk satu pair:
  heat : rata-rata waktu notional limit order (bid+ask, USDT) per bucket harga selama kolom itu
  fp   : footprint = notional trade agresif BELI dan JUAL per bucket harga selama kolom itu
Nilai dikodekan log2 16-bit (presisi relatif ±0,14%) lalu dikompres zlib: ±1 KB per kolom.

Kolom yang sudah ditutup TIDAK pernah ditulis ulang -> tampilan historis tidak berubah (no repaint).
"""
import threading
import zlib

import numpy as np

from .. import store

Q = 256.0
_ready = False
_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS hm_col(
    sym TEXT, lvl INTEGER, ts INTEGER, b REAL, i0 INTEGER, n INTEGER, heat BLOB, fi0 INTEGER, fp BLOB,
    PRIMARY KEY(sym, lvl, ts)
);
CREATE TABLE IF NOT EXISTS hm_big(sym TEXT, ts INTEGER, price REAL, usd REAL, side INTEGER);
CREATE INDEX IF NOT EXISTS ix_hm_big ON hm_big(sym, ts);
CREATE TABLE IF NOT EXISTS hm_bigh(sym TEXT, ts INTEGER, price REAL, usd REAL, side INTEGER, n INTEGER);
CREATE INDEX IF NOT EXISTS ix_hm_bigh ON hm_bigh(sym, ts);
"""


def ensure():
    global _ready
    if _ready:
        return
    with _lock:
        if _ready:
            return
        with store._lock:
            store.conn().executescript(SCHEMA)
            store.conn().commit()
        _ready = True


class Col:
    """Satu kolom: heat[i] = bucket (i0 + i), fp[0]/fp[1] = beli/jual untuk bucket (fi0 + i). Ukuran bucket = b."""
    __slots__ = ("b", "i0", "n", "heat", "fi0", "fp")

    def __init__(self, b, i0, n, heat, fi0=0, fp=None):
        self.b, self.i0, self.n, self.heat, self.fi0, self.fp = b, i0, n, heat, fi0, fp


def enc(arr):
    q = np.clip(np.rint(np.log2(1.0 + np.maximum(np.asarray(arr, dtype=np.float64), 0.0)) * Q), 0, 65535).astype("<u2")
    return zlib.compress(q.tobytes(), 6)


def dec(blob):
    if not blob:
        return np.zeros(0, dtype=np.float64)
    q = np.frombuffer(zlib.decompress(blob), dtype="<u2").astype(np.float64)
    return np.exp2(q / Q) - 1.0


def dense(d, mult=1):
    """dict {indeks: nilai} -> (i0, array padat). mult: bagi nilai dengan jumlah sampel (rata-rata)."""
    if not d:
        return 0, np.zeros(0, dtype=np.float64)
    ks = np.fromiter(d.keys(), dtype=np.int64, count=len(d))
    vs = np.fromiter(d.values(), dtype=np.float64, count=len(d))
    i0 = int(ks.min())
    out = np.zeros(int(ks.max()) - i0 + 1, dtype=np.float64)
    np.add.at(out, ks - i0, vs)
    if mult != 1:
        out /= mult
    return i0, out


def _trim(i0, arr):
    nz = np.nonzero(arr > 0.5)[0]
    if not len(nz):
        return 0, arr[:0]
    return i0 + int(nz[0]), arr[nz[0]:nz[-1] + 1]


def pack(col):
    hi0, heat = _trim(col.i0, col.heat) if col.heat is not None else (0, np.zeros(0))
    fi0, fpb, fps = 0, None, None
    if col.fp is not None and col.fp.shape[1]:
        tot = col.fp[0] + col.fp[1]
        nz = np.nonzero(tot > 0)[0]
        if len(nz):
            a, z = nz[0], nz[-1] + 1
            fi0 = col.fi0 + int(a)
            fpb, fps = col.fp[0][a:z], col.fp[1][a:z]
    fp_blob = enc(np.concatenate([fpb, fps])) if fpb is not None else None
    return hi0, (enc(heat) if len(heat) else None), fi0, fp_blob


def unpack(b, i0, n, heat, fi0, fp):
    h = dec(heat) if heat else np.zeros(0)
    f = None
    if fp:
        v = dec(fp)
        m = len(v) // 2
        f = np.vstack([v[:m], v[m:]])
    return Col(b, i0, n, h, fi0 or 0, f)


# ------------------------------------------------------------------------------------------------ tulis / baca
def put_cols(rows):
    """rows: [(sym, lvl, ts, Col)]"""
    if not rows:
        return
    ensure()
    out = []
    for sym, lvl, ts, col in rows:
        hi0, hb, fi0, fb = pack(col)
        out.append((sym, lvl, int(ts), float(col.b), hi0, int(col.n), hb, fi0, fb))
    store.executemany("INSERT OR REPLACE INTO hm_col(sym,lvl,ts,b,i0,n,heat,fi0,fp) VALUES(?,?,?,?,?,?,?,?,?)", out)


def get_cols(sym, lvl, t0, t1):
    """Kolom dengan t0 <= ts < t1 -> {ts: Col}."""
    ensure()
    rows = store.query("SELECT ts,b,i0,n,heat,fi0,fp FROM hm_col WHERE sym=? AND lvl=? AND ts>=? AND ts<? ORDER BY ts", (sym, lvl, int(t0), int(t1)))
    return {r["ts"]: unpack(r["b"], r["i0"], r["n"], r["heat"], r["fi0"], r["fp"]) for r in rows}


def first_ts(sym):
    ensure()
    rows = store.query("SELECT MIN(ts) AS t FROM hm_col WHERE sym=? AND lvl=1", (sym,))
    return rows[0]["t"] if rows and rows[0]["t"] is not None else None


def add_big(rows):
    """rows: [(sym, ts_ms, price, usd, side)]"""
    if rows:
        ensure()
        store.executemany("INSERT INTO hm_big(sym,ts,price,usd,side) VALUES(?,?,?,?,?)", rows)


def get_big(sym, t0_ms, t1_ms):
    ensure()
    return [(r["ts"], r["price"], r["usd"], r["side"]) for r in
            store.query("SELECT ts,price,usd,side FROM hm_big WHERE sym=? AND ts>=? AND ts<? ORDER BY ts", (sym, int(t0_ms), int(t1_ms)))]


def add_bigh(rows):
    """rows: [(sym, ts_hour, price, usd, side, n)] - klaster big order per jam (dipakai H1..D1)."""
    if rows:
        ensure()
        store.executemany("INSERT INTO hm_bigh(sym,ts,price,usd,side,n) VALUES(?,?,?,?,?,?)", rows)


def get_bigh(sym, t0, t1):
    ensure()
    return [(r["ts"], r["price"], r["usd"], r["side"], r["n"]) for r in
            store.query("SELECT ts,price,usd,side,n FROM hm_bigh WHERE sym=? AND ts>=? AND ts<? ORDER BY ts", (sym, int(t0), int(t1)))]


def prune(now, l1_days, l2_days, majors=None):
    """majors: {sym: USDT} - big trade >= nilai ini disimpan l2_days (riwayat H1..D1), sisanya l1_days."""
    ensure()
    store.execute("DELETE FROM hm_col WHERE lvl=1 AND ts<?", (int(now - l1_days * 86400),))
    store.execute("DELETE FROM hm_col WHERE lvl=2 AND ts<?", (int(now - l2_days * 86400),))
    cut1, cut2 = int((now - l1_days * 86400) * 1000), int((now - l2_days * 86400) * 1000)
    store.execute("DELETE FROM hm_big WHERE ts<?", (cut2,))
    majors = {k: float(v) for k, v in (majors or {}).items() if v and v > 0}
    for sym, m in majors.items():
        store.execute("DELETE FROM hm_big WHERE sym=? AND ts<? AND usd<?", (sym, cut1, m))
    if majors:
        store.execute("DELETE FROM hm_big WHERE ts<? AND sym NOT IN (%s)" % ",".join("?" * len(majors)), (cut1, *majors))
    else:
        store.execute("DELETE FROM hm_big WHERE ts<?", (cut1,))
    store.execute("DELETE FROM hm_bigh WHERE ts<?", (int(now - l2_days * 86400),))
