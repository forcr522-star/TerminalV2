"""Pilihan pair HEATMAP & FOOTPRINT (hanya admin yang boleh mengubah). Disimpan di database (tabel kv).

pairs : pair yang dipantau. Hanya pair ini yang:
        - punya koneksi WebSocket Binance (orderbook, trade, candle) dan permintaan REST,
        - bisa dibuka di chart oleh admin maupun user.
        Pair di luar daftar TIDAK dipantau sama sekali dan permintaan datanya ditolak server.
"""
import copy
import threading

from .. import store
from .settings import CATALOG_SYMS

KEY = "hm_control"
_lock = threading.RLock()
_state = None
_listeners = []


def _defaults():
    return dict(pairs=list(CATALOG_SYMS), rev=0)


def canon_pairs(pairs):
    if not isinstance(pairs, (list, tuple)):
        raise ValueError("pairs harus berupa daftar simbol")
    out, bad = [], []
    for p in pairs:
        s = str(p).strip().upper()
        if s not in CATALOG_SYMS:
            bad.append(str(p))
        elif s not in out:
            out.append(s)
    if bad:
        raise ValueError("pair tidak tersedia untuk heatmap: " + ", ".join(bad[:8]) + " (pilihan: " + ", ".join(CATALOG_SYMS) + ")")
    return [s for s in CATALOG_SYMS if s in out]     # urutan tetap seperti katalog


def _clean(raw):
    st = _defaults()
    if isinstance(raw, dict):
        if isinstance(raw.get("pairs"), list):
            st["pairs"] = [s for s in CATALOG_SYMS if s in {str(x).upper() for x in raw["pairs"]}]
        if isinstance(raw.get("rev"), int):
            st["rev"] = raw["rev"]
    return st


def reload():
    global _state
    with _lock:
        try:
            raw = store.kv_get(KEY)
        except Exception:
            raw = None
        _state = _clean(raw)
        return copy.deepcopy(_state)


def get():
    with _lock:
        if _state is None:
            reload()
        return copy.deepcopy(_state)


def selected():
    return list(get()["pairs"])


def is_selected(sym):
    return str(sym).upper() in get()["pairs"]


def on_change(fn):
    """Daftarkan fungsi yang dipanggil setelah pilihan berubah (dipakai kolektor untuk start/stop pemantauan)."""
    _listeners.append(fn)


def update(pairs=None):
    global _state
    with _lock:
        cur = get()
        new = dict(cur)
        if pairs is not None:
            new["pairs"] = canon_pairs(pairs)
        changed = new["pairs"] != cur["pairs"]
        if changed:
            new["rev"] = cur["rev"] + 1
            _state = new
            store.kv_set(KEY, new)
    if changed:
        for fn in list(_listeners):
            try:
                fn(copy.deepcopy(new))
            except Exception:
                pass
    return copy.deepcopy(new)
