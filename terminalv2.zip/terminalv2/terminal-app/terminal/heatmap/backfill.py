"""Isi RIWAYAT big trade & footprint dari arsip trade publik Binance (tanpa API key).

Kolektor live hanya merekam sejak terminal berjalan, sehingga bubble & footprint di candle lama kosong. Modul ini mengisi
BACKFILL_DAYS hari terakhir (bawaan 30) dari data trade yang sebenarnya (bukan estimasi):
  - hari yang sudah lewat : arsip harian  data.binance.vision/data/spot/daily/aggTrades/<SYM>/<SYM>-aggTrades-<tgl>.zip
                            (satu file berisi SEMUA aggTrade hari itu; BTC ±27 MB per hari)
  - hari ini              : REST /api/v3/aggTrades per jam, dari 00:00 UTC sampai saat terminal mulai merekam (juga
                            menambal jeda saat terminal mati; arsip kemarin yang belum terbit juga lewat REST)
Dari setiap trade: order taker (aggTrade dengan waktu & sisi sama) -> big trade (>= persentil 99,5 hari itu), dan
footprint beli/jual per menit & per jam per bucket harga. Hari di luar retensi L1 (bawaan 7 hari; M1..M30 hanya memuat
±6 hari) cukup disimpan footprint per jam + big trade >= ambang H1 - itulah yang tampil di H1, H4, D1.
Urutan selalu TERBARU dulu & bergiliran antar pair: jam terakhir hari ini untuk semua pair, lalu jam sebelumnya, ...,
lalu arsip kemarin semua pair, dst. Kemajuan disimpan (kv hm_bf_<SYM>: hari arsip selesai + interval REST tercakup);
bersama rentang rekaman live sesi lalu, restart hanya mengunduh celah yang benar-benar belum ada. Data hanya ditulis
untuk waktu SEBELUM sesi ini mulai merekam, jadi tidak pernah bertabrakan dengan rekaman live.
"""
import asyncio
import datetime as dt
import io
import os
import time
import traceback
import zipfile

import numpy as np

from .. import cpu, http as H, store
from . import settings as C, db, binance as B
from .book import bidx
from .db import Col

DAYS = max(0, min(365, int(os.getenv("HEATMAP_BACKFILL_DAYS", "30") or 0)))
ZIP_URL = "https://data.binance.vision/data/spot/daily/aggTrades/{s}/{s}-aggTrades-{d}.zip"
REST_PAUSE = 0.1           # detik antar permintaan REST (bobot 2; maks. ±1000 weight/menit = ±17% batas Binance 6000)
STORE_PCTL = 99.5


# ------------------------------------------------------------------------------------------------ parsing & olah
# Trade disimpan sebagai array kolom (numpy) - satu hari BTC ±1,8 juta aggTrade; diolah tervektor supaya cepat & hemat RAM.
def _empty():
    return dict(T=np.zeros(0, np.int64), p=np.zeros(0), q=np.zeros(0), mk=np.zeros(0, bool))


def read_csv(f):
    """CSV aggTrades Binance (file/stream) -> {T ms, p, q, mk (buyer is maker)}. Header opsional; waktu mikro- atau milidetik."""
    import pandas as pd
    head = f.peek(64)[:1] if hasattr(f, "peek") else b""
    if not head:
        data = f.read()
        data = data.encode() if isinstance(data, str) else data
        head, f = data[:1], io.BytesIO(data)
    df = pd.read_csv(f, header=None, skiprows=0 if head.isdigit() else 1, usecols=[1, 2, 5, 6], names=list(range(8)),
                     dtype={1: np.float64, 2: np.float64, 5: np.int64}, true_values=["True", "true"], false_values=["False", "false"])
    if not len(df):
        return _empty()
    T = df[5].to_numpy(np.int64)
    T = np.where(T > 10 ** 14, T // 1000, T)  # sejak 2025 arsip spot memakai mikrodetik
    return dict(T=T, p=df[1].to_numpy(np.float64), q=df[2].to_numpy(np.float64), mk=df[6].to_numpy(bool))


def parse_csv(text):
    return read_csv(io.BytesIO(text.encode()))


def rest_rows(raw):
    return [(int(r["T"]), float(r["p"]), float(r["q"]), bool(r["m"])) for r in raw]


def as_arrays(trades):
    if isinstance(trades, dict):
        return trades
    if not trades:
        return _empty()
    T, p, q, mk = zip(*trades)
    return dict(T=np.array(T, np.int64), p=np.array(p, float), q=np.array(q, float), mk=np.array(mk, bool))


def n_trades(trades):
    return len(trades["T"]) if isinstance(trades, dict) else len(trades or ())


def _cells(ts, k, usd, buy):
    """Jumlah USDT beli/jual per (ts, k) -> {ts: {k: [beli, jual]}}."""
    out = {}
    if not len(ts):
        return out
    kk = k - k.min()
    key = ts.astype(np.int64) * (int(kk.max()) + 1) + kk
    uk, inv = np.unique(key, return_inverse=True)
    bs = np.bincount(inv, weights=np.where(buy, usd, 0.0), minlength=len(uk))
    ss = np.bincount(inv, weights=np.where(buy, 0.0, usd), minlength=len(uk))
    first = np.zeros(len(uk), np.int64)
    first[inv[::-1]] = np.arange(len(inv))[::-1]   # indeks pertama tiap kunci
    for t, kv, bu, se in zip(ts[first].tolist(), k[first].tolist(), bs.tolist(), ss.tolist()):
        out.setdefault(t, {})[kv] = [bu, se]
    return out


def process(trades, b, t_end_ms):
    """Trade (urut waktu) sebelum t_end_ms -> (order taker array [[T, vwap, usd, sisi]], fp menit {ts: {k: [beli, jual]}}, fp jam).
    Satu order taker = aggTrade berurutan dengan waktu (T) & sisi sama (order market yang menyapu beberapa level)."""
    a = as_arrays(trades)
    n = int(np.searchsorted(a["T"], t_end_ms, side="left")) if len(a["T"]) and np.all(a["T"][1:] >= a["T"][:-1]) else None
    sel = slice(0, n) if n is not None else (a["T"] < t_end_ms)
    T, p, q, mk = a["T"][sel], a["p"][sel], a["q"][sel], a["mk"][sel]
    if not len(T):
        return np.zeros((0, 4)), {}, {}
    usd = p * q
    buy = ~mk
    k = np.floor(p / b + 1e-9).astype(np.int64)
    fp1 = _cells(T // 60000 * 60, k, usd, buy)
    fp2 = _cells(T // 3600000 * 3600, k // C.LEVELS[2]["mult"], usd, buy)
    new = np.ones(len(T), bool)
    new[1:] = (T[1:] != T[:-1]) | (mk[1:] != mk[:-1])
    idx = np.flatnonzero(new)
    qs, us = np.add.reduceat(q, idx), np.add.reduceat(usd, idx)
    ok = qs > 0
    orders = np.column_stack([T[idx][ok].astype(float), us[ok] / qs[ok], us[ok], np.where(mk[idx][ok], -1.0, 1.0)])
    return orders, fp1, fp2


def _fp_col(b, cells, old):
    """Kolom footprint dari sel {k: [beli, jual]}; heat orderbook yang sudah terekam (bila ada) dipertahankan."""
    ks = sorted(cells)
    i0 = ks[0]
    arr = np.zeros((2, ks[-1] - i0 + 1))
    for k, (bu, se) in cells.items():
        arr[0, k - i0] += bu
        arr[1, k - i0] += se
    if old is not None and abs(old.b - b) <= 1e-12 * max(1.0, b):
        return Col(b, old.i0, old.n, old.heat, i0, arr)
    return Col(b, 0, 0, np.zeros(0), i0, arr)


def write(sym, b, orders, fp1, fp2, t0_ms, t1_ms, session_col, floor=None):
    """Simpan hasil satu rentang [t0_ms, t1_ms): big trade (ganti yang lama di rentang itu) + kolom footprint.
    Ambang simpan big trade = floor bila diberikan, selain itu persentil 99,5 order di rentang itu."""
    od = np.asarray(orders, float).reshape(-1, 4)
    usd = od[:, 2]
    if floor is None:
        floor = float(np.percentile(usd, STORE_PCTL)) if len(usd) >= 300 else (float(usd.max()) if len(usd) else 0.0)
    floor = float(floor)
    m = (usd >= floor) & (od[:, 0] >= t0_ms) & (od[:, 0] < t1_ms)
    big = [(sym, int(T), float(p), float(u), int(s)) for T, p, u, s in od[m].tolist()]
    store.execute("DELETE FROM hm_big WHERE sym=? AND ts>=? AND ts<?", (sym, int(t0_ms), int(t1_ms)))
    db.add_big(big)
    rows = []
    for lvl, fp, col in ((1, fp1, 60), (2, fp2, 3600)):
        bl = b * C.LEVELS[lvl]["mult"]
        full = {ts: cells for ts, cells in fp.items() if ts * 1000 >= t0_ms and (ts + col) * 1000 <= t1_ms and ts < session_col[lvl] and cells}
        if not full:
            continue
        old = db.get_cols(sym, lvl, min(full), max(full) + 1)
        rows += [(sym, lvl, ts, _fp_col(bl, cells, old.get(ts))) for ts, cells in full.items()]
    db.put_cols(rows)
    return len(big), len(rows), floor


# ------------------------------------------------------------------------------------------------ sumber data
async def fetch_day(sym, day):
    """Arsip harian -> list trade, atau None bila belum terbit (404)."""
    url = ZIP_URL.format(s=sym, d=day)
    try:
        r = await H.fetch(url, retries=1, quiet=True, timeout=180)
    except Exception as exc:
        if "404" in str(exc) or "410" in str(exc):
            return None
        raise

    def _read():
        z = zipfile.ZipFile(io.BytesIO(r.content))
        with z.open(z.namelist()[0]) as f:
            return read_csv(f)
    return await asyncio.to_thread(_read)


async def fetch_rest(sym, t0_ms, t1_ms):
    """Semua aggTrade dalam [t0_ms, t1_ms) lewat REST (halaman 1000, lanjut dengan fromId)."""
    out = []
    raw = await B.get("/api/v3/aggTrades", {"symbol": sym, "startTime": int(t0_ms), "endTime": int(min(t1_ms, t0_ms + 3600_000) - 1), "limit": 1000})
    while True:
        if not raw:
            # jam tanpa trade: lompat ke jam berikutnya
            t0_ms += 3600_000
            if t0_ms >= t1_ms:
                break
            await asyncio.sleep(REST_PAUSE)
            raw = await B.get("/api/v3/aggTrades", {"symbol": sym, "startTime": int(t0_ms), "endTime": int(min(t1_ms, t0_ms + 3600_000) - 1), "limit": 1000})
            continue
        rows = rest_rows(raw)
        out += [x for x in rows if x[0] < t1_ms]
        if rows[-1][0] >= t1_ms - 1:
            break
        await asyncio.sleep(REST_PAUSE)
        raw = await B.get("/api/v3/aggTrades", {"symbol": sym, "fromId": int(raw[-1]["a"]) + 1, "limit": 1000})
    return out


# ------------------------------------------------------------------------------------------------ jalankan
HOUR = 3_600_000
DAY = 86_400_000


def _merge(iv, now=None):
    """Gabungkan interval [a, b) ms yang tumpang-tindih; interval lebih tua dari 3 hari dibuang (sudah diganti arsip)."""
    keep = (now - 3 * 86400) * 1000 if now else None
    out = []
    for x, y in sorted([int(x), int(y)] for x, y in iv if int(y) > int(x)):
        if keep is not None and y < keep:
            continue
        if out and x <= out[-1][1]:
            out[-1][1] = max(out[-1][1], y)
        else:
            out.append([x, y])
    return out


def _gaps(a, b, cov):
    """[a, b) dikurangi interval tercakup -> daftar celah [x, y) terurut."""
    out, cur = [], a
    for x, y in cov:
        if y <= cur:
            continue
        if x >= b:
            break
        if x > cur:
            out.append((cur, min(x, b)))
        cur = max(cur, y)
        if cur >= b:
            break
    if cur < b:
        out.append((cur, b))
    return out


def _state(sym, now=None):
    s = store.kv_get("hm_bf_" + sym) or {}
    cov = [list(x) for x in (s.get("cov") or []) if isinstance(x, (list, tuple)) and len(x) == 2]
    if s.get("rest_day") and s.get("rest_to"):        # format lama: tercakup [00:00, rest_to)
        cov.append([_day_ms(dt.date.fromisoformat(s["rest_day"])), int(s["rest_to"])])
    return dict(days=list(s.get("days") or []), cov=_merge(cov, now))


def plan_rest(so, st, t0, t1):
    """Potongan per jam (TERBARU dulu) di [t0, t1) yang belum tercakup REST sebelumnya maupun rekaman live sesi lalu."""
    cov = list(st["cov"])
    live = store.kv_get("hm_live_" + so.sym) or {}
    if live.get("from") and live.get("to"):
        cov.append([int(live["from"]), int(live["to"]) + 1])
    out = []
    for x, y in _gaps(int(t0), int(t1), _merge(cov)):
        c = x
        while c < y:
            n = min(y, (c // HOUR + 1) * HOUR)
            out.append((c, n))
            c = n
    return out[::-1]


def _day_ms(day):
    return int(dt.datetime(day.year, day.month, day.day, tzinfo=dt.timezone.utc).timestamp() * 1000)


def _deep(so, day, today):
    """Hari di luar retensi L1 (M1..M30): cukup footprint per jam + big trade >= ambang H1 (yang tampil di H1..D1)."""
    return (today - day).days >= C.LEVELS[1]["days"]


def _trim():
    """Kembalikan memori bebas ke OS setelah mengolah satu arsip besar (Linux/glibc; di OS lain tidak melakukan apa-apa)."""
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


def _save(so, st, summary):
    store.kv_set("hm_bf_" + so.sym, st)
    so.bf_rev += 1
    so.backfill = dict(summary, running=True, at=time.time())


async def _chunk(so, a, b, summary, rest=True, deep=False, trades=None):
    """Olah & simpan satu rentang [a, b). trades=None -> ambil lewat REST."""
    if trades is None:
        trades = await fetch_rest(so.sym, a, b)
    if not n_trades(trades):
        return
    orders, fp1, fp2 = await cpu.run(process, trades, so.b, b)
    if deep:                             # di luar retensi L1: hanya yang tampil di H1..D1
        fp1, floor = {}, so.trade_floor("H1") * C.BIG_KEEP_MARGIN
    elif rest and len(orders) < 2000:    # potongan REST kecil: persentil tidak stabil -> ambang live
        floor = so.floor
    else:                                # persentil 99,5 rentang itu (arsip satu hari / jam yang ramai)
        floor = None
    nb, nc, _ = await asyncio.to_thread(write, so.sym, so.b, orders, fp1, fp2, a, b, so.session_col, floor)
    if not deep:
        so.seed_orders(orders)
    summary.update(rest=summary["rest"] + (n_trades(trades) if rest else 0), big=summary["big"] + nb, cols=summary["cols"] + nc)


async def rest_chunk(so, a, b, now, st, summary, deep=False):
    """Satu potongan REST (<= 1 jam): olah, simpan, catat sebagai tercakup."""
    await _chunk(so, a, b, summary, deep=deep)
    st["cov"] = _merge(st["cov"] + [[a, b]], now)
    _save(so, st, summary)
    return True


async def run_day(so, day, now, st, summary):
    """Satu hari lalu dari arsip harian. Arsip kemarin yang belum terbit diganti REST per jam (bisa dilanjutkan)."""
    if str(day) in st["days"]:
        return False
    today = dt.datetime.fromtimestamp(now, dt.timezone.utc).date()
    t0 = _day_ms(day)
    t1 = min(t0 + DAY, so.session_ms)
    deep = _deep(so, day, today)
    if t1 - t0 > 60_000:
        trades = await fetch_day(so.sym, str(day))
        if trades is None:
            if (today - day).days > 1:
                return False                 # arsip belum terbit: coba lagi di putaran berikutnya
            for a, b in plan_rest(so, st, t0, t1):
                await rest_chunk(so, a, b, now, st, summary, deep=deep)
        else:
            await _chunk(so, t0, t1, summary, rest=False, deep=deep, trades=trades)
            del trades
            _trim()
    st["days"] = sorted(set(st["days"]) | {str(day)})[-400:]
    summary["days"] += 1
    _save(so, st, summary)
    return True


async def run_all(sos, now=None, days=None, alive=None):
    """Isi riwayat beberapa pair bergiliran, yang terbaru dulu: hari ini per jam (jam terakhir semua pair, lalu jam
    sebelumnya, ...), lalu arsip kemarin semua pair, dst. alive(so) False -> pair dibatalkan admin: berhenti meminta data."""
    days = DAYS if days is None else days
    sos = [so for so in sos if so is not None and so.b]
    if not days or not sos:
        return {}
    now = now or time.time()
    today = dt.datetime.fromtimestamp(now, dt.timezone.utc).date()
    st = {so.sym: _state(so.sym, now) for so in sos}
    out = {so.sym: dict(days=0, rest=0, big=0, cols=0) for so in sos}

    async def guard(so, fn, *a):
        if so.sym not in out or (alive is not None and not alive(so)):
            return False
        try:
            return await fn(so, *a, now, st[so.sym], out[so.sym])
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            so.backfill = dict(out[so.sym], error=f"{type(exc).__name__}: {str(exc)[:160]}", at=time.time())
            traceback.print_exc()
            return False
    plans = {so.sym: plan_rest(so, st[so.sym], _day_ms(today), so.session_ms) for so in sos}
    while any(plans.values()):
        for so in sos:
            if plans[so.sym]:
                a, b = plans[so.sym].pop(0)
                if not await guard(so, rest_chunk, a, b):
                    plans[so.sym] = []       # galat / pair dibatalkan: lanjut di putaran berikutnya
    for i in range(1, days + 1):
        for so in sos:
            if await guard(so, run_day, today - dt.timedelta(days=i)):
                await asyncio.sleep(2.0)         # beri jeda CPU untuk server di antara hari arsip
    for so in sos:
        so.backfill = dict(out[so.sym], at=time.time(), days_done=len(st[so.sym]["days"]))
    return out


async def run_sym(so, now=None):
    """Isi riwayat satu pair (dipakai pengujian). Mengembalikan ringkasan."""
    if not DAYS or not so.b:
        return None
    return (await run_all([so], now)).get(so.sym)


async def _after_preload(limit=900):
    """Tunggu preload tahap 1 selesai (maks. limit dtk) supaya isian riwayat tidak berebut CPU saat start."""
    try:
        from ..api import state
    except Exception:
        return
    t0 = time.time()
    while time.time() - t0 < limit and (state.get("preload") or {}).get("phase") not in ("ready", None):
        await asyncio.sleep(5)


async def loop(mgr):
    """Putaran latar: tunggu pair siap (ukuran bucket diketahui) & preload selesai, isi riwayat pair terpilih, ulangi
    tiap jam. Pair yang baru dipilih admin langsung diisi tanpa menunggu putaran berikutnya."""
    if not DAYS:
        return
    await asyncio.sleep(20)
    await _after_preload()
    done, last = set(), 0.0

    def ready():
        return {s for s, so in list(mgr.syms.items()) if so is not None and so.b}
    while True:
        if ready() - done or time.time() - last >= 3600:
            sos = [mgr.syms.get(s) for s in sorted(ready())]
            try:
                await run_all(sos, alive=lambda so: mgr.syms.get(so.sym) is so)
                done, last = {so.sym for so in sos}, time.time()
            except asyncio.CancelledError:
                raise
            except Exception:
                traceback.print_exc()
                last = time.time()
        await asyncio.sleep(30)
