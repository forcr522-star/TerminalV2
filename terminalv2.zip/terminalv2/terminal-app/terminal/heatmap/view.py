"""Data menu HEATMAP & FOOTPRINT per (pair, timeframe): candle, heatmap LIQUIDATION (liqmodel.py), big trade (bubble),
footprint, liquidation map, key liquidation levels, dan market overview.

Semua ukuran DISESUAIKAN TIMEFRAME dari data, bukan angka tetap:
  - baris harga (price step) = kelipatan bulat bucket ≈ median range candle TF itu / 8
      -> H4 memakai baris jauh lebih lebar dari M1, sehingga nilai per baris (dan angka footprint) lebih besar;
  - big trade (bubble) = SATU order taker >= ambang TF (persentil ukuran order 24 jam, naik sesuai TF);
  - dominasi pembeli/penjual = aliran taker & big trade nyata FLOW_BARS candle terakhir.
"""
import asyncio
import base64
import collections
import math
import time

import numpy as np

from . import settings as C, db, control, binance as B, liqmodel
from .book import bidx, nice_step
from .engine import manager, GRACE

NICE = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 2500, 5000, 10000, 20000, 25000, 50000, 100000]
MAX_ROWS = 700
TARGET_ROWS_PER_CANDLE = 8
FLOW_BARS = 20            # candle terakhir untuk aliran taker & big order di overview
LEVEL_HIST = 12           # candle terakhir untuk mengukur "ketahanan" likuiditas (key level)
_cc = collections.OrderedDict()   # cache kolom candle yang SUDAH tutup: (sym, tf, t, r, jenis) -> nilai
CC_MAX = 40000
_rows = {}                # (sym, tf) -> (r, ts) price step stabil 30 menit


# ------------------------------------------------------------------------------------------------ validasi
def pair(symbol):
    s = str(symbol or "").strip().upper()
    if s not in C.CATALOG_SYMS:
        raise ValueError(f"pair '{s}' tidak tersedia di menu heatmap (pilihan: {', '.join(C.CATALOG_SYMS)})")
    if not control.is_selected(s):
        raise ValueError(f"pair {s} tidak dipantau: admin belum memilihnya di PILIH PAIR")
    so = manager.get(s)
    if so is None:
        raise ValueError(f"pair {s} tidak dipantau")
    return so


def timeframe(tf):
    t = str(tf or "").strip().upper()
    if t not in C.TFS:
        raise ValueError("timeframe harus salah satu dari: " + ", ".join(C.TF_ORDER))
    return t


def _digits(tick, price):
    if tick:
        return max(0, min(8, int(round(-math.log10(tick))))) if tick < 1 else 0
    if not price:
        return 2
    return max(0, min(8, 4 - int(math.floor(math.log10(abs(price))))))


def _sig(v, n=3):
    if not v:
        return 0
    return float(f"{v:.{n}g}")


def _base(so, lvl, price):
    b = so.b or nice_step((price or 1) * 1e-4, so.tick or 0.01)
    return b * C.LEVELS[lvl]["mult"]


def row_size(so, tf, candles):
    """Price step baris heatmap untuk TF ini (kelipatan NICE dari bucket dasar), stabil selama 30 menit."""
    lvl = C.TFS[tf]["lvl"]
    price = candles[-1][4] if candles else so.price
    base = _base(so, lvl, price)
    hit = _rows.get((so.sym, tf))
    if hit and time.time() - hit[1] < 1800 and abs(hit[0] / base - round(hit[0] / base)) < 1e-6 and hit[0] >= base:
        return hit[0]
    closed = candles[:-1][-100:] or candles
    rngs = sorted(c[2] - c[3] for c in closed if c[2] > c[3])
    med = rngs[len(rngs) // 2] if rngs else (price or 1) * 1e-3
    target = med / TARGET_ROWS_PER_CANDLE
    m = next((x for x in NICE if base * x >= target * 0.75), NICE[-1])
    if candles:
        span = (max(c[2] for c in candles) - min(c[3] for c in candles)) * 1.6
        while span / (base * m) > MAX_ROWS and m < NICE[-1]:
            m = NICE[NICE.index(m) + 1]
    r = float(f"{base * m:.12g}")
    _rows[(so.sym, tf)] = (r, time.time())
    return r


# ------------------------------------------------------------------------------------------------ kolom candle
def _rebin(i0, arr, b, r):
    """Array per bucket (ukuran b, mulai indeks i0) -> (k0, array per baris ukuran r). Bucket dipetakan lewat titik tengahnya."""
    if arr is None or not len(arr):
        return None
    rows = np.floor(((np.arange(len(arr)) + i0) + 0.5) * b / r).astype(np.int64)
    k0 = int(rows[0])
    out = np.zeros(int(rows[-1]) - k0 + 1, dtype=np.float64)
    np.add.at(out, rows - k0, arr)
    return k0, out


def _add(acc, k0, arr, w=1.0):
    """acc: [k0, array] dijumlah in-place (diperlebar bila perlu)."""
    if acc[1] is None:
        acc[0], acc[1] = k0, arr * w
        return
    a0, a = acc
    lo, hi = min(a0, k0), max(a0 + len(a), k0 + len(arr))
    if lo != a0 or hi != a0 + len(a):
        n = np.zeros(hi - lo, dtype=np.float64)
        n[a0 - lo:a0 - lo + len(a)] = a
        acc[0], acc[1] = lo, n
        a0, a = lo, n
    a[k0 - a0:k0 - a0 + len(arr)] += arr * w


async def _level_cols(so, lvl, t0, t1):
    """Kolom tersimpan + kolom berjalan untuk ts dalam [t0, t1) -> {ts: Col}. Memori dipakai lebih dulu; DB hanya untuk masa lalu."""
    out = {}
    rec = so.recent[lvl]
    opened = so.open_cols(lvl)
    mstart = next(iter(rec)) if rec else (min(opened) if opened else None)
    if mstart is None or t0 < mstart:
        hi = t1 if mstart is None else min(t1, mstart)
        try:
            out.update(await asyncio.to_thread(db.get_cols, so.sym, lvl, t0, hi))
        except Exception:
            pass
    for ts, c in rec.items():
        if t0 <= ts < t1:
            out[ts] = c
    for ts, c in opened.items():
        if t0 <= ts < t1:
            out[ts] = c
    return out


def _closed(so, lvl, t, sec):
    """Candle final bila semua kolomnya sudah ditutup: sebelum sesi ini dimulai, atau sudah ditutup di sesi ini."""
    return t + sec <= max(so.closed_upto[lvl], so.session_col[lvl])


async def candle_cols(so, tf, times, rfp):
    """Footprint (beli, jual) per candle dengan baris rfp. Candle tutup di-cache (tidak berubah lagi kecuali isian riwayat)."""
    lvl, sec = C.TFS[tf]["lvl"], C.TFS[tf]["sec"]
    rev = so.bf_rev                                 # footprint lama bisa bertambah oleh isian riwayat
    res, need = {}, []
    for t in times:
        k = (so.sym, tf, t, rfp, rev)
        if k in _cc:
            _cc.move_to_end(k)
            res[t] = _cc[k]
        else:
            need.append(t)
    if not need:
        return res
    cols = await _level_cols(so, lvl, min(need), max(need) + sec)
    by = collections.defaultdict(list)
    for ts, c in cols.items():
        by[int(ts // sec * sec)].append(c)
    for t in need:
        ab, as_ = [0, None], [0, None]
        for c in by.get(t, ()):
            if c.fp is not None and c.fp.shape[1]:
                _add(ab, *_rebin(c.fi0, c.fp[0], c.b, rfp))
                _add(as_, *_rebin(c.fi0, c.fp[1], c.b, rfp))
        val = None
        if ab[1] is not None:
            lo, hi = min(ab[0], as_[0]), max(ab[0] + len(ab[1]), as_[0] + len(as_[1]))
            buy, sell = np.zeros(hi - lo), np.zeros(hi - lo)
            buy[ab[0] - lo:ab[0] - lo + len(ab[1])] = ab[1]
            sell[as_[0] - lo:as_[0] - lo + len(as_[1])] = as_[1]
            val = (lo, buy, sell)
        res[t] = val
        if _closed(so, lvl, t, sec):
            _cc[(so.sym, tf, t, rfp, rev)] = val
    while len(_cc) > CC_MAX:
        _cc.popitem(last=False)
    return res


def _matrix(times, cols, klo, khi):
    """Kolom heat -> matriks padat (n_candle x n_baris) float."""
    n = khi - klo + 1
    M = np.zeros((len(times), n), dtype=np.float64)
    for i, t in enumerate(times):
        v = cols.get(t)
        if not v:
            continue
        k0, arr = v
        a, z = max(klo, k0), min(khi + 1, k0 + len(arr))
        if z > a:
            M[i, a - klo:z - klo] = arr[a - k0:z - k0]
    return M


def _encode(M):
    """uint8 skala log: q = 255 * log1p(v/u) / log1p(1000), u = vmax/1000. Klien mendekode balik ke USDT."""
    vmax = float(M.max()) if M.size else 0.0
    if vmax <= 0:
        return 0.0, ""
    u = vmax / 1000.0
    q = np.clip(np.rint(255.0 * np.log1p(M / u) / math.log1p(1000.0)), 0, 255).astype(np.uint8)
    return vmax, base64.b64encode(q.tobytes()).decode("ascii")


# ------------------------------------------------------------------------------------------------ big order
_pastc = collections.OrderedDict()


async def _past(key, fn):
    """Data big order SEBELUM batas memori sudah final (masa lalu): dibaca dari DB sekali lalu di-cache."""
    if key in _pastc:
        _pastc.move_to_end(key)
        return _pastc[key]
    try:
        v = await asyncio.to_thread(fn)
    except Exception:
        v = []
    _pastc[key] = v
    while len(_pastc) > 64:
        _pastc.popitem(last=False)
    return v


async def big_trades(so, tf, t0, t1):
    """BIG TRADE: order taker TUNGGAL >= ambang timeframe ini (tanpa penjumlahan), maks. BIG_MAX_BUBBLES terbesar di jendela.
    Mengembalikan [(t_candle, harga, usd, sisi, ts_ms)] urut waktu."""
    sec = C.TFS[tf]["sec"]
    thr = so.trade_floor(tf)
    floor = so.big_floor_ms
    rows = await _past(("big", so.sym, t0, floor, so.bf_rev), lambda: db.get_big(so.sym, t0 * 1000, floor)) if t0 * 1000 < floor else []
    rows = [x for x in rows if x[0] < t1 * 1000] + [x for x in list(so.big) if t0 * 1000 <= x[0] < t1 * 1000]
    sel = sorted((x for x in rows if x[2] >= thr), key=lambda x: -x[2])[:C.BIG_MAX_BUBBLES]
    sel.sort(key=lambda x: x[0])
    return [(int(ts // 1000 // sec * sec), price, usd, side, int(ts)) for ts, price, usd, side in sel]


def pick_bubbles(trades, digits):
    return [[int(t), round(p, digits), round(u), int(s), int(ts)] for t, p, u, s, ts in trades]


# ------------------------------------------------------------------------------------------------ overview
def overview(candles, clusters, r, tf, digits, so):
    """Dominasi pembeli vs penjual dari data trade NYATA: aliran taker & big trade FLOW_BARS candle terakhir."""
    last = candles[-FLOW_BARS:]
    buy = sum(c[6] for c in last)
    sell = sum(max(0.0, c[5] - c[6]) for c in last)
    t_from = last[0][0] if last else 0
    bb = sum(c[2] for c in clusters if c[0] >= t_from and c[3] > 0)
    bs = sum(c[2] for c in clusters if c[0] >= t_from and c[3] < 0)

    def imb(a, b):
        return (a - b) / (a + b) if a + b > 0 else None
    comps = dict(flow=imb(buy, sell), big=imb(bb, bs))
    vals = [v for v in comps.values() if v is not None]
    score = sum(vals) / len(vals) if vals else 0.0
    verdict = "BUYERS" if score > 0.10 else "SELLERS" if score < -0.10 else "BALANCED"
    return dict(taker_buy=round(buy), taker_sell=round(sell), delta=round(buy - sell), flow_bars=len(last),
                big_buy=round(bb), big_sell=round(bs), row=r, tf=tf,
                components={k: (round(v, 3) if v is not None else None) for k, v in comps.items()}, score=round(score, 3), verdict=verdict,
                floor=round(so.trade_floor(tf), 2))


# ------------------------------------------------------------------------------------------------ mode LIQUIDATION (model)
LIQ_BARS = 1000            # candle yang dihitung model (300 tampil + 700 pemanasan; paruh 96 candle -> pengaruh awal < 1%)
LIQ_MAX_ROWS = 900
_liqc = collections.OrderedDict()
MODES = ("liq",)


def mode_of(mode):
    """Menu ini hanya LIQUIDATION. Nilai lama 'book' (tersimpan di browser) diperlakukan sebagai 'liq'."""
    return "liq"


def _liq_band(candles, price):
    """Jangkauan harga peta likuidasi TF ini: 15 x median range candle, min 1,5%, maks 15% dari harga."""
    closed = candles[:-1][-100:] or candles
    rngs = sorted(c[2] - c[3] for c in closed if c[2] > c[3])
    med = rngs[len(rngs) // 2] if rngs else price * 0.01
    return max(0.015, min(0.15, 15 * med / price))


def _liq_grid(so, tf, vis, price, r):
    """Baris harga mode likuidasi: rentang candle yang tampil + pita likuidasi di sekitar harga (maks. LIQ_MAX_ROWS baris)."""
    band = _liq_band(vis, price)
    lo, hi = min(c[3] for c in vis), max(c[2] for c in vis)
    pad = (hi - lo) * 0.3 or price * 0.01
    lo, hi = min(lo - pad, price * (1 - band)), max(hi + pad, price * (1 + band))
    base = _base(so, C.TFS[tf]["lvl"], price)
    m = max(1, round(r / base))
    while (hi - lo) / (base * m) > LIQ_MAX_ROWS and m < NICE[-1]:
        m = next((x for x in NICE if x > m), NICE[-1])
    r = float(f"{base * m:.12g}")
    return r, int(math.floor(lo / r)), int(math.floor(hi / r)), band


async def _liq_run(so, tf, candles, r, klo, n, bars):
    """Model atas candle tutup (di-cache per candle baru) + candle berjalan (dihitung ulang tiap permintaan)."""
    closed = candles[:-1]
    key = (so.sym, tf, r, klo, n, closed[0][0] if closed else 0, closed[-1][0] if closed else 0, len(closed))
    hit = _liqc.get(key)
    if hit is None:
        hit = await asyncio.to_thread(liqmodel.run, closed, r, klo, n, max(0, len(closed) - bars))
        _liqc[key] = hit
        while len(_liqc) > 16:
            _liqc.popitem(last=False)
    else:
        _liqc.move_to_end(key)
    st0, cols_c, hits_c = hit
    st = st0.copy()
    last = candles[-1]
    hl = liqmodel.step(st, last, 0.5 ** (1.0 / liqmodel.HALF_LIFE))
    cols = {t: (klo, a) for t, a in cols_c.items()}
    cols[int(last[0])] = (klo, (st.long + st.short).astype(np.float32))
    return st, cols, hits_c + [(int(last[0]), hl[0], hl[1])]


def _pick(values, centers, mask, price, digits, times, cols, k0, side):
    """Level terbesar (puncak lokal) di satu sisi; ambang z 1,5 (buku tipis: 50% terbesar), maks. 8."""
    idx = np.nonzero(mask & (values > 0))[0]
    if not len(idx):
        return []
    vals = values[idx]
    thr = float(0.5 * vals.max()) if len(idx) < 5 else float(min(vals.mean() + 1.5 * vals.std(), vals.max()))
    n = len(values)
    cand = [i for i in idx if values[i] >= thr and not ((i > 0 and values[i - 1] > values[i]) or (i < n - 1 and values[i + 1] > values[i]))]
    cand.sort(key=lambda i: -values[i])
    out = []
    for i in cand[:8]:
        k, v, since = int(k0 + i), float(values[i]), None
        for t in reversed(times):
            c = cols.get(t)
            if not c:
                break
            ck0, arr = c
            j = k - ck0
            if 0 <= j < len(arr) and arr[j] >= 0.4 * v:
                since = t
            else:
                break
        out.append(dict(price=round(float(centers[i]), digits), usd=round(v), strength=round(v), dist=round(float((centers[i] - price) / price * 100), 3),
                        side=side, since=since, k=k))
    out.sort(key=lambda x: -x["price"])
    return out


def _liq_parts(so, tf, candles, cols, times, hits, st, r, klo, khi, band, digits, clusters):
    price = candles[-1][4]
    n = khi - klo + 1
    centers = (np.arange(n) + klo + 0.5) * r
    inb = np.abs(centers - price) <= band * price
    levels = dict(above=_pick(st.short, centers, inb & (centers > price), price, digits, times, cols, klo, "short"),
                  below=_pick(st.long, centers, inb & (centers < price), price, digits, times, cols, klo, "long"))
    longs, shorts = float(st.long[inb].sum()), float(st.short[inb].sum())
    tot = st.long + st.short
    bi = int(np.argmax(np.where(inb, tot, -1))) if inb.any() else None
    sec = C.TFS[tf]["sec"]
    now = candles[-1][0] + sec
    cut = now - 86400
    h24 = [h for h in hits if h[0] >= cut]
    span = min(24.0, (now - (h24[0][0] if h24 else now)) / 3600.0)
    ov = overview(candles, clusters, r, tf, digits, so)
    ov.update(mode="liq", liq_band_pct=round(band * 100, 3), liq_total=round(longs + shorts), liq_longs=round(longs), liq_shorts=round(shorts),
              liq24=round(sum(h[1] + h[2] for h in h24)), liq24_long=round(sum(h[1] for h in h24)), liq24_short=round(sum(h[2] for h in h24)),
              liq24_hours=round(span, 1), row=r,
              liq_largest=dict(price=round(float(centers[bi]), digits), usd=round(float(tot[bi])), side="long" if centers[bi] < price else "short") if bi is not None and tot[bi] > 0 else None,
              model=dict(tiers=[[lv, round(w, 3)] for lv, w in liqmodel.TIERS], mmr=liqmodel.MMR, open_ratio=liqmodel.OPEN_RATIO, half_life=liqmodel.HALF_LIFE))
    lmap = dict(k0=klo, bid=[_sig(v) for v in st.long], ask=[_sig(v) for v in st.short], mid=price, total_bid=round(float(st.long.sum())), total_ask=round(float(st.short.sum())))
    return dict(book=lmap, levels=levels, overview=ov)


async def liq_view(so, tf, bars):
    sec, lvl = C.TFS[tf]["sec"], C.TFS[tf]["lvl"]
    allc = await so.candles(tf, LIQ_BARS)
    if not allc:
        raise ValueError("candle Binance belum tersedia")
    vis = allc[-bars:]
    price = vis[-1][4]
    digits = _digits(so.tick, price)
    r0 = row_size(so, tf, vis)
    r, klo, khi, band = _liq_grid(so, tf, vis, price, r0)
    st, cols, hits = await _liq_run(so, tf, allc, r, klo, khi - klo + 1, bars)
    times = [c[0] for c in vis]
    M = _matrix(times, cols, klo, khi)
    vmax, q = _encode(M)
    clusters = await big_trades(so, tf, times[0], times[-1] + sec)
    out = dict(symbol=so.sym, name=so.name, market=C.MARKET_LABEL, tf=tf, sec=sec, digits=digits, tick=so.tick, mode="liq",
               candles=vis, row=r, fpb=_base(so, lvl, price), heat=dict(k0=klo, nrows=khi - klo + 1, ncols=len(times), vmax=vmax, q=q),
               bubbles=pick_bubbles(clusters, digits), now=time.time() + so.offset, status=so.status(), since=so.since, lvl=lvl, colsec=C.LEVELS[lvl]["col"],
               trades_from=trades_from(so, lvl))
    out.update(_liq_parts(so, tf, vis, cols, times, hits, st, r, klo, khi, band, digits, clusters))
    return out


async def liq_live(so, tf, since, r, klo, nrows, bars):
    sec = C.TFS[tf]["sec"]
    allc = await so.candles(tf, LIQ_BARS)
    if not allc:
        raise ValueError("candle Binance belum tersedia")
    vis = allc[-bars:]
    price = vis[-1][4]
    digits = _digits(so.tick, price)
    khi = klo + nrows - 1
    st, cols, hits = await _liq_run(so, tf, allc, r, klo, nrows, bars)
    times = [c[0] for c in vis]
    new = [c for c in vis if c[0] >= since]
    heat = [[_sig(float(v)) for v in cols[c[0]][1]] if c[0] in cols else [0.0] * nrows for c in new]
    clusters = await big_trades(so, tf, times[0], times[-1] + sec)
    t_from = new[0][0] if new else times[-1]
    out = dict(symbol=so.sym, tf=tf, row=r, mode="liq", candles=new, heat=heat, now=time.time() + so.offset, status=so.status(), since=so.since,
               bubbles=[b for b in pick_bubbles(clusters, digits) if b[0] >= t_from])
    band = _liq_band(vis, price)
    out.update(_liq_parts(so, tf, vis, cols, times, hits, st, r, klo, khi, band, digits, clusters))
    return out


# ------------------------------------------------------------------------------------------------ endpoint
def _row_ok(so, tf, r, price):
    lvl = C.TFS[tf]["lvl"]
    base = _base(so, lvl, price)
    q = r / base
    return r >= base * 0.999 and abs(q - round(q)) < 1e-6


async def pairs_payload():
    sel = control.selected()
    try:
        t24 = await B.ticker24(sel)
    except Exception:
        t24 = {}
    rows = []
    for s in sel:
        so = manager.get(s)
        st = so.status() if so else {}
        t = t24.get(s) or {}
        rows.append(dict(sym=s, name=C.NAMES.get(s, s), price=st.get("price") or t.get("price"), pct=t.get("pct"), vol=t.get("vol"), state=st.get("state", "idle")))
    return dict(pairs=rows, tfs=C.TF_ORDER, market=C.MARKET_LABEL, collector=C.COLLECTOR)


_TF0 = {}


def trades_from(so, lvl):
    """Awal data trade tersimpan (detik) untuk level ini; candle sebelumnya belum punya big trade & footprint."""
    k, now = (so.sym, lvl), time.time()
    hit = _TF0.get(k)
    if hit and hit[0] == so.bf_rev and now - hit[1] < 300:
        return hit[2]
    v = db.first_ts(so.sym, lvl)
    _TF0[k] = (so.bf_rev, now, v)
    return v


async def view_payload(symbol, tf, bars=300, mode="liq"):
    so, tf = pair(symbol), timeframe(tf)
    bars = int(max(30, min(1000, bars)))
    return await liq_view(so, tf, min(bars, LIQ_BARS - 100))


async def live_payload(symbol, tf, since, row, k0, nrows, bars=300, fp=0, mode="liq"):
    so, tf = pair(symbol), timeframe(tf)
    bars = int(max(30, min(1000, bars)))
    nrows = int(max(1, min(3000, nrows)))
    candles = await so.candles(tf, bars)
    if not candles:
        raise ValueError("candle Binance belum tersedia")
    price = candles[-1][4]
    r = float(row)
    if not _row_ok(so, tf, r, price):
        raise ValueError("price step tidak valid untuk timeframe ini (muat ulang chart)")
    out = await liq_live(so, tf, since, r, int(k0), nrows, min(bars, LIQ_BARS - 100))
    if fp:
        out["fp"] = await _fp(so, tf, [candles[-1][0]], fp, price)
    return out


async def _fp(so, tf, times, m, price):
    lvl = C.TFS[tf]["lvl"]
    m = int(m)
    if m not in NICE:
        raise ValueError("pengali baris footprint tidak valid")
    base = _base(so, lvl, price)
    rfp = float(f"{base * m:.12g}")
    cols = await candle_cols(so, tf, times, rfp)
    out = {}
    for t in times:
        v = cols.get(t)
        if not v:
            continue
        k0, buy, sell = v
        rows = [[int(k0 + i), round(float(buy[i])), round(float(sell[i]))] for i in range(len(buy)) if buy[i] > 0 or sell[i] > 0]
        if rows:
            out[str(t)] = rows
    return dict(row=rfp, m=m, cells=out)


async def footprint_payload(symbol, tf, t0, t1, m=1):
    so, tf = pair(symbol), timeframe(tf)
    sec = C.TFS[tf]["sec"]
    t0, t1 = int(t0) // sec * sec, int(t1) // sec * sec
    if t1 < t0:
        t0, t1 = t1, t0
    if (t1 - t0) // sec > 200:
        t0 = t1 - 200 * sec
    times = list(range(t0, t1 + 1, sec))
    price = so.price
    if price is None:
        cs = await so.candles(tf, 30)
        price = cs[-1][4] if cs else 1.0
    out = await _fp(so, tf, times, m, price)
    out.update(symbol=so.sym, tf=tf, since=so.since)
    return out


async def control_payload():
    c = control.get()
    return dict(catalog=[dict(sym=s, name=n) for s, n in C.CATALOG], pairs=c["pairs"], rev=c["rev"], market=C.MARKET_LABEL,
                collector=C.COLLECTOR, status=manager.status(),
                settings=dict(big_pctl=C.BIG_PCTL, l1_days=C.LEVELS[1]["days"], l2_days=C.LEVELS[2]["days"],
                              rest=list(B._order), ws=list(C.WS_HOSTS)))
