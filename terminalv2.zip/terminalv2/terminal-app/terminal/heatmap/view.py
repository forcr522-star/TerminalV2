"""Data menu HEATMAP & FOOTPRINT per (pair, timeframe): candle, heatmap orderbook, big order, footprint,
liquidity map, key liquidity levels, dan market overview.

Semua ukuran DISESUAIKAN TIMEFRAME dari data, bukan angka tetap:
  - baris harga (price step) = kelipatan bulat bucket ≈ median range candle TF itu / 8
      -> H4 memakai baris jauh lebih lebar dari M1, sehingga likuiditas per baris (dan angka footprint) lebih besar;
  - kolom heatmap = satu candle TF = rata-rata waktu likuiditas selama candle itu;
  - big order (bubble) = jumlah order taker besar per (candle, baris, sisi) -> makin besar TF makin besar nilainya;
  - pita orderbook untuk overview / key level = 10 x median range candle TF (dibatasi cakupan snapshot).
"""
import asyncio
import base64
import collections
import math
import time

import numpy as np

from . import settings as C, db, control, binance as B
from .book import bidx, nice_step
from .engine import manager, GRACE

NICE = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 2500, 5000, 10000, 20000, 25000, 50000, 100000]
MAX_ROWS = 700
TARGET_ROWS_PER_CANDLE = 8
FLOW_BARS = 20            # candle terakhir untuk aliran taker & big order di overview
LEVEL_HIST = 12           # candle terakhir untuk mengukur "ketahanan" likuiditas (key level)
_cc = collections.OrderedDict()   # cache kolom candle yang SUDAH tutup: (sym, tf, t, r, jenis) -> nilai
CC_MAX = 40000
_rows = {}                # (sym, tf) -> (r, ts) price step stabil 30 menit
_bookc = {}               # (sym, r) -> (versi buku, k0, bid, ask)


# ------------------------------------------------------------------------------------------------ validasi
def pair(symbol):
    s = str(symbol or "").strip().upper()
    if s not in C.CATALOG_SYMS:
        raise ValueError(f"pair '{s}' tidak tersedia di menu heatmap (pilihan: {', '.join(C.CATALOG_SYMS)})")
    if not control.is_selected(s):
        raise ValueError(f"pair {s} tidak dipantau: admin belum memilihnya di PILIH PAIR")
    so = manager.get(s)
    if so is None:
        raise ValueError(f"pair {s} tidak dipantau")
    return so


def timeframe(tf):
    t = str(tf or "").strip().upper()
    if t not in C.TFS:
        raise ValueError("timeframe harus salah satu dari: " + ", ".join(C.TF_ORDER))
    return t


def _digits(tick, price):
    if tick:
        return max(0, min(8, int(round(-math.log10(tick))))) if tick < 1 else 0
    if not price:
        return 2
    return max(0, min(8, 4 - int(math.floor(math.log10(abs(price))))))


def _sig(v, n=3):
    if not v:
        return 0
    return float(f"{v:.{n}g}")


def _base(so, lvl, price):
    b = so.b or nice_step((price or 1) * 1e-4, so.tick or 0.01)
    return b * C.LEVELS[lvl]["mult"]


def row_size(so, tf, candles):
    """Price step baris heatmap untuk TF ini (kelipatan NICE dari bucket dasar), stabil selama 30 menit."""
    lvl = C.TFS[tf]["lvl"]
    price = candles[-1][4] if candles else so.price
    base = _base(so, lvl, price)
    hit = _rows.get((so.sym, tf))
    if hit and time.time() - hit[1] < 1800 and abs(hit[0] / base - round(hit[0] / base)) < 1e-6 and hit[0] >= base:
        return hit[0]
    closed = candles[:-1][-100:] or candles
    rngs = sorted(c[2] - c[3] for c in closed if c[2] > c[3])
    med = rngs[len(rngs) // 2] if rngs else (price or 1) * 1e-3
    target = med / TARGET_ROWS_PER_CANDLE
    m = next((x for x in NICE if base * x >= target * 0.75), NICE[-1])
    if candles:
        span = (max(c[2] for c in candles) - min(c[3] for c in candles)) * 1.6
        while span / (base * m) > MAX_ROWS and m < NICE[-1]:
            m = NICE[NICE.index(m) + 1]
    r = float(f"{base * m:.12g}")
    _rows[(so.sym, tf)] = (r, time.time())
    return r


# ------------------------------------------------------------------------------------------------ kolom candle
def _rebin(i0, arr, b, r):
    """Array per bucket (ukuran b, mulai indeks i0) -> (k0, array per baris ukuran r). Bucket dipetakan lewat titik tengahnya."""
    if arr is None or not len(arr):
        return None
    rows = np.floor(((np.arange(len(arr)) + i0) + 0.5) * b / r).astype(np.int64)
    k0 = int(rows[0])
    out = np.zeros(int(rows[-1]) - k0 + 1, dtype=np.float64)
    np.add.at(out, rows - k0, arr)
    return k0, out


def _add(acc, k0, arr, w=1.0):
    """acc: [k0, array] dijumlah in-place (diperlebar bila perlu)."""
    if acc[1] is None:
        acc[0], acc[1] = k0, arr * w
        return
    a0, a = acc
    lo, hi = min(a0, k0), max(a0 + len(a), k0 + len(arr))
    if lo != a0 or hi != a0 + len(a):
        n = np.zeros(hi - lo, dtype=np.float64)
        n[a0 - lo:a0 - lo + len(a)] = a
        acc[0], acc[1] = lo, n
        a0, a = lo, n
    a[k0 - a0:k0 - a0 + len(arr)] += arr * w


async def _level_cols(so, lvl, t0, t1):
    """Kolom tersimpan + kolom berjalan untuk ts dalam [t0, t1) -> {ts: Col}. Memori dipakai lebih dulu; DB hanya untuk masa lalu."""
    out = {}
    rec = so.recent[lvl]
    opened = so.open_cols(lvl)
    mstart = next(iter(rec)) if rec else (min(opened) if opened else None)
    if mstart is None or t0 < mstart:
        hi = t1 if mstart is None else min(t1, mstart)
        try:
            out.update(await asyncio.to_thread(db.get_cols, so.sym, lvl, t0, hi))
        except Exception:
            pass
    for ts, c in rec.items():
        if t0 <= ts < t1:
            out[ts] = c
    for ts, c in opened.items():
        if t0 <= ts < t1:
            out[ts] = c
    return out


def _closed(so, lvl, t, sec):
    """Candle final bila semua kolomnya sudah ditutup: sebelum sesi ini dimulai, atau sudah ditutup di sesi ini."""
    return t + sec <= max(so.closed_upto[lvl], so.session_col[lvl])


async def candle_cols(so, tf, times, r, kind="heat", rfp=None):
    """Heat (rata-rata waktu, USDT per baris) atau footprint (beli, jual) per candle. Candle tutup di-cache (tidak berubah lagi)."""
    lvl, sec = C.TFS[tf]["lvl"], C.TFS[tf]["sec"]
    rr = rfp if kind == "fp" else r
    res, need = {}, []
    for t in times:
        k = (so.sym, tf, t, rr, kind)
        if k in _cc:
            _cc.move_to_end(k)
            res[t] = _cc[k]
        else:
            need.append(t)
    if not need:
        return res
    cols = await _level_cols(so, lvl, min(need), max(need) + sec)
    by = collections.defaultdict(list)
    for ts, c in cols.items():
        by[int(ts // sec * sec)].append(c)
    for t in need:
        if kind == "heat":
            acc, den = [0, None], 0
            for c in by.get(t, ()):
                if c.n and c.heat is not None and len(c.heat):
                    rb = _rebin(c.i0, c.heat, c.b, rr)
                    if rb:
                        _add(acc, rb[0], rb[1], c.n)
                    den += c.n
            val = (acc[0], (acc[1] / den).astype(np.float32)) if acc[1] is not None and den else None
        else:
            ab, as_ = [0, None], [0, None]
            for c in by.get(t, ()):
                if c.fp is not None and c.fp.shape[1]:
                    b1 = _rebin(c.fi0, c.fp[0], c.b, rr)
                    s1 = _rebin(c.fi0, c.fp[1], c.b, rr)
                    _add(ab, *b1)
                    _add(as_, *s1)
            val = None
            if ab[1] is not None:
                lo, hi = min(ab[0], as_[0]), max(ab[0] + len(ab[1]), as_[0] + len(as_[1]))
                buy, sell = np.zeros(hi - lo), np.zeros(hi - lo)
                buy[ab[0] - lo:ab[0] - lo + len(ab[1])] = ab[1]
                sell[as_[0] - lo:as_[0] - lo + len(as_[1])] = as_[1]
                val = (lo, buy, sell)
        res[t] = val
        if _closed(so, lvl, t, sec):
            _cc[(so.sym, tf, t, rr, kind)] = val
    while len(_cc) > CC_MAX:
        _cc.popitem(last=False)
    return res


def _matrix(times, cols, klo, khi):
    """Kolom heat -> matriks padat (n_candle x n_baris) float."""
    n = khi - klo + 1
    M = np.zeros((len(times), n), dtype=np.float64)
    for i, t in enumerate(times):
        v = cols.get(t)
        if not v:
            continue
        k0, arr = v
        a, z = max(klo, k0), min(khi + 1, k0 + len(arr))
        if z > a:
            M[i, a - klo:z - klo] = arr[a - k0:z - k0]
    return M


def _encode(M):
    """uint8 skala log: q = 255 * log1p(v/u) / log1p(1000), u = vmax/1000. Klien mendekode balik ke USDT."""
    vmax = float(M.max()) if M.size else 0.0
    if vmax <= 0:
        return 0.0, ""
    u = vmax / 1000.0
    q = np.clip(np.rint(255.0 * np.log1p(M / u) / math.log1p(1000.0)), 0, 255).astype(np.uint8)
    return vmax, base64.b64encode(q.tobytes()).decode("ascii")


# ------------------------------------------------------------------------------------------------ orderbook sekarang
def book_rows(so, r):
    """Orderbook saat ini dalam baris ukuran r (hanya di dalam cakupan snapshot): (k0, bid[], ask[]) atau None."""
    bk = so.book
    if bk is None or so.state != "live":
        return None
    key = (so.sym, r)
    hit = _bookc.get(key)
    ver = (id(bk), bk.updates)
    if hit and hit[0] == ver:
        return hit[1]
    mid = bk.mid()
    if not mid:
        return None
    lo, hi = bk.window(mid, C.LEVELS[2]["range"])
    klo, khi = bidx(lo, bk.b), bidx(hi, bk.b)

    def side(agg):
        ks = np.fromiter((k for k in agg if klo <= k <= khi), dtype=np.int64)
        if not len(ks):
            return None
        vs = np.fromiter((agg[k] for k in ks.tolist()), dtype=np.float64, count=len(ks))
        rows = np.floor((ks + 0.5) * bk.b / r).astype(np.int64)
        return rows, vs
    bs, as_ = side(bk.bb), side(bk.ab)
    allr = [x[0] for x in (bs, as_) if x is not None]
    if not allr:
        return None
    k0 = int(min(a.min() for a in allr))
    k1 = int(max(a.max() for a in allr))
    bid, ask = np.zeros(k1 - k0 + 1), np.zeros(k1 - k0 + 1)
    if bs is not None:
        np.add.at(bid, bs[0] - k0, bs[1])
    if as_ is not None:
        np.add.at(ask, as_[0] - k0, as_[1])
    val = (k0, bid, ask, mid, lo, hi)
    _bookc[key] = (ver, val)
    if len(_bookc) > 64:
        _bookc.pop(next(iter(_bookc)))
    return val


def _band(candles, mid, cov_lo, cov_hi):
    """Pita orderbook untuk overview/key level: 10 x median range candle TF, min 0,5%, dibatasi cakupan snapshot."""
    closed = candles[:-1][-100:] or candles
    rngs = sorted(c[2] - c[3] for c in closed if c[2] > c[3])
    med = rngs[len(rngs) // 2] if rngs else mid * 0.005
    band = max(0.005, 10 * med / mid)
    lim = min(mid - cov_lo, cov_hi - mid) / mid if mid else band
    return max(0.0005, min(band, lim, C.LEVELS[2]["range"]))


def key_levels(br, r, hist, times, window_cols, band, digits):
    """Key liquidity level: likuiditas besar yang BERTAHAN.

    kekuatan baris = min(likuiditas sekarang, rata-rata likuiditas LEVEL_HIST candle terakhir)
      -> order besar yang baru muncul sesaat (spoof) atau yang baru ditarik tidak lolos.
    Kandidat: puncak lokal dengan kekuatan >= rata-rata + 1,5 x simpangan baku di sisinya (baris terkuat selalu lolos;
    buku tipis < 5 baris: >= 50% baris terkuat), maks. 8 per sisi.
    since: candle paling awal (berturut-turut ke belakang) di mana likuiditas di baris itu >= 40% kekuatannya.
    """
    k0, bid, ask, mid, lo, hi = br
    tot = bid + ask
    n = len(tot)
    per, cnt = np.zeros(n), 0
    for v in hist:
        if not v:
            continue
        hk0, arr = v
        a, z = max(k0, hk0), min(k0 + n, hk0 + len(arr))
        if z > a:
            per[a - k0:z - k0] += arr[a - hk0:z - hk0]
        cnt += 1
    strength = np.minimum(tot, per / cnt) if cnt else tot.copy()
    centers = (np.arange(n) + k0 + 0.5) * r
    inband = np.abs(centers - mid) <= band * mid
    out = {"above": [], "below": []}
    for name, mask in (("above", inband & (centers > mid)), ("below", inband & (centers < mid))):
        idx = np.nonzero(mask & (strength > 0))[0]
        if not len(idx):
            continue
        vals = strength[idx]
        # buku tipis (< 5 baris): ambang 50% dari baris terkuat; selain itu z-score 1,5 (baris terkuat selalu lolos)
        thr = float(0.5 * vals.max()) if len(idx) < 5 else float(min(vals.mean() + 1.5 * vals.std(), vals.max()))
        cand = []
        for i in idx:
            s = strength[i]
            if s < thr:
                continue
            if (i > 0 and strength[i - 1] > s) or (i < n - 1 and strength[i + 1] > s):
                continue
            cand.append(i)
        cand.sort(key=lambda i: -strength[i])
        for i in cand[:8]:
            k = int(k0 + i)
            since = None
            s = strength[i]
            for t in reversed(times):
                v = window_cols.get(t)
                if not v:
                    break
                ck0, arr = v
                j = k - ck0
                if 0 <= j < len(arr) and arr[j] >= 0.4 * s:
                    since = t
                else:
                    break
            out[name].append(dict(price=round(float(centers[i]), digits), usd=round(float(tot[i])), strength=round(float(s)),
                                  dist=round(float((centers[i] - mid) / mid * 100), 3), side="ask" if name == "above" else "bid", since=since, k=k))
        out[name].sort(key=lambda x: -x["price"])
    return out


# ------------------------------------------------------------------------------------------------ big order
_pastc = collections.OrderedDict()


async def _past(key, fn):
    """Data big order SEBELUM batas memori sudah final (masa lalu): dibaca dari DB sekali lalu di-cache."""
    if key in _pastc:
        _pastc.move_to_end(key)
        return _pastc[key]
    try:
        v = await asyncio.to_thread(fn)
    except Exception:
        v = []
    _pastc[key] = v
    while len(_pastc) > 64:
        _pastc.popitem(last=False)
    return v


async def big_clusters(so, tf, t0, t1, r):
    """Big order dikelompokkan per (candle, baris harga, sisi). Mengembalikan semua klaster (tanpa filter)."""
    lvl, sec = C.TFS[tf]["lvl"], C.TFS[tf]["sec"]
    cl = {}
    if lvl == 1:
        floor = so.big_floor_ms
        rows = await _past(("big", so.sym, t0, floor), lambda: db.get_big(so.sym, t0 * 1000, floor)) if t0 * 1000 < floor else []
        rows = [x for x in rows if x[0] < t1 * 1000] + [x for x in list(so.big) if t0 * 1000 <= x[0] < t1 * 1000]
        for ts, price, usd, side in rows:
            key = (int(ts // 1000 // sec * sec), int(math.floor(price / r)), side)
            c = cl.setdefault(key, [0.0, 0, 0.0])
            c[0] += usd
            c[1] += 1
            c[2] += price * usd
    else:
        floor = so.bigh_floor
        rows = await _past(("bigh", so.sym, t0, floor), lambda: db.get_bigh(so.sym, t0, floor)) if t0 < floor else []
        rows = [x for x in rows if x[0] < t1] + so.bigh_mem(max(t0, floor), t1)
        for ts, price, usd, side, n in rows:
            key = (int(ts // sec * sec), int(math.floor(price / r)), side)
            c = cl.setdefault(key, [0.0, 0, 0.0])
            c[0] += usd
            c[1] += n
            c[2] += price * usd
    return [(t, c[2] / c[0] if c[0] else (k + 0.5) * r, c[0], side, c[1]) for (t, k, side), c in cl.items()]


def pick_bubbles(clusters, digits, keep=300):
    """Bubble yang ditampilkan: semua klaster big order di jendela, maks. 300 terbesar (supaya chart tetap terbaca)."""
    if not clusters:
        return []
    sel = sorted(clusters, key=lambda c: -c[2])[:keep]
    sel.sort(key=lambda c: c[0])
    return [[int(t), round(p, digits), round(u), int(s), int(n)] for t, p, u, s, n in sel]


# ------------------------------------------------------------------------------------------------ overview
def overview(br, candles, clusters, band, r, tf, digits, so):
    k0, bid, ask, mid, lo, hi = br
    centers = (np.arange(len(bid)) + k0 + 0.5) * r
    m = np.abs(centers - mid) <= band * mid
    bids, asks = float(bid[m].sum()), float(ask[m].sum())
    tot = bid + ask
    big_i = int(np.argmax(np.where(m, tot, -1))) if m.any() else None
    last = candles[-FLOW_BARS:]
    buy = sum(c[6] for c in last)
    sell = sum(max(0.0, c[5] - c[6]) for c in last)
    t_from = last[0][0] if last else 0
    bb = sum(c[2] for c in clusters if c[0] >= t_from and c[3] > 0)
    bs = sum(c[2] for c in clusters if c[0] >= t_from and c[3] < 0)

    def imb(a, b):
        return (a - b) / (a + b) if a + b > 0 else None
    comps = dict(book=imb(bids, asks), flow=imb(buy, sell), big=imb(bb, bs))
    vals = [v for v in comps.values() if v is not None]
    score = sum(vals) / len(vals) if vals else 0.0
    verdict = "BUYERS" if score > 0.10 else "SELLERS" if score < -0.10 else "BALANCED"
    return dict(
        band_pct=round(band * 100, 3), bids=round(bids), asks=round(asks), total=round(bids + asks),
        taker_buy=round(buy), taker_sell=round(sell), delta=round(buy - sell), flow_bars=len(last),
        big_buy=round(bb), big_sell=round(bs),
        largest=dict(price=round(float(centers[big_i]), digits), usd=round(float(tot[big_i])), side="bid" if centers[big_i] < mid else "ask") if big_i is not None and tot[big_i] > 0 else None,
        row=r, tf=tf, components={k: (round(v, 3) if v is not None else None) for k, v in comps.items()}, score=round(score, 3), verdict=verdict,
        floor=round(so.floor, 2))


# ------------------------------------------------------------------------------------------------ endpoint
def _row_ok(so, tf, r, price):
    lvl = C.TFS[tf]["lvl"]
    base = _base(so, lvl, price)
    q = r / base
    return r >= base * 0.999 and abs(q - round(q)) < 1e-6


async def pairs_payload():
    sel = control.selected()
    try:
        t24 = await B.ticker24(sel)
    except Exception:
        t24 = {}
    rows = []
    for s in sel:
        so = manager.get(s)
        st = so.status() if so else {}
        t = t24.get(s) or {}
        rows.append(dict(sym=s, name=C.NAMES.get(s, s), price=st.get("price") or t.get("price"), pct=t.get("pct"), vol=t.get("vol"), state=st.get("state", "idle")))
    return dict(pairs=rows, tfs=C.TF_ORDER, market=C.MARKET_LABEL, collector=C.COLLECTOR)


async def view_payload(symbol, tf, bars=300):
    so, tf = pair(symbol), timeframe(tf)
    bars = int(max(30, min(1000, bars)))
    sec, lvl = C.TFS[tf]["sec"], C.TFS[tf]["lvl"]
    candles = await so.candles(tf, bars)
    if not candles:
        raise ValueError("candle Binance belum tersedia")
    price = candles[-1][4]
    digits = _digits(so.tick, price)
    r = row_size(so, tf, candles)
    times = [c[0] for c in candles]
    lo = min(c[3] for c in candles)
    hi = max(c[2] for c in candles)
    pad = (hi - lo) * 0.3 or price * 0.01
    lo, hi = lo - pad, hi + pad
    br = book_rows(so, r)
    if br is not None:                       # selalu cakup pita orderbook TF ini (key level & likuiditas dekat harga terlihat saat zoom-out)
        band = _band(candles, br[3], br[4], br[5])
        lo, hi = min(lo, br[3] * (1 - band)), max(hi, br[3] * (1 + band))
    klo, khi = int(math.floor(lo / r)), int(math.floor(hi / r))
    if khi - klo + 1 > 2 * MAX_ROWS:         # batas ukuran respons
        mid = (klo + khi) // 2
        klo, khi = mid - MAX_ROWS, mid + MAX_ROWS
    cols = await candle_cols(so, tf, times, r)
    M = _matrix(times, cols, klo, khi)
    vmax, q = _encode(M)
    t_end = times[-1] + sec
    clusters = await big_clusters(so, tf, times[0], t_end, r)
    out = dict(symbol=so.sym, name=so.name, market=C.MARKET_LABEL, tf=tf, sec=sec, digits=digits, tick=so.tick,
               candles=candles, row=r, fpb=_base(so, lvl, price),
               heat=dict(k0=klo, nrows=khi - klo + 1, ncols=len(times), vmax=vmax, q=q),
               bubbles=pick_bubbles(clusters, digits), now=time.time() + so.offset, status=so.status(),
               since=so.since, lvl=lvl, colsec=C.LEVELS[lvl]["col"])
    out.update(_live_parts(so, tf, candles, cols, times, clusters, r, br, klo, khi, digits))
    return out


def _live_parts(so, tf, candles, cols, times, clusters, r, br, klo, khi, digits):
    if br is None:
        return dict(book=None, levels=None, overview=None)
    k0, bid, ask, mid, lo, hi = br
    band = _band(candles, mid, lo, hi)
    hist = [cols.get(t) for t in times[-LEVEL_HIST:]]
    lv = key_levels(br, r, hist, times, cols, band, digits)
    a, z = max(klo, k0), min(khi + 1, k0 + len(bid))
    n = khi - klo + 1
    bb, aa = np.zeros(n), np.zeros(n)
    if z > a:
        bb[a - klo:z - klo] = bid[a - k0:z - k0]
        aa[a - klo:z - klo] = ask[a - k0:z - k0]
    book = dict(k0=klo, bid=[_sig(v) for v in bb], ask=[_sig(v) for v in aa], mid=round(mid, digits + 1),
                cov=[round(lo, digits), round(hi, digits)], total_bid=round(float(bid.sum())), total_ask=round(float(ask.sum())))
    return dict(book=book, levels=lv, overview=overview(br, candles, clusters, band, r, tf, digits, so))


async def live_payload(symbol, tf, since, row, k0, nrows, bars=300, fp=0):
    so, tf = pair(symbol), timeframe(tf)
    bars = int(max(30, min(1000, bars)))
    nrows = int(max(1, min(3000, nrows)))
    sec, lvl = C.TFS[tf]["sec"], C.TFS[tf]["lvl"]
    candles = await so.candles(tf, bars)
    if not candles:
        raise ValueError("candle Binance belum tersedia")
    price = candles[-1][4]
    r = float(row)
    if not _row_ok(so, tf, r, price):
        raise ValueError("price step tidak valid untuk timeframe ini (muat ulang chart)")
    digits = _digits(so.tick, price)
    times = [c[0] for c in candles]
    cols = await candle_cols(so, tf, times, r)        # candle tutup berasal dari cache: murah
    klo, khi = int(k0), int(k0) + nrows - 1
    new = [c for c in candles if c[0] >= since]
    heat = []
    for c in new:
        v = cols.get(c[0])
        rowv = [0.0] * nrows
        if v:
            ck0, arr = v
            a, z = max(klo, ck0), min(khi + 1, ck0 + len(arr))
            for k in range(a, z):
                rowv[k - klo] = _sig(float(arr[k - ck0]))
        heat.append(rowv)
    br = book_rows(so, r)
    t_from = new[0][0] if new else times[-1]
    clusters = await big_clusters(so, tf, times[0], times[-1] + sec, r)
    out = dict(symbol=so.sym, tf=tf, row=r, candles=new, heat=heat, now=time.time() + so.offset, status=so.status(), since=so.since,
               bubbles=[b for b in pick_bubbles(clusters, digits) if b[0] >= t_from])
    out.update(_live_parts(so, tf, candles, cols, times, clusters, r, br, klo, khi, digits))
    if fp:
        out["fp"] = await _fp(so, tf, [times[-1]], fp, price)
    return out


async def _fp(so, tf, times, m, price):
    lvl = C.TFS[tf]["lvl"]
    m = int(m)
    if m not in NICE:
        raise ValueError("pengali baris footprint tidak valid")
    base = _base(so, lvl, price)
    rfp = float(f"{base * m:.12g}")
    cols = await candle_cols(so, tf, times, None, kind="fp", rfp=rfp)
    out = {}
    for t in times:
        v = cols.get(t)
        if not v:
            continue
        k0, buy, sell = v
        rows = [[int(k0 + i), round(float(buy[i])), round(float(sell[i]))] for i in range(len(buy)) if buy[i] > 0 or sell[i] > 0]
        if rows:
            out[str(t)] = rows
    return dict(row=rfp, m=m, cells=out)


async def footprint_payload(symbol, tf, t0, t1, m=1):
    so, tf = pair(symbol), timeframe(tf)
    sec = C.TFS[tf]["sec"]
    t0, t1 = int(t0) // sec * sec, int(t1) // sec * sec
    if t1 < t0:
        t0, t1 = t1, t0
    if (t1 - t0) // sec > 200:
        t0 = t1 - 200 * sec
    times = list(range(t0, t1 + 1, sec))
    price = so.price or (so.book.mid() if so.book is not None else None)
    if price is None:
        cs = await so.candles(tf, 30)
        price = cs[-1][4] if cs else 1.0
    out = await _fp(so, tf, times, m, price)
    out.update(symbol=so.sym, tf=tf, since=so.since)
    return out


async def control_payload():
    c = control.get()
    return dict(catalog=[dict(sym=s, name=n) for s, n in C.CATALOG], pairs=c["pairs"], rev=c["rev"], market=C.MARKET_LABEL,
                collector=C.COLLECTOR, status=manager.status(),
                settings=dict(sample_sec=C.SAMPLE_SEC, depth_limit=C.DEPTH_LIMIT, big_pctl=C.BIG_PCTL, l1_days=C.LEVELS[1]["days"], l2_days=C.LEVELS[2]["days"],
                              rest=list(B._order), ws=list(C.WS_HOSTS)))
