"""Konfigurasi menu HEATMAP & FOOTPRINT (kripto, data orderbook & trade Binance Spot).

Semua angka di sini bisa diubah lewat .env tanpa menyentuh kode. Nilai bawaan dipilih dari data nyata Binance Spot
(cakupan snapshot depth 5000 level, ukuran tick tiap pair) - lihat README bagian HEATMAP & FOOTPRINT.
"""
import os


def _int(name, default, lo=None, hi=None):
    try:
        v = int(os.getenv(name, str(default)).strip())
    except ValueError:
        v = default
    if lo is not None:
        v = max(lo, v)
    if hi is not None:
        v = min(hi, v)
    return v


def _hosts(name, default):
    raw = os.getenv(name, "").strip()
    items = [h.strip().rstrip("/") for h in raw.split(",") if h.strip()] if raw else []
    return items or list(default)


# Pair yang boleh dipilih admin (semuanya ada di Binance Spot dengan quote USDT). Admin memilih sebagian/semua;
# pair yang TIDAK dipilih tidak dipantau sama sekali (tidak ada WebSocket, tidak ada permintaan REST).
CATALOG = [
    ("BTCUSDT", "Bitcoin"),
    ("ETHUSDT", "Ethereum"),
    ("SOLUSDT", "Solana"),
    ("XRPUSDT", "XRP"),
    ("TRXUSDT", "TRON"),
    ("XAUTUSDT", "Tether Gold"),
]
CATALOG_SYMS = [s for s, _ in CATALOG]
NAMES = dict(CATALOG)
MARKET_LABEL = "Binance Spot"

# Timeframe chart: M1 .. D1. lvl = resolusi data tersimpan yang dipakai (1 = kolom 1 menit, 2 = kolom 1 jam).
TF_ORDER = ["M1", "M5", "M15", "M30", "H1", "H4", "D1"]
TFS = {
    "M1": dict(sec=60, iv="1m", lvl=1),
    "M5": dict(sec=300, iv="5m", lvl=1),
    "M15": dict(sec=900, iv="15m", lvl=1),
    "M30": dict(sec=1800, iv="30m", lvl=1),
    "H1": dict(sec=3600, iv="1h", lvl=2),
    "H4": dict(sec=14400, iv="4h", lvl=2),
    "D1": dict(sec=86400, iv="1d", lvl=2),
}

# Dua resolusi penyimpanan heatmap/footprint:
#   lvl 1: kolom 1 menit, bucket harga = b (±1 bp), jangkauan ±RANGE dari harga, disimpan L1_DAYS hari  -> M1..M30
#   lvl 2: kolom 1 jam,   bucket harga = 10*b,       jangkauan lebih lebar,    disimpan L2_DAYS hari  -> H1..D1
LEVELS = {
    1: dict(col=60, mult=1, range=_int("HEATMAP_L1_RANGE_BP", 300, 50, 3000) / 1e4, days=_int("HEATMAP_L1_DAYS", 5, 1, 60)),
    2: dict(col=3600, mult=10, range=_int("HEATMAP_L2_RANGE_BP", 2500, 200, 9000) / 1e4, days=_int("HEATMAP_L2_DAYS", 365, 7, 3650)),
}

COLLECTOR = os.getenv("HEATMAP_COLLECTOR", "1") != "0"      # 0 = kolektor Binance tidak dijalankan (dipakai pengujian)
SAMPLE_SEC = _int("HEATMAP_SAMPLE_SEC", 2, 1, 30)          # orderbook dicuplik tiap N detik -> rata-rata waktu per kolom
DEPTH_LIMIT = _int("HEATMAP_DEPTH_LIMIT", 5000, 100, 5000)  # level per sisi pada snapshot REST (5000 = cakupan terdalam)
RESYNC_MIN = _int("HEATMAP_RESYNC_MIN", 10, 2, 120)         # snapshot ulang berkala supaya level jauh tetap lengkap
BOOK_KEEP = 0.30                                            # level lebih jauh dari ±30% harga dibuang dari memori
BIG_PCTL = float(os.getenv("HEATMAP_BIG_PCTL", "99.5"))     # big order = order taker >= persentil ini (ukuran order 24 jam terakhir)
BIG_MIN_USD = float(os.getenv("HEATMAP_BIG_MIN_USD", "2000"))
BIG_WARMUP_USD = float(os.getenv("HEATMAP_BIG_WARMUP_USD", "10000"))
# BIG TRADE (bubble) = SATU order taker yang sangat besar. Ambang minimal naik sesuai timeframe: persentil ukuran order
# 24 jam terakhir pair itu (M1 = 0,1% order terbesar ... D1 = 0,002% terbesar). Sebelum distribusi cukup (< 2000 order),
# dipakai ambang dasar x pengali TF. Per layar chart maksimal BIG_MAX_BUBBLES trade terbesar.
BIG_TF_PCTL = {"M1": 99.9, "M5": 99.95, "M15": 99.97, "M30": 99.98, "H1": 99.99, "H4": 99.995, "D1": 99.998}
BIG_TF_MULT = {"M1": 1.5, "M5": 2.5, "M15": 4.0, "M30": 6.0, "H1": 8.0, "H4": 15.0, "D1": 30.0}
BIG_MAX_BUBBLES = _int("HEATMAP_BIG_MAX_BUBBLES", 80, 10, 500)   # ambang sementara sebelum distribusi cukup (2000 order)

# Data pasar publik (tanpa API key). Urutan = prioritas. data-api/data-stream.binance.vision adalah domain resmi Binance
# khusus data pasar publik (tidak diblokir lokasi); api/stream.binance.com dipakai sebagai cadangan.
REST_HOSTS = _hosts("HEATMAP_REST", ["https://data-api.binance.vision", "https://api.binance.com"])
WS_HOSTS = _hosts("HEATMAP_WS", ["wss://data-stream.binance.vision", "wss://stream.binance.com:9443"])
