"""Akses REST data pasar publik Binance Spot (tanpa API key) dengan cadangan host.

Host dicoba berurutan (settings.REST_HOSTS). Host yang gagal (mis. 451 = diblokir lokasi) dipindah ke belakang
sehingga permintaan berikutnya langsung memakai host yang berfungsi.
"""
import json
import time

from .. import http as H
from . import settings as C

_order = list(C.REST_HOSTS)
_tick = {}          # sym -> tickSize
_t24 = {"ts": 0.0, "key": "", "data": {}}


async def get(path, params):
    last = None
    for i, host in enumerate(list(_order)):
        try:
            r = await H.fetch(host + path, params=params, retries=1, quiet=i < len(_order) - 1, timeout=20)
            if i:
                _order.remove(host)
                _order.insert(0, host)
            return r.json()
        except Exception as exc:
            last = exc
    raise last or RuntimeError("tidak ada host REST Binance")


async def tick_size(sym):
    if sym in _tick:
        return _tick[sym]
    d = await get("/api/v3/exchangeInfo", {"symbol": sym})
    tick = 0.01
    for s in d.get("symbols", []):
        for f in s.get("filters", []):
            if f.get("filterType") == "PRICE_FILTER":
                tick = float(f["tickSize"])
    _tick[sym] = tick
    return tick


async def depth(sym, limit):
    return await get("/api/v3/depth", {"symbol": sym, "limit": int(limit)})


def kline_row(k):
    """Baris REST /api/v3/klines -> [t_detik, open, high, low, close, volume_quote, taker_buy_quote]."""
    return [int(k[0]) // 1000, float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[7]), float(k[10])]


def ws_kline_row(k):
    """Payload stream <symbol>@kline_<interval> -> baris yang sama dengan kline_row."""
    return [int(k["t"]) // 1000, float(k["o"]), float(k["h"]), float(k["l"]), float(k["c"]), float(k["q"]), float(k["Q"])]


async def klines(sym, iv, limit):
    raw = await get("/api/v3/klines", {"symbol": sym, "interval": iv, "limit": int(min(1000, max(2, limit)))})
    return [kline_row(k) for k in raw]


async def agg_trades(sym, limit=1000):
    """aggTrade terbaru (REST) - dipakai sekali saat start untuk ambang big order awal."""
    return await get("/api/v3/aggTrades", {"symbol": sym, "limit": int(min(1000, limit))})


async def ticker24(syms):
    """Harga terakhir & perubahan 24 jam untuk pair terpilih (cache 20 detik)."""
    key = ",".join(syms)
    if not syms:
        return {}
    if _t24["key"] == key and time.time() - _t24["ts"] < 20:
        return _t24["data"]
    raw = await get("/api/v3/ticker/24hr", {"symbols": json.dumps(list(syms), separators=(",", ":"))})
    out = {r["symbol"]: dict(price=float(r["lastPrice"]), pct=float(r["priceChangePercent"]), vol=float(r["quoteVolume"])) for r in raw}
    _t24.update(ts=time.time(), key=key, data=out)
    return out
