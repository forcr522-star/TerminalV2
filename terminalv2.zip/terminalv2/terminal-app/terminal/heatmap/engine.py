"""Kolektor realtime Binance Spot untuk menu HEATMAP & FOOTPRINT.

Satu koneksi WebSocket gabungan untuk SEMUA pair terpilih (admin) berisi, per pair:
  <sym>@aggTrade       trade agresif             -> footprint (beli/jual per harga) + big trade (bubble)
  <sym>@kline_<tf>     candle M1..D1 yang sedang berjalan (heatmap LIQUIDATION dihitung dari candle - liqmodel.py)

Trade dijumlahkan ke kolom waktu yang sedang berjalan (1 menit & 1 jam) per bucket harga; kolom yang sudah berakhir
disimpan dan tidak pernah diubah lagi. (Mode ORDERBOOK - stream depth, snapshot 5000 level, cuplikan tiap 2 dtk - sudah
dihapus: menu ini hanya LIQUIDATION.)

Tidak ada kebocoran data masa depan: setiap kolom/candle hanya berisi trade yang waktunya di dalam kolom itu.
Pair yang tidak dipilih admin tidak punya objek Sym, tidak masuk daftar stream, dan tidak pernah diminta ke Binance.
"""
import asyncio
import collections
import json
import math
import time
import traceback

import numpy as np

from .. import store
from . import settings as C, db, control, binance as B
from .book import nice_step, bidx
from .db import Col, dense

GRACE = 3.0                 # detik setelah kolom berakhir sebelum ditutup (menunggu trade yang datang terlambat)
MEM_COLS = {1: 1600, 2: 500}
BIG_MEM_SEC = 26 * 3600


def fp_dense(fp):
    if not fp:
        return 0, None
    ks = list(fp.keys())
    i0 = min(ks)
    arr = np.zeros((2, max(ks) - i0 + 1), dtype=np.float64)
    for k, (bu, se) in fp.items():
        arr[0, k - i0] += bu
        arr[1, k - i0] += se
    return i0, arr


class Acc:
    """Akumulator satu kolom waktu yang masih berjalan."""
    __slots__ = ("ts", "b", "heat", "n", "fp")

    def __init__(self, ts, b):
        self.ts, self.b = ts, b
        self.heat, self.n, self.fp = {}, 0, {}      # heat tidak lagi diisi (tanpa orderbook); format kolom tetap sama

    def trade(self, k, usd, buy):
        c = self.fp.get(k)
        if c is None:
            c = self.fp[k] = [0.0, 0.0]
        c[0 if buy else 1] += usd

    def col(self):
        i0, heat = dense(self.heat, self.n) if self.n else (0, np.zeros(0))
        fi0, fp = fp_dense(self.fp)
        return Col(self.b, i0, self.n, heat, fi0, fp)


class SizeDist:
    """Distribusi ukuran order taker 24 jam terakhir (histogram log, 8 bin per kelipatan 2) untuk ambang big order."""

    def __init__(self):
        self.hours = collections.OrderedDict()

    def add(self, usd, t):
        if usd <= 0:
            return
        h = int(t // 3600)
        if self.hours and h < max(self.hours) - 24:
            return                           # lebih tua dari 24 jam terakhir (mis. isian riwayat): diabaikan
        c = self.hours.get(h)
        if c is None:
            c = self.hours[h] = {}
            while len(self.hours) > 25:
                del self.hours[min(self.hours)]      # buang jam TERTUA (data riwayat bisa masuk tidak berurutan)
        k = int(math.floor(math.log2(usd) * 8))
        c[k] = c.get(k, 0) + 1

    def add_many(self, usd, t):
        """Versi tervektor add() untuk banyak order sekaligus (isian riwayat), urut per jam."""
        usd, t = np.asarray(usd, float), np.asarray(t, float)
        m = usd > 0
        usd, t = usd[m], t[m]
        if not len(usd):
            return
        h = (t // 3600).astype(np.int64)
        kb = np.floor(np.log2(usd) * 8).astype(np.int64)
        for hv in np.unique(h).tolist():
            if self.hours and hv < max(self.hours) - 24:
                continue
            c = self.hours.get(hv)
            if c is None:
                c = self.hours[hv] = {}
                while len(self.hours) > 25:
                    del self.hours[min(self.hours)]
                if hv not in self.hours:
                    continue
            ks, ns = np.unique(kb[h == hv], return_counts=True)
            for k, n in zip(ks.tolist(), ns.tolist()):
                c[k] = c.get(k, 0) + n

    def total(self):
        return sum(sum(c.values()) for c in self.hours.values())

    def dump(self):
        return {str(h): {str(k): n for k, n in c.items()} for h, c in self.hours.items()}

    def load(self, d, now):
        """Pulihkan histogram sesi lalu (checkpoint); jam yang sudah lebih tua dari 24 jam dari sekarang dibuang."""
        h0 = int(now // 3600) - 24
        for h in sorted(int(x) for x in (d or {})):
            if h >= h0:
                c = self.hours.setdefault(h, {})
                for k, n in d[str(h)].items():
                    c[int(k)] = c.get(int(k), 0) + int(n)
        while len(self.hours) > 25:
            del self.hours[min(self.hours)]

    def pct(self, p):
        merged = {}
        for c in self.hours.values():
            for k, n in c.items():
                merged[k] = merged.get(k, 0) + n
        tot = sum(merged.values())
        if not tot:
            return None
        target, cum = p / 100.0 * tot, 0
        for k in sorted(merged):
            cum += merged[k]
            if cum >= target:
                return 2 ** ((k + 0.5) / 8)       # titik tengah geometris bin (resolusi ±4%)
        return 2 ** ((max(merged) + 0.5) / 8)


class Klines:
    """Candle satu timeframe: riwayat dari REST, candle berjalan diperbarui stream kline."""

    def __init__(self, sec):
        self.sec, self.rows, self.fetched, self.limit, self.ws_at, self.stale = sec, [], 0.0, 0, 0.0, True
        self.lock = asyncio.Lock()

    def on_ws(self, row):
        self.ws_at = time.time()
        if not self.rows:
            return
        lt = self.rows[-1][0]
        if row[0] == lt:
            self.rows[-1] = row
        elif row[0] == lt + self.sec:
            self.rows.append(row)
            if len(self.rows) > 1200:
                del self.rows[: len(self.rows) - 1000]
        elif row[0] > lt:
            self.stale = True       # ada candle yang terlewat -> ambil ulang dari REST

    def need(self, n, now):
        if not self.rows or self.stale:
            return True
        if n > len(self.rows) and self.limit < min(1000, n):
            return True
        if now - self.ws_at < 30:
            return now - self.fetched > 1800
        return now - self.fetched > 5


class Sym:
    def __init__(self, sym, mgr=None):
        self.sym, self.name, self.mgr = sym, C.NAMES.get(sym, sym), mgr
        self.tick, self.b = None, None
        self.state, self.err, self._preparing = "idle", None, False
        self.offset, self.last_trade, self.price, self.last_T = 0.0, 0.0, None, 0
        self.accs = {1: {}, 2: {}}
        self.closed_upto = {1: 0, 2: 0}
        self.recent = {1: collections.OrderedDict(), 2: collections.OrderedDict()}
        self.big = collections.deque()                 # (ts_ms, price, usd, side) ~26 jam terakhir
        self.bigh = {}                                 # jam berjalan -> {(k2, side): [usd, n, price*usd]}
        self.bigh_recent = collections.OrderedDict()   # jam tertutup -> [(ts, price, usd, side, n)]
        self.grp = None
        self.dist, self.floor, self.floor_at, self.floor_saved = SizeDist(), C.BIG_WARMUP_USD, 0.0, 0.0
        self.floor_src = "awal"                        # awal | sesi lalu | sampel REST | 24 jam
        self.seeded = False
        self.kl = {tf: Klines(C.TFS[tf]["sec"]) for tf in C.TF_ORDER}
        self.since = None
        now = time.time()
        self.session_ms = int(now * 1000)              # rekaman live sesi ini mulai di sini (isian riwayat berhenti di sini)
        self.bf_rev, self.backfill = 0, None           # naik setiap isian riwayat menulis data (membatalkan cache tampilan)
        self.cov_to, self.cov_ok = None, True          # trade live terekam tanpa putus dari session_ms s/d cov_to (ms)
        # kolom sebelum sesi ini (ditulis sesi sebelumnya atau memang kosong) sudah final dan tidak akan berubah lagi
        self.session_col = {lvl: int(now // C.LEVELS[lvl]["col"] * C.LEVELS[lvl]["col"]) for lvl in (1, 2)}
        self.restored = {1: False, 2: False}
        self.big_floor_ms = int(now * 1000)            # big order >= batas ini ada di memori; sebelumnya di DB
        self.bigh_floor = int(now // 3600 * 3600)      # klaster jam >= batas ini ada di memori; sebelumnya di DB
        self.last_check, self.msgs, self.late = 0.0, 0, 0
        self.writes, self.big_writes, self.bigh_writes = [], [], []
        self._meta_loaded = False

    # ------------------------------------------------------------------------------------------ util
    def _spawn(self, coro):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            coro.close()                 # dipanggil di luar event loop (mis. pengujian): tidak ada tugas latar
            return
        if self.mgr is not None:
            self.mgr.spawn(coro)
        else:
            asyncio.ensure_future(coro)

    def _load_meta(self):
        if self._meta_loaded:
            return
        self._meta_loaded = True
        try:
            m = store.kv_get("hm_meta_" + self.sym) or {}
            if m.get("b"):
                self.b = float(m["b"])
            if m.get("tick"):
                self.tick = float(m["tick"])
            f = store.kv_get("hm_floor_" + self.sym)
            if isinstance(f, (int, float)) and f > 0:
                self.floor = float(f)          # ambang big order sesi sebelumnya: titik awal sampai distribusi baru cukup
                self.floor_src = "sesi lalu"
            self.dist.load(store.kv_get("hm_dist_" + self.sym), time.time())   # distribusi ukuran order 24 jam sesi lalu
            self.since = db.first_ts(self.sym)
        except Exception:
            pass

    def _bucket_for(self, mid):
        """Ukuran bucket dasar (lvl 1) ±1 bp harga, dibulatkan & kelipatan tick. Dipertahankan antar restart supaya
        baris heatmap lama dan baru sejajar; dihitung ulang hanya bila harga sudah bergeser jauh (bucket < 0,25 bp atau > 4 bp)."""
        tick = self.tick or 0.01
        if self.b and mid and 0.25e-4 <= self.b / mid <= 4e-4:
            return self.b
        b = nice_step(mid * 1e-4, tick)
        try:
            store.kv_set("hm_meta_" + self.sym, dict(b=b, tick=tick))
        except Exception:
            pass
        return b

    # ------------------------------------------------------------------------------------------ koneksi
    def on_ws_connected(self):
        self._spawn(self.prepare())

    def on_ws_lost(self):
        self.cov_ok = False               # trade selama koneksi putus hilang -> rentang tanpa-putus berhenti di sini
        if self.state == "live":
            self.state = "connecting"

    def live_mark(self):
        """Rentang trade live tanpa putus sesi ini (dipakai isian riwayat agar tidak mengunduh ulang)."""
        return None if self.cov_to is None else {"from": self.session_ms, "to": int(self.cov_to)}

    async def prepare(self):
        """Siapkan pair: tick, ukuran bucket harga (±1 bp, dari harga terakhir), distribusi ukuran order awal."""
        if self._preparing:
            return
        self._preparing = True
        try:
            self._load_meta()
            if self.tick is None:
                self.tick = await B.tick_size(self.sym)
            if not self.seeded:
                self.seeded = True
                await self.seed_sizes()
            price = self.price
            if not price:
                rows = await B.klines(self.sym, "1m", 2)
                price = float(rows[-1][4])
            b = self._bucket_for(price)
            if self.b and b != self.b:
                self.accs = {1: {}, 2: {}}      # ukuran bucket berubah: kolom berjalan dibuang (tidak tercampur)
            self.b, self.state, self.err = b, "live", None
        except Exception as exc:
            self.state, self.err = "error", f"persiapan pair gagal: {type(exc).__name__}: {str(exc)[:140]}"
            self._spawn(self._retry())
        finally:
            self._preparing = False

    async def seed_sizes(self):
        """Isi distribusi ukuran order dengan 1000 aggTrade terakhir (REST) supaya ambang big order langsung berbasis data."""
        if self.dist.total() >= 2000:
            return                        # distribusi sesi lalu sudah dipulihkan
        try:
            rows = await B.agg_trades(self.sym, 1000)
        except Exception:
            return
        grp = {}
        for t in rows:
            k = (int(t["T"]), bool(t["m"]))
            grp[k] = grp.get(k, 0.0) + float(t["p"]) * float(t["q"])
        for (T, _), usd in grp.items():
            self.dist.add(usd, T / 1000.0)
        self.floor_at = 0.0               # hitung ambang pada langkah berikutnya

    async def _retry(self):
        await asyncio.sleep(8)
        if self.state != "live" and (self.mgr is None or self.mgr.ws_state.get("connected")):
            await self.prepare()

    # ------------------------------------------------------------------------------------------ trade & candle
    def on_trade(self, d):
        self.msgs += 1
        p, q, T, m = float(d["p"]), float(d["q"]), int(d["T"]), bool(d["m"])
        now = time.time()
        self.price, self.last_trade, self.last_T = p, now, T
        E = d.get("E")
        if E:                             # selisih jam Binance vs PC (dipakai menutup kolom tepat waktu)
            off = E / 1000.0 - now
            self.offset = off if not self.offset else self.offset * 0.95 + off * 0.05
        if self.cov_ok:
            self.cov_to = T
        usd = p * q
        buy = not m                       # m=True: pembeli adalah maker -> agresor = penjual
        t = T / 1000.0
        if self.since is None:
            self.since = int(t // 60 * 60)
        if self.b:
            k = bidx(p, self.b)
            a1 = self._acc(1, t)
            if a1 is not None:
                a1.trade(k, usd, buy)
                a2 = self._acc(2, t)
                if a2 is not None:
                    a2.trade(k // C.LEVELS[2]["mult"], usd, buy)
            else:
                self.late += 1
        g = self.grp
        if g is not None and g[0] == T and g[1] == m:
            g[2] += q
            g[3] += usd
        else:
            self._flush_group()
            self.grp = [T, m, q, usd]

    def _flush_group(self, now_ms=None):
        """Satu order taker = semua aggTrade dengan waktu (T) & sisi yang sama (order market yang menyapu beberapa level)."""
        g = self.grp
        if g is None or (now_ms is not None and now_ms - g[0] < 1500):
            return
        self.grp = None
        T, m, q, usd = g
        if q <= 0:
            return
        self.dist.add(usd, T / 1000.0)
        if usd < self.floor:
            return
        price, side = usd / q, (-1 if m else 1)
        rec = (T, price, usd, side)
        self.big.append(rec)
        self.big_writes.append((self.sym,) + rec)
        hour = int(T // 1000 // 3600 * 3600)
        if self.b:
            k2 = bidx(price, self.b * C.LEVELS[2]["mult"])
            c = self.bigh.setdefault(hour, {}).setdefault((k2, side), [0.0, 0, 0.0])
            c[0] += usd
            c[1] += 1
            c[2] += price * usd
        cutoff = T - BIG_MEM_SEC * 1000
        while self.big and self.big[0][0] < cutoff:
            self.big.popleft()
            self.big_floor_ms = max(self.big_floor_ms, cutoff)

    def on_kline(self, k):
        from .binance import ws_kline_row
        iv = k.get("i")
        for tf in C.TF_ORDER:
            if C.TFS[tf]["iv"] == iv:
                self.kl[tf].on_ws(ws_kline_row(k))
                break

    async def candles(self, tf, n):
        """Candle [t, o, h, l, c, vol_quote, taker_buy_quote] terbaru (maks 1000). Candle terakhir = yang sedang berjalan."""
        kc = self.kl[tf]
        now = time.time()
        if kc.need(n, now):
            async with kc.lock:
                if kc.need(n, time.time()):
                    lim = int(min(1000, max(n + 5, 300)))
                    rows = await B.klines(self.sym, C.TFS[tf]["iv"], lim)
                    if rows:
                        kc.rows, kc.fetched, kc.limit, kc.stale = rows, time.time(), lim, False
        rows = [list(r) for r in kc.rows[-n:]]
        # harga trade terakhir (lebih baru dari pesan kline) memperbarui candle berjalan: close/high/low saja
        if rows and self.price and self.last_T // 1000 >= rows[-1][0]:
            last = rows[-1]
            last[4] = self.price
            last[2] = max(last[2], self.price)
            last[3] = min(last[3], self.price)
        return rows

    # ------------------------------------------------------------------------------------------ kolom waktu
    def _acc(self, lvl, t):
        col = C.LEVELS[lvl]["col"]
        ts = int(t // col * col)
        if ts < self.closed_upto[lvl]:
            return None                    # kolom sudah ditutup: tidak diubah lagi
        a = self.accs[lvl].get(ts)
        if a is None:
            a = self.accs[lvl][ts] = Acc(ts, self.b * C.LEVELS[lvl]["mult"])
            if ts == self.session_col[lvl] and not self.restored[lvl]:
                self.restored[lvl] = True
                self._restore(a, lvl)
        return a

    def _restore(self, a, lvl):
        """Kolom pertama sesi ini mungkin sudah sebagian direkam sesi sebelumnya (checkpoint sebelum restart):
        lanjutkan dari sana (jumlah cuplikan & footprint digabung) supaya restart tidak meninggalkan celah."""
        try:
            old = db.get_cols(self.sym, lvl, a.ts, a.ts + 1).get(a.ts)
        except Exception:
            return
        if old is None or abs(old.b - a.b) > 1e-12 * max(1.0, a.b):
            return
        if old.n and old.heat is not None:
            for i, v in enumerate(old.heat):
                if v > 0:
                    a.heat[old.i0 + i] = float(v) * old.n
            a.n = int(old.n)
        if old.fp is not None:
            for i in range(old.fp.shape[1]):
                bu, se = float(old.fp[0][i]), float(old.fp[1][i])
                if bu or se:
                    a.fp[old.fi0 + i] = [bu, se]

    def checkpoint_rows(self):
        """Kolom yang masih berjalan (parsial) untuk disimpan: dipakai lagi bila terminal restart di tengah kolom."""
        out = []
        for lvl in (1, 2):
            for ts, a in self.accs[lvl].items():
                if a.n or a.fp:
                    out.append((self.sym, lvl, ts, a.col()))
        return out

    def step(self, now=None):
        """Dipanggil tiap SAMPLE_SEC: tutup kolom yang selesai, perbarui ambang big order, cek ukuran bucket."""
        now = time.time() if now is None else now
        t = now + self.offset
        self._flush_group(t * 1000)
        self.close_due(t)
        if now - self.floor_at > 30:
            self.floor_at = now
            n = self.dist.total()
            # 24 jam (>= 2000 order) -> persentil stabil. Sebelum itu: ambang sesi lalu bila ada, kalau tidak sampel REST (>= 300 order).
            if n >= 2000 or (n >= 300 and self.floor_src != "sesi lalu"):
                self.floor = max(C.BIG_MIN_USD, self.dist.pct(C.BIG_PCTL) or C.BIG_MIN_USD)
                self.floor_src = "24 jam" if n >= 2000 else "sampel REST"
                if now - self.floor_saved > 600:
                    self.floor_saved = now
                    self._spawn(asyncio.to_thread(store.kv_set, "hm_floor_" + self.sym, round(self.floor, 2)))
        if self.state == "live" and self.price and self.b and now - self.last_check > 300:
            self.last_check = now
            if not 0.25e-4 <= self.b / self.price <= 4e-4:   # harga bergeser sangat jauh: bucket ±1 bp dihitung ulang
                self._spawn(self.prepare())

    def close_due(self, t):
        for lvl in (1, 2):
            col = C.LEVELS[lvl]["col"]
            for ts in sorted(self.accs[lvl]):
                if t < ts + col + GRACE:
                    continue
                acc = self.accs[lvl].pop(ts)
                c = acc.col()
                self.closed_upto[lvl] = max(self.closed_upto[lvl], ts + col)
                rec = self.recent[lvl]
                rec[ts] = c
                while len(rec) > MEM_COLS[lvl]:
                    rec.popitem(last=False)
                if c.n or c.fp is not None:
                    self.writes.append((self.sym, lvl, ts, c))
                if lvl == 2:
                    self._close_hour(ts)

    def _close_hour(self, ts):
        cl = self.bigh.pop(ts, None) or {}
        b2 = (self.b or 0) * C.LEVELS[2]["mult"]
        rows = [(ts, v[2] / v[0] if v[0] else (k2 + 0.5) * b2, v[0], side, v[1]) for (k2, side), v in cl.items()]
        self.bigh_recent[ts] = rows
        while len(self.bigh_recent) > 80:
            self.bigh_recent.popitem(last=False)
            self.bigh_floor = max(self.bigh_floor, next(iter(self.bigh_recent)))
        self.bigh_writes.extend((self.sym,) + r for r in rows)
        for h in [h for h in self.bigh if h < ts]:
            self.bigh.pop(h, None)

    def seed_orders(self, orders):
        """Order dari isian riwayat (24 jam terakhir) ikut membentuk distribusi ukuran order -> ambang big trade akurat sejak awal."""
        od = np.asarray(orders, float).reshape(-1, 4)
        od = od[od[:, 0] >= (time.time() - 86400) * 1000]
        self.dist.add_many(od[:, 2], od[:, 0] / 1000.0)
        self.floor_at = 0.0

    def trade_floor(self, tf):
        """Ambang minimal BIG TRADE untuk timeframe ini (USDT, satu order taker). Naik sesuai TF, tidak pernah di bawah ambang rekam.
        Persentil = maks(persentil TF, persentil yang menyisakan rata-rata BIG_PER_CANDLE order per candle dalam 24 jam terakhir)."""
        tot = self.dist.total()
        if tot >= 2000:
            dens = 100.0 * (1.0 - C.BIG_PER_CANDLE * 86400.0 / (C.TFS[tf]["sec"] * tot))
            v = self.dist.pct(max(C.BIG_TF_PCTL[tf], dens)) or 0.0
        else:
            v = self.floor * C.BIG_TF_MULT[tf]
        return max(v, self.floor)

    # ------------------------------------------------------------------------------------------ baca (dipakai view.py)
    def open_cols(self, lvl):
        """Kolom yang masih berjalan (parsial) -> {ts: Col}."""
        return {ts: a.col() for ts, a in self.accs[lvl].items()}

    def mem_start(self, lvl):
        rec = self.recent[lvl]
        return next(iter(rec)) if rec else None

    def big_since(self, t0_ms, t1_ms):
        return [r for r in self.big if t0_ms <= r[0] < t1_ms]

    def bigh_mem(self, t0, t1):
        out = []
        for ts, rows in self.bigh_recent.items():
            if t0 <= ts < t1:
                out.extend(rows)
        b2 = (self.b or 0) * C.LEVELS[2]["mult"]
        for ts, cl in self.bigh.items():
            if t0 <= ts < t1:
                out.extend((ts, v[2] / v[0] if v[0] else (k2 + 0.5) * b2, v[0], side, v[1]) for (k2, side), v in cl.items())
        return out

    def status(self):
        now = time.time()
        return dict(sym=self.sym, state=self.state, err=self.err, price=self.price, b=self.b, tick=self.tick,
                    trade_age=round(now - self.last_trade, 1) if self.last_trade else None,
                    since=self.since, msgs=self.msgs, backfill=self.backfill, floor=round(self.floor, 2), floor_src=self.floor_src,
                    orders24=self.dist.total())


class Manager:
    def __init__(self):
        self.syms = {}
        self.ws_state = dict(connected=False, host=None, err=None, since=None, streams=0)
        self.running = False
        self._tasks = set()
        self._ws = None
        self._wake = None
        self._ws_task = None

    def spawn(self, coro):
        t = asyncio.ensure_future(coro)
        self._tasks.add(t)
        t.add_done_callback(self._tasks.discard)
        return t

    def get(self, sym):
        """Objek Sym untuk pair TERPILIH (None bila tidak dipilih admin)."""
        if not control.is_selected(sym):
            return None
        s = self.syms.get(sym)
        if s is None:
            s = self.syms[sym] = Sym(sym, self)
            s._load_meta()
        return s

    def sync_pairs(self, pairs):
        want = set(pairs)
        for sym in [s for s in self.syms if s not in want]:
            self.syms.pop(sym, None)          # berhenti memantau: objek & bukunya dibuang
        for sym in pairs:
            self.get(sym)
        if self.running:
            self._restart_ws()

    def _on_change(self, st):
        self.sync_pairs(st["pairs"])

    def _restart_ws(self):
        if self._wake is not None:
            self._wake.set()
        ws = self._ws
        if ws is not None:
            self.spawn(ws.close())

    async def run(self):
        self.running = True
        self._wake = asyncio.Event()
        control.on_change(self._on_change)
        self.sync_pairs(control.selected())
        from . import backfill
        jobs = [self._ws_loop(), self._sample_loop(), self._writer_loop(), self._prune_loop(), backfill.loop(self)]
        try:
            await asyncio.gather(*jobs)
        finally:
            self.running = False
            try:
                self.save_now(checkpoint=True)      # server berhenti: simpan semua, termasuk kolom yang belum selesai
            except Exception:
                traceback.print_exc()

    def streams(self):
        out = []
        for sym in sorted(self.syms):
            s = sym.lower()
            out += [f"{s}@aggTrade"] + [f"{s}@kline_{C.TFS[tf]['iv']}" for tf in C.TF_ORDER]
        return out

    def route(self, raw):
        msg = json.loads(raw)
        d = msg.get("data") if isinstance(msg, dict) else None
        if not isinstance(d, dict):
            return
        s = self.syms.get(d.get("s") or (d.get("k") or {}).get("s"))
        if s is None:
            return
        e = d.get("e")
        if e == "aggTrade":
            s.on_trade(d)
        elif e == "kline":
            s.on_kline(d["k"])

    async def _ws_loop(self):
        import websockets
        hosts, hi, backoff = list(C.WS_HOSTS), 0, 2
        while True:
            streams = self.streams()
            self._wake.clear()
            if not streams:
                self.ws_state.update(connected=False, streams=0, err=None)
                await self._wake.wait()
                continue
            url = f"{hosts[hi]}/stream?streams=" + "/".join(streams)
            try:
                async with websockets.connect(url, max_size=2 ** 24, open_timeout=15, ping_interval=20, ping_timeout=40, close_timeout=3,
                                              compression=None) as ws:     # tanpa permessage-deflate: hemat CPU event loop
                    self._ws = ws
                    self.ws_state.update(connected=True, host=hosts[hi], err=None, since=time.time(), streams=len(streams))
                    backoff = 2
                    for s in list(self.syms.values()):
                        s.on_ws_connected()
                    async for raw in ws:
                        try:
                            self.route(raw)
                        except Exception:
                            traceback.print_exc()
                        if self._wake.is_set():
                            break
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.ws_state.update(err=f"{type(exc).__name__}: {str(exc)[:140]}")
                hi = (hi + 1) % len(hosts)
                await asyncio.sleep(backoff)
                backoff = min(60, backoff * 2)
            finally:
                self._ws = None
                self.ws_state["connected"] = False
                for s in list(self.syms.values()):
                    s.on_ws_lost()

    async def _sample_loop(self):
        while True:
            now = time.time()
            for s in list(self.syms.values()):
                try:
                    s.step(now)
                except Exception:
                    traceback.print_exc()
            await asyncio.sleep(max(0.2, C.SAMPLE_SEC - (time.time() % C.SAMPLE_SEC)))

    def _take(self, checkpoint):
        cols, big, bigh = [], [], []
        for s in list(self.syms.values()):
            cols += s.writes
            big += s.big_writes
            bigh += s.bigh_writes
            s.writes, s.big_writes, s.bigh_writes = [], [], []
            if checkpoint:
                cols += s.checkpoint_rows()
        return cols, big, bigh

    @staticmethod
    def _write(cols, big, bigh):
        db.put_cols(cols)
        db.add_big(big)
        db.add_bigh(bigh)

    def _marks(self):
        out = [("hm_live_" + s.sym, m) for s in list(self.syms.values()) for m in [s.live_mark()] if m]
        return out + [("hm_dist_" + s.sym, s.dist.dump()) for s in list(self.syms.values()) if s.dist.total()]

    @staticmethod
    def _write_marks(marks):
        for k, v in marks:
            store.kv_set(k, v)

    async def flush(self, checkpoint=False):
        cols, big, bigh = self._take(checkpoint)
        if cols or big or bigh:
            await asyncio.to_thread(self._write, cols, big, bigh)
        if checkpoint:
            await asyncio.to_thread(self._write_marks, self._marks())

    def save_now(self, checkpoint=True):
        self._write(*self._take(checkpoint))
        if checkpoint:
            self._write_marks(self._marks())

    async def _writer_loop(self):
        n = 0
        while True:
            await asyncio.sleep(3)
            n += 1
            try:
                await self.flush(checkpoint=n % 5 == 0)     # tiap ±15 dtk kolom berjalan ikut disimpan (tahan restart/mati listrik)
            except Exception:
                traceback.print_exc()

    async def _prune_loop(self):
        await asyncio.sleep(120)
        while True:
            try:
                # big trade >= ambang H1 disimpan selama L2 (riwayat untuk H1..D1); yang lebih kecil hanya L1 (M1..M30)
                majors = {}
                for sym in C.CATALOG_SYMS:
                    so = self.syms.get(sym)
                    if so is not None:
                        majors[sym] = so.trade_floor("H1") * C.BIG_KEEP_MARGIN
                    else:
                        f = store.kv_get("hm_floor_" + sym)
                        if isinstance(f, (int, float)) and f > 0:
                            majors[sym] = f * C.BIG_TF_MULT["H1"] * C.BIG_KEEP_MARGIN
                await asyncio.to_thread(db.prune, time.time(), C.LEVELS[1]["days"], C.LEVELS[2]["days"], majors)
            except Exception:
                traceback.print_exc()
            await asyncio.sleep(3600)

    def status(self):
        return dict(ws=dict(self.ws_state), running=self.running, pairs={k: v.status() for k, v in self.syms.items()})


manager = Manager()
