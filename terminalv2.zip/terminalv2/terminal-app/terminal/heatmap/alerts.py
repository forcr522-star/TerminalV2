"""Notifikasi HEATMAP: "likuiditas besar terambil".

Tiap ALERT_EVERY detik, untuk setiap pair yang dipantau, ambil Key Liquidation Levels (model likuidasi yang sama
dengan panel kanan heatmap) pada timeframe ALERT_TF. Level BESAR = 3 level terbesar per sisi yang nilainya >= 50%
dari level terbesar di sisi itu. Bila sejak pemeriksaan sebelumnya harga menyapu level besar yang tercatat
(high >= level short di atas harga / low <= level long di bawah harga) -> notifikasi sekali (dedup per level per jam).
Pemeriksaan pertama tiap pair hanya mencatat level (tidak ada notifikasi saat start).
"""
import asyncio
import os
import time

from .. import notify
from . import control

ALERT_TF = os.getenv("HEATMAP_ALERT_TF", "H1").upper()
ALERT_EVERY = max(10, int(os.getenv("HEATMAP_ALERT_EVERY", "30") or 30))
TOP = 3
MIN_FRAC = 0.5

_prev = {}            # sym -> dict(at, levels=[...])
_state = dict(checks=0, alerts=0, last_error=None, last_check=None)


def big_levels(lv):
    """Level besar per sisi: maks TOP level terbesar yang >= MIN_FRAC x level terbesar sisi itu."""
    out = []
    for side in ("above", "below"):
        xs = sorted(lv.get(side) or [], key=lambda x: -x["usd"])
        if not xs:
            continue
        top = xs[0]["usd"]
        out += [dict(x, where=side) for x in xs[:TOP] if x["usd"] >= MIN_FRAC * top and x["usd"] > 0]
    return out


def swept(levels, candles, since, sec):
    """Level yang tersapu oleh candle yang berjalan sejak `since` (detik epoch): high menembus level di atas / low
    menembus level di bawah. Hanya data candle yang sudah terjadi (tanpa melihat ke depan)."""
    seg = [c for c in candles if c[0] + sec > since]
    if not seg:
        return []
    hi, lo = max(c[2] for c in seg), min(c[3] for c in seg)
    return [L for L in levels if (L["where"] == "above" and hi >= L["price"]) or (L["where"] == "below" and lo <= L["price"])]


def _say_usd(v):
    """Nominal USD untuk dibacakan: 2,4 juta dolar / 1,1 miliar dolar."""
    v = float(v or 0)
    for div, word in ((1e9, "miliar"), (1e6, "juta"), (1e3, "ribu")):
        if abs(v) >= div:
            return f"{notify.say_num(v / div, 1)} {word} dolar"
    return f"{notify.say_num(v, 0)} dolar"


def _fmt_usd(v):
    return f"${v / 1e6:.2f}M" if v >= 1e6 else f"${v / 1e3:.0f}K"


async def check_pair(sym, so, now=None):
    from . import view
    now = now or time.time()
    lv = await view.key_levels(so, ALERT_TF)
    if not lv:
        return 0
    prev = _prev.get(sym)
    n = 0
    if prev:
        for L in swept(prev["levels"], lv["candles"], prev["at"], lv["sec"]):
            side = "Short" if L["side"] == "short" else "Long"
            hour = int(now // 3600)
            ev = notify.emit("liq", f"{sym}: likuiditas besar terambil · {_fmt_usd(L['usd'])}",
                             f"{side} liquidation ~{_fmt_usd(L['usd'])} di {L['price']:,.{lv['digits']}f} ({ALERT_TF}) tersapu · harga {lv['price']:,.{lv['digits']}f}",
                             url="/#heatmap", key=f"{sym}:{L['side']}:{L['price']}:{hour}", level="high",
                             say=f"Likuiditas besar terambil di {sym}. {side} liquidation sekitar {_say_usd(L['usd'])} "
                                 f"di harga {notify.say_num(L['price'], lv['digits'])} tersapu.")
            n += bool(ev)
    _prev[sym] = dict(at=now, levels=big_levels(lv))
    return n


async def run():
    """Putaran latar: hanya pair terpilih admin yang sudah berjalan. Menunggu muat-awal selesai."""
    from .. import preload
    from .engine import manager
    try:
        await preload.wait_done(600)
    except Exception:
        pass
    while True:
        try:
            for sym in list(control.selected()):
                so = manager.get(sym)
                if so is None:
                    continue
                try:
                    _state["alerts"] += await check_pair(sym, so)
                except Exception as exc:
                    _state["last_error"] = f"{sym}: {type(exc).__name__}: {str(exc)[:100]}"
            _state["checks"] += 1
            _state["last_check"] = time.time()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            _state["last_error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
        await asyncio.sleep(ALERT_EVERY)


def status():
    watch = {sym: [[L["where"], L["price"], round(L["usd"])] for L in v["levels"]] for sym, v in _prev.items()}
    return dict(_state, tf=ALERT_TF, every=ALERT_EVERY, pairs=len(_prev), watching=watch)
