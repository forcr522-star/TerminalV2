"""Panel tetap untuk terminal SERVER: link Cloudflare & info penting selalu di bagian atas, log bergulir di bawahnya.

Kenapa: dulu link dicetak sekali lalu tertimbun log (dan log FEBRIAN di jendela yang sama). Sekarang:
  * sys.stdout / sys.stderr diganti penampung (thread-safe) -> semua print/traceback masuk ke buffer log
    dan ke file data/server.log (log lengkap tidak hilang);
  * satu thread menggambar ulang layar HANYA bila isinya berubah (kursor ke kiri-atas, timpa baris, hapus sisa),
    tanpa menggulung layar, sehingga link tetap di posisi yang sama dan bisa diblok/disalin;
  * event loop server tidak pernah menulis langsung ke konsol. Bila konsol "beku" (QuickEdit: user sedang
    memblok teks), hanya thread gambar yang menunggu - website, tunnel, dan bot tetap berjalan.

Bila keluaran bukan konsol (dialihkan ke file, pengujian) atau SERVER_PANEL=0, panel mati dan print berjalan biasa.
"""
import collections
import datetime as dt
import io
import math
import os
import shutil
import sys
import threading
import time

ESC = "\x1b"


def enable_vt():
    """Aktifkan pemrosesan kode ANSI di konsol Windows 10+. True bila berhasil (atau bukan Windows)."""
    if os.name != "nt":
        return True
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not k.GetConsoleMode(h, ctypes.byref(mode)):
            return False
        return bool(k.SetConsoleMode(h, mode.value | 0x0004))   # ENABLE_VIRTUAL_TERMINAL_PROCESSING
    except Exception:
        return False


class LogBuffer:
    """Ring buffer baris log (thread-safe) + salinan ke file log dengan rotasi sederhana."""

    def __init__(self, maxlen=500, logfile=None, max_bytes=5 * 1024 * 1024):
        self.lines = collections.deque(maxlen=maxlen)
        self.lock = threading.Lock()
        self.partial = ""
        self.version = 0
        self.logfile = logfile
        self.max_bytes = max_bytes
        self._fh = None

    def _file(self):
        if not self.logfile:
            return None
        if self._fh is None:
            try:
                os.makedirs(os.path.dirname(self.logfile), exist_ok=True)
                if os.path.exists(self.logfile) and os.path.getsize(self.logfile) > self.max_bytes:
                    os.replace(self.logfile, self.logfile + ".1")
                self._fh = open(self.logfile, "a", encoding="utf-8", errors="replace")
            except Exception:
                self.logfile = None
                return None
        return self._fh

    def write(self, text):
        if not text:
            return 0
        with self.lock:
            data = self.partial + text.replace("\r\n", "\n")
            parts = data.split("\n")
            self.partial = parts.pop()
            stamp = dt.datetime.now().strftime("%H:%M:%S")
            fh = self._file()
            for p in parts:
                p = p.replace("\r", "").replace("\t", "    ").rstrip()
                if not p.strip():
                    continue
                self.lines.append((stamp, p))
                if fh:
                    try:
                        fh.write(f"{dt.datetime.now():%Y-%m-%d} {stamp} {p}\n")
                    except Exception:
                        pass
            if parts:
                self.version += 1
                if fh:
                    try:
                        fh.flush()
                    except Exception:
                        pass
        return len(text)

    def tail(self, n):
        with self.lock:
            return list(self.lines)[-n:] if n > 0 else []

    def close(self):
        with self.lock:
            if self._fh:
                try:
                    self._fh.close()
                except Exception:
                    pass
                self._fh = None


class _Capture(io.TextIOBase):
    """Pengganti sys.stdout/sys.stderr: semua teks masuk LogBuffer."""

    def __init__(self, buf, original):
        self._buf = buf
        self._orig = original

    def write(self, s):
        return self._buf.write(str(s))

    def flush(self):
        pass

    def isatty(self):
        return False

    def writable(self):
        return True

    @property
    def encoding(self):
        return "utf-8"

    def fileno(self):
        return self._orig.fileno()


def wrap_rows(text, cols):
    """Berapa baris layar yang dipakai teks panjang yang dibiarkan membungkus otomatis."""
    return max(1, math.ceil(len(text) / max(1, cols)))


def compose(header, logs, cols, rows, log_title=" LOG "):
    """Susun bingkai layar: header (daftar (teks, boleh_bungkus)) + garis + log terbaru yang muat.

    Baris boleh_bungkus (link) tidak dipotong supaya bisa disalin utuh; panjangnya dihindarkan dari kelipatan
    persis lebar layar (kursor tertunda di kolom terakhir membuat baris berikutnya bergeser di sebagian konsol).
    Hasil: daftar baris; total baris layar <= rows sehingga layar tidak pernah menggulung.
    """
    cols = max(20, cols)
    rows = max(5, rows)
    out, used = [], 0
    for text, wrap in header:
        if wrap:
            if len(text) % cols == 0:
                text += " "
            need = wrap_rows(text, cols)
        else:
            text = text[: cols - 1]
            need = 1
        if used + need > rows - 1:
            break
        out.append(text)
        used += need
    sep = ("-" * 3 + log_title).ljust(cols - 1, "-")[: cols - 1]
    if used < rows:
        out.append(sep)
        used += 1
    room = rows - used
    for stamp, line in logs[-room:] if room > 0 else []:
        out.append(f"{stamp} {line}"[: cols - 1])
    return out


class Panel:
    def __init__(self, logfile=None, enabled=True, interval=0.5):
        self.buf = LogBuffer(logfile=logfile)
        self.header = [("menyiapkan server ...", False)]
        self.interval = interval
        self.enabled = enabled
        self._orig_out, self._orig_err = sys.stdout, sys.stderr
        self._stop = threading.Event()
        self._thread = None
        self._vt = False
        self._last = None
        self._installed = False

    # --------------------------------------------------------------- pasang / lepas
    def install(self):
        self._installed = True
        if not self.enabled:
            # Mode biasa: print tetap ke konsol, tetapi tetap disalin ke file log.
            sys.stdout = _Tee(self._orig_out, self.buf)
            sys.stderr = _Tee(self._orig_err, self.buf)
            return self
        self._vt = enable_vt()
        try:
            os.system("cls" if os.name == "nt" else "clear")
        except Exception:
            pass
        sys.stdout = _Capture(self.buf, self._orig_out)
        sys.stderr = _Capture(self.buf, self._orig_err)
        self._thread = threading.Thread(target=self._loop, name="server-panel", daemon=True)
        self._thread.start()
        return self

    def close(self, show_tail=0):
        if not self._installed:
            return
        self._installed = False
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)
        sys.stdout, sys.stderr = self._orig_out, self._orig_err
        if self.enabled:
            try:
                self._orig_out.write("\n" * 2)
                if show_tail:
                    self._orig_out.write("---- log terakhir (lengkap di data/server.log) ----\n")
                    for stamp, line in self.buf.tail(show_tail):
                        self._orig_out.write(f"{stamp} {line}\n")
                self._orig_out.flush()
            except Exception:
                pass
        self.buf.close()

    # --------------------------------------------------------------- isi
    def set_header(self, lines):
        """lines: daftar (teks, boleh_bungkus). Dipanggil dari event loop; thread gambar memakai salinannya."""
        self.header = list(lines)

    def log(self, text):
        print(text, flush=True)

    # --------------------------------------------------------------- gambar
    def frame(self):
        size = shutil.get_terminal_size((100, 30))
        return compose(self.header, self.buf.tail(size.lines), size.columns, size.lines), size

    def _draw(self, lines):
        if self._vt:
            data = ESC + "[?25l" + ESC + "[H" + (ESC + "[K\r\n").join(lines) + ESC + "[K" + ESC + "[J"
        else:
            os.system("cls")
            data = "\n".join(lines)
        self._orig_out.write(data)
        self._orig_out.flush()

    def _loop(self):
        while not self._stop.is_set():
            try:
                lines, size = self.frame()
                key = (tuple(lines), size.columns, size.lines)
                if key != self._last:
                    self._draw(lines)
                    self._last = key
            except Exception:
                pass
            self._stop.wait(self.interval)
        if self._vt:
            try:
                self._orig_out.write(ESC + "[?25h")
                self._orig_out.flush()
            except Exception:
                pass


class _Tee(io.TextIOBase):
    """Mode tanpa panel: tulis ke konsol asli DAN ke LogBuffer (file log)."""

    def __init__(self, orig, buf):
        self._orig = orig
        self._buf = buf

    def write(self, s):
        s = str(s)
        try:
            self._orig.write(s)
        except Exception:
            pass
        self._buf.write(s)
        return len(s)

    def flush(self):
        try:
            self._orig.flush()
        except Exception:
            pass

    def isatty(self):
        try:
            return self._orig.isatty()
        except Exception:
            return False

    def writable(self):
        return True

    @property
    def encoding(self):
        return getattr(self._orig, "encoding", "utf-8")

    def fileno(self):
        return self._orig.fileno()


def fmt_age(seconds):
    s = int(max(0, seconds or 0))
    if s < 60:
        return f"{s} dtk"
    if s < 3600:
        return f"{s // 60} mnt"
    d, rem = divmod(s, 86400)
    h, m = divmod(rem // 60, 60)
    return (f"{d}h " if d else "") + f"{h}j {m:02d}m"


def clock(ts=None):
    return time.strftime("%H:%M:%S", time.localtime(ts or time.time()))
