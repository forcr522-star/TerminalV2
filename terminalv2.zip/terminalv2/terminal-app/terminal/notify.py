"""Notifikasi per pengguna (per browser): bunyi + DIBACAKAN di halaman, kartu berwarna menurut tingkat, Web Push ke Chrome.

Satu pusat notifikasi (pengaturan di DASHBOARD). Jenis kejadian (pengguna memilih satu / beberapa / semua):
  news     - berita penting (CRIT / HIGH dari sumber tier-1)
  squawk   - headline cepat SQUAWK (Walter Bloomberg, FinancialJuice, Bloomberg, kabar kilat)
  calendar - kalender ekonomi: 15 menit sebelum rilis & saat angka actual keluar (dampak tinggi/sedang)
  rates    - bank sentral mengubah suku bunga
  curve    - yield 10Y bergerak besar / kurva 2s10s berubah atau berbalik
  signal   - menu SIGNAL: order limit baru, order terisi, posisi selesai (TP/SL/batal)
  liq      - likuiditas besar di HEATMAP tersapu
Log informasi (log bot, status sumber, dsb.) TIDAK dijadikan notifikasi.

Tingkat (warna kartu & nada): high = merah, medium = kuning, low = biru, good = hijau (hasil positif).
Tiap kejadian membawa `say` (teks yang dibacakan, bahasa `lang`: id / en).

Alur:
  1. Pengguna menekan tombol Notifikasi di dashboard -> browser meminta izin -> service worker /sw.js mendaftar
     langganan push (kunci VAPID server ini) -> POST /api/notify/subscribe {subscription, kinds}.
     Langganan disimpan PER BROWSER: mengaktifkan di satu perangkat tidak mengaktifkan pengguna/perangkat lain.
  2. Kejadian -> emit() -> antrean -> push hanya ke langganan yang memilih jenis itu.
  3. Di browser: halaman terbuka -> nada + kartu berwarna + dibacakan; website ditutup -> notifikasi Chrome biasa.
Halaman yang terbuka juga mengambil /api/notify/events?since= (cadangan bila push tidak tersedia, mis. akses http).

Web Push butuh paket `pywebpush` (pip install pywebpush) dan halaman HTTPS (Cloudflare Tunnel) atau localhost.
Tanpa pywebpush: notifikasi tetap berbunyi, dibacakan & tampil selama website terbuka (tab boleh di belakang).
"""
import asyncio
import base64
import collections
import hashlib
import json
import os
import re
import threading
import time

from . import config, store, threads

KINDS = ("news", "squawk", "calendar", "rates", "curve", "signal", "liq")
KIND_LABEL = {"news": "Berita penting", "squawk": "Headline cepat (Squawk)", "calendar": "Kalender ekonomi", "rates": "Suku bunga bank sentral",
              "curve": "Yield & kurva obligasi", "signal": "Sinyal", "liq": "Likuiditas heatmap"}
LEVELS = ("high", "medium", "low", "good")
_LEVEL_ALIAS = {"normal": "medium", "info": "low", "crit": "high", "warn": "medium"}
LS_SUBS = "notify_subs_v1"
CONTACT = os.getenv("WEBPUSH_CONTACT", "mailto:noreply@example.com")   # 'sub' VAPID: kontak umum, bukan data pribadi
DEDUP_SEC = 6 * 3600
MAX_EVENTS = 300

_events = collections.deque(maxlen=MAX_EVENTS)
_seen = {}                      # kunci dedup -> waktu
_lock = threading.Lock()
_queue = None
_loop = None
_state = dict(sent=0, failed=0, removed=0, last_error=None, last_sent=None)
_vapid = None


# ------------------------------------------------------------------------------------------------ kunci VAPID
def push_available():
    try:
        import pywebpush  # noqa: F401
        return True
    except Exception:
        return False


def _b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def vapid():
    """Kunci VAPID server (dibuat sekali, disimpan di data/webpush_vapid.json). None bila pustaka kripto tidak ada."""
    global _vapid
    if _vapid:
        return _vapid
    path = config.DATA_DIR / "webpush_vapid.json"
    try:
        if path.exists():
            _vapid = json.loads(path.read_text())
            return _vapid
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        key = ec.generate_private_key(ec.SECP256R1())
        priv = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
        pub = key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
        raw = key.private_numbers().private_value.to_bytes(32, "big")
        _vapid = dict(private_pem=priv, private_b64=_b64u(raw), public=_b64u(pub))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_vapid))
        return _vapid
    except Exception:
        return None


# ------------------------------------------------------------------------------------------------ langganan per browser
def _subs():
    return store.kv_get(LS_SUBS, {}) or {}


def _save(subs):
    store.kv_set(LS_SUBS, subs)


def sub_id(endpoint):
    return hashlib.sha1(str(endpoint).encode()).hexdigest()[:16]


def subscribe(sub, kinds, role):
    """Simpan / perbarui langganan satu browser. Mengembalikan id langganan."""
    ep = (sub or {}).get("endpoint")
    keys = (sub or {}).get("keys") or {}
    if not ep or not str(ep).startswith("https://") or not keys.get("p256dh") or not keys.get("auth"):
        raise ValueError("langganan push tidak valid")
    ks = [k for k in kinds if k in KINDS]
    with _lock:
        subs = _subs()
        sid = sub_id(ep)
        old = subs.get(sid, {})
        subs[sid] = dict(sub=dict(endpoint=ep, keys=dict(p256dh=keys["p256dh"], auth=keys["auth"])), kinds=ks, role=role,
                         created=old.get("created", time.time()), updated=time.time(), fails=0)
        _save(subs)
    return sid


def unsubscribe(endpoint):
    with _lock:
        subs = _subs()
        n = subs.pop(sub_id(endpoint), None)
        _save(subs)
    return bool(n)


def set_kinds(endpoint, kinds):
    with _lock:
        subs = _subs()
        s = subs.get(sub_id(endpoint))
        if not s:
            return False
        s["kinds"] = [k for k in kinds if k in KINDS]
        _save(subs)
    return True


# ------------------------------------------------------------------------------------------------ kejadian
def emit(kind, title, body="", url="/", key=None, level="medium", ts=None, say=None, lang="id"):
    """Catat kejadian & antrekan push. key: dedup (kejadian sama tidak dikirim ulang dalam 6 jam).
    level: high (merah) / medium (kuning) / low (biru) / good (hijau). say: teks yang dibacakan (default judul), lang: id / en."""
    if kind not in KINDS:
        return None
    level = _LEVEL_ALIAS.get(level, level)
    if level not in LEVELS:
        level = "medium"
    now = time.time()
    k = f"{kind}:{key or title}"
    with _lock:
        for old in [x for x, t in _seen.items() if now - t > DEDUP_SEC]:
            _seen.pop(old, None)
        if k in _seen:
            return None
        _seen[k] = now
        ev = dict(id=hashlib.sha1(f"{k}:{now}".encode()).hexdigest()[:12], ts=ts or now, at=now, kind=kind, title=str(title)[:160],
                  body=str(body)[:300], url=url, level=level, say=str(say or title)[:400], lang=lang if lang in ("id", "en") else "id")
        _events.append(ev)
    q, loop = _queue, _loop
    if q is not None and loop is not None and not loop.is_closed():
        try:
            loop.call_soon_threadsafe(q.put_nowait, ev)      # aman dari thread mana pun (pelacak sinyal berjalan di thread)
        except Exception:
            pass
    return ev


def events_since(since=0.0, kinds=KINDS, limit=30):
    with _lock:
        out = [e for e in _events if e["at"] > since and e["kind"] in kinds]
    return out[-limit:]


# ------------------------------------------------------------------------------------------------ pengiriman push
def _send_one(sub, payload, ttl=3600):
    """Kirim 1 push (sinkron, di thread). Mengembalikan kode status HTTP (201 = diterima layanan push)."""
    from pywebpush import webpush, WebPushException
    v = vapid()
    try:
        r = webpush(subscription_info=sub, data=json.dumps(payload), vapid_private_key=v["private_b64"], vapid_claims={"sub": CONTACT},
                    ttl=ttl, headers={"Urgency": "high" if payload.get("level") == "high" else "normal"}, timeout=10)
        return getattr(r, "status_code", 201)
    except WebPushException as exc:
        return getattr(getattr(exc, "response", None), "status_code", None) or 500


async def _deliver(ev):
    if not push_available() or not vapid():
        return 0
    subs = await asyncio.to_thread(_subs)
    targets = [(sid, s) for sid, s in subs.items() if ev["kind"] in s.get("kinds", [])]
    if not targets:
        return 0
    payload = dict(id=ev["id"], kind=ev["kind"], title=ev["title"], body=ev["body"], url=ev["url"], level=ev["level"], ts=ev["ts"],
                   at=ev["at"], say=ev.get("say"), lang=ev.get("lang"))
    res = await asyncio.gather(*[threads.net(_send_one, s["sub"], payload) for _, s in targets], return_exceptions=True)
    gone = []
    for (sid, s), code in zip(targets, res):
        if isinstance(code, Exception):
            code = 500
        if code in (200, 201, 202):
            _state["sent"] += 1
            _state["last_sent"] = time.time()
        else:
            _state["failed"] += 1
            _state["last_error"] = f"HTTP {code}"
            if code in (404, 410):                     # langganan kedaluwarsa (izin dicabut / browser dihapus)
                gone.append(sid)
    if gone:
        def drop():
            with _lock:
                subs2 = _subs()
                for sid in gone:
                    subs2.pop(sid, None)
                _save(subs2)
        await asyncio.to_thread(drop)
        _state["removed"] += len(gone)
    return len(targets)


async def run():
    """Pengirim push latar (satu antrean; kejadian dikirim berurutan)."""
    global _queue, _loop
    _queue = asyncio.Queue(maxsize=500)
    _loop = asyncio.get_running_loop()
    while True:
        ev = await _queue.get()
        try:
            await _deliver(ev)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            _state["last_error"] = f"{type(exc).__name__}: {str(exc)[:120]}"


async def test(endpoint):
    """Notifikasi uji untuk SATU browser (yang meminta)."""
    if not push_available() or not vapid():
        return dict(ok=False, push=False, error="pywebpush belum terpasang di server - notifikasi hanya berjalan saat website terbuka")
    subs = await asyncio.to_thread(_subs)
    s = subs.get(sub_id(endpoint))
    if not s:
        return dict(ok=False, push=True, error="browser ini belum berlangganan")
    payload = dict(id="test-" + str(int(time.time())), kind="test", title="Notifikasi aktif ✓", body="Uji dari terminal: notifikasi " +
                   ", ".join(KIND_LABEL[k] for k in s["kinds"] if k in KIND_LABEL) + " akan muncul di sini.", url="/#dashboard", level="medium", ts=time.time())
    code = await threads.net(_send_one, s["sub"], payload, 600)
    return dict(ok=code in (200, 201, 202), push=True, status=code)


def status():
    subs = _subs()
    by = {k: sum(1 for s in subs.values() if k in s.get("kinds", [])) for k in KINDS}
    return dict(push=push_available(), vapid=bool(vapid()), subscribers=len(subs), by_kind=by, events=len(_events), **_state)


# ------------------------------------------------------------------------------------------------ teks untuk dibacakan
def _px(x):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return str(x)
    return f"{x:,.5f}".rstrip("0").rstrip(".") if abs(x) < 10 else f"{x:,.2f}"


def say_num(x, nd=None):
    """Angka untuk suara bahasa Indonesia: desimal koma, tanpa pemisah ribuan (1.08345 -> '1,08345'; 3593.8 -> '3593,8')."""
    try:
        x = float(x)
    except (TypeError, ValueError):
        return str(x)
    if nd is None:
        nd = 5 if abs(x) < 10 else 2
    t = f"{x:.{nd}f}".rstrip("0").rstrip(".")
    return t.replace(".", ",").replace("-", "minus ")


_ID_WORDS = re.compile(r"\b(yang|dan|dari|untuk|dengan|tidak|akan|ini|itu|pada|ke|di|karena|naik|turun|harga|pemerintah|ekonomi|kini|nanti|"
                       r"masih|juga|sudah|belum|bisa|lebih|hingga|usai|jelang|soal|kata|minta|tahun|bulan|pekan|saham|pasar|rupiah|dolar|"
                       r"suku|bunga|inflasi|terbaru|target|laba|bersih|prospek|cerah|warnai|ketidakpastian|menteri|presiden|gubernur|dalam|atas|bawah)\b", re.I)


def lang_of(text):
    """Bahasa judul berita (untuk memilih suara): 'id' bila ada >= 2 kata Indonesia umum, selain itu 'en'."""
    return "id" if len(_ID_WORDS.findall(text or "")) >= 2 else "en"


def clean_headline(t):
    t = re.sub(r"^[\s*•#>]+", "", str(t or ""))
    t = re.sub(r"^(BREAKING|FLASH|JUST IN|ALERT)\s*[:\-–]\s*", "", t, flags=re.I)
    return re.sub(r"[*#_]+", "", t).strip()


# ------------------------------------------------------------------------------------------------ produsen: berita & squawk
def high_impact(it):
    """Berita HIGH IMPACT: kritis (perang/serangan/krisis), atau berprioritas tinggi (bank sentral, inflasi, tarif, ...)
    dari sumber tier-1 / sumber cepat SQUAWK, atau kabar kilat (FLASH) dari sumber cepat."""
    if it.get("prio") == "CRIT":
        return True
    fast = bool(it.get("fast"))
    if it.get("prio") == "HIGH" and (it.get("t1") or fast):
        return True
    return bool(it.get("flash") and fast)


def squawk_level(it):
    return "high" if it.get("prio") == "CRIT" else "medium" if (it.get("prio") == "HIGH" or it.get("flash")) else "low"


def on_news(items, now=None):
    """Dipanggil news.ingest untuk item BARU. Hanya berita segar (<= 20 menit) supaya muat-ulang saat start / feed yang
    terlambat tidak membanjiri notifikasi.
    - headline dari sumber CEPAT (squawk) -> jenis 'squawk' (semua headline; tingkat dari prioritas)
    - berita lain yang HIGH IMPACT        -> jenis 'news' (CRIT = merah, HIGH = kuning)"""
    now = now or time.time()
    n = 0
    for it in items:
        if now - it.get("ts", now) > 1200:
            continue
        src = it.get("source", "")
        text = clean_headline(it["title"])
        if it.get("fast"):
            lvl = squawk_level(it)
            ev = emit("squawk", it["title"], f"{src} · {'KRITIS' if lvl == 'high' else 'PENTING' if lvl == 'medium' else 'HEADLINE'}", url="/#intel",
                      key=it.get("id"), level=lvl, ts=it.get("ts"), say=text, lang=lang_of(text))
        elif high_impact(it):
            lvl = "high" if it.get("prio") == "CRIT" else "medium"
            ev = emit("news", it["title"], f"{src} · {'KRITIS' if lvl == 'high' else 'HIGH IMPACT'}", url="/#intel", key=it.get("id"),
                      level=lvl, ts=it.get("ts"), say=text, lang=lang_of(text))
        else:
            continue
        n += bool(ev)
    return n


# ------------------------------------------------------------------------------------------------ produsen: sinyal
def _strat(plan):
    return "Strategi ONE" if (plan or {}).get("strategy") == "one" else "10 metode"


def signal_new(sid, sym, side, plan):
    entry, sl, tp = plan.get("entry"), plan.get("sl"), (plan.get("tp") or [None])[0]
    say = (f"Sinyal baru {_strat(plan)}. {sym} {'beli' if side == 'BUY' else 'jual'} limit di {say_num(entry)}. "
           f"Stop loss {say_num(sl)}, target pertama {say_num(tp)}.")
    return emit("signal", f"{sym} {side} LIMIT {_px(entry)}", f"Order limit baru · SL {_px(sl)} · TP1 {_px(tp)}", url="/#signal",
                key=f"new:{sid}", level="high", say=say)


def signal_filled(sid, sym, side, plan):
    entry, sl, tp = plan.get("entry"), plan.get("sl"), (plan.get("tp") or [None])[0]
    say = f"Order {sym} {'beli' if side == 'BUY' else 'jual'} terisi di {say_num(entry)}. Posisi berjalan, stop loss {say_num(sl)}."
    return emit("signal", f"{sym} {side} · ENTRY TERSENTUH {_px(entry)}", f"Order terisi (OPEN) · SL {_px(sl)} · TP1 {_px(tp)}", url="/#signal",
                key=f"fill:{sid}", level="high", say=say)


CLOSED_TXT = {"TPMAX": "TP MAX tercapai", "TP2": "TP2 tercapai", "TP1": "TP1 tercapai", "SL": "kena stop loss", "TIME": "ditutup karena waktu habis",
              "EXPIRED": "dibatalkan, tidak terisi", "NOFILL": "dibatalkan, tidak terisi", "MISSED": "dibatalkan, target tersentuh lebih dulu",
              "CANCEL": "dibatalkan"}


def signal_closed(sid, sym, side, status, r=None, strategy="multi"):
    """Posisi / order selesai. Untung = hijau, rugi = merah, batal = biru."""
    txt = CLOSED_TXT.get(status, status.lower())
    done = r is not None and status not in ("EXPIRED", "NOFILL", "MISSED", "CANCEL")
    lvl = ("good" if r > 0 else "high" if r < 0 else "medium") if done else "low"
    res = f" · {r:+.2f}R" if done else ""
    st = "Strategi ONE" if strategy == "one" else "10 metode"
    say = f"Sinyal {sym} {'beli' if side == 'BUY' else 'jual'} {txt}" + (f", hasil {'plus' if r >= 0 else 'minus'} {say_num(abs(r), 2)} R." if done else ".")
    return emit("signal", f"{sym} {side} · {txt.upper()}{res}", f"{st} · posisi selesai" if done else f"{st} · order batal", url="/#signal",
                key=f"close:{strategy}:{sid}", level=lvl, say=say)
