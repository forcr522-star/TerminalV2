import sqlite3
import threading
import time
import json
from .config import DB_PATH

# PENULIS: satu koneksi + kunci per proses (SQLite hanya mengizinkan satu penulis). PEMBACA: koneksi sendiri per thread,
# TANPA kunci global. Dengan WAL, baca tidak pernah menunggu tulis - sebelumnya satu tulis besar (atau proses agent lain
# yang sedang menulis, busy_timeout 30 dtk) ikut menahan setiap baca, termasuk yang dipanggil di event loop, sehingga
# seluruh server macet: PING tinggi, semua sumber timeout bersamaan, dan Cloudflare menampilkan "Host Error".
_lock = threading.Lock()
_conn = None
_local = threading.local()
WRITE_BATCH = 300          # executemany besar dipecah per batch supaya kunci tulis tidak dipegang lama


def conn():
    global _conn
    if _conn is None:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        # Enam proses agent berbagi satu SQLite; tunggu lock sebentar daripada gagal seketika.
        _conn = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
        _conn.execute("PRAGMA busy_timeout=30000")
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS retail_snap(
                ts INTEGER, symbol TEXT, long_pct REAL, short_pct REAL,
                long_vol REAL, short_vol REAL, long_pos INTEGER, short_pos INTEGER,
                avg_long REAL, avg_short REAL
            );
            CREATE INDEX IF NOT EXISTS ix_retail ON retail_snap(symbol, ts);
            CREATE TABLE IF NOT EXISTS news(
                id TEXT PRIMARY KEY, ts INTEGER, source TEXT, title TEXT, link TEXT, payload TEXT
            );
            CREATE INDEX IF NOT EXISTS ix_news_ts ON news(ts);
            CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT, ts INTEGER);
            CREATE TABLE IF NOT EXISTS cache(k TEXT PRIMARY KEY, v BLOB, ts REAL);
            CREATE TABLE IF NOT EXISTS signal_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT, sym TEXT, mode TEXT, be INTEGER, side TEXT, created REAL, bar_ts TEXT, plan TEXT,
                status TEXT, r REAL, tp_hits INTEGER, closed REAL, note TEXT
            );
            CREATE INDEX IF NOT EXISTS ix_signal ON signal_log(sym, mode, status);
            CREATE TABLE IF NOT EXISTS one_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT UNIQUE, sym TEXT, mode TEXT, type TEXT, side TEXT, created REAL, bar_ts TEXT,
                plan TEXT, status TEXT, r REAL, closed REAL, note TEXT
            );
            CREATE INDEX IF NOT EXISTS ix_one ON one_log(sym, mode, status);
            CREATE TABLE IF NOT EXISTS snapshots(
                k TEXT PRIMARY KEY, path TEXT, params TEXT, body BLOB, ts REAL, hash TEXT, ms INTEGER, nbytes INTEGER, planned INTEGER DEFAULT 0
            );
            """
        )
        _conn.commit()
    return _conn


def execute(sql, params=()):
    with _lock:
        cur = conn().execute(sql, params)
        conn().commit()
        return cur


def executemany(sql, rows):
    rows = rows if isinstance(rows, list) else list(rows)
    for i in range(0, max(1, len(rows)), WRITE_BATCH):
        with _lock:
            conn().executemany(sql, rows[i:i + WRITE_BATCH])
            conn().commit()


def _reader():
    """Koneksi baca milik thread ini (dibuat sekali). Skema & WAL disiapkan koneksi penulis lebih dulu."""
    c = getattr(_local, "c", None)
    if c is None or getattr(_local, "path", None) != str(DB_PATH):
        conn()
        c = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
        c.execute("PRAGMA busy_timeout=30000")
        _local.c, _local.path = c, str(DB_PATH)
    return c


def query(sql, params=()):
    cur = _reader().execute(sql, params)
    try:
        cols = [c[0] for c in cur.description] if cur.description else []
        return [dict(zip(cols, r)) for r in cur.fetchall()]
    finally:
        cur.close()


def kv_get(key, default=None):
    rows = query("SELECT v FROM kv WHERE k=?", (key,))
    if not rows:
        return default
    try:
        return json.loads(rows[0]["v"])
    except Exception:
        return default


def kv_set(key, value):
    execute("INSERT OR REPLACE INTO kv(k,v,ts) VALUES(?,?,?)", (key, json.dumps(value), int(time.time())))


def drop_backtest_leftovers():
    """Menu BACKTEST sudah dihapus: tabel hasil & pelajaran backtest lama dibuang sekali saat start (aman diulang)."""
    try:
        execute("DROP TABLE IF EXISTS bt_trades")
        execute("DROP TABLE IF EXISTS bt_runs")
        execute("DELETE FROM kv WHERE k IN ('bt_last','bt_lessons')")
    except Exception:
        pass


def prune(days_news=200, days_retail=120, days_cache=90):
    now = int(time.time())
    execute("DELETE FROM news WHERE ts<?", (now - days_news * 86400,))
    execute("DELETE FROM retail_snap WHERE ts<?", (now - days_retail * 86400,))
    # Cache sumber di disk ikut dibatasi supaya terminal berjalan lama tidak menumbuhkan DB tanpa henti.
    try:
        execute("DELETE FROM cache WHERE ts<?", (now - days_cache * 86400,))
    except Exception:
        pass


def cache_get(key):
    """Ambil nilai cache permanen (pickle). Mengembalikan (ts, value) atau None."""
    import pickle
    rows = query("SELECT v, ts FROM cache WHERE k=?", (key,))
    if not rows:
        return None
    try:
        return rows[0]["ts"], pickle.loads(rows[0]["v"])
    except Exception:
        return None


def cache_set(key, ts, value):
    import pickle
    try:
        blob = pickle.dumps(value, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        return False
    execute("INSERT OR REPLACE INTO cache(k,v,ts) VALUES(?,?,?)", (key, blob, ts))
    return True


# --- snapshot respons API (lihat terminal/snapshots.py) ---------------------------------------------------------
def snap_all():
    return query("SELECT k, path, params, body, ts, hash, ms, nbytes, planned FROM snapshots")


def snap_get(k):
    rows = query("SELECT k, path, params, body, ts, hash, ms, nbytes, planned FROM snapshots WHERE k=?", (k,))
    return rows[0] if rows else None


def snap_put(k, path, params, body, ts, digest, ms, planned):
    execute("INSERT OR REPLACE INTO snapshots(k,path,params,body,ts,hash,ms,nbytes,planned) VALUES(?,?,?,?,?,?,?,?,?)",
            (k, path, params, body, ts, digest, ms, len(body), int(planned or 0)))


def snap_touch(k, ts, ms, planned=0):
    execute("UPDATE snapshots SET ts=?, ms=?, planned=? WHERE k=?", (ts, ms, int(planned or 0), k))


def snap_delete(k):
    execute("DELETE FROM snapshots WHERE k=?", (k,))
