"""Semua endpoint data /api/... Setiap endpoint didaftarkan ke mesin snapshot (terminal/snapshots.py):

  ttl   : berapa detik snapshot dianggap segar; setelah itu diperbarui otomatis di latar belakang
  plan  : parameter yang dimuat SAAT START (tahap 1) = semua menu dan semua tab/negara/kelas aset di menu itu
  deep  : parameter ekor panjang (tahap 2, latar belakang) = setiap simbol, instrumen, kontrak, dst.
  valid : hasil yang kosong/tidak lengkap tidak pernah menimpa snapshot yang masih baik

Fungsi di sini hanya MENGHITUNG data (mengembalikan dict atau melempar error). Penyimpanan, TTL, dan penyajian ada di snapshots.py.
"""
import asyncio
import contextlib
import json
import time

from . import config, llm, health, store, cpu
from . import http as H
from . import snapshots as S
from .universe import (COUNTRIES, COUNTRY_ORDER, ALL_ASSETS, BY_SYM, DASH_INDICES, DASH_COMMODITIES, HEATMAP_GROUPS, SECTOR_ETFS, FUTURES_ROOTS, COT_TFF, COT_DISAGG,
                       COT_ASSET_CLASSES, RETAIL_SYMBOLS, FX_CORE, ASSET_CLASSES)
from .providers import yahoo, cftc, myfxbook, news, gpr, geo, ais, trade, fiscal, rates, calendar, macro, portwatch, annual, airtraffic, cyber
from .analytics import quant, catalyst
from .signals import service as sigsvc, journal as sigjournal, control as sigctl, runner as sigrun, board as sigboard
from .agents import bus as agentbus
from .heatmap import routes as hmroutes
from .signals.config import MODES as SIG_MODES, MODE_ORDER as SIG_MODE_ORDER

state = dict(public_url=None, local_url=None, started=time.time(), preload=dict(phase="idle", done=0, total=0, started=None, finished=None))
endpoint = S.endpoint

ASSET_CLS = ["ALL", "INDEX", "FX", "COMMODITY", "CRYPTO", "BOND"]
CCS = list(COUNTRY_ORDER)
MEGA_CAPS = ["MSFT", "NVDA", "GOOGL", "AMZN", "META", "TSLA", "JPM", "XOM"]


def _each(**fixed):
    return lambda: [dict(fixed)]


def _rows(key="rows"):
    return lambda d: bool(d.get(key))


# ------------------------------------------------------------------------------------------------ bantu
def _asset_row(a, q):
    return dict(sym=a["sym"], y=a["y"], name=a["name"], cls=a["cls"], **(q or {}))


async def _quotes_for(assets):
    q = await yahoo.quotes(tuple(a["y"] for a in assets))
    return [_asset_row(a, q.get(a["y"])) for a in assets]


async def _strip():
    pol = await rates.policy_map()
    infls = await asyncio.gather(*[rates.inflation(cc) for cc in COUNTRY_ORDER], return_exceptions=True)
    infl = {cc: v["value"] for cc, v in zip(COUNTRY_ORDER, infls) if v and not isinstance(v, Exception)}
    return [dict(cc=cc, label=COUNTRIES[cc]["cb_short"], rate=(pol.get(cc) or [(None, None)])[-1][1], infl=infl.get(cc)) for cc in COUNTRY_ORDER]


async def _cot_mini():
    names = ["US Dollar Index", "Euro FX", "Japanese Yen", "British Pound", "Canadian Dollar", "Australian Dollar", "New Zealand Dollar", "Swiss Franc", "Dow Jones"]
    res = await asyncio.gather(*[cftc.instrument("tff", n, 6) for n in names], return_exceptions=True)
    out = []
    short = {"US Dollar Index": "DXY", "Euro FX": "EUR", "Japanese Yen": "JPY", "British Pound": "GBP", "Canadian Dollar": "CAD", "Australian Dollar": "AUD", "New Zealand Dollar": "NZD", "Swiss Franc": "CHF", "Dow Jones": "DOW"}
    for n, r in zip(names, res):
        if isinstance(r, Exception) or not r["rows"]:
            continue
        x = r["rows"][0]
        lo, sh = x.get("lev_long") or 0, x.get("lev_short") or 0
        out.append(dict(asset=short[n], net=x.get("lev_net"), long_pct=lo / (lo + sh) * 100 if lo + sh else None, chg=x.get("lev_chg"), date=x["date"]))
    return out


async def _events():
    ev = await calendar.events()
    now = time.strftime("%Y-%m-%d %H:%M", time.gmtime(time.time() - 3600))
    up = [e for e in ev if e["date"] >= now and e["impact"] != "HOLIDAY"]
    up.sort(key=lambda e: e["date"])
    return up[:14]


async def _bonds():
    ov = await rates.overview()
    return [dict(cc=r["cc"], name=r["name"], y2=r["y2"], y10=r["y10"], spread=r["curve"], spread_label=r.get("curve_label"),
                 short_tenor=r.get("short_tenor"), y_short=r.get("y_short"), note=r.get("ynote")) for r in ov["rows"]]


async def _maritime_summary():
    return dict(status=ais.status(), vessels=ais.snapshot(None, 2500))


# ------------------------------------------------------------------------------------------------ DASHBOARD
def _dash_valid(d):
    return bool(d.get("indices") or d.get("commodities") or d.get("bonds") or d.get("feed"))


@endpoint("ticker", ttl=60, group="DASHBOARD", plan=_each(), valid=lambda d: bool(d.get("items")))
async def ticker():
    names = ["EURUSD", "USDCAD", "GBPUSD", "USDJPY", "AUDUSD", "USDCHF", "Gold", "Bitcoin", "Ethereum", "Solana", "Dogecoin", "US500", "US100", "DAX30", "USD Index"]
    assets = [BY_SYM[n.upper()] for n in names if n.upper() in BY_SYM]
    rows = await _quotes_for(assets)
    return dict(items=[dict(sym=r["sym"], price=r.get("price"), pct=r.get("pct")) for r in rows if r.get("price") is not None], alert=news.ticker_alert())


@endpoint("dashboard", ttl=90, group="DASHBOARD", plan=_each(), valid=_dash_valid)
async def dashboard():
    idx_assets = [BY_SYM[n.upper()] for n in DASH_INDICES if n.upper() in BY_SYM]
    com_assets = [BY_SYM[n.upper()] for n in DASH_COMMODITIES if n.upper() in BY_SYM]
    jobs = dict(
        indices=_quotes_for(idx_assets), commodities=_quotes_for(com_assets), cot=_cot_mini(), bonds=_bonds(), gpr=gpr.daily(), strip=_strip(),
        events=_events(), regime=macro.regime("US"), maritime=_maritime_summary(),
    )
    # Satu sumber lambat tidak boleh menahan seluruh dashboard. Permintaan pengunjung dibatasi 12 dtk; pembaruan latar belakang
    # (preload/refresher) diberi 60 dtk. shield: pekerjaan yang lewat batas tetap lanjut dan mengisi cache untuk putaran berikutnya.
    limit = 60 if S.is_background() else 12
    futs = [asyncio.ensure_future(j) for j in jobs.values()]
    res = await asyncio.gather(*[asyncio.wait_for(asyncio.shield(f), limit) for f in futs], return_exceptions=True)
    out = {k: (None if isinstance(v, BaseException) else v) for k, v in zip(jobs.keys(), res)}
    failed = {k: (str(v) or type(v).__name__)[:120] for k, v in zip(jobs.keys(), res) if isinstance(v, BaseException)}
    out["feed"] = news.live_feed(30)
    out["alert"] = news.ticker_alert()
    out["catalysts"] = (await catalyst.build_async())[:8]
    if out.get("gpr"):
        out["gpr"] = {k: v for k, v in out["gpr"].items() if k != "series"} | {"spark": [p["v"] for p in out["gpr"]["series"][-120:]]}
    if out.get("regime"):
        r = out["regime"]
        out["regime"] = dict(regime=r["regime"], growth=r["growth"], inflation=r["inflation"], drivers=r["drivers"][:6], color=r["color"])
    # Bagian yang gagal sekarang memakai nilai terakhir yang baik dari snapshot sebelumnya (bukan panel kosong).
    prev = S.previous("dashboard", {}) or {}
    kept = []
    for k in failed:
        if out.get(k) is None and prev.get(k) is not None:
            out[k] = prev[k]
            kept.append(k)
    out["errors"] = {k: v for k, v in failed.items() if k not in kept}
    out["stale"] = kept
    return out


# ------------------------------------------------------------------------------------------------ MARKET
@endpoint("market/assets", ttl=60, group="MARKET", plan=lambda: [dict(cls=c) for c in ASSET_CLS], valid=lambda d: any(r.get("price") is not None for r in d.get("rows", [])))
async def market_assets(cls: str = "ALL"):
    assets = ALL_ASSETS if cls == "ALL" else [a for a in ALL_ASSETS if a["cls"] == cls]
    return dict(rows=await _quotes_for(assets))


FX_EXTRA = {"HKD": "HKD=X", "KRW": "KRW=X", "TWD": "TWD=X", "BRL": "BRL=X"}


@endpoint("tools/fx", ttl=3600, group="MARKET", plan=_each(), valid=lambda d: bool(d.get("usd")))
async def tools_fx():
    """Nilai 1 unit mata uang dalam USD untuk mata uang kuotasi indeks yang tidak ada di daftar pair (HKD, KRW, TWD, BRL);
    dipakai kalkulator ukuran posisi. Yahoo "KRW=X" = USD/KRW, jadi 1 KRW = 1 / harga."""
    q = await yahoo.quotes(tuple(FX_EXTRA.values()))
    return dict(usd={c: 1.0 / q[s]["price"] for c, s in FX_EXTRA.items() if (q.get(s) or {}).get("price")})


@endpoint("market/heatmap", ttl=120, group="MARKET", plan=_each(), valid=lambda d: any(d.get("groups", {}).get(g) for g in HEATMAP_GROUPS))
async def market_heatmap():
    groups = {}
    names = [n for v in HEATMAP_GROUPS.values() for n in v]
    assets = [BY_SYM[n.upper()] for n in names if n.upper() in BY_SYM]
    q = await yahoo.quotes(tuple(a["y"] for a in assets))
    for g, ns in HEATMAP_GROUPS.items():
        groups[g] = [dict(sym=BY_SYM[n.upper()]["sym"], name=BY_SYM[n.upper()]["name"], price=q.get(BY_SYM[n.upper()]["y"], {}).get("price"), pct=q.get(BY_SYM[n.upper()]["y"], {}).get("pct"))
                     for n in ns if n.upper() in BY_SYM and q.get(BY_SYM[n.upper()]["y"])]
    try:
        ov = await rates.overview()
        groups["SOVEREIGN BONDS"] = [dict(sym=r["cc"], name=r["name"], price=r["y10"], pct=None) for r in ov["rows"] if r["y10"] is not None]
    except Exception:
        groups["SOVEREIGN BONDS"] = []
    return dict(groups=groups)


@endpoint("market/history", ttl=600, group="MARKET", plan=lambda: [dict(symbol="US500", range="1Y")],
          deep=lambda: [dict(symbol=a["sym"], range="1Y") for a in ALL_ASSETS if a["sym"] != "US500"], deep_ttl=3600, valid=_rows())
async def market_history(symbol: str, range: str = "1Y"):
    a = BY_SYM.get(symbol.upper())
    y = a["y"] if a else symbol
    rows = await yahoo.history(y, range)
    return dict(symbol=symbol, y=y, name=a["name"] if a else symbol, rows=rows)


# ------------------------------------------------------------------------------------------------ MACRO
@endpoint("macro/data", ttl=600, group="MACRO", plan=lambda: [dict(cc=c) for c in CCS], valid=_rows())
async def macro_data(cc: str = "US"):
    return dict(rows=await macro.data_rows(cc.upper()))


@endpoint("macro/overview", ttl=600, group="MACRO", plan=lambda: [dict(cc=c) for c in CCS])
async def macro_overview(cc: str = "US"):
    return await macro.overview(cc.upper())


@endpoint("macro/regime", ttl=900, group="MACRO", plan=lambda: [dict(cc=c) for c in CCS])
async def macro_regime(cc: str = "US"):
    r = await macro.regime(cc.upper())
    return dict(r, all=await macro.regime_map())


@endpoint("macro/compare", ttl=900, group="MACRO", plan=lambda: [dict(a="US", b="CN")], deep_ttl=3600,
          deep=lambda: [dict(a=a, b=b) for a in CCS for b in CCS if a != b and not (a == "US" and b == "CN")])
async def macro_compare(a: str = "US", b: str = "CN"):
    return await macro.compare(a.upper(), b.upper())


# ------------------------------------------------------------------------------------------------ CENTRAL BANK & FISCAL
@endpoint("cb/overview", ttl=900, group="CENTRAL BANK", plan=_each())
async def cb_overview():
    return await rates.overview()


@endpoint("cb/country", ttl=900, group="CENTRAL BANK", plan=lambda: [dict(cc=c) for c in CCS])
async def cb_country(cc: str = "US"):
    return await rates.country(cc.upper())


@endpoint("fiscal/overview", ttl=900, group="FISCAL", plan=_each())
async def fiscal_overview():
    return await fiscal.overview()


@endpoint("fiscal/country", ttl=900, group="FISCAL", plan=lambda: [dict(cc=c) for c in CCS])
async def fiscal_country(cc: str = "US"):
    return await fiscal.country(cc.upper())


# ------------------------------------------------------------------------------------------------ MARKET INTELLIGENCE
@endpoint("intel/feed", ttl=60, group="INTELLIGENCE", plan=_each(), cacheable=lambda p: not p["q"])
async def intel_feed(q: str = ""):
    if q:
        return dict(search=news.search(q))
    return dict(board=news.board(), status=news.status())


@endpoint("notify/key", store=False, group="SYSTEM")
async def notify_key():
    """Kunci publik VAPID untuk langganan push + apakah server mampu mengirim push."""
    from . import notify
    v = await asyncio.to_thread(notify.vapid)
    return dict(public=(v or {}).get("public"), push=notify.push_available() and bool(v), kinds=list(notify.KINDS), labels=notify.KIND_LABEL)


@endpoint("notify/events", store=False, group="SYSTEM")
async def notify_events(since: float = 0, kinds: str = "news,squawk,calendar,rates,curve,signal,liq"):
    """Kejadian notifikasi terbaru (cadangan polling saat halaman terbuka / push tidak tersedia). since=0 -> hanya waktu server."""
    from . import notify
    ks = tuple(k for k in kinds.split(",") if k in notify.KINDS)
    now = time.time()
    return dict(now=now, events=notify.events_since(float(since), ks) if since else [])


@endpoint("squawk", store=False, group="INTELLIGENCE")
async def squawk(since: float = 0, n: int = 80):
    """Headline tercepat untuk menu SQUAWK. Dipanggil tiap beberapa detik dengan since=<waktu terakhir> -> hanya item
    baru (biasanya 0-2 baris), jadi ringan lewat tunnel. Status sumber cepat ikut dikirim."""
    from .providers import xfeed, social
    fast = {name: dict(ok=name in news._state["ok"], n=news._state["ok"].get(name), error=news._state["errors"].get(name), every=sec)
            for name, sec in news.FAST.items()}
    return dict(items=news.squawk(since=float(since or 0), n=max(1, min(200, int(n or 80)))), now=time.time(), x=xfeed.status(), social=social.status(), sources=fast)


@endpoint("intel/catalysts", ttl=90, group="INTELLIGENCE", plan=_each())
async def intel_catalysts():
    cats = await catalyst.build_async()
    for c in cats:
        t = llm.stored("analysis", c["id"], llm.fingerprint(c["headlines"]))
        if t:
            c["analysis"] = t
    return dict(catalysts=cats, llm=llm.enabled(), llm_status=llm.status())


@endpoint("intel/map", ttl=90, group="INTELLIGENCE", plan=_each())
async def intel_map():
    cats = await catalyst.build_async()
    return dict(graph=catalyst.graph(cats), catalysts=cats[:10])


@endpoint("intel/research", ttl=90, group="INTELLIGENCE", plan=_each())
async def intel_research():
    cats = await catalyst.build_async()
    pubs = []
    for c in cats[:6]:
        body = c["text"] + " " + f"Terdeteksi {c['count']} headline dalam 36 jam terakhir dengan bias {c['bias'].lower()}."
        ai = llm.stored("research", c["id"], llm.fingerprint(c["headlines"]))
        pubs.append(dict(id=c["id"], title=c["title"], body=ai or body, ai=bool(ai), region=c["region"], asset=c["asset"], impact=c["impact"], ts=c["ts"], instruments=[i["sym"] for i in c["instruments"]]))
    return dict(publications=pubs, llm=llm.enabled(), llm_status=llm.status())


# ------------------------------------------------------------------------------------------------ ETF & FINANCIALS
@endpoint("etf/sectors", ttl=120, group="ETF", plan=_each(), valid=_rows())
async def etf_sectors():
    q = await yahoo.quotes(tuple(s for s, _ in SECTOR_ETFS))
    rows = []
    for s, name in SECTOR_ETFS:
        v = q.get(s)
        if v:
            rows.append(dict(sym=s, name=name, price=v["price"], pct=v["pct"], spark=v["spark"]))
    avg = sum(r["pct"] or 0 for r in rows) / len(rows) if rows else 0
    for r in rows:
        r["rel"] = (r["pct"] or 0) - avg
    adv = len([r for r in rows if (r["pct"] or 0) > 0])
    cyc = [r["pct"] or 0 for r in rows if r["sym"] in ("IXN", "RXI", "IXG", "EXI", "MXI", "IXC")]
    dfn = [r["pct"] or 0 for r in rows if r["sym"] in ("KXI", "IXJ", "JXI", "REET")]
    regime_txt = "RISK-ON" if cyc and dfn and sum(cyc) / len(cyc) > sum(dfn) / len(dfn) else "RISK-OFF"
    lead = max(rows, key=lambda r: r["pct"] or -99) if rows else None
    lag = min(rows, key=lambda r: r["pct"] or 99) if rows else None
    return dict(rows=rows, breadth=dict(adv=adv, total=len(rows)), regime=regime_txt, spread=(sum(cyc) / len(cyc) - sum(dfn) / len(dfn)) if cyc and dfn else None, leader=lead, laggard=lag)


@endpoint("etf/holdings", ttl=900, group="ETF", plan=lambda: [dict(etf="IXN")], deep=lambda: [dict(etf=s) for s, _ in SECTOR_ETFS if s != "IXN"], deep_ttl=3600, valid=_rows())
async def etf_holdings(etf: str = "IXN"):
    hold = await yahoo.etf_holdings(etf)
    q = await yahoo.quotes(tuple(h["symbol"] for h in hold)) if hold else {}
    for h in hold:
        v = q.get(h["symbol"]) or {}
        h["price"], h["pct"] = v.get("price"), v.get("pct")
    return dict(etf=etf, rows=hold)


@endpoint("financials", ttl=1800, group="FINANCIALS", plan=lambda: [dict(ticker="AAPL")], deep=lambda: [dict(ticker=t) for t in MEGA_CAPS], deep_ttl=6 * 3600)
async def financials(ticker: str = "AAPL"):
    return await yahoo.financials(ticker.upper().replace(".US", ""))


# ------------------------------------------------------------------------------------------------ MARKET PARTICIPANT
@endpoint("cot/meta", ttl=3600, group="PARTICIPANT", plan=_each())
async def cot_meta():
    return dict(tff=list(COT_TFF), disagg=list(COT_DISAGG), classes=COT_ASSET_CLASSES)


@endpoint("cot/instrument", ttl=3600, group="PARTICIPANT", plan=lambda: [dict(name="US Dollar Index")],
          deep=lambda: [dict(name=n) for n in list(COT_TFF) + list(COT_DISAGG) if n != "US Dollar Index"], deep_ttl=6 * 3600)
async def cot_instrument(name: str):
    return await cftc.instrument(cftc.kind_of(name), name, 104)


@endpoint("cot/class", ttl=3600, group="PARTICIPANT", plan=lambda: [dict(cls=c) for c in COT_ASSET_CLASSES])
async def cot_class(cls: str = "Currencies"):
    return dict(items=await cftc.asset_class_table(cls))


@endpoint("retail/table", ttl=60, group="PARTICIPANT", plan=_each())
async def retail_table():
    return dict(rows=myfxbook.latest_table(), status=myfxbook.status(), symbols=RETAIL_SYMBOLS)


@endpoint("retail/history", ttl=300, group="PARTICIPANT", plan=lambda: [dict(symbol="XAUUSD", days=14)],
          deep=lambda: [dict(symbol=s, days=14) for s in RETAIL_SYMBOLS if s != "XAUUSD"], deep_ttl=600)
async def retail_history(symbol: str = "XAUUSD", days: int = 14):
    rows = myfxbook.history(symbol, days)
    return dict(symbol=symbol, days=days, rows=rows, interval=myfxbook.POLL_EVERY, first=rows[0]["ts"] if rows else None, last=rows[-1]["ts"] if rows else None)


# ------------------------------------------------------------------------------------------------ GEOPOLITICAL
@endpoint("geo/overview", ttl=120, group="GEOPOLITICAL", plan=_each())
async def geo_overview():
    g = None
    with contextlib.suppress(Exception):
        g = await gpr.daily()
    hot = []
    with contextlib.suppress(Exception):
        hot = await geo.gdelt_hotspots()
    evs = geo.events()
    sev = {"CRITICAL": 0, "HIGH": 0, "ACTIVE": 0}
    for e in evs:
        sev[e["sev"]] += 1
    pw = []
    with contextlib.suppress(Exception):
        pw = await portwatch.summary()
    cps = geo.chokepoints()
    pwmap = portwatch.for_chokepoints(pw) if pw else {}
    for c in cps:
        c["pw"] = pwmap.get(c["id"])
    risk = await cpu.run(geo.risk_map, geo.events(400), hot)     # ratusan pencarian negara: di jalur komputasi, bukan event loop
    return dict(events=evs, chokepoints=cps, gpr=g, hotspots=hot, threat=sev, ais=ais.status(), portwatch=pw, risk=risk)


@endpoint("geo/sea", store=False, group="GEOPOLITICAL")
async def geo_sea(limit: int = 4000):
    """Layer MARITIME (bagian langsung): kapal AIS + choke point (berita & PortWatch) + insiden maritim dari berita."""
    pw = []
    with contextlib.suppress(Exception):
        pw = await portwatch.summary()
    cps = geo.chokepoints()
    pwmap = portwatch.for_chokepoints(pw) if pw else {}
    for c in cps:
        c["pw"] = pwmap.get(c["id"])
    return dict(vessels=ais.snapshot(None, min(limit, 6000)), status=ais.status(), chokepoints=cps, incidents=geo.maritime_events())


@endpoint("geo/sea_static", ttl=6 * 3600, group="GEOPOLITICAL", plan=_each(), valid=lambda d: bool(d.get("ports")))
async def geo_sea_static():
    """Layer MARITIME (bagian jarang berubah, dimuat sekali): 2.000+ pelabuhan + aktivitas 7h vs 28h, negara, rute pelayaran,
    28 choke point PortWatch."""
    return await portwatch.sea_static()


@endpoint("geo/air", store=False, group="GEOPOLITICAL")
async def geo_air():
    """Layer AIRPLANE: pesawat militer ADS-B + darurat 7700 + jumlah per negara + berita penerbangan."""
    return await airtraffic.layer()


@endpoint("geo/air_static", ttl=24 * 3600, group="GEOPOLITICAL", plan=_each(), valid=lambda d: bool(d.get("airports")))
async def geo_air_static():
    """Bandara dunia berkode IATA (dimuat sekali per sesi)."""
    return dict(airports=await portwatch.airports())


@endpoint("geo/cyber", ttl=900, group="GEOPOLITICAL", plan=_each(), valid=lambda d: bool(d.get("victims")))
async def geo_cyber():
    """Layer CYBER: korban ransomware 45 hari (ransomware.live) + serangan yang diberitakan pers + berita siber."""
    return await cyber.layer()


@endpoint("maritime", store=False, group="GEOPOLITICAL")
async def maritime(s: float = -90, w: float = -180, n: float = 90, e: float = 180, limit: int = 3500):
    return dict(vessels=ais.snapshot((s, w, n, e), min(limit, 6000)), status=ais.status())


# ------------------------------------------------------------------------------------------------ SUPPLY CHAIN
def _top_partners(cc, n=5):
    """Mitra dagang teratas dari snapshot overview (kode OEC; dipakai untuk memuat 'pair' tanpa menebak kode negara)."""
    d = S.previous("supply/overview", dict(cc=cc, flow="X")) or {}
    return [p["oid"] for p in (d.get("partners") or [])[:n] if p.get("oid")]


@endpoint("supply/overview", ttl=3600, group="SUPPLY CHAIN", plan=lambda: [dict(cc=c, flow="X") for c in CCS],
          deep=lambda: [dict(cc=c, flow="M") for c in CCS], deep_ttl=6 * 3600,
          valid=lambda d: bool(d.get("partners")) and all(p.get("oid") for p in d["partners"]))   # oid: format sejak kode mitra stabil
async def supply_overview(cc: str = "US", flow: str = "X"):
    return await trade.overview(cc.upper(), flow.upper())


@endpoint("supply/pair", ttl=6 * 3600, group="SUPPLY CHAIN", valid=lambda d: "trend" in d, deep=lambda: [dict(cc=c, oid=o) for c in CCS for o in _top_partners(c)])
async def supply_pair(cc: str = "US", partner: int = 0, oid: str = ""):
    return await trade.pair(cc.upper(), partner, oid.lower()[:8])


@endpoint("supply/sectors", ttl=3600, group="SUPPLY CHAIN", plan=lambda: [dict(cc=c, flow="X") for c in CCS],
          deep=lambda: [dict(cc=c, flow="M") for c in CCS], deep_ttl=6 * 3600)
async def supply_sectors(cc: str = "US", flow: str = "X"):
    return await trade.sectors(cc.upper(), flow.upper())


# ------------------------------------------------------------------------------------------------ QUANT
_QUANT_SYMS = [s for k, v in ASSET_CLASSES.items() if k != "BOND" for s, _, _ in v]


@endpoint("quant/asset", ttl=900, group="QUANT", plan=lambda: [dict(symbol="AUDCAD")], deep=lambda: [dict(symbol=s) for s in _QUANT_SYMS if s != "AUDCAD"], deep_ttl=3600)
async def quant_asset(symbol: str = "AUDCAD"):
    a = BY_SYM.get(symbol.upper())
    y = a["y"] if a else symbol
    return await quant.asset_bundle(y) | {"display": a["sym"] if a else symbol}


@endpoint("quant/assets", ttl=3600, group="QUANT", plan=_each())
async def quant_assets():
    return {k: [dict(sym=s, name=n) for s, _, n in v] for k, v in ASSET_CLASSES.items() if k != "BOND"}


@endpoint("quant/correlation", ttl=1800, group="QUANT", plan=_each())
async def quant_corr():
    return await quant.correlation_matrix()


@endpoint("quant/rolling", ttl=1800, group="QUANT", plan=lambda: [dict(a="EURUSD", b="GBPUSD")])
async def quant_rolling(a: str = "EURUSD", b: str = "GBPUSD"):
    ya = BY_SYM[a.upper()]["y"] if a.upper() in BY_SYM else a
    yb = BY_SYM[b.upper()]["y"] if b.upper() in BY_SYM else b
    return await quant.rolling_corr(ya, yb)


# ------------------------------------------------------------------------------------------------ FUTURES
@endpoint("futures/list", ttl=120, group="FUTURES", plan=lambda: [dict(group=g) for g in FUTURES_ROOTS], valid=lambda d: any(r.get("price") is not None for r in d.get("rows", [])))
async def futures_list(group: str = "COMMODITIES"):
    roots = FUTURES_ROOTS.get(group, [])
    q = await yahoo.quotes(tuple(f"{r}=F" for r, _, _ in roots))
    rows = []
    for r, e, n in roots:
        v = q.get(f"{r}=F") or {}
        rows.append(dict(root=r, exch=e, name=n, price=v.get("price"), chg=v.get("chg"), pct=v.get("pct"), volume=v.get("volume")))
    return dict(group=group, rows=rows)


@endpoint("futures/curve", ttl=900, group="FUTURES", plan=lambda: [dict(root="CL", exch="NYM")],
          deep=lambda: [dict(root=r, exch=e) for g in FUTURES_ROOTS.values() for r, e, _ in g if (r, e) != ("CL", "NYM")], deep_ttl=3600, valid=_rows())
async def futures_curve(root: str = "CL", exch: str = "NYM"):
    return dict(root=root, rows=await yahoo.futures_curve(root, exch))


# ------------------------------------------------------------------------------------------------ pencarian, status (selalu langsung, tidak disnapshot)
@endpoint("search", store=False, group="SYSTEM")
async def search(q: str):
    ql = q.lower().strip()
    if not ql:
        return dict(assets=[], news=[])
    assets = [dict(sym=a["sym"], name=a["name"], cls=a["cls"]) for a in ALL_ASSETS if ql in a["sym"].lower() or ql in a["name"].lower() or ql in a["y"].lower()][:12]
    return dict(assets=assets, news=news.search(q, 8))


@endpoint("ping", store=False, group="SYSTEM")
async def ping():
    return dict(t=time.time())


def snapshot_brief():
    s = S.summary()
    return dict(ready=s["ready"], planned=s["planned"], stored=s["stored"], failing=s["failing"], updated=s["updated"], phase=state["preload"]["phase"])


@endpoint("status", store=False, group="SYSTEM")
async def status():
    return dict(news=news.status(), retail=myfxbook.status(), ais=ais.status(), llm=llm.enabled(), llm_status=llm.status(), public_url=state["public_url"], uptime=int(time.time() - state["started"]),
                health=health.snapshot(), annual=annual.status(), snapshots=S.summary(), preload=state["preload"])


@endpoint("rev", store=False, group="SYSTEM")
async def rev():
    """Penanda perubahan data. Klien menyegarkan menu yang sedang dibuka hanya bila angka ini berubah."""
    return dict(rev=H.rev(), bad=health.snapshot()["bad"], snap=snapshot_brief())


@endpoint("health", store=False, group="SYSTEM")
async def api_health():
    from . import watchdog, notify
    from .heatmap import alerts as hm_alerts
    return dict(health.snapshot(), watchdog=watchdog.stats(), notify=notify.status(), heatmap_alerts=hm_alerts.status())


@endpoint("snapshots", store=False, group="SYSTEM")
async def snapshots(detail: int = 0):
    return dict(S.summary(bool(detail)), preload=state["preload"], db=str(config.DB_PATH))


# ------------------------------------------------------------------------------------------------ SIGNAL
SIG_DEFAULT = sigctl.DEFAULT_PAIRS
SIG_CLASSES = ["FX", "COMMODITY", "INDEX", "CRYPTO"]
# Endpoint yang hanya boleh dibaca admin (kunci ADMIN_KEY). User biasa mendapat 403: isi analisa bot, kontrol, dan status sumber data.
ADMIN_ONLY = {"signal/universe", "signal/catalog", "signal/pair", "signal/history", "signal/control", "signal/detail",
              "health", "status"} | hmroutes.ADMIN_ONLY
MODE_INFO = {
    "scalp": "Chart & analisa M5 (bias H1). Order pullback ditahan maks. ±4 jam. Data M5 publik hanya ±60 hari; sinyal sangat selektif.",
    "intraday": "Chart & analisa H1 (bias H4). Order pullback ditahan maks. ±2 hari.",
    "swing": "Chart & analisa D1 (bias W1). Order pullback ditahan maks. ±30 hari.",
}


@endpoint("signal/universe", ttl=3600, group="SIGNAL", plan=_each())
async def signal_universe():
    classes = {c: [dict(sym=a["sym"], name=a["name"]) for a in ALL_ASSETS if a["cls"] == c] for c in SIG_CLASSES}
    modes = [dict(id=m, label=SIG_MODES[m]["label"], tf=SIG_MODES[m]["tf"], htf=SIG_MODES[m]["htf_label"]) for m in SIG_MODE_ORDER]
    return dict(classes=classes, modes=modes, default=SIG_DEFAULT)


@endpoint("signal/catalog", store=False, group="SIGNAL")
async def signal_catalog():
    """SEMUA pair di terminal (FX, komoditas, indeks, kripto, obligasi) tanpa terkecuali: bahan menu PILIH PAIR (admin)."""
    order = ["FX", "COMMODITY", "INDEX", "CRYPTO", "BOND"]
    classes = {c: [dict(sym=a["sym"], name=a["name"]) for a in ALL_ASSETS if a["cls"] == c] for c in order}
    return dict(classes=classes, order=order, total=sum(len(v) for v in classes.values()), default=list(SIG_DEFAULT))


@endpoint("signal/pair", store=False, group="SIGNAL")
async def signal_pair(symbol: str, mode: str = "intraday", be: int = 1):
    """Analisa langsung satu pair (alat manual admin). Mengikuti saklar SINYAL: bila OFF, bot dilarang menganalisa."""
    if not sigctl.is_on():
        raise ValueError("SINYAL sedang OFF: bot dilarang menganalisa pair")
    return await sigsvc.analyze(symbol, mode, bool(be), new_ok=sigctl.is_on)


@endpoint("signal/history", store=False, group="SIGNAL")
async def signal_history(limit: int = 60, symbol: str = "", mode: str = ""):
    rows = sigjournal.recent(min(int(limit), 300), symbol or None, mode or None)
    out = [dict(id=r["id"], sym=r["sym"], mode=r["mode"], be=bool(r["be"]), side=r["side"], bar_ts=r["bar_ts"], status=r["status"], r=round(r["r"], 2), hits=r["tp_hits"],
                entry=r["plan"]["entry"], sl=r["plan"]["sl"], tp=r["plan"]["tp"], created=r["created"], closed=r["closed"]) for r in rows]
    return dict(rows=out, stats=sigjournal.stats(symbol or None, mode or None), by_mode={m: sigjournal.stats(symbol or None, m) for m in SIG_MODE_ORDER})


@endpoint("signal/board", store=False, group="SIGNAL")
async def signal_board(symbol: str = ""):
    """Menu SIGNAL (admin & user): list pair, chart live pair terpilih, order terbuka / limit / tertutup. Tidak memuat isi analisa."""
    return await sigboard.build(symbol)


@endpoint("signal/control", store=False, group="SIGNAL")
async def signal_control_state():
    """Status kontrol bot (admin): breakeven, sinyal ON/OFF, mode, pair terpilih + ringkasan dominasi 10 analisa tiap pair."""
    c = sigctl.get()
    modes = [dict(id=m, label=SIG_MODES[m]["label"], tf=SIG_MODES[m]["tf"], htf=SIG_MODES[m]["htf_label"], info=MODE_INFO[m]) for m in SIG_MODE_ORDER]
    return dict(on=c["on"], be=c["be"], mode=c["mode"], mode_label=SIG_MODES[c["mode"]]["label"], tf=SIG_MODES[c["mode"]]["tf"], pairs=c["pairs"], rev=c["rev"], modes=modes,
                strategy=c.get("strategy", "multi"), strategies=[dict(id=k, label=v) for k, v in sigctl.STRATEGIES.items()],
                overview=sigrun.overview(), status=sigrun.status())


@endpoint("signal/detail", store=False, group="SIGNAL")
async def signal_detail(symbol: str):
    """Halaman INSIDE/ANALISIS (admin): 10 kartu analisa + teks alasan untuk satu pair."""
    return sigrun.detail(symbol)


@endpoint("thinking/state", store=False, group="THINKING")
async def thinking_state():
    """Status 6 agent untuk menu THINKING (admin & user, hanya informasi)."""
    st = agentbus.state()
    st["signal"] = sigrun.status()
    try:
        from .analytics import world as WD
        w = await WD.snapshot()
        st["world"] = dict(lines=WD.summary(w, limit=8), sources=w.get("sources"), ts=w.get("ts"),
                           shocks=[dict(type=e["type"], sev=e["sev"], title=e["title"], place=e["place"], ts=e["ts"], sources=len(e["sources"]))
                                   for e in (w.get("shocks") or [])[:10]],
                           woken=[dict(sym=k, at=v[0], reason=v[1]) for k, v in sorted(sigrun.WOKEN.items(), key=lambda kv: -kv[1][0])[:6]])
    except Exception as exc:
        st["world"] = dict(error=type(exc).__name__)
    return st


@endpoint("agent/world", store=False, group="THINKING")
async def agent_world():
    """Konteks dunia lengkap yang dibaca agent (risiko, choke point, pelabuhan, pesawat, siber, kejadian mendadak)."""
    from .analytics import world as WD
    w = await WD.snapshot()
    return dict(ts=w["ts"], summary=WD.summary(w, limit=12), sources=w["sources"], shocks=w["shocks"], chokepoints=w["chokepoints"],
                risk=dict(sorted(w["risk"].items(), key=lambda kv: -kv[1].get("score", 0))[:15]), ports=dict(date=(w.get("ports") or {}).get("date")),
                air=w["air"], cyber=w["cyber"])
