"""Tata letak 7 terminal (dipakai start.bat, tools/arrange_terminals.py, terminal agent, dan server).

Grid 3x3 area kerja monitor utama (taskbar tidak tertutup):

    +-----------------+-----------------+--------------------+
    | NEWS AGENT      | TEKNIKAL AGENT  | FUNDAMENTAL AGENT  |   baris 1
    +-----------------+-----------------+--------------------+
    | VOLUME AGENT    | QUANT AGENT     | TERMINAL SERVER    |   baris 2
    +-----------------+-----------------+--------------------+
    | FEBRIAN AGENT   |   (kosong)      |   (kosong)         |   baris 3
    +-----------------+-----------------+--------------------+

Modul ini sengaja tanpa dependensi (tidak mengimpor config/dotenv) supaya bisa dipakai skrip penata jendela.
"""
from __future__ import annotations

SERVER_TITLE = "TERMINAL SERVER (UTAMA)"

# (judul jendela, kolom, baris) -- kolom/baris mulai dari 0
WINDOWS = (
    ("NEWS AGENT", 0, 0),
    ("TEKNIKAL AGENT", 1, 0),
    ("FUNDAMENTAL AGENT", 2, 0),
    ("VOLUME AGENT", 0, 1),
    ("QUANT AGENT", 1, 1),
    (SERVER_TITLE, 2, 1),
    ("FEBRIAN AGENT", 0, 2),
)
TITLES = tuple(w[0] for w in WINDOWS)
GRID = 3

# id agent (terminal/agents/bus.py) -> judul jendela terminalnya
AGENT_TITLES = {
    "news": "NEWS AGENT",
    "technical": "TEKNIKAL AGENT",
    "fundamental": "FUNDAMENTAL AGENT",
    "volume": "VOLUME AGENT",
    "quant": "QUANT AGENT",
    "febrian": "FEBRIAN AGENT",
}


def cells(left: int, top: int, right: int, bottom: int):
    """Posisi piksel tiap jendela di area kerja (left, top, right, bottom).

    Mengembalikan daftar (judul, kolom, baris, x, y, lebar, tinggi). Kolom/baris terakhir menyerap sisa piksel
    pembagian supaya grid menutup area kerja persis tanpa celah.
    """
    width, height = right - left, bottom - top
    cw, ch = width // GRID, height // GRID
    out = []
    for title, col, row in WINDOWS:
        x = left + col * cw
        y = top + row * ch
        w = (right - x) if col == GRID - 1 else cw
        h = (bottom - y) if row == GRID - 1 else ch
        out.append((title, col, row, x, y, w, h))
    return out


def title_matches(window_title: str, target: str) -> bool:
    """Cocokkan judul jendela konsol dengan target.

    cmd.exe dapat menambah awalan ("Administrator: ") dan akhiran (" - "C:\\...\\python.exe" -m ...") pada judul,
    jadi yang dicek: target muncul di awal judul setelah awalan "xxx: " dibuang.
    """
    t = (window_title or "").strip().upper()
    tgt = target.strip().upper()
    if t.startswith(tgt):
        return True
    if ": " in t:
        rest = t.split(": ", 1)[1].lstrip()
        return rest.startswith(tgt)
    return False


def set_console_title(title: str) -> None:
    """Ganti judul jendela konsol (Windows) agar penata jendela selalu menemukannya. No-op di OS lain."""
    import os
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.kernel32.SetConsoleTitleW(str(title))
    except Exception:
        pass
