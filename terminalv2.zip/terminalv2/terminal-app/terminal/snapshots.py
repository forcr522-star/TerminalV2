"""Snapshot respons API: semua menu/fitur dimuat sekali, disimpan di SQLite (data/terminal.db), lalu dilayani instan.

Alur:
  - Setiap endpoint /api/... didaftarkan lewat @endpoint (lihat terminal/api.py) dengan TTL dan daftar parameter
    yang harus dimuat (plan = tahap 1: semua menu & tab; deep = tahap 2: ekor panjang seperti semua simbol).
  - Saat start, preload.py memuat semua `plan` dan menyimpannya di sini. Snapshot juga dibaca kembali dari DB saat
    restart, jadi pengunjung baru (atau Anda yang masuk ulang) langsung mendapat data tanpa memuat apa pun.
  - Permintaan ke /api/... dilayani dari snapshot. Bila umurnya melewati TTL, pembaruan berjalan di latar belakang
    (stale-while-revalidate); pengunjung tidak menunggu.
  - Snapshot hanya diganti oleh hasil yang BERHASIL dan lengkap. Sumber yang sedang gagal tidak menimpa data baik.
  - Snapshot yang isinya berubah menaikkan `rev` sehingga browser menyegarkan tampilan yang sedang dibuka.
"""
import asyncio
import contextlib
import contextvars
import hashlib
import inspect
import json
import time
import traceback
import zlib
from urllib.parse import urlencode

from . import config, store
from . import http as H

ENDPOINTS = {}
JOBS = {}        # key -> Job  (semua snapshot yang diperbarui otomatis)
_mem = {}        # key -> Snap (salinan RAM dari DB)
_inflight = {}   # key -> asyncio.Task
_bg = contextvars.ContextVar("snapshot_background", default=False)
auto_refresh = False   # pembaruan otomatis baru menyala setelah preload tahap 1 selesai (lihat enable())
MAX_UNPLANNED_PER_ENDPOINT = 300
UNPLANNED_IDLE_DAYS = 1.0
# Batas snapshot di RAM (dari sesi sebelumnya). DB tetap menyimpan semuanya; yang dibuang dari RAM dimuat ulang
# dari DB saat pertama diminta, jadi tampilan tidak kosong.
MAX_MEM_SNAPS = 1500
# Snapshot lama yang memuat item dari sumber berita yang sudah tidak ditampilkan dibuang saat start (dihitung ulang
# otomatis), supaya tampilan tidak sempat memperlihatkan data lama setelah pembaruan program.
RETIRED_MARKERS = (b'"source":"Polymarket"',)


class ParamError(ValueError):
    pass


class Snap:
    __slots__ = ("body", "ts", "hash", "ms")

    def __init__(self, body, ts, digest, ms):
        self.body, self.ts, self.hash, self.ms = body, ts, digest, ms


class Job:
    __slots__ = ("key", "path", "params", "planned", "phase", "group", "ttl", "fails", "next_try", "last_error", "last_hit", "last_try")

    def __init__(self, key, path, params, planned, phase, group, ttl):
        self.key, self.path, self.params, self.planned, self.phase, self.group, self.ttl = key, path, params, planned, phase, group, ttl
        self.fails, self.next_try, self.last_error, self.last_hit, self.last_try = 0, 0.0, None, time.time(), 0.0


class Result:
    __slots__ = ("ok", "body", "error", "empty", "changed", "ms")

    def __init__(self, ok, body, error=None, empty=False, changed=False, ms=0):
        self.ok, self.body, self.error, self.empty, self.changed, self.ms = ok, body, error, empty, changed, ms


# ------------------------------------------------------------------------------------------------ endpoint registry
class Endpoint:
    def __init__(self, path, fn, ttl, group, plan, deep, deep_ttl, valid, cacheable, store_snap):
        self.path, self.fn, self.ttl, self.group = path, fn, ttl, group or path.split("/")[0].upper()
        self.plan, self.deep, self.deep_ttl, self.valid, self.cacheable, self.store = plan, deep, deep_ttl or ttl, valid, cacheable, store_snap
        self.sig = inspect.signature(fn)

    def canon(self, raw):
        """Ubah query string mentah menjadi parameter bertipe + nilai bawaan (kunci snapshot kanonik)."""
        out = {}
        for name, p in self.sig.parameters.items():
            ann = p.annotation
            if ann is inspect._empty:
                ann = type(p.default) if p.default is not inspect._empty and p.default is not None else str
            if name in raw and raw[name] is not None:
                v = raw[name]
                try:
                    out[name] = v if ann is str else ann(v)
                except (TypeError, ValueError):
                    raise ParamError(f"parameter '{name}' tidak valid")
            elif p.default is not inspect._empty:
                out[name] = p.default
            else:
                raise ParamError(f"parameter '{name}' wajib")
        return out


def endpoint(path, ttl=300, group=None, plan=None, deep=None, deep_ttl=None, valid=None, cacheable=None, store=True):
    """Daftarkan endpoint. plan/deep: fungsi tanpa argumen yang mengembalikan daftar dict parameter untuk dimuat di tahap 1/2."""
    def deco(fn):
        ENDPOINTS[path] = Endpoint(path, fn, ttl, group, plan, deep, deep_ttl, valid, cacheable, store)
        return fn
    return deco


def enable():
    global auto_refresh
    auto_refresh = True


def age(k):
    """Umur snapshot dalam detik, atau None bila belum ada."""
    s = _mem.get(k)
    return None if s is None else time.time() - s.ts


def key_of(path, params):
    return path + "?" + urlencode(sorted((k, str(v)) for k, v in params.items()))


def _default(o):
    if hasattr(o, "item"):
        return o.item()
    if hasattr(o, "isoformat"):
        return o.isoformat()
    if isinstance(o, (set, frozenset)):
        return sorted(o)
    raise TypeError(f"{type(o).__name__} tidak bisa diubah ke JSON")


def clean(o):
    if isinstance(o, float):
        return None if o != o or o in (float("inf"), float("-inf")) else o
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    return o


def encode(data):
    return json.dumps(clean(data), separators=(",", ":"), ensure_ascii=False, default=_default, allow_nan=False).encode("utf-8")


def err_body(exc_or_msg):
    msg = exc_or_msg if isinstance(exc_or_msg, str) else f"{type(exc_or_msg).__name__}: {str(exc_or_msg)[:220]}"
    return encode({"error": msg})


def is_background():
    return _bg.get()


# ------------------------------------------------------------------------------------------------ penyimpanan
def load():
    """Baca semua snapshot dari DB ke RAM (dipanggil saat start). Mengembalikan jumlah yang dimuat."""
    n = 0
    try:
        rows = store.snap_all()
    except Exception:
        traceback.print_exc()
        return 0
    for r in rows:
        ep = ENDPOINTS.get(r["path"])
        if ep is None or not ep.store:
            with contextlib.suppress(Exception):
                store.snap_delete(r["k"])
            continue
        try:
            body = zlib.decompress(r["body"])
            params = json.loads(r["params"])
            parsed = json.loads(body)  # DB rusak -> buang, akan dimuat ulang
            # snapshot dari versi lama yang tidak lagi memenuhi syarat data endpoint (mis. format berubah) -> dimuat ulang
            if ep.valid is not None and isinstance(parsed, dict) and not parsed.get("error") and not ep.valid(parsed):
                raise ValueError("format lama")
        except Exception:
            with contextlib.suppress(Exception):
                store.snap_delete(r["k"])
            continue
        phase = int(r["planned"] or 0)   # kolom `planned`: 0 = hasil permintaan pengunjung, 1/2 = tahap rencana
        if any(m in body for m in RETIRED_MARKERS):
            with contextlib.suppress(Exception):
                store.snap_delete(r["k"])
            if phase:                    # snapshot terencana: tetap terdaftar agar langsung dihitung ulang
                JOBS[r["k"]] = Job(r["k"], r["path"], params, True, phase, ep.group, ep.deep_ttl if phase == 2 else ep.ttl)
            continue
        _mem[r["k"]] = Snap(body, r["ts"], r["hash"], r["ms"] or 0)
        JOBS[r["k"]] = Job(r["k"], r["path"], params, phase > 0, phase or 3, ep.group, ep.deep_ttl if phase == 2 else ep.ttl)
        n += 1
    # Semua pekerjaan tetap terdaftar (refresher tahu apa yang perlu diperbarui), tetapi isi RAM dibatasi:
    # simpan yang terbaru, sisanya dibaca ulang dari DB saat diminta (tidak ada tampilan kosong).
    if len(_mem) > MAX_MEM_SNAPS:
        for k in sorted(_mem, key=lambda x: _mem[x].ts)[: len(_mem) - MAX_MEM_SNAPS]:
            _mem.pop(k, None)
    return n


def register(ep, params, phase, planned=True):
    """Daftarkan satu pekerjaan snapshot. Mengembalikan Job."""
    k = key_of(ep.path, params)
    ttl = ep.ttl if phase == 1 else ep.deep_ttl
    j = JOBS.get(k)
    if j is None:
        j = JOBS[k] = Job(k, ep.path, params, planned, phase, ep.group, ttl)
    else:
        if planned and not j.planned or phase < j.phase:
            j.planned, j.phase = True, min(j.phase, phase)
        j.ttl = ttl if phase >= j.phase else j.ttl
    return j


def plan_jobs(phase):
    """Daftarkan & kembalikan pekerjaan terencana untuk tahap 1 (plan) atau 2 (deep)."""
    out = []
    for ep in ENDPOINTS.values():
        gen = ep.plan if phase == 1 else ep.deep
        if not gen or not ep.store:
            continue
        try:
            items = gen() or []
        except Exception:
            traceback.print_exc()
            continue
        for raw in items:
            try:
                params = ep.canon({k: v for k, v in raw.items()})
            except ParamError:
                continue
            k = key_of(ep.path, params)
            existing = JOBS.get(k)
            if existing and existing.phase < phase and existing.planned:
                out.append(existing)   # sudah terdaftar di tahap lebih awal
                continue
            out.append(register(ep, params, phase))
    return out


def _load_one(k):
    """Muat satu snapshot dari DB ke RAM (dipakai bila isi RAM sudah dibatasi)."""
    try:
        r = store.snap_get(k)
    except Exception:
        return None
    if not r:
        return None
    try:
        body = zlib.decompress(r["body"])
        json.loads(body)
    except Exception:
        with contextlib.suppress(Exception):
            store.snap_delete(k)
        return None
    s = Snap(body, r["ts"], r["hash"], r["ms"] or 0)
    _mem[k] = s
    return s


def get(path, params):
    ep = ENDPOINTS[path]
    return _mem.get(key_of(path, ep.canon(params)))


def previous(path, params):
    """Data JSON snapshot sebelumnya (dict) atau None. Dipakai endpoint yang mau mempertahankan bagian yang masih baik."""
    s = get(path, params)
    if not s:
        return None
    try:
        return json.loads(s.body)
    except Exception:
        return None


async def _persist(job, body, now, digest, ms, changed):
    try:
        if changed:
            await asyncio.to_thread(store.snap_put, job.key, job.path, json.dumps(job.params), zlib.compress(body, 3), now, digest, ms, job.phase if job.planned else 0)
        else:
            await asyncio.to_thread(store.snap_touch, job.key, now, ms, job.phase if job.planned else 0)
    except Exception:
        traceback.print_exc()


def _evict(ep):
    """Batasi snapshot hasil permintaan pengunjung (bukan rencana) per endpoint agar DB tidak membengkak."""
    mine = [j for j in JOBS.values() if j.path == ep.path and not j.planned]
    if len(mine) <= MAX_UNPLANNED_PER_ENDPOINT:
        return
    mine.sort(key=lambda j: j.last_hit)
    for j in mine[: len(mine) - MAX_UNPLANNED_PER_ENDPOINT]:
        drop(j.key)


def drop(k):
    JOBS.pop(k, None)
    _mem.pop(k, None)
    with contextlib.suppress(Exception):
        store.snap_delete(k)


# ------------------------------------------------------------------------------------------------ pembaruan
async def _compute(ep, params, force):
    t0 = time.time()
    cm = H.force_refresh() if force else contextlib.nullcontext()
    with cm:
        data = await ep.fn(**params)
    return data, int((time.time() - t0) * 1000)


async def _do_refresh(ep, params, k, force, timeout, bg):
    tok = _bg.set(bg)
    try:
        job = JOBS.get(k)
        if job:
            job.last_try = time.time()
        try:
            coro = _compute(ep, params, force)
            data, ms = await (asyncio.wait_for(coro, timeout) if timeout else coro)
        except Exception as exc:
            return _fail(k, f"{type(exc).__name__}: {str(exc)[:200] or 'timeout'}", err_body(exc))
        if isinstance(data, dict) and data.get("error"):
            return _fail(k, str(data["error"])[:200], encode(data))
        try:
            body = encode(data)
        except Exception as exc:
            return _fail(k, f"{type(exc).__name__}: {str(exc)[:200]}", err_body(exc))
        if ep.valid is not None:
            try:
                good = bool(ep.valid(data))
            except Exception:
                good = False
            if not good:
                return _fail(k, "data kosong/tidak lengkap", body, empty=True)
        if ep.cacheable is not None and not ep.cacheable(params):
            return Result(True, body, ms=ms)
        now = time.time()
        digest = hashlib.sha1(body).hexdigest()
        old = _mem.get(k)
        changed = old is None or old.hash != digest
        job = JOBS.get(k) or register(ep, params, 3, planned=False)
        _mem[k] = Snap(body, now, digest, ms)
        job.fails, job.last_error, job.next_try = 0, None, 0.0
        if changed:
            H.bump()
        await _persist(job, body, now, digest, ms, changed)
        if not job.planned:
            _evict(ep)
        return Result(True, body, changed=changed, ms=ms)
    finally:
        _bg.reset(tok)
        _inflight.pop(k, None)


def _fail(k, msg, body, empty=False):
    job = JOBS.get(k)
    if job:
        job.fails += 1
        job.last_error = msg
        job.next_try = time.time() + min(900, 30 * 2 ** min(job.fails - 1, 5))
    return Result(False, body, error=msg, empty=empty)


async def refresh(path, params, force=False, timeout=None, bg=False):
    """Hitung ulang satu snapshot (tunggal per kunci: panggilan serentak berbagi satu pekerjaan). Tidak pernah melempar error."""
    ep = ENDPOINTS[path]
    k = key_of(path, params)
    task = _inflight.get(k)
    if task is None:
        task = _inflight[k] = asyncio.ensure_future(_do_refresh(ep, params, k, force, timeout, bg))
    return await asyncio.shield(task)


async def serve(path, raw_params):
    """Layani satu permintaan API. Mengembalikan (body_json_bytes, status_cache)."""
    ep = ENDPOINTS[path]
    params = ep.canon(raw_params)
    if not ep.store or (ep.cacheable is not None and not ep.cacheable(params)):
        try:
            data, _ = await _compute(ep, params, False)
            return encode(data), "live"
        except ParamError:
            raise
        except Exception as exc:
            return err_body(exc), "live"
    k = key_of(path, params)
    snap = _mem.get(k)
    if snap is None:
        snap = _load_one(k)          # isi RAM dibatasi: ambil lagi dari DB bila sudah dibuang
    job = JOBS.get(k)
    if snap:
        if job is None:
            job = register(ep, params, 3, planned=False)
        job.last_hit = time.time()
        if time.time() - snap.ts > job.ttl and k not in _inflight and time.time() >= job.next_try:
            asyncio.ensure_future(refresh(path, params, force=True, timeout=config.JOB_TIMEOUT, bg=True))
        return snap.body, "hit"
    res = await refresh(path, params)
    j = JOBS.get(k)
    if j:
        j.last_hit = time.time()
    return res.body, "miss" if res.ok else "uncached"


def _due(now):
    out = []
    for k, j in list(JOBS.items()):
        if k in _inflight or now < j.next_try:
            continue
        snap = _mem.get(k)
        if not j.planned and now - j.last_hit > UNPLANNED_IDLE_DAYS * 86400:
            drop(k)
            continue
        age = now - snap.ts if snap else float("inf")
        if age >= j.ttl:
            out.append((j.phase, -(min(age, 1e9) / max(j.ttl, 1)), k))
    out.sort()
    return [JOBS[k] for _, _, k in out if k in JOBS]


async def refresher(interval=5.0):
    """Pembaruan otomatis: tiap `interval` detik, snapshot yang melewati TTL dihitung ulang (paralel terbatas)."""
    running = set()
    while True:
        await asyncio.sleep(interval)
        if not auto_refresh:
            continue
        try:
            from .signals import runner as _sigrun
            if _sigrun.paused():          # menu BACKTEST berjalan: seluruh pembaruan menu lain dijeda agar PC ringan
                continue
        except Exception:
            pass
        try:
            room = config.REFRESH_CONCURRENCY - len(running)
            if room <= 0:
                continue
            for j in _due(time.time())[:room]:
                t = asyncio.ensure_future(refresh(j.path, j.params, force=True, timeout=config.JOB_TIMEOUT, bg=True))
                running.add(t)
                t.add_done_callback(running.discard)
        except asyncio.CancelledError:
            raise
        except Exception:
            traceback.print_exc()


# ------------------------------------------------------------------------------------------------ ringkasan
def summary(detail=False):
    now = time.time()
    groups = {}
    total = ready = stale = planned = 0
    nbytes = 0
    newest = oldest = None
    for k, j in JOBS.items():
        if not j.planned:
            continue
        planned += 1
        g = groups.setdefault(j.group, dict(total=0, ready=0, stale=0, failing=0))
        g["total"] += 1
        s = _mem.get(k)
        if s:
            g["ready"] += 1
            age = now - s.ts
            if age > j.ttl * 3:
                g["stale"] += 1
            newest = s.ts if newest is None else max(newest, s.ts)
            oldest = s.ts if oldest is None else min(oldest, s.ts)
        if j.fails:
            g["failing"] += 1
    for k, s in _mem.items():
        total += 1
        nbytes += len(s.body)
    ready = sum(g["ready"] for g in groups.values())
    out = dict(stored=total, planned=planned, ready=ready, bytes=nbytes, updated=newest, oldest=oldest, groups=groups,
               failing=sum(g["failing"] for g in groups.values()), inflight=len(_inflight))
    if detail:
        out["items"] = [dict(key=k, group=j.group, phase=j.phase, planned=j.planned, ttl=j.ttl, age=(round(now - _mem[k].ts) if k in _mem else None),
                             ms=(_mem[k].ms if k in _mem else None), bytes=(len(_mem[k].body) if k in _mem else 0), fails=j.fails, error=j.last_error)
                        for k, j in sorted(JOBS.items())]
    return out


def reset():
    """Dipakai pengujian: kosongkan RAM (DB dibersihkan terpisah)."""
    global auto_refresh
    auto_refresh = False
    _mem.clear()
    JOBS.clear()
    _inflight.clear()
