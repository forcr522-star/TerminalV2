"""Bus status agent bersama (database kv) — dibaca menu THINKING dan seluruh terminal agent.

State:
  agents: {id: {id, name, icon, role, status, activity, task, progress, updated, pid, alive}}
  logs:   daftar {at, agent, level, text} (maks. 200 terakhir)
  pulses: daftar {at, src, dst, kind, text} (maks. 60; dipakai animasi kabel THINKING)

Status: "idle" (nganggur), "work" (sedang analisa), "ok", "error", "off" (terminal agent tidak hidup).
"""
import json
import os
import threading
import time

from .. import store

KEY = "agents_state"
LOCK = threading.RLock()
MAX_LOGS = 200
MAX_PULSES = 60
ALIVE_AFTER = 12.0     # detik tanpa heartbeat -> dianggap off (mode proses terpisah)
# Mode SATU TERMINAL (bawaan): agent berjalan di dalam proses server. State disimpan di memori dan ditulis ke database
# paling sering tiap SAVE_EVERY detik - dulu 6 proses menulis JSON state ke SQLite berkali-kali per detik.
INPROC = False
ALIVE_INPROC = 90.0    # agent satu terminal punya jeda berbeda (berita 30 dtk, fundamental 45 dtk)
SAVE_EVERY = 5.0
_mem = None
_dirty = False
_last_save = 0.0

AGENTS = [
    dict(id="news", name="NEWS & DATA", icon="📰", role="Memantau berita, katalis, data ekonomi, grafik & sumber data."),
    dict(id="technical", name="TEKNIKAL", icon="📊", role="Analisa teknikal: tren, breakout, pullback, struktur."),
    dict(id="fundamental", name="FUNDAMENTAL", icon="💰", role="Penyaring fundamental: rate/yield, COT, berita, event."),
    dict(id="volume", name="VOLUME / LIQUIDITY", icon="📦", role="Validasi volume profile, likuiditas, level entry/SL/TP."),
    dict(id="quant", name="QUANTITATIVE", icon="∑", role="Probabilitas, rezim, statistik, dan konfirmasi akhir."),
    dict(id="febrian", name="FEBRIAN DEVELOPER", icon="👤", role="Pengontrol: meminta analisa, mengatur risiko, memutuskan BUY/SELL/WAIT."),
]
IDS = [a["id"] for a in AGENTS]
META = {a["id"]: a for a in AGENTS}


def _blank():
    return dict(agents={i: dict(META[i], status="off", activity="terminal agent belum dijalankan", task=None, progress=None,
                                updated=None, pid=None, alive=False) for i in IDS}, logs=[], pulses=[], updated=None)


def _load():
    global _mem
    if INPROC:
        if _mem is None:
            _mem = _read()
        return _mem
    return _read()


def _read():
    st = store.kv_get(KEY)
    if not isinstance(st, dict) or "agents" not in st:
        return _blank()
    base = _blank()
    base["agents"].update({k: dict(base["agents"].get(k, {}), **v) for k, v in (st.get("agents") or {}).items() if k in META})
    base["logs"] = list(st.get("logs") or [])[-MAX_LOGS:]
    base["pulses"] = list(st.get("pulses") or [])[-MAX_PULSES:]
    base["updated"] = st.get("updated")
    return base


def _save(st):
    global _dirty
    st["updated"] = time.time()
    if not INPROC:
        store.kv_set(KEY, st)
        return
    _dirty = True
    if time.time() - _last_save >= SAVE_EVERY:
        flush()


def flush():
    """Tulis state memori ke database (mode satu terminal)."""
    global _dirty, _last_save
    if not INPROC or _mem is None or not _dirty:
        return
    _dirty, _last_save = False, time.time()
    try:
        store.kv_set(KEY, _mem)
    except Exception:
        _dirty = True


def reset():
    with LOCK:
        _save(_blank())


def update(agent, status=None, activity=None, task=None, progress=None, pid=None):
    if agent not in META:
        return
    with LOCK:
        st = _load()
        a = st["agents"][agent]
        if status is not None:
            a["status"] = status
        if activity is not None:
            a["activity"] = str(activity)[:240]
        if task is not None:
            a["task"] = str(task)[:160]
        if progress is not None:
            a["progress"] = max(0.0, min(1.0, float(progress)))
        if pid is not None:
            a["pid"] = int(pid)
        a.update(updated=time.time(), alive=True)
        _save(st)


def heartbeat(agent):
    update(agent)


def log(agent, text, level="info"):
    with LOCK:
        st = _load()
        st["logs"].append(dict(at=time.time(), agent=agent, level=level, text=str(text)[:300]))
        st["logs"] = st["logs"][-MAX_LOGS:]
        _save(st)


def pulse(src, dst, kind="data", text=""):
    if src not in META or dst not in META:
        return
    with LOCK:
        st = _load()
        st["pulses"].append(dict(at=time.time(), src=src, dst=dst, kind=kind, text=str(text)[:160]))
        st["pulses"] = st["pulses"][-MAX_PULSES:]
        _save(st)


def state():
    """Snapshot untuk menu THINKING / agent utama. Agent yang heartbeat-nya basi ditandai off."""
    with LOCK:
        st = json.loads(json.dumps(_load()))      # salinan: penandaan "off" tidak boleh mengubah state memori
    now = time.time()
    for a in st["agents"].values():
        a["alive"] = bool(a.get("updated") and now - a["updated"] <= (ALIVE_INPROC if INPROC else ALIVE_AFTER))
        if not a["alive"]:
            a["status"] = "off"
            a["activity"] = "terminal agent tidak aktif"
    st["active"] = [i for i in IDS if st["agents"][i]["alive"]]
    st["now"] = now
    return st


def awaken(agent, status="ok"):
    """Dipakai proses server (tanpa terminal agent) agar THINKING tetap menunjukkan agent hidup bila batch belum dijalankan."""
    update(agent, status=status, activity="menunggu perintah", pid=os.getpid())