"""Satu terminal = satu agent. Dijalankan oleh start.bat:

  python -m terminal.agents.run news
  python -m terminal.agents.run technical
  python -m terminal.agents.run fundamental
  python -m terminal.agents.run volume
  python -m terminal.agents.run quant
  python -m terminal.agents.run febrian

Setiap agent memperbarui status di bus (dibaca menu THINKING) dan mencetak baris status di terminalnya sendiri.
Agent FEBRIAN (pengontrol) punya jendela sendiri (baris 3, kolom 1 grid); server & Cloudflare ada di jendela
TERMINAL SERVER (UTAMA). Lihat terminal/layout.py.
"""
import asyncio
import os
import sys
import time
import traceback

from . import bus
from .bus import META, IDS
from .. import layout


def _say(agent, line):
    # Tanpa emoji: font konsol Windows (Consolas/Raster) menampilkannya sebagai kotak kosong.
    a = META[agent]
    print(f"{time.strftime('%H:%M:%S')} {a['name']} - {line}", flush=True)


async def _news():
    from terminal.providers import news
    from terminal.analytics import catalyst
    bus.update("news", "work", activity="merangkum feed berita & katalis", task="news/catalyst")
    if bus.INPROC:
        # Satu terminal: feed diperbarui server tiap 90 dtk (server._news_job). Agent hanya merangkum - dulu agent ini
        # mengunduh 42 feed SENDIRI tiap ±6 dtk (±7 permintaan/detik), memicu pembatasan & "sumber bermasalah".
        if not news._items:
            news.load_cached()
    else:
        await news.refresh()
    cats = await catalyst.build_async()
    n = len(getattr(news, "_items", []) or [])
    bus.update("news", "ok", activity=f"{n} berita · {len(cats or [])} katalis", task=None, progress=1.0)
    bus.log("news", f"feed diperbarui: {n} berita, {len(cats or [])} katalis")
    bus.pulse("news", "fundamental", "data", "feed berita & katalis")
    bus.pulse("news", "febrian", "data", "ringkasan berita")


async def _technical():
    from terminal.signals import runner, control, service
    from terminal import snapshots as S
    c = control.get()
    res = runner.RESULTS
    if not c["pairs"]:
        bus.update("technical", "idle", activity="belum ada pair dipilih")
        return
    sym = c["pairs"][0]
    r = res.get(sym)
    if r and (r.get("mode") != c["mode"] or bool(r.get("be")) != bool(c["be"])):
        r = None
    if r is None and time.time() - _own.get(("technical", sym, c["mode"]), 0) < OWN_EVERY:
        bus.update("technical", "idle", activity=f"menunggu analisa runner {sym}")
        return
    if r is None:
        # Hanya bila runner sinyal belum menganalisa pair ini (mis. SINYAL OFF): sendiri, maks. sekali per OWN_EVERY.
        _own[("technical", sym, c["mode"])] = time.time()
        bus.update("technical", "work", activity=f"analisa teknikal {sym}", task=f"{sym} {c['mode']}")
        try:
            payload = await asyncio.wait_for(service.analyze(sym, c["mode"], c["be"], new_ok=control.is_on), 120)
            res[sym] = payload
            r = payload
        except Exception as exc:
            bus.update("technical", "error", activity=f"gagal analisa {sym}: {str(exc)[:120]}")
            return
    v = r.get("votes") or {}
    bus.update("technical", "ok", activity=f"{sym}: {v.get('method_bull', 0)} bullish / {v.get('method_bear', 0)} bearish (metode)", task=None, progress=1.0)
    bus.log("technical", f"{sym} {c['mode']}: {v.get('bull', 0)} keluarga bullish, {v.get('bear', 0)} bearish")
    bus.pulse("technical", "volume", "data", f"hipotesis {sym}")
    bus.pulse("technical", "febrian", "data", f"analisa teknikal {sym}")


async def _fundamental():
    from terminal.signals import fundamental, control
    c = control.get()
    if not c["pairs"]:
        bus.update("fundamental", "idle", activity="belum ada pair dipilih")
        return
    sym = c["pairs"][0]
    from terminal.signals import runner
    r = runner.RESULTS.get(sym) or {}
    f = ((r.get("layers") or {}).get("fundamental")) if r.get("mode") == c["mode"] else None
    if f is None:
        # hasil runner belum ada: hitung sendiri, maks. sekali per OWN_EVERY (dulu tiap 45 dtk, di proses server)
        key = ("fundamental", sym, c["mode"])
        if time.time() - _own.get(key, 0) < OWN_EVERY:
            bus.update("fundamental", "idle", activity=f"menunggu analisa runner {sym}")
            return
        _own[key] = time.time()
        bus.update("fundamental", "work", activity=f"menyaring fundamental {sym}", task=sym)
        f = await fundamental.gather(sym, c["mode"])
    score = (f or {}).get("score", 0.0)
    conf = (f or {}).get("conf", 0.0)
    bus.update("fundamental", "ok", activity=f"{sym}: skor {score:+.2f} (cakupan {conf*100:.0f}%)", task=None, progress=1.0)
    bus.log("fundamental", f"{sym}: skor fundamental {score:+.2f}, kepercayaan {conf:.2f}")
    bus.pulse("fundamental", "quant", "data", "filter fundamental")
    bus.pulse("fundamental", "febrian", "data", f"fundamental {sym} {score:+.2f}")


async def _volume():
    from terminal.signals import runner, control
    c = control.get()
    r = runner.RESULTS.get(c["pairs"][0]) if c["pairs"] else None
    if not r:
        bus.update("volume", "idle", activity="menunggu hasil analisa teknikal")
        return
    prof = ((r.get("layers") or {}).get("profile") or {})
    poc, vah, val = prof.get("poc"), prof.get("vah"), prof.get("val")
    bus.update("volume", "work", activity="validasi volume profile & level likuiditas", task=r.get("symbol"))
    await asyncio.sleep(0.2)
    bus.update("volume", "ok", activity=f"{r.get('symbol')}: POC {poc} · VAH {vah} · VAL {val}", task=None, progress=1.0)
    bus.log("volume", f"level {r.get('symbol')}: POC {poc}, VAH {vah}, VAL {val}")
    bus.pulse("volume", "quant", "data", "validasi level")
    bus.pulse("volume", "febrian", "data", "level volume/likuiditas")


async def _quant():
    from terminal.signals import runner, control, learn
    c = control.get()
    r = runner.RESULTS.get(c["pairs"][0]) if c["pairs"] else None
    if not r:
        bus.update("quant", "idle", activity="menunggu data teknikal + volume")
        return
    q = ((r.get("layers") or {}).get("quant") or {})
    reg = (q.get("regime") or {}).get("label")
    bus.update("quant", "work", activity="menghitung probabilitas & rezim", task=r.get("symbol"))
    lv = learn.verdict(dict(r, signal=r.get("signal"), mode=r.get("mode")), r.get("symbol"))
    bus.update("quant", "ok", activity=f"{r.get('symbol')}: rezim {reg} · p(TP1) {q.get('p_tp1')} · EV {q.get('ev')}R", task=None, progress=1.0)
    bus.log("quant", f"{r.get('symbol')}: rezim {reg}, p(TP1)={q.get('p_tp1')}, EV={q.get('ev')}R, pengalaman={'menolak' if lv['block'] else (lv['note'] or 'netral')}")
    bus.pulse("quant", "febrian", "data", "konfirmasi kuantitatif")


async def _febrian():
    from terminal.signals import runner, control
    from terminal.agents import bus as B
    c = control.get()
    st = B.state()
    alive = st.get("active") or []
    for a in ("news", "technical", "fundamental", "volume", "quant"):
        if a not in alive:
            B.pulse("febrian", a, "request", "aktifkan agent")
    rows = []
    for sym in c["pairs"][:8]:
        r = runner.RESULTS.get(sym)
        if r and r.get("mode") == c["mode"]:
            rows.append(f"{sym}:{r.get('signal')}")
    decisions = [x for x in rows if not x.endswith("WAIT")]
    txt = f"{len(decisions)} sinyal aktif dari {len(rows)} pair" if rows else "menunggu analisa agent"
    bus.update("febrian", "work", activity=txt, task="orchestrasi agent", progress=min(1.0, len(alive) / 6))
    for a in ("technical", "fundamental", "volume", "quant"):
        if a in alive:
            B.pulse("febrian", a, "request", "minta konfirmasi")
    bus.log("febrian", f"status agent: {len(alive)}/6 hidup · {txt}")
    if rows:
        bus.log("febrian", "posisi: " + ", ".join(rows[:8]))
    bus.update("febrian", "ok", activity=txt, task=None, progress=1.0)


TASKS = dict(news=_news, technical=_technical, fundamental=_fundamental, volume=_volume, quant=_quant, febrian=_febrian)


async def main(agent):
    if agent not in META:
        print("Agent tidak dikenal. Pilih: " + ", ".join(IDS), flush=True)
        return 2
    layout.set_console_title(layout.AGENT_TITLES.get(agent, agent.upper()))
    bus.update(agent, "work", activity="memulai", pid=os.getpid())
    _say(agent, "siap")
    try:
        while True:
            try:
                await TASKS[agent]()
            except NotImplementedError:
                bus.update(agent, "idle", activity="menunggu")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                bus.update(agent, "error", activity=f"{type(exc).__name__}: {str(exc)[:140]}")
                bus.log(agent, f"error: {type(exc).__name__}: {exc}", level="error")
                traceback.print_exc()
            _say(agent, bus.state()["agents"][agent].get("activity") or "—")
            await asyncio.sleep(6 if agent != "febrian" else 4)
    except KeyboardInterrupt:
        pass
    finally:
        bus.update(agent, "off", activity="terminal ditutup")
    return 0


# Agent memakai hasil analisa runner sinyal; analisa sendiri (bila runner belum punya hasil) paling sering sekali per ini.
OWN_EVERY = 600
_own = {}
# Jeda antar putaran tiap agent pada mode SATU TERMINAL (detik). Tugas ringan; analisa berat dikerjakan runner sinyal.
INTERVAL = dict(news=30, technical=10, fundamental=45, volume=10, quant=10, febrian=8)


async def run_all(log=None):
    """Jalankan ke-6 agent di dalam proses server (satu terminal). Berbagi hasil analisa, berita & cache dengan server."""
    bus.INPROC = True

    async def one(agent):
        bus.update(agent, "work", activity="memulai", pid=os.getpid())
        await asyncio.sleep(IDS.index(agent) * 1.5)          # mulai bergiliran, tidak serentak
        while True:
            try:
                await TASKS[agent]()
            except NotImplementedError:
                bus.update(agent, "idle", activity="menunggu")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                bus.update(agent, "error", activity=f"{type(exc).__name__}: {str(exc)[:140]}")
                bus.log(agent, f"error: {type(exc).__name__}: {exc}", level="error")
            await asyncio.sleep(INTERVAL.get(agent, 10))

    async def flusher():
        while True:
            await asyncio.sleep(bus.SAVE_EVERY)
            await asyncio.to_thread(bus.flush)
    try:
        await asyncio.gather(flusher(), *(one(a) for a in IDS))
    finally:
        for a in IDS:
            bus.update(a, "off", activity="terminal ditutup")
        bus.flush()


def cli():
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    agent = (sys.argv[1] if len(sys.argv) > 1 else "febrian").strip().lower()
    try:
        return asyncio.run(main(agent))
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    raise SystemExit(cli() or 0)