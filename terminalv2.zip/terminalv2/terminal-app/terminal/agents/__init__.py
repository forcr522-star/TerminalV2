"""Sistem 6 agent terminal (berjalan di terminal terpisah, satu tugas per agent).

AGENT 1 NEWS/DATA -> 2 TEKNIKAL -> 3 FUNDAMENTAL -> 4 VOLUME/LIQUIDITY -> 5 QUANT -> 6 FEBRIAN DEVELOPER (pengontrol).
Menu THINKING menampilkan status dan lalu lintas pesan antar agent dari bus ini.
"""
from . import bus  # noqa: F401