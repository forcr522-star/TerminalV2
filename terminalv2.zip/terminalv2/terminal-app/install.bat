@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Terminal - Install

rem --- 1. Python: cari; bila tidak ada, pasang lewat winget
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY (
  echo [PASANG] Python belum ada, memasang lewat winget ...
  where winget >nul 2>nul
  if errorlevel 1 (
    echo [GAGAL] winget tidak tersedia. Pasang Python 3.10+ dari https://www.python.org/downloads/ ^(centang "Add Python to PATH"^) lalu jalankan install.bat lagi.
    pause
    exit /b 1
  )
  winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
  echo.
  echo Python baru dipasang. TUTUP jendela ini lalu jalankan install.bat sekali lagi agar PATH terbaca.
  pause
  exit /b 0
)

rem --- 2. Semua pemeriksaan & pemasangan (hanya yang belum ada) dikerjakan installer.py
%PY% tools\installer.py %*
set "RC=%errorlevel%"
echo.
if "%RC%"=="0" (
  echo Selesai. Jalankan start.bat untuk menyalakan terminal.
) else (
  echo Ada bagian yang belum beres ^(lihat daftar [GAGAL] di atas^). Perbaiki lalu jalankan install.bat lagi - yang sudah terpasang dilewati.
)
pause
exit /b %RC%
