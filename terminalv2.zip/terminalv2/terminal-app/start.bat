@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title TERMINAL SERVER (UTAMA)

rem ============================================================================
rem  7 TERMINAL - ditata otomatis ke grid 3x3 monitor utama:
rem    baris 1 : NEWS AGENT    - TEKNIKAL AGENT - FUNDAMENTAL AGENT
rem    baris 2 : VOLUME AGENT  - QUANT AGENT    - TERMINAL SERVER (UTAMA) = jendela ini
rem    baris 3 : FEBRIAN AGENT - (kosong)       - (kosong)
rem  Jendela SERVER: website, tunnel Cloudflare, link ADMIN/USER, info server.
rem  CATATAN: file .bat ini harus ber-akhiran baris CRLF (Windows). Jangan pakai
rem  tanda dan-komersial tanpa ^ di perintah echo: cmd menganggapnya pemisah perintah.
rem ============================================================================

rem --- install otomatis bahan yang belum ada (installer melewati yang sudah terpasang) ---
if not exist .install_ok goto install
if not exist .venv\Scripts\python.exe goto install
goto run

:install
echo Instalasi belum lengkap - menjalankan install.bat ...
call install.bat
if errorlevel 1 goto install_failed
goto run

:install_failed
echo Instalasi belum lengkap, terminal tidak dijalankan.
pause
exit /b 1

:run
if not exist .env copy .env.example .env >nul
set "PY=%~dp0.venv\Scripts\python.exe"

rem --- 6 terminal agent, masing-masing jendela sendiri ---
echo [1/3] Membuka 6 terminal agent: NEWS, TEKNIKAL, FUNDAMENTAL, VOLUME, QUANT, FEBRIAN ...
start "NEWS AGENT" cmd /k ""%PY%" -m terminal.agents.run news"
start "TEKNIKAL AGENT" cmd /k ""%PY%" -m terminal.agents.run technical"
start "FUNDAMENTAL AGENT" cmd /k ""%PY%" -m terminal.agents.run fundamental"
start "VOLUME AGENT" cmd /k ""%PY%" -m terminal.agents.run volume"
start "QUANT AGENT" cmd /k ""%PY%" -m terminal.agents.run quant"
start "FEBRIAN AGENT" cmd /k ""%PY%" -m terminal.agents.run febrian"

rem --- tata 7 jendela ke grid 3x3 (jendela ini = TERMINAL SERVER, baris 2 kolom 3) ---
echo [2/3] Menata 7 terminal ke grid 3x3 ...
"%PY%" "%~dp0tools\arrange_terminals.py"
if errorlevel 1 echo [PERINGATAN] Penataan otomatis dilewati; terminal tetap dilanjutkan.

rem --- server website + tunnel Cloudflare + panel info server di jendela ini ---
echo [3/3] Menyalakan TERMINAL SERVER: website dan tunnel Cloudflare ...
"%PY%" "%~dp0main.py"
echo.
echo TERMINAL SERVER berhenti. Log lengkap: data\server.log
pause
