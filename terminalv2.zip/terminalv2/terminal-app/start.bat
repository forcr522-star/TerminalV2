@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title TERMINAL SERVER (UTAMA)

rem ============================================================================
rem  SATU TERMINAL: website, tunnel Cloudflare, link ADMIN/USER, info server, dan
rem  ke-6 agent (NEWS, TEKNIKAL, FUNDAMENTAL, VOLUME, QUANT, FEBRIAN) berjalan di
rem  jendela ini (satu proses). Dulu 7 jendela/proses: RAM +600 MB, kerja ganda,
rem  dan rebutan database - RDP jadi berat. Status agent ada di baris AGENT panel.
rem  CATATAN: file .bat ini harus ber-akhiran baris CRLF (Windows). Jangan pakai
rem  tanda dan-komersial tanpa ^ di perintah echo: cmd menganggapnya pemisah perintah.
rem ============================================================================

rem --- install otomatis bahan yang belum ada (installer melewati yang sudah terpasang) ---
if not exist .install_ok goto install
if not exist .venv\Scripts\python.exe goto install
goto run

:install
echo Instalasi belum lengkap - menjalankan install.bat ...
call install.bat
if errorlevel 1 goto install_failed
goto run

:install_failed
echo Instalasi belum lengkap, terminal tidak dijalankan.
pause
exit /b 1

:run
if not exist .env copy .env.example .env >nul
set "PY=%~dp0.venv\Scripts\python.exe"

rem --- server website + tunnel Cloudflare + 6 agent + panel info server di jendela ini ---
echo Menyalakan TERMINAL SERVER: website, tunnel Cloudflare, dan 6 agent (satu terminal) ...
"%PY%" "%~dp0main.py"
echo.
echo TERMINAL SERVER berhenti. Log lengkap: data\server.log
pause
