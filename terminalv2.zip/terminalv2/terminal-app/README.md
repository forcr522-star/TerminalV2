# Terminal (website via Cloudflare)

Saat dijalankan, program otomatis: menyalakan server website (HTTP), **memuat semua menu & fitur beserta datanya lebih dulu dan menyimpannya di database**, membuka tunnel Cloudflare (tanpa akun/token), lalu mencetak **satu alamat Cloudflare** yang langsung membuka website. Tidak ada Telegram, tidak ada bot.

## Jalankan (Windows)
1. **Klik `install.bat`** (sekali, atau kapan pun ada yang kurang). Ia memeriksa semua bahan dan **hanya memasang yang belum ada**; yang sudah ada dilewati (`[SKIP]`):
   Python 3.10+ (via winget bila belum ada) → virtualenv `.venv` → semua modul `requirements.txt` → `cloudflared` → **Ollama** + model AI ringan → file `.env`.
2. **Klik `start.bat`**. Bila instalasi belum lengkap, `start.bat` menjalankan `install.bat` lebih dulu. Semuanya berjalan di **SATU terminal** (jendela `start.bat` = **TERMINAL SERVER (UTAMA)**): website, tunnel Cloudflare, info server, **dan ke-6 agent** (NEWS, TEKNIKAL, FUNDAMENTAL, VOLUME, QUANT, FEBRIAN). Status agent ada di baris `AGENT` panel dan di menu THINKING.
   Dulu tiap agent membuka jendela & proses Python sendiri (7 jendela): ±600 MB RAM tambahan, analisa & unduhan berita dikerjakan ganda (agent NEWS mengunduh 42 feed tiap ±6 dtk), dan 7 proses berebut satu database — membuat RDP berat, sumber berita membatasi akses, dan server sesekali macet ("Host Error"). Agent di proses yang sama juga berbagi hasil analisa server (VOLUME & QUANT tidak lagi selalu "idle"). `AGENTS_INPROCESS=0` mematikan agent di dalam server.
3. Lihat jendela **TERMINAL SERVER**. Bagian atasnya adalah panel tetap (tidak ikut bergulir, link tidak pernah tertimbun log):
   ```
   == TERMINAL SERVER (UTAMA) == jam 07:30 | hidup 12 mnt
   CF    : AKTIF | cek OK 07:29:41 (tiap 30s) | edge sin01 | ulang 0x
   ADMIN >> https://xxxx.trycloudflare.com/?key=AbC...
   USER  >> https://xxxx.trycloudflare.com/?key=XyZ...
   WEB   : ONLINE :8787 | DATA SIAP 110/110
   AGENT : NEWS ok TEK ok FUND ok VOL ok QUANT ok FEB ok (6/6)
   SINYAL: ON | intraday | 6 pair | BE ON | AI aktif
   HEATM : WS OK | trade 6/6 live | BTC ETH SOL XRP TRX XAUT
   FILE  : data\LINK.txt (link) | data\server.log (log)
   --- LOG ----------------------------------------------------
   ```
   **Buka link hanya setelah `CF : AKTIF`.** Link yang sama juga selalu ditulis ke `data\LINK.txt` (buka dengan Notepad), log lengkap ke `data\server.log`.
   Status sumber data/AI ada di website: klik **DATA** di bilah atas (data tersimpan) atau tombol "N sumber bermasalah".

### Terminal SERVER & Cloudflare (mengatasi error 1033)
Error 1033 ("Cloudflare Tunnel error ... unable to resolve it") berarti link trycloudflare sudah ada tetapi `cloudflared` belum/tidak lagi tersambung ke Cloudflare. Terminal SERVER sekarang mengawasinya:
- Link baru **diverifikasi dulu**: menunggu `Registered tunnel connection`, lalu membuka sendiri `<link>/healthz` lewat Cloudflare. Selama itu status `MEMVERIFIKASI - JANGAN dibuka dulu`; link ADMIN/USER baru muncul setelah `AKTIF`.
- Link diperiksa tiap `TUNNEL_CHECK_EVERY` detik (bawaan 30). Bila Cloudflare membalas 530/1033 (atau 502/503/504) 3× berturut-turut, atau proses `cloudflared` mati, tunnel **dibuat ulang otomatis** dan link BARU langsung tampil di panel + `data\LINK.txt` (link quick tunnel gratis selalu berganti saat dibuat ulang).
- Bila server lokal yang tidak menjawab, link tidak diganti (masalahnya bukan tunnel).

### Server macet / "Host Error" / banyak "sumber bermasalah" sekaligus (sudah diperbaiki)
Gejala: website lambat (PING detik-an), Cloudflare menampilkan **Host Error** padahal terminal jalan, dan tiba-tiba belasan sumber gagal bersamaan dengan `ConnectTimeout` / `PoolTimeout`. Penyebabnya bukan sumbernya, melainkan server yang **macet**: semua baca/tulis database memakai satu kunci; bila satu tulis besar (atau proses agent lain) sedang menulis, setiap baca dari server ikut menunggu (hingga 30 dtk), sehingga semua koneksi yang sedang berjalan habis waktunya bersamaan. Perbaikan:
- **Baca database tanpa kunci** (koneksi baca per thread, mode WAL): baca tidak pernah menunggu tulis; tulis besar dipecah per 300 baris.
- Parsing CSV besar (SNB, BoE, RBA, MOF, FRED, GPR) dipindah ke thread — dulu satu CSV SNB menahan server 2,7–3,8 dtk.
- Satu terminal (lihat di atas): tidak ada lagi 7 proses yang berebut database.
- **Watchdog**: bila server tertahan > 1 dtk, log menulis lokasinya, mis. `[watchdog] server tertahan 4.2 dtk - providers/yields.py:162 parse_snb_csv ...` (ringkasan juga di `/api/health`). Ambang: `WATCHDOG_SEC` (bawaan 1; 0 = mati).
- **Kegagalan lokal tidak dihitung sebagai sumber bermasalah**: `PoolTimeout` dan timeout yang terjadi saat server sempat macet dicatat terpisah (bukan "Perlu perhatian"). Sumber baru dihitung bila gagal **2× berturut-turut** tanpa berhasil; gagal sekali tampil di bagian "Gagal sekali (dicoba ulang otomatis)".
- Hasil watchdog di Windows/RDP (sudah diperbaiki): status agent ditulis ke DB dari event loop (2,9–7,6 dtk) → kini oleh thread latar; katalis berita dihitung ulang di event loop (5,4 dtk) → disimpan sampai feed berubah & dihitung di thread; jalur TLS Chrome (`curl_cffi` AsyncSession) memproses soket di event loop (hingga 34 dtk) → kini sesi sinkron di thread; kompresi websocket dimatikan.
- **Satu jalur komputasi**: analisa sinyal, model likuidasi, backfill, dan katalis berjalan di SATU thread pekerja (`terminal/cpu.py`) sehingga event loop tidak antre GIL di belakang banyak thread berat; jeda tukar GIL 2 ms. Saat start, analisa sinyal & backfill heatmap menunggu preload selesai (tidak berebut CPU).
- **AI lokal (Ollama)** memakai paling banyak setengah core (`OLLAMA_THREADS`) dan, bila dinyalakan terminal, berprioritas di bawah normal — AI tidak lagi merebut CPU dari website/tunnel.
- **Sumber yang diblokir DNS** (mis. `gamma-api.polymarket.com`: "All connection attempts failed"): alamat asli dicari lewat DNS-over-HTTPS (Cloudflare/Google) lalu disambung ke IP itu dengan verifikasi sertifikat TLS tetap atas nama host aslinya (status: "via DoH").
- Gagal membuat tunnel (mis. batas permintaan Cloudflare) → dicoba lagi dengan jeda bertahap 5 dtk → 2 mnt; 2× gagal berturut-turut → protokol berganti `http2` ↔ `quic`.
- `cloudflared` dari `bin\` paket dipakai lebih dulu, baru yang ada di PATH.
- Port sudah dipakai (server lama masih jalan) → pesan jelas, bukan crash diam-diam.
- `SERVER_PANEL=0` di `.env` mengembalikan tampilan log biasa (banner gaya lama).

Linux/macOS: `./install.sh` lalu `./start.sh`. Hanya memeriksa tanpa memasang: `python tools/installer.py --check`.
Alamat Cloudflare gratis **berganti setiap program dijalankan ulang** (isi `PUBLIC_URL` bila memakai named tunnel/domain sendiri).

## Tampilan & alat (berlaku di semua menu)
Tema **"instrument panel"**: graphite gelap, aksen amber, angka memakai huruf mono bertabel (IBM Plex Mono) dan label memakai IBM Plex Sans Condensed. Font dibundel di `terminal/web/vendor/fonts` (lisensi OFL, ±125 KB) — tidak memuat CDN, jadi tetap tampil di RDP/VPS tanpa akses Google Fonts. Warna grafik semua menu ikut tema (hijau-teal = naik, coral = turun, amber = aksen).
- **Sidebar berikon & berkelompok** (Overview, Trading, Markets, Macro, Intelligence). Di desktop melebar saat disorot (label terlihat) tanpa menggeser konten; di ponsel menjadi laci menu dengan label.
- **Command palette** — tekan **Ctrl+K** (Mac: ⌘K) atau **/**, atau klik kotak cari: lompat ke menu mana pun, cari simbol (harga & % hari ini langsung terlihat, ★ untuk watchlist), cari berita, atau jalankan alat. Navigasi ↑ ↓ Enter, tutup Esc.
- **Watchlist & price alert** (ikon ★ di bar atas): simbol pilihan dengan sparkline, harga diperbarui tiap 60 dtk. Ikon lonceng memasang alert harga; arah ditentukan otomatis (di atas harga sekarang = tembus ke atas, di bawah = tembus ke bawah). Alert terpicu → notifikasi di layar + notifikasi browser (bila diizinkan). Disimpan **per browser** (tidak memengaruhi pengguna lain) dan aktif selama tab terminal terbuka.
- **Kalkulator ukuran posisi** (ikon kalkulator di bar atas): saldo, risiko %, entry, stop loss, take profit opsional → lot, jarak SL (pip untuk FX), nilai per pip, rugi bila kena SL, profit di TP & rasio R. Lot dibulatkan **ke bawah** ke 0,01 sehingga risiko nyata tidak pernah melebihi batas. Mata uang kuotasi dikonversi ke USD dari harga FX terkini (mis. USDJPY → JPY); ukuran kontrak bawaan (FX 100.000, Gold 100 oz, Silver 5.000 oz, minyak 1.000 barel, indeks & kripto 1) bisa diubah sesuai broker.
- Ticker atas bisa diklik (membuka simbol di MARKET); jam sesi NY/London/Tokyo menyala saat sesi buka; PING berwarna (hijau < 250 ms, oranye < 800 ms, merah).
- Sisa item Polymarket lama di feed berita & snapshot dibersihkan otomatis saat start (Polymarket kini hanya data pendukung bot).

### Kecepatan website lewat Cloudflare Tunnel
Setiap permintaan dari browser menempuh perjalanan pulang-pergi ke komputer/RDP ini lewat Cloudflare (sering 200–800 ms di tunnel gratis), jadi yang paling berpengaruh adalah **jumlah** permintaan yang harus ditunggu, bukan besarnya.
- **Aset statis disimpan permanen di browser.** Dulu setiap buka/muat ulang website memeriksa ulang ~30 berkas (`no-cache`). Kini `index.html` menautkan JS/CSS dengan `?v=<versi isi berkas>` → disimpan browser (`immutable`) dan tidak diperiksa lagi; versi berganti otomatis saat program diperbarui. Uji dengan latensi 150 ms: muat ulang 2,4 → 1,0 dtk, isi dashboard tampil 1,8 → 0,6 dtk.
- **Peran (admin/user) disisipkan ke halaman** → menu langsung digambar tanpa menunggu `/api/me`.
- **Prefetch menu**: saat kursor menyentuh (atau jari menekan) item menu, data menu itu diambil lebih dulu → ketika diklik langsung tampil tanpa menunggu jaringan. Endpoint tiap menu dipelajari otomatis per browser.
- **Garis progres tipis** di atas layar + efek tekan tombol seketika: klik terasa direspons walau jawaban server masih di jalan.
- Peta dunia disederhanakan (432 → 232 KB), harga watchlist hanya diambil bila ada alert aktif / laci watchlist terbuka (dulu 35 KB tiap menit), sumber yang selalu gagal (CDS & tabel yield worldgovernmentbonds - kini JavaScript) tidak diminta lagi.
- Bila masih terasa lambat: *quick tunnel* gratis (`*.trycloudflare.com`) memang lebih lambat & dibatasi dibanding **named tunnel** (akun Cloudflare gratis + domain sendiri, isi `PUBLIC_URL`). CPU RDP yang penuh (AI lokal / backtest) juga memperlambat jawaban — lihat `[watchdog]` di jendela terminal.

### Motion saat pindah menu
Konten lama meluncur keluar (View Transitions API, dikerjakan GPU), panel & kartu baru muncul berurutan, indikator menu di sidebar bergeser ke item terpilih, judul berganti dengan animasi. Otomatis mati bila Windows/HP diset "kurangi animasi" (`prefers-reduced-motion`). Pembaruan data berkala tidak ikut beranimasi.

### Arti "n/a" dan sel redup
Tanda "—" dulu mudah disangka minus. Kini: sel kosong di tabel tampil redup dengan keterangan saat disorot ("data tidak tersedia, bukan nilai negatif"); kolom obligasi menulis **n/a** + alasannya. Penyebab nilai kosong yang sudah diperbaiki: (1) permintaan FRED tertahan sampai timeout (yield AS sering belum siap dalam batas 12 dtk dashboard), (2) kolom 2Y kosong untuk negara tanpa 2Y — kini memakai tenor pendek yang tersedia (label tenor ditampilkan), (3) harga Yahoo yang sesekali gagal (429) — kini memakai yield Treasury FRED untuk 13W/5Y/10Y/30Y AS dan **harga terakhir yang valid** (maks. 5 hari, ditandai tanggalnya) untuk simbol lain. Yang tetap n/a memang tidak tersedia dari sumber terbuka (mis. yield obligasi China & Indonesia).

### CENTRAL BANK: tampilan per negara kini setara
Setiap negara punya **kartu dan tab yang sama** (Multi-asset overview · Yield curve · Benchmark yields · Policy rate · Yield spread · Balance sheet + riwayat keputusan). Bila sebuah data memang tidak tersedia dari sumber terbuka, tempatnya tetap ada dan menjelaskan alasannya (tanpa angka rekaan). Spread kurva memakai aturan yang sama untuk semua negara: 2s10s bila 2Y ada; jika tidak, 10Y dikurangi tenor terpendek yang punya riwayat (Inggris 5Y–10Y, Selandia Baru 3M–10Y), hanya pada tanggal yang sama di kedua tenor.
- **Perbaikan FRED**: FRED (Akamai) menahan permintaan yang mengaku browser Chrome tetapi bukan Chrome sungguhan sampai timeout (tampil sebagai "FRED bermasalah"). Permintaan FRED kini memakai identitas klien yang jujur → dijawab < 1 dtk.
- **Perbaikan FRED/OECD 10Y**: kode seri dulu memakai kode negara 3 huruf (`IRLTLT01NZLM156N`, selalu 404); kini 2 huruf (`IRLTLT01NZM156N`). Seri yang memang tidak ada (China/Indonesia) tidak diminta lagi sehingga tidak membuat host FRED masuk masa jeda.
- MARKET PARTICIPANT → *Dataset Compare* kini langsung menggambar grafik saat menu dibuka dan memperbarui otomatis setiap pilihan D1/D2 berubah.
- Analisa sinyal & isian riwayat heatmap menunggu muat-awal hanya bila muat-awal memang berjalan (dulu: server tanpa `main.py` menunggu 10 menit sebelum analisa pertama).

## Menu SIGNAL (sinyal BUY/SELL multi-pair, tampilan ala MT5)
**Tampilan user (kunci user)** — hanya-baca:
- Kiri **LIST PAIR YANG DI ANALISA** (pair pilihan developer; klik pair untuk mengganti chart), kanan **CHART** besar live (harga berjalan, candle terakhir ikut bergerak). Timeframe chart mengikuti mode trading global: scalping → M5, intraday → H1, swing → D1.
- Bila pair punya sinyal, chart menggambar posisi simulasi LONG/SHORT lengkap: entry, SL (= 1R) dan TP1 / TP2 / TP MAX (kelipatan R) dengan label RR.
- Panel bawah: **TERBUKA** (posisi berjalan), **LIMIT** (menunggu harga menyentuh entry; menampilkan SL, entry, TP, arah dan jarak harga), **TERTUTUP** (riwayat). Untung/rugi ditulis dalam **R** (SL = −1R). Order kedaluwarsa / tidak terisi ditandai batal (tanpa R).
- User tidak bisa melihat isi analisa bot, kontrol, atau peringatan "sumber bermasalah" (ditolak di server, bukan hanya disembunyikan).

**Tampilan admin (kunci admin)** — sama, ditambah tombol di atas:
- **BREAKEVEN ON/OFF**: ON = setelah TP1 tercapai SL dipindah ke harga entry. OFF = SL & TP tetap (tanpa pemindahan/pemberitahuan).
- **SINYAL ON/OFF**: ON = bot menganalisa semua pair terpilih 24 jam. OFF = bot **dilarang menganalisa** pair mana pun dan tidak menerbitkan sinyal baru. (Order yang sudah berjalan tetap dipantau SL/TP-nya supaya daftar order akurat; itu pelacakan, bukan analisa pasar.)
- **INSIDE/ANALISIS**: halaman terpisah. Tab **PILIH PAIR** (popup di tengah, semua pair terminal tanpa terkecuali: FX, komoditas, indeks, kripto, obligasi), **MODE TRADING** (scalping / intraday / swing), **SINYAL** (kembali ke chart). Kiri: pair yang sedang dianalisa dengan titik hijau/merah = arah dominan 10 analisa (buy/sell). Tengah: kartu **ANALISA 1–10** (BULLISH / BEARISH / WAITING). Klik kartu → **HASIL ANALISA** berisi alasan: teknikal, volume & liquidity, fundamental, quantitative, dan kesimpulan BUY / SELL / WAIT.
- Pengaturan kontrol disimpan di database (bertahan setelah restart). Bot latar belakang bisa dimatikan total dengan `SIGNAL_RUNNER=0` di `.env`.

Untuk tiap pair, 10 metode analisa menjalankan alur Teknikal → Volume Profile & Liquidity → Fundamental → Quantitative, diambil suara mayoritas, lalu bot memberi **ENTRY, SL, TP1, TP2, TP MAX** hanya bila plan cocok. Sinyal yang terbit dikunci di jurnal sampai selesai.
**Baca `docs/SIGNAL_RISET.md` sebelum dipakai**: bukti backtest nyata hanya kuat untuk SWING (D1); INTRADAY hampir impas; SCALPING belum tervalidasi. Ini estimasi statistik, bukan jaminan.

**BACKTEST (perbaikan)**: dulu setiap pair crash diam-diam pada sinyal pertama (label rezim berupa teks dikirim ke fungsi yang memanggil `.get()`), sehingga hasil selalu "SELESAI · 0 sinyal". Kini (1) bug itu diperbaiki, (2) pair yang gagal diuji ditampilkan alasannya di jendela backtest, (3) data **sebelum** tanggal mulai dipakai sebagai pemanasan indikator (dulu 250 bar pertama rentang pilihan — setahun penuh di D1 — habis untuk pemanasan), dan (4) setiap bar dianalisa seperti bot live (dulu tiap 2 bar). Contoh nyata: Gold+EURUSD+USDJPY SWING 2 tahun → 12 sinyal, 7 terisi, 57% positif, rata-rata +0,59R. Bila INTRADAY/SCALPING tetap 0 sinyal, itu filter data-driven strategi sendiri (metode dengan lower-bound R historis ≤ 0 di pair itu tidak boleh memilih), bukan error.

## Menu HEATMAP & FOOTPRINT (kripto, Binance Spot)
Menu khusus untuk melihat **heatmap likuidasi**, **liquidation map**, **footprint**, dan **big trade** — tampilan ala platform heatmap. Menu ini memakai kripto dari **Binance Spot** (bursa terbesar): `BTCUSDT`, `ETHUSDT`, `SOLUSDT`, `XRPUSDT`, `TRXUSDT`, `XAUTUSDT` (Tether Gold). Data publik, tanpa API key.

Baris atas chart: **PAIR** (BTC · ETH · SOL · XRP · TRX · XAUT, hanya pair pilihan admin) · **TF** (M1 … D1), harga pair terpilih di kanan. Mode ORDERBOOK sudah **dihapus** (stream depth, snapshot 5000 level, dan perekaman heat tiap 2 dtk tidak dijalankan lagi — lebih ringan); footprint saat zoom tetap ada.

**Heatmap LIQUIDATION**:
- **Model level likuidasi gaya CoinGlass**, dihitung sendiri dari candle Binance (tanpa API CoinGlass). Karena dihitung dari riwayat candle, heatmap **langsung penuh di seluruh chart untuk setiap timeframe** (M1 … D1), dan tiap timeframe dihitung dari candle timeframe itu sendiri. Cara kerja (transparan, data-driven, tanpa kebocoran masa depan), untuk setiap candle:
  1. level likuidasi yang dilewati harga candle itu **tersapu** (pita berakhir di sana);
  2. posisi lama meluruh (paruh umur 96 candle TF itu);
  3. posisi baru = 10% volume candle, dibuka di sepanjang rentang candle (5 titik low→high, bobot terbesar di tengah), porsi long = volume taker beli, disebar ke 11 tingkat leverage 3x–125x (terbanyak 10x–25x); harga likuidasi long = P×(1−1/lev+0,4%), short = P×(1+1/lev−0,4%). Sebaran ini membuat setiap level harga punya likuiditas, dengan kluster terang di tempat posisi bertumpuk.

  Nilai USDT adalah **estimasi model**, bukan likuidasi aktual (begitu pula CoinGlass: heatmap-nya model). Parameter bisa diubah lewat `.env` (`HEATMAP_LIQ_*`).

**Chart** (timeframe **M1, M5, M15, M30, H1, H4, D1**):
- **Heatmap** — palet gaya CoinGlass: **ungu tua** (kecil) → biru → teal → hijau → **kuning** (terbesar), skala linear terhadap nilai "penuh" (persentil 99,5 di jendela chart). Pita berakhir saat harga menyapunya.
- **Meter sensitivitas** (batang naik di kanan tulisan pair, disimpan per browser): geser ke **kanan = lebih kuning** (likuiditas yang lebih kecil sudah dianggap besar), ke **kiri = lebih redup** (hanya likuiditas sangat besar yang kuning). Ambangnya (mis. `kuning ≥ 309K` per baris) muncul saat kursor diarahkan ke meter. Bisa juga dengan scroll mouse atau tombol panah.
- **Big Trades** — riwayat **satu order taker** yang sangat besar (bukan jumlah banyak order kecil), digambar seperti platform footprint: bola terisi gradasi **tanpa garis tepi**, hijau = beli agresif, merah = jual agresif, luas bola ∝ nilai trade (nilai tertulis di bola besar; hover = sisi, nilai, harga, jam:menit:detik). Ambang minimal **naik sesuai timeframe** dari distribusi ukuran order 24 jam pair itu: M1 = 0,1% order terbesar, M5 0,05%, M15 0,03%, M30 0,02%, H1 0,01%, H4 0,005%, D1 0,002%; pada pair ramai ambang dinaikkan lagi sampai rata-rata 24 jam hanya **±0,6 order per candle** yang lolos (`HEATMAP_BIG_PER_CANDLE`), sehingga di M1 maupun D1 bubble hanya muncul pada order yang benar-benar besar. **Semua** trade ≥ ambang tampil di seluruh chart (batas aman `HEATMAP_BIG_MAX_BUBBLES`, bawaan 500 per layar). Trade ≥ ½ × ambang H1 disimpan 365 hari (riwayat H1–D1), yang lebih kecil 7 hari.
- **Riwayat trade (backfill)** — supaya bubble & footprint ada **sampai awal chart**, terminal mengisi riwayat dari **data trade asli Binance** (bukan estimasi): hari-hari lalu dari arsip harian publik `data.binance.vision` (semua aggTrade satu hari dalam satu file; BTC ±27 MB/hari, diolah tervektor ±1 detik per hari), hari ini & arsip kemarin yang belum terbit lewat REST `aggTrades` per jam. Bawaan 30 hari (`HEATMAP_BACKFILL_DAYS`, 0–365): 7 hari terakhir lengkap (footprint per menit + big trade) untuk M1–M30, hari yang lebih lama cukup footprint per jam + big trade ≥ ambang H1 untuk H1–D1. Urutan: hari ini semua pair → kemarin semua pair → dst. Kemajuan disimpan, jadi tidak pernah diunduh ulang; rentang yang sudah direkam live dilewati, jeda saat terminal mati ditambal otomatis. Garis putus-putus tipis vertikal = awal riwayat trade tersimpan (candle di kirinya belum punya data big trade/footprint — bukan berarti tidak ada big trade). Hanya pair yang dipilih admin yang diunduh: ±60 MB per hari untuk 6 pair (BTC ±27, ETH ±25, SOL ±5, XRP ±3, XAUT ±2, TRX ±1 MB) → 30 hari ±1,9 GB **sekali saja**; set `HEATMAP_BACKFILL_DAYS=14` (cukup untuk H1) atau `7` bila kuota terbatas, atau lebih besar (mis. 60) agar H4 juga penuh.
- **Key Liquidation Levels** — garis kuning (makin tebal/terang = makin kuat) dari saat level mulai terbentuk sampai sekarang, tanpa angka di chart supaya bersih (nilainya ada di panel kanan & tooltip).
- **Footprint** — zoom ke candle (scroll mouse / tombol +, timeframe apa pun), gaya platform footprint: candle berubah menjadi kolom kotak per harga berwarna **delta** (hijau = beli agresif dominan, merah = jual), badan open→close bergaris, sumbu high-low, POC (kotak emas). Zoom lebih dalam: angka **jual × beli** per harga + Δ delta candle. Tersedia untuk seluruh riwayat backfill.
- **Volume Delta** — beli agresif − jual agresif per candle (data taker Binance, tersedia untuk seluruh riwayat candle).
- **Liquidation Map** (strip kanan chart, satu skala harga dengan chart) — level likuidasi aktif per baris harga + kurva kumulatif (merah = likuidasi short di atas harga, hijau = likuidasi long di bawah harga).
- Tombol **CANDLE / LINE** di samping meter warna (kiri atas chart): LINE = garis harga penutupan (footprint tidak dipakai), klik lagi untuk kembali ke CANDLE; disimpan per browser.
- Kiri-atas chart ada daftar indikator ala TradingView dengan **ikon mata** untuk hide/show. Pilihan ini **disimpan per browser** (localStorage): bila user 1 menyembunyikan Big Orders, hanya tampilan user 1 yang berubah.
- Interaksi: scroll = zoom, seret = geser, seret/scroll di sumbu harga = skala harga, klik ganda / ⟲ = reset, AUTO = skala harga otomatis. HP: seret & cubit (pinch).

**Panel kanan**:
- **Key liquidation levels** (Above · short liquidations / Below · long liquidations: harga, nilai, jarak % dari harga) dan **Market overview** (open liquidation levels, longs vs shorts, liquidated in 24h & porsi long/short, level terbesar, price step / column period, taker buy/sell, big order, **dominasi BUYERS / SELLERS / BALANCED**).

**Semua ukuran disesuaikan timeframe (dari data, bukan angka tetap)**:
- Price step baris heatmap = kelipatan bulat bucket dasar ≈ median range candle TF itu / 8 → di H4 satu baris jauh lebih lebar daripada di M1, sehingga nilai likuiditas, footprint, dan big order per baris/candle **lebih besar di TF besar dan lebih kecil di M1/M5**.
- Dominasi: rata-rata dua imbalance dari trade NYATA (taker beli vs jual 20 candle, big trade beli vs jual 20 candle); |skor| > 0,10 = dominan.

**Admin & user**:
- **Admin** melihat tombol **PILIH PAIR** di bawah judul chart. Hanya pair yang dipilih yang **dipantau** server (WebSocket trade & candle Binance). Pair yang tidak dipilih **tidak dipantau sama sekali** dan permintaannya ditolak server (admin maupun user). Pilihan disimpan di database.
- **User** hanya bisa berpindah ke pair yang dipilih admin; `GET/POST /api/heatmap/control` ditolak (403).

**Cara kerja & batasan (jujur)**:
- Heatmap LIQUIDATION langsung penuh dari riwayat candle. Footprint & big trade diisi dari arsip trade Binance (lihat *Riwayat trade*). Candle & volume delta tersedia untuk seluruh riwayat. Data tersimpan di `data/terminal.db` (tabel `hm_*`): kolom 1 menit disimpan 7 hari (M1–M30), kolom 1 jam 365 hari (H1–D1) — ±100–200 MB untuk 6 pair.
- Orderbook lokal mengikuti prosedur resmi Binance (snapshot 5000 level + diff stream, cek urutan `U/u`, sinkron ulang otomatis bila ada event hilang, snapshot ulang tiap 10 menit atau saat harga mendekati tepi cakupan). Heatmap hanya dicuplik di dalam cakupan snapshot (contoh nyata: BTC ±2,2%, ETH ±7,5%), sehingga tidak ada area "kosong palsu".
- Host: `data-api.binance.vision` / `data-stream.binance.vision` (domain resmi Binance khusus data pasar publik), cadangan `api.binance.com` / `stream.binance.com`.
- Model likuidasi (opsional, `.env`): `HEATMAP_LIQ_OPEN_RATIO` (0.10), `HEATMAP_LIQ_HALFLIFE` (96 candle), `HEATMAP_LIQ_MMR` (0.004), `HEATMAP_LIQ_TIERS` (bawaan `3:.04,5:.08,10:.16,15:.12,20:.14,25:.14,35:.08,50:.10,75:.05,100:.06,125:.03`).
- Pengaturan `.env` (opsional): `HEATMAP_COLLECTOR=0` mematikan kolektor; `HEATMAP_BIG_PCTL` (99.5), `HEATMAP_BIG_MAX_BUBBLES` (500), `HEATMAP_BIG_PER_CANDLE` (0.6), `HEATMAP_BACKFILL_DAYS` (30; 0 = tanpa backfill), `HEATMAP_L1_DAYS` (7), `HEATMAP_L2_DAYS` (365), `HEATMAP_REST` / `HEATMAP_WS` (daftar host dipisah koma).

## Keamanan: dua kunci akses (admin & user)
Alamat Cloudflare bersifat publik, jadi website dijaga kunci akses. Ada **dua kunci**:
- `ADMIN_KEY` — developer: semua menu + kontrol SIGNAL + halaman INSIDE/ANALISIS + peringatan sumber bermasalah.
- `USER_KEY` — pengguna biasa: semua menu, SIGNAL hanya-baca, tanpa peringatan sumber bermasalah.

Bila kosong, dibuat acak sekali dan disimpan di `data/access_key.txt` (admin) dan `data/user_key.txt` (user). Saat start, `main.py` mencetak **dua alamat** (admin dan user), masing-masing sudah memuat kuncinya. Buka alamat berkunci sekali: server memasang cookie sesi (HttpOnly, berisi peran + HMAC, bukan kunci itu sendiri) lalu menghapus kunci dari bilah alamat. Semua file website dan `/api/*` tertutup tanpa kunci/cookie; endpoint analisa/kontrol/status hanya untuk admin (403 untuk user).
- `ACCESS_KEY` (lama) tetap dianggap kunci admin bila `ADMIN_KEY` kosong. `ADMIN_KEY=none` (atau `ACCESS_KEY=none`) mematikan penjagaan (semua orang = admin). `USER_KEY=none` mematikan akses user.
- `USER_KEY` yang sama dengan kunci admin diabaikan (diganti kunci acak) dan diberi peringatan di banner, supaya user tidak pernah mendapat akses admin.

## Muat-awal & data tersimpan (database)
- **Saat start (tahap 1, ditunggu):** semua menu beserta setiap tab/negara/kelas aset di dalamnya dimuat paralel dan disimpan di `data/terminal.db` (±110 data). Progres tercetak per item. Batas `PRELOAD_TIMEOUT` (300 dtk) mencegah satu sumber yang macet menahan alamat selamanya; sisanya selesai di latar belakang.
- **Tahap 2 (latar belakang):** ekor panjang — riwayat semua simbol, setiap instrumen COT, setiap kontrak futures, semua ETF sektor, semua aset Quant, pasangan negara Compare, mitra dagang (±450 data). Tidak menahan apa pun.
- **Pengunjung baru / masuk ulang:** semua dilayani langsung dari snapshot (±beberapa ms), tanpa memuat sumber satu per satu. Kombinasi yang belum pernah dimuat dihitung sekali saat diminta lalu ikut tersimpan.
- **Restart:** snapshot dibaca dari database, jadi program langsung siap; data lama diperbarui diam-diam di latar belakang (`PRELOAD_FORCE=1` memaksa menunggu muat-ulang penuh).
- **Pembaruan otomatis:** tiap data punya TTL sendiri (harga 60-120 dtk, berita 60-90 dtk, makro/bank sentral 10-15 mnt, COT 1 jam, dst.). Yang melewati TTL diperbarui di latar belakang; pengunjung tidak pernah menunggu.
- **Aman terhadap sumber mati:** hasil yang gagal/kosong tidak pernah menimpa snapshot yang masih baik (dashboard mempertahankan panel terakhir yang baik); sumber yang gagal dicoba ulang dengan jeda bertahap (30 dtk → 15 mnt).

## Kredensial: tidak ada yang wajib
Tidak ada API key berbayar atau langganan di platform lain. Dua pendaftaran **gratis** bersifat opsional: AISStream (`AISSTREAM_API_KEY`, kapal global) dan akun Myfxbook (`MYFXBOOK_EMAIL`/`MYFXBOOK_PASSWORD`, sentimen retail).

### AI lokal (Ollama, tanpa key)
Narasi Catalyst/Research ditulis model lokal `gemma3:1b` (±0,8 GB; ganti lewat `OLLAMA_MODEL`, alternatif ringan: `qwen2.5:1.5b`, `llama3.2:1b`). Narasi dibuat di latar belakang, **disimpan**, dan hanya ditulis ulang bila headline berubah — membuka menu tidak memicu AI. Tanpa Ollama (atau `LLM_ENABLED=0`) aplikasi tetap jalan penuh dengan ringkasan otomatis berbasis aturan.

## Sumber data (semua gratis, tanpa key)
Setiap data punya **rantai cadangan**; satu sumber yang gagal tidak mengosongkan tampilan. Bila tidak ada sumber gratis yang menyediakan suatu angka, tampilan menulis alasannya (bukan "n/a" atau grafik kosong).

| Modul | Sumber (urutan prioritas) |
|---|---|
| Macro (AS) | FRED (`fredgraph.csv`; jalur lama `/data/<id>.txt` sudah dihapus FRED — 404) |
| Macro (negara lain) | IMF DataMapper → World Bank (tahunan); pasar mingguan (indeks/FX/yield 10Y) dari Yahoo; COT mata uang dari CFTC. Tiap negara punya tabel sendiri |
| Regime / Compare | z-score FRED (AS) → IMF/World Bank (negara lain) |
| Central Bank – suku bunga | BIS → FRED |
| Central Bank – yield | AS: FRED → US Treasury → Yahoo · Euro: ECB → FRED/OECD · Jepang: MOF (beberapa URL kandidat; URL berubah/404 tidak lagi membuat status merah) → FRED/OECD · Kanada: Bank of Canada · Australia: RBA · Swiss: SNB · Inggris: Bank of England IADB (5/10/20Y) → FRED/OECD · Selandia Baru: FRED/OECD 10Y + pasar uang 3M (bulanan) · China & Indonesia: pasar uang 3M (FRED/OECD, bulanan) · cadangan: worldgovernmentbonds.com. Stooq dihapus (tidak lagi bisa diakses tanpa key). Kolom dipilih dari label tenor, bukan nomor seri hafalan |
| Central Bank – lainnya | Inflasi/suku bunga riil (FRED/IMF/WB), **neraca bank sentral ke-10 negara**: AS/Jepang FRED mingguan, Euro ECB → FRED, lalu **BIS *Central bank total assets*** (bulanan, mata uang lokal) untuk semua negara, CDS (scrape worldgovernmentbonds, best-effort), RSS resmi + Google News |
| Fiscal | IMF DataMapper → World Bank → BIS (utang/PDB, mis. China); US Treasury FiscalData. Negara tanpa data publik sama sekali disembunyikan dari tab (bila ≥3 negara punya data) |
| Fiscal – lelang | AS: FiscalData (jadwal + hasil) → TreasuryDirect; negara lain: kalender TradingView (judul *Auction/Tender*, nilai = yield hasil) → ForexFactory. Panel menampilkan tab **Mendatang** dan **Riwayat**; negara tanpa data lelang tidak menampilkan panelnya |
| Market, Quant, Futures, ETF, Financials | Yahoo Finance via `yfinance` (tidak resmi) |
| Market Intelligence | 55 feed: RSS langsung (BBC, MarketWatch/WSJ, Investing, Al Jazeera, CoinDesk, Cointelegraph, EIA, Rigzone, CNBC Indonesia, Kontan, Antara, Tempo) + rilis resmi Fed/ECB/BoE/BoC + Google News per situs (Reuters, Bloomberg, FT, WSJ, CNBC, Nikkei Asia, SCMP, FXStreet, investingLive, Kitco, OilPrice, The Block/Decrypt, Bisnis.com) + topik Google News; klasifikasi rule-based; narasi: Ollama. Jadwal per feed: Google 5 mnt, bank sentral 15 mnt, RSS lain 90 dtk |
| Polymarket (pasar prediksi, pendukung bot) | `gamma-api.polymarket.com` (publik, tanpa key; tidak ditampilkan) — lihat bagian *Polymarket* |
| Market Participant | CFTC Public Reporting (API) → cadangan arsip resmi per tahun `www.cftc.gov/files/dea/history` (TFF & Disaggregated; isi identik); Myfxbook (opsional; riwayat grafik terbentuk selama program berjalan, polling 20 menit, tidak ada backfill) |
| Geopolitical Risk | AI-GPR (Iacoviello), berita ter-geolokasi, GDELT GEO, IMF PortWatch. **Peta negara berwarna** dihitung lokal: titik event dicocokkan ke poligon negara (`world.geojson`), skor = keparahan × kategori × kesegaran |
| Maritime / AIS | Digitraffic Finlandia (Baltik); global opsional via AISStream |
| Supply Chain | UN Comtrade (public preview) |
| Peta | Natural Earth lokal (`vendor/world.geojson`) |

### Polymarket (data pendukung bot, tidak ditampilkan)
Pasar prediksi dengan uang sungguhan (perang/gencatan senjata, Fed, tarif, minyak, China–Taiwan, kripto). Tiap 10 menit diambil pasar aktif teramai per tema (geopolitik, Timur Tengah, Rusia–Ukraina, China/Taiwan, Fed, ekonomi, tarif, minyak, kripto); pasar yang hampir pasti (Yes < 3% / > 97%) atau sepi (< $5.000/24 jam) diabaikan.
- **Dominan BELI / JUAL**: harga "Yes" hanya bergerak karena order yang tereksekusi → Yes **naik** 24 jam (≥ 1 poin) = pembeli dominan (BELI), **turun** = penjual dominan (JUAL). Dominasi tema/keseluruhan = porsi **volume 24 jam** di pasar yang dibeli vs dijual.
- **Arah untuk bot** (driver fundamental baru "Polymarket", bobot 10% di tiap gaya): *risk* (Yes = gencatan/kesepakatan/akhir blokade → risk-on; invasi/perang/resesi/blokade → risk-off), *Fed* (Yes = pemangkasan → dovish; kenaikan/tanpa pemangkasan → hawkish), *kripto* (reach/above → naik; dip/below → turun). Skor = perubahan Yes 24 jam berbobot volume. Peta per aset: indeks & kripto ikut risk-on, emas berlawanan risk-on & ikut Fed dovish, minyak naik saat risk-off, USD menguat saat Fed hawkish, JPY/CHF melemah saat risk-on. Tidak dipakai di backtest (riwayat Polymarket tidak diambil → tanpa kebocoran masa depan).
- Hanya dipakai bot di latar belakang: tidak ada menu/tab dan tidak masuk feed berita. Pasar diambil per tema secara berurutan (jeda 1 dtk) karena sebagian VPS menolak koneksi paralel ke host ini. Kegagalan Polymarket tidak dihitung di lencana "sumber bermasalah" (bot cukup berjalan tanpa driver ini).

### Keandalan sumber (circuit breaker)
- Pemutus 404/403 kini per **sumber daya** (host + path + query). Dulu kuncinya tanpa query, sehingga satu seri FRED yang tidak ada (`fredgraph.csv?id=...` → 404 tiga kali) **mematikan SEMUA seri FRED selama 6 jam** — penyebab makro AS kosong & timeout preload.
- Timeout: paling banyak **satu** ulangan (dulu 3× 25 dtk + percobaan TLS Chrome ≈ 100 dtk per permintaan). Host yang tidak menjawab 3 percobaan berturut-turut **dijeda** 2 → 30 menit: permintaan berikutnya langsung memakai data tersimpan/cadangan.
- Kontrak futures mengikuti siklus bulan resmi bursa (mis. ZB/ES/6E: Mar/Jun/Sep/Des) dan dimulai bulan depan (kontrak bulan berjalan sering sudah kedaluwarsa). Pesan yfinance "symbol may be delisted" tidak lagi membanjiri konsol.

### Cache sumber (lapisan bawah)
Di bawah snapshot, setiap pemanggilan sumber juga ber-cache di memori **dan** SQLite (stale-while-revalidate), dan klien browser menyimpan tampilan terakhir per menu; layar hanya digambar ulang bila server melaporkan data berubah (`/api/rev`, dicek tiap 25 dtk). Tombol **"N sumber bermasalah"** hanya menghitung sumber yang benar-benar mengganggu data (*Perlu perhatian*, *Cadangan aktif*, *Feed opsional tidak aktif*, *Dinonaktifkan sementara* oleh circuit breaker). Situs yang menolak klien biasa dicoba ulang dengan sidik jari TLS Chrome bila `curl_cffi` terpasang (`pip install curl_cffi`).

## Memeriksa sumber dari komputer Anda
```
python -m terminal.selfcheck
```
Mencetak `[OK]/[GAGAL]` untuk setiap sumber dan setiap adapter yield per negara (dengan pesan error), plus status Ollama. Kirim keluarannya bila ada yang gagal — itu cara tercepat menyesuaikan sumber yang diblokir/berubah format di jaringan Anda.

## Batasan yang perlu diketahui
- **Sumber live belum diuji langsung** (lingkungan pengembangan memblokir hampir semua situs data). Yang diuji: seluruh parser dengan fixture berformat resmi, rantai cadangan, rute API dengan data tiruan berbeda per negara, dan seluruh UI di Chromium (desktop + emulasi HP). Parser Bank of Canada, RBA, SNB, MOF Jepang, ECB, dan worldgovernmentbonds dibuat dari format yang dikenal dan dapat berubah; `selfcheck` menunjukkan mana yang perlu disesuaikan.
- `install.bat` ditulis dengan logika inti di Python (`tools/installer.py`, diuji di Linux); skrip `.bat` itu sendiri belum bisa dijalankan di lingkungan pengembangan (bukan Windows).
- Yield 2Y Indonesia tidak ada (Indonesia tidak menerbitkan benchmark 2Y) dan Inggris (BoE IADB tanpa seri 2Y harian; dipakai 5Y). Yield obligasi pemerintah **China & Indonesia** belum ada dari sumber data terbuka (situs penyedianya memuat data lewat API internal) — ditampilkan suku bunga pasar uang 3M (OECD) dan alasannya. CDS best-effort.
- Yahoo Finance dan TradingView gratis tetapi tidak resmi; format bisa berubah. Data di-cache sehingga jumlah pengguna tidak menambah request ke sumber.
- AIS tanpa key hanya Baltik/Eropa Utara; transit choke point global tetap tersedia lewat PortWatch.
- Rating kredit di Fiscal statis (`universe.py`, `RATINGS`).
- Tunnel Cloudflare "quick" gratis, tanpa jaminan uptime.

## Uji
(menu Signal: `tests/test_signal.py`; menu Heatmap & Footprint: `tests/test_heatmap.py` + UI `tests/ui_heatmap_check.py`; backtest data nyata: `python tools/signal_backtest.py --help`)
```
pip install pytest pytest-asyncio
python -m pytest tests                       # ±250 tes: tema & alat (font lokal, login, pembersihan Polymarket), terminal SERVER (satu terminal + agent, start.bat, pengawas tunnel, panel), keandalan (DB, http, watchdog, Polymarket), kunci akses & dua peran, kontrol/runner/menu SIGNAL, snapshot/preload, backtest semua menu, cache, parser, fallback, geo, installer
python tests/run_mock_server.py &            # server dengan dunia tiruan (tanpa internet)
# atau jalur lengkap main.py (preload + tunnel + banner) dengan cloudflared palsu:
#   CLOUDFLARED_PATH=tests/fake_cloudflared_reg.sh python tests/run_mock_main.py 8790   (di konsol: panel TERMINAL SERVER)
# tata letak 7 jendela (rencana posisi, OS apa pun): python tools/arrange_terminals.py --print
python tests/ui_check.py ./shots             # uji UI Chromium 14 menu + SIGNAL (pip install playwright; playwright install chromium)
# uji tema & alat (palette, watchlist/alert, kalkulator, ponsel): MOCK_KEYS=1 python tests/run_mock_server.py 8765 &  python tests/ui_tools_check.py ./shots
# uji peran admin vs user (server dengan dua kunci tiruan):
#   MOCK_KEYS=1 python tests/run_mock_server.py 8765 &  python tests/ui_roles_check.py ./shots
```

- **Tunnel Cloudflare asli tidak bisa diuji di lingkungan pengembangan** (tanpa internet); alur tunnel diuji dengan `cloudflared` palsu yang mencetak alamat seperti aslinya. Pembuatan alamat nyata memakai kode tunnel yang sama dengan versi sebelumnya.
