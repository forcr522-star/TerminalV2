# Terminal (website via Cloudflare)

Saat dijalankan, program otomatis: menyalakan server website (HTTP), **memuat semua menu & fitur beserta datanya lebih dulu dan menyimpannya di database**, membuka tunnel Cloudflare (tanpa akun/token), lalu mencetak **satu alamat Cloudflare** yang langsung membuka website. Tidak ada Telegram, tidak ada bot.

## Jalankan (Windows)
1. **Klik `install.bat`** (sekali, atau kapan pun ada yang kurang). Ia memeriksa semua bahan dan **hanya memasang yang belum ada**; yang sudah ada dilewati (`[SKIP]`):
   Python 3.10+ (via winget bila belum ada) → virtualenv `.venv` → semua modul `requirements.txt` → `cloudflared` → **Ollama** + model AI ringan → file `.env`.
2. **Klik `start.bat`**. Bila instalasi belum lengkap, `start.bat` menjalankan `install.bat` lebih dulu. Launcher membuka **7 terminal** dan menatanya otomatis ke grid 3×3 monitor utama:
   ```
   baris 1 : NEWS AGENT     | TEKNIKAL AGENT | FUNDAMENTAL AGENT
   baris 2 : VOLUME AGENT   | QUANT AGENT    | TERMINAL SERVER (UTAMA)
   baris 3 : FEBRIAN AGENT  | (kosong)       | (kosong)
   ```
   Tiap agent punya jendela sendiri (FEBRIAN tidak lagi menumpang di jendela server). Jendela **TERMINAL SERVER (UTAMA)** = jendela `start.bat` itu sendiri: website, tunnel Cloudflare, dan info server.
3. Lihat jendela **TERMINAL SERVER**. Bagian atasnya adalah panel tetap (tidak ikut bergulir, link tidak pernah tertimbun log):
   ```
   == TERMINAL SERVER (UTAMA) == jam 07:30 | hidup 12 mnt
   CF    : AKTIF | cek OK 07:29:41 (tiap 30s) | edge sin01 | ulang 0x
   ADMIN >> https://xxxx.trycloudflare.com/?key=AbC...
   USER  >> https://xxxx.trycloudflare.com/?key=XyZ...
   WEB   : ONLINE :8787 | DATA SIAP 110/110
   AGENT : NEWS ok TEK ok FUND ok VOL ok QUANT ok FEB ok (6/6)
   SINYAL: ON | intraday | 6 pair | BE ON | AI aktif
   FILE  : data\LINK.txt (link) | data\server.log (log)
   --- LOG ----------------------------------------------------
   ```
   **Buka link hanya setelah `CF : AKTIF`.** Link yang sama juga selalu ditulis ke `data\LINK.txt` (buka dengan Notepad), log lengkap ke `data\server.log`.
   Status sumber data/AI ada di website: klik **DATA** di bilah atas (data tersimpan) atau tombol "N sumber bermasalah".

### Terminal SERVER & Cloudflare (mengatasi error 1033)
Error 1033 ("Cloudflare Tunnel error ... unable to resolve it") berarti link trycloudflare sudah ada tetapi `cloudflared` belum/tidak lagi tersambung ke Cloudflare. Terminal SERVER sekarang mengawasinya:
- Link baru **diverifikasi dulu**: menunggu `Registered tunnel connection`, lalu membuka sendiri `<link>/healthz` lewat Cloudflare. Selama itu status `MEMVERIFIKASI - JANGAN dibuka dulu`; link ADMIN/USER baru muncul setelah `AKTIF`.
- Link diperiksa tiap `TUNNEL_CHECK_EVERY` detik (bawaan 30). Bila Cloudflare membalas 530/1033 (atau 502/503/504) 3× berturut-turut, atau proses `cloudflared` mati, tunnel **dibuat ulang otomatis** dan link BARU langsung tampil di panel + `data\LINK.txt` (link quick tunnel gratis selalu berganti saat dibuat ulang).
- Bila server lokal yang tidak menjawab, link tidak diganti (masalahnya bukan tunnel).
- Gagal membuat tunnel (mis. batas permintaan Cloudflare) → dicoba lagi dengan jeda bertahap 5 dtk → 2 mnt; 2× gagal berturut-turut → protokol berganti `http2` ↔ `quic`.
- `cloudflared` dari `bin\` paket dipakai lebih dulu, baru yang ada di PATH.
- Port sudah dipakai (server lama masih jalan) → pesan jelas, bukan crash diam-diam.
- `SERVER_PANEL=0` di `.env` mengembalikan tampilan log biasa (banner gaya lama).

Linux/macOS: `./install.sh` lalu `./start.sh`. Hanya memeriksa tanpa memasang: `python tools/installer.py --check`.
Alamat Cloudflare gratis **berganti setiap program dijalankan ulang** (isi `PUBLIC_URL` bila memakai named tunnel/domain sendiri).

## Menu SIGNAL (sinyal BUY/SELL multi-pair, tampilan ala MT5)
**Tampilan user (kunci user)** — hanya-baca:
- Kiri **LIST PAIR YANG DI ANALISA** (pair pilihan developer; klik pair untuk mengganti chart), kanan **CHART** besar live (harga berjalan, candle terakhir ikut bergerak). Timeframe chart mengikuti mode trading global: scalping → M5, intraday → H1, swing → D1.
- Bila pair punya sinyal, chart menggambar posisi simulasi LONG/SHORT lengkap: entry, SL (= 1R) dan TP1 / TP2 / TP MAX (kelipatan R) dengan label RR.
- Panel bawah: **TERBUKA** (posisi berjalan), **LIMIT** (menunggu harga menyentuh entry; menampilkan SL, entry, TP, arah dan jarak harga), **TERTUTUP** (riwayat). Untung/rugi ditulis dalam **R** (SL = −1R). Order kedaluwarsa / tidak terisi ditandai batal (tanpa R).
- User tidak bisa melihat isi analisa bot, kontrol, atau peringatan "sumber bermasalah" (ditolak di server, bukan hanya disembunyikan).

**Tampilan admin (kunci admin)** — sama, ditambah tombol di atas:
- **BREAKEVEN ON/OFF**: ON = setelah TP1 tercapai SL dipindah ke harga entry. OFF = SL & TP tetap (tanpa pemindahan/pemberitahuan).
- **SINYAL ON/OFF**: ON = bot menganalisa semua pair terpilih 24 jam. OFF = bot **dilarang menganalisa** pair mana pun dan tidak menerbitkan sinyal baru. (Order yang sudah berjalan tetap dipantau SL/TP-nya supaya daftar order akurat; itu pelacakan, bukan analisa pasar.)
- **INSIDE/ANALISIS**: halaman terpisah. Tab **PILIH PAIR** (popup di tengah, semua pair terminal tanpa terkecuali: FX, komoditas, indeks, kripto, obligasi), **MODE TRADING** (scalping / intraday / swing), **SINYAL** (kembali ke chart). Kiri: pair yang sedang dianalisa dengan titik hijau/merah = arah dominan 10 analisa (buy/sell). Tengah: kartu **ANALISA 1–10** (BULLISH / BEARISH / WAITING). Klik kartu → **HASIL ANALISA** berisi alasan: teknikal, volume & liquidity, fundamental, quantitative, dan kesimpulan BUY / SELL / WAIT.
- Pengaturan kontrol disimpan di database (bertahan setelah restart). Bot latar belakang bisa dimatikan total dengan `SIGNAL_RUNNER=0` di `.env`.

Untuk tiap pair, 10 metode analisa menjalankan alur Teknikal → Volume Profile & Liquidity → Fundamental → Quantitative, diambil suara mayoritas, lalu bot memberi **ENTRY, SL, TP1, TP2, TP MAX** hanya bila plan cocok. Sinyal yang terbit dikunci di jurnal sampai selesai.
**Baca `docs/SIGNAL_RISET.md` sebelum dipakai**: bukti backtest nyata hanya kuat untuk SWING (D1); INTRADAY hampir impas; SCALPING belum tervalidasi. Ini estimasi statistik, bukan jaminan.

## Keamanan: dua kunci akses (admin & user)
Alamat Cloudflare bersifat publik, jadi website dijaga kunci akses. Ada **dua kunci**:
- `ADMIN_KEY` — developer: semua menu + kontrol SIGNAL + halaman INSIDE/ANALISIS + peringatan sumber bermasalah.
- `USER_KEY` — pengguna biasa: semua menu, SIGNAL hanya-baca, tanpa peringatan sumber bermasalah.

Bila kosong, dibuat acak sekali dan disimpan di `data/access_key.txt` (admin) dan `data/user_key.txt` (user). Saat start, `main.py` mencetak **dua alamat** (admin dan user), masing-masing sudah memuat kuncinya. Buka alamat berkunci sekali: server memasang cookie sesi (HttpOnly, berisi peran + HMAC, bukan kunci itu sendiri) lalu menghapus kunci dari bilah alamat. Semua file website dan `/api/*` tertutup tanpa kunci/cookie; endpoint analisa/kontrol/status hanya untuk admin (403 untuk user).
- `ACCESS_KEY` (lama) tetap dianggap kunci admin bila `ADMIN_KEY` kosong. `ADMIN_KEY=none` (atau `ACCESS_KEY=none`) mematikan penjagaan (semua orang = admin). `USER_KEY=none` mematikan akses user.
- `USER_KEY` yang sama dengan kunci admin diabaikan (diganti kunci acak) dan diberi peringatan di banner, supaya user tidak pernah mendapat akses admin.

## Muat-awal & data tersimpan (database)
- **Saat start (tahap 1, ditunggu):** semua menu beserta setiap tab/negara/kelas aset di dalamnya dimuat paralel dan disimpan di `data/terminal.db` (±110 data). Progres tercetak per item. Batas `PRELOAD_TIMEOUT` (300 dtk) mencegah satu sumber yang macet menahan alamat selamanya; sisanya selesai di latar belakang.
- **Tahap 2 (latar belakang):** ekor panjang — riwayat semua simbol, setiap instrumen COT, setiap kontrak futures, semua ETF sektor, semua aset Quant, pasangan negara Compare, mitra dagang (±450 data). Tidak menahan apa pun.
- **Pengunjung baru / masuk ulang:** semua dilayani langsung dari snapshot (±beberapa ms), tanpa memuat sumber satu per satu. Kombinasi yang belum pernah dimuat dihitung sekali saat diminta lalu ikut tersimpan.
- **Restart:** snapshot dibaca dari database, jadi program langsung siap; data lama diperbarui diam-diam di latar belakang (`PRELOAD_FORCE=1` memaksa menunggu muat-ulang penuh).
- **Pembaruan otomatis:** tiap data punya TTL sendiri (harga 60-120 dtk, berita 60-90 dtk, makro/bank sentral 10-15 mnt, COT 1 jam, dst.). Yang melewati TTL diperbarui di latar belakang; pengunjung tidak pernah menunggu.
- **Aman terhadap sumber mati:** hasil yang gagal/kosong tidak pernah menimpa snapshot yang masih baik (dashboard mempertahankan panel terakhir yang baik); sumber yang gagal dicoba ulang dengan jeda bertahap (30 dtk → 15 mnt).

## Kredensial: tidak ada yang wajib
Tidak ada API key berbayar atau langganan di platform lain. Dua pendaftaran **gratis** bersifat opsional: AISStream (`AISSTREAM_API_KEY`, kapal global) dan akun Myfxbook (`MYFXBOOK_EMAIL`/`MYFXBOOK_PASSWORD`, sentimen retail).

### AI lokal (Ollama, tanpa key)
Narasi Catalyst/Research ditulis model lokal `gemma3:1b` (±0,8 GB; ganti lewat `OLLAMA_MODEL`, alternatif ringan: `qwen2.5:1.5b`, `llama3.2:1b`). Narasi dibuat di latar belakang, **disimpan**, dan hanya ditulis ulang bila headline berubah — membuka menu tidak memicu AI. Tanpa Ollama (atau `LLM_ENABLED=0`) aplikasi tetap jalan penuh dengan ringkasan otomatis berbasis aturan.

## Sumber data (semua gratis, tanpa key)
Setiap data punya **rantai cadangan**; satu sumber yang gagal tidak mengosongkan tampilan. Bila tidak ada sumber gratis yang menyediakan suatu angka, tampilan menulis alasannya (bukan "n/a" atau grafik kosong).

| Modul | Sumber (urutan prioritas) |
|---|---|
| Macro (AS) | FRED (`fredgraph.csv`) |
| Macro (negara lain) | IMF DataMapper → World Bank (tahunan); pasar mingguan (indeks/FX/yield 10Y) dari Yahoo; COT mata uang dari CFTC. Tiap negara punya tabel sendiri |
| Regime / Compare | z-score FRED (AS) → IMF/World Bank (negara lain) |
| Central Bank – suku bunga | BIS → FRED |
| Central Bank – yield | AS: FRED → US Treasury → Yahoo · Euro: ECB → FRED/OECD · Jepang: MOF (beberapa URL kandidat; URL berubah/404 tidak lagi membuat status merah) → FRED/OECD · Kanada: Bank of Canada · Australia: RBA · Swiss: SNB · Inggris: Bank of England IADB (5/10/20Y) → FRED/OECD · semua: FRED/OECD (10Y bulanan) → worldgovernmentbonds.com. Stooq dihapus (tidak lagi bisa diakses tanpa key). Kolom dipilih dari label tenor, bukan nomor seri hafalan |
| Central Bank – lainnya | Inflasi/suku bunga riil (FRED/IMF/WB), neraca bank sentral AS/Jepang (FRED) dan Euro (ECB Data Portal → FRED), CDS (scrape worldgovernmentbonds, best-effort), RSS resmi + Google News |
| Fiscal | IMF DataMapper → World Bank → BIS (utang/PDB, mis. China); US Treasury FiscalData. Negara tanpa data publik sama sekali disembunyikan dari tab (bila ≥3 negara punya data) |
| Fiscal – lelang | AS: FiscalData (jadwal + hasil) → TreasuryDirect; negara lain: kalender TradingView (judul *Auction/Tender*, nilai = yield hasil) → ForexFactory. Panel menampilkan tab **Mendatang** dan **Riwayat**; negara tanpa data lelang tidak menampilkan panelnya |
| Market, Quant, Futures, ETF, Financials | Yahoo Finance via `yfinance` (tidak resmi) |
| Market Intelligence | ±41 RSS + klasifikasi rule-based; narasi: Ollama |
| Market Participant | CFTC Public Reporting; Myfxbook (opsional; riwayat grafik terbentuk selama program berjalan, polling 20 menit, tidak ada backfill) |
| Geopolitical Risk | AI-GPR (Iacoviello), berita ter-geolokasi, GDELT GEO, IMF PortWatch. **Peta negara berwarna** dihitung lokal: titik event dicocokkan ke poligon negara (`world.geojson`), skor = keparahan × kategori × kesegaran |
| Maritime / AIS | Digitraffic Finlandia (Baltik); global opsional via AISStream |
| Supply Chain | UN Comtrade (public preview) |
| Peta | Natural Earth lokal (`vendor/world.geojson`) |

### Cache sumber (lapisan bawah)
Di bawah snapshot, setiap pemanggilan sumber juga ber-cache di memori **dan** SQLite (stale-while-revalidate), dan klien browser menyimpan tampilan terakhir per menu; layar hanya digambar ulang bila server melaporkan data berubah (`/api/rev`, dicek tiap 25 dtk). Tombol **"N sumber bermasalah"** hanya menghitung sumber yang benar-benar mengganggu data (*Perlu perhatian*, *Cadangan aktif*, *Feed opsional tidak aktif*, *Dinonaktifkan sementara* oleh circuit breaker). Situs yang menolak klien biasa dicoba ulang dengan sidik jari TLS Chrome bila `curl_cffi` terpasang (`pip install curl_cffi`).

## Memeriksa sumber dari komputer Anda
```
python -m terminal.selfcheck
```
Mencetak `[OK]/[GAGAL]` untuk setiap sumber dan setiap adapter yield per negara (dengan pesan error), plus status Ollama. Kirim keluarannya bila ada yang gagal — itu cara tercepat menyesuaikan sumber yang diblokir/berubah format di jaringan Anda.

## Batasan yang perlu diketahui
- **Sumber live belum diuji langsung** (lingkungan pengembangan memblokir hampir semua situs data). Yang diuji: seluruh parser dengan fixture berformat resmi, rantai cadangan, rute API dengan data tiruan berbeda per negara, dan seluruh UI di Chromium (desktop + emulasi HP). Parser Bank of Canada, RBA, SNB, MOF Jepang, ECB, dan worldgovernmentbonds dibuat dari format yang dikenal dan dapat berubah; `selfcheck` menunjukkan mana yang perlu disesuaikan.
- `install.bat` ditulis dengan logika inti di Python (`tools/installer.py`, diuji di Linux); skrip `.bat` itu sendiri belum bisa dijalankan di lingkungan pengembangan (bukan Windows).
- Yield 2Y Indonesia tidak ada (Indonesia tidak menerbitkan benchmark 2Y); CDS dan neraca bank sentral selain AS/Euro/Jepang tidak punya sumber gratis terbuka — tampilan menyebutkannya.
- Yahoo Finance dan TradingView gratis tetapi tidak resmi; format bisa berubah. Data di-cache sehingga jumlah pengguna tidak menambah request ke sumber.
- AIS tanpa key hanya Baltik/Eropa Utara; transit choke point global tetap tersedia lewat PortWatch.
- Rating kredit di Fiscal statis (`universe.py`, `RATINGS`).
- Tunnel Cloudflare "quick" gratis, tanpa jaminan uptime.

## Uji
(menu Signal: `tests/test_signal.py`; backtest data nyata: `python tools/signal_backtest.py --help`)
```
pip install pytest pytest-asyncio
python -m pytest tests                       # ±200 tes: terminal SERVER (7 jendela, start.bat, pengawas tunnel, panel), kunci akses & dua peran, kontrol/runner/menu SIGNAL, snapshot/preload, backtest semua menu, cache, parser, fallback, geo, installer
python tests/run_mock_server.py &            # server dengan dunia tiruan (tanpa internet)
# atau jalur lengkap main.py (preload + tunnel + banner) dengan cloudflared palsu:
#   CLOUDFLARED_PATH=tests/fake_cloudflared_reg.sh python tests/run_mock_main.py 8790   (di konsol: panel TERMINAL SERVER)
# tata letak 7 jendela (rencana posisi, OS apa pun): python tools/arrange_terminals.py --print
python tests/ui_check.py ./shots             # uji UI Chromium 14 menu + SIGNAL (pip install playwright; playwright install chromium)
# uji peran admin vs user (server dengan dua kunci tiruan):
#   MOCK_KEYS=1 python tests/run_mock_server.py 8765 &  python tests/ui_roles_check.py ./shots
```

- **Tunnel Cloudflare asli tidak bisa diuji di lingkungan pengembangan** (tanpa internet); alur tunnel diuji dengan `cloudflared` palsu yang mencetak alamat seperti aslinya. Pembuatan alamat nyata memakai kode tunnel yang sama dengan versi sebelumnya.
