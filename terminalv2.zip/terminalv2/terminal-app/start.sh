#!/usr/bin/env bash
cd "$(dirname "$0")"
if [ ! -f .install_ok ] || [ ! -x .venv/bin/python ]; then
  echo "Instalasi belum lengkap - menjalankan install.sh ..."
  ./install.sh || { echo "Instalasi belum lengkap."; exit 1; }
fi
[ -f .env ] || cp .env.example .env
. .venv/bin/activate
python main.py
