#!/usr/bin/env bash
cd "$(dirname "$0")"
PY=$(command -v python3 || command -v python)
[ -z "$PY" ] && { echo "[GAGAL] Python 3.10+ belum terpasang (apt install python3 python3-venv)"; exit 1; }
"$PY" tools/installer.py "$@"
