"""TERMINAL SERVER (UTAMA): server website + tunnel Cloudflare + panel info server.

Dijalankan oleh start.bat di jendela "TERMINAL SERVER (UTAMA)" (baris 2, kolom 3 grid). Jendela ini:
  * menyalakan server website (FastAPI/uvicorn) dan mesin data/sinyal;
  * membuat tunnel Cloudflare, memverifikasi link sebelum diumumkan, memantau, dan membuat ulang bila putus;
  * menampilkan panel tetap: status link Cloudflare, link ADMIN/USER, data, agent, sinyal - log bergulir di bawahnya.
Link juga ditulis ke data/LINK.txt dan log lengkap ke data/server.log.
"""
import asyncio
import socket
import sys
import time

import uvicorn

from terminal import config, auth, server, preload, layout, watchdog
from terminal.agents import run as agents_run
from terminal import panel as P
from terminal.tunnel import Supervisor

LINK_FILE = config.DATA_DIR / "LINK.txt"
LOG_FILE = config.DATA_DIR / "server.log"
LIVE_STATES = ("active", "registered", "unstable", "fixed")

# Baris status Cloudflare (dibuat pendek: jendela SERVER hanya 1/3 layar, +-80 kolom).
TUNNEL_TEXT = {
    "starting": "MEMBUAT TUNNEL ({protocol}) ...",
    "verifying": "MEMVERIFIKASI link baru - JANGAN dibuka dulu (bisa error 1033)",
    "active": "AKTIF | cek OK {verified} (tiap {every}s) | edge {edge} | ulang {restarts}x",
    "registered": "TERSAMBUNG (edge {edge}) - PC ini tak bisa cek link sendiri, silakan buka",
    "unstable": "TIDAK STABIL ({fails}x): {last} - diulang otomatis",
    "restarting": "MEMBUAT ULANG tunnel - link BARU muncul di sini",
    "error": "GAGAL: {error} - dicoba lagi otomatis",
    "fixed": "TETAP (PUBLIC_URL dari .env)",
}
AGENT_SHORT = dict(news="NEWS", technical="TEK", fundamental="FUND", volume="VOL", quant="QUANT", febrian="FEB")
AGENT_STATUS = dict(ok="ok", work="kerja", idle="idle", error="ERR", off="MATI")


# ----------------------------------------------------------------------------------------------- link & banner
def access_links(base):
    """Daftar (label, url) untuk alamat dasar tertentu."""
    if not auth.enabled():
        return [("LINK", f"{base}/")]
    out = [("ADMIN", f"{base}/?key={auth.access_key()}")]
    ukey = auth.user_key()
    if ukey:
        out.append(("USER", f"{base}/?key={ukey}"))
    return out


def banner(public_url):
    """Banner gaya lama (dipakai bila panel mati: keluaran dialihkan/pengujian)."""
    line = "=" * 74
    print(f"\n{line}\n {config.TERMINAL_NAME.upper()} SIAP - buka alamat di browser (satu klik, sudah termasuk kunci akses):\n", flush=True)
    if not auth.enabled():
        if public_url:
            print(f"   {public_url}/\n", flush=True)
        print(f"   Lokal : http://127.0.0.1:{config.PORT}/", flush=True)
        print("   Kunci : DIMATIKAN (ACCESS_KEY=none) - siapa pun yang tahu alamat masuk sebagai ADMIN", flush=True)
    else:
        akey, ukey = auth.access_key(), auth.user_key()
        base = public_url or f"http://127.0.0.1:{config.PORT}"
        print(f"   ADMIN (developer, akses penuh - JANGAN dibagikan):\n      {base}/?key={akey}", flush=True)
        if ukey:
            print(f"   USER  (pengguna biasa - boleh dibagikan):\n      {base}/?key={ukey}\n", flush=True)
        else:
            print("   USER  : dimatikan (USER_KEY=none) - hanya admin yang bisa masuk\n", flush=True)
        if public_url:
            print(f"   Lokal : http://127.0.0.1:{config.PORT}/?key={akey}", flush=True)
        print(f"   Kunci admin : {akey}   (ADMIN_KEY di .env, atau {config.DATA_DIR / 'access_key.txt'})", flush=True)
        if ukey:
            print(f"   Kunci user  : {ukey}   (USER_KEY di .env, atau {config.DATA_DIR / 'user_key.txt'})", flush=True)
        if auth.user_key_conflict():
            print("   PERINGATAN  : USER_KEY di .env sama dengan kunci admin -> diabaikan, kunci user acak dipakai. Ubah USER_KEY agar berbeda.", flush=True)
    if public_url and not config.PUBLIC_URL:
        print("   Catatan: alamat Cloudflare gratis berganti setiap program dijalankan ulang.", flush=True)
    print(f"{line}\n", flush=True)


def write_link_file(tun):
    """data/LINK.txt: salinan link terbaru (bisa dibuka dengan Notepad kapan pun)."""
    url = tun.get("url") if tun.get("state") in LIVE_STATES else None
    rows = [f"{config.TERMINAL_NAME.upper()} - link akses (diperbarui {time.strftime('%Y-%m-%d %H:%M:%S')})",
            f"Status Cloudflare : {tun.get('state', '-').upper()}" + ("" if url else " - link belum siap, tunggu status AKTIF"), ""]
    if url:
        rows += [f"{label:<5}: {u}" for label, u in access_links(url)]
    rows += [f"LOKAL: {access_links(f'http://127.0.0.1:{config.PORT}')[0][1]}", "",
             "Link ADMIN memberi akses penuh - JANGAN dibagikan. Link Cloudflare gratis berganti setiap tunnel dibuat ulang."]
    try:
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        LINK_FILE.write_text("\n".join(rows) + "\n", encoding="utf-8")
    except Exception as exc:
        print(f"[server] gagal menulis {LINK_FILE}: {exc}", flush=True)


# ----------------------------------------------------------------------------------------------- panel
def _agents_line():
    from terminal.agents import bus
    st = bus.state()
    parts = [f"{AGENT_SHORT[i]} {AGENT_STATUS.get(st['agents'][i]['status'], st['agents'][i]['status'])}" for i in bus.IDS]
    return " ".join(parts) + f" ({len(st['active'])}/{len(bus.IDS)})"


def _signal_line():
    from terminal.signals import control
    from terminal import llm
    c = control.get()
    sig = "ON" if c["on"] else "OFF"
    if not config.SIGNAL_RUNNER:
        sig += " (bot mati: SIGNAL_RUNNER=0)"
    ai = "aktif" if llm.enabled() else "mati"
    return f"{sig} | {c['mode']} | {len(c['pairs'])} pair | BE {'ON' if c['be'] else 'OFF'} | AI {ai}"


def _heatmap_line():
    from terminal.heatmap import engine, control, settings
    if not settings.COLLECTOR:
        return "MATI (HEATMAP_COLLECTOR=0)"
    st, pairs = engine.manager.status(), control.selected()
    if not pairs:
        return "tidak ada pair dipilih admin (tidak memantau apa pun)"
    live = sum(1 for p in st["pairs"].values() if p["state"] == "live")
    ws = st["ws"]
    w = "WS OK" if ws.get("connected") else (f"WS GAGAL: {(ws.get('err') or '-')[:40]}" if ws.get("err") else "WS menyambung ...")
    return f"{w} | trade {live}/{len(pairs)} live | " + " ".join(p.replace("USDT", "") for p in pairs)


def header_lines(tun, agents, signal):
    from terminal import snapshots as S
    st = server.state
    up = P.fmt_age(time.time() - st["started"])
    out = [(f"== {layout.SERVER_TITLE} == jam {time.strftime('%H:%M')} | hidup {up}", False)]
    s = tun.get("state", "starting")
    txt = TUNNEL_TEXT.get(s, s).format(
        protocol=tun.get("protocol"), verified=P.clock(tun.get("verified_at")) if tun.get("verified_at") else "-",
        every=int(config.TUNNEL_CHECK_EVERY), edge=tun.get("edge") or "?", restarts=tun.get("restarts", 0),
        fails=tun.get("fails", 0), last=(tun.get("last_result") or "-")[:40], error=(tun.get("error") or "-")[:50])
    out.append((f"CF    : {txt}", False))
    url = tun.get("url") if s in LIVE_STATES else None
    if url:
        out += [(f"{label:<5} >> {u}", True) for label, u in access_links(url)]
    else:
        out.append((f"LOKAL >> {access_links(f'http://127.0.0.1:{config.PORT}')[0][1]}", True))
        out.append(("      (link Cloudflare muncul di sini setelah AKTIF)", False))
    pre = st["preload"]
    try:
        summ = S.summary()
        bad = summ.get("failing", 0)
        stored = f"{summ.get('ready', 0)}/{summ.get('planned', 0)}"
    except Exception:
        bad, stored = 0, "?"
    if pre.get("phase") == "ready":
        data = f"SIAP {stored}" + (f" | {bad} sumber bermasalah" if bad else "")
    elif pre.get("phase") == "phase1":
        data = f"MEMUAT {pre.get('done', 0)}/{pre.get('total', 0)} (menu menyusul)"
    else:
        data = "menyiapkan ..."
    out.append((f"WEB   : ONLINE :{config.PORT} | DATA {data}", False))
    if agents:
        out.append((f"AGENT : {agents}", False))
    if signal:
        out.append((f"SINYAL: {signal}", False))
    try:
        out.append((f"HEATM : {_heatmap_line()}", False))
    except Exception:
        pass
    sep = "\\" if sys.platform == "win32" else "/"
    out.append((f"FILE  : {LINK_FILE.parent.name}{sep}{LINK_FILE.name} (link) | {LOG_FILE.parent.name}{sep}{LOG_FILE.name} (log)", False))
    return out


async def status_loop(panel, sup, ready):
    """Perbarui panel & data/LINK.txt; umumkan banner (mode tanpa panel) sekali per link."""
    last_key, announced = None, None
    while True:
        tun = dict(sup.status)
        live = tun.get("url") if tun.get("state") in LIVE_STATES else None
        server.state["public_url"] = live
        key = (tun.get("state") in LIVE_STATES, live)
        if key != last_key:
            write_link_file(tun)
            last_key = key
        if live and ready.is_set() and live != announced and not panel.enabled:
            banner(live)
            announced = live
        if panel.enabled:
            try:
                agents = await asyncio.to_thread(_agents_line)
            except Exception:
                agents = None
            try:
                signal = _signal_line()
            except Exception:
                signal = None
            try:
                panel.set_header(header_lines(tun, agents, signal))
            except Exception as exc:
                panel.set_header([(f"panel error: {exc}", False)])
        await asyncio.sleep(1.0)


# ----------------------------------------------------------------------------------------------- server
def port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


async def amain(panel=None):
    panel = panel or P.Panel(enabled=False)
    if port_in_use(config.PORT):
        raise SystemExit(f"[server] Port {config.PORT} sudah dipakai - kemungkinan server lama masih berjalan. "
                         f"Tutup jendela {layout.SERVER_TITLE} yang lama (atau ubah PORT di .env), lalu jalankan start.bat lagi.")
    cfg = uvicorn.Config(server.app, host=config.HOST, port=config.PORT, log_level="warning", loop="asyncio")
    srv = uvicorn.Server(cfg)
    srv.install_signal_handlers = lambda: None
    server_task = asyncio.create_task(srv.serve())
    while not srv.started:
        if server_task.done():
            server_task.result()
            raise SystemExit("[server] server website berhenti saat start (lihat log di atas)")
        await asyncio.sleep(0.2)
    print(f"[server] berjalan di http://{config.HOST}:{config.PORT}", flush=True)
    watchdog.start(log=lambda m: print(m, flush=True))   # catat bila server macet (penyebab PING tinggi / "Host Error")
    if auth.enabled():
        auth.access_key()  # buat/baca kunci admin & user sekarang agar tersimpan sebelum URL dicetak
        auth.user_key()
    ready = asyncio.Event()
    sup = Supervisor(config.PORT, log=lambda m: print(m, flush=True))
    tunnel_task = asyncio.create_task(sup.run())
    status_task = asyncio.create_task(status_loop(panel, sup, ready))
    deep = None
    agents_task = asyncio.create_task(agents_run.run_all()) if config.AGENTS_INPROCESS else None
    try:
        await preload.phase1()           # semua menu dimuat & disimpan dulu (berjalan paralel dengan pembuatan tunnel)
        ready.set()
        if not panel.enabled and sup.status.get("state") not in LIVE_STATES:
            banner(None)                 # tunnel belum siap: tampilkan alamat lokal dulu, alamat Cloudflare menyusul
        deep = asyncio.create_task(preload.phase2())
        await asyncio.wait([server_task, tunnel_task], return_when=asyncio.FIRST_COMPLETED)
        if tunnel_task.done() and not tunnel_task.cancelled() and tunnel_task.exception():
            print(f"[tunnel] pengawas berhenti: {tunnel_task.exception()!r}", flush=True)
        await server_task
    finally:
        for t in (deep, tunnel_task, status_task, agents_task):
            if t:
                t.cancel()
        await asyncio.gather(*[t for t in (deep, tunnel_task, status_task, agents_task) if t], return_exceptions=True)
        srv.should_exit = True
        await asyncio.sleep(0.2)


def main():
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    layout.set_console_title(layout.SERVER_TITLE)
    use_panel = config.SERVER_PANEL and sys.stdout.isatty()
    panel = P.Panel(logfile=str(LOG_FILE), enabled=use_panel).install()
    code, tail = 0, 0
    try:
        asyncio.run(amain(panel))
    except KeyboardInterrupt:
        pass
    except SystemExit as exc:
        code, tail = (exc.code if isinstance(exc.code, int) else 1), 25
        if not isinstance(exc.code, int):
            print(exc.code, flush=True)
    except BaseException:
        import traceback
        traceback.print_exc()
        code, tail = 1, 40
    finally:
        panel.close(show_tail=tail)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
