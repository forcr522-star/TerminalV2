# Menu SIGNAL — riset, metode, dan hasil backtest (data harga nyata)

Dokumen ini mencatat **apa yang diuji, apa yang terbukti, dan apa yang TIDAK terbukti**. Angka diproduksi ulang dengan `python tools/signal_backtest.py` (lihat bagian terakhir).

## 1. Ringkasan jujur
| Gaya | Bukti backtest (biaya spread dihitung) | Kesimpulan |
|---|---|---|
| **SWING (D1)** | 395 trade, 7 pair + XAUUSD 2012-2026: **win TP1 67,3%**, rata-rata **+0,13R**, PF **1,36** (paruh kedua/out-of-sample sama baiknya dengan paruh pertama) | **Terbukti positif & konsisten.** Gaya paling layak dipakai. |
| **INTRADAY (H1)** | 3.054 trade, 5 pair 2012-2022: win TP1 61,2%, rata-rata +0,013R, PF 1,03 (out-of-sample +0,033R, PF 1,08) | **Hampir impas.** Win rate bagus tetapi keuntungan bersih sangat tipis; biaya spread yang lebih besar dari asumsi bisa membuatnya rugi. |
| **SCALPING (M5)** | Data M5 publik hanya EURUSD ±6 bulan; konsensus ketat menghasilkan 4 trade | **Belum tervalidasi.** Tidak ada bukti edge. Sinyal sengaja sangat jarang. Perlakukan sebagai eksperimental. |

Tidak ada konfigurasi yang menghasilkan win rate 80-90% secara valid. Win rate "TP1 tercapai sebelum SL" ±60-70% adalah hasil nyata; win rate lebih tinggi hanya bisa dibuat dengan menaruh TP1 sangat dekat (keuntungan per trade mengecil) — itu bukan edge. Lapisan **Fundamental tidak bisa diuji historis** (tidak ada data makro per-bar di dataset publik), jadi kontribusinya belum terbukti; ia dipakai sebagai konfirmasi/veto dan filter rilis berita.

## 2. Riset strategi (satu per satu)
Sumber yang ditemukan dan relevan: *Time Series Momentum* (Moskowitz, Ooi, Pedersen, JFE 2012; momentum deret-waktu positif di komoditas, mata uang, indeks, obligasi); dataset AQR dan ringkasan Quantpedia; beberapa blog backtest (kualitas bukti rendah, dipakai hanya sebagai petunjuk arah): win rate tinggi hampir selalu berarti payoff kecil; mean-reversion berwin-rate tinggi di indeks tetapi **negatif pada emas** (artikel 8.693 trade XAUUSD). Kesimpulan riset yang dipakai sebagai hipotesis: **tren/momentum + masuk saat pullback ke level bernilai** adalah keluarga strategi dengan dukungan terbaik; mean-reversion dan breakout murni lemah di FX/emas.

Hipotesis itu lalu **diuji sendiri** pada data nyata (tiap metode berdiri sendiri, struktur TP yang sama). Kolom kiri = hipotesis teknikal mentah, kanan = setelah validasi Volume Profile & Liquidity (langkah 2).

**SWING D1** (7 pair + XAUUSD panjang):
| Metode | Mentah: win TP1 / rata-rata R | Tervalidasi: win TP1 / rata-rata R / PF |
|---|---|---|
| Time-Series Momentum | 58,4% / +0,046 | **69,2% / +0,156 / 1,50** |
| EMA Stack Pullback | 59,9% / +0,045 | **68,8% / +0,164 / 1,52** |
| MACD + ADX | 59,2% / +0,040 | 66,7% / +0,148 / 1,45 |
| Squeeze Breakout | 64,7% / +0,104 | 66,5% / +0,163 / 1,48 |
| Value Area / POC | 56,7% / +0,001 | 62,5% / +0,036 / 1,10 |
| Liquidity Sweep | 59,2% / +0,076 | 60,9% / +0,061 / 1,15 |
| Market Structure | 53,6% / +0,013 | 59,9% / +0,034 / 1,08 |
| RSI(2) Reversion | 56,3% / 0,000 | 58,9% / +0,001 / 1,00 |
| Donchian Breakout | 46,5% / +0,049 | 57,0% / −0,013 / 0,97 |
| Bollinger Z-Score | 50,1% / −0,077 | 53,5% / −0,053 / 0,89 |

**INTRADAY H1** (EURUSD, GBPUSD, XAUUSD): hanya metode tren yang positif tipis setelah validasi (TSMOM 65,5% / +0,041R; EMA Pullback 64,4% / +0,027R; Squeeze +0,017R); metode lain negatif (Bollinger −0,185R, Donchian −0,104R, Value −0,093R, dst.).

Temuan yang konsisten di kedua timeframe:
1. **Validasi Volume Profile & Liquidity (langkah 2) benar-benar menambah nilai**: win rate naik ±4-11 poin dan rata-rata R naik pada hampir semua metode.
2. Metode tren/pullback > breakout murni > mean-reversion. Metode lemah tetap ikut memilih (sesuai permintaan 10 metode), tetapi bobotnya diturunkan oleh statistik historisnya sendiri pada pair itu.

## 3. Arsitektur analisa (kode: `terminal/signals/`)
1. **Teknikal** (`methods.py`): 10 metode menyusun bias + hipotesis titik pullback + SL struktural untuk gaya yang dipilih (M5 bias H1 / H1 bias H4 / D1 bias W1). Semua perhitungan hanya memakai data sampai bar itu (diuji otomatis: tanpa look-ahead).
2. **Volume Profile & Liquidity** (`profile.py`, `structure.py`, `plan.py`): POC/VAH/VAL/HVN/LVN, pool likuiditas (swing, equal high/low, PDH/PDL), Fair Value Gap. Entry yang tidak di level bernilai **dihitung ulang** (dirata-ratakan dengan level valid terdekat) atau metode abstain; SL digeser keluar dari pool likuiditas; TP dikunci di depan level lawan. (Bila volume tidak tersedia, dipakai profil waktu-harga.)
3. **Fundamental** (`fundamental.py`): selisih suku bunga & arah 6 bulan, yield 10Y, regime makro, COT, sentimen retail (kontrarian), katalis berita, risiko geopolitik (GPR), dan **penahan rilis berita berdampak tinggi**. Bobot driver mengikuti gaya (scalping → berita/kalender; swing → makro). Konflik kuat dengan fundamental = veto metode (intraday/swing).
4. **Quantitative** (`quant.py`): posterior Beta-Binomial peluang TP1 tiap metode (prior = peluang acak ½ + rata-rata gabungan metode); drift tersirat pada gerak Brown berdrift → peluang TP2/TP MAX/BE secara analitik → distribusi hasil, **EV (R) bersih biaya**, Kelly pecahan untuk risiko disarankan; rezim (Hurst, Variance-Ratio Lo-MacKinlay, Efficiency Ratio, persentil ATR); penyesuaian ulang SL/TP1 dari grid kecil dengan batas peluang minimum. Verifikasi matematika di tes: tanpa drift EV = 0 (baik BE ON maupun OFF) dan biaya mengurangi EV tepat sebesar biaya.
5. **Suara mayoritas** (`engine.py`): metode searah ≥ 3 (scalping ≥ 5), unggul ≥ 1 (scalping ≥ 3), searah bias HTF. Entry/SL/TP final = **rata-rata berbobot** metode searah yang titik entry-nya berkelompok, lalu disesuaikan quant. Sinyal hanya terbit bila peluang TP1 ≥ 55% dan EV ≥ +0,05R; selain itu bot menampilkan alasan "menunggu".

Struktur TP: TP1 / TP2 / TP MAX = 50% / 30% / 20% posisi (kelipatan R awal 0,8 / 1,6-1,8 / 2,8-3,2, dikunci ke level). **Breakeven ON**: setelah TP1 tercapai SL dipindah ke entry. **OFF**: SL dan TP fixed. Pengaturan BE berlaku langsung pada sinyal yang sedang berjalan.

Sinyal yang sudah terbit **dikunci** di jurnal (tabel `signal_log`) sampai: SL kena / TP / waktu habis / tidak terisi dalam N bar / TP1 tersentuh sebelum entry. Riwayat dan rekam jejak bot ada di tab "Riwayat & Statistik".

## 4. Temuan negatif yang mengubah desain
- **Gerbang EV keras per metode** (tolak metode yang EV historisnya ≤ 0) justru menurunkan hasil (statistik historis terlalu berisik) → dimatikan; statistik hanya dipakai sebagai bobot.
- **Penyesuaian ulang agresif** (SL lebih ketat, TP1 lebih jauh dari grid model) menurunkan win rate nyata dari ±58% ke ±48% karena model barrier mengekstrapolasi berlebihan → grid dibatasi konservatif (SL ×1,0/1,15; TP1 0,6-0,8R).
- **Lebih banyak metode setuju ≠ win rate lebih tinggi** (metode tren saling berkorelasi). Ambang konsensus dipilih agar jumlah sinyal masuk akal, bukan untuk mengejar win rate.

## 5. Asumsi & keterbatasan
- Biaya bolak-balik per trade: FX 0,010% harga (±1 pip EURUSD), XAUUSD 0,016%, indeks 0,012%, kripto 0,06% — ubah di `terminal/signals/config.py` (`COST_FRAC`) sesuai spread broker Anda.
- Simulasi konservatif: bar yang menyentuh SL dan TP sekaligus dianggap SL lebih dulu; BE aktif mulai bar setelah TP1; order limit batal bila tidak terisi atau TP1 tersentuh lebih dulu.
- Data uji: FX majors D1/H1 2012-2022 (komo135/forex-historical-data), XAUUSD D1 2000-2026 (goldfxgraph, tumpang-tindih dengan XAUUSD 2012-2022 di gabungan swing), EURUSD 1 menit 2026. Data live bot memakai Yahoo Finance (simbol Yahoo: emas = GC=F dst.), bukan feed Exness, sehingga level harga bisa berbeda beberapa poin.
- Volume FX di Yahoo umumnya 0 → profil volume FX berbasis waktu-harga; indeks/kripto memakai volume asli.
- Hasil historis bukan jaminan hasil masa depan. Parameter dipilih pada data yang sama yang dilaporkan sebagian (paruh pertama/kedua dilaporkan terpisah untuk melihat konsistensi, tetapi ini bukan pengujian out-of-sample murni).

## 6. Mereproduksi
```
python tools/signal_backtest.py --mode swing                 # ensemble, semua pair
python tools/signal_backtest.py --mode intraday --be 0       # BE OFF
python tools/signal_backtest.py --mode swing --per-method    # riset satu per satu
python -m pytest tests/test_signal.py                         # tes matematika, tanpa look-ahead, simulator, API
```
Data diunduh otomatis ke `data_backtest/` (butuh `git` dan internet).
