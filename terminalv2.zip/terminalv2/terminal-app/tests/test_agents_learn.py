"""Agent (bus & menu THINKING), pelacak trade, log belajar dari jurnal sinyal live, dan penghapusan menu BACKTEST."""
import pathlib
import sqlite3

import numpy as np
import pytest

from terminal import store
from terminal.signals import learn, tracker
from terminal.signals.config import TP_WEIGHTS
from terminal.agents import bus

ROOT = pathlib.Path(__file__).resolve().parents[1]


def test_cost_is_charged_per_leg_and_swap_accrues():
    plan = dict(d=1, entry=100.0, sl=99.0, tp=[101.0, 102.0, 103.0], w=TP_WEIGHTS, expiry=4, max_hold=10, cost=0.3, swap=0.1)
    o, h, l, c = (np.array(x, float) for x in ([100.5, 100.4, 100.2, 100.8, 101.6],
                                              [100.6, 100.5, 100.9, 101.7, 103.2],
                                              [100.4, 99.9, 100.1, 100.7, 101.5],
                                              [100.5, 100.2, 100.8, 101.6, 103.0]))
    r = tracker.simulate(plan, o, h, l, c, 0, True)
    assert r["status"] == "CLOSED" and r["tp_hits"] == 3
    assert r["cost"] == pytest.approx(0.3)            # tiga leg x bobot = total 1.0 posisi x biaya
    assert r["swap"] > 0                              # swap diakrualkan selama posisi hidup
    assert r["r"] < TP_WEIGHTS[0] * 1.0 + TP_WEIGHTS[1] * 2.0 + TP_WEIGHTS[2] * 3.0


def test_agent_bus_status_log_and_pulse():
    bus.reset()
    st = bus.state()
    assert set(st["agents"]) == {"news", "technical", "fundamental", "volume", "quant", "febrian"}
    assert all(a["status"] == "off" for a in st["agents"].values())
    bus.update("technical", "work", activity="analisa EURUSD", task="EURUSD", progress=0.5)
    bus.log("technical", "mulai analisa")
    bus.pulse("technical", "febrian", "data", "hasil")
    st = bus.state()
    a = st["agents"]["technical"]
    assert a["alive"] and a["status"] == "work" and a["progress"] == 0.5
    assert st["logs"][-1]["text"] == "mulai analisa"
    assert st["pulses"][-1]["dst"] == "febrian"
    assert "technical" in st["active"]
    bus.reset()


def test_thinking_is_open(client):
    d = client.get("/api/thinking/state").json()
    assert set(d["agents"]) and "logs" in d and "pulses" in d and "signal" in d
    assert "backtest" not in d


# ------------------------------------------------------------------ log belajar: hanya dari jurnal sinyal live
def _journal(rows):
    return lambda limit=2000, sym=None, mode=None, only_closed=True: rows


def test_lessons_from_live_journal_block_losing_context(monkeypatch):
    losing = [dict(side="BUY", r=-0.6, plan=dict(families=["TREND"], regime="TRENDING")) for _ in range(40)]
    monkeypatch.setattr(learn.journal, "recent", _journal(losing))
    ls = learn.all_lessons("EURUSD", "swing")
    assert ls and ls[0]["verdict"] == "AVOID" and ls[0]["n"] == 40 and ls[0]["source"] == "live"
    res = dict(signal="BUY", mode="swing", families=[dict(family="TREND", vote=1)], regime=dict(label="TRENDING"))
    v = learn.verdict(res, "EURUSD")
    assert v["block"] and "menolak" in v["note"]
    assert not learn.verdict(dict(res, families=[dict(family="REVERSION", vote=1)]), "EURUSD")["block"]
    assert "live" in learn.summary_text()


def test_lessons_ignore_old_backtest_results(monkeypatch):
    monkeypatch.setattr(learn.journal, "recent", _journal([]))
    store.kv_set("bt_lessons", [dict(side="BUY", families="TREND", regime="TRENDING", n=99, avg_r=-1.0, lcb=-1.0, verdict="AVOID")])
    res = dict(signal="BUY", mode="swing", families=[dict(family="TREND", vote=1)], regime=dict(label="TRENDING"))
    assert learn.all_lessons() == [] and not learn.verdict(res, "EURUSD")["block"]
    assert "BACKTEST" not in learn.summary_text()
    assert not hasattr(learn, "prior")
    store.kv_set("bt_lessons", None)


# ------------------------------------------------------------------ menu BACKTEST sudah dihapus sepenuhnya
def test_backtest_removed_everywhere(client):
    assert client.get("/api/signal/backtest").status_code == 404
    assert client.get("/api/signal/backtest/lessons").status_code == 404
    assert client.post("/api/signal/backtest", json={"action": "start"}).status_code in (404, 405)
    from terminal import api
    assert not any("backtest" in k for k in api.ADMIN_ONLY)
    for p in ("terminal/signals/backtest.py", "terminal/web/v_backtest.js", "tools/signal_backtest.py"):
        assert not (ROOT / p).exists(), p
    web = ROOT / "terminal" / "web"
    assert "v_backtest.js" not in (web / "index.html").read_text(encoding="utf-8")
    for f in list(web.glob("*.js")) + [web / "style.css"]:
        t = f.read_text(encoding="utf-8")
        assert "T.Backtest" not in t and ".bt-" not in t and "BACKTEST" not in t, f.name
    from terminal.signals import runner
    assert not hasattr(runner, "paused") and not hasattr(runner, "set_paused")


def test_old_backtest_data_is_dropped_on_start():
    store.execute("CREATE TABLE IF NOT EXISTS bt_runs(id INTEGER PRIMARY KEY, x TEXT)")
    store.execute("CREATE TABLE IF NOT EXISTS bt_trades(id INTEGER PRIMARY KEY, x TEXT)")
    store.kv_set("bt_last", dict(run_id=1))
    store.kv_set("bt_lessons", [1])
    store.drop_backtest_leftovers()
    names = {r["name"] for r in store.query("SELECT name FROM sqlite_master WHERE type='table'")}
    assert "bt_runs" not in names and "bt_trades" not in names
    assert store.kv_get("bt_last") is None and store.kv_get("bt_lessons") is None
    store.drop_backtest_leftovers()                     # aman diulang
