"""Menu BACKTEST + log belajar + menu THINKING/agent: metrik per sinyal, biaya per leg, pelajaran, bus agent, API."""
import numpy as np
import pandas as pd
import pytest

from terminal import store
from terminal.signals import backtest as bt, learn, tracker
from terminal.signals.config import TP_WEIGHTS
from terminal.agents import bus


def _rows(n=6, seed=1, up=0.6):
    """Daftar trade sintetis untuk _metrics/build_lessons."""
    r = np.random.default_rng(seed)
    out = []
    for i in range(n):
        win = i % 2 == 0
        rr = float(abs(r.normal(up, 0.5))) * (1 if win else -1)
        out.append(dict(t=str(pd.Timestamp("2024-01-01") + pd.Timedelta(days=i)), t_epoch=i, sym="EURUSD", side="BUY",
                        status="TP1" if win else "SL", r=rr, tp_hits=1 if win else 0, filled=True, entry=1.0, sl=0.99, tp=[1.01, 1.02, 1.03],
                        context=dict(regime="TRENDING", families=["TREND"]), lesson="x"))
    return out


def test_metrics_are_signal_level_and_include_unfilled():
    rows = _rows(6) + [dict(r=0.0, filled=False, t="2024-01-09", tp_hits=0, status="EXPIRED")]
    m = bt._metrics(rows)
    assert m["signals"] == 7 and m["filled"] == 6
    assert m["fill_rate"] == pytest.approx(6 / 7)
    assert m["avg_r_signal"] == pytest.approx(m["sum_r"] / 7)
    assert m["pos_rate"] == pytest.approx(3 / 6)
    assert m["max_dd"] <= 0


def test_cost_is_charged_per_leg_and_swap_accrues():
    plan = dict(d=1, entry=100.0, sl=99.0, tp=[101.0, 102.0, 103.0], w=TP_WEIGHTS, expiry=4, max_hold=10, cost=0.3, swap=0.1)
    o, h, l, c = (np.array(x, float) for x in ([100.5, 100.4, 100.2, 100.8, 101.6],
                                              [100.6, 100.5, 100.9, 101.7, 103.2],
                                              [100.4, 99.9, 100.1, 100.7, 101.5],
                                              [100.5, 100.2, 100.8, 101.6, 103.0]))
    r = tracker.simulate(plan, o, h, l, c, 0, True)
    assert r["status"] == "CLOSED" and r["tp_hits"] == 3
    assert r["cost"] == pytest.approx(0.3)            # tiga leg x bobot = total 1.0 posisi x biaya
    assert r["swap"] > 0                              # swap diakrualkan selama posisi hidup
    assert r["r"] < TP_WEIGHTS[0] * 1.0 + TP_WEIGHTS[1] * 2.0 + TP_WEIGHTS[2] * 3.0


def test_lessons_flag_losing_context_and_block_signal():
    rows = []
    for i in range(40):
        rows.append(dict(filled=True, side="BUY", r=-0.6, context=dict(families=["TREND"], regime="TRENDING")))
    ls = bt.build_lessons(rows)
    assert ls and ls[0]["verdict"] == "AVOID" and ls[0]["n"] == 40
    store.kv_set("bt_lessons", ls)
    res = dict(signal="BUY", mode="swing", families=[dict(family="TREND", vote=1)], regime=dict(label="TRENDING"))
    v = learn.verdict(res, "EURUSD")
    assert v["block"] and "menolak" in v["note"]
    ok = learn.verdict(dict(res, families=[dict(family="REVERSION", vote=1)]), "EURUSD")
    assert not ok["block"]
    assert learn.prior()["tsmom"] < 1.0


def test_agent_bus_status_log_and_pulse():
    bus.reset()
    st = bus.state()
    assert set(st["agents"]) == {"news", "technical", "fundamental", "volume", "quant", "febrian"}
    assert all(a["status"] == "off" for a in st["agents"].values())
    bus.update("technical", "work", activity="analisa EURUSD", task="EURUSD", progress=0.5)
    bus.log("technical", "mulai analisa")
    bus.pulse("technical", "febrian", "data", "hasil")
    st = bus.state()
    a = st["agents"]["technical"]
    assert a["alive"] and a["status"] == "work" and a["progress"] == 0.5
    assert st["logs"][-1]["text"] == "mulai analisa"
    assert st["pulses"][-1]["dst"] == "febrian"
    assert "technical" in st["active"]
    bus.reset()


def test_backtest_api_requires_admin_and_thinking_is_open(client):
    d = client.get("/api/thinking/state").json()
    assert set(d["agents"]) and "logs" in d and "pulses" in d
    b = client.get("/api/signal/backtest").json()
    assert "status" in b and "last" in b
    assert client.get("/api/signal/backtest/lessons").json()["lessons"] is not None
    bad = client.post("/api/signal/backtest", json={"action": "nope"}).json()
    assert "error" in bad
    stop = client.post("/api/signal/backtest", json={"action": "stop"}).json()
    assert stop.get("ok") is True