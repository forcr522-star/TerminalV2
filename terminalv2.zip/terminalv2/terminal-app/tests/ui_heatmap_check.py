"""Uji UI menu HEATMAP & FOOTPRINT (admin vs user, indikator per browser, zoom -> footprint, HP).

Jalankan server dengan dua kunci (kolektor Binance aktif bila internet tersedia; tanpa internet chart menampilkan pesan):
    MOCK_KEYS=1 python tests/run_mock_server.py 8765 &
    python tests/ui_heatmap_check.py ./shots [scale]
"""
import os
import sys
from playwright.sync_api import sync_playwright

BASE = os.environ.get("BASE", "http://127.0.0.1:8765")
OUT = sys.argv[1] if len(sys.argv) > 1 else "."
SCALE = float(sys.argv[2]) if len(sys.argv) > 2 else 1
fails = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg, flush=True)
    if not cond:
        fails.append(msg)


def legend(pg):
    return pg.evaluate("()=>[...document.querySelectorAll('#view .hf-ind')].map(e=>[e.dataset.ind,!e.classList.contains('off')])")


def main():
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
        errs = []
        # ------------------------------------------------------------------ USER 1
        u1c = b.new_context(viewport={"width": 1600, "height": 900}, device_scale_factor=SCALE)
        u1 = u1c.new_page()
        u1.on("pageerror", lambda e: errs.append(str(e)))
        u1.goto(BASE + "/?key=user-test#heatmap")
        u1.wait_for_selector("#view .hf-cv", timeout=15000)
        u1.wait_for_timeout(6000)
        check(u1.locator("#rail a[data-id=heatmap]").count() == 1, "menu HEATMAP & FOOTPRINT ada di sidebar")
        check(u1.locator("#title").inner_text() == "HEATMAP & FOOTPRINT", "judul menu")
        names = [x[0] for x in legend(u1)]
        check(names == ["heat", "bubbles", "levels", "footprint", "delta", "liqmap"], f"6 indikator dengan ikon mata di kiri atas {names}")
        check(u1.locator("#view .hf-ind .eye svg").count() == 6, "ikon mata tiap indikator")
        check(u1.locator("#view .hf-pick").count() == 0, "user: tombol PILIH PAIR tidak ada")
        check(u1.locator("#view .hf-tfs button").all_inner_texts() == ["M1", "M5", "M15", "M30", "H1", "H4", "D1"], "timeframe M1..D1")
        pairs = u1.locator("#view .hf-pair").count()
        check(pairs >= 1, f"daftar pair dari admin tampil ({pairs})")
        t = u1.locator("#view").inner_text()
        check(all(x.lower() in t.lower() for x in ("Liquidity map", "Key liquidity levels", "Market overview")), "panel kanan: Liquidity map, Key liquidity levels, Market overview")
        st = lambda pg, path, method="GET", body=None: pg.evaluate("async([p,m,b])=>{const r=await fetch(p,{method:m,headers:{'content-type':'application/json'},body:b?JSON.stringify(b):undefined});return r.status}", [path, method, body])
        check(st(u1, "/api/heatmap/control") == 403, "user: GET /api/heatmap/control -> 403")
        check(st(u1, "/api/heatmap/control", "POST", {"pairs": ["BTCUSDT"]}) == 403, "user: POST pilih pair -> 403")
        live = "LIVE" in u1.locator("#view .hf-st").inner_text()
        print("collector live:", live)
        u1.screenshot(path=f"{OUT}/heatmap_user.png")
        # sembunyikan Big Orders di USER 1
        u1.locator("#view .hf-ind[data-ind=bubbles] .eye").click()
        u1.wait_for_timeout(300)
        check(dict(legend(u1))["bubbles"] is False, "user 1: Big Orders disembunyikan")
        # ------------------------------------------------------------------ USER 2 (browser lain): tetap tampil
        u2c = b.new_context(viewport={"width": 1440, "height": 860})
        u2 = u2c.new_page()
        u2.on("pageerror", lambda e: errs.append(str(e)))
        u2.goto(BASE + "/?key=user-test#heatmap")
        u2.wait_for_selector("#view .hf-ind", timeout=15000)
        check(dict(legend(u2))["bubbles"] is True, "user 2: Big Orders tetap tampil (pilihan indikator per user)")
        u1.reload()
        u1.wait_for_selector("#view .hf-ind", timeout=15000)
        check(dict(legend(u1))["bubbles"] is False, "user 1: pilihan tersimpan setelah muat ulang")
        u1.locator("#view .hf-ind[data-ind=bubbles] .eye").click()
        # ------------------------------------------------------------------ timeframe & zoom footprint
        u1.locator("#view .hf-tfs button[data-tf=H4]").click()
        u1.wait_for_timeout(4000)
        check("· H4" in u1.locator("#view .hf-title").inner_text(), "ganti timeframe ke H4")
        rows = u1.evaluate("async()=>{const s=document.querySelector('#view .hf-pair.on').dataset.sym;const a=await (await fetch('/api/heatmap/view?symbol='+s+'&tf=M1&bars=120')).json();const b=await (await fetch('/api/heatmap/view?symbol='+s+'&tf=H4&bars=120')).json();return [a.row,b.row,a.overview&&a.overview.total,b.overview&&b.overview.total]}")
        print("row M1/H4, liquidity M1/H4:", rows)
        check(rows[1] > rows[0], "price step H4 lebih besar dari M1 (volume per baris disesuaikan TF)")
        if rows[2] is not None and rows[3] is not None:
            check(rows[3] >= rows[2], "likuiditas pita orderbook H4 >= M1")
        u1.screenshot(path=f"{OUT}/heatmap_h4.png")
        u1.locator("#view .hf-tfs button[data-tf=M1]").click()
        u1.wait_for_timeout(4000)
        fpreq = []
        u1.on("request", lambda r: fpreq.append(r.url) if "heatmap/footprint" in r.url else None)
        for _ in range(9):                       # tombol + : zoom di sekitar candle terbaru
            u1.locator("#view .hf-tools button[title='Zoom in']").click()
            u1.wait_for_timeout(60)
        u1.wait_for_timeout(2500)
        box = u1.locator("#view .hf-cv").bounding_box()
        x, y = box["x"] + box["width"] - 200, box["y"] + box["height"] * 0.45
        check(bool(fpreq), "zoom ke candle -> footprint dimuat")
        u1.mouse.move(x - 30, y + 10)
        u1.wait_for_timeout(500)
        check(u1.locator("#view .hf-tip").is_visible(), "tooltip crosshair tampil")
        u1.screenshot(path=f"{OUT}/heatmap_footprint.png")
        # ------------------------------------------------------------------ ADMIN
        ac = b.new_context(viewport={"width": 1600, "height": 900}, device_scale_factor=SCALE)
        a = ac.new_page()
        a.on("pageerror", lambda e: errs.append(str(e)))
        a.goto(BASE + "/?key=admin-test#heatmap")
        a.wait_for_selector("#view .hf-pick", timeout=15000)
        a.wait_for_timeout(5000)
        check(a.locator("#view .hf-pick").inner_text() == "PILIH PAIR", "admin: tombol PILIH PAIR di bawah judul chart")
        a.screenshot(path=f"{OUT}/heatmap_admin.png")
        a.locator("#view .hf-pick").click()
        a.wait_for_selector(".hf-modal .hf-chip")
        check(a.locator(".hf-modal .hf-chip").count() == 6, "admin: 6 pair katalog (BTC, ETH, SOL, XRP, TRX, XAUT)")
        a.screenshot(path=f"{OUT}/heatmap_admin_picker.png")
        for sym in ("ETHUSDT", "SOLUSDT", "XRPUSDT", "TRXUSDT"):
            if "on" in (a.locator(f".hf-modal .hf-chip[data-sym={sym}]").get_attribute("class") or ""):
                a.locator(f".hf-modal .hf-chip[data-sym={sym}]").click()
        a.locator(".hf-modal button:has-text('SIMPAN')").click()
        a.wait_for_timeout(1500)
        got = a.locator("#view .hf-pair").evaluate_all("els=>els.map(e=>e.dataset.sym)")
        check(set(got) <= {"BTCUSDT", "XAUTUSDT"} and len(got) >= 1, f"admin: pair terpilih saja {got}")
        u2.reload()
        u2.wait_for_selector("#view .hf-pair", timeout=15000)
        u2.wait_for_timeout(1500)
        got2 = u2.locator("#view .hf-pair").evaluate_all("els=>els.map(e=>e.dataset.sym)")
        check(set(got2) == set(got), f"user: hanya bisa memilih pair pilihan admin {got2}")
        err = u2.evaluate("async()=>(await (await fetch('/api/heatmap/view?symbol=ETHUSDT&tf=M5')).json()).error||''")
        check("tidak dipantau" in err, "user: pair yang tidak dipilih admin ditolak server")
        ctl = a.evaluate("async()=>(await (await fetch('/api/heatmap/control')).json()).status.pairs")
        check(set(ctl) == set(got), f"server hanya memantau pair terpilih {sorted(ctl)}")
        # kembalikan semua pair
        a.evaluate("async()=>fetch('/api/heatmap/control',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({pairs:['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','TRXUSDT','XAUTUSDT']})})")
        # ------------------------------------------------------------------ HP
        mc = b.new_context(**p.devices["iPhone 13"])
        m = mc.new_page()
        m.on("pageerror", lambda e: errs.append(str(e)))
        m.goto(BASE + "/?key=user-test#heatmap")
        m.wait_for_selector("#view .hf-cv", timeout=15000)
        m.wait_for_timeout(5000)
        ov = m.evaluate("()=>document.documentElement.scrollWidth<=window.innerWidth+1")
        check(ov, "HP: tanpa scroll horizontal")
        m.screenshot(path=f"{OUT}/heatmap_mobile.png", full_page=False)
        m.evaluate("()=>document.getElementById('view').scrollTo(0,99999)")
        m.wait_for_timeout(400)
        m.screenshot(path=f"{OUT}/heatmap_mobile_panels.png")
        check(not errs, f"tidak ada error JS {errs[:3]}")
        b.close()
    print("\n%d FAIL" % len(fails) if fails else "\nSEMUA PASS")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
