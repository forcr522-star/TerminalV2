"""Berita tercepat: Walter Bloomberg (@DeItaone) lewat X API / RSS, FinancialJuice & Bloomberg RSS, endpoint /api/squawk."""
import asyncio
import time

import httpx
import pytest

from terminal import config, store
from terminal.providers import news, xfeed

FJ_RSS = """<?xml version="1.0"?><rss><channel>
<item><title>FinancialJuice: US Initial Jobless Claims Actual 214K (Forecast 220K, Previous 222K)</title><link>https://www.financialjuice.com/News/1</link>
<pubDate>{d}</pubDate></item>
<item><title>FinancialJuice: Fed's Waller: further cuts likely appropriate</title><link>https://www.financialjuice.com/News/2</link><pubDate>{d}</pubDate></item>
</channel></rss>"""
TWEETS = {"data": [
    {"id": "1902", "text": "*POWELL: WILL MOVE CAREFULLY https://t.co/abc", "created_at": "2026-11-25T04:59:08.000Z"},
    {"id": "1901", "text": "https://t.co/onlylink", "created_at": "2026-11-25T04:58:00.000Z"},
    {"id": "1900", "text": "OIL JUMPS 3% AFTER\nTANKER ATTACK &amp; STRAIT CLOSURE", "created_at": "2026-11-25T04:57:00.000Z"}],
    "meta": {"newest_id": "1902", "result_count": 3}}


@pytest.fixture(autouse=True)
def clean(monkeypatch):
    monkeypatch.setattr(news, "_items", {})
    monkeypatch.setattr(news, "_state", dict(last_fetch=0, new_last=0, errors={}, ok={}, pending=[]))
    monkeypatch.setattr(xfeed, "_state", dict(mode="off", ok=None, last_ok=None, last_error=None, wait_until=0.0, polls=0, items=0, accounts={}))
    yield


def _d():
    return time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime())


def test_financialjuice_prefix_removed_and_marked_fast():
    items = news._parse("FinancialJuice", FJ_RSS.format(d=_d()), ["MARKETS"])
    assert [i["title"] for i in items] == ["US Initial Jobless Claims Actual 214K (Forecast 220K, Previous 222K)", "Fed's Waller: further cuts likely appropriate"]
    assert news.ingest(items) == 2 and all(v["fast"] and v["seen"] for v in news._items.values())


def test_fast_feeds_have_short_schedule_and_are_optional_sources():
    from terminal import health
    assert news._every("FinancialJuice") == 60 and news._every("Bloomberg Markets") == 45
    assert news._every("Google: Markets") == 300 and news._every("BBC World") == 90
    assert {"FinancialJuice", "Bloomberg Markets", "Bloomberg Economics"} <= {n for n, _, _ in news.FEEDS}
    assert {"www.financialjuice.com", "feeds.bloomberg.com", "api.x.com"} <= health._optional


def test_429_retry_after_is_respected(monkeypatch):
    req = httpx.Request("GET", "https://www.financialjuice.com/feed.ashx?xy=rss")
    async def fake_fetch(url, **kw):
        assert kw["retries"] == 0                                   # feed cepat: tanpa pengulangan langsung
        raise httpx.HTTPStatusError("429", request=req, response=httpx.Response(429, headers={"retry-after": "42"}, request=req))
    monkeypatch.setattr(news, "fetch", fake_fetch)
    t0 = time.time()
    news._pulled["FinancialJuice"] = t0
    assert asyncio.run(news._pull("FinancialJuice", "u", ["MARKETS"])) == []
    nxt = news._pulled["FinancialJuice"] + news._every("FinancialJuice")
    assert 43 <= nxt - t0 <= 46                                     # dicoba lagi setelah Retry-After (+2 dtk), bukan 60 dtk


def test_x_tweets_become_clean_headlines():
    items = xfeed.parse_tweets(TWEETS, "DeItaone")
    assert [i["title"] for i in items] == ["*POWELL: WILL MOVE CAREFULLY", "OIL JUMPS 3% AFTER TANKER ATTACK & STRAIT CLOSURE"]   # tautan saja -> dibuang
    it = items[0]
    assert it["source"] == "Walter Bloomberg (X)" and it["link"] == "https://x.com/DeItaone/status/1902" and it["fast"] and it["feed"] == "X"
    import calendar as _c
    assert it["ts"] == _c.timegm(time.strptime("2026-11-25 04:59:08", "%Y-%m-%d %H:%M:%S"))
    assert xfeed.label("FirstSquawk") == "@FirstSquawk (X)"


def test_x_api_polls_only_new_posts_and_ingests(monkeypatch):
    monkeypatch.setattr(config, "X_BEARER_TOKEN", "tok")
    monkeypatch.setattr(config, "X_ACCOUNTS", ["DeItaone"])
    for k in ("x_uid_deitaone", "x_since_deitaone"):
        store.execute("DELETE FROM kv WHERE k=?", (k,))
    calls = []

    class R:
        def __init__(self, j): self._j = j
        def json(self): return self._j

    async def fake_fetch(url, params=None, headers=None, **kw):
        calls.append((url, dict(params or {}), headers))
        if "/users/by/username/DeItaone" in url:
            return R({"data": {"id": "42"}})
        return R(TWEETS if len(calls) <= 2 else {"meta": {"result_count": 0}})
    monkeypatch.setattr(xfeed, "fetch", fake_fetch)
    assert xfeed.mode() == "api"
    assert asyncio.run(xfeed.poll_once()) == 2
    assert calls[0][2]["Authorization"] == "Bearer tok" and "since_id" not in calls[1][1]
    assert asyncio.run(xfeed.poll_once()) == 0
    assert calls[-1][1]["since_id"] == "1902" and len([c for c in calls if "by/username" in c[0]]) == 1   # id akun disimpan
    sq = news.squawk()
    assert sq[0]["source"] == "Walter Bloomberg (X)" and sq[0]["fast"] and sq[0]["feed"] == "X"
    assert xfeed.status()["ok"] is True


@pytest.mark.parametrize("code,needle,wait", [(401, "menolak token", 3600), (429, "kuota", 42)])
def test_x_api_errors_pause_with_clear_message(monkeypatch, code, needle, wait):
    monkeypatch.setattr(config, "X_BEARER_TOKEN", "tok")
    store.kv_set("x_uid_deitaone", "42")
    req = httpx.Request("GET", "https://api.x.com/2/users/42/tweets")
    hdr = {"x-rate-limit-reset": str(int(time.time() + 40))} if code == 429 else {}
    async def fake_fetch(url, **kw):
        raise httpx.HTTPStatusError(str(code), request=req, response=httpx.Response(code, headers=hdr, request=req))
    monkeypatch.setattr(xfeed, "fetch", fake_fetch)
    assert asyncio.run(xfeed.poll_once()) == 0
    st = xfeed.status()
    assert st["ok"] is False and needle in st["last_error"] and st["wait_until"] and abs(st["wait_until"] - time.time() - wait) < 6
    assert asyncio.run(xfeed.poll_once()) == 0 and xfeed._state["polls"] == 1          # masa jeda: tidak meminta lagi


def test_x_off_without_config(monkeypatch):
    monkeypatch.setattr(config, "X_BEARER_TOKEN", "")
    monkeypatch.setattr(config, "X_RSS_URLS", [])
    assert xfeed.mode() == "off" and asyncio.run(xfeed.poll_once()) == 0


def test_squawk_since_returns_only_new_items():
    old = news._parse("FinancialJuice", FJ_RSS.format(d=_d()), ["MARKETS"])
    news.ingest(old)
    for v in news._items.values():
        v["seen"] -= 100
    cut = time.time() - 50
    news.ingest(xfeed.parse_tweets(TWEETS, "DeItaone"))
    new = news.squawk(since=cut)
    assert {i["source"] for i in new} == {"Walter Bloomberg (X)"} and len(new) == 2
    assert len(news.squawk()) == 4 and news.squawk()[0]["source"] == "Walter Bloomberg (X)"   # urut waktu pertama terlihat


def test_squawk_endpoint(client):
    news.ingest(news._parse("FinancialJuice", FJ_RSS.format(d=_d()), ["MARKETS"]))
    d = client.get("/api/squawk").json()
    fj = [i for i in d["items"] if i["feed"] == "FinancialJuice"]
    assert len(fj) == 2 and all(i["fast"] for i in fj) and d["x"]["mode"] in ("off", "api", "rss") and "FinancialJuice" in d["sources"]
    d2 = client.get("/api/squawk", params={"since": d["now"] + 1}).json()
    assert d2["items"] == []
