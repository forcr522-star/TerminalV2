"""Akses website tanpa Telegram: kunci akses, cookie sesi, dan penjagaan /api."""
import pathlib
import pytest
from terminal import auth, config


@pytest.fixture()
def guarded(monkeypatch, tmp_path):
    """Server dengan penjagaan menyala dan kunci 'rahasia-123'."""
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ACCESS_KEY", "rahasia-123")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    auth._cache.clear()
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app, follow_redirects=False) as c:
        yield c


def test_key_is_generated_once_and_persisted(monkeypatch, tmp_path):
    monkeypatch.setattr(config, "ACCESS_KEY", "")
    monkeypatch.setattr(config, "DATA_DIR", pathlib.Path(tmp_path))
    auth._cache.clear()
    k1 = auth.access_key()
    assert len(k1) >= 20 and (tmp_path / "access_key.txt").read_text().strip() == k1
    auth._cache.clear()
    assert auth.access_key() == k1                      # sesudah restart: kunci sama
    assert auth.check_key(k1) and not auth.check_key("salah") and not auth.check_key("")


def test_env_key_overrides_file_and_none_disables(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ACCESS_KEY", "abc")
    assert auth.enabled() and auth.access_key() == "abc"
    monkeypatch.setattr(config, "ACCESS_KEY", "none")
    assert not auth.enabled() and auth.authorize({}, {})


def test_cookie_is_not_the_key():
    assert auth.session_token() != auth.access_key()
    assert auth.check_cookie(auth.session_token()) and not auth.check_cookie("x") and not auth.check_cookie(None)


def test_page_and_api_blocked_without_key(guarded):
    r = guarded.get("/")
    assert r.status_code == 401 and "Kunci akses" in r.text
    assert guarded.get("/api/status").status_code == 401
    assert guarded.get("/api/ping").json() == {"error": "unauthorized"}
    assert guarded.get("/core.js").status_code == 401            # aset statis pun tertutup
    assert guarded.get("/healthz").json()["ok"] is True           # hanya healthz terbuka


def test_wrong_key_rejected(guarded):
    r = guarded.get("/?key=salah")
    assert r.status_code == 401 and "Kunci salah" in r.text and "set-cookie" not in r.headers


def test_correct_key_sets_cookie_and_strips_key(guarded):
    r = guarded.get("/?key=rahasia-123&x=1")
    assert r.status_code == 303 and r.headers["location"] == "/?x=1"        # kunci hilang dari alamat, parameter lain tetap
    sc = r.headers["set-cookie"]
    assert "terminal_session=" in sc and "HttpOnly" in sc and "rahasia-123" not in sc
    # cookie tersimpan di klien: kunjungan berikutnya tanpa kunci diterima
    assert guarded.get("/").status_code == 200
    assert guarded.get("/api/ping").status_code == 200
    assert guarded.get("/core.js").status_code == 200


def test_cookie_secure_flag_behind_https_tunnel(guarded):
    r = guarded.get("/?key=rahasia-123", headers={"x-forwarded-proto": "https"})
    assert "Secure" in r.headers["set-cookie"]


def test_header_key_works_for_scripts(guarded):
    assert guarded.get("/api/ping").status_code == 401
    assert guarded.get("/api/ping", headers={"x-access-key": "rahasia-123"}).status_code == 200
    assert guarded.get("/api/ping", headers={"x-access-key": "salah"}).status_code == 401


def test_key_in_api_query_is_not_accepted(guarded):
    assert guarded.get("/api/ping?key=rahasia-123").status_code == 401


def test_open_when_disabled(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ACCESS_KEY", "none")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app, follow_redirects=False) as c:
        assert c.get("/").status_code == 200 and c.get("/api/ping").status_code == 200
