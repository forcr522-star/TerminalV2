"""STRATEGI ONE (ZONA + STRUKTUR + HARMONIC, dokumen aturan v2.0).

- Bagian 20 (test vector T-1..T-6) harus keluar PERSIS sama.
- Contoh harmonic emas di Bagian 11 (PRZ utama & cadangan).
- BUY dan SELL simetris (mirror harga).
- Siklus order 14.3-14.5: isi E1/E2, TP1 50% + SL ke BE, TP2, SL, C1/C2/C5.
- Tanpa repaint / kebocoran masa depan: memotong data di bar T tidak mengubah setup yang dibuat <= T.
- Integrasi terminal: tombol strategi, board/detail ONE, dispatch runner.
"""
import math
import random

import pytest

from terminal.signals.one import core
from terminal.signals.one.core import HIGH, LOW, Swing
from terminal.signals.one.engine import Engine, lots

ROWS = """100.0 100.6 99.6 100.3
100.3 101.0 100.1 100.8
100.8 101.5 100.6 101.2
101.2 101.4 100.3 100.6
100.7 100.9 100.2 100.4
100.4 100.7 100.1 100.5
100.5 100.8 100.3 100.6
100.6 101.9 100.5 101.8
101.8 103.2 101.7 103.0
103.0 103.6 102.6 102.8
102.8 103.0 102.0 102.2
102.2 102.4 101.6 101.8
101.8 102.5 101.7 102.3
102.3 102.8 102.1 102.6
102.6 102.7 102.0 102.1
102.1 102.3 101.6 101.7
101.7 101.9 101.3 101.5"""
T0 = 1767250800          # 2026-01-01 07:00 UTC = 14:00 UTC+7 (di dalam sesi)
TV = dict(Fractal_Left=2, Fractal_Right=2)


def vector(extra=()):
    rows = [[float(x) for x in r.split()] for r in ROWS.splitlines()] + [list(map(float, r)) for r in extra]
    o, h, l, c = map(list, zip(*rows))
    return o, h, l, c


def engine(o, h, l, c, **kw):
    n = len(c)
    return Engine(o, h, l, c, [T0 + 300 * i for i in range(n)], params=dict(TV, **kw.pop("params", {})), atr=[1.0] * n, apply_terminal=False, **kw)


def mirror(o, h, l, c, k=200.0):
    return [k - x for x in o], [k - x for x in l], [k - x for x in h], [k - x for x in c]


# ------------------------------------------------------------------------------------------- Bagian 20
def test_vector_T1_swings_T2_bos_T3_T4_zone():
    E = engine(*vector()).run()
    S = E.S
    assert [(("HIGH" if s.type == HIGH else "LOW"), s.index, s.price, s.confirmed_at) for s in S.swings] == [
        ("HIGH", 2, 101.5, 4), ("LOW", 5, 100.1, 7), ("HIGH", 9, 103.6, 11), ("LOW", 11, 101.6, 13), ("HIGH", 13, 102.8, 15)]
    bull = [e for e in S.bos if e["dir"] > 0]
    assert bull[0]["bar"] == 7 and bull[0]["swing"].price == 101.5 and bull[0]["swing"].index == 2
    dem = [z for z in S.zones if z.dir > 0]
    assert len(dem) == 1
    z = dem[0]
    assert (z.born, z.impulse_start, z.base_first, z.base_last) == (8, 7, 4, 6)
    assert (z.wick_top, z.wick_bottom, z.body_top, z.body_bottom) == (100.9, 100.1, 100.7, 100.4)
    assert z.validated and z.visits == 0 and z.state == "FRESH"


def test_vector_T5_setup_a_and_T6_lots():
    E = engine(*vector()).run(15)
    assert [p.price for p in E.S.pivots] == [101.5, 100.1, 103.6, 101.6, 102.8]
    assert len(E.setups) == 1
    s = E.setups[0].as_dict()
    assert (s["type"], s["side"], s["created"], s["status"]) == ("A", "BUY", 15, "PENDING")
    for k, v in dict(E1=100.900, E2=100.596, SL=99.950, TP1=102.750, TP2=103.550).items():
        assert s[k] == pytest.approx(v, abs=1e-9), k
    assert s["rr_final"] == pytest.approx(2.789, abs=1e-3)
    L = lots(10000, 0.5, s["E1"], s["E2"], s["SL"], 100.0)
    assert L["eavg"] == pytest.approx(100.748) and L["dist"] == pytest.approx(0.798)
    assert L["total"] == pytest.approx(0.6266, abs=1e-4) and (L["lot1"], L["lot2"]) == (0.31, 0.31)


def test_vector_bar16_opposite_bos_cancels_pending_c5():
    E = engine(*vector()).run()
    s = E.setups[0]
    assert s.status == "CANCEL" and s.closed_bar == 16 and s.reason.startswith("C5")


# ------------------------------------------------------------------------------------------- BUY/SELL simetris
def test_sell_is_exact_mirror_of_buy():
    E = engine(*mirror(*vector())).run(15)
    s = E.setups[0].as_dict()
    assert (s["type"], s["side"]) == ("A", "SELL")
    for k, v in dict(E1=99.100, E2=99.404, SL=100.050, TP1=97.250, TP2=96.450).items():
        assert s[k] == pytest.approx(v, abs=1e-9), k
    assert s["rr_final"] == pytest.approx(2.789, abs=1e-3)
    assert [p.price for p in E.S.pivots] == [98.5, 99.9, 96.4, 98.4, 97.2]


# ------------------------------------------------------------------------------------------- siklus order
def _cont(*rows):
    """Data uji bar 0..15 + bar lanjutan (bar 16 dokumen diganti)."""
    o, h, l, c = vector()
    o, h, l, c = o[:16], h[:16], l[:16], c[:16]
    for r in rows:
        o.append(r[0]); h.append(r[1]); l.append(r[2]); c.append(r[3])
    return o, h, l, c


def test_lifecycle_fill_tp1_partial_breakeven_then_tp2():
    E = engine(*_cont((101.7, 101.8, 100.85, 101.0), (101.0, 102.0, 100.95, 101.9), (101.9, 102.9, 101.8, 102.6),
                      (102.6, 103.0, 102.2, 102.9), (102.9, 103.7, 102.8, 103.6))).run()
    s = E.setups[0]
    assert s.fill_bar == 16 and len(s.legs) == 1                     # hanya E1 (100.9) terisi; E2 100.596 tidak tersentuh
    assert s.legs[0]["entry_n"] == pytest.approx(100.9)
    assert s.tp1_done and s.status == "TP2" and s.closed_bar == 20
    assert s.sl_now_n == pytest.approx(100.95)                       # BE = Eavg + 0.05 ATR, berlaku bar sesudah TP1
    unit = 100.748 - 99.95
    # hanya E1 terisi = 50% volume rencana; TP1 menutup 50% volume TERBUKA (25%), sisanya (25%) di TP2. R diukur dari risiko rencana.
    assert s.pnl == pytest.approx((0.25 * (102.75 - 100.9) + 0.25 * (103.55 - 100.9)) / unit)


def test_lifecycle_both_legs_then_stop_is_minus_one_r():
    E = engine(*_cont((101.7, 101.8, 100.85, 101.0), (101.0, 101.1, 99.9, 100.0))).run()
    s = E.setups[0]
    assert s.status == "SL" and len(s.legs) == 2
    assert s.pnl - s.cost_acc == pytest.approx(-1.0)


def test_lifecycle_tp1_then_breakeven_stop():
    E = engine(*_cont((101.7, 101.8, 100.85, 101.0), (101.0, 102.9, 100.95, 102.6), (102.6, 102.7, 100.9, 101.0))).run()
    s = E.setups[0]
    assert s.status == "TP1" and s.exit_reason == "BE"
    assert s.pnl == pytest.approx((0.25 * (102.75 - 100.9) + 0.25 * (100.95 - 100.9)) / (100.748 - 99.95))


def test_c2_tp1_before_fill_is_missed():
    E = engine(*_cont((101.7, 102.8, 101.65, 102.5))).run()
    s = E.setups[0]
    assert s.status == "MISSED" and s.fill_bar is None and s.reason.startswith("C2")


def test_c1_expires_after_36_bars_without_fill():
    E = engine(*_cont(*[(102.0, 102.2, 101.8, 102.0)] * 40)).run()
    s = E.setups[0]
    assert s.status == "EXPIRED" and s.closed_bar == 15 + 36


# ------------------------------------------------------------------------------------------- harmonic (Bagian 11)
def test_harmonic_gold_example_prz_and_backup():
    n = 30
    o = [4760.0] * n
    h = [4762.0] * n
    l = [4752.0] * n
    c = [4760.0] * n
    E = Engine(o, h, l, c, [T0 + 120 * i for i in range(n)], atr=[1.0] * n, apply_terminal=False)
    E.S.pivots = [Swing(LOW, 2, 4732.0, 4), Swing(HIGH, 6, 4763.0, 8), Swing(LOW, 10, 4745.5, 12), Swing(HIGH, 14, 4765.0, 16)]
    cand = E.setup_c(20, 1)
    assert cand and cand["type"] == "C"
    inf = cand["info"]
    assert inf["prz"]["top"] == pytest.approx(4735.534) and inf["prz"]["bottom"] == pytest.approx(4733.449)
    assert (inf["prz"]["xa"], inf["prz"]["bc"]) == (0.886, 1.618)
    assert cand["E1n"] == pytest.approx(4735.534)
    assert cand["SLn"] == pytest.approx(4733.449 - 3.10)                         # max(0.10*XA, 0.15*ATR) = 3.10
    e2 = cand["E1n"] - 0.32 * (cand["E1n"] - cand["SLn"])
    assert round(e2, 2) == 4733.87
    kind, bk = inf["backup"]
    assert kind == "prz" and round(bk["top"], 2) == 4727.97 and round(bk["bottom"], 2) == 4726.00
    tp1, tp2 = inf["fixed_tp"][0], inf["fixed_tp"][1]
    AD = 4763.0 - cand["E1n"]
    assert tp1 == pytest.approx(cand["E1n"] + 0.382 * AD) and tp2 == pytest.approx(cand["E1n"] + 0.618 * AD)


# ------------------------------------------------------------------------------------------- tanpa repaint
def _walk(n=1600, seed=7):
    rnd = random.Random(seed)
    o, h, l, c = [], [], [], []
    p = 100.0
    for i in range(n):
        drift = 0.04 * math.sin(i / 60.0)
        op = p
        cl = max(1.0, op + rnd.gauss(drift, 0.35))
        hi = max(op, cl) + abs(rnd.gauss(0, 0.18))
        lo = min(op, cl) - abs(rnd.gauss(0, 0.18))
        o.append(op); h.append(hi); l.append(lo); c.append(cl)
        p = cl
    return o, h, l, c


def _snap(E, upto):
    S = E.S
    setups = [(s.key, s.type, s.d, s.created, round(s.E1n, 9), round(s.E2n, 9), round(s.SLn, 9), round(s.TP1n, 9), round(s.TP2n, 9), s.score)
              for s in E.setups if s.created <= upto]
    swings = [(s.type, s.index, s.price) for s in S.swings if s.confirmed_at <= upto]
    bos = [(e["dir"], e["bar"], e["swing"].index) for e in S.bos if e["bar"] <= upto]
    zones = [(z.dir, z.born, z.base_first, z.base_last, z.wick_top, z.wick_bottom) for z in S.zones if z.born <= upto]
    return setups, swings, bos, zones


def test_no_repaint_truncated_history_gives_identical_past():
    o, h, l, c = _walk()
    ts = [T0 + 300 * i for i in range(len(c))]
    full = Engine(o, h, l, c, ts).run()
    assert len(full.setups) >= 3, "data sintetis harus menghasilkan beberapa setup"
    for cut in (500, 900, 1300):
        part = Engine(o[:cut + 1], h[:cut + 1], l[:cut + 1], c[:cut + 1], ts[:cut + 1]).run()
        assert _snap(part, cut) == _snap(full, cut), f"repaint pada potongan {cut}"


def test_atr_is_mt5_sma_of_true_range():
    h, l, c = [2.0, 3.0, 4.0, 3.5], [1.0, 1.5, 2.5, 2.0], [1.5, 2.5, 3.0, 2.2]
    a = core.atr_mt5(h, l, c, 2)
    assert a[0] is None and a[1] is None                    # belum cukup bar
    assert a[2] == pytest.approx((1.5 + 1.5) / 2)          # TR1 = max(1.5, 1.5, 0) ; TR2 = max(1.5, 1.5, 0)
    assert a[3] == pytest.approx((1.5 + 1.5) / 2)          # TR3 = max(1.5, 0.5, 1.0)


# ------------------------------------------------------------------------------------------- integrasi terminal

import mockworld                                                  # noqa: E402
from terminal import auth, config, store                          # noqa: E402
from terminal.signals import control, runner                      # noqa: E402


@pytest.fixture()
def fresh(monkeypatch):
    store.execute("DELETE FROM kv WHERE k LIKE 'sig_%' OR k LIKE 'one_%'")
    store.execute("DELETE FROM one_log")
    control.reload()
    runner.reset()
    yield
    store.execute("DELETE FROM kv WHERE k LIKE 'sig_%' OR k LIKE 'one_%'")
    store.execute("DELETE FROM one_log")
    control.reload()
    runner.reset()


@pytest.fixture()
def keyed(monkeypatch, fresh):
    mockworld.install(monkeypatch)
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ADMIN_KEY", "adm-key")
    monkeypatch.setattr(config, "USER_KEY", "usr-key")
    monkeypatch.setattr(config, "ACCESS_KEY", "")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    auth._cache.clear()
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app, follow_redirects=False) as c:
        yield c


def _login(client, key):
    client.cookies.clear()
    assert client.get(f"/?key={key}").status_code == 303


def _j(r):
    j = r.json()
    return j.get("data", j) if isinstance(j, dict) else j


def test_control_strategy_switch_and_validation(fresh):
    st = control.get()
    assert st["strategy"] == "multi"
    st = control.update(strategy="one")
    assert st["strategy"] == "one"
    control.reload()                                              # tersimpan (restart)
    assert control.get()["strategy"] == "one"
    with pytest.raises(ValueError):
        control.update(strategy="tidak-ada")
    assert control.get()["strategy"] == "one"


def test_switch_via_api_board_and_detail_follow_strategy(keyed):
    _login(keyed, "adm-key")
    c = _j(keyed.get("/api/signal/control"))
    assert c["strategy"] == "multi" and {s["id"] if isinstance(s, dict) else s for s in c["strategies"]} == {"multi", "one"}
    assert keyed.post("/api/signal/control", json={"strategy": "zzz"}).status_code == 422
    r = keyed.post("/api/signal/control", json={"strategy": "one", "pairs": ["EURUSD", "Gold"], "mode": "intraday"})
    assert r.status_code == 200 and r.json()["state"]["strategy"] == "one"
    b = _j(keyed.get("/api/signal/board"))
    assert b["strategy"] == "one" and [p["sym"] for p in b["pairs"]] == ["EURUSD", "Gold"]
    assert set(b["orders"]) == {"open", "limit", "closed", "stats"}
    # dua pair dianalisa (multi-pasar) dengan mesin ONE
    for sym in ("EURUSD", "Gold"):
        assert keyed.portal.call(runner.analyze_one, sym), runner.ERRORS.get(sym)       # di event loop server
    d = _j(keyed.get("/api/signal/detail", params={"symbol": "Gold"}))
    assert d["ready"] and d["result_strategy"] == "one"
    one = d["one"]
    for k in ("structure", "zones", "liquidity", "checklist", "filters", "stats", "candles", "params"):
        assert k in one, k
    assert {"news", "volume", "quant", "risk"} <= set(one["filters"])
    assert len(one["checklist"]) >= 4
    ov = {o["sym"]: o for o in _j(keyed.get("/api/signal/control"))["overview"]}
    assert ov["EURUSD"]["ready"] and ov["Gold"]["ready"]
    # user: board ONE tanpa isi analisa, detail tetap admin saja
    _login(keyed, "usr-key")
    ub = _j(keyed.get("/api/signal/board"))
    assert ub["strategy"] == "one" and "one" not in ub
    assert keyed.get("/api/signal/detail", params={"symbol": "Gold"}).status_code == 403
    # kembali ke 10 metode: tampilan & board ikut
    _login(keyed, "adm-key")
    keyed.post("/api/signal/control", json={"strategy": "multi"})
    assert _j(keyed.get("/api/signal/board")).get("strategy", "multi") == "multi"


# ------------------------------------------------------------------------------------------- mesin inkremental
def _full_state(E):
    S = E.S
    return (
        [(s.key, s.type, s.d, s.created, s.status, s.fill_bar, s.closed_bar, round(s.pnl - s.cost_acc - s.swap_acc, 12), s.reason) for s in E.setups],
        [(s.type, s.index, s.price, s.confirmed_at) for s in S.swings],
        [(e["dir"], e["bar"], e["swing"].index, e["choch"]) for e in S.bos],
        [(z.id, z.dir, z.born, z.state, z.visits, z.validated, z.is_flip, z.ended) for z in S.zones],
        [(lv.id, lv.dir, lv.price, lv.state, lv.ended) for lv in S.levels],
        [(k, round(v["r"], 12), v["n"]) for k, v in sorted(E.daily.items())],
        len(E.shadow_done), E.atr[-5:],
    )


@pytest.mark.parametrize("chunks", [(900, 1), (700, 37), (1200, 400)])
def test_incremental_extend_equals_full_rebuild(chunks):
    first, step = chunks
    o, h, l, c = _walk(1600, seed=11)
    v = [float(100 + (i * 37) % 90) for i in range(len(c))]
    ts = [T0 + 300 * i for i in range(len(c))]
    full = Engine(o, h, l, c, ts, v=v, cost=0.00006, spread_frac=0.00003).run()
    inc = Engine(o[:first], h[:first], l[:first], c[:first], ts[:first], v=v[:first], cost=0.00006, spread_frac=0.00003).run()
    for a in range(first, len(c), step):
        b = min(len(c), a + step)
        inc.extend(o[a:b], h[a:b], l[a:b], c[a:b], ts[a:b], v[a:b]).run()
    assert inc.n == full.n and len(full.setups) >= 3
    assert _full_state(inc) == _full_state(full)


def test_extend_rejects_old_bars():
    o, h, l, c = _walk(400, seed=3)
    ts = [T0 + 300 * i for i in range(400)]
    E = Engine(o, h, l, c, ts).run()
    with pytest.raises(ValueError):
        E.extend(o[-2:], h[-2:], l[-2:], c[-2:], ts[-2:])


def test_service_engine_cache_continues_and_rebuilds_on_revision():
    import pandas as pd
    from terminal.signals.one import service as OS
    from terminal.universe import BY_SYM
    o, h, l, c = _walk(1300, seed=5)
    idx = pd.to_datetime([T0 + 300 * i for i in range(len(c))], unit="s")
    df = pd.DataFrame(dict(o=o, h=h, l=l, c=c, v=0.0), index=idx)
    a = BY_SYM["EURUSD"]
    OS._ENGINES.clear()
    E1 = OS._engine(df.iloc[100:1000], a, "scalp", set())
    E2 = OS._engine(df.iloc[150:1300], a, "scalp", set())            # jendela sumber bergeser + 300 bar baru
    assert E2 is E1 and E2.n == 1200 and OS.bar_str(E2, E2.n - 1) == str(df.index[-1])
    fresh = OS.Engine(df["o"].values[100:1300], df["h"].values[100:1300], df["l"].values[100:1300], df["c"].values[100:1300],
                      [int(t.timestamp()) for t in df.index[100:1300]], v=df["v"].values[100:1300],
                      cost=E1.cost_frac, swap_bar=E1.swap_bar_frac, spread_frac=E1.spread_frac, bar_sec=300).run()
    assert _full_state(E2) == _full_state(fresh)
    rev = df.copy()
    rev.iloc[1299, rev.columns.get_loc("c")] += 0.01                   # sumber merevisi bar terakhir -> bangun ulang
    rev2 = pd.concat([rev, pd.DataFrame(dict(o=[c[-1]], h=[c[-1] + .1], l=[c[-1] - .1], c=[c[-1]], v=[0.0]),
                                         index=[idx[-1] + pd.Timedelta(minutes=5)])])
    E3 = OS._engine(rev2.iloc[150:], a, "scalp", set())
    assert E3 is not E2 and E3.n == len(rev2) - 150
    OS._ENGINES.clear()
