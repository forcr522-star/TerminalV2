"""Feed sinyal untuk EA MT5 (/api/ea/feed): format baris, waktu kedaluwarsa, ETag/304, dan akses kunci."""
import calendar
import json
import time

import pytest

from terminal import auth, config, ea_feed, store
from terminal.signals.one.params import PARAMS

FIELDS = ["S", "uid", "strat", "sym", "side", "status", "created", "expiry", "e1", "f1", "e2", "f2", "sl", "tp1", "tp2", "tp3",
          "c1", "c2", "c3", "be", "beoff", "cut2", "ref", "refts", "r", "hold"]


def _parse(line):
    v = line.split("|")
    assert len(v) == len(FIELDS)
    return dict(zip(FIELDS, v))


def _multi_row(**kw):
    plan = dict(d=1, entry=1.1, sl=1.095, tp=[1.105, 1.11, 1.12], risk=0.005, w=[0.4, 0.3, 0.3], expiry=12, max_hold=48)
    row = dict(id=7, sym="EURUSD", mode="intraday", be=1, side="BUY", created=1_790_000_000.5, bar_ts="2026-09-21 10:00:00",
               plan=json.dumps(plan), status="PENDING", r=0.0, closed=None)
    row.update(kw)
    return row


def _one_row(**kw):
    plan = dict(side="SELL", E1=2650.5, E2=2655.25, SL=2662.0, TP1=2640.0, TP2=2630.0, atr=4.0, created_ts=1_790_000_000,
                tf_minutes=15, expiry_bars=36, lots=dict(only_e1=False))
    row = dict(id=3, key="k3", sym="Gold", mode="intraday", type="A", side="SELL", created=1_790_000_950.0, bar_ts="x",
               plan=json.dumps(plan), status="PENDING", r=0.0, closed=None)
    row.update(kw)
    return row


def test_multi_line_fields_and_expiry():
    from terminal.signals.config import MODES
    mins = MODES["intraday"]["minutes"]
    f = _parse(ea_feed.multi_line(_multi_row(), 1.1002, 1_790_000_100))
    issued = calendar.timegm(time.strptime("2026-09-21 10:00:00", "%Y-%m-%d %H:%M:%S")) + mins * 60
    assert f["uid"] == "M7" and f["strat"] == "MULTI" and f["sym"] == "EURUSD" and f["side"] == "BUY" and f["status"] == "PENDING"
    assert f["created"] == "1790000000"
    assert int(f["expiry"]) == issued + 12 * mins * 60                    # 12 bar sesudah bar keputusan tutup (UTC)
    assert (f["e1"], f["f1"], f["e2"], f["f2"]) == ("1.1", "1", "0", "0")
    assert (f["sl"], f["tp1"], f["tp2"], f["tp3"]) == ("1.095", "1.105", "1.11", "1.12")
    # 40% volume awal di TP1; 30% awal = 0,5 dari sisa 60% di TP2; sisanya di TP3
    assert float(f["c1"]) == 0.4 and float(f["c2"]) == 0.5 and f["c3"] == "1"
    assert (f["be"], f["beoff"], f["cut2"]) == ("1", "0", "0")
    assert (f["ref"], f["refts"], f["r"]) == ("1.1002", "1790000100", "0")
    assert int(f["hold"]) == 48 * mins * 60                                # max_hold bar -> detik (tutup karena waktu)


def test_multi_line_closed_carries_r_and_be_off():
    f = _parse(ea_feed.multi_line(_multi_row(status="TP2", r=1.35, be=0, closed=time.time())))
    assert f["status"] == "TP2" and f["r"] == "1.35" and f["be"] == "0" and f["ref"] == "0"


def test_one_line_ladder_and_rules():
    f = _parse(ea_feed.one_line(_one_row(), 2651.0, 1_790_001_000))
    assert f["uid"] == "O3" and f["strat"] == "ONE" and f["sym"] == "Gold" and f["side"] == "SELL"
    assert int(f["expiry"]) == 1_790_000_000 + 15 * 60 + 36 * 15 * 60      # Pending_Expiry_Bars sesudah bar setup tutup
    s = PARAMS["Ladder_Lot_Split"]
    assert (f["e1"], float(f["f1"]), f["e2"], float(f["f2"])) == ("2650.5", s, "2655.25", 1 - s)
    assert (f["sl"], f["tp1"], f["tp2"], f["tp3"]) == ("2662.0", "2640.0", "2630.0", "0") or \
           (f["sl"], f["tp1"], f["tp2"], f["tp3"]) == ("2662", "2640", "2630", "0")
    assert float(f["c1"]) == PARAMS["TP1_Close_Fraction"] and f["c2"] == "1"
    assert f["be"] == "1" and float(f["beoff"]) == pytest.approx(PARAMS["BE_Offset_ATR"] * 4.0) and f["cut2"] == "1"
    assert f["hold"] == "0"                                               # STRATEGI ONE tanpa batas waktu


def test_one_line_only_e1_when_leg2_below_min_lot():
    pl = json.loads(_one_row()["plan"])
    pl["lots"] = dict(only_e1=True)
    f = _parse(ea_feed.one_line(_one_row(plan=json.dumps(pl))))
    assert (f["f1"], f["e2"], f["f2"]) == ("1", "0", "0")


def test_render_header_and_lines():
    body = ea_feed.render([_multi_row()], [_one_row()], {"EURUSD": (1.1, 5)}, now=1_790_000_500)
    lines = body.decode().strip().split("\n")
    assert lines[0] == "TSIG|1|1790000500|2"
    assert lines[1].startswith("S|M7|MULTI|EURUSD|BUY|PENDING|") and "|1.1|5|" in lines[1]
    assert lines[2].startswith("S|O3|ONE|Gold|SELL|PENDING|")


def _insert(now):
    m = _multi_row()
    store.execute("INSERT INTO signal_log(sym,mode,be,side,created,bar_ts,plan,status,r,tp_hits,closed,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                  (m["sym"], m["mode"], 1, "BUY", now, m["bar_ts"], m["plan"], "PENDING", 0.0, 0, None, ""))
    store.execute("INSERT INTO signal_log(sym,mode,be,side,created,bar_ts,plan,status,r,tp_hits,closed,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                  (m["sym"], m["mode"], 1, "BUY", now, m["bar_ts"], m["plan"], "CANCEL", 0.0, 0, now - 60, ""))      # baru dibatalkan
    store.execute("INSERT INTO signal_log(sym,mode,be,side,created,bar_ts,plan,status,r,tp_hits,closed,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                  (m["sym"], m["mode"], 1, "BUY", now, m["bar_ts"], m["plan"], "SL", -1.0, 0, now - ea_feed.KEEP_CLOSED - 60, ""))
    o = _one_row()
    store.execute("INSERT INTO one_log(key,sym,mode,type,side,created,bar_ts,plan,status,r,closed,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                  ("ea-test", o["sym"], o["mode"], "A", "SELL", now, o["bar_ts"], o["plan"], "PENDING", 0.0, None, ""))


@pytest.fixture()
def journal():
    store.execute("DELETE FROM signal_log")
    store.execute("DELETE FROM one_log")
    _insert(time.time())
    ea_feed._cache.update(at=0.0, body=b"", etag='"0"', n=0)
    yield
    store.execute("DELETE FROM signal_log")
    store.execute("DELETE FROM one_log")
    ea_feed._cache.update(at=0.0, body=b"", etag='"0"', n=0)


def test_rows_include_active_and_recently_closed_only(journal):
    multi, one = ea_feed.rows()
    assert sorted(r["status"] for r in multi) == ["CANCEL", "PENDING"]      # SL lama (> KEEP_CLOSED) tidak ikut
    assert [r["status"] for r in one] == ["PENDING"]


def test_etag_ignores_server_time(journal, monkeypatch):
    import asyncio

    async def no_refs(syms):
        return {}
    monkeypatch.setattr(ea_feed, "_refs", no_refs)
    t0 = time.time()
    b1, e1, n1 = asyncio.run(ea_feed.build(now=t0))
    b2, e2, _ = asyncio.run(ea_feed.build(now=t0 + 7))
    assert n1 == 3 and b1 != b2 and e1 == e2                               # hanya waktu server berbeda -> ETag sama (304)
    store.execute("UPDATE signal_log SET status='OPEN' WHERE status='PENDING'")
    _, e3, _ = asyncio.run(ea_feed.build(now=t0 + 9))
    assert e3 != e1                                                       # status berubah -> ETag baru


@pytest.fixture()
def guarded(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ACCESS_KEY", "adm-key")
    monkeypatch.setattr(config, "USER_KEY", "usr-key")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    auth._cache.clear()

    async def no_refs(syms):
        return {s: (1.2345, 1_790_000_000) for s in syms}
    monkeypatch.setattr(ea_feed, "_refs", no_refs)
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app, follow_redirects=False) as c:
        yield c


def test_feed_route_requires_key_and_supports_304(guarded, journal):
    assert guarded.get("/api/ea/feed").status_code == 401
    assert guarded.get("/api/ea/feed", headers={"X-Access-Key": "salah"}).status_code == 401
    r = guarded.get("/api/ea/feed", headers={"X-Access-Key": "usr-key"})                     # kunci USER cukup
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/plain")
    lines = r.text.strip().split("\n")
    assert lines[0].startswith("TSIG|1|") and lines[0].endswith("|3") and len(lines) == 4
    assert all(len(x.split("|")) == len(FIELDS) for x in lines[1:])
    assert any("|PENDING|" in x and "|1.2345|1790000000|" in x for x in lines[1:])          # harga acuan untuk sinyal aktif
    et = r.headers["etag"]
    r2 = guarded.get("/api/ea/feed", headers={"X-Access-Key": "usr-key", "If-None-Match": et})
    assert r2.status_code == 304 and r2.content == b"" and r2.headers["etag"] == et
    r3 = guarded.get("/api/ea/feed", headers={"X-Access-Key": "adm-key"})
    assert r3.status_code == 200 and "terminal.db" not in r3.text
