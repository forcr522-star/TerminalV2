"""Uji UI PUSAT NOTIFIKASI (Chromium):
  tombol di dashboard -> modal 8 jenis (semua update terminal) -> izin browser -> service worker terdaftar -> status AKTIF;
  tiap notifikasi: kartu berwarna menurut tingkat -> nada -> isi DIBACAKAN (Web Speech, direkam lewat instrumentasi);
  push dikirim langsung ke service worker lewat DevTools (tanpa layanan push internet):
    - website terbuka  -> halaman menampilkan kartu notifikasi (+ bunyi)
    - tab ditutup      -> service worker memunculkan notifikasi Chrome
  pengaturan per browser: konteks browser lain tetap NONAKTIF.

    MOCK_KEYS=1 python tests/run_mock_server.py 8765 &   lalu:   python tests/ui_notify_check.py ./shots
"""
import json
import os
import sys

from playwright.sync_api import sync_playwright

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
BASE = os.environ.get("BASE", "http://127.0.0.1:8765")
KEY = os.environ.get("ADMIN_KEY_TEST", "admin-test")
UKEY = os.environ.get("USER_KEY_TEST", "user-test")
ok = []


def check(name, cond, info=""):
    ok.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name, info)


with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
    ctx = b.new_context(viewport={"width": 1440, "height": 900})
    ctx.grant_permissions(["notifications"], origin=BASE)
    pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(BASE + f"/?key={KEY}#dashboard"); pg.wait_for_timeout(3000)
    check("dashboard: bar notifikasi + tombol", pg.locator(".notify-bar button", has_text="Aktifkan notifikasi").count() == 1)
    pg.click(".notify-bar button"); pg.wait_for_timeout(400)
    check("modal: 8 jenis update (semua aktif)", pg.locator(".nm-card").count() == 8 and pg.locator(".nm-card.on").count() == 8, pg.locator(".nm-card").count())
    check("modal: legenda 4 tingkat warna", pg.locator(".nm-legend .ntf-lv").count() == 4)
    pg.locator(".nm-card[data-kind=news]").click(); pg.wait_for_timeout(200)      # matikan "berita penting" -> tersisa 7
    check("modal: pilihan bisa diubah", pg.locator(".nm-card.on").count() == 7)
    pg.click(".nm-act .btn.on"); pg.wait_for_timeout(4000)
    st = pg.evaluate("JSON.parse(localStorage.getItem('tm.notify.v2.admin'))")
    check("aktif: tersimpan di browser ini", st["on"] is True and "news" not in st["kinds"] and len(st["kinds"]) == 7 and st["speak"] and st["sound"], st)
    msg = pg.locator(".nm-msg").text_content()
    check("aktif: pesan status tampil", bool(msg.strip()), msg)
    sw = pg.evaluate("navigator.serviceWorker.getRegistration('/').then(r=>!!(r&&r.active))")
    check("service worker /sw.js aktif", sw)
    pg.screenshot(path=os.path.join(OUT, "notify_modal.png"))
    pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
    check("bar: status AKTIF + BUNYI + DIBACAKAN", "AKTIF" in (t := pg.locator(".notify-bar .nb-st").text_content()) and "DIBACAKAN" in t, t)
    # rekam ucapan (headless tidak punya suara): speak() dicatat lalu dianggap selesai
    pg.evaluate("""() => { window.__said = []; speechSynthesis.speak = (u) => { if ((u.text || '').trim()) window.__said.push([u.text, u.lang]); setTimeout(() => u.onend && u.onend(), 30); }; }""")
    pg.mouse.click(5, 300)                                                       # interaksi pengguna: suara diizinkan

    # push langsung ke service worker lewat DevTools
    cdp = ctx.new_cdp_session(pg)
    regs = []
    cdp.on("ServiceWorker.workerRegistrationUpdated", lambda e: regs.extend(e["registrations"]))
    cdp.send("ServiceWorker.enable"); pg.wait_for_timeout(800)
    rid = next((r["registrationId"] for r in regs if r["scopeURL"].startswith(BASE)), None)
    check("DevTools: registrasi service worker ditemukan", rid is not None, rid)
    ev = dict(id="push-1", kind="calendar", title="TEST PUSH: United States: CPI YoY 3.3%", body="perkiraan 3.1% · di atas perkiraan", url="/#dashboard",
              level="high", ts=1, say="Rilis CPI YoY, Amerika Serikat: 3,3 persen, di atas perkiraan.", lang="id")
    cdp.send("ServiceWorker.deliverPushMessage", {"origin": BASE + "/", "registrationId": rid, "data": json.dumps(ev)}); pg.wait_for_timeout(2500)
    card = pg.locator(".ntf", has_text="TEST PUSH")
    check("website terbuka: kartu notifikasi tampil", card.count() >= 1)
    check("kartu TINGGI berwarna merah", card.count() >= 1 and "high" in card.first.get_attribute("class") and
          pg.evaluate("getComputedStyle(document.querySelector('.ntf.high')).getPropertyValue('--c').trim()") in ("#ff4d5e", "rgb(255, 77, 94)"))
    said = pg.evaluate("window.__said")
    check("isi notifikasi DIBACAKAN (bahasa Indonesia)", any("3,3 persen" in t and l.lower().startswith("id") for t, l in said), said)
    pg.screenshot(path=os.path.join(OUT, "notify_toast.png"))
    ev2 = dict(ev, id="push-2", kind="news", title="NEWS yang tidak dipilih", level="medium")
    cdp.send("ServiceWorker.deliverPushMessage", {"origin": BASE + "/", "registrationId": rid, "data": json.dumps(ev2)}); pg.wait_for_timeout(1000)
    check("jenis yang tidak dipilih tidak ditampilkan", pg.locator(".ntf", has_text="NEWS yang tidak dipilih").count() == 0)
    ev4 = dict(ev, id="push-4", kind="squawk", title="*FED'S POWELL: NO RUSH TO CUT RATES", body="Walter Bloomberg (TG) · PENTING", level="medium",
               say="FED'S POWELL: NO RUSH TO CUT RATES", lang="en")
    cdp.send("ServiceWorker.deliverPushMessage", {"origin": BASE + "/", "registrationId": rid, "data": json.dumps(ev4)}); pg.wait_for_timeout(2500)
    said = pg.evaluate("window.__said")
    check("headline squawk: kartu SEDANG kuning + dibacakan suara Inggris", pg.locator(".ntf.medium", has_text="POWELL").count() == 1 and
          any("POWELL" in t and l.lower().startswith("en") for t, l in said), said)
    pg.evaluate("T.openNotify()"); pg.wait_for_timeout(300)
    pg.click(".nm-act .btn:has-text('Uji')"); pg.wait_for_timeout(3500)
    check("uji 4 tingkat: merah, kuning, biru, hijau", all(pg.locator(f".ntf.{k}", has_text="Contoh").count() >= 1 for k in ("high", "medium", "low", "good")))
    pg.keyboard.press("Escape")
    pg.screenshot(path=os.path.join(OUT, "notify_levels.png"))

    # tab ditutup -> service worker memunculkan notifikasi Chrome
    holder = ctx.new_page(); holder.goto("about:blank")
    pg.close()
    cdp2 = ctx.new_cdp_session(holder)
    cdp2.send("ServiceWorker.enable")
    ev3 = dict(ev, id="push-3", title="CLOSED TAB PUSH: EURUSD BUY LIMIT 1.08345", kind="signal", url="/#signal")
    cdp2.send("ServiceWorker.deliverPushMessage", {"origin": BASE + "/", "registrationId": rid, "data": json.dumps(ev3)}); holder.wait_for_timeout(1500)
    p2 = ctx.new_page(); p2.goto(BASE + "/#dashboard"); p2.wait_for_timeout(2000)
    shown = p2.evaluate("navigator.serviceWorker.ready.then(r=>r.getNotifications()).then(ns=>ns.map(n=>[n.title,n.body,n.data&&n.data.url]))")
    check("tab ditutup: notifikasi Chrome muncul", any("CLOSED TAB PUSH" in s[0] and s[2] == "/#signal" for s in shown), shown)

    # browser yang SAMA, login sebagai USER: pengaturan admin tidak ikut, notifikasi admin tidak tampil di sesi user
    p3 = ctx.new_page(); e3 = []
    p3.on("pageerror", lambda e: e3.append(str(e)))
    p3.goto(BASE + f"/?key={UKEY}#dashboard"); p3.wait_for_timeout(3000)
    who = p3.locator(".notify-bar .nb-who").text_content()
    check("browser sama, akun USER: notifikasi NONAKTIF (pengaturan sendiri)", "NONAKTIF" in p3.locator(".notify-bar .nb-st").text_content() and "USER" in who, who)
    cdp3 = ctx.new_cdp_session(p3); cdp3.send("ServiceWorker.enable"); p3.wait_for_timeout(500)
    ev5 = dict(ev, id="push-5", title="ADMIN ONLY PUSH", level="high")
    cdp3.send("ServiceWorker.deliverPushMessage", {"origin": BASE + "/", "registrationId": rid, "data": json.dumps(ev5)}); p3.wait_for_timeout(1500)
    check("akun USER yang tidak mengaktifkan: tidak ada kartu / suara", p3.locator(".ntf").count() == 0)
    p3.click(".notify-bar button"); p3.wait_for_timeout(400)
    p3.locator(".nm-card[data-kind=squawk]").click(); p3.wait_for_timeout(150)          # user memilih pengaturannya sendiri
    p3.click(".nm-seg button[data-min=high]"); p3.wait_for_timeout(150)
    p3.click(".nm-act .btn.on"); p3.wait_for_timeout(3000)
    us = p3.evaluate("JSON.parse(localStorage.getItem('tm.notify.v2.user'))")
    ad = p3.evaluate("JSON.parse(localStorage.getItem('tm.notify.v2.admin'))")
    check("pengaturan USER terpisah dari ADMIN", us["on"] and us["min"] == "high" and "squawk" not in us["kinds"] and ad["min"] == "low" and "squawk" in ad["kinds"],
          dict(user=(us["min"], len(us["kinds"])), admin=(ad["min"], len(ad["kinds"]))))
    p3.keyboard.press("Escape")
    p3.goto(BASE + f"/?key={KEY}#dashboard"); p3.wait_for_timeout(2500)
    check("kembali ke ADMIN: pengaturan admin utuh (AKTIF)", "AKTIF" in p3.locator(".notify-bar .nb-st").text_content() and "ADMIN" in p3.locator(".notify-bar .nb-who").text_content())
    errs += e3

    # pengguna/browser lain tidak ikut aktif
    other = b.new_context(viewport={"width": 1280, "height": 800}); op = other.new_page()
    op.goto(BASE + f"/?key={KEY}#dashboard"); op.wait_for_timeout(2500)
    check("browser lain tetap NONAKTIF", "NONAKTIF" in op.locator(".notify-bar .nb-st").text_content())
    # ponsel
    m = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True); mp = m.new_page()
    mp.goto(BASE + f"/?key={KEY}#dashboard"); mp.wait_for_timeout(2500)
    check("ponsel: bar notifikasi tanpa scroll horizontal", mp.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    mp.screenshot(path=os.path.join(OUT, "notify_phone.png"))
    check("tanpa error JS", not errs, errs[:3])
    b.close()
print(f"{sum(ok)}/{len(ok)} lulus")
sys.exit(0 if all(ok) else 1)
