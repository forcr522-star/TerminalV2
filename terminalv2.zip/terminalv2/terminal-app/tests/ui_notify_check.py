"""Uji UI notifikasi (Chromium):
  tombol di dashboard -> modal 3 pilihan -> izin browser -> service worker terdaftar -> status AKTIF;
  push dikirim langsung ke service worker lewat DevTools (tanpa layanan push internet):
    - website terbuka  -> halaman menampilkan kartu notifikasi (+ bunyi)
    - tab ditutup      -> service worker memunculkan notifikasi Chrome
  pengaturan per browser: konteks browser lain tetap NONAKTIF.

    MOCK_KEYS=1 python tests/run_mock_server.py 8765 &   lalu:   python tests/ui_notify_check.py ./shots
"""
import json
import os
import sys

from playwright.sync_api import sync_playwright

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
BASE = os.environ.get("BASE", "http://127.0.0.1:8765")
KEY = os.environ.get("ADMIN_KEY_TEST", "admin-test")
ok = []


def check(name, cond, info=""):
    ok.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name, info)


with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
    ctx = b.new_context(viewport={"width": 1440, "height": 900})
    ctx.grant_permissions(["notifications"], origin=BASE)
    pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(BASE + f"/?key={KEY}#dashboard"); pg.wait_for_timeout(3000)
    check("dashboard: bar notifikasi + tombol", pg.locator(".notify-bar button", has_text="Aktifkan notifikasi").count() == 1)
    pg.click(".notify-bar button"); pg.wait_for_timeout(400)
    check("modal: 3 pilihan (likuiditas, berita, sinyal)", pg.locator(".nm-card").count() == 3 and pg.locator(".nm-card.on").count() == 3)
    pg.locator(".nm-card").nth(0).click(); pg.wait_for_timeout(200)          # matikan "likuiditas" -> tersisa 2
    check("modal: pilihan bisa diubah", pg.locator(".nm-card.on").count() == 2)
    pg.click(".nm-act .btn.on"); pg.wait_for_timeout(4000)
    st = pg.evaluate("JSON.parse(localStorage.getItem('tm.notify.v1'))")
    check("aktif: tersimpan di browser ini", st["on"] is True and st["kinds"] == ["news", "signal"], st)
    msg = pg.locator(".nm-msg").text_content()
    check("aktif: pesan status tampil", bool(msg.strip()), msg)
    sw = pg.evaluate("navigator.serviceWorker.getRegistration('/').then(r=>!!(r&&r.active))")
    check("service worker /sw.js aktif", sw)
    pg.screenshot(path=os.path.join(OUT, "notify_modal.png"))
    pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
    check("bar: status AKTIF", "AKTIF" in pg.locator(".notify-bar .nb-st").text_content())

    # push langsung ke service worker lewat DevTools
    cdp = ctx.new_cdp_session(pg)
    regs = []
    cdp.on("ServiceWorker.workerRegistrationUpdated", lambda e: regs.extend(e["registrations"]))
    cdp.send("ServiceWorker.enable"); pg.wait_for_timeout(800)
    rid = next((r["registrationId"] for r in regs if r["scopeURL"].startswith(BASE)), None)
    check("DevTools: registrasi service worker ditemukan", rid is not None, rid)
    ev = dict(id="push-1", kind="news", title="TEST PUSH: Missile strike hits port", body="Reuters · CRIT", url="/#intel", level="high", ts=1)
    cdp.send("ServiceWorker.deliverPushMessage", {"origin": BASE + "/", "registrationId": rid, "data": json.dumps(ev)}); pg.wait_for_timeout(1500)
    check("website terbuka: kartu notifikasi tampil di halaman", pg.locator(".toast", has_text="TEST PUSH").count() >= 1)
    pg.screenshot(path=os.path.join(OUT, "notify_toast.png"))
    ev2 = dict(ev, id="push-2", kind="liq", title="LIQ yang tidak dipilih")
    cdp.send("ServiceWorker.deliverPushMessage", {"origin": BASE + "/", "registrationId": rid, "data": json.dumps(ev2)}); pg.wait_for_timeout(1000)
    check("jenis yang tidak dipilih tidak ditampilkan", pg.locator(".toast", has_text="LIQ yang tidak dipilih").count() == 0)

    # tab ditutup -> service worker memunculkan notifikasi Chrome
    holder = ctx.new_page(); holder.goto("about:blank")
    pg.close()
    cdp2 = ctx.new_cdp_session(holder)
    cdp2.send("ServiceWorker.enable")
    ev3 = dict(ev, id="push-3", title="CLOSED TAB PUSH: EURUSD BUY LIMIT 1.08345", kind="signal", url="/#signal")
    cdp2.send("ServiceWorker.deliverPushMessage", {"origin": BASE + "/", "registrationId": rid, "data": json.dumps(ev3)}); holder.wait_for_timeout(1500)
    p2 = ctx.new_page(); p2.goto(BASE + "/#dashboard"); p2.wait_for_timeout(2000)
    shown = p2.evaluate("navigator.serviceWorker.ready.then(r=>r.getNotifications()).then(ns=>ns.map(n=>[n.title,n.body,n.data&&n.data.url]))")
    check("tab ditutup: notifikasi Chrome muncul", any("CLOSED TAB PUSH" in s[0] and s[2] == "/#signal" for s in shown), shown)

    # pengguna/browser lain tidak ikut aktif
    other = b.new_context(viewport={"width": 1280, "height": 800}); op = other.new_page()
    op.goto(BASE + f"/?key={KEY}#dashboard"); op.wait_for_timeout(2500)
    check("browser lain tetap NONAKTIF", "NONAKTIF" in op.locator(".notify-bar .nb-st").text_content())
    # ponsel
    m = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True); mp = m.new_page()
    mp.goto(BASE + f"/?key={KEY}#dashboard"); mp.wait_for_timeout(2500)
    check("ponsel: bar notifikasi tanpa scroll horizontal", mp.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    mp.screenshot(path=os.path.join(OUT, "notify_phone.png"))
    check("tanpa error JS", not errs, errs[:3])
    b.close()
print(f"{sum(ok)}/{len(ok)} lulus")
sys.exit(0 if all(ok) else 1)
