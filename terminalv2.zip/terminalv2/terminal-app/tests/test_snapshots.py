"""Mesin snapshot + preload: simpan ke DB, layani instan, perbarui otomatis, tidak menimpa data baik dengan error."""
import asyncio
import time
import pytest
from terminal import config, store, http as H, snapshots as S, preload
from terminal.api import state


class Fake:
    """Endpoint tiruan dengan penghitung panggilan, supaya terlihat kapan data dihitung ulang."""
    def __init__(self):
        self.calls, self.value, self.fail, self.empty, self.delay = 0, 1, False, False, 0

    async def __call__(self, cc: str = "US", n: int = 1):
        self.calls += 1
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.fail:
            raise RuntimeError("sumber mati")
        return dict(cc=cc, n=n, v=self.value, rows=[] if self.empty else [1, 2])


@pytest.fixture()
def fake(monkeypatch):
    monkeypatch.setattr(S, "ENDPOINTS", {})
    f = Fake()
    S.endpoint("t/data", ttl=60, group="TEST", plan=lambda: [dict(cc="US"), dict(cc="JP")], deep=lambda: [dict(cc="ID")], deep_ttl=600, valid=lambda d: bool(d["rows"]))(f)
    S.reset()
    return f


async def get(path="t/data", **p):
    body, how = await S.serve(path, {k: str(v) for k, v in p.items()})
    import json
    return json.loads(body), how


async def test_canonical_key_and_param_errors(fake):
    ep = S.ENDPOINTS["t/data"]
    assert ep.canon({}) == dict(cc="US", n=1)
    assert ep.canon({"n": "5"}) == dict(cc="US", n=5)
    assert S.key_of("t/data", ep.canon({"n": "1", "cc": "US"})) == S.key_of("t/data", ep.canon({}))   # urutan/default tidak memengaruhi kunci
    with pytest.raises(S.ParamError):
        ep.canon({"n": "abc"})


async def test_miss_then_hit_computes_once(fake):
    d, how = await get()
    assert how == "miss" and d["v"] == 1 and fake.calls == 1
    for _ in range(5):
        d, how = await get()
        assert how == "hit"
    assert fake.calls == 1


async def test_concurrent_requests_share_one_computation(fake):
    fake.delay = 0.2
    res = await asyncio.gather(*[get() for _ in range(10)])
    assert fake.calls == 1 and all(r[0]["v"] == 1 for r in res)


async def test_snapshot_survives_restart_via_db(fake):
    await get(cc="JP")
    assert fake.calls == 1
    S.reset()                              # simulasi proses mati: RAM hilang, DB tetap
    assert S.load() == 1
    d, how = await get(cc="JP")
    assert how == "hit" and d["cc"] == "JP" and fake.calls == 1          # tidak ada pemuatan ulang


async def test_stale_served_instantly_and_refreshed_in_background(fake):
    await get()
    S._mem[S.key_of("t/data", dict(cc="US", n=1))].ts -= 3600            # buat kedaluwarsa
    fake.value = 2
    d, how = await get()
    assert d["v"] == 1 and how == "hit"                                  # pengunjung tidak menunggu: data lama langsung
    for _ in range(50):
        await asyncio.sleep(0.02)
        if fake.calls >= 2 and not S._inflight:
            break
    d, _ = await get()
    assert d["v"] == 2                                                   # pembaruan latar belakang masuk


async def test_failure_never_overwrites_good_snapshot(fake):
    await get()
    k = S.key_of("t/data", dict(cc="US", n=1))
    S._mem[k].ts -= 3600
    fake.fail = True
    d, how = await get()
    assert d["v"] == 1                                                   # tetap data lama
    await asyncio.sleep(0.1)
    d, _ = await get()
    assert d["v"] == 1 and "error" not in d
    assert S.JOBS[k].fails >= 1 and "sumber mati" in S.JOBS[k].last_error


async def test_failure_without_snapshot_returns_error_and_is_not_stored(fake):
    fake.fail = True
    d, how = await get()
    assert "error" in d and "sumber mati" in d["error"] and how == "uncached"
    assert S.summary()["stored"] == 0 and store.snap_all() == []
    fake.fail = False                                                    # sumber pulih: berikutnya sukses & tersimpan
    d, how = await get()
    assert d["v"] == 1 and S.summary()["stored"] == 1


async def test_empty_result_rejected_by_validator(fake):
    await get()
    k = S.key_of("t/data", dict(cc="US", n=1))
    S._mem[k].ts -= 3600
    fake.empty = True
    await get()
    await asyncio.sleep(0.1)
    d, _ = await get()
    assert d["rows"] == [1, 2]                                           # data kosong tidak menimpa data baik
    S.reset()
    fake.empty = True
    d, how = await get(cc="JP")
    assert how == "uncached" and S.summary()["stored"] == 0


async def test_rev_bumps_only_when_content_changes(fake):
    await get()
    r0 = H.rev()
    k = S.key_of("t/data", dict(cc="US", n=1))
    await S.refresh("t/data", dict(cc="US", n=1), force=True)
    assert H.rev() == r0                                                 # isi sama -> klien tidak perlu menggambar ulang
    fake.value = 9
    await S.refresh("t/data", dict(cc="US", n=1), force=True)
    assert H.rev() == r0 + 1
    assert store.snap_all()[0]["hash"] == S._mem[k].hash


async def test_params_are_separate_snapshots(fake):
    a, _ = await get(cc="US")
    b, _ = await get(cc="JP")
    assert a["cc"] == "US" and b["cc"] == "JP" and S.summary()["stored"] == 2


async def test_bad_param_raises(fake):
    with pytest.raises(S.ParamError):
        await S.serve("t/data", {"n": "x"})


async def test_unplanned_snapshots_are_capped(fake, monkeypatch):
    monkeypatch.setattr(S, "MAX_UNPLANNED_PER_ENDPOINT", 5)
    for i in range(9):
        await get(n=i)
        await asyncio.sleep(0.002)
    assert len([j for j in S.JOBS.values() if not j.planned]) == 5
    assert len(store.snap_all()) == 5


async def test_preload_phase1_loads_all_planned_and_saves(fake, capsys):
    await preload.phase1()
    assert fake.calls == 2 and S.summary()["ready"] == 2
    assert {r["params"] for r in store.snap_all()} == {'{"cc": "US", "n": 1}', '{"cc": "JP", "n": 1}'}
    assert state["preload"]["phase"] == "ready" and S.auto_refresh
    out = capsys.readouterr().out
    assert "memuat 2 menu/fitur" in out and "tersimpan di" in out
    # menu yang dibuka sesudah preload langsung dari snapshot
    before = fake.calls
    d, how = await get(cc="JP")
    assert how == "hit" and fake.calls == before


async def test_preload_skips_what_is_already_stored(fake, capsys):
    await preload.phase1()
    n = fake.calls
    S.reset()
    S.load()                                                             # restart
    capsys.readouterr()
    await preload.phase1()
    assert "sudah tersimpan dari sesi sebelumnya" in capsys.readouterr().out
    assert fake.calls == n                                               # tidak memuat ulang apa pun yang masih segar


async def test_preload_stale_after_restart_refreshes_in_background_not_blocking(fake, monkeypatch):
    await preload.phase1()
    S.reset(); S.load()
    for k in list(S._mem):
        S._mem[k].ts -= 3600
    fake.value, fake.delay = 7, 0.3
    t0 = time.time()
    await preload.phase1()
    assert time.time() - t0 < 0.25                                       # tidak menunggu: data lama langsung dipakai
    d, _ = await get()
    assert d["v"] == 1
    await asyncio.sleep(0.8)
    d, _ = await get()
    assert d["v"] == 7                                                   # lalu diperbarui diam-diam


async def test_preload_force_waits_for_full_reload(fake, monkeypatch):
    await preload.phase1()
    monkeypatch.setattr(config, "PRELOAD_FORCE", True)
    fake.value = 5
    await preload.phase1()
    d, _ = await get()
    assert d["v"] == 5


async def test_preload_timeout_does_not_hold_url_forever(fake, monkeypatch, capsys):
    monkeypatch.setattr(config, "PRELOAD_TIMEOUT", 0.3)
    fake.delay = 1.0
    t0 = time.time()
    await preload.phase1()
    assert time.time() - t0 < 0.8
    assert "batas" in capsys.readouterr().out
    await asyncio.sleep(1.5)                                             # sisanya selesai di latar belakang
    assert S.summary()["ready"] == 2


async def test_preload_reports_failures_and_keeps_going(fake, capsys):
    fake.fail = True
    run = await preload.phase1()
    out = capsys.readouterr().out
    assert run.bad == 2 and "GAGAL" in out and "sumber mati" in out
    assert S.summary()["ready"] == 0


async def test_phase2_loads_deep_items(fake, capsys):
    await preload.phase1()
    run = await preload.phase2()
    assert run.ok == 1 and S.age(S.key_of("t/data", dict(cc="ID", n=1))) is not None
    assert S.JOBS[S.key_of("t/data", dict(cc="ID", n=1))].ttl == 600     # ekor panjang diperbarui lebih jarang


async def test_phase2_can_be_disabled(fake, monkeypatch):
    monkeypatch.setattr(config, "PRELOAD_DEEP", False)
    assert await preload.phase2() is None and fake.calls == 0


async def test_refresher_updates_only_due_items(fake, monkeypatch):
    await preload.phase1()
    n = fake.calls
    fake.value = 3
    S._mem[S.key_of("t/data", dict(cc="JP", n=1))].ts -= 3600            # hanya JP yang kedaluwarsa
    task = asyncio.ensure_future(S.refresher(interval=0.05))
    await asyncio.sleep(0.4)
    task.cancel()
    assert fake.calls == n + 1
    assert (await get(cc="JP"))[0]["v"] == 3 and (await get(cc="US"))[0]["v"] == 1


async def test_refresher_waits_until_preload_done(fake):
    S.register(S.ENDPOINTS["t/data"], dict(cc="US", n=1), 1)
    task = asyncio.ensure_future(S.refresher(interval=0.05))
    await asyncio.sleep(0.3)
    assert fake.calls == 0                                               # belum diaktifkan oleh preload
    S.enable()
    await asyncio.sleep(0.3)
    task.cancel()
    assert fake.calls == 1


async def test_failing_job_backs_off(fake):
    await preload.phase1()
    fake.fail = True
    k = S.key_of("t/data", dict(cc="US", n=1))
    S._mem[k].ts -= 3600
    await S.refresh("t/data", dict(cc="US", n=1), force=True)
    j = S.JOBS[k]
    assert j.fails == 1 and j.next_try > time.time() + 20
    assert k not in [x.key for x in S._due(time.time())]                 # tidak dihujani percobaan ulang
    assert k in [x.key for x in S._due(time.time() + 120)]               # tapi dicoba lagi nanti


async def test_summary_groups(fake):
    await preload.phase1()
    s = S.summary(detail=True)
    assert s["planned"] == 2 and s["ready"] == 2 and s["groups"]["TEST"] == dict(total=2, ready=2, stale=0, failing=0)
    assert len(s["items"]) == 2 and s["bytes"] > 0


async def test_force_refresh_bypasses_ttl_but_dedupes_burst():
    H.clear_cache()
    calls = []

    @H.cached(1000)
    async def src(x):
        calls.append(x)
        return len(calls)

    assert await src(1) == 1
    assert await src(1) == 1 and len(calls) == 1
    with H.force_refresh():
        assert await src(1) == 1                       # baru diambil (<30 dtk): tidak diambil ulang beruntun
    k = next(iter(H._cache))
    H._cache[k] = (time.time() - 100, H._cache[k][1])
    with H.force_refresh():
        assert await src(1) == 2                       # sudah >30 dtk: dipaksa ambil dari sumber walau TTL belum habis
    assert await src(1) == 2 and len(calls) == 2


async def test_force_refresh_falls_back_to_stale_on_error():
    H.clear_cache()
    state_ = dict(fail=False)

    @H.cached(1000)
    async def src():
        if state_["fail"]:
            raise RuntimeError("mati")
        return "baik"

    assert await src() == "baik"
    k = next(iter(H._cache))
    H._cache[k] = (time.time() - 100, "baik")
    state_["fail"] = True
    with H.force_refresh():
        assert await src() == "baik"
