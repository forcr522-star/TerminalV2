import os
import sys
import tempfile

# DB sementara: pengujian tidak menyentuh data/terminal.db dan tidak terpengaruh cache permanen lama.
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ.setdefault("LLM_ENABLED", "1")
os.environ["SIGNAL_RUNNER"] = "0"   # bot latar belakang dimatikan di tes (tes menjalankan runner secara langsung)
os.environ["HEATMAP_COLLECTOR"] = "0"   # tanpa WebSocket Binance di tes (tes mengisi kolektor secara langsung)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


import pytest  # noqa: E402


@pytest.fixture()
def client(monkeypatch):
    """Server FastAPI dengan dunia tiruan (tanpa jaringan), dipakai bersama oleh test_world dan test_fixes."""
    import mockworld
    from terminal import config, auth
    monkeypatch.setattr(config, "DEV_NO_AUTH", True)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", True)
    monkeypatch.setattr(config, "ACCESS_KEY", "none")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    mockworld.install(monkeypatch)
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app) as c:
        yield c


@pytest.fixture(autouse=True)
def _clean_caches():
    """Cache memori + cache disk dibersihkan per test supaya hasil satu test tidak bocor ke test lain."""
    from terminal import http as H, store, health, snapshots
    H.clear_cache()
    H._bg.clear()          # tulis-cache latar dari event loop tes sebelumnya tidak boleh ditunggu oleh tes berikutnya
    snapshots.reset()
    try:
        store.execute("DELETE FROM cache")
        store.execute("DELETE FROM snapshots")
    except Exception:
        pass
    health.reset()
    try:
        from terminal.providers import annual
        annual.SRC.clear()
        annual.ERR.clear()
    except Exception:
        pass
    yield
