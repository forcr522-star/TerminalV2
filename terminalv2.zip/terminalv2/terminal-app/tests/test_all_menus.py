"""Uji menyeluruh semua menu: preload NYATA (rencana asli semua menu) di atas dunia tiruan, lalu setiap menu dibuka lewat HTTP."""
import json
import re
import time
import pathlib
import httpx
import pytest
import mockworld
from terminal import config, auth, preload, snapshots as S, store, api
from terminal.universe import COUNTRY_ORDER

WEB = pathlib.Path(__file__).resolve().parent.parent / "terminal" / "web"
# Satu-satunya yang SENGAJA gagal di dunia tiruan: IMF tidak punya data Tiongkok (CN) -> macro CN kosong.
EXPECTED_BAD = re.compile(r"^macro/(data|regime)\?cc=CN$|^macro/compare\?(a=CN|.*&b=CN)")


@pytest.fixture()
def world(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", True)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", True)
    monkeypatch.setattr(config, "ACCESS_KEY", "none")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    mockworld.install(monkeypatch)
    mockworld.seed_retail()
    S.reset()
    from terminal import server
    return server.app


def test_every_ui_api_call_has_an_endpoint():
    used = set()
    for f in WEB.glob("*.js"):
        used |= set(re.findall(r"(?:api|cachedThen|rawFetch|cached[A-Za-z]*)\(\s*['`\"]([a-z/]+)", f.read_text(encoding="utf-8")))
    used -= {"me"}      # /api/me = rute khusus di server.py (peran sesi), bukan endpoint snapshot
    assert used and not (used - set(S.ENDPOINTS)), used - set(S.ENDPOINTS)


def test_every_cacheable_endpoint_is_in_the_startup_plan():
    # tiap endpoint yang disimpan harus punya rencana muat-awal (kecuali yang memang bergantung hasil lain: supply/pair)
    S.reset()
    planned = {j.path for j in S.plan_jobs(1)} | {j.path for j in S.plan_jobs(2)}
    missing = [p for p, ep in S.ENDPOINTS.items() if ep.store and p not in planned and p != "supply/pair"]
    assert not missing, missing


def test_plan_covers_every_tab_of_every_menu():
    S.reset()
    keys = {j.key for j in S.plan_jobs(1)}
    for cc in COUNTRY_ORDER:
        for p in ("macro/data", "macro/overview", "macro/regime", "cb/country", "fiscal/country"):
            assert f"{p}?cc={cc}" in keys, (p, cc)
        assert f"supply/overview?cc={cc}&flow=X" in keys and f"supply/sectors?cc={cc}&flow=X" in keys
    for c in ("ALL", "INDEX", "FX", "COMMODITY", "CRYPTO", "BOND"):
        assert f"market/assets?cls={c}" in keys
    for c in ("Currencies", "Indices", "Rates", "Crypto", "Commodities"):
        assert f"cot/class?cls={c}" in keys
    for g in ("COMMODITIES", "INDICES", "CURRENCIES", "RATES"):
        assert f"futures/list?group={g}" in keys


async def test_full_preload_then_every_menu_served_from_snapshots(world):
    t0 = time.time()
    run1 = await preload.phase1()
    run2 = await preload.phase2()
    bad = [j.key for r in (run1, run2) for j, _, _ in r.fail]
    unexpected = [k for k in bad if not EXPECTED_BAD.match(k)]
    assert not unexpected, unexpected
    assert run1.ok >= 100 and run2.ok >= 400, (run1.ok, run2.ok)

    # semua snapshot tersimpan di DB sebagai JSON sah tanpa 'error'
    rows = store.snap_all()
    assert len(rows) == run1.ok + run2.ok
    import zlib
    for r in rows:
        d = json.loads(zlib.decompress(r["body"]))
        assert not (isinstance(d, dict) and d.get("error")), r["k"]

    # buka setiap menu seperti pengunjung: semuanya langsung dari snapshot
    from terminal import server
    t1 = time.time()
    n = 0
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url="http://t") as c:
        for j in [j for j in S.JOBS.values() if j.planned and S.age(j.key) is not None]:
            r = await c.get("/api/" + j.path, params={k: str(v) for k, v in j.params.items()})
            assert r.status_code == 200 and r.headers["x-snapshot"] == "hit", j.key
            d = r.json()
            assert not (isinstance(d, dict) and d.get("error")), j.key
            n += 1
        # endpoint langsung (tidak disnapshot) tetap berfungsi
        for p in ("rev", "status", "health", "snapshots?detail=1", "ping", "search?q=gold", "maritime"):
            r = await c.get("/api/" + p)
            assert r.status_code == 200 and "error" not in r.json(), p
        st = (await c.get("/api/status")).json()
        assert st["snapshots"]["ready"] >= 100 and st["preload"]["phase"] == "ready"
        rv = (await c.get("/api/rev")).json()["snap"]
        assert rv["ready"] == rv["planned"] - rv["failing"] or rv["ready"] >= 100
    assert n >= 500
    assert (time.time() - t1) / n < 0.05                   # rata-rata <50 ms per menu: tidak ada yang memuat ulang


async def test_restart_serves_everything_instantly_from_db(world, capsys):
    await preload.phase1()
    ready = S.summary()["ready"]
    S.reset()                                              # proses mati
    from terminal import http as H
    H.clear_cache()                                        # cache memori sumber juga hilang
    assert S.load() >= ready
    capsys.readouterr()
    t0 = time.time()
    await preload.phase1()                                 # start ulang: tidak ada yang ditunggu
    assert time.time() - t0 < 1.0
    assert "sudah tersimpan dari sesi sebelumnya" in capsys.readouterr().out
    from terminal import server
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url="http://t") as c:
        r = await c.get("/api/dashboard")
        assert r.headers["x-snapshot"] == "hit" and r.json()["indices"]


async def test_dashboard_keeps_last_good_sections_when_a_source_dies(world, monkeypatch):
    await S.refresh("dashboard", {})
    good = S.previous("dashboard", {})
    assert good["indices"] and good["bonds"] and not good["errors"]
    from terminal.providers import rates

    async def boom(*a, **k):
        raise RuntimeError("sumber obligasi mati")
    monkeypatch.setattr(rates, "overview", boom)
    from terminal import http as H
    H.clear_cache()
    r = await S.refresh("dashboard", {}, force=True, bg=True)
    assert r.ok
    now = S.previous("dashboard", {})
    assert now["bonds"] == good["bonds"] and "bonds" in now["stale"] and "bonds" not in now["errors"]   # panel tidak kosong


async def test_error_never_cached_for_visitors_when_source_down(world, monkeypatch):
    from terminal.providers import yahoo

    async def down(*a, **k):
        raise RuntimeError("yahoo mati")
    monkeypatch.setattr(yahoo, "quotes", down)
    from terminal import server
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url="http://t") as c:
        r = await c.get("/api/market/assets", params={"cls": "FX"})
        assert r.status_code == 200 and "error" in r.json()
        assert S.summary()["stored"] == 0
