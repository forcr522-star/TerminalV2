"""Menu SIGNAL: indikator, tanpa look-ahead, profil volume, kuantitatif (matematika), simulator trade, fundamental, engine, jurnal, dan API."""
import datetime as dt
import math

import numpy as np
import pandas as pd
import pytest

import mockworld
from terminal.signals import ta, ctx as C, profile, structure, quant as Q, tracker, plan as P, engine, fundamental as F, journal, service
from terminal.signals.methods import NAMES, METHODS
from terminal.signals.config import MODES, TP_R, TP_WEIGHTS, TP_MIN_R


def synth(n=900, seed=3, freq="60min", drift=0.0003, vol=0.002, sawtooth=False):
    r = np.random.default_rng(seed)
    idx = pd.date_range("2024-01-01", periods=n, freq=freq)
    ret = r.normal(drift, vol, n)
    if sawtooth:
        ret = ret + 0.0035 * np.sin(np.arange(n) / 9.0)
    c = 100 * np.exp(np.cumsum(ret))
    o = np.concatenate([[c[0]], c[:-1]])
    h = np.maximum(o, c) * (1 + np.abs(r.normal(0, vol * 0.5, n)))
    l = np.minimum(o, c) * (1 - np.abs(r.normal(0, vol * 0.5, n)))
    return pd.DataFrame({"o": o, "h": h, "l": l, "c": c, "v": r.integers(100, 900, n).astype(float)}, index=idx)


# ------------------------------------------------------------------------------------------------ indikator
def test_indicators_bounded_and_finite():
    d = synth()
    r = ta.rsi(d["c"], 14).dropna()
    assert (r >= 0).all() and (r <= 100).all()
    a, pdi, mdi = ta.adx(d, 14)
    assert (a.dropna() >= 0).all() and (a.dropna() <= 100).all()
    assert (ta.atr(d, 14).dropna() > 0).all()
    mid, up, lo, z, bw = ta.bollinger(d["c"])
    assert (up.dropna() >= lo.dropna()).all()
    er = ta.efficiency_ratio(d["c"], 20).dropna()
    assert (er >= 0).all() and (er <= 1.0000001).all()


def test_hurst_random_walk_near_half_and_trend_above():
    r = np.random.default_rng(1).normal(0, 1, 4000)
    h = ta.hurst_vr(r)
    assert 0.4 < h < 0.6
    trend = r + 0.35 * np.sin(np.arange(4000) / 200)
    assert ta.hurst_vr(np.cumsum(r) * 0 + trend) is not None
    vr, z = ta.variance_ratio(r, 4)
    assert 0.8 < vr < 1.2 and abs(z) < 4


@pytest.mark.parametrize("mode,freq", [("intraday", "60min"), ("swing", "1D"), ("scalp", "5min")])
def test_no_lookahead_in_all_method_outputs(mode, freq):
    """Hasil pada bar k tidak boleh berubah bila data setelah k dibuang."""
    d = synth(n=1100, freq=freq, seed=5, sawtooth=True)
    full = C.build(d, mode)
    k = 800
    part = C.build(d.iloc[: k + 1], mode)
    for name in NAMES:
        for key in ("d", "e", "sl"):
            a = full.out[name][key][400:k + 1]
            b = part.out[name][key][400:k + 1]
            assert np.allclose(a, b, equal_nan=True), (mode, name, key)


# ------------------------------------------------------------------------------------------------ profile & structure
def test_volume_profile_properties():
    r = np.random.default_rng(2)
    c = 100 + np.cumsum(r.normal(0, 1, 300))
    h, l = c + r.random(300), c - r.random(300)
    p = profile.volume_profile(h[-120:], l[-120:], r.integers(10, 99, 120))
    assert p["val"] <= p["poc"] <= p["vah"]
    assert p["lo"] <= p["val"] and p["vah"] <= p["hi"]
    z = profile.volume_profile(h[-120:], l[-120:], np.zeros(120))
    assert z["src"] == "tpo" and z["val"] <= z["poc"] <= z["vah"]
    assert profile.volume_profile(np.array([1.0] * 5), np.array([1.0] * 5)) is None


def test_fvg_and_pools():
    h = np.array([10, 10.5, 11, 12, 12.5, 12.6, 12.4], float)
    l = np.array([9, 9.5, 10, 11.6, 12.0, 12.1, 12.0], float)
    z = structure.fvg_zones(h, l, 6, 10)
    assert any(x["dir"] == 1 and abs(x["lo"] - 10.5) < 1e-9 and abs(x["hi"] - 11.6) < 1e-9 for x in z)


# ------------------------------------------------------------------------------------------------ kuantitatif
def test_barrier_math():
    assert Q.p_up_first(1, 1, 0) == pytest.approx(0.5)
    assert Q.p_up_first(0.8, 1, 0) == pytest.approx(1 / 1.8)
    assert Q.p_up_first(0.8, 1, 0.5) > Q.p_up_first(0.8, 1, 0) > Q.p_up_first(0.8, 1, -0.5)
    for p in (0.4, 0.55, 0.7):
        th = Q.implied_theta(p, 0.8)
        assert Q.p_up_first(0.8, 1, th) == pytest.approx(p, abs=1e-6)


@pytest.mark.parametrize("be", [True, False])
def test_outcomes_are_a_distribution_and_zero_drift_is_a_martingale(be):
    for th in (-0.4, 0.0, 0.6):
        o = Q.outcomes((0.8, 1.7, 3.0), th, be, 0.0)
        assert sum(p for p, _ in o) == pytest.approx(1.0)
        assert all(p >= -1e-12 for p, _ in o)
    ev0, _ = Q.moments(Q.outcomes((0.8, 1.7, 3.0), 0.0, be, 0.0))
    assert ev0 == pytest.approx(0.0, abs=1e-9)          # tanpa drift & tanpa biaya: EV = 0, baik BE on maupun off
    ev_c, _ = Q.moments(Q.outcomes((0.8, 1.7, 3.0), 0.0, be, 0.05))
    assert ev_c == pytest.approx(-0.05, abs=1e-9)       # biaya mengurangi EV tepat sebesar biaya


def test_kelly_zero_for_negative_ev_and_bounded():
    assert Q.kelly_risk(Q.outcomes((0.8, 1.7, 3.0), -0.3, True, 0.0)) == 0.0
    k = Q.kelly_risk(Q.outcomes((0.8, 1.7, 3.0), 0.6, True, 0.0))
    assert 0.0025 <= k <= 0.015


def test_posterior_shrinks_toward_prior():
    p0 = Q.baseline_p(0.8)
    assert Q.posterior(0, 0, 0.8) == pytest.approx(p0)
    assert Q.posterior(8, 10, 0.8) < 0.8                    # 80% dari 10 sampel tidak dipercaya penuh
    assert Q.posterior(80, 100, 0.8) > Q.posterior(8, 10, 0.8)


def test_refine_respects_min_probability():
    b = Q.refine(100.0, 99.0, [100.8, 101.7, 103.0], 1, 0.6, 0.01, True, 0.5, pmin=0.52)
    assert b["p1"] >= 0.52 - 1e-9
    assert b["sl"] < b["entry"] < b["tp"][0] < b["tp"][1] < b["tp"][2]
    s = Q.refine(100.0, 101.0, [99.2, 98.3, 97.0], -1, 0.6, 0.01, False, 0.5, pmin=0.52)
    assert s["tp"][2] < s["tp"][1] < s["tp"][0] < s["entry"] < s["sl"]


# ------------------------------------------------------------------------------------------------ simulator trade
def bars(rows):
    a = np.array(rows, float)
    return a[:, 0], a[:, 1], a[:, 2], a[:, 3]


PLAN = dict(d=1, entry=100.0, sl=99.0, tp=[100.8, 101.6, 102.8], w=TP_WEIGHTS, expiry=4, max_hold=10, cost=0.0)


def test_tracker_all_tp_hit():
    o, h, l, c = bars([(100.5, 100.6, 100.4, 100.5), (100.4, 100.5, 99.9, 100.2), (100.2, 100.9, 100.1, 100.8), (100.8, 101.7, 100.7, 101.6), (101.6, 103, 101.5, 102.9)])
    r = tracker.simulate(PLAN, o, h, l, c, 0, True)
    assert r["status"] == "CLOSED" and r["tp_hits"] == 3 and r["r"] == pytest.approx(TP_WEIGHTS[0] * 0.8 + TP_WEIGHTS[1] * 1.6 + TP_WEIGHTS[2] * 2.8)


def test_tracker_breakeven_on_vs_off():
    seq = [(100.5, 100.6, 100.4, 100.5), (100.4, 100.5, 99.9, 100.2), (100.2, 100.9, 100.1, 100.8), (100.8, 100.9, 99.9, 100.0), (100, 100, 98.5, 98.6)]
    o, h, l, c = bars(seq)
    on = tracker.simulate(PLAN, o, h, l, c, 0, True)
    off = tracker.simulate(PLAN, o, h, l, c, 0, False)
    assert on["status"] == "CLOSED" and on["exit_reason"] == "BE" and on["r"] == pytest.approx(TP_WEIGHTS[0] * 0.8)   # TP1 terbayar, sisa keluar di entry
    assert off["status"] == "CLOSED" and off["exit_reason"] == "SL" and off["r"] == pytest.approx(TP_WEIGHTS[0] * 0.8 - (TP_WEIGHTS[1] + TP_WEIGHTS[2]) * 1.0)   # sisa kena SL asli


def test_tracker_nofill_missed_and_stop_first_when_ambiguous():
    o, h, l, c = bars([(100.7, 100.75, 100.6, 100.7)] * 6)
    assert tracker.simulate(PLAN, o, h, l, c, 0, True)["status"] == "NOFILL"
    o, h, l, c = bars([(100.5, 100.6, 100.4, 100.5), (100.6, 101.0, 100.5, 100.9)])
    assert tracker.simulate(PLAN, o, h, l, c, 0, True)["status"] == "MISSED"
    o, h, l, c = bars([(100.5, 100.6, 100.4, 100.5), (100.4, 101.0, 98.9, 100.0)])      # bar yang menyentuh SL dan TP1: SL lebih dulu
    r = tracker.simulate(PLAN, o, h, l, c, 0, True)
    assert r["r"] == pytest.approx(-1.0) and r["tp_hits"] == 0


def test_tracker_short_mirror_and_cost():
    plan = dict(d=-1, entry=100.0, sl=101.0, tp=[99.2, 98.4, 97.2], w=TP_WEIGHTS, expiry=4, max_hold=10, cost=0.1)
    o, h, l, c = bars([(99.5, 99.6, 99.4, 99.5), (99.6, 100.1, 99.5, 99.8), (99.8, 99.9, 99.1, 99.2), (99.2, 99.3, 98.3, 98.4), (98.4, 98.5, 97.0, 97.1)])
    r = tracker.simulate(plan, o, h, l, c, 0, True)
    assert r["tp_hits"] == 3 and r["r"] == pytest.approx(TP_WEIGHTS[0] * 0.8 + TP_WEIGHTS[1] * 1.6 + TP_WEIGHTS[2] * 2.8 - 0.1)


def test_tracker_pending_and_open_states():
    o, h, l, c = bars([(100.5, 100.6, 100.4, 100.5), (100.6, 100.7, 100.5, 100.6)])
    assert tracker.simulate(PLAN, o, h, l, c, 0, True)["status"] == "PENDING"
    o, h, l, c = bars([(100.5, 100.6, 100.4, 100.5), (100.4, 100.5, 99.9, 100.2), (100.2, 100.4, 100.0, 100.3)])
    r = tracker.simulate(PLAN, o, h, l, c, 0, True)
    assert r["status"] == "OPEN" and r["tp_hits"] == 0


# ------------------------------------------------------------------------------------------------ plan & engine
@pytest.fixture(scope="module")
def trend_ctx():
    return C.build(synth(n=1200, seed=11, sawtooth=True, drift=0.0004), "intraday")


def test_build_plan_geometry(trend_ctx):
    x = trend_ctx
    n_ok = 0
    for name in NAMES:
        o = x.out[name]
        for i in np.where(o["d"] != 0)[0][::25][:30]:
            if i < 300:
                continue
            pl = P.build_plan(x, int(i), int(o["d"][i]), o["e"][i], o["sl"][i], o["q"][i])
            if pl is None:
                continue
            n_ok += 1
            d = pl["d"]
            assert d * (pl["tp"][0] - pl["entry"]) > 0 and d * (pl["entry"] - pl["sl"]) > 0
            assert d * (pl["tp"][1] - pl["tp"][0]) > 0 and d * (pl["tp"][2] - pl["tp"][1]) > 0
            assert d * (x.c[i] - pl["entry"]) >= -1e-9          # limit-beli tidak di atas harga, limit-jual tidak di bawah
            assert 0.4 * x.atr[i] <= abs(pl["entry"] - pl["sl"]) <= 2.6 * x.atr[i] + 1e-9
            assert 0 <= pl["q"] <= 1.0
    assert n_ok > 20


RELAX = dict(gate_ev=-9, min_agree=2, min_margin=1, min_p=0.0, min_ev=-9, refine="none")


def test_engine_produces_valid_buy_or_sell_plans(trend_ctx):
    x = trend_ctx
    book = engine.Book(x, True).build()
    seen = set()
    for i in range(400, x.n - 1, 7):
        r = engine.analyze_at(x, i, book, None, True, RELAX)
        assert len(r["rows"]) == 10 and r["bull"] + r["bear"] <= 10
        if r["signal"] == "WAIT":
            assert r["reason"]
            continue
        pl = r["plan"]
        seen.add(r["signal"])
        if r["signal"] == "BUY":
            assert pl["sl"] < pl["entry"] < pl["tp"][0] < pl["tp"][1] < pl["tp"][2] and r["bull"] > r["bear"]
        else:
            assert pl["sl"] > pl["entry"] > pl["tp"][0] > pl["tp"][1] > pl["tp"][2] and r["bear"] > r["bull"]
        assert abs(sum(p for p, _ in r["outs"]) - 1) < 1e-9 and 0 <= r["p_tp1"] <= 1
    assert seen, "engine tidak pernah menghasilkan sinyal pada data bertren"


def test_fundamental_blocks_events_but_does_not_veto_direction(trend_ctx):
    """Hasil audit: fundamental TIDAK boleh memveto arah (belum tervalidasi OOS); event eksekusi tetap memblokir entry."""
    x = trend_ctx
    book = engine.Book(x, True).build()
    idx = next(i for i in range(400, x.n - 1, 3) if engine.analyze_at(x, i, book, None, True, RELAX)["signal"] != "WAIT")
    base = engine.analyze_at(x, idx, book, None, True, RELAX)
    blocked = engine.analyze_at(x, idx, book, dict(score=0, conf=1, block="Rilis berdampak tinggi: NFP dalam 10 menit"), True, RELAX)
    assert blocked["signal"] == "WAIT" and "NFP" in blocked["reason"]
    side = 1 if base["signal"] == "BUY" else -1
    against = engine.analyze_at(x, idx, book, dict(score=-side, conf=1.0), True, RELAX)
    assert not any(r["status"] == "veto-fund" for r in against["rows"])          # tidak ada veto arah
    assert against["signal"] == base["signal"]                                    # arah tidak berubah
    assert against["plan"] is None or abs(against["plan"]["entry"] - base["plan"]["entry"]) <= abs(base["plan"]["entry"]) * 0.01


def test_thresholds_make_signals_rarer(trend_ctx):
    x = trend_ctx
    book = engine.Book(x, True).build()
    cnt = lambda p: sum(engine.analyze_at(x, i, book, None, True, p)["signal"] != "WAIT" for i in range(400, x.n - 1, 11))
    assert cnt(dict(RELAX, min_agree=6, min_margin=3)) <= cnt(dict(RELAX, min_agree=2, min_margin=1))


def test_tp1_never_below_minimum_and_family_vote(trend_ctx):
    """Hasil audit: TP1 >= TP_MIN_R (tidak ada win rate kosmetik) dan keputusan memakai keluarga faktor."""
    x = trend_ctx
    book = engine.Book(x, True).build()
    seen = 0
    for i in range(400, x.n - 1, 9):
        r = engine.analyze_at(x, i, book, None, True, RELAX)
        assert len(r["families"]) <= 6 and all(f["vote"] in (-1, 0, 1) for f in r["families"])
        if r["signal"] == "WAIT":
            continue
        seen += 1
        pl = r["plan"]
        risk = abs(pl["entry"] - pl["sl"])
        assert abs(pl["tp"][0] - pl["entry"]) >= TP_MIN_R[x.mode][0] * risk - 1e-9
        assert (r["bull"] > r["bear"]) if pl["d"] > 0 else (r["bear"] > r["bull"])
    assert seen, "tidak ada sinyal untuk diuji"


def test_level_side_classification():
    from terminal.signals.plan import _on_side
    assert _on_side(99.0, 100.0, 1, 0.5) and not _on_side(101.0, 100.0, 1, 0.5)
    assert _on_side(101.0, 100.0, -1, 0.5) and not _on_side(99.0, 100.0, -1, 0.5)


def test_tracker_gap_sl_fills_at_open_not_at_sl():
    """Gap menembus SL: keluar di harga open (lebih buruk), bukan tepat di SL."""
    plan = dict(d=1, entry=100.0, sl=99.0, tp=[101.0, 102.0, 103.0], w=TP_WEIGHTS, expiry=4, max_hold=10, cost=0.0)
    o, h, l, c = bars([(100.5, 100.6, 100.4, 100.5), (100.4, 100.5, 99.5, 100.0), (98.0, 98.4, 97.5, 98.0)])
    r = tracker.simulate(plan, o, h, l, c, 0, True)
    assert r["status"] == "CLOSED" and r["exit_reason"] == "GAP-SL" and r["r"] == pytest.approx(-2.0)


# ------------------------------------------------------------------------------------------------ fundamental
def test_entity_mapping():
    assert F.entity("EURUSD")["kind"] == "FX" and F.entity("EURUSD")["ccs"] == ["EU", "US"]
    assert F.entity("Gold")["kind"] == "METAL" and F.entity("US100")["kind"] == "INDEX" and F.entity("Bitcoin")["kind"] == "CRYPTO"
    assert F.entity("DAX30")["cc"] == "EU" and F.entity("USDJPY")["base"] == "USD"
    assert F.entity("NOPE")["kind"] == "OTHER"


def _fx_data(high_base):
    pol = {"EU": [("2025-01-01", 1.0), ("2026-10-01", 4.0 if high_base else 1.0)], "US": [("2025-01-01", 1.0), ("2026-10-01", 1.0 if high_base else 4.0)]}
    return dict(policy=pol, overview=[dict(cc="EU", y10=3.5 if high_base else 1.0), dict(cc="US", y10=1.0 if high_base else 3.5)], regime={}, cot={}, retail=None, gpr=None, news=None)


@pytest.mark.parametrize("mode", ["scalp", "intraday", "swing"])
def test_fundamental_direction_follows_rate_differential(mode):
    up, c1, _ = F.score_drivers(F.entity("EURUSD"), _fx_data(True), mode)
    dn, c2, _ = F.score_drivers(F.entity("EURUSD"), _fx_data(False), mode)
    assert up > 0 > dn and 0 < c1 <= 1 and -1 <= dn and up <= 1
    usdeur, _, _ = F.score_drivers(F.entity("USDJPY"), dict(_fx_data(True), policy={"US": [("2025-01-01", 1.0), ("2026-10-01", 4.0)], "JP": [("2025-01-01", 0.0), ("2026-10-01", 0.0)]}), mode)
    assert usdeur > 0


def test_retail_is_contrarian_and_gold_rate_cut_is_bullish():
    s, _, d = F.score_drivers(F.entity("Gold"), dict(policy={"US": [("2025-01-01", 5.0), ("2026-10-01", 3.0)]}, overview=[], regime={}, cot={}, retail=dict(long_pct=80), gpr=None, news=None), "swing")
    keys = {x["key"]: x["score"] for x in d}
    assert keys["retail"] < 0 and keys["rate"] > 0


def test_event_block_window():
    info = F.entity("EURUSD")
    now = dt.datetime(2026, 11, 6, 12, 0)
    ev = [dict(date="2026-11-06 12:20", cc="US", impact="HIGH", event="Non Farm Payrolls")]
    assert "Non Farm Payrolls" in F.event_block(info, ev, "scalp", now)
    assert F.event_block(info, ev, "scalp", now - dt.timedelta(hours=2)) is None
    assert F.event_block(info, [dict(ev[0], impact="LOW")], "scalp", now) is None
    assert F.event_block(info, [dict(ev[0], cc="JP")], "scalp", now) is None
    assert F.event_block(info, ev, "intraday", now - dt.timedelta(hours=1)) is not None


def test_news_net_sign():
    cats = [dict(title="Gold rally", instruments=[dict(sym="Gold", dir="BULLISH", weight=60)])]
    assert F.news_net(F.entity("Gold"), cats)["net"] > 0
    assert F.news_net(F.entity("EURUSD"), cats) is None


# ------------------------------------------------------------------------------------------------ service & jurnal
def test_completed_drops_running_bar():
    d = synth(n=50)
    now = d.index[-1] + pd.Timedelta(minutes=30)
    assert len(service.completed(d, 60, now)) == 49
    assert len(service.completed(d, 60, d.index[-1] + pd.Timedelta(minutes=61))) == 50


def test_digits():
    assert service.digits(2650.3) == 2 and service.digits(150.25) == 3 and service.digits(12.3) == 4 and service.digits(1.0845) == 5


def test_latch_keeps_signal_until_resolved(monkeypatch):
    """Sinyal yang sudah terbit tidak berubah-ubah; hasilnya dicatat di jurnal saat selesai."""
    from terminal import store
    store.execute("DELETE FROM signal_log")
    sym = "EURUSD"
    d = mockworld._ohlcv_sync(sym, "x", "60m")
    pl = dict(d=1, entry=float(d["c"].iloc[-60]) * 0.999, sl=float(d["c"].iloc[-60]) * 0.99, tp=[float(d["c"].iloc[-60]) * 1.01, float(d["c"].iloc[-60]) * 1.02, float(d["c"].iloc[-60]) * 1.04],
              w=list(TP_WEIGHTS), expiry=500, max_hold=500, cost=0.0)
    bar_ts = str(d.index[-60])
    sid = journal.create(sym, "intraday", True, "BUY", bar_ts, pl)
    assert journal.active(sym, "intraday")["id"] == sid
    st, res = service.evaluate_latched(journal.active(sym, "intraday"), d, True)
    assert st in ("PENDING", "OPEN", "SL", "TP1", "TP2", "TPMAX", "TIME", "EXPIRED", "MISSED")
    out = service.analyze_frame(d, sym, "intraday", True, None, now=d.index[-1] + pd.Timedelta(hours=2))
    if st in ("PENDING", "OPEN"):
        assert out["signal"] == "BUY" and out["plan"]["id"] == sid and out["state"] in ("PENDING", "OPEN")
    else:
        assert journal.active(sym, "intraday") is None or journal.active(sym, "intraday")["id"] != sid
        assert out["last"]["id"] == sid
    assert journal.stats(sym, "intraday")["n"] >= 0


def test_evaluate_latched_missing_bar_expires():
    d = synth(n=200)
    act = dict(plan=dict(d=1, entry=100, sl=99, tp=[101, 102, 103], w=list(TP_WEIGHTS), expiry=5, max_hold=10, cost=0), bar_ts="2000-01-01 00:00:00", be=1)
    assert service.evaluate_latched(act, d, True)[0] == "EXPIRED"


def test_journal_stats(monkeypatch):
    from terminal import store
    store.execute("DELETE FROM signal_log")
    mk = lambda st, r, hits: journal.update(journal.create("X", "swing", True, "BUY", "t", dict(d=1, entry=1, sl=0.9, tp=[1.1, 1.2, 1.3])), st, r, hits)
    mk("TP1", 0.4, 1)
    mk("SL", -1.0, 0)
    mk("TPMAX", 1.4, 3)
    mk("EXPIRED", 0.0, 0)
    s = journal.stats("X", "swing")
    assert s["n"] == 3 and s["win"] == pytest.approx(2 / 3) and s["avg_r"] == pytest.approx(0.8 / 3) and s["pf"] == pytest.approx(1.8)
    assert s["signals"] == 4 and s["fill_rate"] == pytest.approx(0.75) and s["max_dd"] <= 0


# ------------------------------------------------------------------------------------------------ API
def test_signal_api(client):
    u = client.get("/api/signal/universe").json()
    assert set(u["classes"]) == {"FX", "COMMODITY", "INDEX", "CRYPTO"} and [m["id"] for m in u["modes"]] == ["scalp", "intraday", "swing"]
    assert all(s in {a["sym"] for a in u["classes"]["FX"] + u["classes"]["COMMODITY"] + u["classes"]["INDEX"] + u["classes"]["CRYPTO"]} for s in u["default"])
    for mode in ("scalp", "intraday", "swing"):
        for be in (1, 0):
            d = client.get(f"/api/signal/pair?symbol=Gold&mode={mode}&be={be}").json()
            assert "error" not in d, d
            assert d["mode"] == mode and d["be"] == bool(be) and d["signal"] in ("BUY", "SELL", "WAIT")
            assert len(d["votes"]["rows"]) == 10 and d["votes"]["method_total"] == 10 and d["votes"]["total"] == 6
            assert d["votes"]["basis"] == "keluarga"
            assert {"technical", "profile", "fundamental", "quant"} <= set(d["layers"]) and d["candles"]
            if d["plan"]:
                p = d["plan"]
                assert p["management"].startswith("Breakeven ON" if be else "Breakeven OFF")
                assert len(p["rr"]) == 3 and p["tp1"] is not None and p["tp2"] is not None and p["tpmax"] is not None and p["sl"] is not None and p["entry"] is not None
    bad = client.get("/api/signal/pair?symbol=NOPE&mode=intraday&be=1").json()
    assert "error" in bad
    badm = client.get("/api/signal/pair?symbol=EURUSD&mode=weekly&be=1").json()
    assert "error" in badm
    h = client.get("/api/signal/history").json()
    assert set(h) == {"rows", "stats", "by_mode"}


def test_signal_pair_many_symbols_all_classes(client):
    for sym in ("EURUSD", "USDJPY", "Silver", "Crude Oil WTI", "US500", "DAX30", "Bitcoin", "Ethereum"):
        d = client.get(f"/api/signal/pair?symbol={sym}&mode=intraday&be=1").json()
        assert "error" not in d, (sym, d)


def test_breakeven_toggle_applies_to_latched_signal():
    """Mengganti Breakeven ON/OFF saat sinyal sudah terkunci harus langsung mengubah manajemen (level entry/SL/TP tidak berubah)."""
    from terminal import store
    store.execute("DELETE FROM signal_log")
    d = mockworld._ohlcv_sync("EURUSD", "x", "60m")
    c0 = float(d["c"].iloc[-3])
    pl = dict(d=1, entry=c0 * 0.99, sl=c0 * 0.97, tp=[c0 * 1.02, c0 * 1.03, c0 * 1.05], w=list(TP_WEIGHTS), expiry=500, max_hold=500, cost=0.0)   # entry di bawah harga, TP1 di atas -> tetap PENDING
    journal.create("EURUSD", "intraday", True, "BUY", str(d.index[-3]), pl)
    now = d.index[-1] + pd.Timedelta(hours=2)
    on = service.analyze_frame(d, "EURUSD", "intraday", True, None, now=now)
    off = service.analyze_frame(d, "EURUSD", "intraday", False, None, now=now)
    assert on["state"] == off["state"] == "PENDING" and on["signal"] == off["signal"] == "BUY"
    assert on["plan"]["management"].startswith("Breakeven ON") and off["plan"]["management"].startswith("Breakeven OFF")
    assert on["plan"]["entry"] == off["plan"]["entry"] and on["plan"]["sl"] == off["plan"]["sl"] and on["plan"]["tp2"] == off["plan"]["tp2"]
