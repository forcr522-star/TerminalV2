"""Dunia tiruan untuk pengujian: mengganti semua sumber eksternal dengan data deterministik yang BERBEDA per negara.

Dipakai oleh tests/test_world.py (pytest) dan tests/ui_check.py (Playwright). Tidak ada akses jaringan.
Beberapa sumber sengaja dibuat gagal (World Bank, NZ yield, ID 2Y) agar jalur cadangan & pesan 'tidak tersedia' ikut teruji.
"""
import hashlib
import time
import datetime as dt
import numpy as np
import pandas as pd

from terminal.universe import COUNTRIES, COUNTRY_ORDER


def _h(*parts):
    return int(hashlib.sha1("|".join(map(str, parts)).encode()).hexdigest()[:8], 16)


def _rng(*parts):
    return np.random.default_rng(_h(*parts))


def _days(n):
    end = dt.date.today()
    return [(end - dt.timedelta(days=n - i)).isoformat() for i in range(n + 1)]


# ------------------------------------------------------------------ yahoo
def _download(symbols, period, interval):
    idx = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=260)
    cols, data = [], []
    for s in symbols:
        r = _rng("px", s)
        base = 20 + (_h(s) % 4000) / 10
        c = base * np.exp(np.cumsum(r.normal(0.0003, 0.01, len(idx))))
        for name, arr in (("Open", c * 0.998), ("High", c * 1.006), ("Low", c * 0.994), ("Close", c), ("Adj Close", c), ("Volume", np.full(len(idx), 1e6))):
            cols.append((s, name))
            data.append(arr)
    df = pd.DataFrame(np.array(data).T, index=idx, columns=pd.MultiIndex.from_tuples(cols))
    return df


def _history_sync(symbol, period, interval):
    df = _download([symbol], period, interval)[symbol]
    out = []
    for ts, r in df.iterrows():
        out.append(dict(t=int(ts.timestamp() * 1000), d=ts.strftime("%Y-%m-%d"), o=r["Open"], h=r["High"], l=r["Low"], c=r["Close"], v=r["Volume"]))
    return out


def _ohlcv_sync(symbol, period, interval):
    """OHLCV tiruan untuk menu SIGNAL: harga berganti-ganti rezim tren/range supaya setiap metode punya kesempatan memberi sinyal."""
    n, step = {"5m": (1800, "5min"), "60m": (1500, "60min"), "1d": (1000, "1D")}[interval]
    end = pd.Timestamp.utcnow().tz_localize(None).floor(step)
    idx = pd.date_range(end=end, periods=n, freq=step)
    r = _rng("ohlcv", symbol, interval)
    base = 20 + (_h(symbol) % 4000) / 10
    vol = 0.0015 if interval != "1d" else 0.009
    drift = np.zeros(n)
    k = 0
    while k < n:
        seg = int(r.integers(60, 220))
        drift[k:k + seg] = r.choice([-1.0, 0.0, 1.0], p=[0.35, 0.3, 0.35]) * vol * 0.12
        k += seg
    ret = drift + r.normal(0, vol, n)
    c = base * np.exp(np.cumsum(ret))
    o = np.concatenate([[c[0]], c[:-1]])
    wick = np.abs(r.normal(0, vol * 0.6, n)) * c
    h = np.maximum(o, c) + wick
    l = np.minimum(o, c) - np.abs(r.normal(0, vol * 0.6, n)) * c
    v = r.integers(100, 1000, n).astype(float)
    return pd.DataFrame({"o": o, "h": h, "l": l, "c": c, "v": v}, index=idx)


def _financials_sync(ticker):
    cols = ["Q1 2025", "Q2 2025", "Q3 2025", "Q4 2025"]
    row = lambda m, v: dict(metric=m, values=v, change=5.0, basis="qoq")
    st = dict(cols=cols, rows=[row("Total Revenue", [100, 110, 120, 130]), row("Net Income", [10, 11, 12, 13])])
    return dict(ticker=ticker, profile=dict(name=f"{ticker} Corp", summary="Mock", sector="Tech", industry="Soft", currency="USD", country="US"),
                metrics=dict(market_cap=1e12, ev=1e12, pe=25, pb=5, insiders=0.01, institutions=0.7, eps=5, price=150),
                analyst=dict(target=170, low=120, high=200, rec="BUY", count=30), insiders=[], income=st, balance=st, cashflow=st,
                chart=dict(cols=cols, revenue=[100, 110, 120, 130], net=[10, 11, 12, 13]), price=[dict(t=1700000000000 + i * 86400000, c=100 + i) for i in range(200)])


# ------------------------------------------------------------------ yields (adapter sintetis)
TEN = {"1M": 0, "3M": 0, "6M": 0.1, "1Y": 0.2, "2Y": 0.3, "5Y": 0.5, "10Y": 0.7, "30Y": 1.0}


def _yield_rows(cc, tenor, base):
    r = _rng("y", cc, tenor)
    vals = base + TEN[tenor] + np.cumsum(r.normal(0, 0.02, 90))
    return list(zip(_days(89), [round(float(v), 3) for v in vals]))


def make_adapter(cc, drop=(), fail=False):
    async def ad(_cc):
        if fail:
            raise ValueError("sumber tiruan gagal")
        base = 1.0 + (_h("base", cc) % 400) / 100
        return {t: _yield_rows(cc, t, base) for t in TEN if t not in drop}
    return ad


# ------------------------------------------------------------------ makro tahunan
NO_FISCAL_IMF = {"CHN"}  # kode IMF negara yang sengaja tanpa data (dunia tiruan)
def imf_fetch_factory():
    async def _imf(indicator, codes):
        out = {}
        for c in codes:
            if c in NO_FISCAL_IMF:
                continue
            r = _rng("imf", indicator, c)
            base = {"NGDP_RPCH": 2.5, "PCPIPCH": 3.0, "LUR": 5.0, "BCA_NGDPD": 0.0, "GGXWDG_NGDP": 80.0, "GGXCNL_NGDP": -4.0}.get(indicator, 1.0)
            scale = 1 + (_h(c) % 30) / 10
            out[c] = [(y, round(float(base * scale / 2 + r.normal(0, 0.8)), 2)) for y in range(2015, 2031)]
        return out
    return _imf


def policy_all_factory():
    async def policy_all():
        out = {}
        for i, cc in enumerate(COUNTRY_ORDER):
            base = 0.5 + (_h("pol", cc) % 500) / 100
            days = _days(900)
            vals = []
            for k, d in enumerate(days):
                step = 0.25 * (k // 150)
                vals.append((d, round(base + (step if k < 450 else 0.75 - step / 2), 2)))
            out[cc] = vals
        return out
    return policy_all


async def fred_series(sid, start="2020-01-01", **kw):
    r = _rng("fred", sid)
    n = 60
    vals = 100 + np.cumsum(r.normal(0.3, 0.5, n))
    dates = [(dt.date.today().replace(day=1) - dt.timedelta(days=30 * (n - i))).isoformat() for i in range(n)]
    return list(zip(dates, [round(float(v), 3) for v in vals]))


# ------------------------------------------------------------------ CFTC, berita, geo
async def cftc_get_json(url, **kw):
    r = _rng("cftc", str(kw.get("params")))
    rows = []
    for i in range(30):
        d = (dt.date.today() - dt.timedelta(days=7 * i)).isoformat() + "T00:00:00.000"
        rows.append({"report_date_as_yyyy_mm_dd": d, "cftc_contract_market_code": "099741", "market_and_exchange_names": "MOCK - CME",
                     "open_interest_all": "100000", "lev_money_positions_long_all": str(int(30000 + r.integers(0, 9000))), "lev_money_positions_short_all": str(int(20000 + r.integers(0, 9000))),
                     "asset_mgr_positions_long_all": "40000", "asset_mgr_positions_short_all": "10000", "dealer_positions_long_all": "5000", "dealer_positions_short_all": "20000",
                     "other_rept_positions_long_all": "8000", "other_rept_positions_short_all": "7000",
                     "m_money_positions_long_all": "30000", "m_money_positions_short_all": "12000", "prod_merc_positions_long_all": "9000", "prod_merc_positions_short_all": "30000",
                     "swap_positions_long_all": "7000", "swap__positions_short_all": "3000"})
    return rows


HEADLINES = [
    ("Israeli airstrike in Gaza kills 12 civilians", "BBC", ["MIDDLE EAST"]),
    ("Russia launches missile attack on Kyiv overnight", "Reuters", ["GEOPOLITICS"]),
    ("Protesters riot in Paris over pension changes", "Reuters", ["EUROPE"]),
    ("Houthi attack disrupts shipping in Red Sea", "Reuters", ["MIDDLE EAST"]),
    ("Fed signals rate cut as inflation cools", "Bloomberg", ["CENTRAL BANKS"]),
    ("Oil prices tumble as OPEC output rises", "Reuters", ["COMMODITIES"]),
    ("Bitcoin ETF inflow surges to record high", "CoinDesk", ["CRYPTO"]),
    ("China military drills near Taiwan raise tensions", "Reuters", ["ASIA"]),
    ("Gold climbs as dollar weakens", "Reuters", ["COMMODITIES"]),
    ("Tanker seized in Strait of Hormuz", "Reuters", ["MIDDLE EAST"]),
]


async def news_pull(name, url, hints):
    from terminal.providers import news
    now = int(time.time())
    out = []
    for i, (t, src, h) in enumerate(HEADLINES):
        it = dict(title=t, source=src, link="#", ts=now - 60 * (i + 1), summary="", hints=list(h) + list(hints), feed=name)
        out.append(it)
    news._state["ok"][name] = len(out)
    return out


async def fetch_feed_url(url, name="feed", hints=(), n=15):
    now = int(time.time())
    return [dict(title=f"{name}: {t}", source=src, link="#", ts=now - 120 * (i + 1), summary="", hints=list(h), feed=name) for i, (t, src, h) in enumerate(HEADLINES[:n])]


async def gdelt():
    return [dict(lat=31.4, lon=34.4, name="Gaza", count=40), dict(lat=50.4, lon=30.5, name="Kyiv", count=55), dict(lat=15.3, lon=44.2, name="Sanaa", count=20)]


async def gpr_daily():
    return dict(latest=135.0, change=2.0, change_pct=1.5, level="HIGH", asof=dt.date.today().isoformat(), avg30=120.0, avg90=110.0, hi180=160.0, lo180=80.0,
                series=[dict(d=d, v=100 + (i % 40)) for i, d in enumerate(_days(200))])


async def pw_summary():
    from terminal.providers import portwatch as P
    out = []
    for nm, la, lo in (("Strait of Hormuz", 26.5, 56.3), ("Suez Canal", 30.5, 32.3), ("Bab el-Mandeb Strait", 12.6, 43.3), ("Strait of Malacca", 2.5, 101.5)):
        rows = [dict(date=d, total=50 + (_h(nm, d) % 20), tanker=12, cargo=30, name=nm) for d in _days(40)]
        out.append(dict(portid=nm, name=nm, lat=la, lon=lo, **P._stats(rows)))
    return out


# ------------------------------------------------------------------ lelang tiruan
def _auc(cc, name, offset, src, status, rate=None, btc=None, amount=None, time_=None):
    d = (dt.date.today() + dt.timedelta(days=offset)).isoformat()
    return dict(date=d, cc=cc, name=name, status=status, src=src, term=None, type=None, amount=amount, rate=rate, btc=btc, forecast=None, previous=None, unit="%" if rate is not None else None,
                importance=None, **({"time": time_} if time_ else {}))


def auctions_world():
    """US: jadwal + riwayat penuh; JP/GB/AU: kalender TV; EU: hanya mendatang; ID: hanya riwayat; CN/CA/CH/NZ: tanpa data."""
    tv = {
        "JP": [_auc("JP", "10-Year JGB Auction", 6, "TradingView Calendar", "upcoming", time_="03:35")] + [_auc("JP", f"{t}-Year JGB Auction", -9 * i - 3, "TradingView Calendar", "done", rate=0.9 + i / 20, time_="03:35") for i, t in enumerate((10, 30, 5, 20, 40, 10))],
        "GB": [_auc("GB", "10-Year Gilt Auction", 4, "TradingView Calendar", "upcoming", time_="09:30"), _auc("GB", "30-Year Gilt Auction", -5, "TradingView Calendar", "done", rate=4.9, time_="09:30")],
        "AU": [_auc("AU", "10-Year Bond Auction", 8, "TradingView Calendar", "upcoming"), _auc("AU", "10-Year Bond Auction", -14, "TradingView Calendar", "done", rate=4.35)],
        "EU": [_auc("EU", "German 10-Year Bund Auction", 5, "TradingView Calendar", "upcoming", time_="10:30")],
        "ID": [_auc("ID", "10-Year Bond Auction", -12, "TradingView Calendar", "done", rate=6.7), _auc("ID", "5-Year Bond Auction", -26, "TradingView Calendar", "done", rate=6.4)],
    }
    us = [_auc("US", "10-Year Note", 6, "US Treasury FiscalData", "upcoming", amount=39e9)] + \
         [_auc("US", t, -7 * i - 2, "US Treasury FiscalData", "done", rate=4.0 + i / 40, btc=2.4 + (i % 3) / 10, amount=40e9) for i, t in enumerate(("2-Year Note", "10-Year Note", "30-Year Bond", "5-Year Note", "7-Year Note", "13-Week Bill"))]
    return us, tv


async def no_cal_dict(*a, **k):
    return {}


# ------------------------------------------------------------------ perdagangan (UN Comtrade) & holding ETF tiruan
def _trade_partners(reporter):
    """Daftar mitra deterministik per negara pelapor (tanpa dirinya sendiri)."""
    from terminal.providers import trade
    codes = [c for c in trade.STATIC if c != reporter]
    r = _rng("trade", reporter)
    r.shuffle(codes)
    return codes[:16]


async def comtrade_call(reporter, partner, flow, year, cmd="TOTAL"):
    from terminal.providers import trade
    if cmd == "AG2":
        r = _rng("ag2", reporter, flow)
        return [dict(cmdCode=c, primaryValue=float(r.uniform(1e8, 9e10))) for c in list(trade.HS2)[:30]] + [dict(cmdCode="TOTAL", primaryValue=1e12)]
    if partner is None:
        rows = []
        for pc in _trade_partners(reporter):
            r = _rng("tp", reporter, pc, flow)
            rows.append(dict(cmdCode="TOTAL", partnerCode=pc, primaryValue=float(r.uniform(1e9, 2e11))))
        rows.append(dict(cmdCode="TOTAL", partnerCode=0, primaryValue=sum(x["primaryValue"] for x in rows) * 1.1))
        return rows
    r = _rng("pair", reporter, partner, flow)
    return [dict(cmdCode="TOTAL", partnerCode=partner, primaryValue=float(r.uniform(1e9, 2e11)))]


async def partner_ref_mock():
    return {}


def holdings_sync(etf):
    r = _rng("hold", etf)
    names = ["AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "META", "JPM", "XOM", "UNH", "V"]
    return [dict(symbol=n, name=n + " Inc", weight=float(8 - i * 0.6 + r.uniform(0, 0.3))) for i, n in enumerate(names)]


# ------------------------------------------------------------------ pasang
def install(monkeypatch):
    from terminal import http as H
    from terminal.providers import yahoo, yields, annual, worldbank, rates, fred, cftc, news, geo, gpr, portwatch, macro, calendar

    monkeypatch.setattr(yahoo, "_download", _download)
    monkeypatch.setattr(yahoo, "_history_sync", _history_sync)
    monkeypatch.setattr(yahoo, "_ohlcv_sync", _ohlcv_sync)
    monkeypatch.setattr(yahoo, "_financials_sync", _financials_sync)
    monkeypatch.setattr(yahoo, "_holdings_sync", holdings_sync)
    from terminal.providers import trade
    monkeypatch.setattr(trade, "_call", comtrade_call)
    monkeypatch.setattr(trade, "_partner_ref", partner_ref_mock)

    chain = {}
    for cc in COUNTRY_ORDER:
        if cc == "NZ":
            chain[cc] = [("MockNZ", make_adapter(cc, fail=True))]
        elif cc == "ID":
            chain[cc] = [("MockID", make_adapter(cc, drop=("2Y",)))]
        else:
            chain[cc] = [("Mock" + cc, make_adapter(cc))]
    monkeypatch.setattr(yields, "CHAIN", chain)

    monkeypatch.setattr(annual, "_imf_fetch", imf_fetch_factory())

    async def wb_fail(*a, **k):
        raise RuntimeError("World Bank tiruan gagal")
    monkeypatch.setattr(worldbank, "indicator", wb_fail)

    # policy_all dibungkus cached; ganti seluruh fungsi
    monkeypatch.setattr(rates, "policy_all", policy_all_factory())
    monkeypatch.setattr(fred, "series", fred_series)
    monkeypatch.setattr(macro, "fred", fred, raising=False)
    monkeypatch.setattr(cftc, "get_json", cftc_get_json)
    monkeypatch.setattr(news, "_pull", news_pull)
    monkeypatch.setattr(news, "fetch_feed_url", fetch_feed_url)
    monkeypatch.setattr(rates.N, "fetch_feed_url", fetch_feed_url, raising=False)
    monkeypatch.setattr(geo, "gdelt_hotspots", gdelt)
    monkeypatch.setattr(gpr, "daily", gpr_daily)
    monkeypatch.setattr(portwatch, "summary", pw_summary)

    async def no_cal(*a, **k):
        return []
    from terminal.providers import auctions
    us_rows, tv_rows = auctions_world()

    async def _us_mock():
        return us_rows, ["US Treasury FiscalData"]

    async def _tv_mock():
        return tv_rows
    monkeypatch.setattr(auctions, "_us", _us_mock)
    monkeypatch.setattr(auctions, "tv_by_country", _tv_mock)
    monkeypatch.setattr(auctions, "_ff_by_country", no_cal_dict)

    async def bs_ecb_fail():
        raise RuntimeError("ECB ILM tiruan gagal")  # memaksa jalur cadangan FRED
    monkeypatch.setattr(rates, "_bs_ecb", bs_ecb_fail)

    async def bis_fail(codes):
        raise RuntimeError("BIS tiruan gagal")
    monkeypatch.setattr(annual, "_bis_debt", bis_fail)

    monkeypatch.setattr(calendar, "tv_calendar", no_cal)
    monkeypatch.setattr(calendar, "ff_calendar", no_cal)
    H.clear_cache()


# ------------------------------------------------------------------ retail sentiment (Myfxbook) tiruan
RETAIL_MOCK_SYMBOLS = (["ADAUSD", "AUDCAD", "AUDCHF", "AUDJPY", "AUDNZD", "AUDSGD", "AUDUSD", "AXSUSD", "BCHUSD", "BTCJPY", "BTCUSD", "CADCHF", "CADJPY", "CHFJPY",
                        "EURAUD", "EURCAD", "EURCHF", "EURGBP", "EURJPY", "EURNZD", "EURUSD", "GBPAUD", "GBPCAD", "GBPCHF", "GBPJPY", "GBPNZD", "GBPUSD",
                        "NZDCAD", "NZDCHF", "NZDJPY", "NZDUSD", "USDCAD", "USDCHF", "USDJPY", "XAUUSD", "XAGUSD", "USOIL", "ETHUSD", "SOLUSD", "XRPUSD"]
                       + [f"MOCK{i:03d}USD" for i in range(70)])


def seed_retail(snapshots=2, interval=1200, symbols=None):
    """Isi tabel retail_snap dengan `snapshots` snapshot berjarak `interval` detik (yang terakhir = sekarang)."""
    from terminal import store
    syms = symbols or RETAIL_MOCK_SYMBOLS
    now = int(time.time())
    store.execute("DELETE FROM retail_snap")
    rows = []
    for sym in syms:
        r = _rng("retail", sym)
        lv = float(r.uniform(5, 1800)) if sym != "XAUUSD" else 1750.0
        sv = float(r.uniform(5, 1800)) if sym != "XAUUSD" else 1700.0
        lp = int(r.integers(1, 9000))
        sp = int(r.integers(1, 9000))
        al = float(r.uniform(0.5, 4400)) if sym != "XAUUSD" else 4344.1723
        ash = float(r.uniform(0.5, 4400)) if sym != "XAUUSD" else 3954.1414
        for k in range(snapshots):
            ts = now - (snapshots - 1 - k) * interval
            lv = max(1.0, lv + float(r.normal(0, lv * 0.01)))
            sv = max(1.0, sv + float(r.normal(0, sv * 0.01)))
            lp = max(1, lp + int(r.integers(-40, 40)))
            sp = max(1, sp + int(r.integers(-40, 40)))
            tot = lv + sv
            # sengaja TIDAK dibulatkan (seperti data mentah API) agar bug 'float panjang' ikut teruji
            rows.append((ts, sym, lv / tot * 100, sv / tot * 100, lv, sv, lp, sp, al + float(r.normal(0, 0.5)), ash + float(r.normal(0, 0.5))))
    store.executemany("INSERT INTO retail_snap VALUES(?,?,?,?,?,?,?,?,?,?)", rows)
    return len(rows)


def install_retail(monkeypatch, snapshots=2):
    from terminal.providers import myfxbook
    monkeypatch.setattr(myfxbook, "enabled", lambda: True)

    async def poll_once():
        myfxbook._session["error"] = None
        myfxbook._session["last_ok"] = int(time.time())
        return 0
    monkeypatch.setattr(myfxbook, "poll_once", poll_once)
    seed_retail(snapshots)
