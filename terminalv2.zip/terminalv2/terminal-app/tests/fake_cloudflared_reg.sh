#!/bin/sh
# cloudflared palsu (uji pengawas tunnel): URL unik per proses + baris "Registered tunnel connection" lalu tetap hidup
echo "2026-11-23T00:00:00Z INF Requesting new quick Tunnel on trycloudflare.com..."
echo "2026-11-23T00:00:00Z INF |  https://fake-$$.trycloudflare.com  |"
echo "2026-11-23T00:00:01Z INF Registered tunnel connection connIndex=0 connection=abc event=0 ip=198.41.192.7 location=sin01 protocol=http2"
exec sleep 600
