"""Uji UI peta THINKING: bola sinyal bergerak DI SEPANJANG kabel dan tidak pernah tampil diam di titik (0,0) kiri atas
(dulu <animateMotion> dengan <mpath> salah namespace + `begin` relatif awal dokumen membuat bola "nyasar" di kiri peta).

    python tests/run_mock_server.py 8765 &   lalu:   python tests/ui_think_check.py ./shots
"""
import json
import os
import sys
import time
from playwright.sync_api import sync_playwright
OUT = sys.argv[1] if len(sys.argv) > 1 else "."
BASE = os.environ.get("BASE", "http://127.0.0.1:8765")
KEY = os.environ.get("ADMIN_KEY_TEST", "admin-test")
ok = []


def check(name, cond, info=""):
    ok.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name, info)


def inject(route):
    r = route.fetch()
    try:
        st = r.json()
    except Exception:
        st = {}
    now = time.time()
    # satu permintaan dua langkah (technical -> news -> fundamental) + satu kiriman langsung news -> technical
    st["pulses"] = [dict(at=now - 0.2, src="technical", dst="fundamental", kind="request"), dict(at=now - 0.1, src="news", dst="technical", kind="deliver")]
    route.fulfill(status=200, content_type="application/json", body=json.dumps(st))


with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
    c = b.new_context(viewport={"width": 1440, "height": 860}); pg = c.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(BASE + f"/?key={KEY}#dashboard"); pg.wait_for_timeout(2500)
    pg.route("**/api/thinking/state*", inject)
    pg.evaluate("location.hash='#thinking'"); pg.wait_for_timeout(300)
    samples = []
    for _ in range(45):
        # posisi TERGAMBAR (layar -> koordinat peta), bukan atribut: bola lama tanpa cx/cy diam di (0,0) peta
        samples += pg.evaluate("""(()=>{const m=document.querySelector('#t-zoom').getScreenCTM().inverse();
            return [...document.querySelectorAll('#t-packets circle')].map(c=>{const r=c.getBoundingClientRect();
              const p=new DOMPoint(r.x+r.width/2,r.y+r.height/2).matrixTransform(m);
              return {v:c.getAttribute('visibility')==='hidden'||getComputedStyle(c).visibility==='hidden'?'hidden':'visible',x:p.x,y:p.y,anim:c.querySelector('animateMotion')!=null}})})()""")
        pg.wait_for_timeout(80)
    vis = [s for s in samples if s["v"] == "visible"]
    check("bola sinyal muncul saat ada pulse", len(vis) >= 5, len(vis))
    check("tidak ada bola tampil di titik asal (0,0)", all(s["x"] == s["x"] and (s["x"] > 60 or s["y"] > 60) for s in vis), [s for s in vis if not (s["x"] > 60 or s["y"] > 60)][:3])
    check("bola tersembunyi sebelum waktunya mulai", all(s["v"] in ("hidden", "visible") for s in samples))
    check("tanpa <animateMotion> (digerakkan JS)", not any(s["anim"] for s in samples))
    xs = {round(s["x"]) for s in vis}
    check("bola benar-benar bergerak", len(xs) >= 4, sorted(xs)[:8])
    pg.unroute("**/api/thinking/state*")
    pg.wait_for_timeout(4000)
    left = pg.evaluate("document.querySelectorAll('#t-packets circle').length")
    check("bola dihapus setelah sampai", left == 0, left)
    pg.screenshot(path=os.path.join(OUT, "think_map.png"))
    check("tanpa error JS", not errs, errs[:3])
    b.close()
print(f"\n{sum(ok)}/{len(ok)} lulus")
sys.exit(0 if all(ok) else 1)
