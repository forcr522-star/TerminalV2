"""Menu HEATMAP & FOOTPRINT: orderbook lokal Binance, kolom heatmap (tanpa repaint), footprint, big order,
skala per timeframe, key level, kontrol pair admin, dan hak akses admin/user. Tanpa jaringan."""
import asyncio
import base64
import datetime as dt_mod
import json
import math

import numpy as np
import pytest

import mockworld
from terminal import auth, config, store
from terminal.heatmap import book as BK, db, control, engine, view, binance as B, settings as C, liqmodel as LM, backfill as BF

T0 = 1_800_000_000 // 3600 * 3600          # awal jam (kolom menit & jam sejajar)


def run(coro):
    return asyncio.run(coro)


@pytest.fixture(autouse=True)
def _fresh():
    db.ensure()
    for t in ("hm_col", "hm_big", "hm_bigh"):
        store.execute(f"DELETE FROM {t}")
    store.execute("DELETE FROM kv WHERE k LIKE 'hm_%'")
    control.reload()
    engine.manager.syms.clear()
    view._cc.clear(); view._rows.clear(); view._bookc.clear(); view._pastc.clear(); view._liqc.clear()
    yield
    engine.manager.syms.clear()
    store.execute("DELETE FROM kv WHERE k LIKE 'hm_%'")
    control.reload()


def snap(bids, asks, L=100):
    return {"lastUpdateId": L, "bids": [[str(p), str(q)] for p, q in bids], "asks": [[str(p), str(q)] for p, q in asks]}


def ev(U, u, b=(), a=(), E=None):
    return {"e": "depthUpdate", "E": E or 0, "s": "BTCUSDT", "U": U, "u": u, "b": [[str(p), str(q)] for p, q in b], "a": [[str(p), str(q)] for p, q in a]}


LV = 99_600                                  # bid besar 0,4% di bawah harga (di dalam pita orderbook M1)


def live_sym(sym="BTCUSDT", b=10.0, bids=((99_990, 1.0), (LV, 10.0)), asks=((100_010, 1.0), (100_400, 5.0))):
    """Sym dalam keadaan LIVE tanpa jaringan (buku dari snapshot tiruan)."""
    so = engine.Sym(sym, None)
    so._meta_loaded = True
    so.tick, so.b = 0.01, b
    so.book = BK.build_synced(snap(bids, asks), 5000, b, [])
    so.state = "live"
    so.last_resync = so.last_prune = 4e9            # tanpa snapshot ulang berkala di tes
    so.session_col = {1: T0, 2: T0}                 # sesi dimulai di T0 (waktu tiruan)
    engine.manager.syms[sym] = so
    return so


def trade(so, T, p, q, m):
    so.on_trade({"e": "aggTrade", "s": so.sym, "p": str(p), "q": str(q), "T": T, "m": m})


# ------------------------------------------------------------------------------------------- orderbook lokal
def test_nice_bucket_from_real_prices():
    assert BK.nice_step(61478 * 1e-4, 0.01) == 5
    assert BK.nice_step(1727 * 1e-4, 0.01) == 0.2
    assert BK.nice_step(0.9415 * 1e-4, 0.0001) == 0.0001
    assert BK.nice_step(3614 * 1e-4, 0.01) == 0.5
    assert BK.nice_step(72.7 * 1e-4, 0.01) == 0.01


def test_book_sync_follows_binance_procedure():
    s = snap([(100, 1), (99, 2)], [(101, 1), (102, 3)], L=100)
    evs = [ev(90, 99, b=[(100, 9)]),                 # lama (u <= L): diabaikan
           ev(98, 103, b=[(100, 0), (98, 4)]),       # menyambung snapshot: U <= L+1 <= u
           ev(104, 106, a=[(101, 2)])]
    bk = BK.build_synced(s, 5000, 1.0, evs)
    assert 100.0 not in bk.bids and bk.bids[98.0] == 4 and bk.asks[101.0] == 2
    assert bk.last_u == 106
    # jumlah notional per bucket konsisten dengan level mentah
    for agg, side in ((bk.bb, bk.bids), (bk.ab, bk.asks)):
        ref = {}
        for p, q in side.items():
            ref[BK.bidx(p, 1.0)] = ref.get(BK.bidx(p, 1.0), 0) + p * q
        assert agg.keys() == ref.keys() and all(abs(agg[k] - ref[k]) < 1e-6 for k in ref)
    with pytest.raises(BK.SyncError):
        bk.apply(ev(108, 110, b=[(97, 1)]))          # event 107 hilang
    with pytest.raises(BK.SyncError):
        BK.build_synced(s, 5000, 1.0, [ev(105, 107)])  # tidak menyambung snapshot


def test_book_coverage_only_where_snapshot_is_complete():
    s = snap([(100 - i, 1) for i in range(5)], [(101 + i, 1) for i in range(3)])
    bk = BK.build_synced(s, 5, 1.0, [])
    assert bk.cov_lo == 96 and math.isinf(bk.cov_hi)        # bid terpotong limit, ask lengkap
    lo, hi = bk.window(100.5, 0.25)
    assert lo == 96 and hi == pytest.approx(100.5 * 1.25)
    assert bk.near_edge(97.0) and not bk.near_edge(100.5)


# ------------------------------------------------------------------------------------------- kodek & DB
def test_codec_roundtrip_and_pack():
    v = np.array([0, 1.5, 990_000, 12.25, 0, 7e7])
    out = db.dec(db.enc(v))
    nz = v > 0
    assert np.all(np.abs(out[nz] - v[nz]) / v[nz] < 0.003) and out[0] == 0
    col = db.Col(10.0, 9900, 3, v, 9990, np.vstack([np.array([0.0, 5000, 0]), np.array([200.0, 0, 0])]))
    db.put_cols([("BTCUSDT", 1, T0, col)])
    got = db.get_cols("BTCUSDT", 1, T0, T0 + 60)[T0]
    assert got.n == 3 and got.i0 == 9901 and len(got.heat) == 5        # nol di tepi dipangkas
    assert got.fi0 == 9990 and got.fp[0][1] == pytest.approx(5000, rel=3e-3) and got.fp[1][0] == pytest.approx(200, rel=3e-3)


# ------------------------------------------------------------------------------------------- kolom heatmap
def test_columns_are_time_averages_and_never_repaint():
    so = live_sym()
    k99 = BK.bidx(LV, so.b)
    so.step(T0 + 5)
    so.step(T0 + 35)
    # level bid besar TERSAPU (dihapus) di menit berikutnya
    so.book.apply(ev(101, 101, b=[(LV, 0)]))
    so.step(T0 + 65)
    so.step(T0 + 95)
    so.step(T0 + 125)                                # menutup menit T0 dan T0+60 (setelah GRACE)
    c0, c1 = so.recent[1][T0], so.recent[1][T0 + 60]
    assert c0.n == 2 and c0.heat[k99 - c0.i0] == pytest.approx(LV * 10)
    assert not (c1.i0 <= k99 < c1.i0 + len(c1.heat)) or c1.heat[k99 - c1.i0] == 0
    # riwayat tetap: trade terlambat untuk menit yang sudah ditutup tidak mengubah kolomnya
    before = c0.heat.copy()
    trade(so, (T0 + 30) * 1000, 99_500, 1.0, False)
    assert so.late == 1 and np.array_equal(so.recent[1][T0].heat, before)
    # kolom 1 jam masih berjalan; rata-rata waktu: 2 dari 5 cuplikan memuat level besar
    a2 = so.accs[2][T0]
    assert a2.n == 5 and a2.heat[k99 // 10] == pytest.approx(LV * 10 * 2)
    run(engine.Manager.flush(engine.manager))
    dbc = db.get_cols("BTCUSDT", 1, T0, T0 + 120)
    assert set(dbc) == {T0, T0 + 60} and dbc[T0].heat[k99 - dbc[T0].i0] == pytest.approx(LV * 10, rel=3e-3)


def test_restart_continues_the_running_column_without_gap():
    a = live_sym()
    k = BK.bidx(LV, a.b)
    a.step(T0 + 5)
    a.step(T0 + 25)
    trade(a, (T0 + 26) * 1000, 100_000, 0.1, False)
    db.put_cols(a.checkpoint_rows())                # checkpoint berkala / saat server berhenti
    b = live_sym()                                  # sesi baru (restart) di menit yang sama
    b.session_col = {1: T0, 2: T0}
    b.step(T0 + 45)
    acc = b.accs[1][T0]
    assert acc.n == 3 and acc.heat[k] == pytest.approx(LV * 10 * 3, rel=0.01)
    assert acc.fp[BK.bidx(100_000, b.b)][0] == pytest.approx(10_000, rel=0.01)
    b.step(T0 + 65)
    assert b.recent[1][T0].n == 3


def test_short_recording_gaps_are_bridged_long_ones_are_not():
    t = [T0 + i * 60 for i in range(40)]
    arr = lambda v: (0, np.array([v], dtype=np.float32))
    cols = {t[i]: arr(i + 1) for i in range(40) if not (2 <= i <= 3 or 10 <= i <= 30)}
    out, filled = view.fill_gaps(t[1:], cols, 60)             # t[0] di luar jendela -> awal jendela = data
    assert filled == t[2:4] and out[t[2]] is cols[t[1]] and out[t[3]] is cols[t[1]]
    assert all(t[i] not in out for i in range(10, 31))        # jeda 21 menit tetap kosong (tidak dikarang)
    _, f2 = view.fill_gaps(t[2:], cols, 60)                   # jeda di AWAL jendela tidak diisi
    assert t[2] not in f2 and t[3] not in f2


def test_footprint_and_big_orders():
    so = live_sym()
    so.floor = 10_000
    T = (T0 + 130) * 1000
    trade(so, T, 100_000, 0.1, False)                # satu order beli market menyapu 2 level (T & sisi sama)
    trade(so, T, 100_010, 0.1, False)
    trade(so, T + 5, 99_990, 0.02, True)             # jual kecil (bukan big order)
    trade(so, T + 9, 99_990, 0.5, True)              # jual besar
    so._flush_group()
    fp = so.accs[1][T0 + 120].fp
    assert fp[BK.bidx(100_000, so.b)][0] == pytest.approx(10_000) and fp[BK.bidx(99_990, so.b)][1] == pytest.approx(99_990 * 0.52)
    big = list(so.big)
    assert [(x[3], round(x[2])) for x in big] == [(1, 20_001), (-1, 49_995)]
    assert big[0][1] == pytest.approx(20_001 / 0.2)          # harga = VWAP order
    assert so.bigh[T0][(BK.bidx(big[1][1], so.b * 10), -1)][1] == 1


def test_big_order_threshold_is_a_24h_percentile():
    d = engine.SizeDist()
    for i in range(1, 1001):
        d.add(float(i), T0)
    assert 880 <= d.pct(90) <= 1000 and d.total() == 1000
    assert d.pct(50) == pytest.approx(500, rel=0.1)


def test_big_order_floor_seeded_from_recent_trades(monkeypatch):
    rows = [{"T": T0 * 1000 + i, "m": i % 2 == 0, "p": "100", "q": str(1 + (i % 100))} for i in range(600)]

    async def fake_agg(sym, limit=1000):
        return rows
    monkeypatch.setattr(B, "agg_trades", fake_agg)
    so = live_sym()
    run(so.seed_sizes())
    assert so.dist.total() == 600 and so.floor_src == "awal"
    so.step(T0 + 5)
    assert so.floor_src == "sampel REST" and 9_000 <= so.floor <= 11_000     # ±persentil 99,5 dari 100..10.000 USDT


def test_big_trades_are_single_orders_with_tf_scaled_threshold(monkeypatch):
    so = live_sym()
    so.floor = 1_000
    N = 100_000                                                       # distribusi 24 jam berekor panjang (Pareto), seperti ukuran order nyata
    for i in range(N):
        so.dist.add(1_000 / (1 - (i + 0.5) / N), T0)
    floors = [so.trade_floor(tf) for tf in C.TF_ORDER]
    assert floors == sorted(floors) and floors[-1] > 10 * floors[0]  # makin tinggi TF makin tinggi ambangnya
    per_candle = [sum(1 for i in range(N) if 1_000 / (1 - (i + 0.5) / N) >= f) * C.TFS[tf]["sec"] / 86400 for tf, f in zip(C.TF_ORDER, floors)]
    assert max(per_candle) <= 2 * C.BIG_PER_CANDLE                    # rata-rata bubble per candle tetap jarang di setiap TF
    for i in range(400):                                              # 400 order besar tercatat di jam terakhir
        usd = round(1_000 / (1 - ((i * 7919) % 400 + 0.5) / 400 * 0.99999), 2) * 100
        so.big.append(((T0 + i * 9) * 1000, 100_000.0, float(usd), 1 if i % 2 else -1))

    async def fake_klines(sym, iv, limit):
        tf = next(t for t in C.TF_ORDER if C.TFS[t]["iv"] == iv)
        return _walk(min(limit, 1000), C.TFS[tf]["sec"], start=100_000)
    monkeypatch.setattr(B, "klines", fake_klines)
    m1 = run(view.big_trades(so, "M1", T0 - 600, T0 + 4000))
    h1 = run(view.big_trades(so, "H1", T0 - 3600, T0 + 7200))
    assert m1 and all(x[2] >= so.trade_floor("M1") for x in m1) and len(m1) <= C.BIG_MAX_BUBBLES
    assert all(x[2] >= so.trade_floor("H1") for x in h1) and len(h1) < len(m1)
    raw = {r[2] for r in so.big}
    assert all(x[2] in raw for x in m1 + h1)                          # setiap bubble = satu order tercatat
    assert [x[4] for x in m1] == sorted(x[4] for x in m1)


def test_prune_keeps_big_trades_long_and_small_ones_short():
    now = T0 + 30 * 86400
    old, new = (now - 10 * 86400) * 1000, (now - 3600) * 1000
    db.add_big([("BTCUSDT", old, 1.0, 5_000_000.0, 1), ("BTCUSDT", old, 1.0, 50_000.0, 1), ("BTCUSDT", new, 1.0, 50_000.0, -1),
                ("ETHUSDT", old, 1.0, 9e9, 1)])
    db.prune(now, 5, 365, {"BTCUSDT": 1_000_000})
    left = sorted((r[2], r[3]) for r in db.get_big("BTCUSDT", 0, now * 1000))
    assert left == [(50_000.0, -1), (5_000_000.0, 1)] and db.get_big("ETHUSDT", 0, now * 1000) == []


# ------------------------------------------------------------------------------------------- isian riwayat (arsip trade Binance)
def test_backfill_parse_and_process():
    csv_text = "agg_trade_id,price,quantity,first_trade_id,last_trade_id,transact_time,is_buyer_maker,is_best_match\n" \
        f"1,100000.0,0.5,1,1,{(T0 + 10) * 1_000_000},False,True\n" \
        f"2,100010.0,0.5,2,3,{(T0 + 10) * 1_000_000},False,True\n" \
        f"3,99990.0,0.2,4,4,{(T0 + 70) * 1000},True,True\n" \
        f"4,99990.0,9.0,5,5,{(T0 + 4000) * 1000},True,True\n"
    tr = BF.parse_csv(csv_text)
    assert (tr["T"][0], tr["p"][0], tr["q"][0], tr["mk"][0]) == ((T0 + 10) * 1000, 100000.0, 0.5, False) and tr["mk"][2]   # mikrodetik -> milidetik
    assert BF.parse_csv(csv_text.split("\n", 1)[1])["T"].tolist() == tr["T"].tolist()                                   # tanpa header
    orders, fp1, fp2 = BF.process(tr, 10.0, (T0 + 3600) * 1000)                         # trade ke-4 di luar rentang
    assert [(o[0], round(o[2]), o[3]) for o in orders] == [((T0 + 10) * 1000, 100005, 1), ((T0 + 70) * 1000, 19998, -1)]
    assert fp1[T0][BK.bidx(100000.0, 10.0)][0] == pytest.approx(50000) and fp1[T0 + 60][BK.bidx(99990.0, 10.0)][1] == pytest.approx(19998)
    assert fp2[T0][BK.bidx(100000.0, 10.0) // 10][0] == pytest.approx(100005)                # bucket jam 10x lebih lebar: kedua trade


def test_backfill_write_keeps_orderbook_heat_and_skips_live_session():
    heat = db.Col(10.0, 9_990, 4, np.array([123.0, 456.0]))
    db.put_cols([("BTCUSDT", 1, T0, heat)])
    db.add_big([("BTCUSDT", (T0 + 5) * 1000, 1.0, 7.0, 1)])                           # sisa rekaman lama di rentang -> diganti
    orders = [((T0 + 1) * 1000 + i, 100_000.0, float(1_000 + i), 1) for i in range(400)]
    fp1 = {T0: {10_000: [5.0, 1.0]}, T0 + 60: {10_000: [2.0, 2.0]}, T0 + 120: {10_000: [9.0, 9.0]}}
    nb, nc, floor = BF.write("BTCUSDT", 10.0, orders, fp1, {}, T0 * 1000, (T0 + 600) * 1000, {1: T0 + 120, 2: T0})
    got = db.get_cols("BTCUSDT", 1, T0, T0 + 600)
    assert set(got) == {T0, T0 + 60}                                                  # menit sesi live (T0+120) tidak disentuh
    assert np.allclose(got[T0].heat, [123.0, 456.0], rtol=3e-3) and got[T0].n == 4    # heat orderbook dipertahankan
    assert got[T0].fp[0][0] == pytest.approx(5.0, rel=3e-3) and got[T0 + 60].n == 0
    big = db.get_big("BTCUSDT", T0 * 1000, (T0 + 600) * 1000)
    assert big and min(r[2] for r in big) >= floor and 7.0 not in [r[2] for r in big] and nb == len(big)


def test_backfill_run_uses_archives_once_and_rest_for_today(monkeypatch):
    so = live_sym()
    now = T0 + 6 * 3600                                                               # 06:00 UTC
    so.session_ms = (now - 60) * 1000
    so.session_col = {1: now // 60 * 60 - 60, 2: now // 3600 * 3600}
    calls = {"day": [], "rest": []}
    day0 = int(dt_mod.datetime.fromtimestamp(now, dt_mod.timezone.utc).replace(hour=0, minute=0, second=0).timestamp())

    async def fake_day(sym, day):
        calls["day"].append(day)
        if day.endswith(str((dt_mod.date.fromtimestamp(day0) - dt_mod.timedelta(days=3)).day).zfill(2)):
            return None                                                               # arsip belum terbit
        t = int(dt_mod.datetime.strptime(day, "%Y-%m-%d").replace(tzinfo=dt_mod.timezone.utc).timestamp())
        return [((t + 60 + i) * 1000, 100_000.0, 0.01 * (1 + i % 50), i % 2 == 0) for i in range(600)]

    async def fake_rest(sym, a, b):
        calls["rest"].append((a, b))
        return [(a + i * 1000, 100_000.0, 0.01 * (1 + i % 50), False) for i in range(600)]
    monkeypatch.setattr(BF, "fetch_day", fake_day)
    monkeypatch.setattr(BF, "fetch_rest", fake_rest)
    monkeypatch.setattr(BF, "DAYS", 3)
    rev0 = so.bf_rev
    s1 = run(BF.run_sym(so, now=now))
    assert s1["days"] == 2 and so.bf_rev > rev0
    assert calls["rest"][0][1] == so.session_ms                                        # jam TERBARU dulu
    rs = sorted(calls["rest"])
    assert rs[0][0] == day0 * 1000 and rs[-1][1] == so.session_ms                         # per jam, tanpa celah
    assert all(a[1] == b[0] and b[1] - b[0] <= 3_600_000 for a, b in zip(rs, rs[1:]))
    assert db.get_big("BTCUSDT", (day0 - 86400) * 1000, day0 * 1000)                  # kemarin terisi dari arsip
    assert so.dist.total() > 0                                                        # distribusi ukuran order ikut terisi
    calls["day"].clear(); calls["rest"].clear()
    s2 = run(BF.run_sym(so, now=now))
    assert len(calls["day"]) == 1 and calls["rest"] == [] and s2["days"] == 0          # hanya hari yang belum terbit dicoba lagi


def test_backfill_skips_range_recorded_live_by_previous_session(monkeypatch):
    so = live_sym()
    now = T0 + 6 * 3600
    day0 = int(dt_mod.datetime.fromtimestamp(now, dt_mod.timezone.utc).replace(hour=0, minute=0, second=0).timestamp())
    so.session_ms = (now - 60) * 1000
    so.session_col = {1: now // 60 * 60 - 60, 2: now // 3600 * 3600}
    prev_from, prev_to = (day0 + 3600) * 1000, (day0 + 5 * 3600) * 1000              # sesi lalu: 01:00-05:00 live
    store.kv_set("hm_bf_BTCUSDT", {"days": [], "rest_day": str(dt_mod.datetime.fromtimestamp(now, dt_mod.timezone.utc).date()), "rest_to": prev_from})
    store.kv_set("hm_live_BTCUSDT", {"from": prev_from, "to": prev_to})
    calls = []

    async def fake_rest(sym, a, b):
        calls.append((a, b))
        return []
    monkeypatch.setattr(BF, "fetch_rest", fake_rest)
    monkeypatch.setattr(BF, "DAYS", 1)
    monkeypatch.setattr(BF, "fetch_day", lambda sym, day: asyncio.sleep(0, None))
    run(BF.run_sym(so, now=now))
    today = sorted(c for c in calls if c[0] >= day0 * 1000)
    assert today and today[0][0] == prev_to + 1 and today[-1][1] == so.session_ms       # hanya jeda 05:00 -> sesi ini
    so.cov_to = so.session_ms + 5000
    assert so.live_mark() == {"from": so.session_ms, "to": so.session_ms + 5000}
    so.on_ws_lost(); so.on_trade({"p": "100000", "q": "0.1", "T": so.session_ms + 9000, "m": False})
    assert so.live_mark()["to"] == so.session_ms + 5000                                 # putus koneksi -> rentang berhenti


def test_backfill_rest_fallback_for_yesterday_and_light_deep_days(monkeypatch):
    so = live_sym()
    now = T0 + 6 * 3600
    today = dt_mod.datetime.fromtimestamp(now, dt_mod.timezone.utc).date()
    day0 = BF._day_ms(today)
    so.session_ms = (now - 60) * 1000
    so.session_col = {1: now // 60 * 60 - 60, 2: now // 3600 * 3600}
    store.kv_set("hm_bf_BTCUSDT", {"days": [], "rest_day": str(today), "rest_to": so.session_ms})
    deep_day = today - dt_mod.timedelta(days=C.LEVELS[1]["days"])
    rest = []

    def trades(t0_ms, n=3000):
        return [(t0_ms + 60_000 + i * 20, 100_000.0, 0.01 * (1 + i % 50) * (40 if i % 997 == 0 else 1), i % 2 == 0) for i in range(n)]

    async def fake_day(sym, day):
        if day == str(today - dt_mod.timedelta(days=1)):
            return None                                                               # arsip kemarin belum terbit
        return trades(BF._day_ms(dt_mod.date.fromisoformat(day)))

    async def fake_rest(sym, a, b):
        rest.append((a, b))
        return trades(a, 200)
    monkeypatch.setattr(BF, "fetch_day", fake_day)
    monkeypatch.setattr(BF, "fetch_rest", fake_rest)
    monkeypatch.setattr(BF, "DAYS", C.LEVELS[1]["days"])
    out = run(BF.run_sym(so, now=now))
    y0 = day0 - 86_400_000
    assert out["days"] == C.LEVELS[1]["days"]                                          # kemarin selesai lewat REST
    rest.sort()
    assert rest[0][0] == y0 and rest[-1][1] == day0 and len(rest) == 24                 # REST per jam, 00:00 -> 24:00
    t0 = BF._day_ms(deep_day)
    assert not db.get_cols("BTCUSDT", 1, t0 // 1000, t0 // 1000 + 86400)               # hari lama: tanpa footprint menit
    assert db.get_cols("BTCUSDT", 2, t0 // 1000, t0 // 1000 + 86400)                   # ... tetapi footprint jam ada
    big = db.get_big("BTCUSDT", t0, t0 + 86_400_000)
    assert big and min(r[2] for r in big) >= so.trade_floor("H1") * C.BIG_KEEP_MARGIN - 1e-6  # big trade hanya >= ambang H1 (dgn margin)
    st = store.kv_get("hm_bf_BTCUSDT")
    assert str(today - dt_mod.timedelta(days=1)) in st["days"]


def test_backfill_interleaves_pairs_newest_hour_first(monkeypatch):
    a, b = live_sym(), live_sym()
    b.sym = "ETHUSDT"
    now = T0 + 6 * 3600
    day0 = BF._day_ms(dt_mod.datetime.fromtimestamp(now, dt_mod.timezone.utc).date())
    for so in (a, b):
        so.session_ms = (now - 60) * 1000
        so.session_col = {1: now // 60 * 60 - 60, 2: now // 3600 * 3600}
    calls = []

    async def fake_rest(sym, x, y):
        calls.append((sym, x, y))
        return []
    monkeypatch.setattr(BF, "fetch_rest", fake_rest)
    monkeypatch.setattr(BF, "fetch_day", lambda sym, day: asyncio.sleep(0, None))
    run(BF.run_all([a, b], now=now, days=1))
    today = [c for c in calls if c[1] >= day0]
    assert [c[0] for c in today[:4]] == ["BTCUSDT", "ETHUSDT", "BTCUSDT", "ETHUSDT"]  # bergiliran antar pair
    assert today[0][2] == a.session_ms and today[2][2] == today[0][1]                   # jam terbaru dulu, lalu mundur
    assert BF._gaps(0, 100, [[10, 20], [15, 30], [50, 60]]) == [(0, 10), (30, 50), (60, 100)]
    calls.clear()
    run(BF.run_all([a, b], now=now, days=1))
    assert not [c for c in calls if c[1] >= day0]                                       # sudah tercakup: tidak diulang


def test_backfill_stops_for_pair_deselected_by_admin(monkeypatch):
    so = live_sym()
    now = T0 + 6 * 3600
    so.session_ms = (now - 60) * 1000
    so.session_col = {1: now // 60 * 60 - 60, 2: now // 3600 * 3600}
    calls = []

    async def fake_rest(sym, a, b):
        calls.append((a, b))
        return []

    async def fake_day(sym, day):
        calls.append(day)
        return None
    monkeypatch.setattr(BF, "fetch_rest", fake_rest)
    monkeypatch.setattr(BF, "fetch_day", fake_day)
    run(BF.run_all([so], now=now, days=5, alive=lambda s: False))
    assert calls == []                                                                # pair tidak dipilih -> tanpa permintaan


def test_size_distribution_keeps_newest_hours_when_history_arrives_late():
    d = engine.SizeDist()
    for h in range(30):
        d.add(100.0, T0 + h * 3600)                                                   # 30 jam live
    d.add(100.0, T0 - 10 * 3600)                                                      # riwayat lama datang belakangan
    assert len(d.hours) <= 25 and max(d.hours) == (T0 + 29 * 3600) // 3600 and min(d.hours) >= (T0 + 5 * 3600) // 3600
    rng = np.random.default_rng(1)
    usd, ts = rng.lognormal(8, 1.5, 5000), np.sort(T0 + rng.uniform(0, 30 * 3600, 5000))
    a, b = engine.SizeDist(), engine.SizeDist()
    for u, t in zip(usd, ts):
        a.add(float(u), float(t))
    b.add_many(usd, ts)                                                               # versi tervektor = hasil sama
    assert a.hours == b.hours and a.pct(99.9) == b.pct(99.9)
    c = engine.SizeDist()
    c.load(json.loads(json.dumps(a.dump())), max(a.hours) * 3600 + 60)                # checkpoint -> restart di jam yang sama
    assert c.hours == a.hours
    e = engine.SizeDist()
    e.load(a.dump(), T0 + 40 * 3600)                                                  # jam > 24 jam dari sekarang dibuang
    assert min(e.hours) >= (T0 + 40 * 3600) // 3600 - 24


def test_kline_cache_merges_stream():
    k = engine.Klines(60)
    k.rows, k.stale = [[T0, 1, 2, 0.5, 1.5, 10, 6]], False
    k.on_ws([T0, 1, 3, 0.5, 2.5, 20, 12])
    k.on_ws([T0 + 60, 2.5, 2.6, 2.4, 2.5, 1, 1])
    assert len(k.rows) == 2 and k.rows[0][2] == 3 and not k.stale
    k.on_ws([T0 + 240, 2, 2, 2, 2, 0, 0])
    assert k.stale


# ------------------------------------------------------------------------------------------- data chart per timeframe
def _candles(tf, n, end):
    sec = C.TFS[tf]["sec"]
    rng = 40.0 * sec / 60                    # range candle membesar dengan timeframe
    out = []
    for i in range(n):
        t = end - (n - 1 - i) * sec
        out.append([t, 100_000.0, 100_000 + rng / 2, 100_000 - rng / 2, 100_000.0 + (i % 3 - 1), 1e6 * sec / 60, 6e5 * sec / 60])
    return out


def _fill(so):
    so.floor = 5_000
    for m in range(10):                       # 10 menit cuplikan + trade
        base = T0 + m * 60
        so.step(base + 5)
        so.step(base + 35)
        trade(so, (base + 20) * 1000, 100_000, 0.2, m % 2 == 1)
    so.step(T0 + 600 + 5)


def test_view_scales_with_timeframe_and_has_no_future_leak(monkeypatch):
    so = live_sym()
    _fill(so)
    end = {"M1": T0 + 600, "M5": T0 + 600}

    async def fake_klines(sym, iv, limit):
        tf = next(t for t in C.TF_ORDER if C.TFS[t]["iv"] == iv)
        return _candles(tf, 60, end.get(tf, T0))
    monkeypatch.setattr(B, "klines", fake_klines)
    m1 = run(view.view_payload("BTCUSDT", "M1", 60, "book"))
    m5 = run(view.view_payload("BTCUSDT", "M5", 60, "book"))
    assert m5["row"] > m1["row"] and m5["row"] % so.b == 0          # baris lebih lebar pada TF lebih besar
    assert m5["overview"]["band_pct"] > m1["overview"]["band_pct"]

    def col(p, t):
        hm = p["heat"]
        q = np.frombuffer(base64.b64decode(hm["q"]), dtype=np.uint8).reshape(hm["ncols"], hm["nrows"])
        i = [c[0] for c in p["candles"]].index(t)
        u = hm["vmax"] / 1000
        return u * np.expm1(q[i].astype(float) / 255 * math.log1p(1000))
    k99 = int(math.floor(LV / m1["row"])) - m1["heat"]["k0"]
    assert col(m1, T0)[k99] == pytest.approx(LV * 10, rel=0.02)
    assert col(m1, T0 - 60).max() == 0                              # sebelum perekaman: kosong (tidak dikarang)
    # candle M5 = rata-rata waktu 5 menitnya; nilai per baris M5 >= nilai bucket M1 (baris lebih lebar menjumlah lebih banyak)
    k5 = int(math.floor(LV / m5["row"])) - m5["heat"]["k0"]
    assert col(m5, T0)[k5] >= col(m1, T0)[k99] * 0.98
    # bubble = big trade TUNGGAL (tidak dijumlahkan); ambang M5 > M1
    assert m1["bubbles"] and all(b[2] == 20_000 for b in m1["bubbles"] + m5["bubbles"])
    assert so.trade_floor("M5") > so.trade_floor("M1")
    # tanpa kebocoran masa depan: kolom candle tutup tidak berubah oleh cuplikan sesudahnya
    before = {t: v[1].copy() for t, v in run(view.candle_cols(so, "M1", [T0, T0 + 60], m1["row"])).items()}
    view._cc.clear()                                                 # hitung ulang dari kolom tersimpan, bukan cache
    so.book.apply(ev(101, 101, b=[(LV, 50.0)]))
    so.step(T0 + 600 + 35)
    so.step(T0 + 720)
    after = run(view.candle_cols(so, "M1", [T0, T0 + 60], m1["row"]))
    assert all(np.array_equal(before[t], after[t][1]) for t in before)
    again = run(view.view_payload("BTCUSDT", "M1", 60, "book"))
    assert col(again, T0)[k99] == pytest.approx(LV * 10, rel=0.03)
    # key level: bid besar (likuiditas besar yang bertahan) terdeteksi di bawah harga
    lv = again["levels"]["below"]
    assert any(abs(x["price"] - LV) <= again["row"] for x in lv)


def test_candles_before_session_are_final_and_cached():
    so = live_sym()
    so.session_col = {1: T0 + 600, 2: T0}
    assert view._closed(so, 1, T0, 60) and view._closed(so, 1, T0 + 540, 60)
    assert not view._closed(so, 1, T0 + 600, 60)              # kolom sesi berjalan belum ditutup
    so.closed_upto[1] = T0 + 660
    assert view._closed(so, 1, T0 + 600, 60) and not view._closed(so, 1, T0 + 600, 300)
    assert not view._closed(so, 2, T0, 3600)


def test_live_and_footprint_payloads(monkeypatch):
    so = live_sym()
    _fill(so)

    async def fake_klines(sym, iv, limit):
        tf = next(t for t in C.TF_ORDER if C.TFS[t]["iv"] == iv)
        return _candles(tf, 60, T0 + 600 if tf in ("M1", "M5") else T0)
    monkeypatch.setattr(B, "klines", fake_klines)
    v = run(view.view_payload("BTCUSDT", "M1", 60, "book"))
    lv = run(view.live_payload("BTCUSDT", "M1", T0 + 540, v["row"], v["heat"]["k0"], v["heat"]["nrows"], 60, 1, "book"))
    assert [c[0] for c in lv["candles"]] == [T0 + 540, T0 + 600] and len(lv["heat"]) == 2 and len(lv["heat"][0]) == v["heat"]["nrows"]
    assert lv["book"]["k0"] == v["heat"]["k0"] and len(lv["book"]["bid"]) == v["heat"]["nrows"]
    with pytest.raises(ValueError):
        run(view.live_payload("BTCUSDT", "M1", T0, v["row"] * 0.37, 0, 10, 0, 0, "book"))
    fpd = run(view.footprint_payload("BTCUSDT", "M5", T0, T0 + 300, 1))
    cells = fpd["cells"][str(T0)]
    assert fpd["row"] == pytest.approx(so.b) and sum(r[1] for r in cells) == pytest.approx(3 * 20_000, rel=0.01)
    assert sum(r[2] for r in cells) == pytest.approx(2 * 20_000, rel=0.01)


# ------------------------------------------------------------------------------------------- model likuidasi (gaya CoinGlass)
def test_liquidation_model_levels_sweep_and_decay():
    r, k0, n = 10.0, 8_000, 4_000                      # baris 10 USDT, harga 80.000 .. 120.000
    st = LM.State(r, k0, n)
    c0 = [T0, 100_000, 100_000, 100_000, 100_000, 1_000_000.0, 600_000.0]   # 60% volume taker beli
    LM.step(st, c0, 1.0)
    new = 1_000_000 * LM.OPEN_RATIO
    for pl, ps, w in LM.liq_prices(100_000):
        if 0 <= int(pl // r) - k0 < n:                       # 3x (−33%) di luar grid tes
            assert st.long[int(pl // r) - k0] == pytest.approx(new * 0.6 * w)
        if 0 <= int(ps // r) - k0 < n:
            assert st.short[int(ps // r) - k0] == pytest.approx(new * 0.4 * w)
    levs = [lv for lv, _ in LM.TIERS]
    p100l, p100s, w100 = LM.liq_prices(100_000)[levs.index(100.0)]           # 100x: ±0,6% dari harga
    assert p100l == pytest.approx(100_000 * (1 - 0.01 + LM.MMR)) and p100s == pytest.approx(100_000 * (1 + 0.01 - LM.MMR))
    w125 = LM.TIERS[levs.index(125.0)][1]
    # candle berikut turun menembus likuidasi long 100x -> level 100x & 125x tersapu; level 50x (lebih jauh) tetap
    p50l = LM.liq_prices(100_000)[levs.index(50.0)][0]
    before = st.long.sum()
    c1 = [T0 + 60, 100_000, 100_000, p100l - 1, 99_500, 0.0, 0.0]
    ll, ls = LM.step(st, c1, 1.0)
    assert ll == pytest.approx(new * 0.6 * (w100 + w125)) and ls == 0
    assert st.long[int(p100l // r) - k0] == 0 and st.long[int(p50l // r) - k0] > 0
    assert st.long.sum() == pytest.approx(before - ll)
    # luruh: posisi ditutup sukarela seiring waktu
    s0 = st.short.sum()
    LM.step(st, [T0 + 120, 99_500, 99_500, 99_500, 99_500, 0.0, 0.0], 0.5)
    assert st.short.sum() == pytest.approx(s0 * 0.5)


def _walk(n, sec, start=100_000.0):
    out, p = [], start
    for i in range(n):
        o = p
        p = p * (1 + 0.004 * math.sin(i / 7.0) + 0.001 * ((i * 37) % 11 - 5) / 5)
        hi, lo = max(o, p) * 1.0015, min(o, p) * 0.9985
        out.append([T0 - (n - 1 - i) * sec, o, hi, lo, p, 2e6 * sec / 60, 1.1e6 * sec / 60])
    return out


def test_liquidation_model_fills_every_level_near_price():
    cs = _walk(300, 3600)
    st, cols, _ = LM.run(cs, 50.0, 1_600, 800)                # baris 50 USDT, 80.000 .. 120.000
    price = cs[-1][4]
    k = int(price // 50) - 1_600
    near_long = st.long[k - 60:k - 5]                          # ±0,3% .. 3% di bawah harga
    near_short = st.short[k + 5:k + 60]
    # hampir semua baris terisi; sebagian kecil kosong karena baru saja tersapu candle terakhir (perilaku benar)
    assert (near_long > 0).mean() > 0.75 and (near_short > 0).mean() > 0.75


def test_liquidation_model_has_no_future_leak():
    cs = _walk(400, 60)
    _, full_cols, _ = LM.run(cs, 10.0, 9_000, 2_200)
    _, part_cols, _ = LM.run(cs[:250], 10.0, 9_000, 2_200)
    for t, a in part_cols.items():
        assert np.array_equal(a, full_cols[t])            # kolom lama tidak berubah oleh candle sesudahnya


def test_liquidation_view_fills_chart_and_scales_with_tf(monkeypatch):
    so = live_sym()

    async def fake_klines(sym, iv, limit):
        tf = next(t for t in C.TF_ORDER if C.TFS[t]["iv"] == iv)
        return _walk(min(limit, 1000), C.TFS[tf]["sec"])
    monkeypatch.setattr(B, "klines", fake_klines)
    m1 = run(view.view_payload("BTCUSDT", "M1", 300))
    h4 = run(view.view_payload("BTCUSDT", "H4", 300))
    assert m1["mode"] == "liq" and len(m1["candles"]) == 300
    hm = m1["heat"]
    q = np.frombuffer(base64.b64decode(hm["q"]), dtype=np.uint8).reshape(hm["ncols"], hm["nrows"])
    assert (q.max(axis=1) > 0).all()                       # SETIAP candle punya kolom heatmap (chart penuh)
    o1, o4 = m1["overview"], h4["overview"]
    assert o4["liq_total"] > o1["liq_total"] and h4["row"] >= m1["row"] and o4["liq_band_pct"] >= o1["liq_band_pct"]
    for side, key in (("above", "short"), ("below", "long")):
        for lv in m1["levels"][side]:
            assert lv["side"] == key and (lv["dist"] > 0) == (side == "above")
    assert len(m1["book"]["bid"]) == hm["nrows"] and m1["book"]["k0"] == hm["k0"]
    assert o1["liq24_hours"] > 0 and o1["liq24"] >= o1["liq24_long"]
    lv = run(view.live_payload("BTCUSDT", "M1", m1["candles"][-1][0], m1["row"], hm["k0"], hm["nrows"], 300))
    assert lv["mode"] == "liq" and len(lv["heat"]) == 1 and len(lv["heat"][0]) == hm["nrows"]
    with pytest.raises(ValueError):
        run(view.view_payload("BTCUSDT", "M1", 300, "xyz"))


# ------------------------------------------------------------------------------------------- kontrol pair & pemantauan
def test_only_selected_pairs_are_monitored(monkeypatch):
    assert control.selected() == C.CATALOG_SYMS
    control.update(pairs=["xautusdt", "BTCUSDT"])
    assert control.selected() == ["BTCUSDT", "XAUTUSDT"]               # urutan katalog, simbol kanonik
    m = engine.Manager()
    m.sync_pairs(control.selected())
    st = m.streams()
    assert {s.split("@")[0] for s in st} == {"btcusdt", "xautusdt"}
    assert len(st) == 2 * (2 + len(C.TF_ORDER))
    assert m.get("ETHUSDT") is None
    with pytest.raises(ValueError):
        view.pair("ETHUSDT")
    with pytest.raises(ValueError):
        control.update(pairs=["DOGEUSDT"])
    # pesan stream untuk pair yang tidak dipantau diabaikan; yang dipantau diteruskan ke bukunya
    so = m.get("BTCUSDT")
    so.b, so.tick = 10.0, 0.01
    m.route(json.dumps({"stream": "ethusdt@aggTrade", "data": {"e": "aggTrade", "s": "ETHUSDT", "p": "1", "q": "1", "T": 1, "m": False}}))
    m.route(json.dumps({"stream": "btcusdt@aggTrade", "data": {"e": "aggTrade", "s": "BTCUSDT", "p": "100000", "q": "0.01", "T": (T0 + 5) * 1000, "m": False}}))
    m.route(json.dumps({"stream": "btcusdt@kline_1m", "data": {"e": "kline", "s": "BTCUSDT", "k": {"t": T0 * 1000, "i": "1m", "o": "1", "h": "2", "l": "0.5", "c": "1.5", "q": "9", "Q": "4", "s": "BTCUSDT"}}}))
    assert so.price == 100_000 and so.msgs == 1 and so.kl["M1"].ws_at > 0
    assert m.get("ETHUSDT") is None


@pytest.fixture()
def keyed(monkeypatch):
    mockworld.install(monkeypatch)
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ADMIN_KEY", "adm-key")
    monkeypatch.setattr(config, "USER_KEY", "usr-key")
    monkeypatch.setattr(config, "ACCESS_KEY", "")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    auth._cache.clear()

    async def fake_klines(sym, iv, limit):
        return _candles("M5", 60, T0)

    async def fake_t24(syms):
        return {s: dict(price=1.0, pct=0.5, vol=1.0) for s in syms}
    monkeypatch.setattr(B, "klines", fake_klines)
    monkeypatch.setattr(B, "ticker24", fake_t24)
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app, follow_redirects=False) as c:
        yield c


def test_roles_admin_picks_pairs_user_reads_only(keyed):
    c = keyed
    assert c.get("/api/heatmap/pairs").status_code == 401
    c.get("/?key=usr-key")
    r = c.get("/api/heatmap/pairs")
    assert r.status_code == 200 and [p["sym"] for p in r.json()["pairs"]] == C.CATALOG_SYMS
    assert c.get("/api/heatmap/control").status_code == 403
    assert c.post("/api/heatmap/control", json={"pairs": ["BTCUSDT"]}).status_code == 403
    assert control.selected() == C.CATALOG_SYMS
    v = c.get("/api/heatmap/view", params={"symbol": "ETHUSDT", "tf": "M5", "bars": 60}).json()
    assert "error" not in v and len(v["candles"]) == 60 and v["symbol"] == "ETHUSDT"
    c.cookies.clear()
    c.get("/?key=adm-key")
    assert c.get("/api/heatmap/control").json()["catalog"][5]["sym"] == "XAUTUSDT"
    assert c.post("/api/heatmap/control", json={"pairs": ["DOGEUSDT"]}).status_code == 422
    assert c.post("/api/heatmap/control", json={"pairs": ["BTCUSDT"], "x": 1}).status_code == 422
    r = c.post("/api/heatmap/control", json={"pairs": ["BTCUSDT", "SOLUSDT"]})
    assert r.status_code == 200 and r.json()["state"]["pairs"] == ["BTCUSDT", "SOLUSDT"]
    c.cookies.clear()
    c.get("/?key=usr-key")
    assert [p["sym"] for p in c.get("/api/heatmap/pairs").json()["pairs"]] == ["BTCUSDT", "SOLUSDT"]
    e = c.get("/api/heatmap/view", params={"symbol": "ETHUSDT", "tf": "M5"}).json()
    assert "tidak dipantau" in e["error"]
    assert "tidak dipantau" in c.get("/api/heatmap/footprint", params={"symbol": "ETHUSDT", "tf": "M5", "t0": T0, "t1": T0}).json()["error"]
    assert "timeframe" in c.get("/api/heatmap/view", params={"symbol": "BTCUSDT", "tf": "M7"}).json()["error"]


def test_menu_registered_in_web():
    import pathlib
    web = pathlib.Path(config.WEB_DIR)
    assert "v_heatmap.js" in (web / "index.html").read_text()
    assert "['heatmap','▩','HEATMAP & FOOTPRINT']" in (web / "core.js").read_text()
    js = (web / "v_heatmap.js").read_text()
    assert "localStorage" in js and "hm.ind.v1" in js                 # indikator disimpan per browser (per user)
    assert "PILIH PAIR" in js and "T.role==='admin'" in js
    assert "hf-meter" in js and "sens:" in js                           # meter sensitivitas heatmap (per browser)
    lv = js[js.index("function drawLevels"):js.index("function drawCandles")]
    assert "fillText" not in lv                                       # key level tanpa angka di kanan chart
