"""Tema baru & alat terminal: font lokal (boleh dimuat halaman login), halaman login, berkas web, dan pembersihan
sisa item Polymarket dari feed berita & snapshot lama."""
import json
import pathlib
import time
import zlib

import pytest

from terminal import auth, config, snapshots as S, store
from terminal.providers import news

WEB = pathlib.Path(config.WEB_DIR)


@pytest.fixture()
def guarded(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ACCESS_KEY", "rahasia-123")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    auth._cache.clear()
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app, follow_redirects=False) as c:
        yield c


def test_fonts_are_bundled_and_public_but_nothing_else(guarded):
    for f in ("plex-cond-400", "plex-cond-500", "plex-cond-600", "plex-cond-700", "plex-mono-400", "plex-mono-500", "plex-mono-600"):
        assert (WEB / "vendor" / "fonts" / f"{f}.woff2").stat().st_size > 5000
        r = guarded.get(f"/vendor/fonts/{f}.woff2")
        assert r.status_code == 200 and r.headers["content-type"].startswith("font/woff2")
    assert (WEB / "vendor" / "fonts" / "OFL.txt").exists()                     # lisensi font ikut dibundel
    assert guarded.get("/vendor/fonts/OFL.txt").status_code == 401           # hanya .woff2 yang terbuka
    assert guarded.get("/vendor/leaflet.js").status_code == 401
    assert guarded.get("/style.css").status_code == 401
    assert guarded.get("/vendor/fonts/../core.js.woff2").status_code in (401, 404)


def test_login_page_uses_theme_and_escapes_name(monkeypatch):
    monkeypatch.setattr(config, "TERMINAL_NAME", "Desk <A&B>")
    page = auth.login_page(error=True)
    assert "Kunci salah" in page and "Kunci akses" in page and 'name="key"' in page
    assert "Desk &lt;A&amp;B&gt;" in page and "DESK &lt;A&amp;B&gt;" in page and "<A&B>" not in page
    assert "/vendor/fonts/plex-cond-600.woff2" in page and "#f0a92e" in page


def test_index_loads_tools_and_theme_files():
    html = (WEB / "index.html").read_text(encoding="utf-8")
    assert html.index("v_tools.js") < html.index("boot.js")                  # boot.js memakai ikon & grup dari v_tools.js
    assert 'id="tbtools"' in html and 'id="eyebrow"' in html and "plex-mono-400.woff2" in html
    js = (WEB / "v_tools.js").read_text(encoding="utf-8")
    for name in ("T.openPalette", "T.openWatch", "T.openCalc", "T.posSize", "T.ICONS", "T.GROUPS"):
        assert name in js
    css = (WEB / "style.css").read_text(encoding="utf-8")
    assert "THEME: INSTRUMENT PANEL" in css and '@font-face{font-family:"IBM Plex Mono"' in css
    core = (WEB / "core.js").read_text(encoding="utf-8")
    assert "T.PALETTE" in core and "#3b82f6','#22c55e" not in core


def test_every_menu_has_an_icon_and_a_group():
    js = (WEB / "v_tools.js").read_text(encoding="utf-8")
    core = (WEB / "core.js").read_text(encoding="utf-8")
    ids = [m.split("'")[1] for m in core.split("T.modules=[", 1)[1].split("];", 1)[0].split("[")[1:]]
    assert len(ids) >= 16
    groups = js.split("T.GROUPS=", 1)[1].split(";", 1)[0]
    for i in ids:
        assert f"  {i}:S(" in js, f"ikon untuk menu {i}"
        assert f"'{i}'" in groups, f"grup untuk menu {i}"


def test_retired_polymarket_rows_are_purged_from_news(monkeypatch):
    now = int(time.time())
    payload = json.dumps(dict(sent=0, prio="LOW", flash=False, t1=False, tags=[]))
    store.executemany("INSERT OR REPLACE INTO news(id,ts,source,title,link,payload) VALUES(?,?,?,?,?,?)",
                      [("pm-1", now, "Polymarket", "Polymarket: Will X?", "https://polymarket.com/event/x", payload),
                       ("rt-1", now, "Reuters", "Gold climbs", "https://reuters.com/x", payload)])
    monkeypatch.setattr(news, "_items", {})
    try:
        news.load_cached()
        assert "rt-1" in news._items and "pm-1" not in news._items
        assert not store.query("SELECT id FROM news WHERE source='Polymarket'")
    finally:                                   # jangan tinggalkan baris uji untuk tes lain (geo, feed)
        store.execute("DELETE FROM news WHERE id IN ('pm-1','rt-1')")


def test_snapshots_with_retired_items_are_dropped_and_recomputed(monkeypatch):
    ep = S.ENDPOINTS.get("intel/feed") or next(iter(S.ENDPOINTS.values()))
    old = S.encode({"items": [{"source": "Polymarket", "title": "Polymarket: Will X?"}]})
    good = S.encode({"items": [{"source": "Reuters", "title": "Gold climbs"}]})
    k1, k2 = S.key_of(ep.path, {"a": "1"}), S.key_of(ep.path, {"a": "2"})
    now = time.time()
    store.snap_put(k1, ep.path, json.dumps({"a": "1"}), zlib.compress(old), now, "h1", 5, 1)
    store.snap_put(k2, ep.path, json.dumps({"a": "2"}), zlib.compress(good), now, "h2", 5, 1)
    monkeypatch.setattr(S, "_mem", {})
    monkeypatch.setattr(S, "JOBS", {})
    try:
        S.load()
        assert k2 in S._mem and k1 not in S._mem                 # yang lama tidak dilayani lagi
        assert k1 in S.JOBS                                      # tetapi tetap terdaftar -> langsung dihitung ulang
        assert store.snap_get(k1) is None and store.snap_get(k2) is not None
        assert S._due(time.time())[0].key == k1
    finally:
        store.snap_delete(k1)
        store.snap_delete(k2)


# ------------------------------------------------------------------ CENTRAL BANK: tampilan negara setara
CBTA_CSV = """FREQ,REF_AREA,COMP_METHOD,UNIT_MEASURE,CURRENCY,TRANSFORMATION,UNIT_MULT,TIME_PERIOD,OBS_VALUE
M,GB,B,XDC,GBP,N,9,2026-06,799.187
M,GB,B,XDC,GBP,N,9,2026-07,805.29
M,GB,B,XDC,GBP,B,9,2026-07,700.0
M,GB,B,USD,USD,B,9,2026-07,1080.8
M,XM,B,XDC,EUR,N,9,2026-07,5941.248
M,CN,B,XDC,CNY,B,9,2026-06,49433.5
"""


def test_bis_central_bank_assets_parse_local_currency_level():
    from terminal.providers import rates
    out = rates.parse_cbta(CBTA_CSV)
    assert out["GB"] == ("GBP", [("2026-06-01", 799.187e9), ("2026-07-01", 805.29e9)])   # XDC, tanpa penyesuaian (N), miliar
    assert out["XM"][0] == "EUR" and out["CN"] == ("CNY", [("2026-06-01", 49433.5e9)])     # hanya B -> dipakai


def test_spread_uses_same_rule_for_every_country():
    from terminal.providers import rates
    h = {"2Y": [("d1", 3.0), ("d2", 3.1)], "10Y": [("d1", 4.0), ("d2", 4.3)], "5Y": [("d1", 3.5), ("d2", 3.6)]}
    assert rates.spread_pair(h) == ("10Y", "2Y") and rates.spread_label(("10Y", "2Y")) == "2s10s"
    gb = {"5Y": [("d1", 4.0), ("d2", 4.1)], "10Y": [("d1", 4.4), ("d2", 4.3)], "20Y": [("d1", 5), ("d2", 5)]}
    assert rates.spread_pair(gb) == ("10Y", "5Y") and rates.spread_label(("10Y", "5Y")) == "5Y–10Y"
    nz = {"3M": [("m1", 3.0), ("m2", 3.25), ("m3", 3.3)], "10Y": [("m1", 4.5), ("m2", 5.01)]}
    assert rates.spread_series(nz, rates.spread_pair(nz)) == [("m1", 150.0), ("m2", 176.0)]   # hanya tanggal yang sama (tanpa isi-ke-depan)
    assert rates.spread_pair({"3M": [("m1", 1.5), ("m2", 1.51)]}) is None


def test_fred_series_ids_and_honest_client_header():
    from terminal.providers import yields, fred
    assert all(len(v) == 2 for v in yields.OECD3.values())                 # IRLTLT01NZM156N, bukan IRLTLT01NZLM156N
    assert "CN" not in yields.OECD3 and "ID" not in yields.OECD3           # seri 10Y OECD tidak ada -> jangan bebani FRED
    assert set(yields.SHORT3M) == {"CN", "ID", "NZ"}
    assert "compatible" in fred.HEADERS["User-Agent"] and "Chrome" not in fred.HEADERS["User-Agent"]
    for cc in ("CN", "ID", "NZ"):
        assert any(n.startswith("FRED/OECD 3M") for n, _ in yields.CHAIN[cc])


async def test_country_view_has_same_fields_for_every_country(monkeypatch):
    import mockworld
    from terminal.providers import rates
    from terminal.universe import COUNTRY_ORDER
    mockworld.install(monkeypatch)
    keys = None
    for cc in COUNTRY_ORDER:
        d = await rates.country(cc)
        k = set(d)
        assert {"hist", "spread_hist", "spread_label", "short_tenor", "y_short", "balance", "policy_hist", "curve"} <= k
        keys = k if keys is None else keys
        assert k == keys, cc                                                  # struktur sama persis untuk semua negara
        if cc != "NZ":
            assert d["balance"]["series"], cc                                 # neraca: semua negara (tiruan: kecuali NZ)
        else:
            assert d["balance"]["reason"]


async def test_heavy_jobs_wait_only_while_preload_actually_runs(monkeypatch):
    import time as _t
    from terminal import preload
    from terminal.api import state
    pre = dict(state["preload"])
    try:
        monkeypatch.setitem(state, "started", _t.time() - 60)
        state["preload"].update(phase="idle")
        t0 = _t.time()
        assert await preload.wait_done(limit=30, grace=30) == "no-preload" and _t.time() - t0 < 1   # tanpa preload: tidak menunggu 10 mnt
        state["preload"].update(phase="ready")
        assert await preload.wait_done(limit=30) == "ready"
        state["preload"].update(phase="phase1")
        assert await preload.wait_done(limit=0.2) == "timeout"                                      # preload berjalan: ditunggu
    finally:
        state["preload"].clear(); state["preload"].update(pre)


# ------------------------------------------------------------------ kecepatan lewat tunnel
def test_index_links_versioned_assets_and_embeds_role(guarded):
    r = guarded.get("/?key=rahasia-123")
    assert r.status_code == 303
    page = guarded.get("/", cookies=dict(r.cookies))
    html = page.text
    assert page.status_code == 200 and page.headers["cache-control"] == "no-cache"
    import re as _re
    vers = set(_re.findall(r'(?:src|href)="[^"]+\.(?:js|css)\?v=([0-9a-f]{10})"', html))
    assert len(vers) == 1                                                    # semua js/css bertanda versi yang sama
    assert 'window.__ROLE="admin"' in html and html.index("__ROLE") < html.index("core.js")
    assert 'href="vendor/fonts/plex-cond-500.woff2"' in html                  # font tanpa ?v (CSS memanggilnya tanpa versi)
    v = vers.pop()
    a = guarded.get(f"/core.js?v={v}", cookies=dict(r.cookies))
    assert a.status_code == 200 and "immutable" in a.headers["cache-control"]
    assert guarded.get("/core.js", cookies=dict(r.cookies)).headers["cache-control"] == "no-cache"
    assert "immutable" in guarded.get("/vendor/fonts/plex-mono-400.woff2").headers["cache-control"]


def test_asset_version_changes_when_a_file_changes(tmp_path, monkeypatch):
    from terminal import server
    (tmp_path / "index.html").write_text('<script src="core.js"></script>')
    (tmp_path / "core.js").write_text("a")
    monkeypatch.setattr(config, "WEB_DIR", tmp_path)
    server._index_cache.clear()
    v1 = server._asset_version()
    import os as _os, time as _t
    (tmp_path / "core.js").write_text("ab"); _os.utime(tmp_path / "core.js", (_t.time() + 5, _t.time() + 5))
    assert server._asset_version() != v1
    assert "core.js?v=" + server._asset_version() in server.render_index("user")


# ------------------------------------------------------------------ nilai "—": cadangan data
def test_yahoo_missing_quotes_use_fred_for_us_yields_and_last_good_for_others(monkeypatch):
    import asyncio
    from terminal.providers import yahoo, fred
    from terminal import store as st
    async def fake_series(sid, start=None):
        assert sid == "DGS10"
        return [("2026-11-20", 4.10), ("2026-11-21", 4.15)]
    monkeypatch.setattr(fred, "series", fake_series)
    monkeypatch.setattr(yahoo, "_last", {"EURUSD=X": dict(price=1.08, pct=0.1, _at=__import__("time").time() - 3600),
                                         "OLD=X": dict(price=9.0, _at=__import__("time").time() - 30 * 86400)})
    res = {}
    asyncio.run(yahoo._fill_missing(res, ["^TNX", "EURUSD=X", "OLD=X", "NONE"]))
    assert res["^TNX"]["price"] == 4.15 and res["^TNX"]["src"] == "FRED" and round(res["^TNX"]["chg"], 2) == 0.05
    assert res["EURUSD=X"]["price"] == 1.08 and res["EURUSD=X"]["stale"] is True and "_at" not in res["EURUSD=X"]
    assert "OLD=X" not in res and "NONE" not in res                       # terlalu lama / tidak pernah ada: tetap kosong (jujur)


def test_overview_rows_give_short_tenor_and_same_spread_rule(monkeypatch):
    import asyncio, mockworld
    from terminal.providers import rates
    mockworld.install(monkeypatch)
    ov = asyncio.run(rates.overview())
    by = {r["cc"]: r for r in ov["rows"]}
    assert by["US"]["short_tenor"] == "2Y" and by["US"]["curve_label"] == "2s10s"
    assert by["ID"]["y2"] is None and by["ID"]["short_tenor"] not in (None, "2Y") and by["ID"]["curve"] is not None   # mock ID tanpa 2Y
    assert all(r["cds"] is None for r in ov["rows"])                       # CDS dimatikan (sumber kini JavaScript)


def test_real_yield_chains_skip_sources_that_always_fail():
    import inspect
    from terminal.providers import yields
    src = inspect.getsource(yields)
    chain = src[src.index("CHAIN = {"):src.index("}", src.index("CHAIN = {"))]
    assert "ad_wgb" not in chain                       # halaman WGB kini JavaScript: tidak diminta lagi tiap pembaruan
