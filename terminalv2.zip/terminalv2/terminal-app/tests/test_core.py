import json
import time
import numpy as np
import pandas as pd
import pytest

from terminal import auth, config
from terminal.analytics import sentiment as S, quant, regime as R, catalyst
from terminal.providers import cftc, news, geo, ais, rates, macro, yahoo
from terminal.tunnel import URL_RE


def test_tunnel_regex():
    line = "2026-11-03T10:00:00Z INF |  https://quiet-river-abc-123.trycloudflare.com  |"
    assert URL_RE.search(line).group(0) == "https://quiet-river-abc-123.trycloudflare.com"


def test_cftc_normalise():
    row = {"report_date_as_yyyy_mm_dd": "2026-10-27T00:00:00.000", "open_interest_all": "1000", "lev_money_positions_long": "300", "lev_money_positions_short": "100",
           "change_in_lev_money_long": "5", "pct_of_oi_lev_money_long": "30", "traders_lev_money_long_all": "9", "asset_mgr_positions_long": "200", "asset_mgr_positions_short": "50",
           "dealer_positions_long_all": "10", "dealer_positions_short_all": "20"}
    n = cftc._norm("tff", row)
    assert n["lev_net"] == 200 and n["asset_net"] == 150 and n["dealer_net"] == -10 and n["date"] == "2026-10-27"
    d = cftc._norm("disagg", {"m_money_positions_long_all": "500", "m_money_positions_short_all": "100", "swap_positions_long_all": "3", "swap__positions_short_all": "30", "swap_positions_spread_all": "99"})
    assert d["mm_net"] == 400 and d["swap_net"] == -27


def test_sentiment():
    assert S.sentiment_label("Bitcoin surges to record high") == "STRONG BULL"
    assert S.sentiment_label("Oil slides as talks progress") == "BEAR"
    assert S.priority("Missile attack kills 10") == "CRIT"
    assert S.priority("Fed signals rate cut") == "HIGH"
    assert "CRYPTO" in S.categories("Bitcoin ETF inflow")
    assert S.is_flash("BREAKING: something happened")


def test_news_parse_and_board(monkeypatch):
    from email.utils import formatdate
    pub = formatdate(time.time() - 3600, usegmt=True)  # tanggal dinamis: parser membuang berita > 3 hari
    xml = f"""<?xml version="1.0"?><rss version="2.0"><channel><item><title>Oil prices tumble as OPEC output rises - Reuters</title><link>http://x/1</link><pubDate>{pub}</pubDate></item></channel></rss>"""
    items = news._parse("Google: Oil", xml, ["COMMODITIES"])
    assert items and items[0]["source"] == "Reuters" and items[0]["title"].startswith("Oil prices tumble")
    now = time.time()
    news._items.clear()
    it = news._enrich(dict(title="Oil prices tumble as OPEC output rises", source="Reuters", link="#", ts=int(now) - 30, summary="", hints=["COMMODITIES"], feed="Google: Oil"))
    news._items[it["id"]] = it
    b = news.board()
    assert any(i["id"] == it["id"] for i in b["sections"]["COMMODITIES"]["items"])
    assert b["stats"]["articles"] == 1
    cats = catalyst.build()
    assert cats and cats[0]["id"] == "oil_supply"
    g = catalyst.graph(cats)
    assert g["nodes"] and g["links"]
    news._items.clear()


def test_geo_locate_and_events():
    assert geo.locate("Israel strikes in Gaza")[0] == "gaza" or geo.locate("Israel strikes in Gaza")[0] == "israel"
    assert geo.classify("Protesters riot in Paris") == "CIVIL UNREST"
    news._items.clear()
    it = news._enrich(dict(title="Israeli airstrike in Gaza kills 12", source="BBC", link="#", ts=int(time.time()), summary="", hints=["MIDDLE EAST"], feed="BBC"))
    news._items[it["id"]] = it
    ev = geo.events()
    assert ev and ev[0]["sev"] == "CRITICAL" and ev[0]["cat"] == "ARMED CONFLICT"
    news._items.clear()


def test_ais_handlers():
    ais._v.clear()
    ais._handle({"MessageType": "PositionReport", "MetaData": {"MMSI": 1, "ShipName": "X "}, "Message": {"PositionReport": {"Latitude": 1.2, "Longitude": 103.5, "Cog": 90, "Sog": 10, "TrueHeading": 511}}})
    ais._handle({"MessageType": "ShipStaticData", "MetaData": {"MMSI": 1}, "Message": {"ShipStaticData": {"Type": 84, "Name": "TANKER ONE", "Destination": "SG"}}})
    s = ais.snapshot((0, 100, 5, 110))
    assert s and s[0][4] == "tanker" and s[0][5] == "TANKER ONE"
    assert ais.snapshot((50, 0, 60, 10)) == []
    ais._v.clear()


def _df(n=700, drift=0.0004):
    rng = np.random.default_rng(1)
    c = 100 * np.exp(np.cumsum(rng.normal(drift, 0.01, n)))
    idx = pd.bdate_range("2023-01-02", periods=n)
    return pd.DataFrame(dict(o=c, h=c * 1.005, l=c * 0.995, c=c, v=1000.0), index=idx)


def test_quant_outputs():
    df = _df()
    t = quant.technical(df)
    assert t["regime"] in ("BULLISH", "BEARISH", "NEUTRAL") and len(t["dates"]) == 120 and t["levels"]
    s = quant.statistical(df)
    assert s["hist"]["counts"] and s["var95"] < 0 and 0 < s["hurst"] < 1.5
    v = quant.volatility(df)
    assert v["current"] > 0 and len(v["term"]) == 4
    se = quant.seasonality(df)
    assert len(se["months"]) == 12 and len(se["dow"]) == 5 and se["best"]


def test_regime_classify_and_alignment():
    assert R.classify(.3, .5) == "REFLATION" and R.classify(.3, -.5) == "EXPANSION"
    assert R.classify(-.3, .5) == "STAGFLATION" and R.classify(-.3, -.5) == "DEFLATION"
    z, mean, sd = R.zscore_last([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert round(mean, 1) == 5.5 and z > 1
    assert R.correlation([1, 2, 3, 4, 5], [2, 4, 6, 8, 10]) == pytest.approx(1)
    assert R.alignment_label(None, 0, 0) == "INSUFFICIENT DATA"


def test_macro_transform():
    rows = [("2024-%02d-01" % i, 100 + i) for i in range(1, 13)] + [("2025-%02d-01" % i, 112 + i * 1.2) for i in range(1, 13)]
    assert macro._period(rows) == 12
    yoy = macro.transform(rows, "yoy")
    assert yoy[-1][1] == pytest.approx((112 + 12 * 1.2) / 112 - 1 * 1, rel=1) or yoy[-1][1] > 10
    assert macro.transform(rows, "diff")[-1][1] == pytest.approx(1.2)


def test_rates_decisions():
    d = rates.decisions([("2024-01-01", 5.0), ("2024-02-01", 5.0), ("2024-03-01", 4.75)])
    assert len(d) == 2 and d[-1]["change"] == pytest.approx(-0.25)


def test_yahoo_futures_symbols():
    syms = yahoo.futures_symbols("CL", "NYM", 3)
    assert len(syms) == 3 and syms[0][1].startswith("CL") and syms[0][1].endswith(".NYM")


def test_server_routes_offline(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", True)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", True)
    from fastapi.testclient import TestClient
    from terminal import server
    c = TestClient(server.app)
    assert c.get("/healthz").json()["ok"]
    assert c.get("/").status_code == 200
    for p in ["/api/cot/meta", "/api/status", "/api/quant/assets", "/api/retail/table", "/api/geo/overview", "/api/intel/catalysts", "/api/intel/feed", "/api/search?q=gold"]:
        r = c.get(p)
        assert r.status_code == 200 and "error" not in r.json(), p


def test_digitraffic_parse():
    ais._v.clear()
    loc = {"features": [{"mmsi": 230123000, "geometry": {"coordinates": [24.95, 60.15]}, "properties": {"mmsi": 230123000, "sog": 12.3, "cog": 88.0, "heading": 511, "timestampExternal": int(time.time() * 1000)}}]}
    meta = {230123000: {"name": "FINNLADY ", "shipType": 60, "destination": "TALLINN"}}
    assert ais._digi_apply(loc, meta) == 1
    s = ais.snapshot()
    assert s[0][4] == "passenger" and s[0][5] == "FINNLADY" and s[0][2] == 88
    old = {"features": [{"mmsi": 1, "geometry": {"coordinates": [1, 1]}, "properties": {"timestampExternal": 1000}}]}
    assert ais._digi_apply(old, {}) == 0
    st = ais.status()
    assert st["enabled"] and st["coverage"] == "BALTIC / N. EUROPE"
    ais._v.clear()


def test_portwatch_stats():
    from terminal.providers import portwatch as P
    rows = [{"date": "2026-10-%02d" % d, "total": 50 + d, "tanker": 10, "cargo": 40, "name": "Strait of Hormuz"} for d in range(1, 31)]
    st = P._stats(rows)
    assert st["latest"] == 80 and st["chg_pct"] > 0
    summ = [dict(st, portid="a", name="Strait of Hormuz", lat=26, lon=56), dict(st, portid="b", name="Suez Canal", lat=30, lon=32), dict(st, portid="c", name="Bab el-Mandeb Strait", lat=12, lon=43)]
    m = P.for_chokepoints(summ)
    assert m["hormuz"]["transits"] == 80 and m["redsea"]["transits"] == 160
    assert P._date(1730000000000) == "2024-10-27"


@pytest.mark.asyncio
async def test_tradingview_calendar_parse(monkeypatch):
    from terminal.providers import calendar as C
    sample = {"status": "ok", "result": [{"title": "ISM Manufacturing PMI", "country": "US", "currency": "USD", "importance": 1, "actual": 54.2, "forecast": 52.0, "previous": 51.5, "unit": "", "scale": "", "date": "2026-11-02T15:00:00.000Z"},
                                         {"title": "Retail Sales", "country": "ID", "currency": "IDR", "importance": -1, "actual": None, "forecast": None, "previous": 3.2, "unit": "%", "scale": "", "date": "2026-11-03T04:00:00.000Z"}]}

    async def fake(url, **kw):
        assert kw["headers"]["Origin"] == "https://www.tradingview.com" and "ID" in kw["params"]["countries"]
        return sample

    monkeypatch.setattr(C, "get_json", fake)
    from terminal.http import clear_cache
    clear_cache()
    ev = await C.tv_calendar()
    assert ev[0]["impact"] == "HIGH" and ev[0]["actual"] == 54.2 and C.cc_of(ev[0]) == "US"
    assert ev[1]["impact"] == "LOW" and ev[1]["actual"] is None and ev[1]["unit"] == "%"


def test_no_paid_services_configured():
    import pathlib
    root = pathlib.Path(__file__).resolve().parent.parent
    banned = ["TRADINGECONOMICS", "ANTHROPIC_API_KEY", "api.anthropic.com", "cartocdn", "tile.openstreetmap", "api.tradingeconomics.com"]
    for f in list((root / "terminal").rglob("*.py")) + list((root / "terminal" / "web").glob("*.js")) + [root / ".env.example"]:
        text = f.read_text(errors="ignore")
        for b in banned:
            assert b not in text, f"{b} ditemukan di {f.name}"


def test_world_map_is_local():
    import pathlib
    root = pathlib.Path(__file__).resolve().parent.parent / "terminal" / "web"
    g = json.loads((root / "vendor" / "world.geojson").read_text())
    assert len(g["features"]) > 200
    core = (root / "core.js").read_text()
    assert "vendor/world.geojson" in core and "tileLayer" not in core


def test_llm_disabled_by_default():
    from terminal import llm
    assert llm.enabled() in (True, False)
