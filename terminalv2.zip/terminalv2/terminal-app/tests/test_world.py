"""Pengujian perbaikan: cache, parser sumber gratis, fallback, per-negara, geo, Ollama, installer. Tanpa jaringan."""
import asyncio
import http.server
import json
import sys
import threading
import time
import pytest

import mockworld
from terminal import config, http as H, auth
from terminal.universe import COUNTRY_ORDER

ROOT = __import__("pathlib").Path(__file__).resolve().parent.parent


# ------------------------------------------------------------------ cache (akar bug #3: tabrakan kunci antar modul)
async def test_cache_key_includes_module():
    calls = []

    @H.cached(60)
    async def overview():
        calls.append("a")
        return {"from": "a"}

    ns = {"__name__": "other.module"}
    exec("async def overview():\n    return {'from': 'b'}", ns)
    b = H.cached(60)(ns["overview"])
    H.clear_cache()
    assert (await overview())["from"] == "a"
    assert (await b())["from"] == "b"


async def test_cache_swr_and_error_fallback():
    state = {"n": 0, "fail": False}

    @H.cached(0.05, stale_ok=60)
    async def f():
        state["n"] += 1
        if state["fail"]:
            raise RuntimeError("down")
        return state["n"]

    H.clear_cache()
    assert await f() == 1
    await asyncio.sleep(0.1)
    state["fail"] = True
    assert await f() == 1  # gagal -> tetap data lama, bukan error/kosong
    state["fail"] = False
    await asyncio.sleep(0.2)
    await f()
    await asyncio.sleep(0.1)
    assert await f() >= 2


async def test_cache_persist_survives_memory_clear():
    n = {"c": 0}

    @H.cached(3600, persist=True)
    async def g():
        n["c"] += 1
        return {"v": [1, 2, 3]}

    H.clear_cache()
    await g()
    await asyncio.gather(*list(H._bg))   # tunggu tulis ke disk selesai (sebelumnya bergantung pada keberuntungan waktu)
    H._cache.clear()
    assert (await g())["v"] == [1, 2, 3] and n["c"] == 1


async def test_rev_bumps_only_on_change():
    box = {"v": 1}

    @H.cached(0.01)
    async def h():
        return box["v"]

    H.clear_cache()
    await h()
    r0 = H.rev()
    await asyncio.sleep(0.05)
    await h()
    await asyncio.sleep(0.1)
    same = H.rev()
    box["v"] = 2
    await asyncio.sleep(0.05)
    await h()
    await asyncio.sleep(0.1)
    await h()
    assert same == r0 and H.rev() > same


# ------------------------------------------------------------------ parser sumber gratis (fixture bentuk resmi)
def test_tenor_of():
    from terminal.providers.yields import tenor_of
    cases = {"2 Yr": "2Y", "10 YR": "10Y", "SR_10Y": "10Y", "6 Mo": "6M", "3 Months": "3M", "1 Month": "1M", "30 Year": "30Y", "10J": "10Y", "Date": None, "abc": None}
    for k, v in cases.items():
        assert tenor_of(k) == v, k


def test_parse_treasury():
    from terminal.providers.yields import parse_treasury_csv
    csv_ = 'Date,"1 Mo","3 Mo","2 Yr","10 Yr","30 Yr"\n11/03/2026,4.1,4.0,3.8,4.2,4.7\n11/02/2026,4.1,4.0,3.7,4.1,4.6\n'
    r = parse_treasury_csv(csv_)
    assert r["10Y"][-1] == ("2026-11-03", 4.2) and r["2Y"][0][0] == "2026-11-02" and "1M" in r


def test_parse_ecb():
    from terminal.providers.yields import parse_ecb_csv
    r = parse_ecb_csv("KEY,TIME_PERIOD,OBS_VALUE\nx,2026-11-02,2.4\nx,2026-11-03,2.5\nx,2026-11-04,\n")
    assert r == [("2026-11-02", 2.4), ("2026-11-03", 2.5)]


def test_parse_mof():
    from terminal.providers.yields import parse_mof_csv
    r = parse_mof_csv("Interest Rate\n(Unit : %)\nDate,1Y,2Y,10Y,30Y\n2026/11/3,0.5,0.7,1.6,2.9\n2026/11/4,0.5,0.8,1.7,3.0\n")
    assert r["10Y"][-1] == ("2026-11-04", 1.7) and r["2Y"][0][1] == 0.7
    with pytest.raises(ValueError):
        parse_mof_csv("nothing here")


def test_parse_boc():
    from terminal.providers.yields import parse_boc
    j = {"observations": [{"d": "2026-11-03", "BD.CDN.2YR.DQ.YLD": {"v": "3.1"}, "BD.CDN.10YR.DQ.YLD": {"v": "3.4"}, "BD.CDN.LONG.DQ.YLD": {"v": "3.6"}}]}
    r = parse_boc(j)
    assert r["2Y"][0][1] == 3.1 and r["10Y"][0][1] == 3.4 and r["30Y"][0][1] == 3.6


def test_parse_rba_picks_by_title_not_column_position():
    from terminal.providers.yields import parse_rba_csv
    txt = ("F2 CAPITAL MARKET YIELDS\nTitle,Australian Government 2 year bond,Australian Government 10 year bond,Australian Government 10 year bond index\n"
           "Units,Per cent,Per cent,Index\n03-Nov-2026,3.9,4.5,100\n04-Nov-2026,3.95,4.55,101\n")
    r = parse_rba_csv(txt)
    assert r["10Y"][-1] == ("2026-11-04", 4.55) and r["2Y"][-1][1] == 3.95 and len(r) == 2


def test_parse_snb():
    from terminal.providers.yields import parse_snb_csv
    txt = '"CubeId";"x"\n\n"Date";"D0";"Value"\n"2026-11-03";"10J";"0.5"\n"2026-11-03";"2J";"0.1"\n'
    r = parse_snb_csv(txt)
    assert r["10Y"][0][1] == 0.5 and r["2Y"][0][1] == 0.1


def test_parse_wgb():
    from terminal.providers.yields import parse_wgb
    html = "<table><tr><td>2 years</td><td>3.10%</td></tr><tr><td>10 years</td><td>4.25%</td></tr><tr><td>Other</td><td>9%</td></tr></table>"
    assert parse_wgb(html) == {"2Y": 3.10, "10Y": 4.25}


def test_parse_worldbank():
    from terminal.providers import worldbank
    j = [{"page": 1}, [{"countryiso3code": "IDN", "date": "2024", "value": 5.0}, {"countryiso3code": "IDN", "date": "2023", "value": 4.9}, {"countryiso3code": "IDN", "date": "2022", "value": None}]]
    assert worldbank.parse(j) == {"IDN": [(2023, 4.9), (2024, 5.0)]}
    with pytest.raises(ValueError):
        worldbank.parse([{"message": [{"value": "Invalid"}]}])


# ------------------------------------------------------------------ rantai cadangan
async def test_annual_falls_back_to_worldbank(monkeypatch):
    from terminal.providers import annual, worldbank
    H.clear_cache()

    async def imf_down(ind, codes):
        raise RuntimeError("IMF 403")

    async def wb(ind, codes):
        return {c: [(2024, 1.0), (2025, 2.0)] for c in codes}

    monkeypatch.setattr(annual, "_imf_fetch", imf_down)
    monkeypatch.setattr(worldbank, "indicator", wb)
    d = await annual.indicator("NGDP_RPCH", ("USA", "IDN", "EURO"))
    assert set(d) == {"USA", "IDN", "EURO"} and annual.SRC["NGDP_RPCH"] == "World Bank"


async def test_yield_chain_uses_next_source_and_reports_missing(monkeypatch):
    from terminal.providers import yields
    H.clear_cache()

    async def bad(cc):
        raise ValueError("diblokir")

    async def partial(cc):
        return {"10Y": [("2026-11-03", 4.0), ("2026-11-04", 4.1)], "5Y": [("2026-11-04", 3.9)]}

    monkeypatch.setitem(yields.CHAIN, "ZZ", [("bad", bad), ("partial", partial)])
    r = await yields.collect("ZZ")
    assert [c["tenor"] for c in r["curve"]] == ["5Y", "10Y"] and r["src"] == "partial"
    assert "2Y" in r["missing"] and any(n["src"] == "bad" for n in r["notes"])


# ------------------------------------------------------------------ geo
def test_country_at_and_risk_map():
    from terminal.providers import geo
    assert geo.country_at(55.75, 37.6) == "Russia" and geo.country_at(50.4, 30.5) == "Ukraine"
    assert geo.country_at(66, -175) == "Russia"            # sisi timur garis tanggal
    assert geo.country_at(64, -150) == "United States of America"
    assert geo.country_at(78, 0) is None                    # laut terbuka
    now = int(time.time())
    evs = [dict(lat=31.4, lon=34.4, place="Gaza", ts=now, sev="CRITICAL", cat="ARMED CONFLICT", title="t", source="s", link="#")] * 4
    rm = geo.risk_map(evs, [])
    assert rm["Palestine"]["level"] in ("HIGH", "CRITICAL") and rm["Palestine"]["events"] == 4
    assert geo.level_of(0) == "NONE" and geo.level_of(12) == "CRITICAL" and geo.level_of(6) == "HIGH" and geo.level_of(3) == "ELEVATED" and geo.level_of(.5) == "LOW"


# ------------------------------------------------------------------ server + dunia tiruan
def test_cb_overview_and_country_differ(client):
    ov = client.get("/api/cb/overview").json()
    assert len(ov["rows"]) == 10 and len({r["policy"] for r in ov["rows"]}) > 5
    us, jp, nz, idn = (client.get(f"/api/cb/country?cc={c}").json() for c in ("US", "JP", "NZ", "ID"))
    assert us["y10"] != jp["y10"] and us["policy"] != jp["policy"]
    assert len(us["curve"]) >= 5 and us["h10"] and us["inflation"] and us["real_rate"] is not None
    assert nz["y10"] is None and "10Y" in nz["ymissing"] and nz["curve"] == []        # tidak ada angka palsu
    assert idn["y10"] is not None and idn["y2"] is None and "Indonesia" in idn["ymissing"]["2Y"]


def test_fiscal_works_and_survives_total_failure(client, monkeypatch):
    f = client.get("/api/fiscal/overview").json()
    assert len(f["rows"]) == 10 and f["summary"] and not f["complete"]   # China sengaja tanpa data di dunia tiruan
    assert f["hidden"] == ["CN"] and "CN" not in f["available"] and len(f["available"]) == 9
    assert client.get("/api/fiscal/country?cc=JP").json()["debt_gdp"] is not None
    from terminal.providers import annual
    from terminal import store
    r_stale = client.get("/api/fiscal/overview").json()
    H.clear_cache()
    # Sumber mati tetapi data permanen di disk ada -> tetap tampil (bukan kosong)
    async def dead0(ind, codes):
        raise RuntimeError("semua sumber mati")
    monkeypatch.setattr(annual, "_imf_fetch", dead0)
    assert client.get("/api/fiscal/overview").json()["rows"][0]["debt_gdp"] == r_stale["rows"][0]["debt_gdp"]
    # Sumber mati DAN tanpa data tersimpan -> tidak crash, rangkuman kosong + info error
    H.clear_cache()
    store.execute("DELETE FROM cache")

    async def dead(ind, codes):
        raise RuntimeError("semua sumber mati")
    monkeypatch.setattr(annual, "_imf_fetch", dead)
    r = client.get("/api/fiscal/overview")
    j = r.json()
    assert r.status_code == 200 and "summary" in j and j["rows"] is not None and not j["complete"]   # tidak crash, ada rangkuman kosong + info error


def test_macro_overview_is_per_country(client):
    us, jp, idn = (client.get(f"/api/macro/overview?cc={c}").json() for c in ("US", "JP", "ID"))
    assert us["cc"] == "US" and jp["cc"] == "JP"
    lab = lambda d: [c["label"] for c in d["cards"]]
    assert lab(us) != lab(jp)
    assert json.dumps(jp["groups"], sort_keys=True) != json.dumps(idn["groups"], sort_keys=True)


def test_regime_has_data_or_clear_error(client):
    r = client.get("/api/macro/regime").json()
    assert r.get("regime") in ("EXPANSION", "REFLATION", "STAGFLATION", "DEFLATION") and r.get("description")


def test_geo_overview_has_risk_map(client):
    g = client.get("/api/geo/overview").json()
    assert g["risk"] and all(v["level"] in ("CRITICAL", "HIGH", "ELEVATED", "LOW") for v in g["risk"].values())
    assert g["gpr"]["latest"] == 135.0


def test_rev_and_health_endpoints(client):
    assert set(client.get("/api/rev").json()) >= {"rev", "bad"}
    h = client.get("/api/health").json()
    assert "hosts" in h and "bad" in h


def test_no_cache_collision_between_overviews(client):
    a, b = client.get("/api/cb/overview").json(), client.get("/api/fiscal/overview").json()
    assert "rows" in a and "rows" in b and a["rows"][0].keys() != b["rows"][0].keys()


# ------------------------------------------------------------------ Ollama (server tiruan)
class _Ollama(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, obj):
        raw = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        self._send({"models": [{"name": "gemma3:1b"}]} if self.path == "/api/tags" else {"version": "0"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        self._send({"response": "Narasi uji untuk " + body.get("model", "") + ".", "done": True})


@pytest.fixture()
def ollama():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Ollama)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}"
    srv.shutdown()


async def test_llm_against_mock_ollama(monkeypatch, ollama):
    from terminal import llm
    monkeypatch.setattr(config, "LLM_ENABLED", True)
    monkeypatch.setattr(config, "OLLAMA_HOST", ollama)
    monkeypatch.setattr(config, "OLLAMA_MODEL", "gemma3:1b")
    assert await llm.probe(force=True) and llm.enabled()
    assert "Narasi uji" in await llm.complete("halo", system=llm.SYSTEM_ID)
    cats = [dict(id="oil", title="Minyak", asset="WTI", headlines=[dict(title="Oil falls", source="R")])]
    assert await llm.narrate(cats) >= 1
    fp = llm.fingerprint(cats[0]["headlines"])
    assert "Narasi uji" in llm.stored("analysis", "oil", fp) or llm.stored("research", "oil", fp)


async def test_llm_down_degrades_gracefully(monkeypatch):
    from terminal import llm
    monkeypatch.setattr(config, "LLM_ENABLED", True)
    monkeypatch.setattr(config, "OLLAMA_HOST", "http://127.0.0.1:9")
    assert not await llm.probe(force=True) and not llm.enabled()
    with pytest.raises(RuntimeError):
        await llm.complete("x")


# ------------------------------------------------------------------ installer
def _inst():
    sys.path.insert(0, str(ROOT / "tools"))
    import installer
    return installer


def test_installer_requirements_logic(tmp_path):
    i = _inst()
    reqs = i.parse_requirements("fastapi>=0.110\nuvicorn[standard]>=0.29\n# komentar\n\nhttpx==0.27.0\npandas\n")
    assert [r[0] for r in reqs] == ["fastapi", "uvicorn", "httpx", "pandas"] and reqs[1][1:] == (">=", "0.29")
    assert i.satisfied("0.111.0", ">=", "0.110") and not i.satisfied("0.9", ">=", "0.110") and not i.satisfied(None, None, None) and i.satisfied("1", None, None)
    miss = i.missing_packages([("pytest", None, None), ("paket-yang-tidak-ada-xyz", ">=", "1.0")])
    assert [m[0] for m in miss] == ["paket-yang-tidak-ada-xyz"]       # yang ada dilewati, yang tidak ada dipasang
    real = i.parse_requirements((ROOT / "requirements.txt").read_text())
    assert {"fastapi", "uvicorn", "httpx", "pandas", "yfinance"} <= {r[0] for r in real}
    assert "python-telegram-bot" not in {r[0] for r in real}


def test_installer_ollama_model_check_and_env(tmp_path):
    i = _inst()
    tags = {"models": [{"name": "gemma3:1b"}, {"name": "llama3.2:latest"}]}
    assert i.model_present(tags, "gemma3:1b") and i.model_present(tags, "llama3.2") and not i.model_present(tags, "qwen2.5:1.5b") and not i.model_present(None, "x")
    f = tmp_path / ".env"
    f.write_text("BOT_TOKEN=\nPORT=1\n")
    i.set_env("BOT_TOKEN", "123:abc", f)
    i.set_env("ADMIN_IDS", "42", f)
    assert f.read_text().splitlines() == ["BOT_TOKEN=123:abc", "PORT=1", "ADMIN_IDS=42"]


def test_installer_cloudflared_asset_and_scripts_exist():
    i = _inst()
    a, name, _ = i.cloudflared_asset()
    assert a.startswith("cloudflared-") and name.startswith("cloudflared")
    for f in ("install.bat", "install.sh", "start.bat", "start.sh", "tools/installer.py"):
        assert (ROOT / f).exists(), f
    sb = (ROOT / "start.bat").read_text()
    assert "install.bat" in sb and ".install_ok" in sb
    ib = (ROOT / "install.bat").read_text()
    assert "installer.py" in ib and "winget" in ib
    assert "\r" not in (ROOT / "install.sh").read_text()


def test_env_example_has_no_required_credentials_and_no_telegram():
    txt = (ROOT / ".env.example").read_text()
    keys = [ln.split("=")[0] for ln in txt.splitlines() if "=" in ln and not ln.startswith("#")]
    assert "BOT_TOKEN" not in keys and "ADMIN_IDS" not in keys
    # login/bot Telegram sudah dihapus: tidak ada kunci TELEGRAM_* / token bot. (Membaca halaman PUBLIK channel
    # Telegram untuk berita - TG_CHANNELS - tidak memakai akun, bot, atau token.)
    assert not [k for k in keys if k.upper().startswith("TELEGRAM")] and "api.telegram.org" not in txt
    assert "GEMINI" not in txt and "ANTHROPIC" not in txt
    assert "ACCESS_KEY" in keys and "PRELOAD_TIMEOUT" in keys


def test_no_telegram_left_in_code():
    import re
    hits = []
    for f in list(ROOT.glob("*.py")) + list((ROOT / "terminal").rglob("*.py")) + list((ROOT / "terminal" / "web").glob("*.js")) + [ROOT / "terminal" / "web" / "index.html", ROOT / "requirements.txt", ROOT / "tools" / "installer.py"]:
        # sisa login/bot Telegram (Bot API, WebApp initData, token/admin id). Halaman publik channel (t.me/s/...) untuk
        # berita SQUAWK boleh: tanpa akun, bot, maupun token.
        if re.search(r"api\.telegram\.org|telegram\.webapp|telegram-web-app|BOT_TOKEN|ADMIN_IDS|initData", f.read_text(encoding="utf-8"), re.I):
            hits.append(f.name)
    assert not hits, hits
    assert not (ROOT / "terminal" / "bot.py").exists()
