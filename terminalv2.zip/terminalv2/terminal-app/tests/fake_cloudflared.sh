#!/bin/sh
# cloudflared palsu untuk uji: mencetak URL seperti aslinya lalu tetap hidup
sleep 1
echo "2026-11-06T10:00:00Z INF |  Your quick Tunnel has been created! Visit it at (it may take some time to be reachable):"
echo "2026-11-06T10:00:00Z INF |  https://fake-test-abc.trycloudflare.com"
exec sleep 600
