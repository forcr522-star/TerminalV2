"""Jalankan server dengan dunia tiruan (tanpa jaringan) untuk uji UI:  python tests/run_mock_server.py [port]"""
import os, sys, tempfile
if os.environ.get("MOCK_KEYS"):       # uji dua peran: kunci admin "admin-test", kunci user "user-test"
    os.environ["ADMIN_KEY"], os.environ["USER_KEY"] = "admin-test", "user-test"
else:
    os.environ.setdefault("DEV_NO_AUTH", "1")
os.environ.setdefault("LLM_ENABLED", "0")
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "mock.db")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pytest, uvicorn
mp = pytest.MonkeyPatch()
import mockworld
mockworld.install(mp)
if os.environ.get('MOCK_RETAIL_SNAPS'):
    mockworld.install_retail(mp, int(os.environ['MOCK_RETAIL_SNAPS']))
from terminal import server
uvicorn.run(server.app, host="127.0.0.1", port=int(sys.argv[1]) if len(sys.argv) > 1 else 8765, log_level="warning")
