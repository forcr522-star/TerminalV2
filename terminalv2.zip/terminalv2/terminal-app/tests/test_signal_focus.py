"""Menu SIGNAL: (1) bot hanya menjalankan strategi terpilih, (2) tab TERBUKA / LIMIT / TERTUTUP mengikuti siklus order
(limit -> terisi -> selesai) memakai data harga sintetis yang dikendalikan penuh (tanpa jaringan)."""
import asyncio
import datetime as dt
import json

import pandas as pd
import pytest

from terminal import store
from terminal.signals import board, control, journal, runner
from terminal.signals.one import journal as one_journal


def run(coro):
    return asyncio.run(coro)


@pytest.fixture(autouse=True)
def _clean():
    def wipe():
        store.execute("DELETE FROM kv WHERE k LIKE 'sig_%'")
        store.execute("DELETE FROM signal_log")
        store.execute("DELETE FROM one_log")
        control.reload()
        runner.reset()
    wipe()
    yield
    wipe()


# ------------------------------------------------------------------------------------------ data harga sintetis (H1)
ENTRY, SL, TPS = 99.5, 98.5, [100.3, 101.2, 102.5]
SIG_BAR = 40


def _frame():
    """Bar 0..42 datar (100 ± 0,1) -> bar 43 menyentuh entry 99,5 -> bar 44..50 naik melewati TP1, TP2, TP MAX."""
    now = pd.Timestamp(dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)).floor("h")
    idx = pd.date_range(now - pd.Timedelta(hours=80), periods=51, freq="h")
    o, hi, lo, c = [], [], [], []
    for i in range(51):
        if i <= 42:
            o.append(100.0); hi.append(100.1); lo.append(99.9); c.append(100.0)
        elif i == 43:
            o.append(99.9); hi.append(100.0); lo.append(99.4); c.append(99.7)
        else:
            px = 99.7 + (i - 43) * 0.45
            o.append(px - 0.2); hi.append(px + 0.1); lo.append(px - 0.3); c.append(px)
    return pd.DataFrame(dict(o=o, h=hi, l=lo, c=c, v=[1000.0] * 51), index=idx)


FULL = _frame()


def _plan():
    return dict(d=1, entry=ENTRY, sl=SL, tp=list(TPS), w=[0.4, 0.3, 0.3], expiry=6, max_hold=48)


@pytest.fixture()
def market(monkeypatch):
    """yahoo.ohlcv / live_ohlcv / quotes -> bingkai sintetis yang dipotong sampai bar 'sekarang' (view['n'])."""
    from terminal.providers import yahoo
    view = dict(n=43)

    async def ohlcv(*a, **k):
        return FULL.iloc[:view["n"]].copy()

    async def quotes(symbols):
        return {}
    monkeypatch.setattr(yahoo, "ohlcv", ohlcv)
    monkeypatch.setattr(yahoo, "live_ohlcv", ohlcv)
    monkeypatch.setattr(yahoo, "quotes", quotes)
    control.update(pairs=["EURUSD"], mode="intraday", strategy="multi", be=True)
    return view


def _tabs(out):
    o = out["orders"]
    return [x["id"] for x in o["open"]], [x["id"] for x in o["limit"]], [x["id"] for x in o["closed"]]


def test_order_lifecycle_moves_between_limit_open_closed_tabs(market):
    sid = journal.create("EURUSD", "intraday", True, "BUY", str(FULL.index[SIG_BAR]), _plan(), "t")
    # 1) harga belum menyentuh entry -> LIMIT
    market["n"] = 43
    run(runner.track_once())
    assert journal.get(sid)["status"] == "PENDING"
    op, lm, cl = _tabs(run(board.build("EURUSD")))
    assert (op, lm, cl) == ([], [sid], [])
    out = run(board.build("EURUSD"))
    assert out["orders"]["limit"][0]["kind"] == "BUY LIMIT" and out["chart"]["order"]["id"] == sid
    assert next(p for p in out["pairs"] if p["sym"] == "EURUSD")["limit"] == 1
    # 2) bar menyentuh entry -> TERBUKA (posisi berjalan)
    market["n"] = 44
    run(runner.track_once())
    assert journal.get(sid)["status"] == "OPEN"
    out = run(board.build("EURUSD"))
    op, lm, cl = _tabs(out)
    assert (op, lm, cl) == ([sid], [], [])
    assert out["orders"]["open"][0]["kind"] == "BUY" and out["orders"]["open"][0]["fill_ts"] is not None
    # 3) harga melewati TP1, TP2, TP MAX -> TERTUTUP dengan hasil positif
    market["n"] = 51
    run(runner.track_once())
    row = journal.get(sid)
    assert row["status"] == "TPMAX" and row["closed"] is not None and float(row["r"]) > 0
    out = run(board.build("EURUSD"))
    op, lm, cl = _tabs(out)
    assert (op, lm, cl) == ([], [], [sid])
    c = out["orders"]["closed"][0]
    assert c["status_txt"] == "TP MAX tercapai" and c["r"] > 0
    assert out["orders"]["stats"]["n"] == 1 and out["chart"]["order"] is None


def test_unfilled_limit_expires_into_closed_tab(market):
    pl = dict(_plan(), entry=95.0, sl=94.0)        # entry jauh di bawah harga (tidak pernah terisi), TP1 di atas harga (bukan MISSED)
    sid = journal.create("EURUSD", "intraday", True, "BUY", str(FULL.index[SIG_BAR - 20]), pl, "t")
    market["n"] = 43
    run(runner.track_once())
    assert journal.get(sid)["status"] == "EXPIRED"
    out = run(board.build("EURUSD"))
    assert _tabs(out) == ([], [], [sid])
    assert out["orders"]["closed"][0]["r"] is None and "Batal" in out["orders"]["closed"][0]["status_txt"]


def _one_plan(side="BUY"):
    return dict(side=side, E1=99.5, E2=99.2, SL=98.5, TP1=100.3, TP2=101.2, atr=0.5, created_ts=int(FULL.index[SIG_BAR].timestamp()),
                tf_minutes=60, expiry_bars=36, lots=dict(only_e1=False), digits=2)


def test_switching_strategy_cancels_only_unfilled_limits_of_other_strategy(market):
    m_pend = journal.create("EURUSD", "intraday", True, "BUY", str(FULL.index[SIG_BAR]), _plan(), "t")
    m_open = journal.create("GBPUSD", "intraday", True, "BUY", str(FULL.index[SIG_BAR]), _plan(), "t")
    journal.update(m_open, "OPEN", 0.2, 0)
    o_pend = one_journal.create("k-pend", "EURUSD", "intraday", "A", "BUY", str(FULL.index[SIG_BAR]), _one_plan())
    o_open = one_journal.create("k-open", "Gold", "intraday", "B", "SELL", str(FULL.index[SIG_BAR]), _one_plan("SELL"))
    one_journal.update(o_open, "OPEN", 0.1)

    # admin memilih STRATEGI ONE -> limit 10 METODE dibatalkan, posisi 10 METODE yang sudah terisi tetap dipantau
    runner.on_control_changed(control.update(strategy="one"))
    assert journal.get(m_pend)["status"] == "CANCEL" and "STRATEGI ONE" in journal.get(m_pend)["note"]
    assert journal.get(m_open)["status"] == "OPEN"
    assert {r["id"]: r["status"] for r in one_journal.active_all()} == {o_pend: "PENDING", o_open: "OPEN"}

    # kembali ke 10 METODE -> limit ONE dibatalkan, posisi ONE tetap
    runner.on_control_changed(control.update(strategy="multi"))
    st = {r["id"]: r["status"] for r in one_journal.recent(50)}
    assert st[o_pend] == "CANCEL" and st[o_open] == "OPEN"
    assert journal.get(m_open)["status"] == "OPEN"
    # tab TERTUTUP 10 METODE menampilkan pembatalan tanpa hasil R, tidak dihitung sebagai trade
    out = run(board.build("EURUSD"))
    cl = {o["id"]: o for o in out["orders"]["closed"]}
    assert cl[m_pend]["status_txt"] == "Dibatalkan (strategi diganti)" and cl[m_pend]["r"] is None
    assert out["orders"]["stats"]["n"] == 0
    # idempoten: tidak ada lagi yang dibatalkan
    assert runner.focus_strategy("multi") == 0


def test_tracker_cleans_leftover_limits_of_inactive_strategy(market):
    """Limit strategi lain yang tersisa (mis. dari sebelum restart) dibatalkan oleh pelacak, bukan dibiarkan terisi."""
    o_pend = one_journal.create("k-left", "EURUSD", "intraday", "A", "BUY", str(FULL.index[SIG_BAR]), _one_plan())
    assert control.get()["strategy"] == "multi"
    run(runner.track_once())
    assert one_journal.recent(5)[0]["id"] == o_pend and one_journal.recent(5)[0]["status"] == "CANCEL"


def test_control_endpoint_switch_applies_focus(client):
    from terminal.signals import control as ctl
    ctl.update(pairs=["EURUSD"], strategy="multi")
    sid = journal.create("EURUSD", "intraday", True, "BUY", str(FULL.index[SIG_BAR]), _plan(), "t")
    r = client.post("/api/signal/control", json={"strategy": "one"})
    assert r.status_code == 200 and r.json()["state"]["strategy"] == "one"
    assert journal.get(sid)["status"] == "CANCEL"


def test_ea_feed_reports_cancel_so_ea_deletes_limit(market):
    from terminal import ea_feed
    sid = journal.create("EURUSD", "intraday", True, "BUY", str(FULL.index[SIG_BAR]), _plan(), "t")
    runner.on_control_changed(control.update(strategy="one"))
    multi, _ = ea_feed.rows()
    line = ea_feed.multi_line(next(r for r in multi if r["id"] == sid))
    assert line.split("|")[1] == f"M{sid}" and line.split("|")[5] == "CANCEL"
