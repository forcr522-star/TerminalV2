"""Uji UI tema & alat terminal: sidebar berikon + grup, font lokal, command palette (Ctrl+K / "/"), watchlist & price
alert, kalkulator ukuran posisi (rumus diuji dengan angka nyata), semua menu tanpa error JS, tampilan ponsel.

    MOCK_KEYS=1 python tests/run_mock_server.py 8765 &   lalu:
    python tests/ui_tools_check.py ./shots          (PW_CHROMIUM=<jalur chrome> bila perlu)
"""
import os
import sys
from playwright.sync_api import sync_playwright
OUT = sys.argv[1] if len(sys.argv) > 1 else "."
BASE = os.environ.get("BASE", "http://127.0.0.1:8765")
KEY = os.environ.get("ADMIN_KEY_TEST", "admin-test")
ok = []
def check(name, cond, info=""):
    ok.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name, info)
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
    c = b.new_context(viewport={"width": 1440, "height": 860}); pg = c.new_page(); errs = []; bad = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.on("response", lambda r: bad.append(f"{r.status} {r.url}") if r.status >= 400 else None)
    pg.goto(BASE + f"/?key={KEY}#dashboard"); pg.wait_for_timeout(4500)
    check("font Plex dimuat", pg.evaluate("document.fonts.check('12px \"IBM Plex Mono\"') && document.fonts.check('600 12px \"IBM Plex Sans Condensed\"')"))
    check("sidebar 5 grup + semua menu", pg.evaluate("document.querySelectorAll('#rail .rg').length>=5 && document.querySelectorAll('#rail a[data-id]').length===T.modules.length"))
    check("ikon SVG di setiap menu", pg.evaluate("[...document.querySelectorAll('#rail a[data-id] .ico')].every(e=>e.querySelector('svg'))"))
    # palette
    pg.keyboard.press("Control+k"); pg.wait_for_timeout(300)
    check("palette terbuka (Ctrl+K)", pg.locator(".tm-modal.pal").count() == 1)
    pg.keyboard.type("heatmap"); pg.wait_for_timeout(200); pg.keyboard.press("Enter"); pg.wait_for_timeout(1200)
    check("palette -> menu heatmap", pg.evaluate("location.hash") == "#heatmap", pg.evaluate("location.hash"))
    check("judul & eyebrow ikut menu", pg.evaluate("document.getElementById('eyebrow').textContent==='TRADING' && document.getElementById('title').textContent.startsWith('HEATMAP')"))
    pg.goto(BASE + "/#dashboard"); pg.wait_for_timeout(1500)
    pg.keyboard.press("/"); pg.wait_for_timeout(200); pg.keyboard.type("eurusd"); pg.wait_for_timeout(300)
    check("palette cari simbol", pg.locator(".pal-it", has_text="EURUSD").count() >= 1)
    pg.keyboard.press("Enter"); pg.wait_for_timeout(1500)
    check("simbol -> MARKET", pg.evaluate("location.hash") == "#market")
    # rumus kalkulator (angka nyata)
    r = pg.evaluate("[T.posSize(10000,1,1.0800,1.0750,100000,1).lotsR, T.posSize(10000,1,150,149.5,100000,1/150).lotsR, T.posSize(10000,1,2000,1990,100,1).lotsR, T.posSize(5000,2,1.08,1.0850,100000,1).side, T.posSize(10000,0.5,1.25,1.2470,100000,1).lotsR]")
    check("lot EURUSD 50 pip 1% $10k = 0.20", abs(r[0] - 0.20) < 1e-9, r[0])
    check("lot USDJPY 50 pip (kurs JPY) = 0.30", abs(r[1] - 0.30) < 1e-9, r[1])
    check("lot Gold $10 SL kontrak 100 = 0.10", abs(r[2] - 0.10) < 1e-9, r[2])
    check("SL di atas entry = SELL", r[3] == "SELL", r[3])
    check("lot dibulatkan ke bawah (0.1666 -> 0.16)", abs(r[4] - 0.16) < 1e-9, r[4])
    fx = pg.evaluate("[T.toUSD('USD'), T.toUSD('JPY'), T.quoteOf({cls:'FX',sym:'USDJPY'}), T.quoteOf({cls:'INDEX',sym:'DAX30'})]")
    check("kurs & mata uang kuotasi", fx[0] == 1 and fx[1] and fx[2] == "JPY" and fx[3] == "EUR", fx)
    # alert terpicu
    pg.evaluate("localStorage.setItem('tm.alerts.v1',JSON.stringify([{id:'t1',sym:'Gold',op:'<=',price:1e9,note:'uji',fired:null},{id:'t2',sym:'Gold',op:'>=',price:1e9,note:'',fired:null}]))")
    pg.evaluate("T.refreshWatch()"); pg.wait_for_timeout(1200)
    al = pg.evaluate("JSON.parse(localStorage.getItem('tm.alerts.v1')).map(a=>!!a.fired)")
    check("alert yang tertembus terpicu, yang belum tetap aktif", al == [True, False], al)
    check("toast PRICE ALERT muncul", pg.locator(".toast.alert").count() >= 1)
    check("lencana jumlah alert aktif = 1", pg.evaluate("document.querySelector('#tb-watch i').textContent") == "1")
    # watchlist tambah/hapus
    pg.click("#tb-watch"); pg.wait_for_timeout(500)
    pg.fill(".wl-add input", "Silver"); pg.keyboard.press("Enter"); pg.wait_for_timeout(300)
    check("watchlist tambah simbol", "Silver" in pg.evaluate("JSON.parse(localStorage.getItem('tm.watch.v1'))"))
    pg.keyboard.press("Escape"); pg.wait_for_timeout(200)
    # kalkulator terbuka & menghitung
    pg.click(".tbb[title='Kalkulator ukuran posisi']"); pg.wait_for_timeout(500)
    check("kalkulator menampilkan hasil", pg.locator(".calc-hero").count() == 1)
    sp = pg.evaluate("""[T.quoteOf({cls:'INDEX',sym:'Nikkei225'}), T.quoteOf({cls:'INDEX',sym:'KOSPI'}), T.quoteOf({cls:'INDEX',sym:'SSEC'}),
        (s=>s.size*s.scale)(T.specOf({cls:'COMMODITY',sym:'Corn'})), (s=>s.size*s.scale)(T.specOf({cls:'COMMODITY',sym:'Gasoline'})),
        T.specOf({cls:'FX',sym:'USDJPY'}).pip, T.specOf({cls:'FX',sym:'USDIDR'}).pip, T.specOf({cls:'COMMODITY',sym:'Gold'}).size]""")
    check("kuotasi indeks: Nikkei225=JPY, KOSPI=KRW, SSEC=CNY", sp[:3] == ["JPY", "KRW", "CNY"], sp[:3])
    check("Corn dalam sen: 1.0 harga = $50/lot; Gasoline 42.000 galon", sp[3] == 50 and sp[4] == 42000, sp[3:5])
    check("pip USDJPY 0.01, USDIDR 1; Gold 100 oz", sp[5] == 0.01 and sp[6] == 1 and sp[7] == 100, sp[5:])
    setv = """(([sym,acc,vals])=>{const m=document.querySelector('.calcm');const s=m.querySelectorAll('select');
        s[0].value=sym;s[0].dispatchEvent(new Event('change'));s[1].value=acc;s[1].dispatchEvent(new Event('change'));
        const i=[...m.querySelectorAll('input')];Object.entries(vals).forEach(([k,v])=>{i[+k].value=v;i[+k].dispatchEvent(new Event('input'))});
        return {hero:m.querySelector('.calc-hero').innerText.replace(/\\n/g,' | '),kv:[...m.querySelectorAll('.calc-out .kv')].map(x=>x.innerText.replace(/\\n/g,' = ')),
          warn:[...m.querySelectorAll('.calc-out .warn')].map(x=>x.className+': '+x.innerText),q:i[6].value,ro:i[6].readOnly}})"""
    # skenario laporan pengguna: Gold, saldo 100, risiko 100%, entry 3506.1, SL 1124 (input: 0 saldo,1 risiko,2 TP,3 entry,4 SL,5 kontrak,6 kuotasi)
    g = pg.evaluate(setv, ["Gold", "USD", {"0": 100, "1": 100, "3": 3506.1, "4": 1124}])
    print("   gold:", g)
    check("Gold < 0.01 lot: hero '< 0.01'", "< 0.01" in g["hero"], g["hero"])
    check("Gold < 0.01 lot: rugi di lot minimum ditampilkan (bukan $0.00)", any("(0.01 lot)" in k and "2,382.10" in k for k in g["kv"]), g["kv"])
    check("Gold < 0.01 lot: peringatan merah + risiko 100% + jarak SL", any("warn dn" in w and "0.01 lot" in w for w in g["warn"]) and any("100.0% saldo" in w for w in g["warn"]) and any("Jarak SL" in w for w in g["warn"]), g["warn"])
    check("mata uang kuotasi otomatis & tidak bisa diisi (Gold = USD)", g["q"] == "USD" and g["ro"] is True, g)
    e = pg.evaluate(setv, ["EURUSD", "IDR", {"0": 10000000, "1": 1, "3": 1.08, "4": 1.075}])
    want = pg.evaluate("Math.floor(10000000*0.01/(0.005*100000*T.assetOf('USDIDR').price)*100+1e-9)/100")
    print("   eurusd/idr:", e, "want", want)
    check("akun IDR: lot = risiko IDR / (50 pip x $10 x USDIDR)", f"| {want:.2f} lot" in e["hero"] if want >= 0.01 else "< 0.01" in e["hero"], (e["hero"], want))
    check("akun IDR: rugi & risiko dalam IDR", "IDR" in e["hero"] and any(k.startswith("Rugi bila kena SL") and "IDR" in k for k in e["kv"]), e)
    n = pg.evaluate(setv, ["Nikkei225", "USD", {"0": 10000, "1": 1, "3": 40000, "4": 39800, "5": 1}])
    jpy = pg.evaluate("T.toUSD('JPY')")
    want = pg.evaluate("Math.floor(100/(200*1*T.toUSD('JPY'))*100+1e-9)/100")
    check("Nikkei225 dalam JPY: lot = $100 / (200 poin x ¥1 x JPY→USD)", f"| {want:.2f} lot" in n["hero"] and n["q"] == "JPY", (n["hero"], want, jpy))
    pg.keyboard.press("Escape")
    # motion: indikator menu aktif berada tepat di item terpilih; panel muncul berurutan lalu bersih
    pg.goto(BASE + "/#dashboard"); pg.wait_for_timeout(1500)
    pg.evaluate("location.hash='#centralbank'"); pg.wait_for_timeout(150)
    popping = pg.evaluate("document.querySelectorAll('#view .pop').length")
    pg.wait_for_timeout(1400)
    al = pg.evaluate("(()=>{const i=document.querySelector('.rail-ind'),a=document.querySelector('#rail a.on');return Math.abs(i.getBoundingClientRect().top-a.getBoundingClientRect().top)})()")
    check("motion: panel muncul berurutan (cascade)", popping >= 3, popping)
    check("motion: indikator sidebar di menu aktif", al < 2, al)
    check("motion: kelas animasi dibersihkan", pg.evaluate("document.querySelectorAll('#view .pop').length") == 0)
    # prefetch: sorot menu -> data diambil lebih dulu; saat diklik tidak ada permintaan baru
    seen = []
    pg.on("request", lambda r: seen.append(r.url) if "/api/macro/" in r.url else None)
    pg.hover("#rail a[data-id='macro']"); pg.wait_for_timeout(800); n_hover = len(seen)
    pg.click("#rail a[data-id='macro']"); pg.wait_for_timeout(1000)
    check("prefetch: data menu diambil saat disorot", n_hover >= 1, n_hover)
    check("prefetch: klik tidak menunggu jaringan lagi", len(seen) == n_hover, seen)
    # halaman membawa peran sesi & aset berversi (tanpa menunggu /api/me)
    check("index: peran disisipkan + aset berversi", pg.evaluate("window.__ROLE==='admin' && !!window.__V && [...document.scripts].some(s=>s.src.indexOf('core.js?v=')>=0)"))
    # SQUAWK: tab pertama MARKET INTELLIGENCE, baris headline + panel sumber + kontrol suara
    pg.goto(BASE + "/#intel"); pg.wait_for_timeout(2500)
    check("squawk: tab default di MARKET INTELLIGENCE", pg.locator(".tabs button.on", has_text="Squawk").count() == 1)
    check("squawk: baris headline tampil", pg.locator(".sq-row").count() >= 1, pg.locator(".sq-row").count())
    check("squawk: panel sumber & status Walter Bloomberg", pg.locator(".sq-x").count() == 1 and pg.locator(".sq-srow").count() >= 3)
    pg.click(".sq-tog:has-text('Bunyi') input"); pg.wait_for_timeout(200)
    check("squawk: pilihan tersimpan per browser", pg.evaluate("JSON.parse(localStorage.getItem('tm.squawk.v1')).sound===true"))
    pg.click(".sq-tog:has-text('Bunyi') input")
    reqs = []
    pg.on("request", lambda r: reqs.append(r.url) if "/api/squawk" in r.url and "since=" in r.url else None)
    pg.wait_for_timeout(5600)
    check("squawk: polling ringan dengan since=", len(reqs) >= 1, reqs[:1])
    # semua menu tetap terbuka tanpa error
    for m in pg.evaluate("T.modules.map(m=>m[0])"):
        pg.goto(BASE + "/#" + m); pg.wait_for_timeout(1200)
    check("semua menu tanpa error JS", not errs, errs[:3])
    real_bad = [x for x in bad if "/favicon" not in x]
    check("tidak ada resource gagal (selain favicon)", not real_bad, real_bad[:5])
    # ponsel
    m = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True); mp = m.new_page()
    mp.goto(BASE + f"/?key={KEY}#signal"); mp.wait_for_timeout(3500)
    check("ponsel: tanpa scroll horizontal", mp.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    mp.click("#burger"); mp.wait_for_timeout(500)
    check("ponsel: drawer menu dengan label", mp.evaluate("getComputedStyle(document.querySelector('#rail .lbl')).opacity==='1' && document.getElementById('rail').getBoundingClientRect().left>=0"))
    mp.screenshot(path=os.path.join(OUT, "tools_phone_menu.png"))
    mp.click("#scrim", position={"x": 350, "y": 400}); mp.wait_for_timeout(400)
    check("ponsel: scrim menutup menu", not mp.evaluate("document.getElementById('rail').classList.contains('open')"))
    mp.screenshot(path=os.path.join(OUT, "tools_phone_signal.png"))
    mp.goto(BASE + "/#dashboard"); mp.wait_for_timeout(3000); mp.screenshot(path=os.path.join(OUT, "tools_phone_dashboard.png"))
    b.close()
print(f"{sum(ok)}/{len(ok)} lulus")
sys.exit(0 if all(ok) else 1)
