"""Keandalan server & sumber data: DB tidak menahan event loop, pemutus per sumber daya, jeda host yang tidak menjawab,
kegagalan lokal tidak dihitung sebagai sumber bermasalah, watchdog, Polymarket, feed berita, dan perbaikan backtest."""
import asyncio
import threading
import time

import httpx
import numpy as np
import pandas as pd
import pytest

from terminal import health, http as H, store, watchdog
from terminal.providers import news, polymarket as PM
from terminal.signals import backtest as BT, fundamental as F


def run(coro):
    return asyncio.run(coro)


# ------------------------------------------------------------------------------------------- database
def test_reads_do_not_wait_for_a_long_write():
    store.kv_set("rel_probe", {"v": 1})
    hold = threading.Event()

    def writer():
        with store._lock:                         # tulis besar / proses lain sedang menulis
            hold.set()
            time.sleep(1.5)
    t = threading.Thread(target=writer)
    t.start()
    hold.wait()
    t0 = time.time()
    v = store.kv_get("rel_probe")
    took = time.time() - t0
    t.join()
    assert v == {"v": 1} and took < 0.5          # dulu: baca menunggu kunci tulis (event loop macet)


def test_large_writes_are_batched():
    store.execute("CREATE TABLE IF NOT EXISTS rel_rows(i INTEGER)")
    store.execute("DELETE FROM rel_rows")
    store.executemany("INSERT INTO rel_rows VALUES(?)", [(i,) for i in range(store.WRITE_BATCH * 2 + 7)])
    assert store.query("SELECT COUNT(*) AS n FROM rel_rows")[0]["n"] == store.WRITE_BATCH * 2 + 7


# ------------------------------------------------------------------------------------------- http
@pytest.fixture()
def mock_http(monkeypatch):
    calls = []

    def install(handler):
        async def mk():
            return httpx.AsyncClient(transport=httpx.MockTransport(handler))
        c = run(mk())
        monkeypatch.setattr(H, "client", lambda: c)
        return c
    health.reset()
    H._strikes.clear()
    H._cool.clear()
    monkeypatch.setattr(H, "_impersonated", lambda *a, **k: asyncio.sleep(0, None))
    monkeypatch.setattr(asyncio, "sleep", _fast_sleep)
    yield install, calls
    H._cool.clear()
    H._strikes.clear()
    health.reset()


_real_sleep = asyncio.sleep


async def _fast_sleep(d, result=None):
    return await _real_sleep(0, result)


def test_breaker_disables_only_the_missing_series_not_the_whole_endpoint(mock_http):
    install, _ = mock_http

    def handler(req):
        return httpx.Response(404 if req.url.params.get("id") == "GONE" else 200, text="date,v\n2026-01-01,1\n")
    install(handler)
    url = "https://fred.example/graph/fredgraph.csv"
    for _ in range(H.STRIKES_TO_DISABLE):
        with pytest.raises(Exception):
            run(H.fetch(url, params={"id": "GONE"}, retries=0))
    assert health.is_disabled(H._key(url, {"id": "GONE"}))
    r = run(H.fetch(url, params={"id": "DGS10"}, retries=0))      # seri lain di path yang sama tetap jalan
    assert r.status_code == 200


def test_timeouts_retry_once_then_host_cools_down(mock_http):
    install, _ = mock_http
    n = {"req": 0}

    def handler(req):
        n["req"] += 1
        raise httpx.ReadTimeout("timed out", request=req)
    install(handler)
    url = "https://slow.example/data"
    with pytest.raises(httpx.ReadTimeout):
        run(H.fetch(url, retries=2))
    assert n["req"] == 2                                            # 1 ulangan saja (dulu 3 + TLS Chrome)
    for _ in range(H.COOL_AFTER - 2):                               # dihitung per percobaan: 2 + 1 = COOL_AFTER
        with pytest.raises(httpx.ReadTimeout):
            run(H.fetch(url, retries=0))
    before = n["req"]
    with pytest.raises(H.HttpError):
        run(H.fetch(url))                                           # dijeda: gagal seketika, tanpa permintaan
    assert n["req"] == before and H.cooling("slow.example")
    assert health.snapshot()["bad"] == 1


def test_pool_timeouts_are_local_trouble_not_a_bad_source(mock_http):
    install, _ = mock_http

    def handler(req):
        raise httpx.PoolTimeout("pool full", request=req)
    install(handler)
    with pytest.raises(httpx.PoolTimeout):
        run(H.fetch("https://feeds.example/rss", retries=0))
    snap = health.snapshot()
    host = next(h for h in snap["hosts"] if h["host"] == "feeds.example")
    assert snap["bad"] == 0 and host["level"] == "ok" and host["local_fail"] == 1
    assert not H.cooling("feeds.example")


def test_watchdog_reports_recent_stall(monkeypatch):
    monkeypatch.setitem(watchdog._state, "running", True)
    monkeypatch.setitem(watchdog._state, "beat", time.monotonic() - 5)
    assert watchdog.stalled_since(time.time() - 10)                # loop baru saja macet
    monkeypatch.setitem(watchdog._state, "beat", time.monotonic())
    watchdog._recent.clear()
    assert not watchdog.stalled_since(time.time() - 10)
    watchdog._recent.append((time.time() - 3, time.time() - 1))
    assert watchdog.stalled_since(time.time() - 10) and not watchdog.stalled_since(time.time())


# ------------------------------------------------------------------------------------------- Polymarket
def _ev(title, markets, slug="x"):
    return dict(title=title, slug=slug, markets=[dict(question=q, outcomes='["Yes", "No"]', outcomePrices=f'["{p}", "{1 - p}"]',
                                                     volume24hr=v, oneDayPriceChange=d, active=True, closed=False) for q, p, v, d in markets])


def test_polymarket_dominance_and_direction_scores():
    ev = [_ev("Israel x Iran ceasefire", [("Israel x Iran ceasefire continues through December 31?", 0.7, 200_000, 0.06)]),
          _ev("US invade Iran", [("Will the U.S. invade Iran before 2027?", 0.1, 100_000, -0.03)]),
          _ev("Netanyahu", [("Netanyahu out by June?", 0.4, 50_000, 0.002)]),
          _ev("dead", [("Will X happen?", 0.995, 900_000, 0.0)]),                    # hampir pasti: diabaikan
          _ev("thin", [("Will Y happen?", 0.5, 100, 0.2)])]                          # sepi: diabaikan
    rows = PM.parse_events(ev, "geopolitics")
    assert [r["side"] for r in rows] == ["BELI", "JUAL", "NETRAL"] and [r["risk"] for r in rows] == [1, -1, 0]
    s = PM.summarize(rows)
    assert s["overall"]["verdict"] == "BELI" and s["overall"]["buy_pct"] == pytest.approx(200 / 350 * 100, rel=1e-3)
    assert s["risk"] > 0.9                                                         # gencatan dibeli + invasi dijual = risk-on
    fed = PM.parse_events([_ev("Fed", [("Will the Fed decrease interest rates by 25 bps after the December meeting?", 0.3, 100_000, -0.05),
                                         ("Will the Fed increase interest rates by 25 bps after the December meeting?", 0.6, 100_000, 0.05)])], "fed")
    assert [r["fed"] for r in fed] == [1, -1] and PM.summarize(fed)["fed"] < -0.9   # hawkish
    assert PM._risk("Israel-Hamas ceasefire ends by March?") == -1 and PM._risk("Will the war end by 2026?") == 1
    assert PM._crypto("Will Bitcoin dip to $55,000 by December 31?", "crypto") == -1 and PM._crypto("Will Bitcoin reach $90,000?", "crypto") == 1


def test_polymarket_driver_maps_direction_per_asset():
    pm = dict(risk=0.8, fed=-0.6, crypto=0.5, n_risk=10, n_fed=5, n_crypto=8, overall=dict(verdict="BELI"))
    gold = F.pm_score(dict(kind="METAL", name="Gold"), pm)[0]
    spx = F.pm_score(dict(kind="INDEX", name="US500"), pm)[0]
    eurusd = F.pm_score(dict(kind="FX", base="EUR", quote="USD", name="EURUSD"), pm)[0]
    usdjpy = F.pm_score(dict(kind="FX", base="USD", quote="JPY", name="USDJPY"), pm)[0]
    assert gold < 0 < spx                          # risk-on & Fed hawkish: emas tertekan, indeks naik
    assert eurusd < 0 < usdjpy                     # Fed hawkish -> USD kuat; risk-on -> JPY lemah
    assert F.pm_score(dict(kind="OTHER"), pm) is None and F.pm_score(dict(kind="INDEX"), None) is None


# ------------------------------------------------------------------------------------------- berita
def test_feeds_have_their_own_schedule_and_external_items_dedupe(monkeypatch):
    pulled = []

    async def fake_pull(n, u, h):
        pulled.append(n)
        return []
    monkeypatch.setattr(news, "_pull", fake_pull)
    news._pulled.clear()
    run(news.refresh())
    first = len(pulled)
    assert first == len(news.FEEDS)
    pulled.clear()
    run(news.refresh())                                              # langsung lagi: belum ada yang jatuh tempo
    assert pulled == []
    assert news._every("Google: Reuters Markets") == 300 and news._every("ECB Press") == 900 and news._every("BBC World") == 90
    item = dict(title="Polymarket: Will X happen? - peluang Yes 60% (+8.0 poin 24 jam, dominan BELI)", source="Polymarket", link="https://p", hints=["MARKETS"], uid="x:2026-11-24")
    assert run(news.add_external([item], "pm")) == 1 and run(news.add_external([dict(item, title=item["title"].replace("60", "61"))], "pm")) == 0


# ------------------------------------------------------------------------------------------- backtest
def test_backtest_context_accepts_regime_dict():
    ctx = BT._context(dict(families=[dict(family="TREND", vote=1)]), dict(label="TRENDING", atr_pct=0.4), "GOLD")
    assert ctx["regime"] == "TRENDING" and ctx["atr_pct"] == 0.4 and ctx["families"] == ["TREND"]
    assert BT._context({}, "CAMPURAN", "GOLD")["regime"] == "CAMPURAN"         # label lama tetap aman


def test_backtest_uses_history_before_start_as_warmup(monkeypatch):
    idx = pd.date_range("2022-01-01", periods=900, freq="D", tz="UTC")
    seen = {}

    def fake_build(df, mode):
        seen["n"], seen["first"] = len(df), df.index[0]
        raise RuntimeError("stop")                                   # cukup: periksa data yang dipakai
    monkeypatch.setattr(BT.C, "build", fake_build)
    df = pd.DataFrame(dict(o=1.0, h=1.0, l=1.0, c=1.0, v=1.0), index=idx)
    with pytest.raises(RuntimeError):
        BT._run_pair(df, "GOLD", "swing", True, "2024-01-01", "2024-06-01")
    assert seen["first"] == idx[0]                                   # pemanasan memakai data sebelum tanggal mulai
    assert seen["n"] == int(np.searchsorted(idx, pd.Timestamp("2024-06-02", tz="UTC"), side="right"))   # s/d tanggal selesai (+1 hari, inklusif)
    with pytest.raises(ValueError):
        BT._run_pair(df, "GOLD", "swing", True, "2030-01-01", "2030-02-01")         # rentang tanpa data: pesan jelas


def test_futures_contracts_follow_exchange_cycle_and_skip_expired_month():
    import datetime as dt
    from terminal.providers import yahoo
    nov = dt.date(2026, 11, 24)
    cl = [s for _, s in yahoo.futures_symbols("CL", "NYM", today=nov)]
    zb = [s for _, s in yahoo.futures_symbols("ZB", "CBT", today=nov)]
    assert cl[0] == "CLZ26.NYM" and "CLX26.NYM" not in cl                 # kontrak November sudah kedaluwarsa
    assert all(s[2] in "HMUZ" for s in zb) and zb[0] == "ZBZ26.CBT" and len(zb) == 8
