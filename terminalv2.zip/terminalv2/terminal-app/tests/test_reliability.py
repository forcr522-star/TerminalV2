"""Keandalan server & sumber data: DB tidak menahan event loop, pemutus per sumber daya, jeda host yang tidak menjawab,
kegagalan lokal tidak dihitung sebagai sumber bermasalah, watchdog, Polymarket, feed berita."""
import asyncio
import threading
import time

import httpx
import numpy as np
import pandas as pd
import pytest

from terminal import health, http as H, store, watchdog
from terminal.providers import news, polymarket as PM
from terminal.signals import fundamental as F


def run(coro):
    return asyncio.run(coro)


# ------------------------------------------------------------------------------------------- database
def test_reads_do_not_wait_for_a_long_write():
    store.kv_set("rel_probe", {"v": 1})
    hold = threading.Event()

    def writer():
        with store._lock:                         # tulis besar / proses lain sedang menulis
            hold.set()
            time.sleep(1.5)
    t = threading.Thread(target=writer)
    t.start()
    hold.wait()
    t0 = time.time()
    v = store.kv_get("rel_probe")
    took = time.time() - t0
    t.join()
    assert v == {"v": 1} and took < 0.5          # dulu: baca menunggu kunci tulis (event loop macet)


def test_large_writes_are_batched():
    store.execute("CREATE TABLE IF NOT EXISTS rel_rows(i INTEGER)")
    store.execute("DELETE FROM rel_rows")
    store.executemany("INSERT INTO rel_rows VALUES(?)", [(i,) for i in range(store.WRITE_BATCH * 2 + 7)])
    assert store.query("SELECT COUNT(*) AS n FROM rel_rows")[0]["n"] == store.WRITE_BATCH * 2 + 7


# ------------------------------------------------------------------------------------------- http
@pytest.fixture()
def mock_http(monkeypatch):
    calls = []

    def install(handler):
        async def mk():
            return httpx.AsyncClient(transport=httpx.MockTransport(handler))
        c = run(mk())
        monkeypatch.setattr(H, "client", lambda: c)
        return c
    health.reset()
    H._strikes.clear()
    H._cool.clear()
    monkeypatch.setattr(H, "_impersonated", lambda *a, **k: asyncio.sleep(0, None))
    monkeypatch.setattr(asyncio, "sleep", _fast_sleep)
    yield install, calls
    H._cool.clear()
    H._strikes.clear()
    health.reset()


_real_sleep = asyncio.sleep


async def _fast_sleep(d, result=None):
    return await _real_sleep(0, result)


def test_breaker_disables_only_the_missing_series_not_the_whole_endpoint(mock_http):
    install, _ = mock_http

    def handler(req):
        return httpx.Response(404 if req.url.params.get("id") == "GONE" else 200, text="date,v\n2026-01-01,1\n")
    install(handler)
    url = "https://fred.example/graph/fredgraph.csv"
    for _ in range(H.STRIKES_TO_DISABLE):
        with pytest.raises(Exception):
            run(H.fetch(url, params={"id": "GONE"}, retries=0))
    assert health.is_disabled(H._key(url, {"id": "GONE"}))
    r = run(H.fetch(url, params={"id": "DGS10"}, retries=0))      # seri lain di path yang sama tetap jalan
    assert r.status_code == 200


def test_timeouts_retry_once_then_host_cools_down(mock_http):
    install, _ = mock_http
    n = {"req": 0}

    def handler(req):
        n["req"] += 1
        raise httpx.ReadTimeout("timed out", request=req)
    install(handler)
    url = "https://slow.example/data"
    with pytest.raises(httpx.ReadTimeout):
        run(H.fetch(url, retries=2))
    assert n["req"] == 2                                            # 1 ulangan saja (dulu 3 + TLS Chrome)
    for _ in range(H.COOL_AFTER - 2):                               # dihitung per percobaan: 2 + 1 = COOL_AFTER
        with pytest.raises(httpx.ReadTimeout):
            run(H.fetch(url, retries=0))
    before = n["req"]
    with pytest.raises(H.HttpError):
        run(H.fetch(url))                                           # dijeda: gagal seketika, tanpa permintaan
    assert n["req"] == before and H.cooling("slow.example")
    assert health.snapshot()["bad"] == 1


def test_pool_timeouts_are_local_trouble_not_a_bad_source(mock_http):
    install, _ = mock_http

    def handler(req):
        raise httpx.PoolTimeout("pool full", request=req)
    install(handler)
    with pytest.raises(httpx.PoolTimeout):
        run(H.fetch("https://feeds.example/rss", retries=0))
    snap = health.snapshot()
    host = next(h for h in snap["hosts"] if h["host"] == "feeds.example")
    assert snap["bad"] == 0 and host["level"] == "ok" and host["local_fail"] == 1
    assert not H.cooling("feeds.example")


def test_watchdog_reports_recent_stall(monkeypatch):
    monkeypatch.setitem(watchdog._state, "running", True)
    monkeypatch.setitem(watchdog._state, "beat", time.monotonic() - 5)
    assert watchdog.stalled_since(time.time() - 10)                # loop baru saja macet
    monkeypatch.setitem(watchdog._state, "beat", time.monotonic())
    watchdog._recent.clear()
    assert not watchdog.stalled_since(time.time() - 10)
    watchdog._recent.append((time.time() - 3, time.time() - 1))
    assert watchdog.stalled_since(time.time() - 10) and not watchdog.stalled_since(time.time())


# ------------------------------------------------------------------------------------------- Polymarket
def _ev(title, markets, slug="x"):
    return dict(title=title, slug=slug, markets=[dict(question=q, outcomes='["Yes", "No"]', outcomePrices=f'["{p}", "{1 - p}"]',
                                                     volume24hr=v, oneDayPriceChange=d, active=True, closed=False) for q, p, v, d in markets])


def test_polymarket_dominance_and_direction_scores():
    ev = [_ev("Israel x Iran ceasefire", [("Israel x Iran ceasefire continues through December 31?", 0.7, 200_000, 0.06)]),
          _ev("US invade Iran", [("Will the U.S. invade Iran before 2027?", 0.1, 100_000, -0.03)]),
          _ev("Netanyahu", [("Netanyahu out by June?", 0.4, 50_000, 0.002)]),
          _ev("dead", [("Will X happen?", 0.995, 900_000, 0.0)]),                    # hampir pasti: diabaikan
          _ev("thin", [("Will Y happen?", 0.5, 100, 0.2)])]                          # sepi: diabaikan
    rows = PM.parse_events(ev, "geopolitics")
    assert [r["side"] for r in rows] == ["BELI", "JUAL", "NETRAL"] and [r["risk"] for r in rows] == [1, -1, 0]
    s = PM.summarize(rows)
    assert s["overall"]["verdict"] == "BELI" and s["overall"]["buy_pct"] == pytest.approx(200 / 350 * 100, rel=1e-3)
    assert s["risk"] > 0.9                                                         # gencatan dibeli + invasi dijual = risk-on
    fed = PM.parse_events([_ev("Fed", [("Will the Fed decrease interest rates by 25 bps after the December meeting?", 0.3, 100_000, -0.05),
                                         ("Will the Fed increase interest rates by 25 bps after the December meeting?", 0.6, 100_000, 0.05)])], "fed")
    assert [r["fed"] for r in fed] == [1, -1] and PM.summarize(fed)["fed"] < -0.9   # hawkish
    assert PM._risk("Israel-Hamas ceasefire ends by March?") == -1 and PM._risk("Will the war end by 2026?") == 1
    assert PM._crypto("Will Bitcoin dip to $55,000 by December 31?", "crypto") == -1 and PM._crypto("Will Bitcoin reach $90,000?", "crypto") == 1


def test_polymarket_driver_maps_direction_per_asset():
    pm = dict(risk=0.8, fed=-0.6, crypto=0.5, n_risk=10, n_fed=5, n_crypto=8, overall=dict(verdict="BELI"))
    gold = F.pm_score(dict(kind="METAL", name="Gold"), pm)[0]
    spx = F.pm_score(dict(kind="INDEX", name="US500"), pm)[0]
    eurusd = F.pm_score(dict(kind="FX", base="EUR", quote="USD", name="EURUSD"), pm)[0]
    usdjpy = F.pm_score(dict(kind="FX", base="USD", quote="JPY", name="USDJPY"), pm)[0]
    assert gold < 0 < spx                          # risk-on & Fed hawkish: emas tertekan, indeks naik
    assert eurusd < 0 < usdjpy                     # Fed hawkish -> USD kuat; risk-on -> JPY lemah
    assert F.pm_score(dict(kind="OTHER"), pm) is None and F.pm_score(dict(kind="INDEX"), None) is None


# ------------------------------------------------------------------------------------------- berita
def test_feeds_have_their_own_schedule(monkeypatch):
    pulled = []

    async def fake_pull(n, u, h):
        pulled.append(n)
        return []
    monkeypatch.setattr(news, "_pull", fake_pull)
    news._pulled.clear()
    run(news.refresh())
    assert len(pulled) == len(news.FEEDS)
    pulled.clear()
    run(news.refresh())                                              # langsung lagi: belum ada yang jatuh tempo
    assert pulled == []
    assert news._every("Google: Reuters Markets") == 300 and news._every("ECB Press") == 900 and news._every("BBC World") == 90


def test_polymarket_is_background_only_and_optional():
    from terminal import api
    assert "intel/polymarket" not in api.S.ENDPOINTS                     # tidak ditampilkan / tidak di-preload
    health.reset()
    health.host_fail("gamma-api.polymarket.com", RuntimeError("ConnectError"))
    health.host_fail("gamma-api.polymarket.com", RuntimeError("ConnectError"))
    assert health.snapshot()["bad"] == 0                              # data pendukung: tidak dihitung di lencana
    health.reset()


def test_cot_falls_back_to_cftc_archive(monkeypatch):
    from terminal.providers import cftc
    from terminal import http as Hm
    import io as _io, zipfile as _zf
    hdr = "Market_and_Exchange_Names,As_of_Date_In_Form_YYMMDD,Report_Date_as_YYYY-MM-DD,CFTC_Contract_Market_Code,Open_Interest_All," \
          "Lev_Money_Positions_Long_All,Lev_Money_Positions_Short_All,Lev_Money_Positions_Spread_All,Change_in_Lev_Money_Long_All," \
          "Dealer_Positions_Long_All,Dealer_Positions_Short_All,Asset_Mgr_Positions_Long_All,Asset_Mgr_Positions_Short_All," \
          "Other_Rept_Positions_Long_All,Other_Rept_Positions_Short_All\n"
    rows = "".join(f"EURO FX - CHICAGO MERCANTILE EXCHANGE,2611{d:02d},2026-11-{d:02d},099741,800000,{100 + d},{300 + d},5,9,1,2,3,4,5,6\n" for d in (3, 10, 17))
    buf = _io.BytesIO()
    with _zf.ZipFile(buf, "w") as z:
        z.writestr("FinFutYY.txt", hdr + rows)

    async def fake_get_json(url, **kw):
        raise httpx.ConnectTimeout("timed out")

    class R:
        content = buf.getvalue()

    async def fake_fetch(url, **kw):
        if "2026" not in url and "fut_fin_txt_" in url and str(__import__("datetime").date.today().year) not in url:
            raise RuntimeError("404")
        return R()
    monkeypatch.setattr(cftc, "get_json", fake_get_json)
    monkeypatch.setattr(cftc, "fetch", fake_fetch)
    Hm.clear_cache()
    health.reset()
    health.host_fail("publicreporting.cftc.gov", RuntimeError("ConnectTimeout"))
    health.host_fail("publicreporting.cftc.gov", RuntimeError("ConnectTimeout"))
    out = run(cftc.instrument("tff", "Euro FX", 2))
    assert [r["date"] for r in out["rows"]] == ["2026-11-17", "2026-11-10"] and out["rows"][0]["lev_net"] == -200
    assert out["rows"][0]["lev_chg"] == 0 and health.snapshot()["bad"] == 0      # sumber utama gagal, data dari arsip
    Hm.clear_cache()
    health.reset()


def test_futures_contracts_follow_exchange_cycle_and_skip_expired_month():
    import datetime as dt
    from terminal.providers import yahoo
    nov = dt.date(2026, 11, 24)
    cl = [s for _, s in yahoo.futures_symbols("CL", "NYM", today=nov)]
    zb = [s for _, s in yahoo.futures_symbols("ZB", "CBT", today=nov)]
    assert cl[0] == "CLZ26.NYM" and "CLX26.NYM" not in cl                 # kontrak November sudah kedaluwarsa
    assert all(s[2] in "HMUZ" for s in zb) and zb[0] == "ZBZ26.CBT" and len(zb) == 8


def test_dns_blocked_host_is_reached_via_doh_with_original_sni(mock_http):
    install, _ = mock_http
    seen = []

    def handler(req):
        if req.url.host == "cloudflare-dns.com":
            return httpx.Response(200, json={"Answer": [{"type": 1, "data": "104.18.1.2"}]})
        if req.url.host == "gamma.example":
            raise httpx.ConnectError("All connection attempts failed", request=req)
        seen.append((req.url.host, req.headers.get("host"), req.extensions.get("sni_hostname")))
        return httpx.Response(200, json=[{"ok": 1}])
    install(handler)
    H._doh_ip.clear(); H._doh_hosts.clear()
    r = run(H.fetch("https://gamma.example/events", params={"limit": 1}, retries=0))
    assert r.json() == [{"ok": 1}] and seen[-1] == ("104.18.1.2", "gamma.example", "gamma.example")
    host = next(h for h in health.snapshot()["hosts"] if h["host"] == "gamma.example")
    assert host["level"] == "ok" and host["via"] == "DoH"
    n = len(seen)
    run(H.fetch("https://gamma.example/events", retries=0))           # berikutnya langsung lewat DoH
    assert len(seen) == n + 1 and not H.cooling("gamma.example")
    H._doh_ip.clear(); H._doh_hosts.clear()


def test_single_transient_failure_is_not_counted_in_badge():
    health.reset()
    health.host_fail("cftc.example", RuntimeError("ConnectTimeout"))
    assert health.snapshot()["bad"] == 0 and health.snapshot()["hosts"][0]["level"] == "retry"
    health.host_fail("cftc.example", RuntimeError("ConnectTimeout"))
    assert health.snapshot()["bad"] == 1                                       # gagal berturut-turut: dihitung
    health.host_ok("cftc.example")
    assert health.snapshot()["bad"] == 0
    health.reset()
