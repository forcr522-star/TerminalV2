"""Jalankan main.py ASLI (server + tunnel + preload + panel/banner) di atas dunia tiruan, dengan cloudflared palsu:
   CLOUDFLARED_PATH=/path/fake_cloudflared_reg.sh python tests/run_mock_main.py [port]

Link trycloudflare palsu tidak bisa dibuka, jadi pemeriksaan link diarahkan ke server lokal (meniru Cloudflare sehat).
Di konsol sungguhan panel tetap TERMINAL SERVER tampil; bila keluaran dialihkan, banner gaya lama dicetak."""
import os, sys, tempfile
os.environ.setdefault("LLM_ENABLED", "0")
os.environ.setdefault("DB_PATH", os.path.join(tempfile.mkdtemp(), "e2e.db"))
if len(sys.argv) > 1:
    os.environ["PORT"] = sys.argv[1]
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pytest
mp = pytest.MonkeyPatch()
import mockworld
mockworld.install(mp)
mockworld.seed_retail()
import main
from terminal import tunnel, config

_real_probe = tunnel.probe


async def _probe_local(url, timeout=12.0, client=None):
    return await _real_probe(f"http://127.0.0.1:{config.PORT}", timeout=timeout)

mp.setattr(tunnel, "probe", _probe_local)
raise SystemExit(main.main())
