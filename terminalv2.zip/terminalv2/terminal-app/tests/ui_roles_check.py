"""Uji UI peran admin vs user:  MOCK_KEYS=1 python tests/run_mock_server.py &  python tests/ui_roles_check.py [outdir]
(MOCK_KEYS=1 -> ADMIN_KEY=admin-test, USER_KEY=user-test)."""
import sys
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8765"
OUT = sys.argv[1] if len(sys.argv) > 1 else "."
fails = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        fails.append(msg)


def main():
    with sync_playwright() as p:
        b = p.chromium.launch()
        # tanpa kunci: ditolak
        c0 = b.new_context(); pg0 = c0.new_page()
        check(pg0.goto(BASE + "/").status == 401, "tanpa kunci: halaman ditolak (401)")
        check(pg0.goto(BASE + "/?key=salah").status == 401, "kunci salah ditolak")
        # ---------------- USER
        cu = b.new_context(viewport={"width": 1440, "height": 860}); u = cu.new_page()
        errs = []
        u.on("pageerror", lambda e: errs.append(str(e)))
        u.goto(BASE + "/?key=user-test#signal"); u.wait_for_timeout(5000)
        vt = lambda pg: pg.evaluate("()=>document.getElementById('view').innerText")
        t = vt(u)
        check(u.evaluate("location.search") == "", "user: kunci dihapus dari alamat")
        check("LIST PAIR YANG DI ANALISA" in t and "CHART" in t, "user: list pair + CHART tampil")
        check(all(x in t for x in ("TERBUKA", "LIMIT", "TERTUTUP")), "user: tab TERBUKA / LIMIT / TERTUTUP")
        check(u.locator("#view .sg-row").count() == 6, "user: list berisi pair pilihan developer (6)")
        check(all(u.locator(f"#view button:has-text('{x}')").count() == 0 for x in ("BREAKEVEN", "SINYAL:", "INSIDE/ANALISIS")), "user: tombol admin TIDAK ada")
        check(u.locator("#hbtn").count() == 0 or not u.locator("#hbtn").is_visible(), "user: peringatan 'sumber bermasalah' TIDAK tampil")
        check(u.locator("#view .sg-dot").count() == 0, "user: titik arah analisa TIDAK ada")
        check(u.evaluate("document.querySelectorAll('#view .sg-cbox canvas').length") >= 1, "user: chart tampil")
        for i in range(u.locator("#view .sg-row").count()):
            u.locator("#view .sg-row").nth(i).click(); u.wait_for_timeout(1200)
        check("Data tidak tersedia" not in vt(u), "user: semua pair termuat")
        u.screenshot(path=f"{OUT}/roles_user.png")
        st = lambda path, method="GET", body=None: u.evaluate("async([p,m,b])=>{const r=await fetch(p,{method:m,headers:{'content-type':'application/json'},body:b?JSON.stringify(b):undefined});return r.status}", [path, method, body])
        for path in ("/api/signal/control", "/api/signal/detail?symbol=EURUSD", "/api/signal/catalog", "/api/signal/pair?symbol=EURUSD", "/api/signal/history", "/api/health", "/api/status"):
            check(st(path) == 403, f"user: {path} -> 403")
        check(st("/api/signal/control", "POST", {"on": False}) == 403, "user: POST kontrol -> 403")
        check(st("/api/signal/board") == 200, "user: /api/signal/board -> 200")
        u.goto(BASE + "/#signal/inside"); u.wait_for_timeout(2500)
        check(u.evaluate("location.hash") == "#signal" and "HASIL ANALISA" not in vt(u), "user: #signal/inside dialihkan ke chart")
        for m in ("dashboard", "macro", "market", "centralbank", "geo"):
            u.evaluate(f"location.hash='#{m}'"); u.wait_for_timeout(1500)
        check(not errs, f"user: tidak ada error JS {errs[:3]}")
        # ---------------- ADMIN
        ca = b.new_context(viewport={"width": 1440, "height": 860}); a = ca.new_page()
        a.on("pageerror", lambda e: errs.append(str(e)))
        a.goto(BASE + "/?key=admin-test#signal"); a.wait_for_timeout(5000)
        check(all(a.locator(f"#view button:has-text('{x}')").count() >= 1 for x in ("BREAKEVEN", "SINYAL:", "INSIDE/ANALISIS")), "admin: tombol kontrol tampil")
        bad = a.evaluate("fetch('/api/rev').then(r=>r.json()).then(d=>d.bad||0)")
        # lencana hanya untuk sumber yang gagal >= 2x berturut-turut (health.BAD_STREAK): tampil tepat bila server melaporkannya
        check(a.locator("#hbtn").count() == 1 and a.locator("#hbtn").is_visible() == (bad > 0), f"admin: peringatan 'sumber bermasalah' mengikuti server (bad={bad})")
        check(a.locator("#view .sg-dot").count() >= 6, "admin: titik arah analisa tampil")
        sta = lambda path: a.evaluate("async p=>(await fetch(p)).status", path)
        check(sta("/api/signal/control") == 200 and sta("/api/signal/catalog") == 200, "admin: endpoint kontrol -> 200")
        a.screenshot(path=f"{OUT}/roles_admin.png")
        check(not errs, f"admin: tidak ada error JS {errs[:3]}")
        b.close()
    print("FAILS:", fails)
    sys.exit(1 if fails else 0)


main()
