"""Uji logika agent terhadap berita & semua informasi website: arah katalis, kejadian mendadak (pesawat jatuh, tanker
diserang, peretasan bursa, ...), reaksi harga tanpa data masa depan, konteks dunia, dan pemicu analisa ulang."""
import asyncio
import time
import types

import numpy as np
import pandas as pd
import pytest

from terminal.analytics import catalyst, shocks as SH, world as WD
from terminal.providers import news
from terminal.signals import fundamental as F


def _item(title, ago_min=10, prio="CRIT", source="Reuters", fast=False):
    now = time.time()
    it = news._enrich(dict(title=title, source=source, link="#", ts=int(now - ago_min * 60), summary="", hints=[], feed="test"))
    it["prio"] = prio
    it["fast"] = fast
    return it


@pytest.fixture()
def feed():
    news._items.clear()
    catalyst._memo.update(key=None, at=0.0, val=None)

    def put(*items):
        for it in items:
            news._items[it["id"]] = it
        catalyst._memo.update(key=None, at=0.0, val=None)
    yield put
    news._items.clear()


# ------------------------------------------------------------------ katalis: arah tidak lagi terbalik
def test_escalation_makes_gold_and_oil_bullish_equities_bearish(feed):
    feed(_item("Missile strike hits Israeli port as Iran retaliates"), _item("Houthi drones attack tanker in Red Sea", 30))
    me = next(c for c in catalyst.build() if c["id"] == "midEast")
    d = {i["sym"]: i["dir"] for i in me["instruments"]}
    assert d["Gold"] == "BULLISH" and d["Brent Oil"] == "BULLISH" and d["US500"] == "BEARISH"     # dulu kebalikannya
    assert F.news_net(F.entity("Gold"), catalyst.build())["net"] > 0


def test_ceasefire_reverses_the_escalation_trade(feed):
    feed(_item("Israel and Hamas agree to ceasefire, hostages released", prio="HIGH"))
    me = next(c for c in catalyst.build() if c["id"] == "midEast")
    d = {i["sym"]: i["dir"] for i in me["instruments"]}
    assert d["Gold"] == "BEARISH" and d["US500"] == "BULLISH"


@pytest.mark.parametrize("theme,title,want", [
    ("us_inflation", "US CPI hotter than expected at 3.4%", 1), ("us_inflation", "Inflation cools to 2.4% in October", -1),
    ("fed", "Fed signals more rate cuts ahead", -1), ("fed", "Powell says rates to stay higher for longer", 1),
    ("oil_supply", "Oil prices tumble as OPEC output rises", -1), ("oil_supply", "Tanker seized in Strait of Hormuz", 1),
    ("tariff", "US and China reach trade deal", -1), ("boj_yen", "Yen surges after suspected intervention", 1),
])
def test_theme_polarity(theme, title, want):
    assert catalyst.polarity(theme, title) == want


# ------------------------------------------------------------------ kejadian mendadak
@pytest.mark.parametrize("title,typ", [
    ("Passenger jet crashes after take off in Nepal, 72 dead", "AVIATION"),
    ("Tanker hit by missile in Red Sea, crew evacuated", "MARITIME"),
    ("Bybit hacked: $1.5bn in ether stolen", "CYBER"),
    ("Magnitude 7.4 earthquake strikes off Japan coast, tsunami warning", "DISASTER"),
    ("Military coup in Niger as president detained", "POLITICAL"),
    ("Silicon Valley Bank collapse triggers bank run fears", "FINANCIAL"),
    ("Saudi-led coalition: two drones shot down over eastern region", "CONFLICT"),
    ("Why the plane crash matters for Boeing", None),                       # analisis, bukan kejadian
    ("Dry Bulk Shipping Rates Climb as Capesize Vessel Supply Tightens", None),
])
def test_classify(title, typ):
    assert SH.classify(title)[0] == typ


def test_civil_plane_crash_is_logged_but_barely_moves_signals(feed):
    feed(_item("Passenger jet crashes after take off in Nepal, 72 dead", 5))
    evs = SH.events()
    assert [e["type"] for e in evs] == ["AVIATION"]
    for sym in ("EURUSD", "Gold", "US500"):
        assert SH.for_asset(sym, evs) is None                               # tidak ada templat makro: tidak mengubah sinyal


def test_plane_shot_down_is_treated_as_risk_off(feed):
    feed(_item("Passenger plane shot down over Black Sea, missile suspected", 5))
    g = SH.for_asset("Gold", SH.events(), mode="intraday")
    assert g["score"] > 0 and g["guard"] and g["guard"]["type"] == "AVIATION"


def test_reports_from_several_sources_merge_and_raise_confidence(feed):
    feed(_item("Tanker hit by missile in Red Sea", 20, source="Reuters"), _item("Tanker attacked by missile in Red Sea, crew safe", 15, source="Bloomberg"),
         _item("Red Sea: tanker hit by missile, UKMTO says", 12, source="FinancialJuice"))
    evs = SH.events()
    assert len(evs) == 1 and len(evs[0]["sources"]) == 3
    b = SH.for_asset("Brent Oil", evs)
    assert b["score"] > 0 and b["guard"]
    one = SH.for_asset("Brent Oil", [dict(evs[0], sources=["Reuters"])])
    assert b["score"] > one["score"]


def test_crypto_exchange_hack_hits_crypto_only(feed):
    feed(_item("Major crypto exchange hacked, $400m drained from hot wallets", 8))
    evs = SH.events()
    assert SH.for_asset("Bitcoin", evs)["score"] < 0 and SH.for_asset("EURUSD", evs) is None


def test_old_or_future_news_is_ignored(feed):
    feed(_item("Tanker hit by missile in Red Sea", 60 * 13), _item("Tanker hit by missile in Red Sea", -30))   # 13 jam lalu & 30 mnt di MASA DEPAN
    assert SH.events() == []


def test_guard_expires_and_impact_decays(feed):
    feed(_item("Tanker hit by missile in Red Sea", 5))
    e = SH.events()
    now = time.time()
    assert SH.for_asset("Brent Oil", e, now=now, mode="scalp")["guard"]
    later = SH.for_asset("Brent Oil", e, now=now + 3600, mode="scalp")            # jendela scalp 20 mnt sudah lewat
    assert later["guard"] is None and later["score"] < SH.for_asset("Brent Oil", e, now=now)["score"]


# ------------------------------------------------------------------ reaksi harga: hanya bar TUTUP, patokan sebelum berita
def _bars(n=30, step=3600, start=1_800_000_000):
    return [start + i * step for i in range(n)]


def test_reaction_uses_only_closed_bars_after_the_news():
    idx = _bars()
    close = [100.0] * 30
    g_late = dict(ts=idx[20] + 3600 + 60, expected=1)          # berita SESUDAH bar tutup terakhir (bar 20)
    assert SH.reaction(g_late, idx[:21], close[:21], 1.0, 3600) is None    # belum ada bar tutup sesudah berita
    ev_ts = idx[20] + 1800                                   # berita di tengah bar ke-20
    g = dict(ts=ev_ts, expected=1)
    close2 = close[:20] + [100.5, 102.0, 101.6]
    r = SH.reaction(g, idx[:23], close2, 1.0, 3600)
    assert r["bars"] == 3 and r["peak_atr"] == pytest.approx(2.0) and r["agrees"]   # patokan = tutup bar 19 (sebelum berita)


def test_reaction_against_expectation_is_flagged():
    idx = _bars()
    close = [100.0] * 21 + [99.0, 98.8]
    r = SH.reaction(dict(ts=idx[20] + 10, expected=1), idx[:23], close, 1.0, 3600)
    assert r["agrees"] is False and r["move_atr"] < 0


def test_shock_check_blocks_entries_while_market_digests():
    from terminal.signals import service
    idx = pd.date_range("2026-11-20", periods=40, freq="h")
    df = pd.DataFrame({"o": 1.0, "h": 1.0, "l": 1.0, "c": 1.0}, index=idx)
    c = np.full(40, 100.0)
    c[-2:] = [101.5, 102.5]                                   # +2,5 ATR sesudah berita
    x = types.SimpleNamespace(n=40, c=c, atr=np.full(40, 1.0))
    ev_ts = int(pd.Timestamp(idx[-3]).timestamp()) + 600       # berita saat bar ke-38 berjalan
    fund = dict(score=0.2, conf=0.5, block=None, drivers=[dict(key="shock", score=0.8, weight=0.25, text="MARITIME ↑ tanker"), dict(key="rate", score=0.0, weight=0.15, text="x")],
                shock=dict(score=0.8, matched=[], guard=dict(type="MARITIME", title="Tanker hit by missile", ts=ev_ts, expected=1)))
    now = (pd.Timestamp(idx[-1]) + pd.Timedelta(minutes=30)).to_pydatetime()
    out = service.shock_check(fund, df, x, "intraday", now)
    assert out["block"] and "ditahan" in out["block"] and out["shock"]["reaction"]["peak_atr"] >= 1.0
    c2 = c.copy()
    c2[-2:] = [99.2, 98.9]                                    # pasar bergerak BERLAWANAN -> dampak diabaikan
    out2 = service.shock_check(fund, df, types.SimpleNamespace(n=40, c=c2, atr=np.full(40, 1.0)), "intraday", now)
    assert next(d for d in out2["drivers"] if d["key"] == "shock")["score"] == 0.0


# ------------------------------------------------------------------ skor fundamental & konteks dunia
def test_event_drivers_do_not_dilute_coverage():
    drv = [dict(key="rate", score=0.5, weight=0.15, text=""), dict(key="regime", score=0.5, weight=0.15, text="")]
    s1, c1, _ = F.rescore(drv, "intraday")
    s2, c2, _ = F.rescore(drv + [dict(key="shock", score=-1.0, weight=0.25, text="")], "intraday")
    assert c2 >= c1 and s2 < s1                                 # kejadian menggeser skor tanpa menurunkan cakupan


def test_world_drivers_from_chokepoints_ports_and_cyber():
    w = dict(risk={"Iran": dict(score=60.0, level="CRITICAL"), "Japan": dict(score=0.0)},
             chokepoints=[dict(id="hormuz", name="Strait of Hormuz", level="CRITICAL", pw=dict(chg_pct=-40.0)), dict(id="redsea", name="Red Sea", level="NORMAL", pw=None)],
             ports=dict(countries={"China": dict(chg=20.0)}), cyber=dict(crypto_24h=4), air=dict(regions=[dict(name="Persian Gulf", count=6)]))
    sc = lambda sym: sum(p[0] for p in WD.drivers(F.entity(sym), w))
    assert sc("Brent Oil") > 0.5 and sc("Gold") > 0 and sc("USDCAD") < 0 and sc("Copper") > 0 and sc("Bitcoin") < 0
    assert "Persian Gulf 6" in WD.air_context(w)


def test_agent_triggers_reanalysis_of_affected_pairs(feed, monkeypatch):
    from terminal.agents import run as AR, bus
    from terminal.signals import runner, control
    monkeypatch.setattr(control, "get", lambda: dict(on=True, pairs=["Brent Oil", "EURUSD"], mode="intraday", be=True))
    monkeypatch.setattr(runner, "RESULTS", {"Brent Oil": dict(at=time.time()), "EURUSD": dict(at=time.time())})
    logs = []
    monkeypatch.setattr(bus, "log", lambda a, t, level="info": logs.append((a, t, level)))
    monkeypatch.setattr(bus, "pulse", lambda *a, **k: None)
    AR._SEEN_SHOCK.clear()
    feed(_item("Tanker hit by missile in Red Sea", 3))
    asyncio.run(AR._shock_trigger(SH.events()))
    assert runner.RESULTS["Brent Oil"]["at"] == 0.0 and runner.RESULTS["EURUSD"]["at"] > 0      # hanya pair terdampak dianalisa ulang
    assert any("KEJADIAN MARITIME" in t and "Brent Oil" in t for _, t, _ in logs)
    n = len(logs)
    asyncio.run(AR._shock_trigger(SH.events()))                                              # kejadian yang sama tidak dipicu dua kali
    assert len(logs) == n


def test_conflict_moves_oil_only_in_energy_regions():
    base = dict(type="CONFLICT", sev="CRIT", half_life_h=12, sources=["Reuters"], ts=time.time(), cc=None, crypto=False, escalated=False)
    assert SH.effects(dict(base, place="iran")).get("Brent Oil", 0) > 0
    assert "Brent Oil" not in SH.effects(dict(base, place="gaza")) and SH.effects(dict(base, place="gaza"))["Gold"] > 0   # tetap risk-off
