"""Notifikasi per browser: kejadian (berita high impact, sinyal, likuiditas heatmap), langganan push, pengiriman."""
import asyncio
import base64
import json
import time

import pytest

from terminal import notify, store, config
from terminal.heatmap import alerts


@pytest.fixture(autouse=True)
def fresh(monkeypatch, tmp_path):
    monkeypatch.setattr(notify, "_events", notify.collections.deque(maxlen=notify.MAX_EVENTS))
    monkeypatch.setattr(notify, "_seen", {})
    monkeypatch.setattr(notify, "_queue", None)
    monkeypatch.setattr(notify, "_loop", None)
    monkeypatch.setattr(notify, "_vapid", None)
    monkeypatch.setattr(config, "DATA_DIR", tmp_path)
    store.kv_set(notify.LS_SUBS, {})
    yield


def _b64(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def browser_keys():
    """Kunci yang dibuat browser saat berlangganan push (p256dh + auth) - untuk menguji enkripsi bolak-balik."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    import os
    priv = ec.generate_private_key(ec.SECP256R1())
    pub = priv.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    auth = os.urandom(16)
    return priv, dict(p256dh=_b64(pub), auth=_b64(auth)), auth


def sub_for(i, keys):
    return dict(endpoint=f"https://fcm.googleapis.com/fcm/send/browser-{i}", keys=keys)


# ------------------------------------------------------------------ kejadian
def test_emit_dedups_and_events_since_filters_kinds():
    a = notify.emit("news", "FED HIKES 50BP", key="x1")
    assert a and notify.emit("news", "FED HIKES 50BP", key="x1") is None          # sama -> tidak dikirim ulang
    notify.emit("liq", "BTCUSDT sweep", key="l1")
    assert notify.emit("bogus", "x") is None
    assert [e["kind"] for e in notify.events_since(0, ("news", "liq"))] == ["news", "liq"]
    assert [e["kind"] for e in notify.events_since(0, ("liq",))] == ["liq"]
    assert notify.events_since(time.time() + 1) == []


def test_high_impact_news_rules_and_only_fresh_items():
    now = time.time()
    base = dict(ts=now - 60, source="Reuters", t1=True, fast=False, flash=False, prio="")
    crit = dict(base, id="c", title="Missile strike hits port", prio="CRIT", t1=False)
    high_t1 = dict(base, id="h", title="Fed signals rate hike", prio="HIGH")
    high_low = dict(base, id="hl", title="Fed blog post", prio="HIGH", t1=False)
    flash_fast = dict(base, id="f", title="*POWELL: NO RUSH TO CUT", flash=True, fast=True, t1=False, source="Walter Bloomberg (TG)")
    flash_slow = dict(base, id="fs", title="BREAKING something", flash=True, fast=False, t1=False)
    old = dict(crit, id="old", title="Old missile strike", ts=now - 3600)
    assert notify.on_news([crit, high_t1, high_low, flash_fast, flash_slow, old], now=now) == 3
    titles = [e["title"] for e in notify.events_since(0)]
    assert titles == ["Missile strike hits port", "Fed signals rate hike", "*POWELL: NO RUSH TO CUT"]
    assert notify.events_since(0)[0]["level"] == "high"


def test_news_ingest_triggers_notification_for_new_high_impact_only(monkeypatch):
    from terminal.providers import news
    monkeypatch.setattr(news, "_items", {})
    now = int(time.time())
    it = dict(title="Explosion at refinery halts output", source="Bloomberg Markets", link="l", ts=now - 30, summary="", hints=["MARKETS"], feed="Bloomberg Markets")
    assert news.ingest([dict(it)]) == 1 and len(notify.events_since(0)) == 1
    assert news.ingest([dict(it)]) == 0 and len(notify.events_since(0)) == 1          # judul sama: tidak dobel


def test_signal_journal_new_limit_and_entry_hit():
    from terminal.signals import journal
    plan = dict(entry=1.08345, sl=1.0795, tp=[1.0912, 1.0950, 1.1010], d=1)
    sid = journal.create("EURUSD", "intraday", True, "BUY", int(time.time()), plan)
    journal.update(sid, "PENDING", 0.0, 0)                                           # belum tersentuh: tidak ada kejadian baru
    journal.update(sid, "OPEN", 0.1, 0)                                              # PENDING -> OPEN = entry tersentuh
    journal.update(sid, "OPEN", 0.3, 0)                                              # tetap OPEN: tidak dobel
    ev = notify.events_since(0, ("signal",))
    assert [e["title"] for e in ev] == ["EURUSD BUY LIMIT 1.08345", "EURUSD BUY · ENTRY TERSENTUH 1.08345"]
    assert "SL 1.0795" in ev[0]["body"] and ev[1]["url"] == "/#signal"


# ------------------------------------------------------------------ heatmap: likuiditas besar terambil
def test_big_levels_and_sweep_detection():
    lv = dict(above=[dict(price=110.0, usd=100e3, side="short"), dict(price=112.0, usd=60e3, side="short"), dict(price=115.0, usd=20e3, side="short")],
              below=[dict(price=95.0, usd=80e3, side="long")])
    big = alerts.big_levels(lv)
    assert [(b["price"], b["where"]) for b in big] == [(110.0, "above"), (112.0, "above"), (95.0, "below")]   # 20K < 50% x 100K: bukan besar
    c = lambda t, h, l: [t, 100, h, l, 100]
    assert [b["price"] for b in alerts.swept(big, [c(0, 109, 99), c(3600, 110.5, 99)], since=3601, sec=3600)] == [110.0]
    assert alerts.swept(big, [c(0, 120, 90)], since=7200, sec=3600) == []          # candle sebelum pemeriksaan lalu: diabaikan
    assert [b["price"] for b in alerts.swept(big, [c(3600, 101, 94.9)], since=3700, sec=3600)] == [95.0]


def test_check_pair_first_run_only_records_then_alerts_once(monkeypatch):
    from terminal.heatmap import view
    seq = []
    def lv(price, hi, lo, t):
        return dict(price=price, digits=2, sec=3600, candles=[[t, price, hi, lo, price]],
                    above=[dict(price=62087.5, usd=154e3, side="short")], below=[dict(price=59000.0, usd=90e3, side="long")])
    states = [lv(61900, 61950, 61850, 1000 * 3600), lv(62110, 62150, 61900, 1000 * 3600), lv(62100, 62120, 62000, 1000 * 3600)]
    async def fake(so, tf):
        i = len(seq)
        seq.append(1)
        return states[i]
    monkeypatch.setattr(view, "key_levels", fake)
    monkeypatch.setattr(alerts, "_prev", {})
    t0 = 1000 * 3600 + 100
    assert asyncio.run(alerts.check_pair("BTCUSDT", object(), now=t0)) == 0          # pertama: hanya mencatat level
    assert asyncio.run(alerts.check_pair("BTCUSDT", object(), now=t0 + 30)) == 1     # high 62150 >= 62087.5 -> tersapu
    assert asyncio.run(alerts.check_pair("BTCUSDT", object(), now=t0 + 60)) == 0     # sama -> tidak dobel
    ev = notify.events_since(0, ("liq",))[0]
    assert "BTCUSDT" in ev["title"] and "$154K" in ev["title"] and "62,087.50" in ev["body"] and ev["url"] == "/#heatmap"


# ------------------------------------------------------------------ langganan per browser & pengiriman
def test_subscriptions_are_per_browser_and_by_kind(monkeypatch):
    _, k1, _ = browser_keys()
    _, k2, _ = browser_keys()
    s1 = notify.subscribe(sub_for(1, k1), ["news", "signal"], "admin")
    s2 = notify.subscribe(sub_for(2, k2), ["liq"], "user")
    assert s1 != s2 and notify.status()["subscribers"] == 2 and {k: v for k, v in notify.status()["by_kind"].items() if v} == {"liq": 1, "news": 1, "signal": 1}
    with pytest.raises(ValueError):
        notify.subscribe(dict(endpoint="http://insecure", keys=k1), ["news"], "user")
    sent = []
    monkeypatch.setattr(notify, "push_available", lambda: True)
    monkeypatch.setattr(notify, "_send_one", lambda sub, payload, ttl=3600: sent.append((sub["endpoint"], payload["kind"])) or 201)
    ev = notify.emit("liq", "ETHUSDT sweep", key="e")
    assert asyncio.run(notify._deliver(ev)) == 1 and sent == [("https://fcm.googleapis.com/fcm/send/browser-2", "liq")]   # hanya browser 2
    sent.clear()
    assert asyncio.run(notify._deliver(notify.emit("news", "War", key="w"))) == 1 and sent[0][0].endswith("browser-1")
    assert notify.unsubscribe(sub_for(1, k1)["endpoint"]) and notify.status()["subscribers"] == 1


def test_expired_subscription_is_removed(monkeypatch):
    _, k, _ = browser_keys()
    notify.subscribe(sub_for(9, k), ["news"], "user")
    monkeypatch.setattr(notify, "push_available", lambda: True)
    monkeypatch.setattr(notify, "_send_one", lambda *a, **kw: 410)
    asyncio.run(notify._deliver(notify.emit("news", "x", key="z")))
    assert notify.status()["subscribers"] == 0 and notify._state["removed"] >= 1


def test_web_push_payload_is_decryptable_by_the_browser(monkeypatch):
    """Enkripsi aes128gcm (RFC 8291) + VAPID: payload yang dikirim pywebpush dapat dibuka dengan kunci browser."""
    pytest.importorskip("pywebpush")
    import http_ece
    import pywebpush
    priv, keys, auth = browser_keys()
    v = notify.vapid()
    assert v and len(base64.urlsafe_b64decode(v["public"] + "==")) == 65                # kunci publik P-256 tak terkompresi
    assert (config.DATA_DIR / "webpush_vapid.json").exists() and notify.vapid() is v
    captured = {}

    class Resp:
        status_code = 201
        text = ""
        headers = {}

    def fake_post(url, data=None, headers=None, timeout=None, **kw):
        captured.update(url=url, data=data, headers=headers)
        return Resp()
    monkeypatch.setattr(pywebpush.requests, "post", fake_post)
    payload = dict(id="abc", kind="news", title="FED HIKES", body="Reuters · CRIT", url="/#intel", level="high", ts=1.0)
    assert notify._send_one(sub_for(1, keys), payload) == 201
    h = {k.lower(): v for k, v in captured["headers"].items()}
    assert h["content-encoding"] == "aes128gcm" and h["ttl"] == "3600" and h["urgency"] == "high"
    assert h["authorization"].startswith("vapid t=") and f"k={v['public']}" in h["authorization"]
    plain = http_ece.decrypt(captured["data"], private_key=priv, auth_secret=auth, version="aes128gcm")
    assert json.loads(plain) == payload


# ------------------------------------------------------------------ HTTP
def test_notify_routes(client):
    k = client.get("/api/notify/key").json()
    assert k["kinds"] == ["news", "squawk", "calendar", "rates", "curve", "signal", "liq"] and (k["public"] is None or len(k["public"]) > 80)
    _, keys, _ = browser_keys()
    r = client.post("/api/notify/subscribe", json=dict(subscription=sub_for(5, keys), kinds=["news", "bogus"])).json()
    assert r["ok"] and store.kv_get(notify.LS_SUBS)[r["id"]]["kinds"] == ["news"]
    assert client.post("/api/notify/subscribe", json=dict(subscription={"endpoint": "x"})).status_code == 422
    t0 = client.get("/api/notify/events").json()
    assert t0["events"] == [] and t0["now"] > 0
    notify.emit("news", "Test event", key="t")
    got = client.get("/api/notify/events", params=dict(since=t0["now"] - 1, kinds="news")).json()["events"]
    assert "Test event" in [e["title"] for e in got] and all(e["kind"] == "news" for e in got)
    assert client.post("/api/notify/unsubscribe", json=dict(endpoint=sub_for(5, keys)["endpoint"])).json()["ok"]


def test_service_worker_and_icon_public_without_key(monkeypatch):
    from terminal import auth
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ACCESS_KEY", "rahasia-123")
    auth._cache.clear()
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app) as c:
        sw = c.get("/sw.js")
        assert sw.status_code == 200 and "showNotification" in sw.text and "javascript" in sw.headers["content-type"]
        assert c.get("/vendor/notify-icon.png").status_code == 200
        assert c.get("/v_notify.js").status_code == 401 and c.get("/api/notify/key").status_code == 401



# ------------------------------------------------------------------ pusat notifikasi: semua update terminal
def test_emit_levels_say_and_lang():
    ev = notify.emit("curve", "Yield 10Y", key="lv1", level="normal", say="Yield naik", lang="id")
    assert ev["level"] == "medium" and ev["say"] == "Yield naik" and ev["lang"] == "id"
    assert notify.emit("rates", "x", key="lv2", level="bogus")["level"] == "medium"
    assert notify.emit("news", "Fed hikes", key="lv3")["say"] == "Fed hikes"                # default: judul dibacakan
    assert notify.say_num(1.08345) == "1,08345" and notify.say_num(4.25, 2) == "4,25" and notify.say_num(-0.5, 2) == "minus 0,5"


def test_fast_headlines_become_squawk_with_levels_and_english_voice():
    now = time.time()
    base = dict(ts=now - 30, source="FinancialJuice", t1=False, fast=True, flash=False, prio="")
    items = [dict(base, id="a", title="US 10Y yield up 3bp"), dict(base, id="b", title="*BREAKING: ECB HIKES 50BP", flash=True),
             dict(base, id="c", title="Missile strike on tanker", prio="CRIT"),
             dict(base, id="d", title="Harga minyak naik karena pasokan dari Timur Tengah turun", source="CNBC Indonesia")]
    assert notify.on_news(items, now=now) == 4
    ev = {e["title"]: e for e in notify.events_since(0, ("squawk",))}
    assert ev["US 10Y yield up 3bp"]["level"] == "low" and ev["*BREAKING: ECB HIKES 50BP"]["level"] == "medium"
    assert ev["Missile strike on tanker"]["level"] == "high"
    assert ev["*BREAKING: ECB HIKES 50BP"]["say"] == "ECB HIKES 50BP" and ev["*BREAKING: ECB HIKES 50BP"]["lang"] == "en"
    assert ev["Harga minyak naik karena pasokan dari Timur Tengah turun"]["lang"] == "id"
    assert notify.events_since(0, ("news",)) == []                                      # tidak dobel sebagai 'news'


def _watch(monkeypatch):
    from terminal import notify_watch as W
    W.reset()
    store.kv_set(W.KV, {})
    W._load()["started"] = time.time() - 3600
    return W


def test_calendar_pre_release_and_actual_vs_forecast(monkeypatch):
    W = _watch(monkeypatch)
    import datetime as dt
    now = time.time()
    when = dt.datetime.fromtimestamp(now + 10 * 60, dt.timezone.utc).strftime("%Y-%m-%d %H:%M")
    ev = dict(date=when, cc="US", cur="USD", event="CPI YoY", impact="HIGH", actual=None, forecast=3.1, previous=3.0, unit="%")
    low = dict(ev, event="Redbook", impact="LOW")
    assert W.calendar_check([ev, low], now) == 1
    pre = notify.events_since(0, ("calendar",))[-1]
    assert pre["level"] == "high" and "menit lagi" in pre["title"] and "Perkiraan 3,1 persen" in pre["say"]
    assert W.calendar_check([ev], now + 30) == 0                                          # tidak dobel
    later = now + 11 * 60
    done = dict(ev, actual=3.3)
    assert W.calendar_check([done], later) == 1
    rel = notify.events_since(0, ("calendar",))[-1]
    assert "3.3%" in rel["title"] and "di atas perkiraan" in rel["body"] and "3,3 persen" in rel["say"]
    mod = dict(done, event="Retail Sales MoM", impact="MODERATE", actual=-0.2, forecast=0.1)
    assert W.calendar_check([mod], later) == 1 and notify.events_since(0, ("calendar",))[-1]["level"] == "medium"
    assert "di bawah perkiraan" in notify.events_since(0, ("calendar",))[-1]["body"]


def test_calendar_old_release_at_startup_is_baseline_only(monkeypatch):
    W = _watch(monkeypatch)
    W._load()["started"] = time.time()
    import datetime as dt
    now = time.time()
    old = dict(date=dt.datetime.fromtimestamp(now - 3600, dt.timezone.utc).strftime("%Y-%m-%d %H:%M"), cc="GB", event="GDP", impact="HIGH",
               actual=0.2, forecast=0.1, previous=0.0, unit="%")
    assert W.calendar_check([old], now) == 0


def test_rates_and_curve_changes_from_to(monkeypatch):
    W = _watch(monkeypatch)
    row = dict(cc="ID", name="INDONESIA", cb="Bank Indonesia", policy=6.0, y10=6.80, curve=40.0, curve_label="2s10s")
    assert W.rates_check([row]) == 0                                                      # pengamatan pertama = acuan
    assert W.rates_check([dict(row, y10=6.85)]) == 0                                      # +5 bp: belum
    assert W.rates_check([dict(row, policy=5.75, y10=6.95, curve=-5.0)]) == 3
    ev = notify.events_since(0, ("rates", "curve"))
    pol = next(e for e in ev if e["kind"] == "rates")
    assert pol["level"] == "high" and "6.00% → 5.75%" in pol["title"] and "menurunkan suku bunga dari 6 persen ke 5,75 persen" in pol["say"]
    y = next(e for e in ev if e["title"].startswith("Yield 10Y"))
    assert "6.80% → 6.95%" in y["title"] and y["level"] == "medium" and "15 basis poin" in y["say"]
    c = next(e for e in ev if e["title"].startswith("Kurva"))
    assert c["level"] == "high" and "terbalik" in c["body"]
    assert W.rates_check([dict(row, policy=5.75, y10=6.96, curve=-6.0)]) == 0           # acuan sudah diperbarui: tidak dobel


def test_signal_results_from_both_journals_are_notified(monkeypatch):
    W = _watch(monkeypatch)
    assert W.signals_check() == 0                                                         # pertama kali: mulai dari sekarang
    t = time.time() + 1
    store.execute("INSERT INTO signal_log(sym, mode, be, side, created, bar_ts, plan, status, r, tp_hits, closed) VALUES('EURUSD','intraday',1,'BUY',?,?,'{}','TP2',1.8,2,?)", (t, "x", t))
    store.execute("INSERT INTO one_log(key, sym, mode, type, side, created, bar_ts, plan, status, r, closed) VALUES('k-sl','Gold','scalp','A','SELL',?,'x','{}','SL',-1.0,?)", (t, t))
    store.execute("INSERT INTO one_log(key, sym, mode, type, side, created, bar_ts, plan, status, r, closed) VALUES('k-c','US500','scalp','C','BUY',?,'x','{}','CANCEL',0,?)", (t, t))
    assert W.signals_check(now=t + 5) == 3
    ev = {e["title"].split(" ")[0]: e for e in notify.events_since(0, ("signal",))}
    assert ev["EURUSD"]["level"] == "good" and "+1.80R" in ev["EURUSD"]["title"] and "plus 1,8 R" in ev["EURUSD"]["say"]
    assert ev["Gold"]["level"] == "high" and "Strategi ONE" in ev["Gold"]["body"]
    assert ev["US500"]["level"] == "low"
    assert W.signals_check(now=t + 10) == 0
    store.execute("DELETE FROM signal_log"); store.execute("DELETE FROM one_log")



# ------------------------------------------------------------------ per pengguna: tiap browser/peran punya pengaturan sendiri
def test_push_goes_only_to_browsers_that_chose_kind_and_level(monkeypatch):
    k = dict(p256dh="BPx", auth="ax")
    a = notify.subscribe(sub_for(11, k), ["squawk", "signal"], "user", "high")      # user 1: squawk & sinyal, hanya TINGGI
    b = notify.subscribe(sub_for(12, k), ["calendar"], "admin", "low")              # admin: kalender saja, semua tingkat
    # user 2 tidak mengaktifkan apa pun -> tidak punya langganan
    assert notify.status()["by_role"] == {"user": 1, "admin": 1}
    assert notify.subscription(sub_for(11, k)["endpoint"]) == dict(kinds=["squawk", "signal"], min="high", role="user")
    sent = []
    monkeypatch.setattr(notify, "push_available", lambda: True)
    monkeypatch.setattr(notify, "vapid", lambda: {"private_b64": "x", "public": "y"})
    monkeypatch.setattr(notify, "_send_one", lambda sub, payload, ttl=3600: sent.append(sub["endpoint"].rsplit("/", 1)[-1]) or 201)
    assert asyncio.run(notify._deliver(notify.emit("squawk", "biasa", key="s-low", level="low"))) == 0           # di bawah tingkat user 1
    assert asyncio.run(notify._deliver(notify.emit("squawk", "kritis", key="s-high", level="high"))) == 1 and sent == ["browser-11"]
    assert asyncio.run(notify._deliver(notify.emit("calendar", "CPI", key="c1", level="medium"))) == 1 and sent[-1] == "browser-12"
    assert asyncio.run(notify._deliver(notify.emit("news", "berita", key="n1", level="high"))) == 0               # tidak ada yang memilih
    notify.subscribe(sub_for(11, k), ["squawk"], "user", "low")                       # user 1 mengubah pengaturannya
    assert asyncio.run(notify._deliver(notify.emit("squawk", "biasa 2", key="s-low2", level="low"))) == 1 and sent[-1] == "browser-11"
    assert notify.subscription(sub_for(12, k)["endpoint"])["min"] == "low"           # pengaturan admin tidak ikut berubah
