"""Uji UI Chromium: MARKET INTELLIGENCE -> Catalyst Map (layar penuh) dan GEOPOLITICAL RISK -> globe 3D.

    MOCK_KEYS=1 python tests/run_mock_server.py 8765 &   lalu:   python tests/ui_map_globe_check.py ./shots
    (BASE=http://127.0.0.1:8766 untuk server lain; PW_CHROMIUM=<path chrome> bila Chromium Playwright tidak dipakai)
"""
import os
import sys

from playwright.sync_api import sync_playwright

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
BASE = os.environ.get("BASE", "http://127.0.0.1:8765")
KEY = os.environ.get("ADMIN_KEY_TEST", "admin-test")
ok = []


def check(name, cond, info=""):
    ok.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name, info)


STATE = """({mode:document.querySelector('.cmap')?.dataset.mode,cat:document.querySelectorAll('.cm-cat').length,ins:document.querySelectorAll('.cm-ins').length,
  lanes:document.querySelectorAll('.cm-lane').length,links:document.querySelectorAll('.cm-l').length,hscroll:document.documentElement.scrollWidth>innerWidth+1,
  detail:!!document.querySelector('.cm-detail:not(.min)'),
  covered:(()=>{const d=document.querySelector('.cmap[data-mode=wide] .cm-detail:not(.min)');if(!d)return false;const r=d.getBoundingClientRect();
    return [...document.querySelectorAll('.cm-ins')].some(e=>e.getBoundingClientRect().right>r.left+1)})()})"""

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
    # ---------------- Catalyst Map ----------------
    ctx = b.new_context(viewport={"width": 1600, "height": 940}); pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(BASE + f"/?key={KEY}#intel"); pg.wait_for_timeout(2500)
    pg.click(".tabs button[data-id='map']"); pg.wait_for_timeout(3500)
    st = pg.evaluate(STATE)
    check("cmap: layar lebar -> 4 kolom terisi", st["mode"] == "wide" and st["cat"] > 0 and st["ins"] > 0 and st["links"] > st["cat"], st)
    check("cmap: panel detail tidak menutupi kolom instrumen", st["detail"] and not st["covered"], st)
    h = pg.evaluate("document.querySelector('.cmap').getBoundingClientRect().bottom")
    check("cmap: mengisi tinggi layar", h > 900, h)
    pg.hover(".cm-imp .hub >> nth=0", force=True); pg.wait_for_timeout(300)
    hl = pg.evaluate("({hl:document.querySelector('.cm-svg').classList.contains('hl'),on:document.querySelectorAll('.cm-n.on').length,all:document.querySelectorAll('.cm-n').length})")
    check("cmap: sorot dampak -> jalurnya menyala, sisanya redup", hl["hl"] and 0 < hl["on"] < hl["all"], hl)
    pg.screenshot(path=os.path.join(OUT, "cmap_hover.png"))
    n = pg.locator(".cm-cat").count()
    pg.click(f".cm-cat >> nth={n - 1}", force=True); pg.mouse.move(3, 3); pg.wait_for_timeout(400)
    title = pg.evaluate(f"document.querySelectorAll('.cm-cat')[{n - 1}].querySelector('.t1').textContent")
    dt = pg.locator(".cm-dt").text_content()
    check("cmap: klik katalis -> panel detail katalis itu", dt and title.rstrip("…")[:10] == dt[:10], (title, dt))
    check("cmap: headline pemicu tampil", pg.locator(".cm-detail .cm-hl").count() > 0)
    pg.click(".cm-x"); pg.wait_for_timeout(600)
    st2 = pg.evaluate(STATE)
    check("cmap: tutup panel -> peta melebar & tetap tergambar", not st2["detail"] and st2["cat"] == st["cat"], st2)
    pg.screenshot(path=os.path.join(OUT, "cmap_wide.png"))
    check("cmap: tanpa error JS", not errs, errs[:3])
    ctx.close()
    m = b.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True); mp = m.new_page(); merr = []
    mp.on("pageerror", lambda e: merr.append(str(e)))
    mp.goto(BASE + f"/?key={KEY}#intel"); mp.wait_for_timeout(2500)
    mp.click(".tabs button[data-id='map']"); mp.wait_for_timeout(3000)
    st = mp.evaluate(STATE)
    check("cmap ponsel: kartu jalur, tanpa scroll horizontal", st["mode"] == "narrow" and st["lanes"] > 0 and not st["hscroll"], st)
    mp.locator(".cm-lane").nth(0).tap(); mp.wait_for_timeout(400)
    check("cmap ponsel: ketuk kartu -> detail terbuka di dalamnya", mp.locator(".cm-lane.sel .cm-detail:not(.min) .cm-dt").count() == 1)
    mp.screenshot(path=os.path.join(OUT, "cmap_phone.png"))
    check("cmap ponsel: tanpa error JS", not merr, merr[:3])
    m.close()

    # ---------------- Globe 3D ----------------
    ctx = b.new_context(viewport={"width": 1600, "height": 940}); pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(BASE + f"/?key={KEY}#geo"); pg.wait_for_timeout(6000)
    bb = pg.locator(".gl-cv").bounding_box()
    check("globe: kanvas tampil", bb and bb["width"] > 500 and bb["height"] > 400, bb)
    check("globe: d3-geo dimuat dari vendor lokal", pg.evaluate("[...document.scripts].some(s=>s.src.includes('vendor/d3-geo.min.js'))&&!!(window.d3&&d3.geoOrthographic)"))
    lit = pg.evaluate("(()=>{const c=document.querySelector('.gl-cv'),d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;for(let i=0;i<d.length;i+=4*97)if(d[i]+d[i+1]+d[i+2]>60)n++;return n})()")
    check("globe: tergambar", lit > 300, lit)
    pg.mouse.move(3, 3); pg.wait_for_timeout(1200)
    perf = pg.evaluate("""new Promise(r=>{const g=T._globe,n0=g.stats.n;let a=0,c=0;const t0=performance.now();const f=()=>{a+=g.stats.ms;c++;if(performance.now()-t0<2000)requestAnimationFrame(f);else r({avg:+(a/c).toFixed(1),fps:(g.stats.n-n0)/2})};f()})""")
    check("globe: berputar otomatis, waktu gambar < 33 ms", perf["avg"] < 33 and perf["fps"] >= 10, perf)
    cx, cy = bb["x"] + bb["width"] / 2, bb["y"] + bb["height"] / 2
    pg.click(".gl-b[title*='otomatis']"); pg.wait_for_timeout(300)
    a = pg.screenshot(clip=bb)
    pg.mouse.move(cx, cy); pg.mouse.down(); pg.mouse.move(cx + 220, cy + 50, steps=10); pg.mouse.up(); pg.wait_for_timeout(900)
    check("globe: seret memutar", a != pg.screenshot(clip=bb))
    k0 = pg.evaluate("T._globe.k"); pg.mouse.move(cx, cy); pg.mouse.wheel(0, -500); pg.wait_for_timeout(300); k1 = pg.evaluate("T._globe.k")
    check("globe: roda mouse memperbesar", k1 > k0 * 1.5, (k0, k1))
    pg.click(".gl-b[title='Perkecil']"); pg.wait_for_timeout(200)
    check("globe: tombol perkecil", pg.evaluate("T._globe.k") < k1)
    pg.click(".gl-b[title='Atur ulang']"); pg.wait_for_timeout(1100)
    check("globe: atur ulang -> zoom 1", abs(pg.evaluate("T._globe.k") - 1) < 1e-6)
    tip = None
    for dx in range(-240, 241, 40):
        for dy in range(-200, 201, 40):
            pg.mouse.move(cx + dx, cy + dy); pg.wait_for_timeout(50)
            if pg.evaluate("document.querySelector('.gl-tip').classList.contains('on')"):
                tip = pg.locator(".gl-tip").inner_text(); break
        if tip:
            break
    check("globe: tooltip saat diarahkan", bool(tip), (tip or "")[:80].replace("\n", " | "))
    pg.screenshot(path=os.path.join(OUT, "globe.png"))
    if pg.locator("#view .feed").count():
        s1 = pg.screenshot(clip=bb); pg.hover("#view .feed >> nth=0"); pg.wait_for_timeout(1200)
        check("globe: arahkan ke berita -> berputar ke lokasi event", s1 != pg.screenshot(clip=bb) and pg.evaluate("T._globe.k") >= 2.3)
    # 4 layer di atas globe (satu-satunya pemilih: tab lama Geo Map / Maritime sudah dihapus)
    check("globe: tanpa tab ganda di atas panel", pg.locator("#view .tabs").count() == 0 and pg.locator(".gl-lb").count() == 4)
    for lid, need in [("sea", "kapal"), ("air", "PESAWAT MILITER"), ("cyber", "KORBAN RANSOMWARE"), ("risk", "TOP COUNTRY RISK")]:
        pg.click(f".gl-lb[data-id='{lid}']"); pg.wait_for_timeout(3500)
        st = pg.evaluate("({on:document.querySelector('.gl-lb.on').dataset.id,feed:document.querySelectorAll('.panel')[1].innerText.slice(0,400),lgd:document.querySelectorAll('.lgd').length})")
        check(f"layer {lid}: aktif, panel kanan & legenda sesuai", st["on"] == lid and need.lower() in st["feed"].lower() and st["lgd"] >= 2, st["feed"][:80].replace("\n", " | "))
        pg.screenshot(path=os.path.join(OUT, f"globe_layer_{lid}.png"))
    pg.evaluate("location.hash='#dashboard'"); pg.wait_for_timeout(800)
    n0 = pg.evaluate("T._globe.stats.n"); pg.wait_for_timeout(800)
    check("globe: loop berhenti saat menu ditinggalkan", pg.evaluate("T._globe.stats.n") == n0)
    check("globe: tanpa error JS", not errs, errs[:3])
    ctx.close()
    m = b.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True); mp = m.new_page(); merr = []
    mp.on("pageerror", lambda e: merr.append(str(e)))
    mp.goto(BASE + f"/?key={KEY}#geo"); mp.wait_for_timeout(6000)
    mb = mp.locator(".gl-cv").bounding_box()
    check("globe ponsel: tampil tanpa scroll horizontal", mb and mb["width"] > 300 and mp.evaluate("document.documentElement.scrollWidth<=innerWidth+1"), mb)
    mp.screenshot(path=os.path.join(OUT, "globe_phone.png"))
    check("globe ponsel: tanpa error JS", not merr, merr[:3])
    m.close()
    b.close()
print(f"{sum(ok)}/{len(ok)} lulus")
sys.exit(0 if all(ok) else 1)
