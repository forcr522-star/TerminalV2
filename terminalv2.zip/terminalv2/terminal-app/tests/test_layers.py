"""Uji: globe 4 layer (GDELT 2.0, pesawat militer, siber, insiden maritim), thread pool DNS, perdagangan BACI, seri FRED."""
import asyncio
import concurrent.futures as cf
import contextvars
import io
import socket
import time
import zipfile

import pytest

from terminal import threads
from terminal.providers import gdelt, geo, airtraffic, cyber, trade, macro


def run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


# ------------------------------------------------------------------ "sumber bermasalah": DNS antre di thread pool
def test_dns_not_starved_by_long_blocking_calls():
    """Pool bawaan kecil yang penuh unduhan lama dulu membuat DNS antre -> ConnectTimeout serentak. Kini tidak."""
    async def main(install):
        loop = asyncio.get_running_loop()
        loop.set_default_executor(cf.ThreadPoolExecutor(max_workers=4))          # mirip RDP 2 core (bawaan: min(32, core+4))
        if install:
            threads._installed.discard(id(loop))
            threads.install(loop)
            hogs = [asyncio.ensure_future(threads.net(time.sleep, 3)) for _ in range(6)]   # unduhan panjang di pool jaringan
        else:
            hogs = [asyncio.ensure_future(asyncio.to_thread(time.sleep, 3)) for _ in range(6)]
        await asyncio.sleep(0.1)
        t = time.perf_counter()
        try:
            await asyncio.wait_for(loop.getaddrinfo("localhost", 443, type=socket.SOCK_STREAM), 1.0)
            ok = True
        except asyncio.TimeoutError:
            ok = False
        dt_ = time.perf_counter() - t
        for h in hogs:
            h.cancel()
        return ok, dt_
    starved, _ = asyncio.run(main(False))
    fine, took = asyncio.run(main(True))
    assert starved is False                     # gejala lama: resolusi DNS tidak selesai dalam batas waktu
    assert fine is True and took < 0.5          # sesudah perbaikan: langsung


def test_net_pool_keeps_context_and_result():
    var = contextvars.ContextVar("v", default="-")

    async def main():
        var.set("ok")
        return await threads.net(lambda a, b=0: (var.get(), a + b), 2, b=3)
    assert asyncio.run(main()) == ("ok", 5)


def test_fred_gdp_series_id_fixed():
    src = open(macro.__file__, encoding="utf-8").read()
    assert "A191RL1Q225SBEA" in src and "A191RL1Q225SBP" not in src                # dulu salah ketik -> 404 berulang


# ------------------------------------------------------------------ GDELT 2.0 (pengganti GEO API yang 404)
def _gdelt_zip(rows):
    lines = []
    for root, geotype, lat, lon, name, mentions in rows:
        c = [""] * 61
        c[0], c[28], c[29], c[31], c[51], c[52], c[53], c[56], c[57], c[60] = "1", root, "4", str(mentions), geotype, name, "XX", str(lat), str(lon), "https://example.org/a"
        lines.append("\t".join(c))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("x.export.CSV", "\n".join(lines))
    return buf.getvalue()


def test_gdelt_export_keeps_specific_conflict_events_only():
    raw = _gdelt_zip([("19", "4", 50.45, 30.52, "Kyiv, Ukraine", 12),        # pertempuran di kota -> ambil
                      ("19", "1", 49.0, 32.0, "Ukraine", 30),              # titik tengah NEGARA -> buang
                      ("04", "4", 51.5, -0.1, "London", 9),                # konsultasi (bukan konflik) -> buang
                      ("14", "3", 40.7, -74.0, "New York", 5)])            # protes -> ambil
    ev = gdelt.parse_export(raw)
    assert [e["name"] for e in ev] == ["Kyiv, Ukraine", "New York"] and ev[0]["mentions"] == 12 and ev[0]["root"] == "19"


def test_gdelt_alone_cannot_make_a_country_high_or_critical():
    hot = [dict(lat=38.9 + i * 0.01, lon=-77.0, count=40) for i in range(200)]   # ratusan titik berisik di AS
    rm = geo.risk_map([], hot)
    assert rm["United States of America"]["level"] in ("LOW", "ELEVATED")
    now = time.time()
    evs = [dict(lat=31.4, lon=34.4, place="Gaza", ts=now, sev="CRITICAL", cat="ARMED CONFLICT", title="t", source="s", link="#")] * 4
    assert geo.risk_map(evs, hot)["Palestine"]["level"] in ("HIGH", "CRITICAL")     # berita terverifikasi tetap menentukan


# ------------------------------------------------------------------ AIRPLANE (adsb.lol)
def test_military_aircraft_layer(monkeypatch):
    now = time.time()

    async def fake(url, **kw):
        assert url == airtraffic.URL
        return dict(now=now * 1000, ac=[
            dict(hex="a1", flight="RCH123 ", t="C17", lat=50.0, lon=20.0, alt_baro=31000, gs=450, track=90, seen=1.2, squawk="1200"),
            dict(hex="a2", flight="HOMER1", t="R135", lat=44.0, lon=33.0, alt_baro="ground", gs=0, track=None, seen=4, squawk="7700"),
            dict(hex="a3", flight="OLD", t="K35R", lat=10.0, lon=10.0, seen=900),          # posisi > 5 menit -> buang
            dict(hex="a4", flight="NOPOS", t="F16")])                                       # tanpa posisi -> buang
    monkeypatch.setattr(airtraffic, "get_json", fake)
    d = run(airtraffic.military.__wrapped__())                          # tanpa cache: langsung fungsi aslinya
    assert d["total"] == 2 and {a["hex"] for a in d["aircraft"]} == {"a1", "a2"}
    a2 = next(a for a in d["aircraft"] if a["hex"] == "a2")
    assert a2["role"] == "ISR" and a2["alt"] == 0 and a2["emergency"] and d["emergencies"][0]["hex"] == "a2"
    assert d["roles"] == {"TRANSPORT": 1, "ISR": 1}
    assert "Black Sea" in [r["name"] for r in d["regions"]]
    assert airtraffic.POLL_SEC >= 120                                   # batas gratis 500 permintaan/hari


# ------------------------------------------------------------------ CYBER (ransomware.live + berita)
def test_ransomware_victims_mapped_without_onion_links(monkeypatch):
    async def fake(url, **kw):
        return [dict(victim="Acme", group="play", country="DE", description="manufacturing · Germany | x", discovered="2026-11-25T10:00:00+00:00",
                     url="https://www.ransomware.live/id/abc", claim_url="http://xyz.onion"),
                dict(victim="Beta", group="akira", country="", description="", discovered="2026-11-25T12:00:00+00:00", url="http://evil.onion/x")]
    monkeypatch.setattr(cyber, "get_json", fake)
    v = run(cyber.ransomware.__wrapped__())
    assert [x["victim"] for x in v] == ["Beta", "Acme"]                  # terbaru dulu
    acme = v[1]
    assert acme["country"] == "Germany" and acme["sector"] == "manufacturing" and acme["link"] == "https://www.ransomware.live/id/abc"
    assert v[0]["link"] is None and v[0]["lat"] is None                  # tautan .onion tidak pernah diteruskan


@pytest.mark.parametrize("title,hit", [
    ("Hackers breach CIA intelligence network in latest US cyberattack", True),
    ("US Treasury financial crime watchdog hit by suspected cyber attack", True),
    ("We Tried Out Pirelli's Smart Cyber Tire", False),
    ("US warns Kim Ju-ae's ski gear may breach UN sanctions on North Korea", False),
    ("More than 490,000 Russian soldiers have died, leaked data suggests", False),
])
def test_cyber_keywords(title, hit):
    assert bool(cyber._KW_RE.search(title)) is hit


def test_cyber_iso2_names_exist_on_globe():
    import json
    from terminal.config import WEB_DIR
    names = {f["properties"]["n"] for f in json.load(open(WEB_DIR / "vendor" / "world.geojson", encoding="utf-8"))["features"]}
    assert all(v[0] in names for v in cyber.ISO2.values())


# ------------------------------------------------------------------ MARITIME (insiden dari berita)
def test_maritime_incidents_keywords_and_location(monkeypatch):
    now = time.time()
    items = [dict(id=str(i), title=t, source="s", link="#", ts=now - i, prio="HIGH", cats=[]) for i, t in enumerate([
        "Third tanker hits mine in Strait of Hormuz, Iran says",
        "Democrats Press Navy Nominee Over Iran War's Toll on Sailors",
        "Saylor says Strategy plans to buy all Bitcoin left to be mined",
        "Thirty-one killed in massive fire as fuel tanker crashes on Cairo highway"])]
    monkeypatch.setattr(geo.N, "all_items", lambda secs: items)
    ev = geo.maritime_events()
    assert [e["title"][:12] for e in ev] == ["Third tanker", "Democrats Pr"]
    assert ev[0]["place"] == "Strait of Hormuz" and ev[1]["place"] == "Iran"            # "iran" tidak lagi dipetakan ke Hormuz


def test_locate_one_requires_unambiguous_place():
    assert geo.locate_one("Missile strike hits Kyiv")[0] == "kyiv"
    assert geo.locate_one("Libya rages at Ukraine over ship strike")[0] is None       # dua tempat -> tidak ditaruh di globe


# ------------------------------------------------------------------ SUPPLY CHAIN (BACI/OEC)
def test_partner_codes_stable_across_export_and_import_lists():
    assert trade.code_of("eufra") == 250 and trade.code_of("asind") == 699
    assert trade.code_of("asyem") == trade.code_of("asyem") < 0 and trade.code_of("asyem") != trade.code_of("askwt")


def test_pair_works_for_any_partner_and_euro_area(monkeypatch):
    import mockworld
    monkeypatch.setattr(trade, "_query", mockworld.oec_query)

    async def main():
        x = await trade.pair("CN", 0, "eufra")                 # France: dulu selalu "—"
        eu = await trade.overview("EU", "X")
        return x, eu
    x, eu = run(main())
    assert x["exports"] > 0 and x["imports"] > 0 and len(x["trend"]) == 5 and x["top_exports"] and x["ex_rank"]
    assert x["partner_import_share"] is not None and x["asym_exports"] is not None
    members = set(trade.EA20)
    assert eu["partners"] and not any(p["oid"] in members for p in eu["partners"])     # perdagangan extra-euro area
