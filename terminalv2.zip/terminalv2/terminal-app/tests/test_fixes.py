"""Pengujian perbaikan v2: lelang, sumber cadangan, status sumber, retail sentiment, sembunyikan data kosong. Tanpa jaringan."""
import datetime as dt
import json
import pytest

import mockworld
from terminal import http as H, health
from terminal.providers import auctions, annual, myfxbook, rates, yields


# ------------------------------------------------------------------ parser lelang
def test_parse_fd_upcoming_and_history():
    up = auctions.parse_fd_upcoming([{"auction_date": "2026-11-12", "security_term": "10-Year", "security_type": "Note", "offering_amt": "39000000000", "issue_date": "2026-11-16", "reopening": "No"},
                                     {"auction_date": None}])
    assert len(up) == 1 and up[0]["name"] == "10-Year Note" and up[0]["amount"] == 39e9 and up[0]["status"] == "upcoming"
    hi = auctions.parse_fd_history([{"auction_date": "2026-11-03T00:00:00", "security_term": "30-Year", "security_type": "Bond", "high_yield": "4.612", "bid_to_cover_ratio": "2.41", "offering_amt": "25000000000"},
                                    {"auction_date": "2026-11-02", "security_term": "13-Week", "security_type": "Bill", "high_yield": "null", "high_discnt_rate": "3.9", "bid_to_cover_ratio": "3.1"}])
    assert hi[0]["rate"] == 4.612 and hi[0]["btc"] == 2.41 and hi[0]["status"] == "done"
    assert hi[1]["rate"] == 3.9  # jatuh ke kolom alternatif


def test_parse_td_uses_camelcase():
    r = auctions.parse_td([{"auctionDate": "2026-11-03T00:00:00", "securityTerm": "2-Year", "securityType": "Note", "highYield": "3.95", "bidToCoverRatio": "2.6", "offeringAmount": "69000000000"}], "done")
    assert r[0]["rate"] == 3.95 and r[0]["btc"] == 2.6 and r[0]["src"] == "TreasuryDirect"
    r = auctions.parse_td([{"auctionDate": "2026-12-01", "securityTerm": "2-Year", "securityType": "Note", "highYield": "3.95"}], "upcoming")
    assert r[0]["rate"] is None  # jadwal tidak boleh membawa angka hasil


def test_parse_tv_splits_upcoming_and_done_and_ignores_other_events():
    now = dt.datetime(2026, 11, 6, 12, 0, tzinfo=dt.timezone.utc)
    res = [
        {"title": "10-Year JGB Auction", "country": "JP", "date": "2026-11-10T03:35:00Z", "actual": None, "forecast": None, "previous": 0.95},
        {"title": "30-Year JGB Auction", "country": "JP", "date": "2026-11-02T03:35:00Z", "actual": 2.4, "previous": 2.3, "unit": "%"},
        {"title": "CPI YoY", "country": "JP", "date": "2026-11-03T00:00:00Z", "actual": 3.0},
        {"title": "Old Auction no result", "country": "JP", "date": "2026-10-01T00:00:00Z", "actual": None},
        {"title": "Bund Auction", "country": None, "date": "2026-11-10T00:00:00Z"},
        {"title": "Gilt Auction", "country": "GB", "date": "bukan-tanggal"},
    ]
    out = auctions.parse_tv(res, now=now)
    assert set(out) == {"JP"} and [r["status"] for r in out["JP"]] == ["upcoming", "done"]
    assert out["JP"][1]["rate"] == 2.4 and out["JP"][1]["unit"] == "%"


def test_parse_ff_yield_and_btc():
    now = dt.datetime(2026, 11, 6, 12, 0, tzinfo=dt.timezone.utc)
    out = auctions.parse_ff([{"event": "10-y Bond Auction", "cc": "GB", "date": "2026-11-05 09:30", "actual": "4.51%|2.7"},
                             {"event": "5-y Bond Auction", "cc": "GB", "date": "2026-11-09 09:30", "actual": ""},
                             {"event": "CPI m/m", "cc": "GB", "date": "2026-11-09 09:30", "actual": ""}], now=now)
    rows = out["GB"]
    assert len(rows) == 2 and rows[0]["rate"] == 4.51 and rows[0]["btc"] == 2.7 and rows[1]["status"] == "upcoming"


def test_merge_dedup_and_order():
    mk = lambda d, n, st: auctions._row(d, "JP", n, st, "x")
    up, hist = auctions.merge([mk("2026-11-20", "A", "upcoming"), mk("2026-11-10", "B", "upcoming"), mk("2026-11-10", "b", "upcoming"),
                               mk("2026-10-01", "C", "done"), mk("2026-10-20", "D", "done")] + [mk(f"2026-01-{i:02d}", f"H{i}", "done") for i in range(1, 25)])
    assert [r["name"] for r in up] == ["B", "A"]               # naik, duplikat dibuang
    assert hist[0]["name"] == "D" and len(hist) == auctions.HIST_MAX and all(hist[i]["date"] >= hist[i + 1]["date"] for i in range(len(hist) - 1))


async def test_for_country_available_flags(monkeypatch):
    us, tv = mockworld.auctions_world()

    async def _us():
        return us, ["US Treasury FiscalData"]

    async def _tv():
        return tv

    async def _ff():
        return {}
    monkeypatch.setattr(auctions, "_us", _us)
    monkeypatch.setattr(auctions, "tv_by_country", _tv)
    monkeypatch.setattr(auctions, "_ff_by_country", _ff)
    jp, cn, us_r = await auctions.for_country("JP"), await auctions.for_country("CN"), await auctions.for_country("US")
    assert jp["available"] and jp["upcoming"] and jp["history"]
    assert not cn["available"] and cn["upcoming"] == [] and cn["history"] == []
    assert us_r["upcoming"] and us_r["history"] and "US Treasury FiscalData" in us_r["sources"]


async def test_us_falls_back_to_treasurydirect(monkeypatch):
    async def get_json(url, **kw):
        if "fiscaldata" in url:
            raise RuntimeError("FiscalData mati")
        if url.endswith("/upcoming"):
            return [{"auctionDate": (dt.date.today() + dt.timedelta(days=3)).isoformat() + "T00:00:00", "securityTerm": "10-Year", "securityType": "Note", "offeringAmount": "39000000000"}]
        return [{"auctionDate": (dt.date.today() - dt.timedelta(days=3)).isoformat() + "T00:00:00", "securityTerm": "2-Year", "securityType": "Note", "highYield": "3.9", "bidToCoverRatio": "2.5"}]
    monkeypatch.setattr(auctions, "get_json", get_json)
    rows, srcs = await auctions._us()
    assert srcs == ["TreasuryDirect"] and {r["status"] for r in rows} == {"upcoming", "done"}


# ------------------------------------------------------------------ API: lelang & negara fiskal
def test_fiscal_country_exposes_auctions_and_hides_empty(client):
    us = client.get("/api/fiscal/country?cc=US").json()
    assert us["auctions"]["available"] and us["auctions"]["upcoming"] and us["auctions"]["history"] and us["has_data"]
    jp = client.get("/api/fiscal/country?cc=JP").json()
    assert jp["auctions"]["available"] and jp["has_data"]
    cn = client.get("/api/fiscal/country?cc=CN").json()
    assert not cn["has_data"] and not cn["auctions"]["available"]
    ca = client.get("/api/fiscal/country?cc=CA").json()
    assert ca["has_data"] and ca["auctions"]["available"] is False   # data fiskal ada, lelang tidak -> hanya panel lelang yang hilang


# ------------------------------------------------------------------ BIS WS_TC (cadangan utang/PDB)
BIS_CSV = """FREQ:Frequency,BORROWERS_CTY:Borrowers' country,TC_BORROWERS:Borrowing sector,TC_LENDERS:Lending sector,VALUATION:Valuation,UNIT_TYPE:Unit type,TC_ADJUST:Adjustment,TIME_PERIOD:Period,OBS_VALUE:Value
Q:Quarterly,CN:China,G:General government,A:All sectors,N:Nominal,770:Percentage of GDP,A:Adjusted,2023-Q1,70.1
Q:Quarterly,CN:China,G:General government,A:All sectors,N:Nominal,770:Percentage of GDP,A:Adjusted,2023-Q4,76.0
Q:Quarterly,CN:China,G:General government,A:All sectors,N:Nominal,770:Percentage of GDP,A:Adjusted,2024-Q2,80.5
Q:Quarterly,CN:China,G:General government,A:All sectors,M:Market,770:Percentage of GDP,A:Adjusted,2024-Q2,99.9
Q:Quarterly,CN:China,N:Non-financial corporations,A:All sectors,N:Nominal,770:Percentage of GDP,A:Adjusted,2024-Q2,150
Q:Quarterly,CN:China,G:General government,A:All sectors,N:Nominal,XDC:Domestic currency,A:Adjusted,2024-Q2,1
Q:Quarterly,XM:Euro area,G:General government,A:All sectors,M:Market,770:Percentage of GDP,A:Adjusted,2024-Q1,88.0
"""


def test_parse_bis_tc():
    out = annual.parse_bis_tc(BIS_CSV)
    assert out["CN"] == [(2023, 76.0), (2024, 80.5)]        # kuartal terakhir per tahun, valuasi Nominal diprioritaskan, hanya sektor G & unit 770
    assert out["XM"] == [(2024, 88.0)]                      # tanpa Nominal -> Market
    with pytest.raises(ValueError):
        annual.parse_bis_tc("A,B\n1,2\n")


async def test_indicator_uses_bis_for_missing_country(monkeypatch):
    H.clear_cache()

    async def imf(ind, codes):
        return {c: [(2023, 50.0)] for c in codes if c != "CHN"}

    async def bis(codes):
        assert "CHN" in codes
        return {"CHN": [(2023, 76.0)]}

    async def wb(*a, **k):
        raise RuntimeError("wb mati")
    monkeypatch.setattr(annual, "_imf_fetch", imf)
    monkeypatch.setattr(annual, "_bis_debt", bis)
    monkeypatch.setattr(annual.worldbank, "indicator", wb)
    out = await annual.indicator("GGXWDG_NGDP", tuple(mockworld.COUNTRIES[c]["imf"] for c in mockworld.COUNTRY_ORDER))
    assert out["CHN"] == [(2023, 76.0)] and out["USA"] == [(2023, 50.0)]
    assert "BIS" in annual.SRC["GGXWDG_NGDP"]


# ------------------------------------------------------------------ status sumber (poin 6)
def test_health_levels_cover_and_disable():
    health.reset()
    health.host_fail("dead.example", RuntimeError("HTTP 500"), url="https://dead.example/x")
    assert {h["host"]: h["level"] for h in health.snapshot()["hosts"]}["dead.example"] == "retry"   # sekali gagal: belum dihitung
    health.host_fail("dead.example", RuntimeError("HTTP 500"), url="https://dead.example/x")     # gagal berturut-turut
    health.host_fail("backup.example", RuntimeError("HTTP 403"), url="https://backup.example/y")
    health.cover("backup.example", "Sumber Lain")
    health.host_fail("feed.example", RuntimeError("HTTP 404"))
    health.mark_optional("feed.example")
    snap = health.snapshot()
    lvl = {h["host"]: h["level"] for h in snap["hosts"]}
    assert lvl["dead.example"] == "bad" and lvl["backup.example"] == "covered" and lvl["feed.example"] == "optional"
    bh = " ".join(snap["bad_hosts"])
    assert "dead.example" in bh and "backup.example" not in bh and "feed.example" not in bh and snap["bad"] == 1 and snap["covered"] == 1 and snap["optional_bad"] == 1
    health.host_ok("dead.example")
    assert {h["host"]: h["level"] for h in health.snapshot()["hosts"]}["dead.example"] == "ok"
    health.disable("https://x.example/a.csv", "HTTP 404", 60)
    assert health.is_disabled("https://x.example/a.csv") and any(d["url"] == "https://x.example/a.csv" for d in health.snapshot()["disabled"])


class _FakeClient:
    """Pengganti httpx.AsyncClient: selalu membalas `code`; menghitung panggilan."""

    def __init__(self, code):
        self.code, self.n = code, 0

    async def request(self, method, url, **kw):
        import httpx
        self.n += 1
        return httpx.Response(self.code, request=httpx.Request(method, url), text="x")


async def test_fetch_falls_back_to_tls_impersonation_on_403(monkeypatch):
    import httpx
    fc = _FakeClient(403)
    monkeypatch.setattr(H, "client", lambda: fc)

    async def imp(method, url, params, headers, json, data, timeout):
        return httpx.Response(200, text="data-ok", request=httpx.Request("GET", url))
    monkeypatch.setattr(H, "_impersonated", imp)
    r = await H.fetch("https://blocked.example/a.csv", retries=0)
    assert r.text == "data-ok"
    assert {h["host"]: h for h in health.snapshot()["hosts"]}["blocked.example"]["level"] == "ok"


async def test_fetch_404_circuit_breaker(monkeypatch):
    fc = _FakeClient(404)
    calls = fc
    monkeypatch.setattr(H, "client", lambda: fc)
    url = "https://gone.example/dead.csv"
    for _ in range(H.STRIKES_TO_DISABLE):
        with pytest.raises(Exception):
            await H.fetch(url, retries=3)
    assert calls.n == H.STRIKES_TO_DISABLE           # 404 = permanen: tidak ada retry
    before = calls.n
    with pytest.raises(Exception):
        await H.fetch(url, retries=3)
    assert calls.n == before and health.is_disabled(H._key(url))   # sirkuit terbuka: tidak lagi memukul URL mati


# ------------------------------------------------------------------ yield cadangan: BoE & MOF
BOE = "Date,IUDSNPY,IUDMNPY,IUDLNPY\n01 Oct 2026,3.90,4.20,4.90\n02 Oct 2026,3.95,4.25,4.95\n05 Oct 2026,,4.30,5.00\n"


def test_parse_boe_csv():
    out = yields.parse_boe_csv(BOE)
    assert out["5Y"][-1][1] == 3.95 and out["10Y"][-1] == ("2026-10-05", 4.30) and out["20Y"][0] == ("2026-10-01", 4.90)


# ------------------------------------------------------------------ balance sheet: rantai & UI hide
async def test_balance_sheet_chain_and_unavailable(monkeypatch):
    mockworld.install(monkeypatch)
    for cc in ("US", "EU", "JP"):
        b = await rates.balance_sheet(cc)
        assert b["series"] and b["latest"] and b["src"] == "FRED" and b["unit"] in ("USD", "EUR", "JPY")   # EU: ECB tiruan gagal -> FRED
    ca = await rates.balance_sheet("CA")                 # negara tanpa FRED: neraca bulanan BIS (sama untuk semua negara)
    assert ca["series"] and ca["src"] == "BIS" and ca["unit"] == "CAD" and ca["freq"] == "bulanan"
    nz = await rates.balance_sheet("NZ")                 # BIS tiruan tanpa NZ -> kosong + alasan
    assert nz["series"] == [] and nz["latest"] is None and nz["reason"]


# ------------------------------------------------------------------ Myfxbook
def test_parse_outlook_rounding():
    j = {"symbols": [{"name": "EURUSD", "shortPercentage": 38.123456789, "longPercentage": 61.876543211, "shortVolume": 1234.56789, "longVolume": 2345.6789, "longPositions": 1200.0, "shortPositions": 900,
                      "avgShortPrice": 1.0845123456789, "avgLongPrice": 1.09123456789}]}
    rows = myfxbook.parse_outlook(j, 1_700_000_000)
    ts, name, lpct, spct, lv, sv, lp, sp, alp, asp = rows[0]
    assert (name, lpct, spct, lv, sv, asp, alp) == ("EURUSD", 61.88, 38.12, 2345.68, 1234.57, 1.08451, 1.09123)
    assert isinstance(lp, int) and isinstance(sp, int)
    assert myfxbook.parse_outlook({"symbols": [{"name": ""}, {"name": "X"}]}, 1) == []   # simbol kosong / tanpa angka dibuang


def test_retail_history_and_table(client, monkeypatch):
    mockworld.install_retail(monkeypatch, snapshots=6)
    h = client.get("/api/retail/history?symbol=EURUSD&days=14").json()
    assert h["symbol"] == "EURUSD" and len(h["rows"]) == 6 and h["interval"] and h["first"] <= h["last"]
    assert all({"ts", "long_pct", "short_pct", "net_vol", "total_pos"} <= set(r) for r in h["rows"])
    assert all(round(r["long_pct"], 2) == r["long_pct"] for r in h["rows"])
    t = client.get("/api/retail/table").json()
    assert t["rows"] and any(r["symbol"] == "EURUSD" for r in t["rows"])
    assert all(round(r["long_pct"], 2) == r["long_pct"] for r in t["rows"] if r.get("long_pct") is not None)


def test_retail_history_downsamples_keeping_last(client, monkeypatch):
    mockworld.install_retail(monkeypatch, snapshots=900, )
    h = client.get("/api/retail/history?symbol=EURUSD&days=14").json()
    assert len(h["rows"]) <= 600 and h["rows"][-1]["ts"] == h["last"]
