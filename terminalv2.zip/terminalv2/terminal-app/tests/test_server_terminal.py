"""Terminal SERVER: tata letak 7 jendela, start.bat, pengawas tunnel Cloudflare, dan panel tetap."""
import asyncio
import os
import pathlib
import re
import sys

import httpx
import pytest

from terminal import layout, panel as P, tunnel as T

ROOT = pathlib.Path(__file__).resolve().parent.parent
FAKE = str(ROOT / "tests" / "fake_cloudflared_reg.sh")


# ------------------------------------------------------------------------------------------- tata letak
def test_layout_seven_windows_like_screenshot():
    pos = {t: (c, r) for t, c, r, *_ in layout.cells(0, 0, 1920, 1040)}
    assert len(pos) == 7
    assert pos == {
        "NEWS AGENT": (0, 0), "TEKNIKAL AGENT": (1, 0), "FUNDAMENTAL AGENT": (2, 0),
        "VOLUME AGENT": (0, 1), "QUANT AGENT": (1, 1), layout.SERVER_TITLE: (2, 1),
        "FEBRIAN AGENT": (0, 2),
    }


def test_layout_cells_fill_work_area_without_gaps():
    cells = {t: (x, y, w, h) for t, c, r, x, y, w, h in layout.cells(0, 40, 1921, 1081)}
    x, y, w, h = cells["FUNDAMENTAL AGENT"]
    assert x + w == 1921 and y == 40
    x, y, w, h = cells["FEBRIAN AGENT"]
    assert x == 0 and y + h == 1081
    assert cells["NEWS AGENT"][2] == cells["TEKNIKAL AGENT"][2] == 640


def test_title_matching_handles_cmd_prefix_and_suffix():
    assert layout.title_matches("Administrator: TERMINAL SERVER (UTAMA)", layout.SERVER_TITLE)
    assert layout.title_matches('NEWS AGENT - "C:\\terminal\\.venv\\Scripts\\python.exe" -m terminal.agents.run news', "NEWS AGENT")
    assert layout.title_matches("Administrator:  FEBRIAN AGENT", "FEBRIAN AGENT")
    assert not layout.title_matches("Google Chrome - NEWS AGENT", "NEWS AGENT")
    assert not layout.title_matches("QUANT AGENT", "FEBRIAN AGENT")


def test_every_agent_has_a_window():
    from terminal.agents.bus import IDS
    assert set(layout.AGENT_TITLES) == set(IDS)
    assert set(layout.AGENT_TITLES.values()) | {layout.SERVER_TITLE} == set(layout.TITLES)


def test_arrange_pick_prefers_newest_console_window():
    sys.path.insert(0, str(ROOT / "tools"))
    import arrange_terminals as A
    rows = [
        dict(handle=1, title="NEWS AGENT", cls="Chrome_WidgetWin_1", created=99),
        dict(handle=2, title="Administrator: NEWS AGENT", cls="ConsoleWindowClass", created=5),
        dict(handle=3, title="NEWS AGENT - python", cls="ConsoleWindowClass", created=7),
    ]
    assert A.pick(rows, "NEWS AGENT")["handle"] == 3
    assert A.pick(rows, "NEWS AGENT", exclude={3})["handle"] == 2
    assert A.main(["--print"]) == 0


def test_start_bat_launches_seven_terminals_safely():
    raw = (ROOT / "start.bat").read_bytes()
    assert b"\r\n" in raw and raw.count(b"\n") == raw.count(b"\r\n"), "start.bat harus CRLF (cmd salah membaca label/goto pada LF)"
    text = raw.decode("ascii").replace("\r\n", "\n")
    for line in text.splitlines():
        s = line.strip()
        if s.lower().startswith("echo"):
            assert not re.search(r"(?<!\^)[&|<>]", s), f"karakter khusus tanpa ^ di echo: {s}"
    titles = re.findall(r'^start "([^"]+)" cmd /k .*terminal\.agents\.run (\w+)"$', text, re.M)
    assert {t: a for t, a in titles} == {v: k for k, v in layout.AGENT_TITLES.items()}
    assert f"title {layout.SERVER_TITLE}" in text
    assert "arrange_terminals.py" in text and "main.py" in text
    assert "/b" not in re.sub(r"exit /b", "", text), "FEBRIAN tidak boleh lagi berbagi jendela server (start /b)"
    assert (ROOT / "install.bat").read_bytes().count(b"\n") == (ROOT / "install.bat").read_bytes().count(b"\r\n")


# ------------------------------------------------------------------------------------------- probe link
def _client(handler):
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


@pytest.mark.asyncio
async def test_probe_detects_error_1033_and_success():
    def h(status, text="", js=None):
        return lambda req: httpx.Response(status, json=js) if js is not None else httpx.Response(status, text=text)

    async with _client(h(530, "<title>Cloudflare Tunnel error</title> Error 1033")) as c:
        ok, code, detail = await T.probe("https://x.trycloudflare.com", client=c)
        assert ok is False and code == 530 and "1033" in detail
    async with _client(h(502, "bad gateway")) as c:
        assert (await T.probe("https://x.trycloudflare.com", client=c))[0] is False
    async with _client(h(200, js={"ok": True, "uptime": 3})) as c:
        assert (await T.probe("https://x.trycloudflare.com", client=c))[:2] == (True, 200)

    def boom(req):
        raise httpx.ConnectError("dns")
    async with _client(boom) as c:
        assert (await T.probe("https://x.trycloudflare.com", client=c))[0] is None


# ------------------------------------------------------------------------------------------- pengawas tunnel
@pytest.mark.asyncio
async def test_supervisor_verifies_then_recreates_dead_link(monkeypatch):
    if os.name == "nt":
        pytest.skip("cloudflared palsu berupa skrip sh")
    from terminal import config
    monkeypatch.setattr(config, "CLOUDFLARED_PATH", FAKE)
    monkeypatch.setattr(config, "PUBLIC_URL", "")
    plan = {"dead": set()}

    async def fake_probe(url, timeout=12.0, client=None):
        if url in plan["dead"]:
            return False, 530, "error 1033 (tunnel tidak tersambung ke Cloudflare)"
        return True, 200, "ok"

    async def fake_local(port, timeout=5.0):
        return True

    monkeypatch.setattr(T, "probe", fake_probe)
    monkeypatch.setattr(T, "probe_local", fake_local)
    links, logs = [], []
    sup = T.Supervisor(1, on_link=lambda url, active: links.append((url, active)), log=logs.append, check_every=0.05)
    sup.check_every = 0.05
    task = asyncio.create_task(sup.run())
    try:
        for _ in range(200):
            if sup.status["state"] == "active":
                break
            await asyncio.sleep(0.05)
        first = sup.status["url"]
        assert sup.status["state"] == "active" and first.startswith("https://fake-")
        assert sup.status["edge"] == "sin01" and sup.status["connections"] == 1
        assert (first, True) in links
        plan["dead"].add(first)                       # edge mulai membalas 530 / error 1033
        for _ in range(400):
            if sup.status["state"] == "active" and sup.status["url"] not in (None, first):
                break
            await asyncio.sleep(0.05)
        assert sup.status["url"] != first and sup.status["state"] == "active"
        assert sup.status["restarts"] == 1
        assert any("BERGANTI" in m for m in logs)
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
    assert sup.tunnel.proc.returncode is not None      # cloudflared dihentikan saat pengawas berhenti


@pytest.mark.asyncio
async def test_supervisor_does_not_replace_link_when_local_server_is_down(monkeypatch):
    if os.name == "nt":
        pytest.skip("cloudflared palsu berupa skrip sh")
    from terminal import config
    monkeypatch.setattr(config, "CLOUDFLARED_PATH", FAKE)
    monkeypatch.setattr(config, "PUBLIC_URL", "")
    calls = {"n": 0}

    async def fake_probe(url, timeout=12.0, client=None):
        calls["n"] += 1
        return (True, 200, "ok") if calls["n"] == 1 else (False, 502, "edge Cloudflare HTTP 502")

    async def local_down(port, timeout=5.0):
        return False

    monkeypatch.setattr(T, "probe", fake_probe)
    monkeypatch.setattr(T, "probe_local", local_down)
    sup = T.Supervisor(1, log=lambda m: None, check_every=0.02)
    task = asyncio.create_task(sup.run())
    try:
        for _ in range(100):
            if calls["n"] > 15:
                break
            await asyncio.sleep(0.05)
        assert calls["n"] > 15 and sup.status["restarts"] == 0
        assert "server lokal" in (sup.status["last_result"] or "")
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_supervisor_fixed_public_url(monkeypatch):
    from terminal import config
    monkeypatch.setattr(config, "PUBLIC_URL", "https://terminal.example.com/")
    seen = []
    sup = T.Supervisor(1, on_link=lambda u, a: seen.append((u, a)), log=lambda m: None)
    await sup.run()
    assert sup.status["state"] == "fixed" and seen == [("https://terminal.example.com", True)]


# ------------------------------------------------------------------------------------------- panel
def test_panel_keeps_links_whole_and_never_scrolls():
    link = "ADMIN >> https://achievements-showed-canvas-lesser.trycloudflare.com/?key=injKxpyfC-tHstilQvyv1xZ-abcdef"
    header = [("== TERMINAL SERVER (UTAMA) == " + "x" * 200, False), ("CLOUDFLARE: [AKTIF]", False), (link, True)]
    logs = [("07:00:00", f"baris log {i} " + "y" * 150) for i in range(100)]
    out = P.compose(header, logs, cols=80, rows=20)
    assert link in out                                      # link utuh (dibungkus otomatis oleh konsol, bisa disalin)
    used = sum(P.wrap_rows(line, 80) for line in out)
    assert used <= 20
    assert all(len(line) < 80 for line in out if line != link and not line.startswith(link))
    assert out[-1].endswith(logs[-1][1][:40]) or "baris log 99" in out[-1]


def test_panel_link_length_multiple_of_width_is_padded():
    out = P.compose([("a" * 160, True)], [], cols=80, rows=10)
    assert len(out[0]) == 161


def test_logbuffer_joins_partial_writes_and_writes_file(tmp_path):
    f = tmp_path / "server.log"
    b = P.LogBuffer(logfile=str(f))
    b.write("[server] ber")
    b.write("jalan\n\nbaris dua\r\nsisa")
    assert [x[1] for x in b.tail(10)] == ["[server] berjalan", "baris dua"]
    b.close()
    assert "baris dua" in f.read_text(encoding="utf-8")


def test_header_lines_show_link_only_when_live(monkeypatch):
    import main
    from terminal import auth
    monkeypatch.setattr(auth, "access_key", lambda: "ADMINKEY")
    monkeypatch.setattr(auth, "user_key", lambda: "USERKEY")
    monkeypatch.setattr(auth, "enabled", lambda: True)
    busy = main.header_lines(dict(state="verifying", url="https://a.trycloudflare.com"), "NEWS ok", "ON")
    text = "\n".join(t for t, _ in busy)
    assert "JANGAN dibuka" in text and "https://a.trycloudflare.com" not in text and "127.0.0.1" in text
    live = main.header_lines(dict(state="active", url="https://a.trycloudflare.com", verified_at=1.0, edge="sin01"), "NEWS ok", "ON")
    text = "\n".join(t for t, _ in live)
    assert "CF    : AKTIF" in text
    assert "https://a.trycloudflare.com/?key=ADMINKEY" in text and "https://a.trycloudflare.com/?key=USERKEY" in text


def test_link_file_written(monkeypatch, tmp_path):
    import main
    from terminal import auth
    monkeypatch.setattr(auth, "access_key", lambda: "ADMINKEY")
    monkeypatch.setattr(auth, "user_key", lambda: "USERKEY")
    monkeypatch.setattr(auth, "enabled", lambda: True)
    monkeypatch.setattr(main, "LINK_FILE", tmp_path / "LINK.txt")
    main.write_link_file(dict(state="active", url="https://b.trycloudflare.com"))
    txt = (tmp_path / "LINK.txt").read_text(encoding="utf-8")
    assert "ADMIN: https://b.trycloudflare.com/?key=ADMINKEY" in txt and "USER : https://b.trycloudflare.com/?key=USERKEY" in txt
    main.write_link_file(dict(state="restarting", url=None))
    assert "trycloudflare" not in (tmp_path / "LINK.txt").read_text(encoding="utf-8")
