"""Uji perbaikan: watchdog "server tertahan" (parser dibatasi, country_at di-memo, risk_map di luar event loop),
panel COT negara tanpa data CFTC, hasil kosong OEC tidak di-cache, kurs tambahan kalkulator ukuran posisi."""
import asyncio
import pathlib
import random
import re
import threading
import time

from terminal import cpu
from terminal.providers import geo, macro, trade

ROOT = pathlib.Path(__file__).resolve().parents[1] / "terminal"


def run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


# ------------------------------------------------------------------ watchdog: parser berjalan di jalur terbatas
def test_parse_lane_is_bounded():
    """Puluhan parser serentak dulu memenuhi executor 64 thread dan event loop kalah berebut GIL. Kini paling banyak
    PARSE_THREADS parser berjalan bersamaan."""
    live, peak, lock = [0], [0], threading.Lock()

    def work():
        with lock:
            live[0] += 1
            peak[0] = max(peak[0], live[0])
        time.sleep(0.05)
        with lock:
            live[0] -= 1
        return threading.current_thread().name

    async def main():
        return await asyncio.gather(*[cpu.parse(work) for _ in range(12)])
    names = run(main())
    assert peak[0] <= cpu.PARSE_THREADS
    assert all(n.startswith("parse") for n in names)


def test_cpu_parsers_not_on_default_pool():
    """Parser RSS/CSV/JSON tidak lagi lewat asyncio.to_thread (executor bawaan 64 thread)."""
    bad = []
    for f in ("polymarket", "rates", "fred", "gdelt", "news", "social", "xfeed", "cyber", "yields", "gpr"):
        src = (ROOT / "providers" / f"{f}.py").read_text(encoding="utf-8")
        for m in re.finditer(r"asyncio\.to_thread\(([\w.]+)", src):
            if not m.group(1).startswith("store."):          # akses database (I/O) tetap di executor bawaan
                bad.append(f"{f}: {m.group(1)}")
    assert not bad, bad


def test_country_at_memo_matches_and_skips_rescan(monkeypatch):
    rnd = random.Random(7)
    pts = [(rnd.uniform(-55, 70), rnd.uniform(-170, 170)) for _ in range(150)]
    geo._CC_MEMO.clear()
    want = [geo._country_at(round(a, 2), round(b, 2)) for a, b in pts]
    assert [geo.country_at(a, b) for a, b in pts] == want
    calls = [0]
    real = geo._country_at
    monkeypatch.setattr(geo, "_country_at", lambda la, lo: calls.__setitem__(0, calls[0] + 1) or real(la, lo))
    assert [geo.country_at(a, b) for a, b in pts] == want
    assert calls[0] == 0                                        # semua dari memo: tidak memindai poligon lagi
    assert geo.country_at(None, 10) is None


def test_country_at_known_places():
    assert geo.country_at(-6.2, 106.8) == "Indonesia"
    assert geo.country_at(48.85, 2.35) == "France"
    assert geo.country_at(35.7, 139.7) == "Japan"


def test_geo_overview_risk_map_off_event_loop(client, monkeypatch):
    seen = []
    real = geo.risk_map

    def spy(*a, **k):
        seen.append(threading.current_thread().name)
        return real(*a, **k)
    monkeypatch.setattr(geo, "risk_map", spy)
    r = client.get("/api/geo/overview")
    assert r.status_code == 200 and "risk" in r.json()
    assert seen and all(n.startswith("cpu") for n in seen), seen


def test_air_layer_country_lookup_off_event_loop(monkeypatch):
    from terminal.providers import airtraffic
    seen = []

    async def mil():
        return dict(aircraft=[dict(hex="a1", lat=35.7, lon=139.7, role="tanker")], total=1, roles={}, regions=[], emergencies=[], ts=1, source="t", poll_sec=1)

    async def em():
        return []
    monkeypatch.setattr(airtraffic, "military", mil)
    monkeypatch.setattr(airtraffic, "emergencies", em)
    real = geo.country_at
    monkeypatch.setattr(geo, "country_at", lambda la, lo: seen.append(threading.current_thread().name) or real(la, lo))
    d = run(airtraffic.layer())
    assert d["countries"] == {"Japan": {"count": 1, "roles": {"tanker": 1}}}
    assert seen and all(n.startswith("cpu") for n in seen)


def test_gc_freeze_task_present():
    src = (ROOT / "server.py").read_text(encoding="utf-8")
    assert "gc.freeze()" in src and "_gc_freeze()" in src


# ------------------------------------------------------------------ COT: tidak ada panel kosong untuk IDR / CNY
def test_cot_group_absent_without_cftc_data():
    assert run(macro._cot_group("ID")) is None
    assert run(macro._cot_group("CN")) is None


def test_overview_has_no_cot_panel_for_id(client):
    for cc, want in (("ID", False), ("CN", False), ("US", True), ("JP", True)):
        d = client.get("/api/macro/overview", params={"cc": cc}).json()
        kinds = [g.get("kind") for g in d["groups"]]
        assert ("cot" in kinds) is want, (cc, kinds)
        assert not any("tidak menerbitkan data COT" in (g.get("note") or "") for g in d["groups"])


# ------------------------------------------------------------------ OEC: jawaban kosong tidak disimpan sehari
def test_empty_oec_answer_not_cached(monkeypatch):
    calls = [0]

    async def empty(*a, **k):
        calls[0] += 1
        return []
    monkeypatch.setattr(trade, "_query", empty)
    for _ in range(2):
        try:
            run(trade._flow_rows("xxdeu", "X", 2024))
            raise AssertionError("harus error")
        except LookupError:
            pass
    assert calls[0] == 2                                    # dicoba lagi, bukan dilayani dari cache "kosong"


def test_partners_skip_missing_year(monkeypatch):
    async def q(drill, exporter=None, importer=None, year=None, limit=500):
        if year and int(year) >= 2025:
            return []                                       # tahun belum terbit di BACI
        return [{"Importer Country ID": "asjpn", "Importer Country": "Japan", "Trade Value": 5e9}]
    monkeypatch.setattr(trade, "_query", q)
    d = run(trade.partners(trade._m49("US"), "X", None))
    assert d["year"] and d["year"] <= 2024 and d["partners"][0]["oid"] == "asjpn"


# ------------------------------------------------------------------ kalkulator: kurs mata uang kuotasi indeks Asia/Brasil
def test_tools_fx_endpoint(client):
    d = client.get("/api/tools/fx").json()
    usd = d["usd"]
    assert set(usd) == {"HKD", "KRW", "TWD", "BRL"}
    assert all(v > 0 for v in usd.values())


# ------------------------------------------------------------------ watchdog Windows: thread dibuat SAAT start, bukan saat sibuk
# Log pengguna (Python 3.11, Windows): "tertahan 25.9 dtk - threading.py:320 wait <- ... getaddrinfo" (event loop menunggu
# thread baru pool bawaan mulai) dan "28.7 dtk - futures/thread.py:162 submit" (menunggu kunci global ThreadPoolExecutor
# yang dipegang selama thread baru dibuat, mis. oleh pool yang dibuat yfinance di setiap download).
import concurrent.futures as cf  # noqa: E402
from terminal import threads, watchdog  # noqa: E402


def _count_thread_starts(monkeypatch):
    n = [0]
    real = threading.Thread.start

    def start(self, *a, **k):
        n[0] += 1
        return real(self, *a, **k)
    monkeypatch.setattr(threading.Thread, "start", start)
    return n


def test_prestart_creates_all_threads_then_submit_never_spawns(monkeypatch):
    ex = cf.ThreadPoolExecutor(max_workers=8, thread_name_prefix="t")
    assert threads.prestart(ex, 8) == 8 and len(ex._threads) == 8
    starts = _count_thread_starts(monkeypatch)
    gate = threading.Event()
    futs = [ex.submit(gate.wait, 5) for _ in range(8)]       # 8 tugas memblokir bersamaan: semua thread sudah ada
    gate.set()
    [f.result() for f in futs]
    assert starts[0] == 0 and len(ex._threads) == 8
    assert threads.prestart(ex, 8) == 8                       # kedua kalinya tidak menunggu apa pun
    ex.shutdown()


def test_submit_fast_under_gil_contention_when_prestarted():
    """Seperti RDP sibuk: 6 thread mengurai JSON besar (kode C yang memegang GIL). Pool yang sudah lengkap: submit dari
    event loop tetap seketika (tanpa prestart, uji 2 core mengukur hingga 4,5 dtk per submit)."""
    import json
    big = json.dumps([{"a": i, "b": "x" * 20} for i in range(60000)])
    stop = threading.Event()

    def hog():
        while not stop.is_set():
            json.loads(big)
    ex = cf.ThreadPoolExecutor(max_workers=24)
    threads.prestart(ex, 24)
    hogs = [threading.Thread(target=hog, daemon=True) for _ in range(6)]
    [h.start() for h in hogs]
    worst = 0.0
    try:
        for _ in range(24):
            t = time.perf_counter()
            ex.submit(time.sleep, 0.3)
            worst = max(worst, time.perf_counter() - t)
            time.sleep(0.01)
    finally:
        stop.set()
        [h.join() for h in hogs]
        ex.shutdown(wait=False)
    assert worst < 0.25, worst


def test_install_prestarts_every_pool():
    async def main():
        threads._installed.discard(id(asyncio.get_running_loop()))
        threads.install()
        await threads.prestart_anyio()
        return dict(threads.STATUS["prestarted"])
    st = asyncio.run(main())
    assert st["io"] == threads.DEFAULT_WORKERS and st["net"] == threads.NET_WORKERS and st["yf"] == threads.YF_WORKERS
    assert st["cpu"] == 1 and st["parse"] == cpu.PARSE_THREADS and st["anyio"] >= 2


def test_anyio_workers_reused_not_started_per_request(monkeypatch):
    import anyio.to_thread

    async def main():
        await threads.prestart_anyio(4)
        starts = _count_thread_starts(monkeypatch)
        for _ in range(3):
            await asyncio.gather(*[anyio.to_thread.run_sync(time.sleep, 0.01) for _ in range(4)])
            await asyncio.sleep(0.05)
        return starts[0]
    assert asyncio.run(main()) == 0


def test_yfinance_download_never_creates_its_own_threads(monkeypatch):
    import pandas as pd
    import numpy as np
    from terminal.providers import yahoo
    calls = []

    def fake_download(tickers, **kw):
        calls.append((list(tickers), kw.get("threads"), threading.current_thread().name))
        idx = pd.bdate_range(end="2026-11-20", periods=5)
        cols = pd.MultiIndex.from_tuples([(t, c) for t in tickers for c in ("Open", "High", "Low", "Close", "Volume")])
        return pd.DataFrame(np.ones((5, len(cols))), index=idx, columns=cols)
    monkeypatch.setattr(yahoo.yf, "download", fake_download)
    threads.prestart(threads._yf(), threads.YF_WORKERS)
    syms = [f"S{i}" for i in range(23)]
    starts = _count_thread_starts(monkeypatch)
    got = cf.ThreadPoolExecutor(1).submit(yahoo._download_frames, syms, "6mo", "1d").result()   # dipanggil dari pool lain, seperti threads.net
    assert sorted(got) == sorted(syms)
    assert all(t is False for _, t, _ in calls)                       # yfinance tidak membuat thread sendiri
    assert all(n.startswith("yf") for _, _, n in calls) and len(calls) == threads.YF_WORKERS
    assert sorted(s for c, _, _ in calls for s in c) == sorted(syms)  # setiap simbol tepat satu kali
    assert starts[0] <= 1                                             # hanya pool uji 1-thread di atas


# ------------------------------------------------------------------ watchdog: mundur sesudah macet + daftar thread sibuk
def test_watchdog_busy_and_calm(monkeypatch):
    monkeypatch.setitem(watchdog._state, "running", True)
    monkeypatch.setitem(watchdog._state, "beat", time.monotonic())
    watchdog._recent.clear()
    assert watchdog.busy() is False
    watchdog._recent.append((time.time() - 2, time.time() - 0.5))      # macet yang baru selesai
    assert watchdog.busy(within=3) is True and watchdog.busy(within=0.1) is False
    t = time.perf_counter()
    asyncio.run(watchdog.calm(max_wait=0.6, within=3))
    assert 0.5 <= time.perf_counter() - t < 2.0                         # menunggu, tetapi berbatas
    watchdog._recent.clear()


def test_watchdog_reports_busy_threads_during_stall(monkeypatch):
    lines = []
    for k, v in dict(beat=0.0, stalls=0, worst=0.0, running=False).items():
        monkeypatch.setitem(watchdog._state, k, v)
    stop = threading.Event()

    def churn():                         # kode Python yang terus berjalan (kandidat perebut GIL)
        x = 0
        while not stop.is_set():
            x += sum(range(200))
    worker = threading.Thread(target=churn, name="hogger-1", daemon=True)

    async def main():
        watchdog.start(log=lines.append, threshold=0.3)
        await asyncio.sleep(0.4)
        worker.start()
        time.sleep(1.6)                   # event loop tertahan
        await asyncio.sleep(0.8)
        stop.set()
    asyncio.run(main())
    worker.join()
    assert lines and "server tertahan" in lines[0]
    assert "thread sibuk: hogger" in lines[0] and "churn" in lines[0], lines


def test_phase2_preload_backs_off_after_stall(monkeypatch):
    from terminal import preload
    seen = []

    async def calm(*a, **k):
        seen.append("calm")

    class R:
        ok, empty, error, ms, body = True, False, None, 1, b""

    async def refresh(*a, **k):
        return R()
    monkeypatch.setattr(watchdog, "calm", calm)
    monkeypatch.setattr(preload.S, "refresh", refresh)
    J = type("J", (), {})

    async def main():
        jobs = []
        for i in range(3):
            j = J(); j.path, j.params = "x", {"i": i}
            jobs.append(j)
        r = preload._Run(jobs, 2, force=True, verbose=False, gentle=True)
        await asyncio.gather(*r.tasks)
        r2 = preload._Run(jobs[:1], 1, force=True, verbose=False)
        await asyncio.gather(*r2.tasks)
    monkeypatch.setitem(preload.state, "preload", dict(phase="idle", done=0, total=0, started=None, finished=None))   # dipulihkan sesudah tes
    asyncio.run(main())
    assert seen == ["calm"] * 3                                         # hanya tahap latar yang mengalah
