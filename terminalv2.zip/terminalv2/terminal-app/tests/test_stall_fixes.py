"""Uji perbaikan: watchdog "server tertahan" (parser dibatasi, country_at di-memo, risk_map di luar event loop),
panel COT negara tanpa data CFTC, hasil kosong OEC tidak di-cache, kurs tambahan kalkulator ukuran posisi."""
import asyncio
import pathlib
import random
import re
import threading
import time

from terminal import cpu
from terminal.providers import geo, macro, trade

ROOT = pathlib.Path(__file__).resolve().parents[1] / "terminal"


def run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


# ------------------------------------------------------------------ watchdog: parser berjalan di jalur terbatas
def test_parse_lane_is_bounded():
    """Puluhan parser serentak dulu memenuhi executor 64 thread dan event loop kalah berebut GIL. Kini paling banyak
    PARSE_THREADS parser berjalan bersamaan."""
    live, peak, lock = [0], [0], threading.Lock()

    def work():
        with lock:
            live[0] += 1
            peak[0] = max(peak[0], live[0])
        time.sleep(0.05)
        with lock:
            live[0] -= 1
        return threading.current_thread().name

    async def main():
        return await asyncio.gather(*[cpu.parse(work) for _ in range(12)])
    names = run(main())
    assert peak[0] <= cpu.PARSE_THREADS
    assert all(n.startswith("parse") for n in names)


def test_cpu_parsers_not_on_default_pool():
    """Parser RSS/CSV/JSON tidak lagi lewat asyncio.to_thread (executor bawaan 64 thread)."""
    bad = []
    for f in ("polymarket", "rates", "fred", "gdelt", "news", "social", "xfeed", "cyber", "yields", "gpr"):
        src = (ROOT / "providers" / f"{f}.py").read_text(encoding="utf-8")
        for m in re.finditer(r"asyncio\.to_thread\(([\w.]+)", src):
            if not m.group(1).startswith("store."):          # akses database (I/O) tetap di executor bawaan
                bad.append(f"{f}: {m.group(1)}")
    assert not bad, bad


def test_country_at_memo_matches_and_skips_rescan(monkeypatch):
    rnd = random.Random(7)
    pts = [(rnd.uniform(-55, 70), rnd.uniform(-170, 170)) for _ in range(150)]
    geo._CC_MEMO.clear()
    want = [geo._country_at(round(a, 2), round(b, 2)) for a, b in pts]
    assert [geo.country_at(a, b) for a, b in pts] == want
    calls = [0]
    real = geo._country_at
    monkeypatch.setattr(geo, "_country_at", lambda la, lo: calls.__setitem__(0, calls[0] + 1) or real(la, lo))
    assert [geo.country_at(a, b) for a, b in pts] == want
    assert calls[0] == 0                                        # semua dari memo: tidak memindai poligon lagi
    assert geo.country_at(None, 10) is None


def test_country_at_known_places():
    assert geo.country_at(-6.2, 106.8) == "Indonesia"
    assert geo.country_at(48.85, 2.35) == "France"
    assert geo.country_at(35.7, 139.7) == "Japan"


def test_geo_overview_risk_map_off_event_loop(client, monkeypatch):
    seen = []
    real = geo.risk_map

    def spy(*a, **k):
        seen.append(threading.current_thread().name)
        return real(*a, **k)
    monkeypatch.setattr(geo, "risk_map", spy)
    r = client.get("/api/geo/overview")
    assert r.status_code == 200 and "risk" in r.json()
    assert seen and all(n.startswith("cpu") for n in seen), seen


def test_air_layer_country_lookup_off_event_loop(monkeypatch):
    from terminal.providers import airtraffic
    seen = []

    async def mil():
        return dict(aircraft=[dict(hex="a1", lat=35.7, lon=139.7, role="tanker")], total=1, roles={}, regions=[], emergencies=[], ts=1, source="t", poll_sec=1)

    async def em():
        return []
    monkeypatch.setattr(airtraffic, "military", mil)
    monkeypatch.setattr(airtraffic, "emergencies", em)
    real = geo.country_at
    monkeypatch.setattr(geo, "country_at", lambda la, lo: seen.append(threading.current_thread().name) or real(la, lo))
    d = run(airtraffic.layer())
    assert d["countries"] == {"Japan": {"count": 1, "roles": {"tanker": 1}}}
    assert seen and all(n.startswith("cpu") for n in seen)


def test_gc_freeze_task_present():
    src = (ROOT / "server.py").read_text(encoding="utf-8")
    assert "gc.freeze()" in src and "_gc_freeze()" in src


# ------------------------------------------------------------------ COT: tidak ada panel kosong untuk IDR / CNY
def test_cot_group_absent_without_cftc_data():
    assert run(macro._cot_group("ID")) is None
    assert run(macro._cot_group("CN")) is None


def test_overview_has_no_cot_panel_for_id(client):
    for cc, want in (("ID", False), ("CN", False), ("US", True), ("JP", True)):
        d = client.get("/api/macro/overview", params={"cc": cc}).json()
        kinds = [g.get("kind") for g in d["groups"]]
        assert ("cot" in kinds) is want, (cc, kinds)
        assert not any("tidak menerbitkan data COT" in (g.get("note") or "") for g in d["groups"])


# ------------------------------------------------------------------ OEC: jawaban kosong tidak disimpan sehari
def test_empty_oec_answer_not_cached(monkeypatch):
    calls = [0]

    async def empty(*a, **k):
        calls[0] += 1
        return []
    monkeypatch.setattr(trade, "_query", empty)
    for _ in range(2):
        try:
            run(trade._flow_rows("xxdeu", "X", 2024))
            raise AssertionError("harus error")
        except LookupError:
            pass
    assert calls[0] == 2                                    # dicoba lagi, bukan dilayani dari cache "kosong"


def test_partners_skip_missing_year(monkeypatch):
    async def q(drill, exporter=None, importer=None, year=None, limit=500):
        if year and int(year) >= 2025:
            return []                                       # tahun belum terbit di BACI
        return [{"Importer Country ID": "asjpn", "Importer Country": "Japan", "Trade Value": 5e9}]
    monkeypatch.setattr(trade, "_query", q)
    d = run(trade.partners(trade._m49("US"), "X", None))
    assert d["year"] and d["year"] <= 2024 and d["partners"][0]["oid"] == "asjpn"


# ------------------------------------------------------------------ kalkulator: kurs mata uang kuotasi indeks Asia/Brasil
def test_tools_fx_endpoint(client):
    d = client.get("/api/tools/fx").json()
    usd = d["usd"]
    assert set(usd) == {"HKD", "KRW", "TWD", "BRL"}
    assert all(v > 0 for v in usd.values())
