"""(1) User tidak melihat info diagnostik admin (sumber/endpoint gagal, teks error, status feed).
(2) Fiscal Policy: semua negara mendapat set data yang sama (IMF WEO + Fiscal Monitor), dan data IMF yang bagus tidak
    tertimpa cadangan World Bank yang jarang ketika IMF sesekali gagal."""
import asyncio
import json
import time

import pytest

import mockworld
from terminal import auth, config, privacy
from terminal import http as H


@pytest.fixture()
def keyed(monkeypatch):
    mockworld.install(monkeypatch)
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ADMIN_KEY", "adm-key")
    monkeypatch.setattr(config, "USER_KEY", "usr-key")
    monkeypatch.setattr(config, "ACCESS_KEY", "")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    auth._cache.clear()
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app, follow_redirects=False) as c:
        yield c


def _login(c, key):
    c.cookies.clear()
    assert c.get(f"/?key={key}").status_code == 303


# ------------------------------------------------------------------------------------------- privasi
def test_scrub_removes_diagnostics_keeps_content():
    body = json.dumps({"items": [{"title": "Fed hikes", "src": "Bloomberg", "error": None}], "errors": {"FRED": "HTTP 404 https://x"},
                       "status": {"error": "ConnectError: api.example", "connected": True, "sources": {"aisstream": False}},
                       "chart_error": "ValueError: data", "auctions": {"sources": ["US Treasury"]}, "last_url": "https://h/x"}).encode()
    d = json.loads(privacy._view("x", body))
    assert d["items"] == [{"title": "Fed hikes", "src": "Bloomberg", "error": None}]   # konten (berita & atribusi) tetap
    assert "errors" not in d and "last_url" not in d
    assert d["status"] == {"error": "tidak tersedia", "connected": True}                 # teks error & peta status sumber hilang
    assert d["chart_error"] == "data" and d["auctions"]["sources"] == ["US Treasury"]                 # awalan exception dibuang
    assert json.loads(privacy._view("x", b'{"error":"ValueError: pair ETHUSDT tidak dipantau"}')) == {"error": "pair ETHUSDT tidak dipantau"}
    assert json.loads(privacy._view("x", b'{"error":"HTTPStatusError: 403 for url https://api.x/y"}')) == {"error": privacy.GENERIC}


def test_for_user_fast_path_and_cache():
    plain = b'{"rows":[1,2,3]}'
    assert asyncio.run(privacy.for_user("market/x", "", plain)) is plain           # tanpa pola diagnostik: tidak diurai
    b = b'{"a":1,"errors":["x"]}'
    o1 = asyncio.run(privacy.for_user("p", "q=1", b))
    o2 = asyncio.run(privacy.for_user("p", "q=1", b))
    assert o1 == b'{"a":1}' and o2 is o1                                            # snapshot sama -> hasil saringan dipakai ulang


def test_user_snapshot_popup_has_no_failing_endpoints_or_errors(keyed):
    _login(keyed, "usr-key")
    u = keyed.get("/api/snapshots", params={"detail": 1}).json()
    assert "items" not in u and "db" not in u and "groups" in u and "ready" in u
    assert set(u["preload"]) <= {"phase", "done", "total", "started", "finished"}
    _login(keyed, "adm-key")
    a = keyed.get("/api/snapshots", params={"detail": 1}).json()
    assert "items" in a and "db" in a                                               # admin tetap melihat detail lengkap


def test_user_squawk_has_headlines_but_no_feed_status(keyed):
    _login(keyed, "usr-key")
    u = keyed.get("/api/squawk").json()
    assert "items" in u and not ({"x", "social", "sources"} & set(u))
    _login(keyed, "adm-key")
    a = keyed.get("/api/squawk").json()
    assert {"x", "social", "sources"} <= set(a)


def test_user_never_sees_raw_error_text(keyed, monkeypatch):
    from terminal.providers import fiscal

    async def boom(cc):
        raise RuntimeError("ConnectError: https://secret-host.example/api?key=abc")
    monkeypatch.setattr(fiscal, "country", boom)
    _login(keyed, "usr-key")
    r = keyed.get("/api/fiscal/country", params={"cc": "JP"}).json()
    assert r == {"error": privacy.GENERIC}
    _login(keyed, "adm-key")
    assert "secret-host" in keyed.get("/api/fiscal/country", params={"cc": "JP"}).json()["error"]


# ------------------------------------------------------------------------------------------- fiscal
def test_fiscal_every_country_gets_the_same_full_set(monkeypatch):
    mockworld.install(monkeypatch)
    from terminal.providers import fiscal
    for cc in ("ID", "JP", "AU"):
        d = asyncio.run(fiscal.country(cc))
        for k in ("debt_gdp", "balance", "primary", "revenue", "expenditure", "interest", "debt_usd", "debt_proj"):
            assert d[k] is not None, (cc, k)
        for k in ("history_debt", "history_balance", "history_primary", "history_revenue", "history_expenditure", "history_net_interest"):
            assert len(d[k]) > 5, (cc, k)
        assert d["commentary"] and "proyeksi IMF" in d["commentary"]
    o = asyncio.run(fiscal.overview())
    row = {r["cc"]: r for r in o["rows"]}["ID"]
    assert row["primary"] is not None and row["revenue"] is not None and row["debt_usd"] is not None


def test_interest_prefers_gross_paid_then_net():
    from terminal.providers import fiscal
    pri, bal = [(2024, -0.6), (2026, -0.6)], [(2024, -2.8), (2026, -2.9)]
    assert fiscal.interest_pick([(2023, 2.1), (2024, 2.2)], pri, bal, 2026) == (2.2, 2024, "gross")
    v, y, kind = fiscal.interest_pick([], pri, bal, 2026)
    assert (round(v, 3), y, kind) == (2.3, 2026, "net")
    assert fiscal.interest_pick([], [], [], 2026) == (None, None, None)


def test_good_imf_data_survives_a_later_imf_failure(monkeypatch):
    from terminal.providers import annual
    H.clear_cache()
    codes = ("USA", "IDN")

    async def imf_ok(ind, cs):
        return {c: [(y, 40.0) for y in range(2005, 2031)] for c in cs}
    monkeypatch.setattr(annual, "_imf_fetch", imf_ok)
    assert asyncio.run(annual.indicator("GGXWDG_NGDP", codes))["IDN"][-1] == (2030, 40.0)
    for k in list(H._cache):                                            # semua cache kedaluwarsa (lewat 12 jam)
        H._cache[k] = (time.time() - 13 * 3600, H._cache[k][1])

    async def imf_down(ind, cs):
        raise RuntimeError("IMF 403")

    async def wb(ind, cs):
        return {c: [(2008, 30.0), (2009, 30.0)] for c in cs}
    monkeypatch.setattr(annual, "_imf_fetch", imf_down)
    monkeypatch.setattr(annual.worldbank, "indicator", wb)
    H._cache.pop(next(k for k in H._cache if "indicator" in str(k)))    # paksa hitung ulang gabungan
    out = asyncio.run(annual.indicator("GGXWDG_NGDP", codes))
    assert out["IDN"][-1] == (2030, 40.0) and annual.SRC["GGXWDG_NGDP"] == "IMF"


def test_stale_world_bank_series_is_replaced_by_bis(monkeypatch):
    from terminal.providers import annual
    H.clear_cache()

    async def imf_down(ind, cs):
        raise RuntimeError("IMF 403")

    async def wb(ind, cs):
        return {c: [(2008, 30.0), (2009, 30.0)] for c in cs}

    async def bis(cs):
        assert "IDN" in cs
        return {"IDN": [(2023, 39.0), (2024, 39.5)]}
    monkeypatch.setattr(annual, "_imf_fetch", imf_down)
    monkeypatch.setattr(annual.worldbank, "indicator", wb)
    monkeypatch.setattr(annual, "_bis_debt", bis)
    out = asyncio.run(annual.indicator("GGXWDG_NGDP", ("IDN",)))
    assert out["IDN"][-1] == (2024, 39.5)
