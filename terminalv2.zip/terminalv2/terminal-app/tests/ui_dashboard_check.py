"""Uji UI DASHBOARD (Chromium): globe 4 layer (sama dengan GEOPOLITICAL RISK), pemilih negara Macro Regime,
tombol "HIGH saja" di Upcoming Macro Events.

    python tests/run_mock_server.py 8765 &   lalu:   python tests/ui_dashboard_check.py ./shots
"""
import os
import sys

from playwright.sync_api import sync_playwright

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
BASE = os.environ.get("BASE", "http://127.0.0.1:8765")
ok = []


def check(name, cond, info=""):
    ok.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name, info)


with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
    pg = b.new_page(viewport={"width": 1600, "height": 950}); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    reqs = []
    pg.on("request", lambda r: reqs.append(r.url) if "/api/" in r.url else None)
    # dunia tiruan tidak punya kalender: respons dashboard diisi event campuran (HIGH / MODERATE / LOW) untuk menguji tombol
    EVS = [dict(date=f"2026-12-0{i % 5 + 1} 13:30", country=c, event=f"Event {i} {imp}", impact=imp, forecast=None)
           for i, (c, imp) in enumerate([("US", "LOW"), ("US", "HIGH"), ("EU", "MODERATE"), ("GB", "HIGH"), ("JP", "LOW"), ("US", "HIGH"), ("CA", "MODERATE")])]

    def fake_dash(route):
        import json as _j
        r = route.fetch(); d = r.json()
        d["events"] = EVS; d["events_high"] = [e for e in EVS if e["impact"] == "HIGH"]
        route.fulfill(response=r, body=_j.dumps(d), headers=dict(r.headers, **{"content-type": "application/json"}))
    pg.route("**/api/dashboard*", fake_dash)
    pg.goto(BASE + "/#dashboard"); pg.wait_for_timeout(6000)
    sz = pg.evaluate("()=>{const m=document.querySelector('.dash-globe .gl-cv');if(!m)return [0,0];const r=m.getBoundingClientRect();return [r.width,r.height]}")
    check("globe 3D tampil di dashboard (menggantikan peta datar)", sz[0] > 300 and sz[1] > 200 and pg.locator("#view .leaflet-container").count() == 0, sz)
    labs = pg.locator(".dash-globe .gl-lb span").all_inner_texts()
    check("pemilih 4 layer: Risk, Maritime, Airplane, Cyber", [x.upper() for x in labs] == ["RISK", "MARITIME", "AIRPLANE", "CYBER"], labs)
    title = lambda: pg.locator(".panel:has(.dash-globe) .ph span").first.text_content()
    check("judul mengikuti layer (Risk)", "Risk" in title(), title())
    for lid, word in (("sea", "Maritime"), ("air", "Airplane"), ("cyber", "Cyber")):
        pg.click(f".dash-globe .gl-lb[data-id={lid}]"); pg.wait_for_timeout(2500)
        check(f"pindah layer {word}: tombol aktif + judul + data dimuat", pg.locator(f".dash-globe .gl-lb[data-id={lid}].on").count() == 1 and word in title()
              and any(f"/api/geo/{'sea' if lid == 'sea' else lid}" in u for u in reqs), title())
    check("legenda ringkas (terlipat) di dashboard", pg.locator(".dash-globe .lgd.compact").count() >= 1 and pg.locator(".dash-globe .lgd.lcp").count() == 0)
    pg.screenshot(path=os.path.join(OUT, "dashboard_globe.png"))
    # pilihan layer dashboard terpisah dari menu GEOPOLITICAL RISK
    pg.evaluate("location.hash='#geo'"); pg.wait_for_timeout(3500)
    check("menu Geo Risk tetap globe + feed, pilihan layer sendiri (Risk)", pg.locator("#view .gl-lb[data-id=risk].on").count() == 1 and pg.locator("#view .feed").count() >= 1)
    pg.evaluate("location.hash='#dashboard'"); pg.wait_for_timeout(3000)
    check("kembali ke dashboard: layer terakhir (Cyber) diingat", pg.locator(".dash-globe .gl-lb[data-id=cyber].on").count() == 1)

    # HIGH saja
    badges = lambda: pg.locator(".panel:has(.ph-tog) table.t tbody tr td:last-child").all_inner_texts()
    before = badges()
    pg.click(".ph-tog"); pg.wait_for_timeout(400)
    after = badges()
    msg = pg.locator(".panel:has(.ph-tog) .msg").count()
    check("HIGH saja: hanya rilis berdampak TINGGI", len(before) == 7 and after == ["HIGH", "HIGH", "HIGH"], (before, after))
    check("HIGH saja: tombol aktif & tersimpan per browser", pg.locator(".ph-tog.on").count() == 1 and pg.evaluate("JSON.parse(localStorage.getItem('tm.dash.v1')).evHigh===true"))
    pg.click(".ph-tog"); pg.wait_for_timeout(300)
    check("HIGH saja dimatikan: semua dampak kembali", badges() == before)

    # Macro Regime per negara
    check("regime: 10 tombol negara", pg.locator(".reg-pick button").count() == 10)
    rc = pg.evaluate("[...document.querySelectorAll('.reg-pick button')].map(b=>b.style.getPropertyValue('--rc')).filter(Boolean).length")
    check("regime: tombol negara berwarna sesuai regime-nya", rc >= 8, rc)
    pg.click(".reg-pick button[data-cc=JP]"); pg.wait_for_timeout(2500)
    txt = pg.locator(".panel:has(.reg-pick)").inner_text()
    check("regime Jepang tampil (permintaan macro/regime?cc=JP)", any("macro/regime" in u and "cc=JP" in u for u in reqs) and "JAPAN" in txt.upper()
          and pg.locator(".reg-pick button[data-cc=JP].on").count() == 1, txt[:160].replace("\n", " | "))
    check("regime: pilihan negara tersimpan", pg.evaluate("JSON.parse(localStorage.getItem('tm.dash.v1')).regCC==='JP'"))
    pg.screenshot(path=os.path.join(OUT, "dashboard_regime_high.png"))
    pg.reload(); pg.wait_for_timeout(5000)
    check("muat ulang: regime JP & tombol HIGH tetap", pg.locator(".reg-pick button[data-cc=JP].on").count() == 1 and pg.locator(".ph-tog.on").count() == 0)
    check("tanpa error JS", not errs, errs[:3])
    m = b.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    m.goto(BASE + "/#dashboard"); m.wait_for_timeout(5000)
    check("ponsel: tanpa scroll horizontal, globe tampil", m.evaluate("document.documentElement.scrollWidth<=innerWidth+1") and m.locator(".dash-globe .gl-cv").count() == 1)
    b.close()
print(f"{sum(ok)}/{len(ok)} lulus")
sys.exit(0 if all(ok) else 1)
