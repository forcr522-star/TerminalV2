"""Uji UI end-to-end dengan Chromium (Playwright) terhadap server tiruan:  python tests/run_mock_server.py &  python tests/ui_check.py [outdir]"""
import sys, json, time, collections
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8765"
OUT = sys.argv[1] if len(sys.argv) > 1 else "."
fails = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        fails.append(msg)


def main():
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={"width": 1280, "height": 800}, device_scale_factor=1)
        page = ctx.new_page()
        errors, reqs = [], collections.Counter()
        page.on("pageerror", lambda e: errors.append("pageerror: " + str(e)))
        page.on("console", lambda m: errors.append("console: " + m.text) if m.type == "error" and "Failed to load resource" not in m.text else None)
        page.on("request", lambda r: reqs.update([r.url.split("?")[0].replace(BASE, "")]) if "/api/" in r.url else None)
        sigurls = []
        page.on("request", lambda r: sigurls.append(r.url) if "/api/signal/pair" in r.url else None)
        page.goto(BASE + "/#dashboard")
        page.wait_for_timeout(3000)

        # 1. semua modul render tanpa error JS
        for mod in ["dashboard", "signal", "macro", "market", "centralbank", "fiscal", "intel", "etf", "financials", "participant", "geo", "supply", "quant", "futures"]:
            page.evaluate(f"location.hash='#{mod}'")
            page.wait_for_timeout(2500)
            page.screenshot(path=f"{OUT}/{mod}.png")
        check(not errors, f"tidak ada error JS di 14 modul {errors[:5]}")

        # 2. Central bank: chart terisi untuk US; NZ (yield gagal) menyembunyikan panel yang kosong
        page.evaluate("location.hash='#centralbank'"); page.wait_for_timeout(2000)
        info = page.evaluate("""()=>({charts:(window.echarts&&[...document.querySelectorAll('#view canvas')].length)||0, text:document.getElementById('view').innerText.length, txt:document.getElementById('view').innerText.slice(0,1500)})""")
        check(info["charts"] >= 1, f"CB overview punya chart canvas ({info['charts']})")
        # CB: tab negara -> chart + KPI terisi; NZ -> pesan jelas, bukan chart kosong
        def tab(label):
            page.locator("#view .tab, #view [class*=tab] >> text=" + label).first.click(); page.wait_for_timeout(1800)
        tab("UNITED STATES")
        us = page.evaluate("()=>({c:document.querySelectorAll('#view canvas').length,t:document.getElementById('view').innerText})")
        check(us["c"] >= 3, f"CB US: >=3 chart ({us['c']})")
        check("n/a" not in us["t"].lower(), "CB US: tidak ada teks n/a")
        tab("NEW ZEALAND")
        nz = page.evaluate("()=>document.getElementById('view').innerText")
        # Desain baru: data yang tidak ada TIDAK ditampilkan (tanpa kartu/kolom/chart kosong dan tanpa teks error teknis); data yang ada tetap tampil.
        nzu = nz.upper()
        check("POLICY RATE" in nzu and "GOVT 10Y" not in nzu and "2S10S" not in nzu and "BALANCE SHEET" not in nzu and "gagal" not in nz.lower() and "error" not in nz.lower(),
              "CB NZ: hanya data yang tersedia tampil (tanpa kartu yield/2s10s/neraca kosong atau teks error)")
        page.screenshot(path=f"{OUT}/cb_nz.png")
        tab("JAPAN")
        jp = page.evaluate("()=>document.getElementById('view').innerText")
        check(jp != us["t"], "CB: data Jepang berbeda dari AS")

        # Fiscal
        page.evaluate("location.hash='#fiscal'"); page.wait_for_timeout(2500)
        ft = page.evaluate("()=>document.getElementById('view').innerText")
        check("error" not in ft.lower()[:200] and "United States" in ft, "Fiscal render tanpa error")

        # Macro overview berbeda per negara
        page.evaluate("location.hash='#macro'"); page.wait_for_timeout(2500)
        texts = {}
        for lab in ("UNITED STATES", "JAPAN", "INDONESIA"):
            try:
                page.locator("#view >> text=" + lab).first.click(); page.wait_for_timeout(1800)
            except Exception:
                pass
            texts[lab] = page.evaluate("()=>document.getElementById('view').innerText")
        check(len(set(texts.values())) >= 2, "Macro: konten berbeda antar negara")

        # Catalyst map statis
        page.evaluate("location.hash='#intel'"); page.wait_for_timeout(2000)
        page.locator("#view >> text=CATALYST MAP").first.click(); page.wait_for_timeout(2500)
        page.screenshot(path=f"{OUT}/catmap.png")
        box = page.evaluate("()=>{const c=document.querySelector('#view canvas');if(!c)return null;const r=c.getBoundingClientRect();return [r.x,r.y,r.width,r.height]}")
        check(box is not None, "Catalyst Map: canvas ada")
        if box:
            before = page.screenshot(clip=dict(x=box[0], y=box[1], width=box[2], height=box[3]))
            page.mouse.move(box[0] + box[2] / 2, box[1] + box[3] / 2); page.mouse.down(); page.mouse.move(box[0] + box[2] / 2 + 120, box[1] + box[3] / 2 + 80, steps=8); page.mouse.up()
            page.mouse.wheel(0, -400); page.wait_for_timeout(600)
            after = page.screenshot(clip=dict(x=box[0], y=box[1], width=box[2], height=box[3]))
            check(before == after, "Catalyst Map: tidak bergeser oleh drag / scroll (statis)")

        # Financials: tombol LOAD (klik, Enter, dan sentuhan)
        page.evaluate("location.hash='#financials'"); page.wait_for_timeout(2000)
        n0 = reqs["/api/financials"]
        page.fill("#view input.in", "MSFT"); page.locator("#view button:has-text('Load')").click(); page.wait_for_timeout(1500)
        check(reqs["/api/financials"] > n0 and "MSFT" in page.evaluate("()=>document.getElementById('view').innerText"), "Financials: klik Load memuat MSFT")
        n1 = reqs["/api/financials"]
        page.fill("#view input.in", "NVDA"); page.keyboard.press("Enter"); page.wait_for_timeout(1500)
        check(reqs["/api/financials"] > n1 and "NVDA" in page.evaluate("()=>document.getElementById('view').innerText"), "Financials: Enter memuat NVDA")

        # Geo: peta tetap ada & berwarna setelah feed termuat, dan tidak hilang setelah polling
        page.evaluate("location.hash='#geo'"); page.wait_for_timeout(6000)
        g = page.evaluate("()=>{const m=document.querySelector('#view .leaflet-container');const r=m.getBoundingClientRect();return [r.width,r.height]}")
        check(g[0] > 400 and g[1] > 300, f"Geo: peta berukuran penuh {g}")
        page.wait_for_timeout(30000)
        g2 = page.evaluate("()=>{const m=document.querySelector('#view .leaflet-container');if(!m)return [0,0];const r=m.getBoundingClientRect();return [r.width,r.height]}")
        check(g2[0] > 400 and g2[1] > 300, f"Geo: peta masih ada setelah 30 dtk polling {g2}")


        # SIGNAL (admin, penjagaan mati): board MT5, kontrol BE / SINYAL, halaman INSIDE/ANALISIS, popup PILIH PAIR & MODE TRADING
        page.evaluate("localStorage.clear()")
        page.evaluate("location.hash='#dashboard'"); page.wait_for_timeout(500)
        page.evaluate("location.hash='#signal'"); page.wait_for_timeout(5000)
        vt = lambda: page.evaluate("()=>document.getElementById('view').innerText")
        nrows = lambda: page.locator("#view .sg-row").count()
        check(nrows() == 6, f"Signal: list 6 pair default ({nrows()})")
        t = vt()
        check("LIST PAIR YANG DI ANALISA" in t and "CHART" in t, "Signal: panel list pair + CHART tampil")
        check(all(page.locator(f"#view button:has-text('{b}')").count() >= 1 for b in ("BREAKEVEN", "SINYAL", "INSIDE/ANALISIS")), "Signal: tombol admin (BREAKEVEN / SINYAL / INSIDE-ANALISIS) tampil")
        check(all(x in t for x in ("TERBUKA", "LIMIT", "TERTUTUP")), "Signal: tab TERBUKA / LIMIT / TERTUTUP tampil")
        check(page.evaluate("()=>document.querySelectorAll('#view .sg-cbox canvas').length") >= 1, "Signal: chart candlestick tampil")
        check("Data tidak tersedia" not in t, "Signal: tidak ada pesan error")
        page.screenshot(path=f"{OUT}/signal_admin.png")
        for i in range(nrows()):
            page.locator("#view .sg-row").nth(i).click(); page.wait_for_timeout(1500)
            sym = page.locator("#view .sg-row").nth(i).get_attribute("data-sym")
            check(sym in page.locator("#view .sg-chead").inner_text(), f"Signal: klik {sym} mengganti chart")
        for tab in ("LIMIT", "TERTUTUP", "TERBUKA"):
            page.locator(f"#view .sg-tabs button:has-text('{tab}')").click(); page.wait_for_timeout(300)
        check(True, "Signal: tab order bisa dibuka")
        ctl = lambda: page.evaluate("async()=>(await (await fetch('/api/signal/control')).json())")
        c0 = ctl(); c0 = c0.get("data", c0)
        page.locator("#view button:has-text('BREAKEVEN')").click(); page.wait_for_timeout(1500)
        c1 = ctl(); c1 = c1.get("data", c1)
        check(c1["be"] != c0["be"] and ("BREAKEVEN: " + ("ON" if c1["be"] else "OFF")) in vt(), f"Signal: BREAKEVEN berpindah {c0['be']}->{c1['be']}")
        page.locator("#view button:has-text('BREAKEVEN')").click(); page.wait_for_timeout(1500)
        page.locator("#view button:has-text('SINYAL:')").click(); page.wait_for_timeout(1500)
        c2 = ctl(); c2 = c2.get("data", c2)
        check(c2["on"] is False and "SINYAL: OFF" in vt(), "Signal: SINYAL OFF (bot dilarang analisa)")
        page.locator("#view button:has-text('SINYAL:')").click(); page.wait_for_timeout(1500)
        c3 = ctl(); c3 = c3.get("data", c3)
        check(c3["on"] is True and c3["be"] == c0["be"], "Signal: SINYAL & BREAKEVEN kembali ke semula")

        page.locator("#view button:has-text('INSIDE/ANALISIS')").click(); page.wait_for_timeout(35000)
        check(page.evaluate("location.hash") == "#signal/inside", "Signal: INSIDE/ANALISIS membuka halaman terpisah")
        check(page.locator("#view .sgi-tile").count() == 10, f"Signal: 10 kartu ANALISA ({page.locator('#view .sgi-tile').count()})")
        it = vt()
        check(all(x in it for x in ("PILIH PAIR", "MODE TRADING", "HASIL ANALISA")), "Signal inside: tab PILIH PAIR / MODE TRADING / HASIL ANALISA")
        check(any(x in it for x in ("BULLISH", "BEARISH", "WAITING")), "Signal inside: status BULLISH/BEARISH/WAITING tampil")
        page.locator("#view .sgi-tile").nth(1).click(); page.wait_for_timeout(600)
        it = vt()
        check(all(x in it for x in ("TEKNIKAL", "VOLUME & LIQUIDITY", "FUNDAMENTAL", "QUANTITATIVE")), "Signal inside: alasan 4 bagian (teknikal, volume & liquidity, fundamental, quantitative)")
        page.screenshot(path=f"{OUT}/signal_inside.png")
        page.locator("#view button:has-text('PILIH PAIR')").click(); page.wait_for_timeout(1200)
        nchip = page.locator(".sg-modal .chip").count()
        check(nchip == 96, f"Signal: popup PILIH PAIR memuat semua pair tanpa terkecuali ({nchip})")
        page.locator(".sg-modal .chip[data-sym='Silver']").click()
        page.locator(".sg-modal button:has-text('SIMPAN')").click(); page.wait_for_timeout(2500)
        check(page.locator(".sg-modal").count() == 0 and page.locator("#view .sg-row:has-text('Silver')").count() == 1, "Signal: SIMPAN menambah Silver ke list analisa")
        page.locator("#view button:has-text('PILIH PAIR')").click(); page.wait_for_timeout(1200)
        page.locator(".sg-modal button:has-text('Default')").click()
        page.locator(".sg-modal button:has-text('SIMPAN')").click(); page.wait_for_timeout(2500)
        check(nrows() == 6, "Signal: Default mengembalikan 6 pair")
        page.locator("#view button:has-text('MODE TRADING')").click(); page.wait_for_timeout(800)
        check(page.locator(".sg-modal .sg-mode").count() == 3, "Signal: popup MODE TRADING punya 3 gaya")
        page.locator(".sg-modal .sg-mode[data-mode='swing']").click(); page.wait_for_timeout(2500)
        page.locator("#view button:has-text('SINYAL')").last.click(); page.wait_for_timeout(5000)
        check("D1" in page.locator("#view .sg-chead").inner_text(), "Signal: mode swing -> chart D1")
        page.locator("#view button:has-text('INSIDE/ANALISIS')").click(); page.wait_for_timeout(1500)
        page.locator("#view button:has-text('MODE TRADING')").click(); page.wait_for_timeout(500)
        page.locator(".sg-modal .sg-mode[data-mode='scalp']").click(); page.wait_for_timeout(2500)
        page.locator("#view button:has-text('SINYAL')").last.click(); page.wait_for_timeout(5000)
        check("M5" in page.locator("#view .sg-chead").inner_text(), "Signal: mode scalping -> chart M5")
        page.locator("#view button:has-text('INSIDE/ANALISIS')").click(); page.wait_for_timeout(1500)
        page.locator("#view button:has-text('MODE TRADING')").click(); page.wait_for_timeout(500)
        page.locator(".sg-modal .sg-mode[data-mode='intraday']").click(); page.wait_for_timeout(2500)
        page.locator("#view button:has-text('SINYAL')").last.click(); page.wait_for_timeout(5000)
        check("H1" in page.locator("#view .sg-chead").inner_text(), "Signal: mode intraday -> chart H1")
        page.set_viewport_size({"width": 390, "height": 800}); page.wait_for_timeout(2500)
        ov = page.evaluate("()=>document.documentElement.scrollWidth>document.documentElement.clientWidth+2||document.getElementById('view').scrollWidth>document.getElementById('view').clientWidth+2")
        check(not ov, "Signal: tidak ada scroll horizontal di layar HP 390px")
        page.screenshot(path=f"{OUT}/signal_mobile.png")
        page.set_viewport_size({"width": 1280, "height": 800})

        # Cache: kembali ke menu yang sudah dibuka tidak memicu fetch ulang segera
        page.evaluate("location.hash='#centralbank'"); page.wait_for_timeout(2500)
        c0 = reqs["/api/cb/overview"]
        for m in ("fiscal", "centralbank", "fiscal", "centralbank"):
            page.evaluate(f"location.hash='#{m}'"); page.wait_for_timeout(700)
        check(reqs["/api/cb/overview"] == c0, f"Cache: pindah menu tidak mengunduh ulang CB ({c0}->{reqs['/api/cb/overview']})")
        check(not errors, f"tidak ada error JS selama skenario {errors[:5]}")
        b.close()
    print("FAILS:", fails)
    sys.exit(1 if fails else 0)


main()
