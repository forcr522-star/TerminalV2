"""Dua kunci (admin / user), kontrol bot sinyal, runner, dan menu SIGNAL baru. Tanpa jaringan (dunia tiruan)."""
import asyncio
import json
import pathlib
import time

import pytest

import mockworld
from terminal import auth, config, store
from terminal.signals import control, journal, runner, board, explain
from terminal.signals.config import MODES, MODE_ORDER
from terminal.universe import ALL_ASSETS, BY_SYM


def run(coro):
    return asyncio.run(coro)


@pytest.fixture(autouse=True)
def _fresh_control():
    store.execute("DELETE FROM kv WHERE k LIKE 'sig_%'")
    store.execute("DELETE FROM signal_log")
    control.reload()
    runner.reset()
    yield
    store.execute("DELETE FROM kv WHERE k LIKE 'sig_%'")
    store.execute("DELETE FROM signal_log")
    control.reload()
    runner.reset()


@pytest.fixture()
def keyed(monkeypatch, tmp_path):
    """Server dengan penjagaan menyala: admin 'adm-key', user 'usr-key'."""
    mockworld.install(monkeypatch)
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ADMIN_KEY", "adm-key")
    monkeypatch.setattr(config, "USER_KEY", "usr-key")
    monkeypatch.setattr(config, "ACCESS_KEY", "")
    monkeypatch.setattr(config, "LLM_ENABLED", False)
    auth._cache.clear()
    from fastapi.testclient import TestClient
    from terminal import server
    with TestClient(server.app, follow_redirects=False) as c:
        yield c


def _login(client, key):
    r = client.get(f"/?key={key}")
    assert r.status_code == 303
    return r


# ------------------------------------------------------------------------------------------ auth: dua peran
def test_role_resolution(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ADMIN_KEY", "A1")
    monkeypatch.setattr(config, "USER_KEY", "U1")
    monkeypatch.setattr(config, "ACCESS_KEY", "")
    assert auth.role_for_key("A1") == "admin" and auth.role_for_key("U1") == "user"
    assert auth.role_for_key("x") is None and auth.role_for_key("") is None and auth.role_for_key(None) is None
    assert auth.session_token("admin") != auth.session_token("user")
    assert auth.role_for_cookie(auth.session_token("admin")) == "admin"
    assert auth.role_for_cookie(auth.session_token("user")) == "user"
    assert auth.role_for_cookie("zzz") is None
    assert auth.role_of({}, {"x-access-key": "U1"}) == "user" and auth.role_of({}, {"x-access-key": "A1"}) == "admin"
    assert auth.role_of({}, {}) is None


def test_legacy_access_key_is_admin(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ADMIN_KEY", "")
    monkeypatch.setattr(config, "ACCESS_KEY", "lama")
    monkeypatch.setattr(config, "USER_KEY", "U2")
    assert auth.role_for_key("lama") == "admin" and auth.role_for_key("U2") == "user"


def test_user_key_equal_to_admin_key_is_ignored(monkeypatch, tmp_path):
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "DATA_DIR", pathlib.Path(tmp_path))
    monkeypatch.setattr(config, "ADMIN_KEY", "sama")
    monkeypatch.setattr(config, "USER_KEY", "sama")
    auth._cache.clear()
    assert auth.user_key_conflict()
    assert auth.role_for_key("sama") == "admin"          # tidak pernah turun jadi user
    assert auth.user_key() != "sama" and auth.role_for_key(auth.user_key()) == "user"


def test_user_key_none_disables_user_role(monkeypatch):
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    monkeypatch.setattr(config, "ADMIN_KEY", "A1")
    monkeypatch.setattr(config, "USER_KEY", "none")
    assert auth.user_key() == "" and auth.role_for_key("none") is None
    assert auth.role_for_cookie(auth._token("", b"terminal-session-user-v1")) is None


def test_auth_disabled_everyone_is_admin(monkeypatch):
    monkeypatch.setattr(config, "ADMIN_KEY", "none")
    monkeypatch.setattr(config, "DEV_NO_AUTH", False)
    monkeypatch.setattr(auth, "DEV_NO_AUTH", False)
    assert not auth.enabled() and auth.role_of({}, {}) == "admin"


# ------------------------------------------------------------------------------------------ middleware / pembatasan API
ADMIN_PATHS = ["signal/universe", "signal/catalog", "signal/history", "signal/control", "signal/detail?symbol=EURUSD", "signal/pair?symbol=EURUSD", "health", "status"]
USER_PATHS = ["signal/board", "ping", "me"]


def test_user_cannot_reach_admin_endpoints_but_can_use_board(keyed):
    _login(keyed, "usr-key")
    assert keyed.get("/api/me").json() == {"role": "user"}
    for p in ADMIN_PATHS:
        r = keyed.get("/api/" + p)
        assert r.status_code == 403, (p, r.status_code)
    r = keyed.get("/api/signal/board")
    assert r.status_code == 200 and "pairs" in r.json()["data"] if "data" in r.json() else "pairs" in r.json()
    assert keyed.post("/api/signal/control", json={"on": False}).status_code == 403
    assert control.get()["on"] is True


def test_admin_reaches_everything_and_unauth_is_401(keyed):
    assert keyed.get("/api/signal/board").status_code == 401
    assert keyed.post("/api/signal/control", json={"on": False}).status_code == 401
    _login(keyed, "adm-key")
    assert keyed.get("/api/me").json() == {"role": "admin"}
    assert keyed.get("/api/signal/control").status_code == 200
    assert keyed.get("/api/signal/catalog").status_code == 200
    assert keyed.get("/api/signal/board").status_code == 200


def test_header_key_roles(keyed):
    assert keyed.get("/api/me", headers={"x-access-key": "usr-key"}).json()["role"] == "user"
    assert keyed.get("/api/me", headers={"x-access-key": "adm-key"}).json()["role"] == "admin"
    assert keyed.get("/api/me", headers={"x-access-key": "nope"}).status_code == 401


def test_source_problem_warning_only_for_admin(keyed):
    _login(keyed, "usr-key")
    r = keyed.get("/api/rev")
    assert r.status_code == 200 and r.json().get("bad", 0) == 0
    keyed.cookies.clear()
    _login(keyed, "adm-key")
    assert keyed.get("/api/rev").status_code == 200


def test_wrong_key_rejected_both_roles(keyed):
    r = keyed.get("/?key=salah")
    assert r.status_code == 401 and "Kunci salah" in r.text


# ------------------------------------------------------------------------------------------ kontrol (POST /api/signal/control)
def test_control_update_validation_and_persistence(keyed):
    _login(keyed, "adm-key")
    r = keyed.post("/api/signal/control", json={"be": False, "mode": "swing", "on": False})
    assert r.status_code == 200
    st = r.json()["state"]
    assert (st["be"], st["mode"], st["on"]) == (False, "swing", False)
    control.reload()                                         # simulasi restart: baca ulang dari database
    assert control.get()["mode"] == "swing" and control.get()["be"] is False and control.get()["on"] is False
    # validasi: tidak ada yang berubah bila salah satu nilai salah
    before = control.get()
    for bad in ({"mode": "harian"}, {"on": "ya"}, {"be": 1}, {"pairs": ["NGAWUR"]}, {"pairs": "EURUSD"}, {"foo": 1}):
        assert keyed.post("/api/signal/control", json=bad).status_code == 422, bad
    assert keyed.post("/api/signal/control", json={"mode": "scalp", "on": "ya"}).status_code == 422
    assert control.get() == before
    assert keyed.post("/api/signal/control", content=b"bukan json", headers={"content-type": "application/json"}).status_code == 400
    assert keyed.post("/api/signal/control", json=[1]).status_code == 400


def test_control_pairs_canonical_and_dedup():
    st = control.update(pairs=["eurusd", "EURUSD", "gold", "BITCOIN", "US 13W"] if False else ["eurusd", "EURUSD", "gold", "bitcoin"])
    assert st["pairs"] == ["EURUSD", "Gold", "Bitcoin"]
    with pytest.raises(ValueError):
        control.update(pairs=["EURUSD", "XXX"])
    assert control.get()["pairs"] == ["EURUSD", "Gold", "Bitcoin"]
    assert control.update(pairs=[])["pairs"] == []


def test_control_rev_bumps_only_on_change():
    r0 = control.get()["rev"]
    control.update(be=control.get()["be"])
    assert control.get()["rev"] == r0
    control.update(be=not control.get()["be"])
    assert control.get()["rev"] == r0 + 1


def test_control_defaults_and_corrupt_data_is_repaired():
    d = control.get()
    assert d["on"] and d["be"] and d["mode"] == "intraday" and d["pairs"] == control.DEFAULT_PAIRS
    store.kv_set(control.KEY, {"on": "x", "mode": "zzz", "pairs": ["EURUSD", "NGAWUR", "gold"], "be": False})
    s = control.reload()
    assert s["on"] is True and s["mode"] == "intraday" and s["be"] is False and s["pairs"] == ["EURUSD", "Gold"]


def test_catalog_has_every_pair_without_exception(keyed):
    _login(keyed, "adm-key")
    j = keyed.get("/api/signal/catalog").json()
    d = j.get("data", j)
    syms = {x["sym"] for v in d["classes"].values() for x in v}
    assert syms == {a["sym"] for a in ALL_ASSETS} and d["total"] == len(ALL_ASSETS)
    assert set(d["classes"]) == {"FX", "COMMODITY", "INDEX", "CRYPTO", "BOND"}
    # semua pair katalog bisa disimpan sebagai daftar analisa
    st = control.update(pairs=sorted(syms))
    assert len(st["pairs"]) == len(ALL_ASSETS)


# ------------------------------------------------------------------------------------------ runner
def test_off_means_no_analysis_and_no_new_signal(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(on=False)
    assert run(runner.run_once()) == 0
    assert runner.RESULTS == {} and journal.active_all() == []
    assert run(runner.analyze_one("EURUSD")) is False


def test_on_analyzes_all_selected_pairs_and_stores_results(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(pairs=["EURUSD", "Gold"])
    assert run(runner.run_once()) == 2
    assert set(runner.RESULTS) == {"EURUSD", "Gold"}
    ov = {o["sym"]: o for o in runner.overview()}
    for s in ("EURUSD", "Gold"):
        o = ov[s]
        assert o["ready"] and o["fresh"] and o["dom"] in ("BUY", "SELL", "NEUTRAL") and o["bull"] + o["bear"] + o["wait"] == 10
    # tidak jatuh tempo lagi -> tidak dikerjakan ulang
    assert run(runner.run_once()) == 0
    # hasil bertahan setelah restart
    runner.RESULTS.clear()
    assert runner.load() == 2
    json.dumps(runner.RESULTS)                               # bisa di-JSON-kan


def test_mode_or_be_change_triggers_reanalysis(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(pairs=["EURUSD"])
    run(runner.run_once())
    assert runner.RESULTS["EURUSD"]["mode"] == "intraday"
    control.update(mode="swing")
    assert not runner.overview()[0]["fresh"]
    assert run(runner.run_once()) == 1 and runner.RESULTS["EURUSD"]["mode"] == "swing"
    control.update(be=False)
    assert run(runner.run_once()) == 1 and runner.RESULTS["EURUSD"]["be"] is False


def test_removed_pair_results_are_dropped(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(pairs=["EURUSD", "Gold"])
    run(runner.run_once())
    st = control.update(pairs=["EURUSD"])
    runner.on_control_changed(st)
    assert "Gold" not in runner.RESULTS
    assert store.kv_get(runner.KV_PREFIX + "Gold") is None
    with pytest.raises(ValueError):
        runner.detail("Gold")


def test_error_backoff(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(pairs=["EURUSD"])
    from terminal.signals import service

    async def boom(*a, **k):
        raise RuntimeError("sumber mati")
    monkeypatch.setattr(service, "analyze", boom)
    assert run(runner.run_once()) == 1
    assert "EURUSD" in runner.ERRORS and runner.overview()[0]["error"].startswith("RuntimeError")
    assert run(runner.run_once()) == 0                       # ditahan backoff, tidak menghajar sumber data


@pytest.mark.parametrize("mode", MODE_ORDER)
def test_all_pairs_all_modes_analyze_and_explain(monkeypatch, mode):
    """Semua 96 pair x 3 gaya: analisa jalan, 10 kartu, teks penjelasan lengkap, tanpa error."""
    mockworld.install(monkeypatch)
    allsyms = [a["sym"] for a in ALL_ASSETS]
    control.update(pairs=allsyms, mode=mode)
    n = run(runner.run_once(concurrency=6))
    assert n == len(allsyms)
    assert not runner.ERRORS, dict(list(runner.ERRORS.items())[:3])
    for s in allsyms:
        d = runner.detail(s)
        assert d["ready"] and len(d["tiles"]) == 10 and d["mode"] == mode
        assert {t["state"] for t in d["tiles"]} <= {"BULLISH", "BEARISH", "WAITING"}
        assert d["bull"] + d["bear"] + d["wait"] == 10
        ex = d["explain"]
        assert ex and len(ex["methods"]) == 10
        for m in ex["methods"].values():
            assert m["sections"] and all(sec["lines"] for sec in m["sections"])
        titles = [sec["title"] for sec in ex["overall"]["sections"]]
        for need in ("TEKNIKAL", "VOLUME & LIQUIDITY", "FUNDAMENTAL", "QUANTITATIVE"):
            assert any(need in t for t in titles), (s, titles)
        assert ex["overall"]["state"] in ("BUY", "SELL", "WAIT")
        json.dumps(d)


# ------------------------------------------------------------------------------------------ board (menu SIGNAL)
def _plan(d=1, entry=100.0, risk=1.0):
    return dict(d=d, entry=entry, sl=entry - d * risk, tp=[entry + d * risk * k for k in (0.8, 1.7, 3.0)], w=[0.4, 0.3, 0.3], expiry=6, max_hold=48)


def _row_ts():
    return "2026-11-08 10:00:00"


def test_order_out_rr_geometry():
    row = dict(id=1, sym="EURUSD", mode="intraday", be=1, side="BUY", created=time.time(), closed=None, bar_ts=_row_ts(), plan=_plan(1), status="PENDING", r=0.0, tp_hits=0)
    o = board.order_out(row, dict(price=99.5, hits=0, sl_now=99.0))
    assert o["side"] == "LONG" and o["kind"] == "BUY LIMIT" and o["rr"] == [0.8, 1.7, 3.0] and o["risk"] == 1.0 and o["dist_r"] == 0.5
    row = dict(row, plan=_plan(-1), status="OPEN")
    o = board.order_out(row, dict(price=99.5, hits=0, r_total=0.5, sl_now=101.0))
    assert o["side"] == "SHORT" and o["kind"] == "SELL" and o["sl"] == 101.0 and o["r"] == 0.5


def test_board_classifies_open_limit_closed_and_hides_internals(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(pairs=["EURUSD", "GBPUSD", "Gold", "Bitcoin"])
    from terminal.providers import yahoo
    df = run(yahoo.ohlcv(BY_SYM["EURUSD"]["y"], MODES["intraday"]["yf_period"], MODES["intraday"]["yf_interval"]))
    last = float(df["c"].iloc[-1])
    # limit BUY yang belum tersentuh: entry 3% di bawah harga, bar terbit = bar terakhir (belum kedaluwarsa)
    a = journal.create("EURUSD", "intraday", True, "BUY", str(df.index[-1]), _plan(1, entry=last * 0.97, risk=last * 0.003), "t")
    b = journal.create("GBPUSD", "intraday", True, "SELL", _row_ts(), _plan(-1), "t")
    c = journal.create("Gold", "intraday", True, "BUY", _row_ts(), _plan(1), "t")
    d = journal.create("Bitcoin", "intraday", True, "BUY", _row_ts(), _plan(1), "t")
    journal.update(b, "OPEN", 0.3, 1)
    journal.update(c, "TP2", 1.7, 2)
    journal.update(d, "EXPIRED", 0.0, 0)
    out = run(board.build("EURUSD"))
    assert out["symbol"] == "EURUSD" and out["mode"] == "intraday" and out["tf"] == "H1"
    assert [o["id"] for o in out["orders"]["limit"]] == [a]
    assert [o["id"] for o in out["orders"]["open"]] == [b]
    assert {o["id"] for o in out["orders"]["closed"]} == {c, d}
    cl = {o["id"]: o for o in out["orders"]["closed"]}
    assert cl[c]["r"] == 1.7 and cl[d]["r"] is None
    assert out["orders"]["stats"]["n"] == 1 and out["orders"]["stats"]["cancelled"] == 1
    assert out["chart"]["candles"] and out["chart"]["tf"] == "H1"
    assert out["chart"]["order"] and out["chart"]["order"]["id"] == a
    txt = json.dumps(out)
    for leak in ("explain", "votes", "tiles", "posterior", "kelly"):
        assert leak not in txt, leak
    # pair di list = pair pilihan developer, urutan sama
    assert [p["sym"] for p in out["pairs"]] == ["EURUSD", "GBPUSD", "Gold", "Bitcoin"]
    # pilihan pair tidak dikenal -> jatuh ke pair pertama
    assert run(board.build("NGAWUR"))["symbol"] == "EURUSD"
    assert run(board.build("Gold"))["symbol"] == "Gold"


@pytest.mark.parametrize("mode,tf", [("scalp", "M5"), ("intraday", "H1"), ("swing", "D1")])
def test_board_chart_follows_global_mode(monkeypatch, mode, tf):
    mockworld.install(monkeypatch)
    control.update(pairs=["EURUSD"], mode=mode)
    out = run(board.build(""))
    assert out["tf"] == tf and out["chart"]["tf"] == tf and len(out["chart"]["candles"]) > 20


def test_board_with_no_pairs_is_empty_not_error(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(pairs=[])
    out = run(board.build(""))
    assert out["pairs"] == [] and out["symbol"] is None and out["chart"] is None


# ------------------------------------------------------------------------------------------ pelacak order + breakeven
def test_tracker_updates_orders_and_respects_be_flag(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(pairs=["EURUSD"])
    from terminal.providers import yahoo
    df = run(yahoo.ohlcv(BY_SYM["EURUSD"]["y"], MODES["intraday"]["yf_period"], MODES["intraday"]["yf_interval"]))
    last = float(df["c"].iloc[-1])
    ts = str(df.index[-30])
    pl = _plan(1, entry=last * 0.5, risk=last * 0.001)           # entry jauh di bawah harga -> tidak pernah terisi
    sid = journal.create("EURUSD", "intraday", True, "BUY", ts, pl, "t")
    assert run(runner.track_once()) == 1
    row = journal.get(sid)
    assert row["status"] in ("PENDING", "EXPIRED", "MISSED")
    # OFF tidak menghentikan pelacakan order yang sudah ada
    control.update(on=False)
    assert run(runner.track_once()) in (0, 1)


def test_explain_state_and_tiles_match_votes(monkeypatch):
    mockworld.install(monkeypatch)
    control.update(pairs=["Gold"])
    run(runner.run_once())
    d = runner.detail("Gold")
    V = runner.RESULTS["Gold"]["votes"]
    assert sum(t["state"] == "BULLISH" for t in d["tiles"]) == V["bull"]
    assert sum(t["state"] == "BEARISH" for t in d["tiles"]) == V["bear"]
    assert d["dom"] == ("BUY" if V["bull"] > V["bear"] else "SELL" if V["bear"] > V["bull"] else "NEUTRAL")


def test_pair_endpoint_respects_off(keyed):
    _login(keyed, "adm-key")
    control.update(on=False)
    r = keyed.get("/api/signal/pair?symbol=EURUSD")
    assert r.status_code >= 400 or "OFF" in json.dumps(r.json())
