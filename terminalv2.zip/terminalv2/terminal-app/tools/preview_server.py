"""Jalankan terminal untuk pratinjau lokal di Browser pane (tanpa tunnel Cloudflare).

Sama seperti `python main.py`, tetapi PUBLIC_URL diisi alamat lokal supaya banner langsung mencetak
alamat admin/user tanpa menunggu tunnel. Tidak dipakai di produksi.
"""
import os
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

os.environ.setdefault("PUBLIC_URL", f"http://127.0.0.1:{os.environ.get('PORT', '8787')}")
os.environ.setdefault("PRELOAD_TIMEOUT", "120")

import asyncio  # noqa: E402

from main import amain  # noqa: E402

if __name__ == "__main__":
    try:
        asyncio.run(amain())
    except KeyboardInterrupt:
        pass
