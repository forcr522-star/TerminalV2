"""Tata 7 jendela Terminal ke grid 3x3 monitor utama (Windows).

    baris 1 : NEWS AGENT      | TEKNIKAL AGENT | FUNDAMENTAL AGENT
    baris 2 : VOLUME AGENT    | QUANT AGENT    | TERMINAL SERVER (UTAMA)
    baris 3 : FEBRIAN AGENT   | (kosong)       | (kosong)

Hanya pustaka standar + Win32 user32/kernel32 (tanpa PowerShell). Jendela SERVER adalah konsol yang menjalankan
skrip ini (GetConsoleWindow), jadi tidak bergantung pada judul ("Administrator: ..." tidak lagi membuatnya hilang).
Jendela yang tidak ditemukan dilaporkan, tetapi tidak menghentikan server.

    python tools/arrange_terminals.py            # tata sekarang (menunggu jendela muncul maks. 25 dtk)
    python tools/arrange_terminals.py --print    # hanya cetak rencana posisi (bisa dijalankan di OS apa pun)
"""
from __future__ import annotations

import ctypes
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from terminal.layout import SERVER_TITLE, TITLES, cells, title_matches  # noqa: E402

WAIT_SECONDS = float(os.getenv("ARRANGE_WAIT", "25"))
SW_RESTORE = 9
SPI_GETWORKAREA = 0x0030
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
CONSOLE_CLASSES = ("ConsoleWindowClass", "CASCADIA_HOSTING_WINDOW_CLASS", "PseudoConsoleWindow")


def _load_win32():
    from ctypes import wintypes

    class RECT(ctypes.Structure):
        _fields_ = (("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG))

    class FILETIME(ctypes.Structure):
        _fields_ = (("dwLowDateTime", wintypes.DWORD), ("dwHighDateTime", wintypes.DWORD))

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    enum_proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    user32.EnumWindows.argtypes = (enum_proc, wintypes.LPARAM)
    user32.EnumWindows.restype = wintypes.BOOL
    user32.IsWindowVisible.argtypes = (wintypes.HWND,)
    user32.IsWindowVisible.restype = wintypes.BOOL
    user32.GetWindowTextLengthW.argtypes = (wintypes.HWND,)
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
    user32.GetClassNameW.restype = ctypes.c_int
    user32.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.ShowWindow.argtypes = (wintypes.HWND, ctypes.c_int)
    user32.ShowWindow.restype = wintypes.BOOL
    user32.MoveWindow.argtypes = (wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.BOOL)
    user32.MoveWindow.restype = wintypes.BOOL
    user32.SetProcessDPIAware.argtypes = ()
    user32.SetProcessDPIAware.restype = wintypes.BOOL
    user32.SystemParametersInfoW.argtypes = (wintypes.UINT, wintypes.UINT, ctypes.POINTER(RECT), wintypes.UINT)
    user32.SystemParametersInfoW.restype = wintypes.BOOL
    kernel32.GetConsoleWindow.argtypes = ()
    kernel32.GetConsoleWindow.restype = wintypes.HWND
    kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ctypes.POINTER(FILETIME),) * 4
    kernel32.GetProcessTimes.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL
    return user32, kernel32, RECT, FILETIME, enum_proc


class Win:
    def __init__(self):
        from ctypes import wintypes
        self.wt = wintypes
        self.user32, self.kernel32, self.RECT, self.FILETIME, self.enum_proc = _load_win32()
        self.user32.SetProcessDPIAware()

    def _created(self, pid):
        h = self.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not h:
            return 0
        try:
            t = [self.FILETIME() for _ in range(4)]
            if not self.kernel32.GetProcessTimes(h, *[ctypes.byref(x) for x in t]):
                return 0
            return (int(t[0].dwHighDateTime) << 32) | int(t[0].dwLowDateTime)
        finally:
            self.kernel32.CloseHandle(h)

    def windows(self):
        rows = []
        u = self.user32

        @self.enum_proc
        def cb(hwnd, _lp):
            if not u.IsWindowVisible(hwnd):
                return True
            n = max(512, int(u.GetWindowTextLengthW(hwnd)) + 1)
            buf = ctypes.create_unicode_buffer(n)
            u.GetWindowTextW(hwnd, buf, n)
            title = buf.value.strip()
            if not title:
                return True
            cls = ctypes.create_unicode_buffer(256)
            u.GetClassNameW(hwnd, cls, 256)
            pid = self.wt.DWORD(0)
            u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            rows.append(dict(handle=hwnd, title=title, cls=cls.value, pid=int(pid.value), created=self._created(int(pid.value))))
            return True

        u.EnumWindows(cb, 0)
        return rows

    def own_console(self):
        h = self.kernel32.GetConsoleWindow()
        return h or None

    def work_area(self):
        r = self.RECT()
        if not self.user32.SystemParametersInfoW(SPI_GETWORKAREA, 0, ctypes.byref(r), 0):
            raise OSError("SystemParametersInfoW(SPI_GETWORKAREA) gagal")
        return r.left, r.top, r.right, r.bottom

    def place(self, hwnd, x, y, w, h):
        self.user32.ShowWindow(hwnd, SW_RESTORE)
        return bool(self.user32.MoveWindow(hwnd, x, y, w, h, True))


def pick(rows, target, exclude=()):
    """Jendela terbaru yang judulnya cocok; jendela konsol didahulukan (browser/Explorer dengan judul mirip diabaikan)."""
    m = [r for r in rows if r["handle"] not in exclude and title_matches(r["title"], target)]
    con = [r for r in m if r.get("cls") in CONSOLE_CLASSES]
    return max(con or m, key=lambda r: r["created"], default=None)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--print" in argv:
        for title, col, row, x, y, w, h in cells(0, 0, 1920, 1040):
            print(f"[LAYOUT] {title:<26} kolom {col + 1}, baris {row + 1}  ({x},{y}) {w}x{h}  (contoh layar 1920x1040)")
        return 0
    if os.name != "nt":
        print("[LAYOUT] Bukan Windows; penataan jendela dilewati.", flush=True)
        return 0

    win = Win()
    found = {}
    own = win.own_console()
    if own:
        found[SERVER_TITLE] = dict(handle=own, title=SERVER_TITLE)
    deadline = time.monotonic() + WAIT_SECONDS
    while len(found) < len(TITLES):
        rows = win.windows()
        used = {v["handle"] for v in found.values()}
        for target in TITLES:
            if target not in found:
                r = pick(rows, target, exclude=used)
                if r is not None:
                    found[target] = r
                    used.add(r["handle"])
        if len(found) >= len(TITLES) or time.monotonic() >= deadline:
            break
        time.sleep(0.3)

    left, top, right, bottom = win.work_area()
    for title, col, row, x, y, w, h in cells(left, top, right, bottom):
        r = found.get(title)
        if r is None:
            continue
        ok = win.place(r["handle"], x, y, w, h)
        print(f"[LAYOUT] {title:<24} -> kolom {col + 1}, baris {row + 1} ({w}x{h}){'' if ok else '  [GAGAL dipindah]'}", flush=True)

    missing = [t for t in TITLES if t not in found]
    if missing:
        print(f"[LAYOUT] Peringatan: {len(found)}/{len(TITLES)} jendela ditemukan; belum ada: {', '.join(missing)}. Server tetap dilanjutkan.", flush=True)
    else:
        print("[LAYOUT] 7 terminal tertata: baris 1-2 = 5 agent + SERVER, baris 3 kolom 1 = FEBRIAN.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
