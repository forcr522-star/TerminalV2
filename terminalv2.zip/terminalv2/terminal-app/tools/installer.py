"""Pemasang otomatis Terminal: periksa semua modul & bahan, pasang HANYA yang belum ada.

Hanya memakai pustaka standar Python (berjalan sebelum dependensi proyek terpasang).
Dijalankan oleh install.bat / install.sh:   python tools/installer.py [--no-ollama] [--no-prompt] [--check]
  --check      hanya memeriksa dan melaporkan, tidak memasang apa pun
  --no-prompt  tidak menanyakan apa pun (untuk otomasi; saat ini tidak ada pertanyaan wajib)
"""
import hashlib
import importlib.metadata as md
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
IS_WIN = os.name == "nt"
VENV = ROOT / ".venv"
VENV_PY = VENV / ("Scripts/python.exe" if IS_WIN else "bin/python")
MARK = ROOT / ".install_ok"
MIN_PY = (3, 10)
OK, SKIP, FIX, BAD = "[OK]   ", "[SKIP] ", "[PASANG]", "[GAGAL]"


def say(tag, msg):
    print(f"{tag} {msg}", flush=True)


def run(cmd, **kw):
    return subprocess.run(cmd, **kw)


# ---------------------------------------------------------------------------------------------- requirements
def parse_requirements(text):
    """-> [(nama_paket, spesifikasi_versi_min_atau_None)] dari requirements.txt."""
    out = []
    for line in text.splitlines():
        line = line.split("#")[0].strip()
        if not line or line.startswith("-"):
            continue
        m = re.match(r"^([A-Za-z0-9_.\-]+)(\[[^\]]*\])?\s*(?:(>=|==|~=|>|<=|<|!=)\s*([0-9][^\s,;]*))?", line)
        if m:
            out.append((m.group(1), m.group(3), m.group(4)))
    return out


def _vt(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4])


def installed_version(pkg, python=None):
    """Versi paket terpasang di interpreter tertentu (default: interpreter ini) atau None."""
    if python is None or Path(python) == Path(sys.executable):
        try:
            return md.version(pkg)
        except md.PackageNotFoundError:
            return None
    code = f"import importlib.metadata as m\ntry:\n print(m.version({pkg!r}))\nexcept Exception:\n print('')"
    r = run([str(python), "-c", code], capture_output=True, text=True)
    v = (r.stdout or "").strip()
    return v or None


def satisfied(have, op, want):
    if not have:
        return False
    if not op or not want:
        return True
    a, b = _vt(have), _vt(want)
    return {">=": a >= b, "==": a == b, "~=": a >= b, ">": a > b, "<=": a <= b, "<": a < b, "!=": a != b}[op]


def missing_packages(reqs, python=None):
    return [(p, op, v) for p, op, v in reqs if not satisfied(installed_version(p, python), op, v)]


# ---------------------------------------------------------------------------------------------- langkah-langkah
def step_python():
    ok = sys.version_info >= MIN_PY
    say(OK if ok else BAD, f"Python {platform.python_version()} (butuh >= {MIN_PY[0]}.{MIN_PY[1]})")
    return ok


def step_venv(check):
    if VENV_PY.exists():
        say(SKIP, "virtualenv .venv sudah ada")
        return True
    if check:
        say(BAD, "virtualenv .venv belum ada")
        return False
    say(FIX, "membuat virtualenv .venv ...")
    return run([sys.executable, "-m", "venv", str(VENV)]).returncode == 0 and VENV_PY.exists()


def step_requirements(check):
    reqs = parse_requirements((ROOT / "requirements.txt").read_text(encoding="utf-8"))
    py = VENV_PY if VENV_PY.exists() else sys.executable
    miss = missing_packages(reqs, py)
    for p, op, v in reqs:
        if (p, op, v) not in miss:
            say(SKIP, f"{p} sudah terpasang ({installed_version(p, py)})")
    if not miss:
        return True
    names = [p for p, _, _ in miss]
    if check:
        for n in names:
            say(BAD, f"{n} belum terpasang")
        return False
    say(FIX, f"memasang {len(names)} modul yang belum ada: {', '.join(names)}")
    specs = [f"{p}{op or ''}{v or ''}" for p, op, v in miss]
    r = run([str(py), "-m", "pip", "install", "--disable-pip-version-check", *specs])
    if r.returncode != 0:
        say(BAD, "pip gagal; periksa koneksi internet lalu jalankan install.bat lagi")
        return False
    left = missing_packages(reqs, py)
    for p, _, _ in left:
        say(BAD, f"{p} masih belum terpasang")
    return not left


def cloudflared_asset():
    s, m = platform.system().lower(), platform.machine().lower()
    arm = "arm64" if ("arm" in m or "aarch" in m) else "amd64"
    if s == "windows":
        return f"cloudflared-windows-{'amd64' if '64' in m else '386'}.exe", "cloudflared.exe", False
    if s == "darwin":
        return f"cloudflared-darwin-{arm}.tgz", "cloudflared", True
    return f"cloudflared-linux-{arm}", "cloudflared", False


def find_cloudflared():
    env = os.getenv("CLOUDFLARED_PATH", "").strip()
    if env and os.path.exists(env):
        return env
    w = shutil.which("cloudflared")
    if w:
        return w
    _, name, _ = cloudflared_asset()
    p = ROOT / "bin" / name
    return str(p) if p.exists() else None


def download(url, timeout=180):
    req = urllib.request.Request(url, headers={"User-Agent": "terminal-installer"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def step_cloudflared(check):
    f = find_cloudflared()
    if f:
        say(SKIP, f"cloudflared sudah ada ({f})")
        return True
    if check:
        say(BAD, "cloudflared belum ada")
        return False
    asset, name, tgz = cloudflared_asset()
    say(FIX, f"mengunduh cloudflared ({asset}) ...")
    try:
        data = download("https://github.com/cloudflare/cloudflared/releases/latest/download/" + asset)
        (ROOT / "bin").mkdir(exist_ok=True)
        target = ROOT / "bin" / name
        if tgz:
            import io
            with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as t:
                m = next(x for x in t.getmembers() if x.name.endswith("cloudflared"))
                target.write_bytes(t.extractfile(m).read())
        else:
            target.write_bytes(data)
        target.chmod(target.stat().st_mode | stat.S_IEXEC)
        say(OK, f"cloudflared terpasang di {target}")
        return True
    except Exception as exc:
        say(BAD, f"gagal mengunduh cloudflared: {exc}")
        return False


def find_ollama():
    w = shutil.which("ollama")
    if w:
        return w
    cands = []
    if IS_WIN:
        for env in ("LOCALAPPDATA", "ProgramFiles"):
            base = os.getenv(env)
            if base:
                cands.append(Path(base) / "Programs" / "Ollama" / "ollama.exe")
                cands.append(Path(base) / "Ollama" / "ollama.exe")
    else:
        cands += [Path("/usr/local/bin/ollama"), Path("/usr/bin/ollama"), Path("/opt/homebrew/bin/ollama")]
    return next((str(c) for c in cands if c.exists()), None)


def read_env():
    env = {}
    f = ROOT / ".env"
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    return env


def ollama_api(host, path, timeout=4):
    try:
        with urllib.request.urlopen(host.rstrip("/") + path, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except Exception:
        return None


def model_present(tags, model):
    names = [m.get("name", "") for m in (tags or {}).get("models", [])]
    base = model.split(":")[0]
    return model in names or (":" not in model and any(n.split(":")[0] == base for n in names))


def step_ollama(check):
    env = read_env()
    host = env.get("OLLAMA_HOST") or "http://127.0.0.1:11434"
    model = env.get("OLLAMA_MODEL") or "gemma3:1b"
    if env.get("LLM_ENABLED", "1") == "0":
        say(SKIP, "AI lokal dimatikan (LLM_ENABLED=0)")
        return True
    exe = find_ollama()
    if exe:
        say(SKIP, f"Ollama sudah terpasang ({exe})")
    elif check:
        say(BAD, "Ollama belum terpasang")
        return False
    else:
        say(FIX, "memasang Ollama ...")
        exe = install_ollama()
        if not exe:
            say(BAD, "Ollama gagal dipasang otomatis. Pasang manual dari https://ollama.com/download lalu jalankan install.bat lagi (aplikasi tetap jalan dengan narasi otomatis tanpa AI).")
            return False
        say(OK, f"Ollama terpasang ({exe})")
    if ollama_api(host, "/api/version") is None:
        if check:
            say(BAD, "server Ollama belum berjalan")
            return False
        say(FIX, "menyalakan server Ollama ...")
        flags = (getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)) if IS_WIN else 0
        try:
            subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, creationflags=flags)
        except Exception as exc:
            say(BAD, f"gagal menjalankan ollama serve: {exc}")
            return False
        for _ in range(30):
            time.sleep(1)
            if ollama_api(host, "/api/version") is not None:
                break
        else:
            say(BAD, "server Ollama tidak merespons")
            return False
    else:
        say(SKIP, "server Ollama sudah berjalan")
    if model_present(ollama_api(host, "/api/tags"), model):
        say(SKIP, f"model {model} sudah ada")
        return True
    if check:
        say(BAD, f"model {model} belum diunduh")
        return False
    say(FIX, f"mengunduh model {model} (sekali saja, ~1 GB) ...")
    r = run([exe, "pull", model])
    ok = r.returncode == 0 and model_present(ollama_api(host, "/api/tags"), model)
    say(OK if ok else BAD, f"model {model} {'siap' if ok else 'gagal diunduh'}")
    return ok


def install_ollama():
    if IS_WIN:
        if shutil.which("winget"):
            r = run(["winget", "install", "-e", "--id", "Ollama.Ollama", "--silent", "--accept-package-agreements", "--accept-source-agreements"])
            if r.returncode == 0 and find_ollama():
                return find_ollama()
        try:
            tmp = Path(os.getenv("TEMP", ROOT)) / "OllamaSetup.exe"
            say(FIX, "mengunduh OllamaSetup.exe ...")
            tmp.write_bytes(download("https://ollama.com/download/OllamaSetup.exe", 600))
            run([str(tmp), "/VERYSILENT", "/NORESTART"])
        except Exception as exc:
            say(BAD, f"unduhan Ollama gagal: {exc}")
        return find_ollama()
    if sys.platform == "darwin" and shutil.which("brew"):
        run(["brew", "install", "ollama"])
        return find_ollama()
    try:
        sh = download("https://ollama.com/install.sh", 60)
        run(["sh"], input=sh.decode(), text=True)
    except Exception as exc:
        say(BAD, f"install.sh Ollama gagal: {exc}")
    return find_ollama()


def step_env(check, prompt):
    """Tidak ada kredensial wajib: cukup pastikan .env ada (dibuat dari .env.example)."""
    envf, ex = ROOT / ".env", ROOT / ".env.example"
    if not envf.exists():
        if check:
            say(BAD, ".env belum ada")
            return False
        shutil.copy(ex, envf)
        say(FIX, ".env dibuat dari .env.example")
    say(OK, ".env siap (tidak ada kredensial wajib; kunci admin & user website dibuat otomatis saat start)")
    return True


def set_env(key, value, path=None):
    f = path or (ROOT / ".env")
    lines = f.read_text(encoding="utf-8").splitlines() if f.exists() else []
    for i, ln in enumerate(lines):
        if ln.split("=", 1)[0].strip() == key:
            lines[i] = f"{key}={value}"
            break
    else:
        lines.append(f"{key}={value}")
    f.write_text("\n".join(lines) + "\n", encoding="utf-8")


def req_hash():
    return hashlib.sha256((ROOT / "requirements.txt").read_bytes()).hexdigest()[:16]


def main(argv):
    check, prompt = "--check" in argv, "--no-prompt" not in argv
    print("=" * 60 + "\n TERMINAL — pemeriksaan & instalasi bahan\n" + "=" * 60)
    results = {}
    results["python"] = step_python()
    if not results["python"]:
        return 1
    results["venv"] = step_venv(check)
    results["modul"] = results["venv"] and step_requirements(check)
    results["cloudflared"] = step_cloudflared(check)
    results["ollama"] = True if "--no-ollama" in argv else step_ollama(check)
    results["env"] = step_env(check, prompt)
    print("\n" + "-" * 60)
    for k, v in results.items():
        say(OK if v else BAD, k)
    core = results["venv"] and results["modul"] and results["cloudflared"]
    if core and not check:
        MARK.write_text(json.dumps(dict(req=req_hash(), python=platform.python_version(), ts=int(time.time()))), encoding="utf-8")
    if not results["ollama"]:
        print("\nCatatan: tanpa Ollama, aplikasi tetap berjalan penuh; hanya narasi AI yang diganti ringkasan otomatis.")
    return 0 if core and results["env"] else 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
