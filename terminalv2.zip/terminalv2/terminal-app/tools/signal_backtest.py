"""Backtest walk-forward engine SIGNAL pada data harga nyata (tanpa look-ahead, biaya spread dihitung).

Pemakaian:
  python tools/signal_backtest.py --mode swing
  python tools/signal_backtest.py --mode intraday --pairs EURUSD,GBPUSD,XAUUSD --be 1
  python tools/signal_backtest.py --mode scalp

Data (publik, diunduh otomatis ke ./data_backtest via git): github.com/komo135/forex-historical-data (FX & XAUUSD, D1/H1/M15, 2012-2022),
github.com/getdata-finance/eurusd-1m-ohlcv-forex-historical-data (EURUSD 1 menit -> M5), github.com/michael-chow-arch/goldfxgraph (XAUUSD D1 2000-2026).
Lapisan Fundamental TIDAK ikut diuji (tidak ada data makro historis per bar); lapisan 1,2,4 (Teknikal, Volume Profile/Liquidity, Quant) ikut.
"""
import argparse
import os
import subprocess
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
DATA = os.path.join(ROOT, "data_backtest")
from terminal.signals import ctx, engine, tracker  # noqa: E402

REPOS = {"fx": "komo135/forex-historical-data", "m1": "getdata-finance/eurusd-1m-ohlcv-forex-historical-data", "xau": "michael-chow-arch/goldfxgraph"}


def fetch(key):
    d = os.path.join(DATA, REPOS[key].split("/")[1])
    if not os.path.isdir(d):
        os.makedirs(DATA, exist_ok=True)
        subprocess.check_call(["git", "clone", "-q", "--depth", "1", "https://github.com/" + REPOS[key], d])
    return d


def scale(sym):
    return 100 if sym == "XAUUSD" else (1000 if sym.endswith("JPY") else 100000)


def load_fx(sym, tf):
    d = pd.read_csv(f"{fetch('fx')}/{sym}/{sym}{tf}.csv")
    d.columns = ["t", "o", "h", "l", "c", "v"]
    d = d.set_index(pd.to_datetime(d["t"])).drop(columns="t")
    for k in "ohlc":
        d[k] = d[k] / scale(sym)
    return d


def load_m5():
    m = pd.read_csv(f"{fetch('m1')}/EURUSD_1m.csv", parse_dates=["datetime"]).set_index("datetime")
    m.index = m.index.tz_localize(None)
    m.columns = ["o", "h", "l", "c", "v"]
    return m.resample("5min").agg({"o": "first", "h": "max", "l": "min", "c": "last", "v": "sum"}).dropna()


def load_xau_long():
    d = pd.read_csv(f"{fetch('xau')}/data/raw/xauusd_daily.csv", parse_dates=["Date"]).set_index("Date")
    d.columns = ["o", "h", "l", "c"]
    d["v"] = 0.0
    return d


def run(x, be=True, cost_frac=0.0001, start=300, book=None):
    cfg = x.cfg
    book = book or engine.Book(x, be, cost_frac).build()
    rows, last = [], -10 ** 9
    for i in range(start, x.n - 1, max(1, cfg["expiry"] // 2)):
        if i - last < cfg["expiry"]:
            continue
        r = engine.analyze_at(x, i, book, None, be, None, cost_frac)
        if r["signal"] == "WAIT":
            continue
        s = tracker.simulate(r["plan"], x.o, x.h, x.l, x.c, i, be)
        last = i
        if s["status"] == "CLOSED":
            rows.append((x.df.index[i], r["plan"]["d"], s["r"], s["tp_hits"] >= 1, s["tp_hits"]))
    return pd.DataFrame(rows, columns=["t", "d", "r", "win", "hits"])


def summ(df):
    if not len(df):
        return "n=0"
    gl, gp = -df.r[df.r < 0].sum(), df.r[df.r > 0].sum()
    return f"n={len(df)}  win(TP1)={df.win.mean()*100:.1f}%  rata-rata={df.r.mean():+.3f}R  PF={gp/gl if gl > 0 else float('inf'):.2f}  TP2+={((df.hits>=2).mean()*100):.0f}%  TPMAX={((df.hits>=3).mean()*100):.0f}%"


def per_method(x, cost_frac, be=True):
    """Riset satu per satu: tiap metode berdiri sendiri (tanpa suara mayoritas) dengan struktur TP yang sama. raw = hipotesis teknikal mentah,
    validated = setelah validasi Volume Profile & Liquidity (langkah 2)."""
    from terminal.signals import plan as P
    from terminal.signals.config import TP_R, TP_WEIGHTS
    from terminal.signals.methods import NAMES
    cfg, out = x.cfg, {}
    for name in NAMES:
        o = x.out[name]
        for validated in (False, True):
            rows, last = [], -10 ** 9
            for i in range(300, x.n - 1):
                d = int(o["d"][i])
                if d == 0 or i - last < cfg["expiry"]:
                    continue
                if validated:
                    pl = P.build_plan(x, i, d, o["e"][i], o["sl"][i], o["q"][i])
                    if pl is None:
                        continue
                else:
                    risk = abs(o["e"][i] - o["sl"][i])
                    pl = dict(d=d, entry=o["e"][i], sl=o["sl"][i], tp=[o["e"][i] + d * m * risk for m in TP_R[x.mode]])
                pl.update(w=TP_WEIGHTS, expiry=cfg["expiry"], max_hold=cfg["max_hold"], cost=cost_frac * x.c[i])
                last = i
                s = tracker.simulate(pl, x.o, x.h, x.l, x.c, i, be)
                if s["status"] == "CLOSED":
                    rows.append((x.df.index[i], d, s["r"], s["tp_hits"] >= 1, s["tp_hits"]))
            out[(name, validated)] = pd.DataFrame(rows, columns=["t", "d", "r", "win", "hits"])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="swing", choices=["scalp", "intraday", "swing"])
    ap.add_argument("--pairs", default="")
    ap.add_argument("--be", type=int, default=1)
    ap.add_argument("--per-method", action="store_true", help="uji tiap metode sendiri-sendiri (riset), bukan ensemble")
    a = ap.parse_args()
    be = bool(a.be)
    sets = []
    if a.mode == "scalp":
        sets.append(("EURUSD M5 (1 mnt -> M5, 2026)", load_m5(), 0.0001))
    else:
        tf = "h1" if a.mode == "intraday" else "d1"
        pairs = a.pairs.split(",") if a.pairs else (["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "XAUUSD"] if a.mode == "intraday" else ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "XAUUSD", "USDCAD", "USDCHF"])
        sets += [(p, load_fx(p, tf), 0.00016 if p == "XAUUSD" else 0.0001) for p in pairs]
        if a.mode == "swing":
            sets.append(("XAUUSD D1 2000-2026", load_xau_long(), 0.00016))
    if a.per_method:
        from terminal.signals.methods import NAMES
        acc = {}
        for name, df, cf in sets:
            x = ctx.build(df, a.mode)
            for k, v in per_method(x, cf, be).items():
                acc.setdefault(k, []).append(v)
        print(f"{'metode':9s} {'MENTAH (hipotesis teknikal)':58s} DIVALIDASI (Volume Profile & Liquidity)")
        for n in NAMES:
            print(f"{n:9s} {summ(pd.concat(acc[(n, False)])):58s} {summ(pd.concat(acc[(n, True)]))}")
        return
    allr = []
    for name, df, cf in sets:
        x = ctx.build(df, a.mode)
        r = run(x, be, cf)
        r["pair"] = name
        allr.append(r)
        print(f"{name:32s} {summ(r)}", flush=True)
    full = pd.concat(allr)
    cut = full.t.sort_values().iloc[len(full) // 2]
    print("-" * 100)
    print(f"{'GABUNGAN':32s} {summ(full)}")
    print(f"{'  paruh pertama (in-sample)':32s} {summ(full[full.t < cut])}")
    print(f"{'  paruh kedua (out-of-sample)':32s} {summ(full[full.t >= cut])}")


if __name__ == "__main__":
    main()
